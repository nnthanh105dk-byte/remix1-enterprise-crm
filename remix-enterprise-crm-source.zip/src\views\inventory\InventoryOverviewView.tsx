import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { WarehouseProduct } from '../../data/mockWarehouseData';
import { useColumnVisibility, ColumnDef } from '../../hooks/useColumnVisibility';
import { ColumnVisibilityPicker } from '../../components/common/ColumnVisibilityPicker';

const INVENTORY_COLUMNS: ColumnDef[] = [
  { id: 'sku_name', label: 'Mã SKU & Tên sản phẩm', required: true },
  { id: 'category', label: 'Nhóm hàng' },
  { id: 'unit', label: 'ĐVT' },
  { id: 'actualStock', label: 'Tồn thực tế' },
  { id: 'reserved', label: 'Đang giữ chỗ' },
  { id: 'available', label: 'Tồn khả dụng' },
  { id: 'minSafeStock', label: 'Mức tối thiểu' },
  { id: 'costPrice', label: 'Giá vốn (VND)' },
  { id: 'totalValue', label: 'Giá trị tồn' },
  { id: 'classification', label: 'Phân loại ABC' },
  { id: 'status', label: 'Trạng thái' },
];

import {
  Boxes,
  DollarSign,
  AlertTriangle,
  XCircle,
  Clock,
  CalendarClock,
  Search,
  Filter,
  ArrowRight,
  TrendingUp,
  PieChart,
  Layers,
  Building,
  Plus,
  ArrowUpFromLine,
  ArrowDownToLine,
  X,
  FileSpreadsheet,
  BarChart2,
} from 'lucide-react';

export const InventoryOverviewView: React.FC = () => {
  const { setActiveModule, themeDef, showToast } = useCRM();
  const { warehouses, products, lots, stockMoves } = useWarehouse();

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [onlyNeedRestock, setOnlyNeedRestock] = useState<boolean>(false);

  // Selected Product for Right Drawer
  const [drawerProduct, setDrawerProduct] = useState<WarehouseProduct | null>(null);

  const {
    columns: colDefs,
    visibleColumns,
    isVisible,
    toggleColumn,
    selectAll,
    resetToDefault,
  } = useColumnVisibility('inventory_overview', INVENTORY_COLUMNS);


  // Calculations for KPIs
  const totalSKUs = products.length;
  const totalInventoryValue = products.reduce((sum, p) => {
    const totalQty = Object.values(p.stocks).reduce((q, val) => q + val, 0);
    return sum + totalQty * p.costPrice;
  }, 0);

  const lowStockCount = products.filter((p) => {
    const totalQty = Object.values(p.stocks).reduce((q, val) => q + val, 0);
    const available = Math.max(0, totalQty - p.reserved);
    return available > 0 && available < p.minSafeStock;
  }).length;

  const outOfStockCount = products.filter((p) => {
    const totalQty = Object.values(p.stocks).reduce((q, val) => q + val, 0);
    return totalQty === 0;
  }).length;

  const stagnantCount = 2; // SKU không biến động > 90 ngày

  // Lô sắp hết hạn (<= 90 ngày)
  const expiringLotsCount = lots.filter((l) => {
    const exp = new Date(l.expiryDate).getTime();
    const now = new Date('2026-10-04').getTime();
    const diffDays = Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
    return diffDays <= 90;
  }).length;

  // Filtered Products
  const filteredProducts = products.filter((p) => {
    const totalQty =
      selectedWarehouseId === 'all'
        ? Object.values(p.stocks).reduce((sum, val) => sum + val, 0)
        : p.stocks[selectedWarehouseId] || 0;
    const available = Math.max(0, totalQty - p.reserved);

    if (selectedCategory !== 'all' && p.category !== selectedCategory) return false;

    // Status filter
    if (selectedStatus === 'in_stock' && available <= p.minSafeStock) return false;
    if (selectedStatus === 'low_stock' && (available === 0 || available >= p.minSafeStock)) return false;
    if (selectedStatus === 'out_of_stock' && totalQty > 0) return false;

    // Quick filter: Chỉ hiện hàng cần nhập thêm
    if (onlyNeedRestock && available >= p.minSafeStock) return false;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const match =
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.barcode.includes(q) ||
        p.supplierName.toLowerCase().includes(q);
      if (!match) return false;
    }

    return true;
  });

  // ABC Analysis Calculation
  // A: 70% giá trị, B: 20%, C: 10%
  const sortedByVal = [...products].sort((a, b) => {
    const valA = Object.values(a.stocks).reduce((s, v) => s + v, 0) * a.costPrice;
    const valB = Object.values(b.stocks).reduce((s, v) => s + v, 0) * b.costPrice;
    return valB - valA;
  });

  const getABCClass = (p: WarehouseProduct): 'A' | 'B' | 'C' => {
    const idx = sortedByVal.findIndex((it) => it.id === p.id);
    if (idx < 3) return 'A';
    if (idx < 7) return 'B';
    return 'C';
  };

  const handleExportExcel = () => {
    showToast('Xuất báo cáo tồn kho', 'Đang tải xuống tệp Excel tồn kho chi tiết.', 'success');
  };

  return (
    <div className="space-y-6">
      {/* 6 Top KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* 1. Tổng SKU */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold">Tổng mã SKU</span>
            <Boxes className="w-4 h-4 text-sky-500" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-1 font-mono">
            {totalSKUs}
          </h3>
          <p className="text-[10px] text-slate-400 mt-0.5">3 kho đang hoạt động</p>
        </div>

        {/* 2. Tổng giá trị tồn */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold">Tổng giá trị tồn</span>
            <DollarSign className="w-4 h-4 text-emerald-500" />
          </div>
          <h3 className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-1 font-mono">
            {(totalInventoryValue / 1000000000).toFixed(2)} Tỷ
          </h3>
          <p className="text-[10px] text-slate-400 mt-0.5">Theo giá vốn bình quân</p>
        </div>

        {/* 3. Dưới mức tối thiểu */}
        <div className="bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-900/60 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-amber-700 dark:text-amber-400">
            <span className="text-[11px] font-semibold">Dưới mức tối thiểu</span>
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          </div>
          <h3 className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-1 font-mono">
            {lowStockCount} mã
          </h3>
          <button
            onClick={() => setOnlyNeedRestock(true)}
            className="text-[10px] text-amber-700 dark:text-amber-300 font-semibold hover:underline mt-0.5"
          >
            Lọc mã cần nhập →
          </button>
        </div>

        {/* 4. Hết hàng */}
        <div className="bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/60 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-rose-700 dark:text-rose-400">
            <span className="text-[11px] font-semibold">Hết hàng (Tồn = 0)</span>
            <XCircle className="w-4 h-4 text-rose-500" />
          </div>
          <h3 className="text-xl font-bold text-rose-600 dark:text-rose-400 mt-1 font-mono">
            {outOfStockCount} mã
          </h3>
          <p className="text-[10px] text-rose-600/80 mt-0.5">Cần đặt hàng khẩn cấp</p>
        </div>

        {/* 5. Tồn lâu > 90 ngày */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold">Tồn chậm (&gt;90 ngày)</span>
            <Clock className="w-4 h-4 text-purple-500" />
          </div>
          <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-1 font-mono">
            {stagnantCount} mã
          </h3>
          <p className="text-[10px] text-slate-400 mt-0.5">Cần giải phóng vốn</p>
        </div>

        {/* 6. Lô sắp hết hạn -> Click chuyển sang trang "Hàng sắp hết hạn" */}
        <div
          onClick={() => setActiveModule('inventory-expiry')}
          className="bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-xl p-3.5 shadow-xs cursor-pointer hover:border-amber-500 transition-all group"
        >
          <div className="flex items-center justify-between text-amber-800 dark:text-amber-300">
            <span className="text-[11px] font-bold">Lô sắp hết hạn</span>
            <CalendarClock className="w-4 h-4 text-amber-600 group-hover:scale-110 transition-transform" />
          </div>
          <h3 className="text-xl font-bold text-amber-700 dark:text-amber-300 mt-1 font-mono">
            {expiringLotsCount} lô
          </h3>
          <span className="text-[10px] font-semibold text-amber-800 dark:text-amber-200 flex items-center gap-0.5 mt-0.5">
            Xem cảnh báo <ArrowRight className="w-3 h-3" />
          </span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Search by name/sku/barcode */}
          <div className="relative max-w-sm w-full">
            <input
              type="text"
              placeholder="Tìm theo mã SKU, tên hàng, mã vạch (quét barcode)..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>

          {/* Quick Filter: Chỉ hiện hàng cần nhập & Export */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => setOnlyNeedRestock(!onlyNeedRestock)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                onlyNeedRestock
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Chỉ hiện hàng cần nhập thêm</span>
            </button>

            <button
              onClick={handleExportExcel}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-semibold shadow-xs"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Xuất Excel</span>
            </button>
          </div>
        </div>

        {/* Dropdowns */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Kho hàng</label>
            <select
              value={selectedWarehouseId}
              onChange={(e) => setSelectedWarehouseId(e.target.value)}
              className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả kho (Tổng hợp)</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Nhóm hàng</label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả nhóm hàng</option>
              <option value="Thiết bị công nghệ & IoT">Thiết bị công nghệ & IoT</option>
              <option value="Phần cứng Máy chủ & Mạng">Phần cứng Máy chủ & Mạng</option>
              <option value="Linh kiện & Phụ kiện">Linh kiện & Phụ kiện</option>
              <option value="Vật tư tiêu hao">Vật tư tiêu hao</option>
              <option value="Dược & Hóa phẩm bảo trì">Dược & Hóa phẩm bảo trì</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Trạng thái tồn</label>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="in_stock">Bình thường (Đủ hàng)</option>
              <option value="low_stock">Sắp hết (Dưới tối thiểu)</option>
              <option value="out_of_stock">Hết hàng (Tồn = 0)</option>
            </select>
          </div>

          <div className="flex items-end justify-between sm:justify-end gap-3 flex-1">
            <span className="text-xs text-slate-500 pb-1">
              Hiển thị <span className="font-bold text-slate-900 dark:text-white">{filteredProducts.length}</span> mã hàng
            </span>
            <ColumnVisibilityPicker
              columns={colDefs}
              visibleColumns={visibleColumns}
              onToggle={toggleColumn}
              onSelectAll={selectAll}
              onReset={resetToDefault}
            />
          </div>
        </div>
      </div>

      {/* Main Inventory Table */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-4 sm:p-5 shadow-xs space-y-4`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                {isVisible('sku_name') && <th className="py-3 px-3">Mã SKU & Tên sản phẩm</th>}
                {isVisible('category') && <th className="py-3 px-3">Nhóm hàng</th>}
                {isVisible('unit') && <th className="py-3 px-3 text-center">ĐVT</th>}
                {isVisible('actualStock') && <th className="py-3 px-3 text-right">Tồn thực tế</th>}
                {isVisible('reserved') && <th className="py-3 px-3 text-right">Đang giữ chỗ</th>}
                {isVisible('available') && <th className="py-3 px-3 text-right">Tồn khả dụng</th>}
                {isVisible('minSafeStock') && <th className="py-3 px-3 text-right">Mức tối thiểu</th>}
                {onlyNeedRestock && <th className="py-3 px-3 text-right text-amber-600">Đề xuất nhập</th>}
                {isVisible('costPrice') && <th className="py-3 px-3 text-right">Giá vốn (VND)</th>}
                {isVisible('totalValue') && <th className="py-3 px-3 text-right">Giá trị tồn</th>}
                {isVisible('classification') && <th className="py-3 px-3 text-center">Phân loại</th>}
                {isVisible('status') && <th className="py-3 px-3 text-center">Trạng thái</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredProducts.map((p) => {
                const totalQty =
                  selectedWarehouseId === 'all'
                    ? Object.values(p.stocks).reduce((sum, val) => sum + val, 0)
                    : p.stocks[selectedWarehouseId] || 0;
                const available = Math.max(0, totalQty - p.reserved);
                const isOutOfStock = totalQty === 0;
                const isLowStock = !isOutOfStock && available < p.minSafeStock;
                const totalValue = totalQty * p.costPrice;
                const restockSuggest = Math.max(0, p.optimalStock - available);
                const abc = getABCClass(p);

                return (
                  <tr
                    key={p.id}
                    onClick={() => setDrawerProduct(p)}
                    className={`cursor-pointer transition-colors ${
                      isOutOfStock
                        ? 'bg-rose-50/30 dark:bg-rose-950/20 hover:bg-rose-50/50'
                        : isLowStock
                        ? 'bg-amber-50/30 dark:bg-amber-950/20 hover:bg-amber-50/50'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    {isVisible('sku_name') && (
                      <td className="py-3 px-3">
                        <p className="font-bold text-slate-900 dark:text-white hover:text-sky-600 transition-colors">
                          {p.name}
                        </p>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="font-mono text-[10px] font-bold text-sky-600">{p.sku}</span>
                          {p.trackExpiry && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 font-medium">
                              Theo dõi lô/hạn
                            </span>
                          )}
                        </div>
                      </td>
                    )}

                    {isVisible('category') && (
                      <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                        {p.category}
                      </td>
                    )}

                    {isVisible('unit') && (
                      <td className="py-3 px-3 text-center text-slate-500">
                        {p.unit}
                      </td>
                    )}

                    {isVisible('actualStock') && (
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                        {totalQty}
                      </td>
                    )}

                    {isVisible('reserved') && (
                      <td className="py-3 px-3 text-right font-mono text-slate-400">
                        {p.reserved}
                      </td>
                    )}

                    {isVisible('available') && (
                      <td className="py-3 px-3 text-right font-mono font-bold text-sky-600 dark:text-sky-400">
                        {available}
                      </td>
                    )}

                    {isVisible('minSafeStock') && (
                      <td className="py-3 px-3 text-right font-mono text-slate-500">
                        {p.minSafeStock}
                      </td>
                    )}

                    {onlyNeedRestock && (
                      <td className="py-3 px-3 text-right font-mono font-bold text-amber-600">
                        +{restockSuggest}
                      </td>
                    )}

                    {isVisible('costPrice') && (
                      <td className="py-3 px-3 text-right font-mono text-slate-600 dark:text-slate-400">
                        {p.costPrice.toLocaleString('vi-VN')} đ
                      </td>
                    )}

                    {isVisible('totalValue') && (
                      <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {(totalValue / 1000000).toLocaleString('vi-VN')} Tr
                      </td>
                    )}

                    {isVisible('classification') && (
                      <td className="py-3 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          abc === 'A' ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300' :
                          abc === 'B' ? 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300' :
                          'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                        }`}>
                          Nhóm {abc}
                        </span>
                      </td>
                    )}

                    {isVisible('status') && (
                      <td className="py-3 px-3 text-center">
                        {isOutOfStock ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                            Hết hàng
                          </span>
                        ) : isLowStock ? (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                            Sắp hết
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                            Bình thường
                          </span>
                        )}
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Right Drawer: Product Inventory Detail Inspector */}
      {drawerProduct && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 w-full max-w-xl h-full shadow-2xl p-6 overflow-y-auto border-l border-slate-200 dark:border-slate-800 flex flex-col justify-between animate-in slide-in-from-right duration-200">
            <div>
              {/* Header */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-4">
                <div>
                  <span className="text-xs font-mono font-bold text-sky-600">{drawerProduct.sku}</span>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                    {drawerProduct.name}
                  </h3>
                  <p className="text-xs text-slate-500">{drawerProduct.category} • NCC: {drawerProduct.supplierName}</p>
                </div>
                <button
                  onClick={() => setDrawerProduct(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Tồn theo từng kho */}
              <div className="space-y-2 mb-5">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Building className="w-3.5 h-3.5 text-sky-500" />
                  Phân bổ tồn kho theo chi nhánh
                </h4>
                <div className="grid grid-cols-3 gap-2">
                  {warehouses.map((w) => {
                    const qty = drawerProduct.stocks[w.id] || 0;
                    return (
                      <div key={w.id} className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-800">
                        <span className="text-[11px] text-slate-500 truncate block">{w.name.replace('Kho ', '')}</span>
                        <p className="text-lg font-bold font-mono text-slate-900 dark:text-white mt-1">
                          {qty} <span className="text-xs font-normal text-slate-400">{drawerProduct.unit}</span>
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Tồn theo Lô & Hạn sử dụng */}
              {drawerProduct.trackExpiry && (
                <div className="space-y-2 mb-5">
                  <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                    <CalendarClock className="w-3.5 h-3.5 text-amber-500" />
                    Chi tiết Lô hàng &amp; Hạn sử dụng (FEFO)
                  </h4>
                  <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-bold">
                        <tr>
                          <th className="py-2 px-2.5">Số Lô</th>
                          <th className="py-2 px-2.5">Kho</th>
                          <th className="py-2 px-2.5 text-right">SL Còn</th>
                          <th className="py-2 px-2.5 text-right">Hạn dùng</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {lots.filter((l) => l.sku === drawerProduct.sku).map((l) => (
                          <tr key={l.id}>
                            <td className="py-2 px-2.5 font-mono font-bold text-slate-800 dark:text-slate-200">{l.lotNumber}</td>
                            <td className="py-2 px-2.5 text-slate-500">{l.warehouseName.replace('Kho ', '')}</td>
                            <td className="py-2 px-2.5 text-right font-mono font-bold">{l.quantity}</td>
                            <td className="py-2 px-2.5 text-right font-mono text-amber-600">{l.expiryDate}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* 10 Giao dịch gần nhất */}
              <div className="space-y-2 mb-5">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-purple-500" />
                  Giao dịch phát sinh gần nhất
                </h4>
                <div className="space-y-1.5">
                  {stockMoves.filter((m) => m.sku === drawerProduct.sku).slice(0, 5).map((m) => (
                    <div key={m.id} className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                            m.quantity > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                          }`}>
                            {m.type}
                          </span>
                          <span className="font-mono text-slate-500">{m.refCode}</span>
                        </div>
                        <p className="text-[11px] text-slate-500 mt-0.5">{m.timestamp} • {m.performedBy}</p>
                      </div>
                      <span className={`font-mono font-bold text-sm ${m.quantity > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {m.quantity > 0 ? `+${m.quantity}` : m.quantity} {drawerProduct.unit}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Action Buttons */}
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
              <button
                onClick={() => {
                  setDrawerProduct(null);
                  setActiveModule('inventory-stock-in');
                }}
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-xs"
              >
                <ArrowDownToLine className="w-4 h-4" />
                <span>Tạo phiếu nhập</span>
              </button>

              <button
                onClick={() => {
                  setDrawerProduct(null);
                  setActiveModule('inventory-stock-out');
                }}
                className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-xs"
              >
                <ArrowUpFromLine className="w-4 h-4" />
                <span>Tạo phiếu xuất</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
