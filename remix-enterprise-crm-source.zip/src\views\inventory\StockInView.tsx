import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { StockInReceipt, StockInItem } from '../../data/mockWarehouseData';
import {
  ArrowDownToLine,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Printer,
  FileSpreadsheet,
  Trash2,
  X,
  Upload,
  Calendar,
  Building,
  User,
  AlertCircle,
  FileText,
} from 'lucide-react';

export interface StockInViewProps {
  viewMode?: 'warehouse' | 'logistics';
}

export const StockInView: React.FC<StockInViewProps> = ({ viewMode = 'warehouse' }) => {
  const { themeDef, showToast, setActiveModule } = useCRM();
  const {
    warehouses,
    products,
    stockInReceipts,
    createStockInReceipt,
    approveStockInReceipt,
    cancelStockInReceipt,
  } = useWarehouse();

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [excelModalOpen, setExcelModalOpen] = useState(false);
  const [printReceipt, setPrintReceipt] = useState<StockInReceipt | null>(null);

  // Form State for Creating Receipt
  const [formDate, setFormDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [formImportType, setFormImportType] = useState<StockInReceipt['importType']>('Mua hàng từ nhà cung cấp');
  const [formWarehouseId, setFormWarehouseId] = useState<string>(warehouses[0]?.id || 'wh-hn');
  const [formSupplierName, setFormSupplierName] = useState<string>('HPE Việt Nam (Phân phối FPT)');
  const [formInvoiceNumber, setFormInvoiceNumber] = useState<string>('');
  const [formNotes, setFormNotes] = useState<string>('');
  const [formItems, setFormItems] = useState<StockInItem[]>([
    {
      sku: products[0]?.sku || '',
      productName: products[0]?.name || '',
      quantity: 5,
      unitPrice: products[0]?.costPrice || 0,
      lotNumber: 'LOT-2026-N01',
      mfgDate: '2026-09-01',
      expDate: '2027-09-01',
      shelfLocation: 'Kệ A-01',
      total: (products[0]?.costPrice || 0) * 5,
    },
  ]);

  // Filtered receipts
  const filteredReceipts = stockInReceipts.filter((r) => {
    if (selectedWarehouseId !== 'all' && r.warehouseId !== selectedWarehouseId) return false;
    if (selectedStatus !== 'all' && r.status !== selectedStatus) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const match =
        r.receiptNumber.toLowerCase().includes(q) ||
        r.supplierName.toLowerCase().includes(q) ||
        r.invoiceNumber.toLowerCase().includes(q) ||
        r.createdBy.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Add Item Line
  const handleAddItemLine = () => {
    const firstProd = products[0];
    setFormItems((prev) => [
      ...prev,
      {
        sku: firstProd.sku,
        productName: firstProd.name,
        quantity: 1,
        unitPrice: firstProd.costPrice,
        lotNumber: '',
        mfgDate: '',
        expDate: '',
        shelfLocation: '',
        total: firstProd.costPrice,
      },
    ]);
  };

  const handleRemoveItemLine = (index: number) => {
    if (formItems.length === 1) return;
    setFormItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleItemSkuChange = (index: number, newSku: string) => {
    const selectedProd = products.find((p) => p.sku === newSku);
    if (!selectedProd) return;

    setFormItems((prev) =>
      prev.map((item, idx) =>
        idx === index
          ? {
              ...item,
              sku: selectedProd.sku,
              productName: selectedProd.name,
              unitPrice: selectedProd.costPrice,
              total: selectedProd.costPrice * item.quantity,
            }
          : item
      )
    );
  };

  const handleItemQuantityChange = (index: number, qty: number) => {
    const safeQty = Math.max(1, qty);
    setFormItems((prev) =>
      prev.map((item, idx) =>
        idx === index
          ? {
              ...item,
              quantity: safeQty,
              total: safeQty * item.unitPrice,
            }
          : item
      )
    );
  };

  const handleItemPriceChange = (index: number, price: number) => {
    const safePrice = Math.max(0, price);
    setFormItems((prev) =>
      prev.map((item, idx) =>
        idx === index
          ? {
              ...item,
              unitPrice: safePrice,
              total: item.quantity * safePrice,
            }
          : item
      )
    );
  };

  const totalFormQuantity = formItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalFormAmount = formItems.reduce((sum, item) => sum + item.total, 0);

  const handleSubmitCreateReceipt = (e: React.FormEvent) => {
    e.preventDefault();
    const wh = warehouses.find((w) => w.id === formWarehouseId);

    createStockInReceipt({
      date: formDate,
      importType: formImportType,
      warehouseId: formWarehouseId,
      warehouseName: wh ? wh.name : 'Kho Tổng',
      supplierName: formSupplierName,
      invoiceNumber: formInvoiceNumber || `HD-${Date.now().toString().slice(-6)}`,
      notes: formNotes,
      items: formItems,
      totalQuantity: totalFormQuantity,
      totalAmount: totalFormAmount,
      createdBy: 'Nguyễn Văn Định (Thủ kho)',
    });

    setCreateModalOpen(false);
  };

  const handleSimulateExcelImport = () => {
    showToast('Tải tệp Excel thành công', 'Đã thẩm định 3 dòng hàng hợp lệ từ tệp nhập kho.', 'success');
    setExcelModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/50">
              <ArrowDownToLine className="w-5 h-5" />
            </span>
            {viewMode === 'logistics' ? 'Nhập Kho Mua Hàng & Luân Chuyển (Phân hệ Vận chuyển)' : 'Quản lý Nhập kho (Stock In)'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {viewMode === 'logistics'
              ? 'Tiếp nhận hàng hóa từ Đơn mua hàng (PO), nhập kho theo lô FEFO và đối soát phục vụ lập Hóa đơn mua hàng (3-Way Matching).'
              : 'Quy trình lập, thẩm định và phê duyệt phiếu nhập kho; tự động cập nhật số dư tồn và giá vốn'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {viewMode === 'logistics' && (
            <button
              onClick={() => setActiveModule('logistics-purchase-orders')}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 hover:bg-emerald-100 transition-colors"
            >
              <span>Xem Đơn mua hàng (PO)</span>
            </button>
          )}

          <button
            onClick={() => setExcelModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 shadow-xs transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-emerald-600" />
            <span>Nhập từ Excel</span>
          </button>

          <button
            onClick={() => setCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001c42] shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Tạo phiếu nhập mới</span>
          </button>
        </div>
      </div>

      {viewMode === 'logistics' && (
        <div className="bg-emerald-50/80 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-xl p-3.5 flex items-center justify-between text-xs text-emerald-900 dark:text-emerald-200">
          <div>
            <p className="font-bold">Góc nhìn Logistics: Nhập kho từ PO nhà cung cấp</p>
            <p className="text-slate-500 dark:text-slate-400 text-[11px]">
              Phiếu nhập kho hoàn tất sẽ tự động liên kết với Hóa đơn mua hàng để chạy quy trình kiểm soát 3 bên (PO - Phiếu Nhập - Hóa Đơn).
            </p>
          </div>
          <button
            onClick={() => setActiveModule('logistics-purchase-invoices')}
            className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold shrink-0 text-xs shadow-xs"
          >
            Đối chiếu hóa đơn mua hàng &rarr;
          </button>
        </div>
      )}

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative max-w-sm w-full">
            <input
              type="text"
              placeholder="Tìm theo số phiếu, nhà cung cấp, hóa đơn..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedWarehouseId}
              onChange={(e) => setSelectedWarehouseId(e.target.value)}
              className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả kho nhận</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="Chờ duyệt">Chờ duyệt</option>
              <option value="Đã nhập kho">Đã nhập kho (Hoàn tất)</option>
              <option value="Đã hủy">Đã hủy</option>
            </select>
          </div>
        </div>
      </div>

      {/* Receipts Table */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-4 sm:p-5 shadow-xs space-y-4`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">Số phiếu</th>
                <th className="py-3 px-3">Ngày nhập</th>
                <th className="py-3 px-3">Loại nhập</th>
                <th className="py-3 px-3">Kho nhận</th>
                <th className="py-3 px-3">Nhà cung cấp / Nguồn</th>
                <th className="py-3 px-3 text-center">Số lượng</th>
                <th className="py-3 px-3 text-right">Tổng giá trị</th>
                <th className="py-3 px-3">Người lập</th>
                <th className="py-3 px-3 text-center">Trạng thái</th>
                <th className="py-3 px-3 text-center">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredReceipts.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-3">
                    <span className="font-mono font-bold text-sky-600">{r.receiptNumber}</span>
                    <p className="text-[10px] text-slate-400">{r.invoiceNumber}</p>
                  </td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-400">{r.date}</td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">{r.importType}</td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">{r.warehouseName}</td>
                  <td className="py-3 px-3 text-slate-900 dark:text-white font-semibold">{r.supplierName}</td>
                  <td className="py-3 px-3 text-center font-mono font-bold">{r.totalQuantity}</td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {(r.totalAmount / 1000000).toLocaleString('vi-VN')} Tr
                  </td>
                  <td className="py-3 px-3 text-slate-500">{r.createdBy.split('(')[0]}</td>
                  <td className="py-3 px-3 text-center">
                    {r.status === 'Đã nhập kho' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        Đã nhập kho
                      </span>
                    ) : r.status === 'Chờ duyệt' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 animate-pulse">
                        Chờ duyệt
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                        Đã hủy
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {r.status === 'Chờ duyệt' && (
                        <button
                          onClick={() => approveStockInReceipt(r.id)}
                          className="px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold shadow-xs"
                          title="Duyệt và cộng tồn kho"
                        >
                          Duyệt nhập
                        </button>
                      )}

                      <button
                        onClick={() => setPrintReceipt(r)}
                        className="p-1 rounded text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
                        title="In phiếu nhập kho (PDF)"
                      >
                        <Printer className="w-4 h-4" />
                      </button>

                      {r.status === 'Chờ duyệt' && (
                        <button
                          onClick={() => cancelStockInReceipt(r.id)}
                          className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50"
                          title="Hủy phiếu"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Tạo phiếu nhập mới */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <ArrowDownToLine className="w-5 h-5 text-emerald-600" />
                Lập Phiếu Nhập Kho Mới
              </h3>
              <button
                onClick={() => setCreateModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitCreateReceipt} className="space-y-4 text-xs">
              {/* Header Info */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Ngày nhập *</label>
                  <input
                    type="date"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    required
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Loại nhập *</label>
                  <select
                    value={formImportType}
                    onChange={(e) => setFormImportType(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-medium"
                  >
                    <option value="Mua hàng từ nhà cung cấp">Mua hàng từ nhà cung cấp</option>
                    <option value="Khách trả hàng">Khách trả hàng</option>
                    <option value="Nhập từ kho khác">Nhập từ kho khác (Điều chuyển)</option>
                    <option value="Nhập điều chỉnh kiểm kê">Nhập điều chỉnh kiểm kê</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Kho nhận *</label>
                  <select
                    value={formWarehouseId}
                    onChange={(e) => setFormWarehouseId(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-medium"
                  >
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Nhà cung cấp / Đối tác *</label>
                  <input
                    type="text"
                    value={formSupplierName}
                    onChange={(e) => setFormSupplierName(e.target.value)}
                    required
                    placeholder="VD: HPE Synnex FPT"
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Số HĐ / Chứng từ gốc</label>
                  <input
                    type="text"
                    value={formInvoiceNumber}
                    onChange={(e) => setFormInvoiceNumber(e.target.value)}
                    placeholder="VD: HD-883921"
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Ghi chú phiếu</label>
                  <input
                    type="text"
                    value={formNotes}
                    onChange={(e) => setFormNotes(e.target.value)}
                    placeholder="Ghi chú thêm về lô hàng..."
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>
              </div>

              {/* Items Table in Modal */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 dark:text-white">Chi tiết các mặt hàng nhập kho</h4>
                  <button
                    type="button"
                    onClick={handleAddItemLine}
                    className="text-xs text-sky-600 font-semibold hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Thêm dòng hàng
                  </button>
                </div>

                <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-x-auto">
                  <table className="w-full text-left text-xs min-w-[650px]">
                    <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold">
                      <tr>
                        <th className="py-2 px-2">Chọn sản phẩm (SKU)</th>
                        <th className="py-2 px-2 text-center w-20">SL</th>
                        <th className="py-2 px-2 text-right w-28">Đơn giá nhập</th>
                        <th className="py-2 px-2 w-28">Số Lô</th>
                        <th className="py-2 px-2 w-24">Hạn dùng</th>
                        <th className="py-2 px-2 text-right w-28">Thành tiền</th>
                        <th className="py-2 px-2 text-center w-10">Xóa</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {formItems.map((item, idx) => (
                        <tr key={idx}>
                          <td className="py-2 px-2">
                            <select
                              value={item.sku}
                              onChange={(e) => handleItemSkuChange(idx, e.target.value)}
                              className="w-full text-xs px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                            >
                              {products.map((p) => (
                                <option key={p.id} value={p.sku}>
                                  {p.sku} - {p.name}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="py-2 px-2">
                            <input
                              type="number"
                              min="1"
                              value={item.quantity}
                              onChange={(e) => handleItemQuantityChange(idx, parseInt(e.target.value) || 1)}
                              className="w-full text-center px-1 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono"
                            />
                          </td>
                          <td className="py-2 px-2 text-right">
                            <input
                              type="number"
                              min="0"
                              value={item.unitPrice}
                              onChange={(e) => handleItemPriceChange(idx, parseFloat(e.target.value) || 0)}
                              className="w-full text-right px-1 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono"
                            />
                          </td>
                          <td className="py-2 px-2">
                            <input
                              type="text"
                              placeholder="Số lô..."
                              value={item.lotNumber || ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFormItems((prev) =>
                                  prev.map((it, i) => (i === idx ? { ...it, lotNumber: val } : it))
                                );
                              }}
                              className="w-full px-1.5 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 font-mono text-[11px]"
                            />
                          </td>
                          <td className="py-2 px-2">
                            <input
                              type="date"
                              value={item.expDate || ''}
                              onChange={(e) => {
                                const val = e.target.value;
                                setFormItems((prev) =>
                                  prev.map((it, i) => (i === idx ? { ...it, expDate: val } : it))
                                );
                              }}
                              className="w-full px-1 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-[10px]"
                            />
                          </td>
                          <td className="py-2 px-2 text-right font-mono font-bold text-emerald-600">
                            {item.total.toLocaleString('vi-VN')} đ
                          </td>
                          <td className="py-2 px-2 text-center">
                            <button
                              type="button"
                              onClick={() => handleRemoveItemLine(idx)}
                              className="text-slate-400 hover:text-rose-500 p-1"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Total Summary Row */}
                <div className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800/80 font-bold">
                  <span>Tổng cộng phiếu:</span>
                  <div className="flex items-center gap-6 font-mono text-sm">
                    <span>Tổng SL: {totalFormQuantity}</span>
                    <span className="text-emerald-600 dark:text-emerald-400">
                      Tổng tiền: {totalFormAmount.toLocaleString('vi-VN')} đ
                    </span>
                  </div>
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001c42] shadow-xs"
                >
                  Lưu &amp; Chuyển duyệt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: In Phiếu Nhập Kho (PDF Preview) */}
      {printReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-xl max-w-2xl w-full p-8 shadow-2xl border border-slate-200 print:p-0 animate-in fade-in zoom-in-95 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-6 print:hidden">
              <span className="text-xs font-bold text-slate-500 uppercase">Mẫu phiếu nhập kho tiêu chuẩn (Mẫu số 01 - VT)</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-[#002659] text-white rounded text-xs font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" /> In ngay
                </button>
                <button
                  onClick={() => setPrintReceipt(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Header */}
            <div className="text-center space-y-1 mb-6">
              <p className="text-xs uppercase font-bold tracking-wider text-slate-500">CÔNG TY CỔ PHẦN CÔNG NGHỆ A+ VIỆT NAM</p>
              <h2 className="text-xl font-bold uppercase tracking-tight">PHIẾU NHẬP KHO</h2>
              <p className="text-xs text-slate-500">
                Ngày {printReceipt.date.split('-')[2]} tháng {printReceipt.date.split('-')[1]} năm {printReceipt.date.split('-')[0]}
              </p>
              <p className="text-xs font-mono font-bold text-sky-700">Số: {printReceipt.receiptNumber}</p>
            </div>

            {/* Info */}
            <div className="text-xs space-y-1.5 mb-5 leading-relaxed">
              <p>- Họ và tên người giao hàng: <strong>{printReceipt.supplierName}</strong></p>
              <p>- Theo chứng từ số: <strong>{printReceipt.invoiceNumber}</strong></p>
              <p>- Nhập tại kho: <strong>{printReceipt.warehouseName}</strong></p>
              <p>- Lý do nhập: <strong>{printReceipt.importType} ({printReceipt.notes})</strong></p>
            </div>

            {/* Items Table */}
            <table className="w-full text-left text-xs border-collapse border border-slate-300 mb-6">
              <thead className="bg-slate-100 font-bold">
                <tr>
                  <th className="border border-slate-300 p-2 text-center w-8">STT</th>
                  <th className="border border-slate-300 p-2">Tên sản phẩm &amp; Mã SKU</th>
                  <th className="border border-slate-300 p-2 text-center w-20">Số Lô</th>
                  <th className="border border-slate-300 p-2 text-center w-16">SL</th>
                  <th className="border border-slate-300 p-2 text-right w-24">Đơn giá</th>
                  <th className="border border-slate-300 p-2 text-right w-28">Thành tiền</th>
                </tr>
              </thead>
              <tbody>
                {printReceipt.items.map((it, idx) => (
                  <tr key={idx}>
                    <td className="border border-slate-300 p-2 text-center">{idx + 1}</td>
                    <td className="border border-slate-300 p-2">
                      <p className="font-bold">{it.productName}</p>
                      <span className="font-mono text-[10px] text-slate-500">{it.sku}</span>
                    </td>
                    <td className="border border-slate-300 p-2 text-center font-mono">{it.lotNumber || '-'}</td>
                    <td className="border border-slate-300 p-2 text-center font-bold font-mono">{it.quantity}</td>
                    <td className="border border-slate-300 p-2 text-right font-mono">{it.unitPrice.toLocaleString('vi-VN')} đ</td>
                    <td className="border border-slate-300 p-2 text-right font-mono font-bold">{it.total.toLocaleString('vi-VN')} đ</td>
                  </tr>
                ))}
                <tr className="bg-slate-50 font-bold">
                  <td colSpan={3} className="border border-slate-300 p-2 text-center">CỘNG TỔNG</td>
                  <td className="border border-slate-300 p-2 text-center font-mono">{printReceipt.totalQuantity}</td>
                  <td className="border border-slate-300 p-2"></td>
                  <td className="border border-slate-300 p-2 text-right font-mono text-emerald-700">
                    {printReceipt.totalAmount.toLocaleString('vi-VN')} đ
                  </td>
                </tr>
              </tbody>
            </table>

            {/* Signature Blocks */}
            <div className="grid grid-cols-4 gap-2 text-center text-xs pt-4 mb-8">
              <div>
                <p className="font-bold">Người lập phiếu</p>
                <p className="text-[10px] text-slate-400 italic">(Ký, họ tên)</p>
                <div className="h-16" />
                <p className="font-semibold">{printReceipt.createdBy.split('(')[0]}</p>
              </div>
              <div>
                <p className="font-bold">Người giao hàng</p>
                <p className="text-[10px] text-slate-400 italic">(Ký, họ tên)</p>
                <div className="h-16" />
                <p className="font-semibold">Đại diện NCC</p>
              </div>
              <div>
                <p className="font-bold">Thủ kho</p>
                <p className="text-[10px] text-slate-400 italic">(Ký, họ tên)</p>
                <div className="h-16" />
                <p className="font-semibold">Nguyễn Văn Định</p>
              </div>
              <div>
                <p className="font-bold">Kế toán trưởng</p>
                <p className="text-[10px] text-slate-400 italic">(Ký, họ tên)</p>
                <div className="h-16" />
                <p className="font-semibold">Trần Văn Duyệt</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Nhập nhanh từ Excel */}
      {excelModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-md w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Upload className="w-5 h-5 text-emerald-600" />
              Nhập nhanh phiếu từ file Excel
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Tải file mẫu Excel chuẩn để điền danh mục SKU, số lượng, đơn giá và số lô, sau đó kéo thả tệp vào ô dưới đây.
            </p>

            <div className="p-6 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl text-center space-y-2 mb-4">
              <FileSpreadsheet className="w-10 h-10 text-emerald-600 mx-auto" />
              <p className="text-xs font-bold text-slate-800 dark:text-slate-200">
                Kéo thả file .xlsx / .csv hoặc nhấp để chọn tệp
              </p>
              <p className="text-[11px] text-slate-400">Dung lượng tối đa 10MB</p>
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={() => showToast('Đang tải file mẫu', 'Tải file mẫu Mau_Nhap_Kho_Aplus.xlsx thành công.')}
                className="text-xs text-sky-600 hover:underline font-semibold"
              >
                Tải file mẫu .xlsx
              </button>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setExcelModalOpen(false)}
                  className="px-3 py-1.5 text-xs font-semibold rounded-lg text-slate-500 hover:bg-slate-100"
                >
                  Đóng
                </button>
                <button
                  type="button"
                  onClick={handleSimulateExcelImport}
                  className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs"
                >
                  Xác nhận tải lên
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
