import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import { DeliveryNote, DeliveryNoteStatus } from '../../types/logistics';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import { APlusLogo } from '../../components/common/APlusLogo';
import {
  FileText,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Printer,
  X,
  Truck,
  Building,
  User,
  MapPin,
  Phone,
  AlertTriangle,
  RotateCcw,
  Check,
  Calendar,
  Layers,
} from 'lucide-react';

export const LogisticsDeliveryNotesView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { deliveryNotes, updateDeliveryNoteStatus, drivers } = useLogistics();

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [driverFilter, setDriverFilter] = useState<string>('all');

  // Selected note for detail drawer or print
  const [selectedNote, setSelectedNote] = useState<DeliveryNote | null>(null);
  const [printNote, setPrintNote] = useState<DeliveryNote | null>(null);

  // Modals for delivery result
  const [isConfirmDeliveryModalOpen, setIsConfirmDeliveryModalOpen] = useState(false);
  const [receiverName, setReceiverName] = useState('');
  const [deliveryNoteType, setDeliveryNoteType] = useState<'full' | 'partial'>('full');
  const [partialReasons, setPartialReasons] = useState('');
  const [deliveredQuantities, setDeliveredQuantities] = useState<Record<string, number>>({});

  const [isFailDeliveryModalOpen, setIsFailDeliveryModalOpen] = useState(false);
  const [failReason, setFailReason] = useState('Khách vắng mặt, điện thoại không liên lạc được');
  const [rescheduleDate, setRescheduleDate] = useState(
    new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );

  const filteredNotes = deliveryNotes.filter((dn) => {
    if (statusFilter !== 'all' && dn.status !== statusFilter) return false;
    if (driverFilter !== 'all' && dn.driverName !== driverFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        dn.code.toLowerCase().includes(q) ||
        dn.customerName.toLowerCase().includes(q) ||
        dn.orderCode.toLowerCase().includes(q) ||
        dn.deliveryAddress.toLowerCase().includes(q) ||
        (dn.shipmentCode && dn.shipmentCode.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleOpenConfirmModal = (dn: DeliveryNote) => {
    setSelectedNote(dn);
    setReceiverName(dn.recipientName || dn.customerName);
    const initialQty: Record<string, number> = {};
    dn.items.forEach((it) => {
      initialQty[it.sku] = it.quantity;
    });
    setDeliveredQuantities(initialQty);
    setDeliveryNoteType('full');
    setIsConfirmDeliveryModalOpen(true);
  };

  const handleOpenFailModal = (dn: DeliveryNote) => {
    setSelectedNote(dn);
    setIsFailDeliveryModalOpen(true);
  };

  const handleSubmitConfirmDelivery = () => {
    if (!selectedNote || !receiverName.trim()) {
      showToast('Lỗi', 'Bắt buộc nhập họ tên người ký nhận.', 'warning');
      return;
    }

    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    if (deliveryNoteType === 'full') {
      updateDeliveryNoteStatus(selectedNote.id, 'Đã giao', {
        deliveredAt: now,
        receiverSignedName: receiverName.trim(),
      });
      setSelectedNote((prev) =>
        prev ? { ...prev, status: 'Đã giao', deliveredAt: now, receiverSignedName: receiverName.trim() } : null
      );
    } else {
      updateDeliveryNoteStatus(selectedNote.id, 'Giao một phần', {
        deliveredAt: now,
        receiverSignedName: receiverName.trim(),
        failedReason: partialReasons || 'Khách nhận một phần theo thỏa thuận',
      });
      setSelectedNote((prev) =>
        prev
          ? {
              ...prev,
              status: 'Giao một phần',
              deliveredAt: now,
              receiverSignedName: receiverName.trim(),
              failedReason: partialReasons,
            }
          : null
      );
    }

    setIsConfirmDeliveryModalOpen(false);
  };

  const handleSubmitFailDelivery = () => {
    if (!selectedNote) return;
    updateDeliveryNoteStatus(selectedNote.id, 'Giao thất bại', {
      failedReason: failReason,
      rescheduledDate: rescheduleDate,
    });
    setIsFailDeliveryModalOpen(false);
    setSelectedNote((prev) =>
      prev ? { ...prev, status: 'Giao thất bại', failedReason: failReason, rescheduledDate: rescheduleDate } : null
    );
  };

  const handleReschedule = (dn: DeliveryNote) => {
    updateDeliveryNoteStatus(dn.id, 'Chờ giao');
    setSelectedNote((prev) => (prev ? { ...prev, status: 'Chờ giao' } : null));
    showToast('Hẹn giao lại', `Phiếu giao ${dn.code} đã được đưa về trạng thái "Chờ giao" để xếp chuyến mới.`);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
              <FileText className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Phiếu Giao Hàng (Delivery Notes)
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Quản lý phiếu giao hàng xuất phát từ kho, in 2 liên kèm chữ ký, theo dõi tiến độ giao và thu tiền COD.
          </p>
        </div>

        <button
          onClick={() => setActiveModule('logistics-shipments')}
          className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
        >
          <Truck className="w-4 h-4" />
          <span>Gom chuyến giao hàng</span>
        </button>
      </div>

      {/* KPI Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Chờ giao &amp; Xếp chuyến</span>
          <p className="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-1">
            {deliveryNotes.filter((d) => d.status === 'Chờ giao' || d.status === 'Đã xếp chuyến').length}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Sẵn sàng để điều phối xe</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Đang trên đường giao</span>
          <p className="text-2xl font-bold text-sky-600 dark:text-sky-400 mt-1">
            {deliveryNotes.filter((d) => d.status === 'Đang giao').length}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Tài xế đang vận chuyển</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Giao thành công</span>
          <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {deliveryNotes.filter((d) => d.status === 'Đã giao' || d.status === 'Giao một phần').length}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Đã có chữ ký nhận hàng</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Giao thất bại / Hoàn về</span>
          <p className="text-2xl font-bold text-rose-600 dark:text-rose-400 mt-1">
            {deliveryNotes.filter((d) => d.status === 'Giao thất bại' || d.status === 'Đã hoàn về').length}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Cần hẹn giao lại hoặc nhập kho</p>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm số phiếu, khách hàng, đơn hàng..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          >
            <option value="all">Tất cả trạng thái</option>
            <option value="Chờ giao">Chờ giao</option>
            <option value="Đã xếp chuyến">Đã xếp chuyến</option>
            <option value="Đang giao">Đang giao</option>
            <option value="Đã giao">Đã giao</option>
            <option value="Giao một phần">Giao một phần</option>
            <option value="Giao thất bại">Giao thất bại</option>
            <option value="Đã hoàn về">Đã hoàn về</option>
          </select>

          <select
            value={driverFilter}
            onChange={(e) => setDriverFilter(e.target.value)}
            className="text-xs px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
          >
            <option value="all">Tất cả tài xế</option>
            {drivers.map((drv) => (
              <option key={drv.id} value={drv.fullName}>
                {drv.fullName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[11px]">
                <th className="py-3 px-4">Số phiếu &amp; Ngày</th>
                <th className="py-3 px-4">Khách hàng &amp; Địa chỉ</th>
                <th className="py-3 px-4">Đơn hàng gốc</th>
                <th className="py-3 px-4">Chuyến hàng / Tài xế</th>
                <th className="py-3 px-4 text-right">Tiền thu hộ COD</th>
                <th className="py-3 px-4 text-center">Trạng thái</th>
                <th className="py-3 px-4 text-center">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredNotes.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-10 text-center text-slate-400">
                    Không có phiếu giao hàng nào.
                  </td>
                </tr>
              ) : (
                filteredNotes.map((dn) => (
                  <tr key={dn.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      {dn.code}
                      <div className="text-[10px] text-slate-400 font-sans font-normal">{dn.date}</div>
                    </td>
                    <td className="py-3 px-4 max-w-[240px]">
                      <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                        {dn.customerName}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span>{dn.deliveryAddress}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-600 dark:text-slate-300">
                      {dn.orderCode}
                    </td>
                    <td className="py-3 px-4">
                      {dn.shipmentCode ? (
                        <div>
                          <span className="font-mono font-bold text-sky-600">{dn.shipmentCode}</span>
                          <div className="text-[10px] text-slate-500">{dn.driverName || 'Chưa gán tài xế'}</div>
                        </div>
                      ) : (
                        <span className="text-slate-400 italic">Chưa xếp chuyến</span>
                      )}
                    </td>
                    <td className="py-3 px-4 text-right font-bold text-slate-900 dark:text-white">
                      {dn.codAmount > 0 ? `${dn.codAmount.toLocaleString()} đ` : '-'}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span
                        className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-bold ${
                          dn.status === 'Đã giao'
                            ? 'bg-emerald-100 text-emerald-800'
                            : dn.status === 'Giao một phần'
                            ? 'bg-teal-100 text-teal-800'
                            : dn.status === 'Đang giao'
                            ? 'bg-sky-100 text-sky-800'
                            : dn.status === 'Đã xếp chuyến'
                            ? 'bg-indigo-100 text-indigo-800'
                            : dn.status === 'Chờ giao'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {dn.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => setSelectedNote(dn)}
                          className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200 font-semibold"
                        >
                          Chi tiết
                        </button>
                        <button
                          onClick={() => setPrintNote(dn)}
                          title="In phiếu giao hàng 2 liên"
                          className="p-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-600"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drawer Chi tiết Phiếu Giao Hàng */}
      {selectedNote && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end animate-fade-in">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col overflow-hidden border-l border-slate-200 dark:border-slate-800">
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-base font-bold text-indigo-600 dark:text-indigo-400">
                    {selectedNote.code}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200 dark:bg-slate-700">
                    {selectedNote.status}
                  </span>
                </div>
                <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-100 mt-0.5">
                  {selectedNote.customerName}
                </h3>
              </div>
              <button onClick={() => setSelectedNote(null)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="p-4 bg-slate-100/60 dark:bg-slate-950/40 border-b border-slate-200 dark:border-slate-800 shrink-0">
              <DocumentChainBar chain={selectedNote.chain} currentType="order" />
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Đơn hàng gốc:</span>
                  <span className="font-mono font-bold text-sky-600">{selectedNote.orderCode}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Phiếu xuất kho:</span>
                  <span className="font-mono font-bold text-purple-600">
                    {selectedNote.stockOutReceiptNumber}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400">Người nhận &amp; SĐT:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {selectedNote.recipientName} ({selectedNote.recipientPhone})
                  </span>
                </div>
                <div className="flex items-start justify-between">
                  <span className="text-slate-400">Địa chỉ giao:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200 text-right max-w-[260px]">
                    {selectedNote.deliveryAddress}
                  </span>
                </div>
                {selectedNote.codAmount > 0 && (
                  <div className="flex items-center justify-between pt-2 border-t border-slate-200 dark:border-slate-700">
                    <span className="text-slate-500 font-bold">Số tiền thu hộ (COD):</span>
                    <span className="font-bold text-emerald-600 text-sm">
                      {selectedNote.codAmount.toLocaleString()} đ
                    </span>
                  </div>
                )}
              </div>

              {/* Items List */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-2">
                  Danh sách hàng hóa giao
                </h4>
                <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 dark:bg-slate-800 text-[11px] text-slate-600 dark:text-slate-300">
                      <tr>
                        <th className="p-2.5">Sản phẩm</th>
                        <th className="p-2.5 text-center">Số lượng</th>
                        <th className="p-2.5 text-center">Lô hàng</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {selectedNote.items.map((item, i) => (
                        <tr key={i}>
                          <td className="p-2.5">
                            <div className="font-semibold">{item.productName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{item.sku}</div>
                          </td>
                          <td className="p-2.5 text-center font-bold">
                            {item.quantity} {item.unit}
                          </td>
                          <td className="p-2.5 text-center font-mono text-[11px] text-slate-500">
                            {item.lotNumber || 'FIFO'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Delivery Result Info */}
              {selectedNote.deliveredAt && (
                <div className="p-3.5 rounded-xl bg-emerald-50/60 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-300 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Đã giao hàng thành công</span>
                  </div>
                  <div>Thời gian: {selectedNote.deliveredAt}</div>
                  <div>Người ký nhận: <strong>{selectedNote.receiverSignedName}</strong></div>
                </div>
              )}

              {selectedNote.failedReason && (
                <div className="p-3.5 rounded-xl bg-rose-50/60 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-300 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600" />
                    <span>Lý do giao thất bại / ghi chú:</span>
                  </div>
                  <p>{selectedNote.failedReason}</p>
                  {selectedNote.rescheduledDate && (
                    <div className="text-slate-600 dark:text-slate-300">
                      Hẹn giao lại: {selectedNote.rescheduledDate}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Footer Action Buttons */}
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 flex items-center justify-between gap-2 shrink-0">
              <button
                onClick={() => setPrintNote(selectedNote)}
                className="px-3.5 py-2 rounded-lg border border-slate-300 text-slate-700 dark:text-slate-200 font-semibold text-xs flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>In Phiếu (2 liên)</span>
              </button>

              <div className="flex items-center gap-2">
                {selectedNote.status === 'Giao thất bại' ? (
                  <button
                    onClick={() => handleReschedule(selectedNote)}
                    className="px-3.5 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center gap-1.5"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>Hẹn Giao Lại</span>
                  </button>
                ) : selectedNote.status === 'Đang giao' || selectedNote.status === 'Đã xếp chuyến' ? (
                  <>
                    <button
                      onClick={() => handleOpenFailModal(selectedNote)}
                      className="px-3 py-2 rounded-lg border border-rose-300 text-rose-600 hover:bg-rose-50 text-xs font-semibold"
                    >
                      Báo thất bại
                    </button>
                    <button
                      onClick={() => handleOpenConfirmModal(selectedNote)}
                      className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Xác Nhận Đã Giao</span>
                    </button>
                  </>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Xác nhận Đã Giao Thành Công */}
      {isConfirmDeliveryModalOpen && selectedNote && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              <span>Xác Nhận Giao Hàng {selectedNote.code}</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Loại kết quả giao</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      checked={deliveryNoteType === 'full'}
                      onChange={() => setDeliveryNoteType('full')}
                    />
                    <span>Giao đủ 100%</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input
                      type="radio"
                      checked={deliveryNoteType === 'partial'}
                      onChange={() => setDeliveryNoteType('partial')}
                    />
                    <span>Giao một phần</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Họ tên người nhận ký trên phiếu
                </label>
                <input
                  type="text"
                  value={receiverName}
                  onChange={(e) => setReceiverName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              {deliveryNoteType === 'partial' && (
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">
                    Lý do giao một phần / Số lượng thực nhận
                  </label>
                  <textarea
                    rows={2}
                    value={partialReasons}
                    onChange={(e) => setPartialReasons(e.target.value)}
                    placeholder="Khách chỉ nhận trước các kiện nguyên vẹn..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setIsConfirmDeliveryModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 text-slate-600 text-xs font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={handleSubmitConfirmDelivery}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700"
              >
                Hoàn Tất Giao Hàng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Báo Giao Thất Bại */}
      {isFailDeliveryModalOpen && selectedNote && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="font-bold text-sm text-rose-600 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              <span>Ghi Nhận Giao Thất Bại</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Lý do thất bại</label>
                <select
                  value={failReason}
                  onChange={(e) => setFailReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="Khách vắng mặt, điện thoại không liên lạc được">
                    Khách vắng mặt, điện thoại không liên lạc được
                  </option>
                  <option value="Sai địa chỉ giao hàng">Sai địa chỉ giao hàng</option>
                  <option value="Khách từ chối nhận hàng do hàng sai quy cách">
                    Khách từ chối nhận hàng do hàng sai quy cách
                  </option>
                  <option value="Chưa chuẩn bị đủ tiền mặt thanh toán COD">
                    Chưa chuẩn bị đủ tiền mặt thanh toán COD
                  </option>
                  <option value="Khác">Lý do khác</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Ngày hẹn giao lại</label>
                <input
                  type="date"
                  value={rescheduleDate}
                  onChange={(e) => setRescheduleDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setIsFailDeliveryModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 text-slate-600 text-xs font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={handleSubmitFailDelivery}
                className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold text-xs hover:bg-rose-700"
              >
                Lưu Thất Bại &amp; Lên Lịch Lại
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Mẫu In Phiếu Giao Hàng 2 Liên A4/A5 */}
      {printNote && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-2xl max-w-3xl w-full p-8 shadow-2xl my-8 space-y-6">
            <div className="flex items-start justify-between border-b pb-4">
              <div className="flex items-center gap-3">
                <APlusLogo size={42} />
                <div>
                  <h2 className="text-base font-bold text-slate-900 uppercase">
                    CÔNG TY CỔ PHẦN CÔNG NGHỆ &amp; GIẢI PHÁP A+
                  </h2>
                  <p className="text-xs text-slate-500">
                    Tầng 8, Tòa nhà Innovation, Cầu Giấy, Hà Nội | Hotline: 1900 6868
                  </p>
                </div>
              </div>
              <div className="text-right">
                <h1 className="text-lg font-bold text-indigo-700">PHIẾU GIAO HÀNG</h1>
                <p className="text-xs font-mono font-bold text-slate-600">{printNote.code}</p>
                <p className="text-[11px] text-slate-400 italic">Liên 1: Lưu kho / Liên 2: Giao khách</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <p>Khách hàng: <strong>{printNote.customerName}</strong></p>
                <p>Người nhận: <strong>{printNote.recipientName}</strong></p>
                <p>Điện thoại: {printNote.recipientPhone}</p>
                <p>Địa chỉ giao: {printNote.deliveryAddress}</p>
              </div>
              <div>
                <p>Ngày lập phiếu: {printNote.date}</p>
                <p>Đơn hàng liên quan: <strong>{printNote.orderCode}</strong></p>
                <p>Phiếu xuất kho: {printNote.stockOutReceiptNumber}</p>
                <p>Tài xế phụ trách: {printNote.driverName || 'Đội xe nội bộ'}</p>
              </div>
            </div>

            <table className="w-full border border-slate-300 text-xs">
              <thead className="bg-slate-100 border-b border-slate-300">
                <tr>
                  <th className="p-2 border-r border-slate-300 text-center w-12">STT</th>
                  <th className="p-2 border-r border-slate-300">Tên hàng hóa / Quy cách</th>
                  <th className="p-2 border-r border-slate-300 text-center w-24">Mã SKU</th>
                  <th className="p-2 border-r border-slate-300 text-center w-16">ĐVT</th>
                  <th className="p-2 border-r border-slate-300 text-center w-20">Số lượng</th>
                  <th className="p-2 text-center w-28">Lô hàng</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {printNote.items.map((it, idx) => (
                  <tr key={idx}>
                    <td className="p-2 border-r border-slate-200 text-center">{idx + 1}</td>
                    <td className="p-2 border-r border-slate-200 font-semibold">{it.productName}</td>
                    <td className="p-2 border-r border-slate-200 text-center font-mono">{it.sku}</td>
                    <td className="p-2 border-r border-slate-200 text-center">{it.unit}</td>
                    <td className="p-2 border-r border-slate-200 text-center font-bold">{it.quantity}</td>
                    <td className="p-2 text-center font-mono">{it.lotNumber || 'FIFO'}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {printNote.codAmount > 0 && (
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs flex justify-between">
                <span>Số tiền thu hộ (COD):</span>
                <span className="font-bold text-slate-900 text-sm">
                  {printNote.codAmount.toLocaleString()} VNĐ
                </span>
              </div>
            )}

            <div className="grid grid-cols-3 gap-4 text-center text-xs pt-8">
              <div>
                <p className="font-bold">NGƯỜI LẬP PHIẾU</p>
                <p className="text-[11px] text-slate-400 italic mt-0.5">(Ký, họ tên)</p>
                <div className="h-16" />
                <p className="font-medium text-slate-600">Điều phối Logistics</p>
              </div>

              <div>
                <p className="font-bold">NGƯỜI GIAO HÀNG</p>
                <p className="text-[11px] text-slate-400 italic mt-0.5">(Ký, họ tên)</p>
                <div className="h-16" />
                <p className="font-medium text-slate-600">{printNote.driverName || 'Tài xế'}</p>
              </div>

              <div>
                <p className="font-bold">NGƯỜI NHẬN HÀNG</p>
                <p className="text-[11px] text-slate-400 italic mt-0.5">(Ký, ghi rõ họ tên)</p>
                <div className="h-16" />
                <p className="font-medium text-slate-600">{printNote.recipientName}</p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-4 border-t print:hidden">
              <button
                onClick={() => setPrintNote(null)}
                className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 text-xs font-semibold"
              >
                Đóng
              </button>
              <button
                onClick={handlePrint}
                className="px-5 py-2 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>In Ngay</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
