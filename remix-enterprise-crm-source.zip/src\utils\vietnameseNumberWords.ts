/**
 * Utility chuyển đổi số tiền thành chữ tiếng Việt chuẩn cho Hợp đồng, Báo giá, Hóa đơn và Phiếu thu
 */
const DIGITS = ['không', 'một', 'hai', 'ba', 'bốn', 'năm', 'sáu', 'bảy', 'tám', 'chín'];

function readGroupOfThree(numStr: string, readZeroHundred: boolean): string {
  const [c1, c2, c3] = numStr.split('').map(Number);
  let res = '';

  if (c1 === 0 && c2 === 0 && c3 === 0) return '';

  if (c1 > 0 || readZeroHundred) {
    res += `${DIGITS[c1]} trăm `;
  }

  if (c2 === 0 && c3 !== 0) {
    if (c1 > 0 || readZeroHundred) res += 'lẻ ';
    res += DIGITS[c3];
  } else if (c2 === 1) {
    res += 'mười ';
    if (c3 === 5) res += 'lăm';
    else if (c3 > 0) res += DIGITS[c3];
  } else if (c2 > 1) {
    res += `${DIGITS[c2]} mươi `;
    if (c3 === 1) res += 'mốt';
    else if (c3 === 5) res += 'lăm';
    else if (c3 > 0) res += DIGITS[c3];
  } else if (c3 > 0) {
    res += DIGITS[c3];
  }

  return res.trim();
}

export function numberToVietnameseWords(amount: number): string {
  if (isNaN(amount) || amount === 0) return 'Không đồng';
  
  const isNegative = amount < 0;
  const absAmount = Math.round(Math.abs(amount));
  const str = absAmount.toString();
  
  const scales = ['', 'nghìn', 'triệu', 'tỷ', 'nghìn tỷ', 'triệu tỷ'];
  const groups: string[] = [];
  
  let len = str.length;
  while (len > 0) {
    const start = Math.max(0, len - 3);
    groups.push(str.substring(start, len));
    len -= 3;
  }

  let result = '';
  for (let i = groups.length - 1; i >= 0; i--) {
    const groupStr = groups[i].padStart(3, '0');
    const readZeroHundred = i < groups.length - 1;
    const groupWords = readGroupOfThree(groupStr, readZeroHundred);
    
    if (groupWords) {
      result += `${groupWords} ${scales[i]} `;
    }
  }

  result = result.trim();
  if (!result) return 'Không đồng';

  // Viết hoa chữ cái đầu và thêm đuôi "đồng chẵn."
  result = result.charAt(0).toUpperCase() + result.slice(1) + ' đồng chẵn';
  if (isNegative) result = 'Âm ' + result.toLowerCase();

  return result.replace(/\s+/g, ' ');
}

export function formatVND(amount: number): string {
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
}
