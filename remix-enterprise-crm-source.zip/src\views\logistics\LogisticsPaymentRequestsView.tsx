import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import { PaymentRequest, PaymentRequestType } from '../../types/logistics';
import { APlusLogo } from '../../components/common/APlusLogo';
import { numberToVietnameseWords } from '../../utils/vietnameseNumberWords';
import {
  CreditCard,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  Printer,
  X,
  Building,
  DollarSign,
  AlertTriangle,
  User,
  Check,
  ShieldCheck,
} from 'lucide-react';

export const LogisticsPaymentRequestsView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    paymentRequests,
    createPaymentRequest,
    approvePaymentRequest,
    rejectPaymentRequest,
    markPaymentRequestPaid,
    purchaseInvoices,
  } = useLogistics();

  const [activeTab, setActiveTab] = useState<'all' | 'pending_approval'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRequest, setSelectedRequest] = useState<PaymentRequest | null>(null);
  const [printRequest, setPrintRequest] = useState<PaymentRequest | null>(null);

  // Modal Create Request
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formType, setFormType] = useState<PaymentRequestType>('Thanh toán nhà cung cấp');
  const [formRequester, setFormRequester] = useState('Trần Minh Đức');
  const [formDepartment, setFormDepartment] = useState('Logistics & Vận tải');
  const [formBeneficiaryName, setFormBeneficiaryName] = useState('');
  const [formBeneficiaryBank, setFormBeneficiaryBank] = useState('');
  const [formBeneficiaryAccount, setFormBeneficiaryAccount] = useState('');
  const [formSelectedInvoiceCodes, setFormSelectedInvoiceCodes] = useState<string[]>([]);
  const [formAmount, setFormAmount] = useState<number>(0);
  const [formDueDate, setFormDueDate] = useState(
    new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [formReason, setFormReason] = useState('');
  const [formMethod, setFormMethod] = useState<'Chuyển khoản' | 'Tiền mặt'>('Chuyển khoản');

  // Pending for current user/manager
  const pendingRequests = paymentRequests.filter(
    (p) => p.status === 'Chờ duyệt (Trưởng BP)' || p.status === 'Chờ duyệt (Giám đốc)'
  );

  const filteredRequests = (activeTab === 'pending_approval' ? pendingRequests : paymentRequests).filter((pr) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        pr.code.toLowerCase().includes(q) ||
        pr.beneficiaryName.toLowerCase().includes(q) ||
        pr.requesterName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleInvoiceSelect = (code: string, remainingAmt: number) => {
    if (formSelectedInvoiceCodes.includes(code)) {
      setFormSelectedInvoiceCodes((prev) => prev.filter((c) => c !== code));
      setFormAmount((prev) => Math.max(0, prev - remainingAmt));
    } else {
      setFormSelectedInvoiceCodes((prev) => [...prev, code]);
      setFormAmount((prev) => prev + remainingAmt);
    }
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formAmount <= 0) {
      showToast('Lỗi', 'Số tiền đề nghị thanh toán phải lớn hơn 0.', 'warning');
      return;
    }

    createPaymentRequest({
      requestDate: new Date().toISOString().split('T')[0],
      requesterName: formRequester,
      department: formDepartment,
      type: formType,
      beneficiaryName: formBeneficiaryName || 'Đối tác thanh toán',
      beneficiaryBank: formBeneficiaryBank,
      beneficiaryAccount: formBeneficiaryAccount,
      relatedDocumentIds: [],
      relatedDocumentCodes: formSelectedInvoiceCodes,
      totalAmount: formAmount,
      amountInWords: numberToVietnameseWords(formAmount),
      paymentMethod: formMethod,
      dueDate: formDueDate,
      reason: formReason,
    });

    setIsCreateModalOpen(false);
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
              <CreditCard className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Đề Nghị Thanh Toán (Payment Requests)
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Lập đề nghị chi tiền NCC, cước vận chuyển, chi phí phát sinh chuyến xe, luồng duyệt 2 cấp và Kế toán xác nhận đã chi.
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>Lập Đề Nghị Chi Tiền</span>
        </button>
      </div>

      {/* Tabs & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeTab === 'all'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Tất Cả Đề Nghị ({paymentRequests.length})
            </button>
            <button
              onClick={() => setActiveTab('pending_approval')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 ${
                activeTab === 'pending_approval'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <span>Chờ Tôi Duyệt</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/20">
                {pendingRequests.length}
              </span>
            </button>
          </div>
        </div>

        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo số phiếu (DNTT-2026-xxxx), người thụ hưởng..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border bg-slate-50 dark:bg-slate-800"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] text-slate-500 uppercase font-semibold">
            <tr>
              <th className="p-3">Mã phiếu &amp; Ngày lập</th>
              <th className="p-3">Loại thanh toán</th>
              <th className="p-3">Người đề nghị</th>
              <th className="p-3">Người nhận tiền</th>
              <th className="p-3 text-right">Số tiền đề nghị</th>
              <th className="p-3">Hạn thanh toán</th>
              <th className="p-3 text-center">Trạng thái</th>
              <th className="p-3 text-center">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredRequests.map((pr) => (
              <tr key={pr.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <td className="p-3 font-mono font-bold text-emerald-600">
                  {pr.code}
                  <div className="text-[10px] text-slate-400 font-sans font-normal">{pr.requestDate}</div>
                </td>
                <td className="p-3 font-semibold">{pr.type}</td>
                <td className="p-3">
                  <div className="font-semibold">{pr.requesterName}</div>
                  <div className="text-[10px] text-slate-400">{pr.department}</div>
                </td>
                <td className="p-3 font-medium">{pr.beneficiaryName}</td>
                <td className="p-3 text-right font-bold text-slate-900 dark:text-white">
                  {pr.totalAmount.toLocaleString()} đ
                </td>
                <td className="p-3 font-medium">{pr.dueDate}</td>
                <td className="p-3 text-center">
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      pr.status === 'Đã chi'
                        ? 'bg-emerald-100 text-emerald-800'
                        : pr.status === 'Đã duyệt'
                        ? 'bg-purple-100 text-purple-800'
                        : pr.status === 'Từ chối'
                        ? 'bg-rose-100 text-rose-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {pr.status}
                  </span>
                </td>
                <td className="p-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    <button
                      onClick={() => setSelectedRequest(pr)}
                      className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 font-semibold"
                    >
                      Chi tiết
                    </button>
                    <button
                      onClick={() => setPrintRequest(pr)}
                      className="p-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-600"
                    >
                      <Printer className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Drawer Chi tiết Phiếu */}
      {selectedRequest && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end animate-fade-in">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col border-l">
            <div className="p-4 sm:p-5 border-b flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
              <div>
                <span className="font-mono text-base font-bold text-emerald-600">{selectedRequest.code}</span>
                <span className="ml-2 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200">
                  {selectedRequest.status}
                </span>
                <p className="text-xs text-slate-500 mt-0.5">{selectedRequest.type}</p>
              </div>
              <button onClick={() => setSelectedRequest(null)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Người đề nghị:</span>
                  <span className="font-bold">{selectedRequest.requesterName} ({selectedRequest.department})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Đối tượng nhận tiền:</span>
                  <span className="font-bold text-slate-900 dark:text-white">{selectedRequest.beneficiaryName}</span>
                </div>
                {selectedRequest.beneficiaryBank && (
                  <div className="flex justify-between">
                    <span className="text-slate-400">Tài khoản ngân hàng:</span>
                    <span className="font-mono">{selectedRequest.beneficiaryBank}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-400">Hình thức &amp; Hạn chi:</span>
                  <span className="font-semibold">{selectedRequest.paymentMethod} - Hạn: {selectedRequest.dueDate}</span>
                </div>
                <div className="flex justify-between pt-2 border-t">
                  <span className="text-slate-500 font-bold">Số tiền đề nghị:</span>
                  <span className="font-bold text-emerald-600 text-sm">
                    {selectedRequest.totalAmount.toLocaleString()} VNĐ
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 italic">({selectedRequest.amountInWords})</div>
              </div>

              <div>
                <h4 className="font-bold text-slate-700 uppercase mb-1">Lý do &amp; Nội dung thanh toán</h4>
                <p className="p-3 bg-slate-50 dark:bg-slate-800/30 rounded-xl border">{selectedRequest.reason}</p>
              </div>

              {selectedRequest.relatedDocumentCodes && selectedRequest.relatedDocumentCodes.length > 0 && (
                <div>
                  <h4 className="font-bold text-slate-700 uppercase mb-1">Chứng từ hóa đơn liên quan</h4>
                  <div className="flex gap-2">
                    {selectedRequest.relatedDocumentCodes.map((c, i) => (
                      <span key={i} className="font-mono text-sky-600 font-bold bg-sky-50 px-2 py-1 rounded">
                        {c}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {selectedRequest.paidAt && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800">
                  <p className="font-bold flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>Kế toán đã chi tiền thành công</span>
                  </p>
                  <p className="mt-1">Thời gian: {selectedRequest.paidAt} - Kế toán: {selectedRequest.accountantName}</p>
                </div>
              )}
            </div>

            {/* Actions for Approval & Accounting */}
            <div className="p-4 border-t flex justify-between gap-2 bg-slate-50">
              <button
                onClick={() => setPrintRequest(selectedRequest)}
                className="px-3.5 py-2 rounded border text-slate-700 text-xs flex items-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>In Phiếu Chi</span>
              </button>

              <div className="flex items-center gap-2">
                {selectedRequest.status === 'Chờ duyệt (Trưởng BP)' && (
                  <button
                    onClick={() => {
                      approvePaymentRequest(selectedRequest.id, 'Trưởng Bộ phận Logistics', 'Trưởng BP');
                      setSelectedRequest((prev) => (prev ? { ...prev, status: 'Đã duyệt' } : null));
                    }}
                    className="px-4 py-2 rounded bg-emerald-600 text-white font-bold text-xs"
                  >
                    Trưởng BP Duyệt
                  </button>
                )}

                {selectedRequest.status === 'Chờ duyệt (Giám đốc)' && (
                  <button
                    onClick={() => {
                      approvePaymentRequest(selectedRequest.id, 'Giám đốc Điều hành', 'Giám đốc');
                      setSelectedRequest((prev) => (prev ? { ...prev, status: 'Đã duyệt' } : null));
                    }}
                    className="px-4 py-2 rounded bg-purple-600 text-white font-bold text-xs"
                  >
                    Giám Đốc Duyệt Chi
                  </button>
                )}

                {selectedRequest.status === 'Đã duyệt' && (
                  <button
                    onClick={() => {
                      markPaymentRequestPaid(selectedRequest.id, 'Nguyễn Thị Bích Ngọc (Kế toán)');
                      setSelectedRequest((prev) => (prev ? { ...prev, status: 'Đã chi' } : null));
                    }}
                    className="px-4 py-2 rounded bg-emerald-600 text-white font-bold text-xs flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Xác Nhận Đã Chi Tiền (Kế toán)</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Lập Đề Nghị Chi Tiền Mới */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full p-6 shadow-2xl border space-y-4 my-8">
            <h3 className="font-bold text-base text-slate-900 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-emerald-500" />
              <span>Lập Đề Nghị Thanh Toán Mới</span>
            </h3>

            <form onSubmit={handleCreateSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Loại đề nghị chi</label>
                  <select
                    value={formType}
                    onChange={(e: any) => setFormType(e.target.value)}
                    className="w-full px-3 py-2 rounded border"
                  >
                    <option value="Thanh toán nhà cung cấp">Thanh toán nhà cung cấp</option>
                    <option value="Cước vận chuyển">Cước vận chuyển (3PL)</option>
                    <option value="Chi phí phát sinh">Chi phí phát sinh (xăng, cầu đường...)</option>
                    <option value="Khác">Khác</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Hình thức chi</label>
                  <select
                    value={formMethod}
                    onChange={(e: any) => setFormMethod(e.target.value)}
                    className="w-full px-3 py-2 rounded border"
                  >
                    <option value="Chuyển khoản">Chuyển khoản</option>
                    <option value="Tiền mặt">Tiền mặt</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Đối tượng nhận tiền</label>
                <input
                  type="text"
                  value={formBeneficiaryName}
                  onChange={(e) => setFormBeneficiaryName(e.target.value)}
                  placeholder="Công ty TNHH Cisco / Tài xế Nguyễn Văn Mạnh..."
                  className="w-full px-3 py-2 rounded border"
                  required
                />
              </div>

              {formMethod === 'Chuyển khoản' && (
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Tài khoản &amp; Ngân hàng nhận</label>
                  <input
                    type="text"
                    value={formBeneficiaryBank}
                    onChange={(e) => setFormBeneficiaryBank(e.target.value)}
                    placeholder="Vietcombank CN Ba Đình - 0011002345678"
                    className="w-full px-3 py-2 rounded border"
                  />
                </div>
              )}

              {/* Nếu là thanh toán NCC: cho phép tick chọn hóa đơn */}
              {formType === 'Thanh toán nhà cung cấp' && (
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">
                    Chọn hóa đơn mua hàng cần thanh toán:
                  </label>
                  <div className="border rounded-xl max-h-32 overflow-y-auto divide-y">
                    {purchaseInvoices
                      .filter((pi) => pi.status !== 'Đã thanh toán' && pi.status !== 'Chênh lệch')
                      .map((pi) => (
                        <label
                          key={pi.id}
                          className="flex items-center justify-between p-2 hover:bg-slate-50 cursor-pointer"
                        >
                          <div className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              checked={formSelectedInvoiceCodes.includes(pi.code)}
                              onChange={() => handleInvoiceSelect(pi.code, pi.remainingAmount)}
                            />
                            <span className="font-mono font-bold">{pi.code}</span> - {pi.supplierName}
                          </div>
                          <span className="font-bold text-rose-600">
                            {pi.remainingAmount.toLocaleString()} đ
                          </span>
                        </label>
                      ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Số tiền đề nghị (VNĐ)</label>
                  <input
                    type="number"
                    value={formAmount}
                    onChange={(e) => setFormAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded border font-bold text-emerald-600"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Hạn thanh toán</label>
                  <input
                    type="date"
                    value={formDueDate}
                    onChange={(e) => setFormDueDate(e.target.value)}
                    className="w-full px-3 py-2 rounded border"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Lý do chi tiền</label>
                <textarea
                  rows={2}
                  value={formReason}
                  onChange={(e) => setFormReason(e.target.value)}
                  placeholder="Thanh toán tiền mua vật tư, cước xe..."
                  className="w-full px-3 py-2 rounded border"
                  required
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded border text-slate-600"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded bg-emerald-600 text-white font-bold"
                >
                  Gửi Đề Nghị Thanh Toán
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Mẫu In Đề Nghị Thanh Toán */}
      {printRequest && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-2xl max-w-2xl w-full p-8 shadow-2xl my-8 space-y-6">
            <div className="flex items-start justify-between border-b pb-4">
              <div className="flex items-center gap-3">
                <APlusLogo size={40} />
                <div>
                  <h2 className="text-sm font-bold uppercase">CÔNG TY CỔ PHẦN CÔNG NGHỆ &amp; GIẢI PHÁP A+</h2>
                  <p className="text-xs text-slate-500">Phòng Tài chính - Kế toán</p>
                </div>
              </div>
              <div className="text-right">
                <h1 className="text-base font-bold text-emerald-700 uppercase">GIẤY ĐỀ NGHỊ THANH TOÁN</h1>
                <p className="text-xs font-mono font-bold">{printRequest.code}</p>
                <p className="text-[11px] text-slate-400">Ngày: {printRequest.requestDate}</p>
              </div>
            </div>

            <div className="text-xs space-y-1.5">
              <p>Kính gửi: <strong>Ban Giám đốc &amp; Phòng Kế toán Công ty</strong></p>
              <p>Họ tên người đề nghị: <strong>{printRequest.requesterName}</strong></p>
              <p>Bộ phận / Đội: {printRequest.department}</p>
              <p>Nội dung thanh toán: {printRequest.reason}</p>
              <p>Đơn vị / Người nhận tiền: <strong>{printRequest.beneficiaryName}</strong></p>
              {printRequest.beneficiaryBank && <p>Tài khoản nhận: {printRequest.beneficiaryBank}</p>}
              <p>Hình thức: {printRequest.paymentMethod}</p>
              <p className="pt-2 text-sm">
                Số tiền đề nghị: <strong>{printRequest.totalAmount.toLocaleString()} VNĐ</strong>
              </p>
              <p className="italic text-slate-500">Bằng chữ: {printRequest.amountInWords}</p>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center text-xs pt-8">
              <div>
                <p className="font-bold">NGƯỜI ĐỀ NGHỊ</p>
                <div className="h-16" />
                <p className="font-semibold">{printRequest.requesterName}</p>
              </div>
              <div>
                <p className="font-bold">TRƯỞNG BỘ PHẬN</p>
                <div className="h-16" />
                <p className="font-semibold">Đã duyệt</p>
              </div>
              <div>
                <p className="font-bold">KẾ TOÁN THANH TOÁN</p>
                <div className="h-16" />
                <p className="font-semibold">{printRequest.accountantName || 'Chờ chi'}</p>
              </div>
              <div>
                <p className="font-bold">GIÁM ĐỐC DUYỆT</p>
                <div className="h-16" />
                <p className="font-semibold">Đã duyệt</p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t print:hidden">
              <button
                onClick={() => setPrintRequest(null)}
                className="px-4 py-2 rounded border text-slate-600 text-xs font-semibold"
              >
                Đóng
              </button>
              <button
                onClick={() => window.print()}
                className="px-5 py-2 rounded bg-emerald-600 text-white font-bold text-xs flex items-center gap-1"
              >
                <Printer className="w-4 h-4" />
                <span>In Ngay</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
