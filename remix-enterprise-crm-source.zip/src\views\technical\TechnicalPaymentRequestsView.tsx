import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import { useTechnical } from '../../context/TechnicalContext';
import { PaymentRequest, PaymentRequestType } from '../../types/logistics';
import { APlusLogo } from '../../components/common/APlusLogo';
import { numberToVietnameseWords } from '../../utils/vietnameseNumberWords';
import {
  CreditCard,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  Printer,
  X,
  Building,
  DollarSign,
  AlertTriangle,
  FolderKanban,
  Check,
  ShieldCheck,
  TrendingDown,
} from 'lucide-react';

export const TechnicalPaymentRequestsView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    paymentRequests,
    createPaymentRequest,
    approvePaymentRequest,
    rejectPaymentRequest,
  } = useLogistics();
  const { projects } = useTechnical();

  const [activeTab, setActiveTab] = useState<'all' | 'pending'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRequest, setSelectedRequest] = useState<PaymentRequest | null>(null);
  const [printRequest, setPrintRequest] = useState<PaymentRequest | null>(null);

  // Modal tạo đề nghị thanh toán chi phí kỹ thuật
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formRequester, setFormRequester] = useState('Trần Văn Nam');
  const [formDepartment, setFormDepartment] = useState('Phòng Kỹ thuật & Triển khai');
  const [formType, setFormType] = useState<PaymentRequestType>('Chi phí phát sinh');
  const [formProjectId, setFormProjectId] = useState(projects[0]?.id || '');
  const [formBeneficiaryName, setFormBeneficiaryName] = useState('Công ty TNHH Cơ điện & PCCC Thăng Long');
  const [formBeneficiaryBank, setFormBeneficiaryBank] = useState('Vietcombank - CN Hà Nội');
  const [formBeneficiaryAccount, setFormBeneficiaryAccount] = useState('0011004321999');
  const [formAmount, setFormAmount] = useState<number>(15000000);
  const [formDueDate, setFormDueDate] = useState(
    new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [formReason, setFormReason] = useState('Chi phí nhân công thầu phụ thi công máng cáp và ống luồn dây tầng 15');
  const [formMethod, setFormMethod] = useState<'Chuyển khoản' | 'Tiền mặt'>('Chuyển khoản');

  // Lọc các đề nghị chi phí thuộc Kỹ thuật
  const techPaymentRequests = paymentRequests.filter(
    (p) =>
      p.department?.toLowerCase().includes('kỹ thuật') ||
      p.type === 'Chi phí phát sinh' ||
      p.reason?.toLowerCase().includes('công trình') ||
      p.reason?.toLowerCase().includes('thi công')
  );

  const pendingRequests = techPaymentRequests.filter(
    (p) => p.status === 'Chờ duyệt (Trưởng BP)' || p.status === 'Chờ duyệt (Giám đốc)'
  );

  const filteredList = (activeTab === 'pending' ? pendingRequests : techPaymentRequests).filter((pr) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        pr.code.toLowerCase().includes(q) ||
        pr.beneficiaryName.toLowerCase().includes(q) ||
        pr.reason.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const proj = projects.find((p) => p.id === formProjectId);

    createPaymentRequest({
      requesterName: formRequester,
      department: formDepartment,
      type: formType,
      requestDate: new Date().toISOString().split('T')[0],
      beneficiaryName: formBeneficiaryName,
      beneficiaryBank: formBeneficiaryBank,
      beneficiaryAccount: formBeneficiaryAccount,
      relatedDocumentIds: proj ? [proj.id] : [],
      relatedDocumentCodes: proj ? [proj.code] : [],
      totalAmount: formAmount,
      amountInWords: numberToVietnameseWords(formAmount),
      paymentMethod: formMethod,
      dueDate: formDueDate,
      reason: proj ? `[Dự án ${proj.code}] ${formReason}` : formReason,
    });

    setIsCreateModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50">
              <CreditCard className="w-5 h-5" />
            </span>
            Đề Nghị Thanh Toán Kỹ Thuật (Payment Requests)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Lập và phê duyệt đề nghị chi trả thầu phụ, nhân công ngoài, thuê xe nâng/thiết bị thi công, đối soát ngân sách từng dự án
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001c42] shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Tạo đề nghị thanh toán</span>
        </button>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('all')}
            className={`py-2.5 px-4 font-bold border-b-2 transition-colors ${
              activeTab === 'all'
                ? 'border-sky-600 text-sky-600 dark:text-sky-400 bg-sky-50/50 dark:bg-sky-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Tất cả đề nghị ({techPaymentRequests.length})
          </button>
          <button
            onClick={() => setActiveTab('pending')}
            className={`py-2.5 px-4 font-bold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'pending'
                ? 'border-sky-600 text-sky-600 dark:text-sky-400 bg-sky-50/50 dark:bg-sky-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span>Chờ phê duyệt</span>
            {pendingRequests.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500 text-white">
                {pendingRequests.length}
              </span>
            )}
          </button>
        </div>

        <div className="relative max-w-xs w-full pb-1">
          <input
            type="text"
            placeholder="Tìm mã DNTT, người thụ hưởng, lý do..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden text-xs">
        <table className="w-full text-left">
          <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300">
            <tr>
              <th className="p-3">Số DNTT &amp; Ngày</th>
              <th className="p-3">Người Đề Nghị</th>
              <th className="p-3">Dự Án / Căn Cứ</th>
              <th className="p-3">Người Thụ Hưởng &amp; Tài Khoản</th>
              <th className="p-3 text-right">Số Tiền (đ)</th>
              <th className="p-3 text-center">Hạn Chi</th>
              <th className="p-3 text-center">Trạng Thái</th>
              <th className="p-3 text-center w-24">Thao Tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={8} className="p-8 text-center text-slate-400 italic">
                  Không tìm thấy đề nghị thanh toán nào phù hợp.
                </td>
              </tr>
            ) : (
              filteredList.map((pr) => (
                <tr key={pr.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="p-3">
                    <span className="font-mono font-bold text-sky-600 block">{pr.code}</span>
                    <span className="text-[11px] text-slate-400 font-mono">{pr.requestDate}</span>
                  </td>
                  <td className="p-3">
                    <div className="font-semibold text-slate-900 dark:text-white">{pr.requesterName}</div>
                    <span className="text-[10px] text-slate-400">{pr.department}</span>
                  </td>
                  <td className="p-3 max-w-xs">
                    {pr.relatedDocumentCodes && pr.relatedDocumentCodes.length > 0 && (
                      <span className="px-1.5 py-0.5 rounded bg-sky-50 dark:bg-sky-950 font-mono font-bold text-sky-600 text-[10px] mr-1">
                        {pr.relatedDocumentCodes.join(', ')}
                      </span>
                    )}
                    <p className="line-clamp-2 text-slate-600 dark:text-slate-400 text-[11px] mt-0.5">
                      {pr.reason}
                    </p>
                  </td>
                  <td className="p-3">
                    <div className="font-semibold text-slate-900 dark:text-white">{pr.beneficiaryName}</div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {pr.beneficiaryAccount} - {pr.beneficiaryBank}
                    </div>
                  </td>
                  <td className="p-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                    {pr.totalAmount.toLocaleString()} đ
                  </td>
                  <td className="p-3 text-center font-mono">{pr.dueDate}</td>
                  <td className="p-3 text-center">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        pr.status === 'Đã chi'
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : pr.status === 'Từ chối'
                          ? 'bg-rose-100 text-rose-700'
                          : 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                      }`}
                    >
                      {pr.status}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => setPrintRequest(pr)}
                        className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                        title="In phiếu DNTT"
                      >
                        <Printer className="w-4 h-4" />
                      </button>

                      {pr.status.startsWith('Chờ duyệt') && (
                        <button
                          onClick={() => approvePaymentRequest(pr.id, 'Trần Văn Nam (Trưởng BP Kỹ thuật)', 'Trưởng BP')}
                          className="px-2 py-0.5 rounded bg-emerald-600 text-white text-[10px] font-bold hover:bg-emerald-700"
                        >
                          Duyệt
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal: Tạo Đề Nghị Thanh Toán Mới */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-8 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Lập Đề Nghị Thanh Toán Chi Phí Kỹ Thuật
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Người đề nghị</label>
                  <input
                    type="text"
                    value={formRequester}
                    onChange={(e) => setFormRequester(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Dự án công trình gắn kết</label>
                  <select
                    value={formProjectId}
                    onChange={(e) => setFormProjectId(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                  >
                    <option value="">-- Không gắn dự án --</option>
                    {projects.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.code} - {p.title} (Ngân sách: {p.budget.toLocaleString()} đ)
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Đơn vị / Người thụ hưởng *</label>
                <input
                  type="text"
                  required
                  placeholder="Công ty đối tác hoặc thợ thi công..."
                  value={formBeneficiaryName}
                  onChange={(e) => setFormBeneficiaryName(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Ngân hàng</label>
                  <input
                    type="text"
                    value={formBeneficiaryBank}
                    onChange={(e) => setFormBeneficiaryBank(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Số tài khoản</label>
                  <input
                    type="text"
                    value={formBeneficiaryAccount}
                    onChange={(e) => setFormBeneficiaryAccount(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Số tiền thanh toán (đ) *</label>
                  <input
                    type="number"
                    required
                    value={formAmount}
                    onChange={(e) => setFormAmount(Number(e.target.value))}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold text-sky-600 text-sm"
                  />
                  <span className="text-[10px] text-slate-400 block mt-1">
                    Bằng chữ: <em>{numberToVietnameseWords(formAmount)}</em>
                  </span>
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Hạn thanh toán</label>
                  <input
                    type="date"
                    value={formDueDate}
                    onChange={(e) => setFormDueDate(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Lý do &amp; Căn cứ chi tiết *</label>
                <textarea
                  rows={2}
                  required
                  placeholder="Ghi rõ hạng mục thi công, biên bản đối soát..."
                  value={formReason}
                  onChange={(e) => setFormReason(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#002659] text-white font-semibold shadow-xs"
                >
                  Gửi duyệt đề nghị chi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal In Đề Nghị Thanh Toán */}
      {printRequest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-xl max-w-2xl w-full p-8 shadow-2xl my-8 text-xs font-serif leading-relaxed">
            <div className="flex justify-between items-start pb-4 border-b border-slate-300 mb-6">
              <APlusLogo />
              <div className="text-right">
                <h4 className="font-bold text-sm">CÔNG TY CỔ PHẦN CÔNG NGHỆ A+</h4>
                <p className="text-[11px] text-slate-500">Mã phiếu: {printRequest.code}</p>
                <p className="text-[11px] text-slate-500">Ngày lập: {printRequest.requestDate}</p>
              </div>
            </div>

            <div className="text-center my-6">
              <h2 className="text-lg font-bold uppercase tracking-wider">GIẤY ĐỀ NGHỊ THANH TOÁN</h2>
              <p className="text-[11px] italic">Căn cứ theo tiến độ công trình và dự án kỹ thuật</p>
            </div>

            <div className="space-y-2 mb-6">
              <p>- Kính gửi: Ban Giám Đốc &amp; Phòng Kế Toán</p>
              <p>- Họ và tên người đề nghị: <strong>{printRequest.requesterName}</strong> ({printRequest.department})</p>
              <p>- Lý do thanh toán: <strong>{printRequest.reason}</strong></p>
              <p>- Đơn vị thụ hưởng: <strong>{printRequest.beneficiaryName}</strong></p>
              <p>- Số tài khoản: <strong>{printRequest.beneficiaryAccount}</strong> tại {printRequest.beneficiaryBank}</p>
              <p>- Số tiền đề nghị: <strong className="text-sm font-mono">{printRequest.totalAmount.toLocaleString()} VNĐ</strong></p>
              <p>- Viết bằng chữ: <em className="font-semibold">{numberToVietnameseWords(printRequest.totalAmount)}</em></p>
            </div>

            <div className="grid grid-cols-4 gap-2 text-center pt-8 border-t border-slate-300">
              <div>
                <p className="font-bold">Người đề nghị</p>
                <div className="h-16" />
                <p className="font-semibold">{printRequest.requesterName}</p>
              </div>
              <div>
                <p className="font-bold">Trưởng BP Kỹ thuật</p>
                <div className="h-16" />
                <p className="font-semibold">Trần Văn Nam</p>
              </div>
              <div>
                <p className="font-bold">Kế toán thanh toán</p>
                <div className="h-16" />
                <p className="font-semibold">Đặng Thu Thảo</p>
              </div>
              <div>
                <p className="font-bold">Giám đốc duyệt</p>
                <div className="h-16" />
                <p className="font-semibold">Trần Minh Đức</p>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-200 flex justify-end gap-2 no-print">
              <button
                onClick={() => setPrintRequest(null)}
                className="px-4 py-2 border border-slate-300 rounded font-sans font-bold"
              >
                Đóng
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-sky-600 text-white rounded font-sans font-bold"
              >
                In Phiếu (PDF)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
