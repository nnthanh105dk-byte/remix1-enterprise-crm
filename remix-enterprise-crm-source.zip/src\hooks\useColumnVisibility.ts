import { useState, useEffect, useCallback, useMemo } from 'react';

export interface ColumnDef {
  id: string;
  label: string;
  defaultVisible?: boolean;
  required?: boolean; // Cannot be hidden
}

export function useColumnVisibility(
  storageKey: string,
  columns: ColumnDef[]
) {
  // Initialize from localStorage or defaultVisible
  const initialVisibility = useMemo(() => {
    try {
      const saved = localStorage.getItem(`crm_cols_${storageKey}`);
      if (saved) {
        const parsed = JSON.parse(saved);
        // Ensure all columns exist in the state
        const merged: Record<string, boolean> = {};
        columns.forEach((col) => {
          if (col.required) {
            merged[col.id] = true;
          } else if (parsed[col.id] !== undefined) {
            merged[col.id] = Boolean(parsed[col.id]);
          } else {
            merged[col.id] = col.defaultVisible !== false;
          }
        });
        return merged;
      }
    } catch {
      // Fallback
    }

    const defaults: Record<string, boolean> = {};
    columns.forEach((col) => {
      defaults[col.id] = col.defaultVisible !== false;
    });
    return defaults;
  }, [storageKey, columns]);

  const [visibleColumns, setVisibleColumns] = useState<Record<string, boolean>>(initialVisibility);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`crm_cols_${storageKey}`, JSON.stringify(visibleColumns));
    } catch {
      // ignore
    }
  }, [storageKey, visibleColumns]);

  const isVisible = useCallback(
    (columnId: string): boolean => {
      return visibleColumns[columnId] !== false;
    },
    [visibleColumns]
  );

  const toggleColumn = useCallback((columnId: string) => {
    setVisibleColumns((prev) => {
      const col = columns.find((c) => c.id === columnId);
      if (col?.required) return prev; // Cannot toggle required columns
      return {
        ...prev,
        [columnId]: !prev[columnId],
      };
    });
  }, [columns]);

  const setColumnVisible = useCallback((columnId: string, visible: boolean) => {
    setVisibleColumns((prev) => {
      const col = columns.find((c) => c.id === columnId);
      if (col?.required) return prev;
      return {
        ...prev,
        [columnId]: visible,
      };
    });
  }, [columns]);

  const selectAll = useCallback(() => {
    const all: Record<string, boolean> = {};
    columns.forEach((col) => {
      all[col.id] = true;
    });
    setVisibleColumns(all);
  }, [columns]);

  const resetToDefault = useCallback(() => {
    const defaults: Record<string, boolean> = {};
    columns.forEach((col) => {
      defaults[col.id] = col.defaultVisible !== false;
    });
    setVisibleColumns(defaults);
    try {
      localStorage.removeItem(`crm_cols_${storageKey}`);
    } catch {
      // ignore
    }
  }, [columns, storageKey]);

  return {
    columns,
    visibleColumns,
    isVisible,
    toggleColumn,
    setColumnVisible,
    selectAll,
    resetToDefault,
  };
}
