import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { LeadsView } from './LeadsView';
import { OpportunitiesView } from './OpportunitiesView';
import { QuotationsView } from './QuotationsView';
import { ContractsView } from './ContractsView';
import { Target, Briefcase, FileSpreadsheet, FileCheck2, BarChart2 } from 'lucide-react';

export const SalesHubView: React.FC = () => {
  const [salesSubTab, setSalesSubTab] = useState<'leads' | 'opportunities' | 'quotations' | 'contracts'>('leads');
  const { leads, opportunities, quotations, contracts } = useCRM();

  const openDealsCount = opportunities.filter((o) => o.stage !== 'Thành công (Won)' && o.stage !== 'Thất bại (Lost)').length;
  const newLeadsCount = leads.filter((l) => l.status === 'Mới' || l.status === 'Đang liên hệ').length;

  return (
    <div className="space-y-4">
      {/* Sales Hub Navigation Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-2 sm:p-2.5 shadow-xs flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center font-bold">
            <BarChart2 className="w-4 h-4" />
          </div>
          <div>
            <h1 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white leading-tight">
              Phân hệ Quản lý Sales
            </h1>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block">
              Quản trị toàn bộ chu trình bán hàng từ Tiềm năng, Phễu cơ hội tới Báo giá & Hợp đồng
            </p>
          </div>
        </div>

        {/* Submodule Tabs */}
        <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          <button
            onClick={() => setSalesSubTab('leads')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              salesSubTab === 'leads'
                ? 'bg-[#002659] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            <span>Tiềm năng (Leads)</span>
            {newLeadsCount > 0 && (
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${
                salesSubTab === 'leads' ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300'
              }`}>
                {newLeadsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setSalesSubTab('opportunities')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              salesSubTab === 'opportunities'
                ? 'bg-[#002659] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5" />
            <span>Cơ hội ({openDealsCount})</span>
          </button>

          <button
            onClick={() => setSalesSubTab('quotations')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              salesSubTab === 'quotations'
                ? 'bg-[#002659] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Báo giá ({quotations.length})</span>
          </button>

          <button
            onClick={() => setSalesSubTab('contracts')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors shrink-0 ${
              salesSubTab === 'contracts'
                ? 'bg-[#002659] text-white shadow-xs'
                : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>Hợp đồng ({contracts.length})</span>
          </button>
        </div>
      </div>

      {/* Render Selected Sales View */}
      <div>
        {salesSubTab === 'leads' && <LeadsView />}
        {salesSubTab === 'opportunities' && <OpportunitiesView />}
        {salesSubTab === 'quotations' && <QuotationsView />}
        {salesSubTab === 'contracts' && <ContractsView />}
      </div>
    </div>
  );
};
