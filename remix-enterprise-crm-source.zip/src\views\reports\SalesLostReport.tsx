import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { ReportFilterState } from '../../types/crm';
import { ReportFilterBar } from '../../components/reports/ReportFilterBar';
import { ExecutiveStatCard } from '../../components/reports/ReportCharts';
import { MOCK_LOST_DEALS, MockLostDeal } from '../../data/mockReportsData';
import {
  XCircle,
  RotateCcw,
  Search,
  DollarSign,
  AlertOctagon,
  ShieldAlert,
  BarChart2,
  PieChart,
} from 'lucide-react';

interface SalesLostReportProps {
  filter: ReportFilterState;
  onChangeFilter: (updated: Partial<ReportFilterState>) => void;
}

export const SalesLostReport: React.FC<SalesLostReportProps> = ({
  filter,
  onChangeFilter,
}) => {
  const { showToast, themeDef } = useCRM();
  const [dealsList, setDealsList] = useState<MockLostDeal[]>(MOCK_LOST_DEALS);
  const [searchTerm, setSearchTerm] = useState('');

  // Filter deals
  const filteredDeals = dealsList.filter((d) => {
    if (filter.teamId !== 'all' && d.teamId !== filter.teamId) return false;
    if (filter.salesRepId !== 'all' && d.repId !== filter.salesRepId) return false;
    if (filter.region !== 'all' && d.region !== filter.region) return false;
    if (filter.source !== 'all' && d.source !== filter.source) return false;
    if (filter.productId !== 'all' && d.productName !== filter.productId) return false;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const match =
        d.title.toLowerCase().includes(q) ||
        d.code.toLowerCase().includes(q) ||
        d.customerCompany.toLowerCase().includes(q) ||
        d.lossReason.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const totalLostCount = filteredDeals.length;
  const totalLostValue = filteredDeals.reduce((sum, d) => sum + d.value, 0);

  // Top Loss Reasons aggregation
  const reasonsCount: Record<string, { count: number; value: number }> = {};
  filteredDeals.forEach((d) => {
    if (!reasonsCount[d.lossReason]) {
      reasonsCount[d.lossReason] = { count: 0, value: 0 };
    }
    reasonsCount[d.lossReason].count += 1;
    reasonsCount[d.lossReason].value += d.value;
  });

  const reasonsList = Object.entries(reasonsCount).map(([reason, stats]) => ({
    reason,
    count: stats.count,
    value: stats.value,
    pct: Math.round((stats.count / Math.max(1, totalLostCount)) * 100),
  }));

  // Stages where deals are most frequently lost
  const stageLossCount: Record<string, number> = {
    'Khám phá nhu cầu': 0,
    'Báo giá & Đề xuất': 0,
    'Đàm phán': 0,
  };
  filteredDeals.forEach((d) => {
    if (stageLossCount[d.lostStage] !== undefined) {
      stageLossCount[d.lostStage] += 1;
    }
  });

  // Re-open deal handler
  const handleReopenDeal = (deal: MockLostDeal) => {
    setDealsList((prev) => prev.filter((d) => d.id !== deal.id));
    showToast(
      'Mở lại Deal thành công',
      `Đã chuyển "${deal.title}" về phễu cơ hội để chuyên viên ${deal.repName} tiếp cận chăm sóc lại.`,
      'success'
    );
  };

  return (
    <div className="space-y-6">
      {/* Shared Filter Bar */}
      <ReportFilterBar
        filter={filter}
        onChangeFilter={onChangeFilter}
        reportTitle="Báo cáo Deal Thua (Closed Lost)"
      />

      {/* Top 3 Stat Cards (Executive Style: Chỉ hiển thị Tiêu đề và Con số, bấm ! xem giải thích) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <ExecutiveStatCard
          title="Tổng số Deal thua"
          value={`${totalLostCount} deal`}
          valueColor="text-rose-600 dark:text-rose-400"
          icon={XCircle}
          iconColor="bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-800"
          explanation="Tổng số lượng cơ hội bị hủy hoặc thua đối thủ cạnh tranh trong kỳ, cần đánh giá rút kinh nghiệm."
        />

        <ExecutiveStatCard
          title="Tổng giá trị thất thoát"
          value={`${(totalLostValue / 1000000000).toFixed(2)} Tỷ`}
          icon={DollarSign}
          iconColor="bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-800"
          explanation="Tổng quy mô ngân sách tiềm năng chưa thể chuyển đổi thành doanh thu chính thức."
        />

        <ExecutiveStatCard
          title="Nguyên nhân chính"
          value="Đối thủ & Giá"
          icon={AlertOctagon}
          iconColor="bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800"
          explanation="Chiếm trên 62% tổng các ca thất bại do đối thủ phá giá và tính năng chuyên sâu chưa đáp ứng."
        />
      </div>

      {/* Two Analytics Charts: Top Loss Reasons & Stage Loss Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Loss Reasons Bars */}
        <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-3`}>
          <h3 className="section-title">
            <PieChart className="w-4.5 h-4.5 text-rose-500 mr-2 shrink-0" />
            Top Lý do thua thầu phổ biến
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Tỷ lệ phần trăm và giá trị mất theo từng nhóm lý do phản hồi từ khách hàng
          </p>

          <div className="space-y-3 pt-2">
            {reasonsList.map((item, idx) => (
              <div key={idx} className="space-y-1 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {item.reason} ({item.count} deal)
                  </span>
                  <span className="font-mono text-slate-500">
                    {(item.value / 1000000).toLocaleString('vi-VN')} Tr ({item.pct}%)
                  </span>
                </div>
                <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div
                    style={{ width: `${item.pct}%` }}
                    className="h-full bg-rose-500 rounded-full transition-all duration-300"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Stages where deals are most frequently lost */}
        <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-3`}>
          <h3 className="section-title">
            <BarChart2 className="w-4.5 h-4.5 text-amber-500 mr-2 shrink-0" />
            Giai đoạn bị thua nhiều nhất
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Xác định tầng phễu gặp trở ngại lớn nhất để đào tạo kỹ năng cho đội ngũ
          </p>

          <div className="grid grid-cols-3 gap-3 pt-4 text-center">
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
              <span className="text-[11px] text-slate-500 font-semibold block mb-1">
                Khám phá nhu cầu
              </span>
              <p className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
                {stageLossCount['Khám phá nhu cầu']}
              </p>
              <span className="text-[10px] text-slate-400">chưa đủ nhu cầu</span>
            </div>

            <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800">
              <span className="text-[11px] text-amber-800 dark:text-amber-300 font-semibold block mb-1">
                Báo giá &amp; Đề xuất
              </span>
              <p className="text-2xl font-bold font-mono text-amber-600 dark:text-amber-400">
                {stageLossCount['Báo giá & Đề xuất']}
              </p>
              <span className="text-[10px] text-amber-700 dark:text-amber-400">so sánh ngân sách</span>
            </div>

            <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800">
              <span className="text-[11px] text-rose-800 dark:text-rose-300 font-semibold block mb-1">
                Đàm phán chốt
              </span>
              <p className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400">
                {stageLossCount['Đàm phán']}
              </p>
              <span className="text-[10px] text-rose-700 dark:text-rose-400">vướng điều khoản / đối thủ</span>
            </div>
          </div>
        </div>
      </div>

      {/* Lost Deals Table with "Mở lại Deal" action */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-4`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="section-title">
              Danh sách chi tiết Deal thất bại
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Có thể kích hoạt nút "Mở lại deal" để đưa cơ hội trở lại chu trình chăm sóc
            </p>
          </div>

          <div className="relative max-w-xs w-full">
            <input
              type="text"
              placeholder="Tìm theo tên deal, khách hàng, lý do..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">Mã &amp; Tên deal</th>
                <th className="py-3 px-3">Khách hàng</th>
                <th className="py-3 px-3 text-right">Giá trị (VND)</th>
                <th className="py-3 px-3">Lý do thua</th>
                <th className="py-3 px-3">Đối thủ thắng thầu</th>
                <th className="py-3 px-3">Giai đoạn bị thua</th>
                <th className="py-3 px-3">Phụ trách</th>
                <th className="py-3 px-3 text-center">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredDeals.map((deal) => (
                <tr key={deal.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-3">
                    <p className="font-bold text-slate-900 dark:text-white">{deal.title}</p>
                    <span className="font-mono text-[10px] text-slate-500">{deal.code}</span>
                  </td>
                  <td className="py-3 px-3">
                    <p className="font-semibold text-slate-800 dark:text-slate-200">{deal.customerCompany}</p>
                    <p className="text-[11px] text-slate-500">{deal.customerName}</p>
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-slate-700 dark:text-slate-300">
                    {(deal.value / 1000000).toLocaleString('vi-VN')} Tr
                  </td>
                  <td className="py-3 px-3">
                    <span className="inline-block px-2 py-0.5 rounded-full text-[11px] font-semibold bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300">
                      {deal.lossReason}
                    </span>
                  </td>
                  <td className="py-3 px-3">
                    {deal.competitor ? (
                      <span className="font-bold text-amber-700 dark:text-amber-400">
                        {deal.competitor}
                      </span>
                    ) : (
                      <span className="text-slate-400 italic">Không rõ</span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                    {deal.lostStage}
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    {deal.repName}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <button
                      onClick={() => handleReopenDeal(deal)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-semibold bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 hover:bg-sky-100 transition-colors border border-sky-200 dark:border-sky-800 shadow-xs"
                      title="Tạo cơ hội chăm sóc lại"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Mở lại deal</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
