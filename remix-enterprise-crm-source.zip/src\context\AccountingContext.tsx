import React, { createContext, useContext, useState, useMemo } from 'react';
import { useCRM } from './CRMContext';
import { useSales } from './SalesContext';
import { useLogistics } from './LogisticsContext';
import { SalesInvoice } from '../types/sales';
import { PaymentRequest, PurchaseInvoice } from '../types/logistics';
import {
  CustomerDebtSummary,
  SupplierDebtSummary,
  DebtLedgerEntry,
  DebtAdjustmentRecord,
  DebtReminderLog,
  AccountingQuotationReview,
  CashTransaction,
  BankAccountBalance,
  CashForecastPeriod,
  ProfitAndLossStatement,
  RevenueProfitByDimension,
  PaymentChannel,
  CashCategoryType,
} from '../types/accounting';
import {
  INITIAL_CUSTOMER_DEBTS,
  INITIAL_SUPPLIER_DEBTS,
  INITIAL_LEDGER_ENTRIES,
  INITIAL_DEBT_REMINDERS,
  INITIAL_DEBT_ADJUSTMENTS,
  INITIAL_QUOTATION_REVIEWS,
  INITIAL_CASH_TRANSACTIONS,
  INITIAL_BANK_BALANCES,
  INITIAL_CASH_FORECAST,
  INITIAL_PL_STATEMENT,
  REVENUE_BY_PRODUCT_LINE,
  REVENUE_BY_SALES_STAFF,
} from '../data/mockAccountingData';

interface AccountingContextType {
  // State
  customerDebts: CustomerDebtSummary[];
  supplierDebts: SupplierDebtSummary[];
  ledgerEntries: Record<string, DebtLedgerEntry[]>;
  debtReminders: DebtReminderLog[];
  debtAdjustments: DebtAdjustmentRecord[];
  quotationReviews: AccountingQuotationReview[];
  cashTransactions: CashTransaction[];
  bankBalances: BankAccountBalance[];
  cashForecasts: CashForecastPeriod[];
  plStatement: ProfitAndLossStatement;
  revenueByProduct: RevenueProfitByDimension[];
  revenueBySalesStaff: RevenueProfitByDimension[];

  // Actions
  updateCreditLimit: (customerId: string, newLimit: number, creditTermDays: number, blockOnOverdue: boolean) => void;
  addDebtAdjustment: (adj: Omit<DebtAdjustmentRecord, 'id' | 'createdAt'>) => void;
  sendDebtReminder: (reminder: Omit<DebtReminderLog, 'id' | 'sentAt' | 'sentBy'>) => void;
  createReceiptFromAccounting: (data: {
    customerId: string;
    customerName: string;
    invoiceId?: string;
    invoiceNumber?: string;
    amount: number;
    channel: PaymentChannel;
    bankRefNumber?: string;
    payerName: string;
    reason: string;
  }) => void;
  createPaymentFromAccounting: (data: {
    supplierId: string;
    supplierName: string;
    invoiceCode?: string;
    paymentRequestId?: string;
    amount: number;
    category: CashCategoryType;
    channel: PaymentChannel;
    bankRefNumber?: string;
    reason: string;
  }) => void;
  reviewQuotationFinancial: (
    reviewId: string,
    status: 'Đạt tiêu chuẩn' | 'Cần duyệt ngoại lệ' | 'Đã duyệt' | 'Từ chối',
    notes?: string
  ) => void;
  addCashTransaction: (tx: Omit<CashTransaction, 'id' | 'createdAt'>) => void;
  cancelCashTransaction: (txId: string, reason: string) => void;
  reconcileBankBalance: (bankId: string, actualBalance: number) => void;
  updateEInvoiceDetails: (
    invoiceId: string,
    details: {
      einvoiceNumber: string;
      einvoiceSymbol: string;
      einvoiceIssuedDate: string;
      einvoiceFileUrl?: string;
    }
  ) => void;
}

const AccountingContext = createContext<AccountingContextType | undefined>(undefined);

export const AccountingProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { showToast, currentUser } = useCRM();
  const { invoices: salesInvoices, setInvoices: setSalesInvoices, createReceiptFromInvoice } = useSales();
  const { paymentRequests, setPaymentRequests, purchaseInvoices, setPurchaseInvoices } = useLogistics();

  const [customerDebts, setCustomerDebts] = useState<CustomerDebtSummary[]>(INITIAL_CUSTOMER_DEBTS);
  const [supplierDebts, setSupplierDebts] = useState<SupplierDebtSummary[]>(INITIAL_SUPPLIER_DEBTS);
  const [ledgerEntries, setLedgerEntries] = useState<Record<string, DebtLedgerEntry[]>>(INITIAL_LEDGER_ENTRIES);
  const [debtReminders, setDebtReminders] = useState<DebtReminderLog[]>(INITIAL_DEBT_REMINDERS);
  const [debtAdjustments, setDebtAdjustments] = useState<DebtAdjustmentRecord[]>(INITIAL_DEBT_ADJUSTMENTS);
  const [quotationReviews, setQuotationReviews] = useState<AccountingQuotationReview[]>(INITIAL_QUOTATION_REVIEWS);
  const [cashTransactions, setCashTransactions] = useState<CashTransaction[]>(INITIAL_CASH_TRANSACTIONS);
  const [bankBalances, setBankBalances] = useState<BankAccountBalance[]>(INITIAL_BANK_BALANCES);
  const [cashForecasts] = useState<CashForecastPeriod[]>(INITIAL_CASH_FORECAST);
  const [plStatement] = useState<ProfitAndLossStatement>(INITIAL_PL_STATEMENT);
  const [revenueByProduct] = useState<RevenueProfitByDimension[]>(REVENUE_BY_PRODUCT_LINE);
  const [revenueBySalesStaff] = useState<RevenueProfitByDimension[]>(REVENUE_BY_SALES_STAFF);

  // 1. Cập nhật hạn mức công nợ
  const updateCreditLimit = (
    customerId: string,
    newLimit: number,
    creditTermDays: number,
    blockOnOverdue: boolean
  ) => {
    setCustomerDebts((prev) =>
      prev.map((c) =>
        c.customerId === customerId
          ? { ...c, creditLimit: newLimit, creditTermDays, blockNewOrdersOnOverdue: blockOnOverdue }
          : c
      )
    );
    showToast('Cập nhật hạn mức thành công', 'Đã lưu cấu hình hạn mức tín dụng cho khách hàng');
  };

  // 2. Thêm chứng từ điều chỉnh công nợ
  const addDebtAdjustment = (adjData: Omit<DebtAdjustmentRecord, 'id' | 'createdAt'>) => {
    const newId = `adj-${Date.now()}`;
    const newAdj: DebtAdjustmentRecord = {
      ...adjData,
      id: newId,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setDebtAdjustments((prev) => [newAdj, ...prev]);

    // Cập nhật công nợ đối tác
    if (adjData.partnerType === 'customer') {
      setCustomerDebts((prev) =>
        prev.map((c) => {
          if (c.customerId === adjData.partnerId) {
            const newClosing =
              adjData.direction === 'increase'
                ? c.closingDebt + adjData.amount
                : Math.max(0, c.closingDebt - adjData.amount);
            return { ...c, closingDebt: newClosing };
          }
          return c;
        })
      );

      // Thêm vào ledger
      const entry: DebtLedgerEntry = {
        id: `led-adj-${Date.now()}`,
        date: adjData.date,
        docType:
          adjData.direction === 'increase'
            ? 'Chứng từ điều chỉnh tăng'
            : 'Chứng từ điều chỉnh giảm',
        docCode: adjData.code,
        description: `Điều chỉnh: ${adjData.reason}`,
        increaseAmount: adjData.direction === 'increase' ? adjData.amount : 0,
        decreaseAmount: adjData.direction === 'decrease' ? adjData.amount : 0,
        runningBalance: 0, // sẽ được tính lại khi xem sổ
      };
      setLedgerEntries((prev) => ({
        ...prev,
        [adjData.partnerId]: [...(prev[adjData.partnerId] || []), entry],
      }));
    } else {
      setSupplierDebts((prev) =>
        prev.map((s) => {
          if (s.supplierId === adjData.partnerId) {
            const newClosing =
              adjData.direction === 'increase'
                ? s.closingDebt + adjData.amount
                : Math.max(0, s.closingDebt - adjData.amount);
            return { ...s, closingDebt: newClosing };
          }
          return s;
        })
      );
    }

    showToast('Tạo chứng từ điều chỉnh thành công', `Đã ghi nhận chứng từ ${adjData.code}`);
  };

  // 3. Gửi nhắc nợ
  const sendDebtReminder = (reminderData: Omit<DebtReminderLog, 'id' | 'sentAt' | 'sentBy'>) => {
    const newReminder: DebtReminderLog = {
      ...reminderData,
      id: `rem-${Date.now()}`,
      sentAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      sentBy: currentUser?.fullName || 'Kế toán công nợ',
    };
    setDebtReminders((prev) => [newReminder, ...prev]);
    showToast(
      'Đã gửi nhắc nợ thành công',
      `Đã chuyển thông báo qua kênh ${reminderData.channel} tới ${reminderData.customerName}`
    );
  };

  // 4. Tạo Phiếu thu từ Kế toán (đồng bộ sang SalesReceipt và SalesInvoice)
  const createReceiptFromAccounting = ({
    customerId,
    customerName,
    invoiceId,
    invoiceNumber,
    amount,
    channel,
    bankRefNumber,
    payerName,
    reason,
  }: {
    customerId: string;
    customerName: string;
    invoiceId?: string;
    invoiceNumber?: string;
    amount: number;
    channel: PaymentChannel;
    bankRefNumber?: string;
    payerName: string;
    reason: string;
  }) => {
    const receiptNum = `PT-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const nowIso = new Date().toISOString().split('T')[0];

    // Thêm giao dịch sổ quỹ
    const newTx: CashTransaction = {
      id: `tx-${Date.now()}`,
      code: receiptNum,
      type: 'Thu',
      date: nowIso,
      category: 'Thu tiền hàng từ khách',
      partnerType: 'Khách hàng',
      partnerId: customerId,
      partnerName: customerName,
      amount,
      amountInWords: `${amount.toLocaleString('vi-VN')} đồng`,
      channel,
      bankRefNumber,
      reason,
      creatorName: currentUser?.fullName || 'Kế toán viên',
      approverName: 'Vũ Hoàng Yến (KTT)',
      cashierName: 'Lê Mai Anh (Thủ quỹ)',
      status: 'Đã thực hiện',
      referenceDocType: 'Hóa đơn bán hàng',
      referenceDocCode: invoiceNumber,
      createdAt: new Date().toISOString(),
    };
    setCashTransactions((prev) => [newTx, ...prev]);

    // Cập nhật số dư ngân hàng/quỹ
    setBankBalances((prev) =>
      prev.map((b) => {
        if (
          (channel.includes('Vietcombank') && b.accountNumber === '0011004321999') ||
          (channel.includes('Techcombank') && b.accountNumber === '19033321456011') ||
          (channel.includes('MB Bank') && b.accountNumber === '0888666999') ||
          (channel.includes('Tiền mặt') && b.accountNumber === 'QUY-TIEN-MAT')
        ) {
          return {
            ...b,
            currentBalance: b.currentBalance + amount,
            bookBalance: b.bookBalance + amount,
          };
        }
        return b;
      })
    );

    // Cập nhật công nợ khách hàng
    setCustomerDebts((prev) =>
      prev.map((c) => {
        if (c.customerId === customerId) {
          const newPaid = c.periodPaid + amount;
          const newClosing = Math.max(0, c.closingDebt - amount);
          const newOverdue = Math.max(0, c.overdueDebt - amount);
          return {
            ...c,
            periodPaid: newPaid,
            closingDebt: newClosing,
            overdueDebt: newOverdue,
            lastPaymentDate: nowIso,
            riskStatus: newClosing === 0 ? 'Bình thường' : c.riskStatus,
          };
        }
        return c;
      })
    );

    // Thêm vào sổ chi tiết (ledger)
    const entry: DebtLedgerEntry = {
      id: `led-${Date.now()}`,
      date: nowIso,
      docType: 'Phiếu thu',
      docCode: receiptNum,
      description: reason,
      increaseAmount: 0,
      decreaseAmount: amount,
      runningBalance: 0,
      referenceDocId: invoiceId,
    };
    setLedgerEntries((prev) => ({
      ...prev,
      [customerId]: [...(prev[customerId] || []), entry],
    }));

    // Cập nhật Sales Invoice và đồng bộ SalesReceipt nếu có
    if (invoiceId) {
      try {
        createReceiptFromInvoice(
          invoiceId,
          amount,
          channel.includes('Tiền mặt') ? 'Tiền mặt' : 'Chuyển khoản',
          bankRefNumber || '',
          reason,
          payerName
        );
      } catch {
        setSalesInvoices((prev: SalesInvoice[]) =>
          prev.map((inv: SalesInvoice) => {
            if (inv.id === invoiceId || inv.invoiceNumber === invoiceNumber) {
              const newPaid = inv.paidAmount + amount;
              const newRemaining = Math.max(0, inv.totalAmount - newPaid);
              const newStatus =
                newRemaining === 0 ? 'Đã thanh toán' : 'Thanh toán một phần';
              return {
                ...inv,
                paidAmount: newPaid,
                remainingAmount: newRemaining,
                status: newStatus,
              };
            }
            return inv;
          })
        );
      }
    }

    showToast('Tạo phiếu thu thành công', `Đã lập phiếu thu ${receiptNum} và trừ công nợ.`);
  };

  // 5. Tạo Phiếu chi từ Kế toán (cho NCC / Vận chuyển / Kỹ thuật)
  const createPaymentFromAccounting = ({
    supplierId,
    supplierName,
    invoiceCode,
    paymentRequestId,
    amount,
    category,
    channel,
    bankRefNumber,
    reason,
  }: {
    supplierId: string;
    supplierName: string;
    invoiceCode?: string;
    paymentRequestId?: string;
    amount: number;
    category: CashCategoryType;
    channel: PaymentChannel;
    bankRefNumber?: string;
    reason: string;
  }) => {
    const paymentNum = `PC-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const nowIso = new Date().toISOString().split('T')[0];

    const newTx: CashTransaction = {
      id: `tx-${Date.now()}`,
      code: paymentNum,
      type: 'Chi',
      date: nowIso,
      category,
      partnerType: 'Nhà cung cấp',
      partnerId: supplierId,
      partnerName: supplierName,
      amount,
      amountInWords: `${amount.toLocaleString('vi-VN')} đồng`,
      channel,
      bankRefNumber,
      reason,
      creatorName: currentUser?.fullName || 'Kế toán viên',
      approverName: 'Đặng Tuấn Anh (Giám đốc)',
      cashierName: 'Lê Mai Anh (Thủ quỹ)',
      status: 'Đã thực hiện',
      referenceDocType: paymentRequestId ? 'Đề nghị thanh toán' : 'Hóa đơn mua hàng',
      referenceDocCode: invoiceCode || paymentRequestId,
      createdAt: new Date().toISOString(),
    };
    setCashTransactions((prev) => [newTx, ...prev]);

    // Trừ số dư ngân hàng/quỹ
    setBankBalances((prev) =>
      prev.map((b) => {
        if (
          (channel.includes('Vietcombank') && b.accountNumber === '0011004321999') ||
          (channel.includes('Techcombank') && b.accountNumber === '19033321456011') ||
          (channel.includes('MB Bank') && b.accountNumber === '0888666999') ||
          (channel.includes('Tiền mặt') && b.accountNumber === 'QUY-TIEN-MAT')
        ) {
          return {
            ...b,
            currentBalance: b.currentBalance - amount,
            bookBalance: b.bookBalance - amount,
          };
        }
        return b;
      })
    );

    // Cập nhật công nợ nhà cung cấp
    setSupplierDebts((prev) =>
      prev.map((s) => {
        if (s.supplierId === supplierId) {
          const newPaid = s.periodPaid + amount;
          const newClosing = Math.max(0, s.closingDebt - amount);
          return {
            ...s,
            periodPaid: newPaid,
            closingDebt: newClosing,
            status: newClosing === 0 ? 'Đã duyệt chi' : s.status,
          };
        }
        return s;
      })
    );

    // Cập nhật Đề nghị thanh toán trong Logistics nếu có
    if (paymentRequestId) {
      setPaymentRequests((prev: PaymentRequest[]) =>
        prev.map((p: PaymentRequest) =>
          p.id === paymentRequestId || p.code === paymentRequestId
            ? { ...p, status: 'Đã chi', paidAt: nowIso, accountantName: currentUser?.fullName }
            : p
        )
      );
    }

    // Cập nhật Hóa đơn mua hàng nếu có
    if (invoiceCode) {
      setPurchaseInvoices((prev: PurchaseInvoice[]) =>
        prev.map((p: PurchaseInvoice) => {
          if (p.code === invoiceCode || p.id === invoiceCode) {
            const newPaid = p.paidAmount + amount;
            const newRemaining = Math.max(0, p.totalAmount - newPaid);
            return {
              ...p,
              paidAmount: newPaid,
              remainingAmount: newRemaining,
              status: newRemaining === 0 ? 'Đã thanh toán' : 'Thanh toán một phần',
            };
          }
          return p;
        })
      );
    }

    showToast('Tạo phiếu chi thành công', `Đã lập phiếu chi ${paymentNum} và cập nhật công nợ.`);
  };

  // 6. Thẩm duyệt báo giá tài chính
  const reviewQuotationFinancial = (
    reviewId: string,
    status: 'Đạt tiêu chuẩn' | 'Cần duyệt ngoại lệ' | 'Đã duyệt' | 'Từ chối',
    notes?: string
  ) => {
    setQuotationReviews((prev) =>
      prev.map((q) =>
        q.id === reviewId
          ? {
              ...q,
              financialStatus: status,
              reviewNotes: notes || q.reviewNotes,
              reviewedBy: currentUser?.fullName || 'Vũ Hoàng Yến (KTT)',
              reviewedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            }
          : q
      )
    );
    showToast('Phê duyệt báo giá thành công', `Trạng thái thẩm duyệt: ${status}`);
  };

  // 7. Thêm giao dịch sổ quỹ trực tiếp
  const addCashTransaction = (txData: Omit<CashTransaction, 'id' | 'createdAt'>) => {
    const newTx: CashTransaction = {
      ...txData,
      id: `tx-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setCashTransactions((prev) => [newTx, ...prev]);

    // Cập nhật số dư tài khoản
    setBankBalances((prev) =>
      prev.map((b) => {
        const matches =
          (txData.channel.includes('Vietcombank') && b.accountNumber === '0011004321999') ||
          (txData.channel.includes('Techcombank') && b.accountNumber === '19033321456011') ||
          (txData.channel.includes('MB Bank') && b.accountNumber === '0888666999') ||
          (txData.channel.includes('Tiền mặt') && b.accountNumber === 'QUY-TIEN-MAT');
        if (matches) {
          const delta = txData.type === 'Thu' ? txData.amount : -txData.amount;
          return {
            ...b,
            currentBalance: b.currentBalance + delta,
            bookBalance: b.bookBalance + delta,
          };
        }
        return b;
      })
    );

    showToast('Đã ghi nhận giao dịch', `Mã chứng từ ${txData.code}`);
  };

  // 8. Hủy giao dịch sổ quỹ
  const cancelCashTransaction = (txId: string, reason: string) => {
    setCashTransactions((prev) =>
      prev.map((tx) =>
        tx.id === txId
          ? { ...tx, status: 'Đã hủy', reason: `${tx.reason} (HỦY: ${reason})` }
          : tx
      )
    );
    showToast('Đã hủy giao dịch', 'Giao dịch đã được chuyển sang trạng thái Đã hủy');
  };

  // 9. Đối soát ngân hàng
  const reconcileBankBalance = (bankId: string, actualBalance: number) => {
    setBankBalances((prev) =>
      prev.map((b) =>
        b.id === bankId
          ? {
              ...b,
              currentBalance: actualBalance,
              unreconciledDifference: actualBalance - b.bookBalance,
              lastReconciledDate: new Date().toISOString().split('T')[0],
            }
          : b
      )
    );
    showToast('Đã đối soát số dư', 'Hệ thống đã cập nhật số dư thực tế và chênh lệch kiểm kê.');
  };

  // 10. Cập nhật thông tin Hóa đơn điện tử (HĐĐT)
  const updateEInvoiceDetails = (
    invoiceId: string,
    details: {
      einvoiceNumber: string;
      einvoiceSymbol: string;
      einvoiceIssuedDate: string;
      einvoiceFileUrl?: string;
    }
  ) => {
    setSalesInvoices((prev: SalesInvoice[]) =>
      prev.map((inv: SalesInvoice) =>
        inv.id === invoiceId
          ? {
              ...inv,
              einvoiceNumber: details.einvoiceNumber,
              einvoiceSymbol: details.einvoiceSymbol,
              einvoiceIssuedDate: details.einvoiceIssuedDate,
              einvoiceFileUrl: details.einvoiceFileUrl || 'https://misa.vn/einvoice/download-sample.pdf',
              status: inv.status === 'Nháp' ? 'Đã phát hành' : inv.status,
            }
          : inv
      )
    );
    showToast(
      'Cập nhật HĐĐT thành công',
      `Đã liên kết số hóa đơn điện tử ${details.einvoiceNumber} (${details.einvoiceSymbol})`
    );
  };

  const value = useMemo(
    () => ({
      customerDebts,
      supplierDebts,
      ledgerEntries,
      debtReminders,
      debtAdjustments,
      quotationReviews,
      cashTransactions,
      bankBalances,
      cashForecasts,
      plStatement,
      revenueByProduct,
      revenueBySalesStaff,
      updateCreditLimit,
      addDebtAdjustment,
      sendDebtReminder,
      createReceiptFromAccounting,
      createPaymentFromAccounting,
      reviewQuotationFinancial,
      addCashTransaction,
      cancelCashTransaction,
      reconcileBankBalance,
      updateEInvoiceDetails,
    }),
    [
      customerDebts,
      supplierDebts,
      ledgerEntries,
      debtReminders,
      debtAdjustments,
      quotationReviews,
      cashTransactions,
      bankBalances,
      cashForecasts,
      plStatement,
      revenueByProduct,
      revenueBySalesStaff,
    ]
  );

  return <AccountingContext.Provider value={value}>{children}</AccountingContext.Provider>;
};

export const useAccounting = () => {
  const context = useContext(AccountingContext);
  if (!context) {
    throw new Error('useAccounting must be used within an AccountingProvider');
  }
  return context;
};
