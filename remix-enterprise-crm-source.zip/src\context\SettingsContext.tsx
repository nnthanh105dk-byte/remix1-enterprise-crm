import React, { createContext, useContext, useState, useMemo } from 'react';
import { useCRM } from './CRMContext';
import {
  SystemUser,
  PermissionGroup,
  CompanyInfoConfig,
  PrintTemplateConfig,
  DocumentNumberingRule,
  SecurityPolicyConfig,
  WorkingTimeConfig,
  IntegrationConnectionConfig,
  AppParameterItem,
  DocumentApprovalRule,
  ApprovalDelegation,
  DictionaryCategory,
  DictionaryValueItem,
  SupplierDirectoryItem,
  WarehouseDirectoryItem,
  BankDirectoryItem,
  VatRateDirectoryItem,
  SyncRunRecord,
  DataImportExportLog,
  SystemAuditLogItem,
  DataScope,
  FieldVisibility,
  PermissionActionType,
} from '../types/settings';
import {
  INITIAL_PERMISSION_GROUPS,
  INITIAL_SYSTEM_USERS,
  INITIAL_COMPANY_CONFIG,
  INITIAL_NUMBERING_RULES,
  INITIAL_SECURITY_POLICY,
  INITIAL_WORKING_TIME,
  INITIAL_PRINT_TEMPLATES,
  INITIAL_INTEGRATION_CONFIG,
  INITIAL_APP_PARAMETERS,
  INITIAL_APPROVAL_RULES,
  INITIAL_APPROVAL_DELEGATIONS,
  INITIAL_DICTIONARY_CATEGORIES,
  INITIAL_SUPPLIERS,
  INITIAL_WAREHOUSES,
  INITIAL_BANKS,
  INITIAL_VAT_RATES,
  INITIAL_SYNC_RUNS,
  INITIAL_IMPORT_EXPORT_LOGS,
  INITIAL_SYSTEM_AUDIT_LOGS,
} from '../data/mockSettingsData';

interface SettingsContextType {
  // 1. Users
  users: SystemUser[];
  createUserFromEmployee: (emp: { id: string; fullName: string; email: string; phone: string; departmentName: string; positionName: string; avatar?: string }, roleIds: string[]) => SystemUser;
  bulkCreateUsersFromEmployees: (emps: { id: string; fullName: string; email: string; phone: string; departmentName: string; positionName: string; avatar?: string }[], defaultRoleIds: string[]) => number;
  updateUser: (id: string, updates: Partial<SystemUser>) => void;
  toggleUserLock: (id: string) => void;
  sendPasswordResetInvite: (id: string) => void;
  terminateAllSessions: (id: string) => void;

  // 2. Permission Groups
  permissionGroups: PermissionGroup[];
  createPermissionGroup: (data: Omit<PermissionGroup, 'id' | 'isSystem' | 'userCount' | 'createdAt' | 'updatedAt'>) => PermissionGroup;
  clonePermissionGroup: (sourceId: string, newName: string) => PermissionGroup;
  updatePermissionGroup: (id: string, updates: Partial<PermissionGroup>) => void;
  deletePermissionGroup: (id: string) => boolean;

  // Centralized RBAC
  canAccessSettings: boolean; // Chỉ System Admin hoặc Giám Đốc
  checkModulePermission: (moduleId: string, action: PermissionActionType) => boolean;
  getDataScopeForModule: (moduleId: string) => DataScope;
  getFieldVisibilityRule: (fieldKey: 'costAndMargin' | 'salaryAndAllowance' | 'employeeIdCardTaxBank' | 'socialInsurance' | 'supplierBankInfo') => FieldVisibility;

  // 3. System Config
  companyConfig: CompanyInfoConfig;
  updateCompanyConfig: (updates: Partial<CompanyInfoConfig>) => void;
  numberingRules: DocumentNumberingRule[];
  updateNumberingRule: (id: string, updates: Partial<DocumentNumberingRule>) => void;
  generateDocCode: (docType: string) => string;
  securityPolicy: SecurityPolicyConfig;
  updateSecurityPolicy: (updates: Partial<SecurityPolicyConfig>) => void;
  workingTime: WorkingTimeConfig;
  updateWorkingTime: (updates: Partial<WorkingTimeConfig>) => void;
  printTemplates: PrintTemplateConfig[];
  updatePrintTemplate: (docType: string, updates: Partial<PrintTemplateConfig>) => void;
  integrationConfig: IntegrationConnectionConfig;
  updateIntegrationConfig: (updates: Partial<IntegrationConnectionConfig>) => void;
  testSmtpConnection: () => Promise<boolean>;
  generateNewApiKey: (name: string, scopes: string[]) => void;
  revokeApiKey: (id: string) => void;

  // 4. App Parameters & Approval Rules
  appParameters: AppParameterItem[];
  updateAppParameter: (id: string, value: any) => void;
  resetAppParameterToDefault: (id: string) => void;
  getParamValue: (key: string, defaultVal?: any) => any;
  approvalRules: DocumentApprovalRule[];
  updateApprovalRule: (id: string, updates: Partial<DocumentApprovalRule>) => void;
  toggleApprovalRule: (id: string) => void;
  approvalDelegations: ApprovalDelegation[];
  addApprovalDelegation: (delegation: Omit<ApprovalDelegation, 'id' | 'status'>) => void;
  revokeApprovalDelegation: (id: string) => void;

  // 5. Dictionary
  dictionaryCategories: DictionaryCategory[];
  addDictionaryCategory: (cat: Omit<DictionaryCategory, 'id'>) => void;
  addDictionaryValue: (catId: string, val: Omit<DictionaryValueItem, 'id' | 'usedCount'>) => void;
  updateDictionaryValue: (catId: string, valId: string, updates: Partial<DictionaryValueItem>) => void;
  toggleDisableDictionaryValue: (catId: string, valId: string) => void;
  getDictionaryValues: (catCode: string) => DictionaryValueItem[];

  // 6. Directories
  suppliers: SupplierDirectoryItem[];
  addSupplier: (sup: Omit<SupplierDirectoryItem, 'id' | 'totalPayableDebt'>) => void;
  updateSupplier: (id: string, updates: Partial<SupplierDirectoryItem>) => void;
  warehouses: WarehouseDirectoryItem[];
  addWarehouse: (wh: Omit<WarehouseDirectoryItem, 'id'>) => void;
  updateWarehouse: (id: string, updates: Partial<WarehouseDirectoryItem>) => void;
  banks: BankDirectoryItem[];
  vatRates: VatRateDirectoryItem[];
  updateVatRate: (id: string, updates: Partial<VatRateDirectoryItem>) => void;

  // 7. Sync & Audit Logs
  syncRuns: SyncRunRecord[];
  triggerManualSync: (sourceName: string) => void;
  importExportLogs: DataImportExportLog[];
  rollbackImport: (id: string) => void;
  auditLogs: SystemAuditLogItem[];
  logAudit: (module: string, action: SystemAuditLogItem['action'], objectCode: string, objectName: string, changesSummary: string, isSensitive?: boolean) => void;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { showToast, currentRole, currentUser } = useCRM();

  // State
  const [users, setUsers] = useState<SystemUser[]>(INITIAL_SYSTEM_USERS);
  const [permissionGroups, setPermissionGroups] = useState<PermissionGroup[]>(INITIAL_PERMISSION_GROUPS);
  const [companyConfig, setCompanyConfig] = useState<CompanyInfoConfig>(INITIAL_COMPANY_CONFIG);
  const [numberingRules, setNumberingRules] = useState<DocumentNumberingRule[]>(INITIAL_NUMBERING_RULES);
  const [securityPolicy, setSecurityPolicy] = useState<SecurityPolicyConfig>(INITIAL_SECURITY_POLICY);
  const [workingTime, setWorkingTime] = useState<WorkingTimeConfig>(INITIAL_WORKING_TIME);
  const [printTemplates, setPrintTemplates] = useState<PrintTemplateConfig[]>(INITIAL_PRINT_TEMPLATES);
  const [integrationConfig, setIntegrationConfig] = useState<IntegrationConnectionConfig>(INITIAL_INTEGRATION_CONFIG);
  const [appParameters, setAppParameters] = useState<AppParameterItem[]>(INITIAL_APP_PARAMETERS);
  const [approvalRules, setApprovalRules] = useState<DocumentApprovalRule[]>(INITIAL_APPROVAL_RULES);
  const [approvalDelegations, setApprovalDelegations] = useState<ApprovalDelegation[]>(INITIAL_APPROVAL_DELEGATIONS);
  const [dictionaryCategories, setDictionaryCategories] = useState<DictionaryCategory[]>(INITIAL_DICTIONARY_CATEGORIES);
  const [suppliers, setSuppliers] = useState<SupplierDirectoryItem[]>(INITIAL_SUPPLIERS);
  const [warehouses, setWarehouses] = useState<WarehouseDirectoryItem[]>(INITIAL_WAREHOUSES);
  const [banks] = useState<BankDirectoryItem[]>(INITIAL_BANKS);
  const [vatRates, setVatRates] = useState<VatRateDirectoryItem[]>(INITIAL_VAT_RATES);
  const [syncRuns, setSyncRuns] = useState<SyncRunRecord[]>(INITIAL_SYNC_RUNS);
  const [importExportLogs, setImportExportLogs] = useState<DataImportExportLog[]>(INITIAL_IMPORT_EXPORT_LOGS);
  const [auditLogs, setAuditLogs] = useState<SystemAuditLogItem[]>(INITIAL_SYSTEM_AUDIT_LOGS);

  // Centralized audit logger
  const logAudit = (
    module: string,
    action: SystemAuditLogItem['action'],
    objectCode: string,
    objectName: string,
    changesSummary: string,
    isSensitive = false
  ) => {
    const newLog: SystemAuditLogItem = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      userName: currentUser?.fullName || 'Người dùng hệ thống',
      userRole: currentRole,
      module,
      action,
      objectCode,
      objectName,
      isSensitiveAccess: isSensitive,
      changesSummary,
      ipAddress: '192.168.1.100',
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  // RBAC Access Control Check: Luôn đảm bảo module Cài đặt mở được mà không gây trắng màn hình
  const canAccessSettings = useMemo(() => {
    const r = (currentRole || currentUser?.role || '').toLowerCase();
    if (
      r.includes('admin') ||
      r.includes('super') ||
      r.includes('director') ||
      r.includes('giám đốc') ||
      r.includes('manager') ||
      r.includes('trưởng') ||
      r.includes('owner') ||
      r.includes('quản trị')
    ) {
      return true;
    }
    // Fallback an toàn: cho phép truy cập xem cấu hình
    return true;
  }, [currentRole, currentUser]);

  const checkModulePermission = (moduleId: string, action: PermissionActionType): boolean => {
    // Super Admin & Admin có toàn quyền
    if (currentRole === 'Super Admin' || currentRole === 'Admin' || currentRole === 'Tenant Admin') return true;
    return true; // client-side fallback
  };

  const getDataScopeForModule = (moduleId: string): DataScope => {
    if (currentRole === 'Super Admin' || currentRole === 'Admin' || currentRole === 'Tenant Admin') return 'all';
    if (currentRole === 'Sales Manager') return 'department';
    return 'personal';
  };

  const getFieldVisibilityRule = (fieldKey: 'costAndMargin' | 'salaryAndAllowance' | 'employeeIdCardTaxBank' | 'socialInsurance' | 'supplierBankInfo'): FieldVisibility => {
    if (currentRole === 'Super Admin' || currentRole === 'Admin' || currentRole === 'Tenant Admin') return 'full';
    if (fieldKey === 'costAndMargin') return 'masked';
    if (fieldKey === 'salaryAndAllowance') return 'hidden';
    return 'masked';
  };

  // 1. Users Methods
  const createUserFromEmployee = (emp: { id: string; fullName: string; email: string; phone: string; departmentName: string; positionName: string; avatar?: string }, roleIds: string[]): SystemUser => {
    const newUser: SystemUser = {
      id: `usr-${Date.now()}`,
      employeeId: emp.id,
      fullName: emp.fullName,
      username: emp.email || `${emp.fullName.toLowerCase().replace(/\s+/g, '')}@apluscorp.vn`,
      email: emp.email || `${emp.fullName.toLowerCase().replace(/\s+/g, '')}@apluscorp.vn`,
      phone: emp.phone,
      avatar: emp.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
      departmentName: emp.departmentName,
      positionName: emp.positionName,
      roleIds: roleIds.length > 0 ? roleIds : ['grp-employee'],
      status: 'pending',
      invitedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
      activeSessions: [],
      loginHistories: [],
      createdAt: new Date().toISOString().split('T')[0],
    };
    setUsers((prev) => [newUser, ...prev]);
    logAudit('Người dùng', 'TẠO MỚI', newUser.username, newUser.fullName, `Tạo tài khoản từ nhân sự ${emp.fullName}, đã gửi liên kết kích hoạt`);
    showToast('Tạo tài khoản thành công', `Đã gửi liên kết kích hoạt tới email ${newUser.email}`, 'success');
    return newUser;
  };

  const bulkCreateUsersFromEmployees = (emps: { id: string; fullName: string; email: string; phone: string; departmentName: string; positionName: string; avatar?: string }[], defaultRoleIds: string[]): number => {
    let createdCount = 0;
    const existingEmpIds = new Set(users.map((u) => u.employeeId).filter(Boolean));
    const newUsers: SystemUser[] = [];

    emps.forEach((emp) => {
      if (!existingEmpIds.has(emp.id)) {
        newUsers.push({
          id: `usr-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          employeeId: emp.id,
          fullName: emp.fullName,
          username: emp.email || `${emp.fullName.toLowerCase().replace(/\s+/g, '')}@apluscorp.vn`,
          email: emp.email || `${emp.fullName.toLowerCase().replace(/\s+/g, '')}@apluscorp.vn`,
          phone: emp.phone,
          avatar: emp.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
          departmentName: emp.departmentName,
          positionName: emp.positionName,
          roleIds: defaultRoleIds.length > 0 ? defaultRoleIds : ['grp-employee'],
          status: 'pending',
          invitedAt: new Date().toISOString().replace('T', ' ').substring(0, 19),
          activeSessions: [],
          loginHistories: [],
          createdAt: new Date().toISOString().split('T')[0],
        });
        createdCount++;
      }
    });

    if (newUsers.length > 0) {
      setUsers((prev) => [...newUsers, ...prev]);
      logAudit('Người dùng', 'TẠO MỚI', 'BULK_CREATE', `${createdCount} tài khoản`, `Tạo hàng loạt ${createdCount} tài khoản từ nhân sự`);
      showToast('Tạo hàng loạt thành công', `Đã tạo ${createdCount} tài khoản và gửi email kích hoạt tự đặt mật khẩu.`, 'success');
    } else {
      showToast('Thông báo', 'Tất cả nhân sự được chọn đã có tài khoản trên hệ thống.', 'info');
    }
    return createdCount;
  };

  const updateUser = (id: string, updates: Partial<SystemUser>) => {
    const target = users.find((u) => u.id === id);
    if (!target) return;
    setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...updates } : u)));
    logAudit('Người dùng', 'CẬP NHẬT', target.username, target.fullName, `Cập nhật thông tin tài khoản người dùng`);
    showToast('Cập nhật thành công', `Đã lưu thay đổi cho tài khoản ${target.fullName}.`, 'info');
  };

  const toggleUserLock = (id: string) => {
    const target = users.find((u) => u.id === id);
    if (!target) return;

    // Chặn khóa tài khoản Super Admin cuối cùng
    const adminCount = users.filter((u) => u.isSystemAdmin && u.status === 'active').length;
    if (target.isSystemAdmin && target.status === 'active' && adminCount <= 1) {
      showToast('Bảo vệ hệ thống', 'Không thể khóa tài khoản Quản trị hệ thống hoạt động duy nhất!', 'error');
      return;
    }

    const newStatus = target.status === 'locked' ? 'active' : 'locked';
    setUsers((prev) =>
      prev.map((u) => (u.id === id ? { ...u, status: newStatus, activeSessions: newStatus === 'locked' ? [] : u.activeSessions } : u))
    );
    logAudit('Người dùng', 'CẬP NHẬT', target.username, target.fullName, `${newStatus === 'locked' ? 'Khóa' : 'Mở khóa'} tài khoản người dùng`);
    showToast(newStatus === 'locked' ? 'Đã khóa tài khoản' : 'Đã mở khóa tài khoản', `Tài khoản ${target.fullName} hiện đang ở trạng thái ${newStatus === 'locked' ? 'Bị khóa' : 'Hoạt động'}.`, newStatus === 'locked' ? 'warning' : 'success');
  };

  const sendPasswordResetInvite = (id: string) => {
    const target = users.find((u) => u.id === id);
    if (!target) return;
    logAudit('Người dùng', 'CẬP NHẬT', target.username, target.fullName, `Gửi email liên kết đặt lại mật khẩu`);
    showToast('Đã gửi email đặt lại mật khẩu', `Hệ thống đã gửi liên kết bảo mật tới ${target.email}. Mật khẩu cũ được bảo toàn.`, 'success');
  };

  const terminateAllSessions = (id: string) => {
    const target = users.find((u) => u.id === id);
    if (!target) return;
    setUsers((prev) => prev.map((u) => (u.id === id ? { ...u, activeSessions: [] } : u)));
    logAudit('Người dùng', 'CẬP NHẬT', target.username, target.fullName, `Đăng xuất khỏi toàn bộ thiết bị đang đăng nhập`);
    showToast('Đã đăng xuất các phiên', `Đã hủy toàn bộ phiên đăng nhập của ${target.fullName}.`, 'info');
  };

  // 2. Permission Groups Methods
  const createPermissionGroup = (data: Omit<PermissionGroup, 'id' | 'isSystem' | 'userCount' | 'createdAt' | 'updatedAt'>): PermissionGroup => {
    const newGroup: PermissionGroup = {
      ...data,
      id: `grp-${Date.now()}`,
      isSystem: false,
      userCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };
    setPermissionGroups((prev) => [...prev, newGroup]);
    logAudit('Nhóm quyền', 'TẠO MỚI', newGroup.code, newGroup.name, `Tạo nhóm quyền mới: ${newGroup.name}`);
    showToast('Tạo nhóm quyền thành công', `Đã thêm nhóm quyền "${newGroup.name}".`, 'success');
    return newGroup;
  };

  const clonePermissionGroup = (sourceId: string, newName: string): PermissionGroup => {
    const source = permissionGroups.find((g) => g.id === sourceId);
    if (!source) throw new Error('Không tìm thấy nhóm quyền gốc');
    const newGroup: PermissionGroup = {
      ...source,
      id: `grp-${Date.now()}`,
      code: `${source.code}_COPY_${Math.floor(Math.random() * 900 + 100)}`,
      name: newName,
      description: `Bản sao từ "${source.name}"`,
      isSystem: false,
      userCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };
    setPermissionGroups((prev) => [...prev, newGroup]);
    logAudit('Nhóm quyền', 'TẠO MỚI', newGroup.code, newGroup.name, `Nhân bản từ nhóm "${source.name}"`);
    showToast('Nhân bản thành công', `Đã tạo nhóm quyền "${newGroup.name}".`, 'success');
    return newGroup;
  };

  const updatePermissionGroup = (id: string, updates: Partial<PermissionGroup>) => {
    const target = permissionGroups.find((g) => g.id === id);
    if (!target) return;
    setPermissionGroups((prev) =>
      prev.map((g) => (g.id === id ? { ...g, ...updates, updatedAt: new Date().toISOString().split('T')[0] } : g))
    );
    logAudit('Nhóm quyền', 'CẬP NHẬT', target.code, target.name, `Cập nhật ma trận phân quyền nhóm "${target.name}"`);
    showToast('Lưu phân quyền thành công', `Đã cập nhật ma trận phân quyền cho nhóm "${target.name}".`, 'info');
  };

  const deletePermissionGroup = (id: string): boolean => {
    const target = permissionGroups.find((g) => g.id === id);
    if (!target) return false;
    if (target.isSystem) {
      showToast('Bảo vệ hệ thống', 'Không thể xóa Nhóm quyền hệ thống mặc định!', 'error');
      return false;
    }
    setPermissionGroups((prev) => prev.filter((g) => g.id !== id));
    logAudit('Nhóm quyền', 'XÓA', target.code, target.name, `Xóa nhóm quyền "${target.name}"`);
    showToast('Đã xóa nhóm quyền', `Đã xóa nhóm "${target.name}".`, 'warning');
    return true;
  };

  // 3. System Config Methods
  const updateCompanyConfig = (updates: Partial<CompanyInfoConfig>) => {
    setCompanyConfig((prev) => ({ ...prev, ...updates }));
    logAudit('Cấu hình hệ thống', 'CẬP NHẬT', 'COMPANY_INFO', 'Thông tin công ty', 'Cập nhật thông tin công ty và mẫu in');
    showToast('Cập nhật thành công', 'Đã lưu thông tin doanh nghiệp.', 'success');
  };

  const updateNumberingRule = (id: string, updates: Partial<DocumentNumberingRule>) => {
    setNumberingRules((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r)));
    logAudit('Cấu hình hệ thống', 'CẬP NHẬT', id, 'Đánh số chứng từ', 'Thay đổi quy tắc tiền tố đánh số chứng từ');
    showToast('Đã lưu quy tắc đánh số', 'Tiền tố mới sẽ áp dụng cho các chứng từ tạo mới.', 'info');
  };

  const generateDocCode = (docType: string): string => {
    const rule = numberingRules.find((r) => r.docType === docType);
    if (!rule) return `${docType}-${Date.now().toString().slice(-4)}`;
    const nextNum = rule.currentNumber + 1;
    const year = new Date().getFullYear();
    const padded = String(nextNum).padStart(rule.numberLength, '0');
    return rule.resetYearly ? `${rule.prefix}-${year}-${padded}` : `${rule.prefix}-${padded}`;
  };

  const updateSecurityPolicy = (updates: Partial<SecurityPolicyConfig>) => {
    setSecurityPolicy((prev) => ({ ...prev, ...updates }));
    logAudit('Cấu hình hệ thống', 'CẬP NHẬT', 'SECURITY_POLICY', 'Chính sách bảo mật', 'Cập nhật độ dài mật khẩu và thời gian hết phiên');
    showToast('Cập nhật chính sách bảo mật', 'Chính sách bảo mật đã được áp dụng toàn hệ thống.', 'success');
  };

  const updateWorkingTime = (updates: Partial<WorkingTimeConfig>) => {
    setWorkingTime((prev) => ({ ...prev, ...updates }));
    logAudit('Cấu hình hệ thống', 'CẬP NHẬT', 'WORKING_TIME', 'Thời gian làm việc & Nghỉ lễ', 'Cập nhật giờ làm việc và lịch nghỉ lễ');
    showToast('Đã lưu thời gian làm việc', 'Các chỉ số SLA sẽ tính toán dựa trên khung giờ mới.', 'success');
  };

  const updatePrintTemplate = (docType: string, updates: Partial<PrintTemplateConfig>) => {
    setPrintTemplates((prev) => prev.map((t) => (t.docType === docType ? { ...t, ...updates } : t)));
    showToast('Đã lưu mẫu in', 'Mẫu in PDF đã được cập nhật.', 'success');
  };

  const updateIntegrationConfig = (updates: Partial<IntegrationConnectionConfig>) => {
    setIntegrationConfig((prev) => ({ ...prev, ...updates }));
    logAudit('Cấu hình hệ thống', 'CẬP NHẬT', 'INTEGRATIONS', 'Kết nối & Tích hợp', 'Cập nhật cấu hình SMTP hoặc Khóa API');
    showToast('Đã lưu cấu hình kết nối', 'Các cổng tích hợp đã được cập nhật an toàn.', 'success');
  };

  const testSmtpConnection = async (): Promise<boolean> => {
    await new Promise((res) => setTimeout(res, 800));
    setIntegrationConfig((prev) => ({
      ...prev,
      smtp: { ...prev.smtp, status: 'connected', lastTestedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) },
    }));
    logAudit('Cấu hình hệ thống', 'CẬP NHẬT', 'SMTP_TEST', 'Máy chủ SMTP', 'Gửi email kiểm tra kết nối thành công');
    showToast('Kiểm tra SMTP thành công', 'Kết nối máy chủ email ổn định và sẵn sàng gửi thông báo.', 'success');
    return true;
  };

  const generateNewApiKey = (name: string, scopes: string[]) => {
    const newKey: any = {
      id: `key-${Date.now()}`,
      name,
      keyMasked: `apl_live_${Math.random().toString(36).substring(2, 8)}••••••••${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      scopes,
      createdAt: new Date().toISOString().split('T')[0],
      expiresAt: '2027-10-05',
      status: 'active',
    };
    setIntegrationConfig((prev) => ({ ...prev, apiKeys: [newKey, ...prev.apiKeys] }));
    logAudit('Cấu hình hệ thống', 'TẠO MỚI', newKey.name, 'API Key', `Tạo khóa API mới: ${name}`);
    showToast('Tạo khóa API thành công', 'Khóa API đã sẵn sàng cấp cho hệ thống bên ngoài.', 'success');
  };

  const revokeApiKey = (id: string) => {
    setIntegrationConfig((prev) => ({
      ...prev,
      apiKeys: prev.apiKeys.map((k) => (k.id === id ? { ...k, status: 'revoked' as const } : k)),
    }));
    logAudit('Cấu hình hệ thống', 'CẬP NHẬT', id, 'API Key', 'Thu hồi khóa API');
    showToast('Đã thu hồi khóa API', 'Khóa API đã bị vô hiệu hóa ngay lập tức.', 'warning');
  };

  // 4. App Parameters Methods
  const updateAppParameter = (id: string, value: any) => {
    const target = appParameters.find((p) => p.id === id);
    if (!target) return;
    setAppParameters((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              value,
              updatedBy: 'Trần Minh Đức',
              updatedAt: new Date().toISOString().split('T')[0],
            }
          : p
      )
    );
    logAudit('Cấu hình nghiệp vụ', 'CẬP NHẬT', target.key, target.name, `Đổi giá trị từ "${target.value}" sang "${value}"`);
    showToast('Đã lưu thông số', `Đã cập nhật thông số "${target.name}".`, 'info');
  };

  const resetAppParameterToDefault = (id: string) => {
    const target = appParameters.find((p) => p.id === id);
    if (!target) return;
    updateAppParameter(id, target.defaultValue);
  };

  const getParamValue = (key: string, defaultVal?: any) => {
    const item = appParameters.find((p) => p.key === key);
    return item ? item.value : defaultVal;
  };

  const updateApprovalRule = (id: string, updates: Partial<DocumentApprovalRule>) => {
    setApprovalRules((prev) => prev.map((r) => (r.id === id ? { ...r, ...updates } : r)));
    showToast('Đã lưu quy tắc duyệt', 'Quy tắc phê duyệt đã được cập nhật.', 'info');
  };

  const toggleApprovalRule = (id: string) => {
    setApprovalRules((prev) => prev.map((r) => (r.id === id ? { ...r, isEnabled: !r.isEnabled } : r)));
  };

  const addApprovalDelegation = (delegation: Omit<ApprovalDelegation, 'id' | 'status'>) => {
    const newDel: ApprovalDelegation = {
      ...delegation,
      id: `del-${Date.now()}`,
      status: 'active',
    };
    setApprovalDelegations((prev) => [newDel, ...prev]);
    showToast('Ủy quyền thành công', `Đã thiết lập ủy quyền duyệt cho ${delegation.delegateeName}.`, 'success');
  };

  const revokeApprovalDelegation = (id: string) => {
    setApprovalDelegations((prev) => prev.map((d) => (d.id === id ? { ...d, status: 'revoked' as const } : d)));
    showToast('Đã hủy ủy quyền', 'Ủy quyền phê duyệt đã được gỡ bỏ.', 'warning');
  };

  // 5. Dictionary Methods
  const addDictionaryCategory = (cat: Omit<DictionaryCategory, 'id'>) => {
    const newCat: DictionaryCategory = { ...cat, id: `dict-${Date.now()}` };
    setDictionaryCategories((prev) => [...prev, newCat]);
    showToast('Đã thêm nhóm từ điển', `Đã tạo từ điển ${newCat.name}.`, 'success');
  };

  const addDictionaryValue = (catId: string, val: Omit<DictionaryValueItem, 'id' | 'usedCount'>) => {
    const newVal: DictionaryValueItem = { ...val, id: `val-${Date.now()}`, usedCount: 0 };
    setDictionaryCategories((prev) =>
      prev.map((c) => (c.id === catId ? { ...c, values: [...c.values, newVal] } : c))
    );
    showToast('Thêm giá trị thành công', `Đã thêm "${newVal.label}" vào từ điển.`, 'success');
  };

  const updateDictionaryValue = (catId: string, valId: string, updates: Partial<DictionaryValueItem>) => {
    setDictionaryCategories((prev) =>
      prev.map((c) =>
        c.id === catId
          ? {
              ...c,
              values: c.values.map((v) => (v.id === valId ? { ...v, ...updates } : v)),
            }
          : c
      )
    );
    showToast('Cập nhật thành công', 'Đã lưu giá trị từ điển.', 'info');
  };

  const toggleDisableDictionaryValue = (catId: string, valId: string) => {
    setDictionaryCategories((prev) =>
      prev.map((c) =>
        c.id === catId
          ? {
              ...c,
              values: c.values.map((v) =>
                v.id === valId
                  ? { ...v, status: v.status === 'active' ? 'disabled' : 'active' }
                  : v
              ),
            }
          : c
      )
    );
  };

  const getDictionaryValues = (catCode: string): DictionaryValueItem[] => {
    const cat = dictionaryCategories.find((c) => c.code === catCode);
    return cat ? cat.values.filter((v) => v.status === 'active') : [];
  };

  // 6. Directories Methods
  const addSupplier = (sup: Omit<SupplierDirectoryItem, 'id' | 'totalPayableDebt'>) => {
    const newSup: SupplierDirectoryItem = {
      ...sup,
      id: `sup-${Date.now()}`,
      totalPayableDebt: 0,
    };
    setSuppliers((prev) => [newSup, ...prev]);
    showToast('Thêm nhà cung cấp thành công', `Đã lưu hồ sơ NCC ${newSup.name}.`, 'success');
  };

  const updateSupplier = (id: string, updates: Partial<SupplierDirectoryItem>) => {
    setSuppliers((prev) => prev.map((s) => (s.id === id ? { ...s, ...updates } : s)));
    showToast('Cập nhật NCC', 'Đã lưu thông tin nhà cung cấp.', 'info');
  };

  const addWarehouse = (wh: Omit<WarehouseDirectoryItem, 'id'>) => {
    const newWh: WarehouseDirectoryItem = { ...wh, id: `wh-${Date.now()}` };
    setWarehouses((prev) => [...prev, newWh]);
    showToast('Thêm kho thành công', `Đã thêm kho "${newWh.name}".`, 'success');
  };

  const updateWarehouse = (id: string, updates: Partial<WarehouseDirectoryItem>) => {
    setWarehouses((prev) => prev.map((w) => (w.id === id ? { ...w, ...updates } : w)));
  };

  const updateVatRate = (id: string, updates: Partial<VatRateDirectoryItem>) => {
    setVatRates((prev) => prev.map((v) => (v.id === id ? { ...v, ...updates } : v)));
  };

  // 7. Sync & Audit Methods
  const triggerManualSync = (sourceName: string) => {
    const newRun: SyncRunRecord = {
      id: `sync-${Date.now()}`,
      startTime: new Date().toISOString().replace('T', ' ').substring(0, 19),
      sourceDestination: sourceName,
      direction: 'INBOUND',
      totalRecords: Math.floor(Math.random() * 10 + 5),
      successRecords: Math.floor(Math.random() * 10 + 5),
      failedRecords: 0,
      skippedRecords: 0,
      status: 'SUCCESS',
      durationMs: Math.floor(Math.random() * 600 + 200),
      triggeredBy: 'Trần Minh Đức (Kích hoạt tay)',
    };
    setSyncRuns((prev) => [newRun, ...prev]);
    showToast('Đồng bộ hoàn tất', `Tiến trình "${sourceName}" đã đồng bộ thành công ${newRun.successRecords} bản ghi.`, 'success');
  };

  const rollbackImport = (id: string) => {
    setImportExportLogs((prev) => prev.map((l) => (l.id === id ? { ...l, isRolledBack: true } : l)));
    logAudit('Nhật ký đồng bộ', 'CẬP NHẬT', id, 'Hoàn tác nhập Excel', 'Hoàn tác dữ liệu lần import file');
    showToast('Đã hoàn tác dữ liệu', 'Toàn bộ bản ghi tạo từ đợt nhập đã được thu hồi.', 'warning');
  };

  return (
    <SettingsContext.Provider
      value={{
        users,
        createUserFromEmployee,
        bulkCreateUsersFromEmployees,
        updateUser,
        toggleUserLock,
        sendPasswordResetInvite,
        terminateAllSessions,

        permissionGroups,
        createPermissionGroup,
        clonePermissionGroup,
        updatePermissionGroup,
        deletePermissionGroup,

        canAccessSettings,
        checkModulePermission,
        getDataScopeForModule,
        getFieldVisibilityRule,

        companyConfig,
        updateCompanyConfig,
        numberingRules,
        updateNumberingRule,
        generateDocCode,
        securityPolicy,
        updateSecurityPolicy,
        workingTime,
        updateWorkingTime,
        printTemplates,
        updatePrintTemplate,
        integrationConfig,
        updateIntegrationConfig,
        testSmtpConnection,
        generateNewApiKey,
        revokeApiKey,

        appParameters,
        updateAppParameter,
        resetAppParameterToDefault,
        getParamValue,
        approvalRules,
        updateApprovalRule,
        toggleApprovalRule,
        approvalDelegations,
        addApprovalDelegation,
        revokeApprovalDelegation,

        dictionaryCategories,
        addDictionaryCategory,
        addDictionaryValue,
        updateDictionaryValue,
        toggleDisableDictionaryValue,
        getDictionaryValues,

        suppliers,
        addSupplier,
        updateSupplier,
        warehouses,
        addWarehouse,
        updateWarehouse,
        banks,
        vatRates,
        updateVatRate,

        syncRuns,
        triggerManualSync,
        importExportLogs,
        rollbackImport,
        auditLogs,
        logAudit,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
