/**
 * Data types for Sales Management Module (Quản lý Sales)
 * Xuyên suốt luồng: Lead -> Khách hàng -> Cơ hội -> Báo giá -> Đơn hàng -> Hợp đồng -> Hóa đơn -> Phiếu thu
 */

export interface DocumentChainInfo {
  leadId?: string;
  leadCode?: string;
  customerId?: string;
  customerCode?: string;
  customerName?: string;
  opportunityId?: string;
  opportunityCode?: string;
  technicalRequestId?: string;
  technicalRequestCode?: string;
  quotationId?: string;
  quotationCode?: string;
  orderId?: string;
  orderCode?: string;
  stockOutId?: string;
  stockOutCode?: string;
  deliveryNoteId?: string;
  deliveryNoteCode?: string;
  contractId?: string;
  contractCode?: string;
  projectId?: string;
  projectCode?: string;
  acceptanceId?: string;
  acceptanceCode?: string;
  invoiceId?: string;
  invoiceCode?: string;
  receiptId?: string;
  receiptCode?: string;
}

// 1. Lead
export type LeadStatus = 'Mới' | 'Đang liên hệ' | 'Đủ điều kiện' | 'Không phù hợp';
export type LeadSource = 'Website' | 'Facebook' | 'Zalo' | 'Giới thiệu' | 'Hotline' | 'Khác';

export interface SalesLead {
  id: string;
  code: string; // LEAD-2026-xxxx
  fullName: string;
  company: string;
  phone: string;
  email: string;
  source: LeadSource;
  status: LeadStatus;
  assignedTo: string;
  estimatedValue: number;
  notes: string;
  createdAt: string;
  lastContactedAt?: string;
  convertedTo?: {
    customerId: string;
    contactId: string;
    opportunityId: string;
    convertedAt: string;
  };
}

// 2. Khách hàng (Account / Customer)
export type CustomerType = 'Doanh nghiệp' | 'Cá nhân';
export type CustomerGroup = 'Thường' | 'VIP' | 'Tiềm năng';

export interface CustomerContactPerson {
  id: string;
  fullName: string;
  role: string;
  phone: string;
  email: string;
  isPrimary: boolean;
  isDecisionMaker: boolean;
}

export interface CustomerAccount {
  id: string;
  code: string; // KH-xxxx
  name: string;
  type: CustomerType;
  taxId: string; // Mã số thuế
  phone: string;
  email: string;
  industry: string;
  group: CustomerGroup;
  assignedTo: string;
  totalRevenue: number; // Doanh thu lũy kế
  currentDebt: number; // Công nợ hiện tại
  billingAddress: string;
  shippingAddresses: string[];
  contacts: CustomerContactPerson[];
  lastPurchaseDate?: string;
  openDealsCount: number;
  notes: string;
  createdAt: string;
}

// 3. Cơ hội bán hàng (Opportunity)
export type OpportunityStageName = 
  | 'Khám phá nhu cầu' 
  | 'Báo giá & Đề xuất' 
  | 'Đàm phán' 
  | 'Thành công (Won)' 
  | 'Thất bại (Lost)';

export interface SalesOpportunity {
  id: string;
  code: string; // CH-2026-xxxx
  title: string;
  customerId: string;
  customerCode: string;
  customerName: string;
  contactName: string;
  amount: number;
  stage: OpportunityStageName;
  probability: number; // 20, 40, 70, 100, 0
  expectedCloseDate: string; // BẮT BUỘC
  leadSource: string;
  interestedProducts: string[]; // SKU list
  assignedTo: string;
  nextStep: string; // BẮT BUỘC với cơ hội đang mở
  nextStepDate: string;
  lostReason?: 'Giá cao' | 'Đối thủ' | 'Chưa có ngân sách' | 'Không phản hồi' | 'Khác';
  competitorName?: string;
  lastActivityDate: string; // Để cảnh báo đứng > 14 ngày
  chain: DocumentChainInfo;
  createdAt: string;
}

// 4. Báo giá (Quote)
export type QuotationStatus = 
  | 'Nháp' 
  | 'Chờ duyệt' 
  | 'Chờ Sales duyệt thương mại'
  | 'Đã gửi' 
  | 'Chấp nhận' 
  | 'Từ chối' 
  | 'Hết hạn';

export interface SalesQuotationLineItem {
  id: string;
  productId: string;
  sku: string;
  productName: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  discountPercent: number;
  total: number;
  availableStock?: number;
}

export interface SalesQuotation {
  id: string;
  code: string; // BG-2026-xxxx
  version: number; // v1, v2...
  isLatestVersion: boolean;
  parentQuotationCode?: string;
  title: string;
  customerId: string;
  customerCode: string;
  customerName: string;
  customerCompany: string;
  customerEmail: string;
  customerPhone: string;
  customerAddress: string;
  opportunityId?: string;
  opportunityCode?: string;
  items: SalesQuotationLineItem[];
  subTotal: number;
  discountPercentTotal: number;
  discountAmountTotal: number;
  taxRate: 0 | 5 | 8 | 10;
  taxAmount: number;
  grandTotal: number;
  amountInWords: string;
  status: QuotationStatus;
  validUntil: string;
  paymentTerms: string;
  notes: string;
  createdByName: string;
  requiresApproval?: boolean;
  approvalRequiredBy?: 'Trưởng nhóm' | 'Giám đốc';
  approvedBy?: string;
  approvedAt?: string;
  chain: DocumentChainInfo;
  createdAt: string;
}

import type { LogisticsProcessStatus, OrderComment, OrderStatusHistoryItem } from './logistics';

// 5. Đơn hàng & Phê duyệt (Sales Order / Booking Approval)
export type OrderStatus = 
  | 'Nháp' 
  | 'Chờ duyệt' 
  | 'Đã duyệt' 
  | 'Từ chối' 
  | 'Đang thực hiện' 
  | 'Hoàn tất' 
  | 'Hủy';

export type OrderApprovalStatus = 'Nháp' | 'Chờ duyệt' | 'Đã duyệt' | 'Từ chối' | 'Hủy';

export interface SalesOrderItem {
  sku: string;
  productName: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  discountPercent: number;
  total: number;
  availableStock: number;
  confirmedQuantity?: number;
  lineAction?: 'Đủ hàng' | 'Chờ nhập hàng' | 'Loại khỏi đơn';
}

export interface SalesOrder {
  id: string;
  code: string; // DH-2026-xxxx
  quotationId?: string;
  quotationCode?: string;
  customerId: string;
  customerCode: string;
  customerName: string;
  orderDate: string;
  expectedDeliveryDate: string;
  expectedShipDate?: string;
  items: SalesOrderItem[];
  subTotal: number;
  taxAmount: number;
  totalAmount: number;
  amountInWords: string;
  paymentTerms: string;
  assignedTo: string;
  status: OrderStatus;
  approvalStatus?: OrderApprovalStatus;
  logisticsStatus?: LogisticsProcessStatus;
  sentToLogisticsAt?: string;
  isLockedForSales?: boolean;
  approvalLevel: 'Trưởng nhóm' | 'Giám đốc';
  approvedBy?: string;
  approvedAt?: string;
  rejectionReason?: string;
  logisticsRejectionReason?: string;
  logisticsNeedInfoReason?: string;
  stockSufficient: boolean;
  stockWarnings: string[];
  stockOutRequested?: boolean;
  stockAllocated?: boolean;
  contractCreated?: boolean;
  comments?: OrderComment[];
  statusHistory?: OrderStatusHistoryItem[];
  chain: DocumentChainInfo;
  createdAt: string;
}

// 6. Hợp đồng (Contract)
export type ContractStatus = 
  | 'Nháp' 
  | 'Chờ duyệt' 
  | 'Chờ ký' 
  | 'Đang hiệu lực' 
  | 'Hoàn thành' 
  | 'Hết hạn' 
  | 'Hủy';

export interface ContractPaymentMilestone {
  id: string;
  title: string;
  percentage: number;
  amount: number;
  dueDate: string;
  isPaid: boolean;
  invoiceCode?: string;
}

export interface SalesContract {
  id: string;
  contractNumber: string; // HD-2026-xxxx
  title: string;
  orderId?: string;
  orderCode?: string;
  customerId: string;
  customerCode: string;
  customerName: string;
  customerCompany: string;
  totalValue: number;
  amountInWords: string;
  startDate: string;
  endDate: string;
  status: ContractStatus;
  signedDate?: string;
  paymentMilestones: ContractPaymentMilestone[];
  manager: string;
  templateVariables: {
    ten_khach_hang: string;
    gia_tri: string;
    ngay_ky: string;
    dia_chi: string;
    dai_dien: string;
    chuc_vu: string;
  };
  attachments: { name: string; size: string; uploadDate: string }[];
  chain: DocumentChainInfo;
  createdAt: string;
}

// 7. Hóa đơn (Invoice)
export type InvoiceStatus = 
  | 'Nháp' 
  | 'Đã phát hành' 
  | 'Chưa thanh toán' 
  | 'Thanh toán một phần' 
  | 'Đã thanh toán' 
  | 'Quá hạn' 
  | 'Hủy';

export interface SalesInvoice {
  id: string;
  invoiceNumber: string; // HDON-2026-xxxx
  customerId: string;
  customerCode: string;
  customerName: string;
  customerTaxId: string;
  customerAddress: string;
  contractId?: string;
  contractCode?: string;
  orderId?: string;
  orderCode?: string;
  milestoneTitle?: string;
  issueDate: string;
  dueDate: string;
  subTotal: number;
  taxRate: number;
  taxAmount: number;
  totalAmount: number;
  amountInWords: string;
  paidAmount: number;
  remainingAmount: number;
  status: InvoiceStatus;
  // Electronic invoice integration placeholders
  einvoiceNumber?: string; // Số HĐĐT
  einvoiceSymbol?: string; // Ký hiệu ví dụ 1C26TBB
  einvoiceIssuedDate?: string;
  einvoiceFileUrl?: string;
  chain: DocumentChainInfo;
  createdAt: string;
}

// 8. Phiếu thu (Printed Receipt)
export type ReceiptStatus = 'Hoàn tất' | 'Đã hủy';
export type PaymentMethod = 'Chuyển khoản' | 'Tiền mặt' | 'Khác';

export interface SalesReceipt {
  id: string;
  receiptNumber: string; // PT-2026-xxxx
  date: string;
  customerId: string;
  customerCode: string;
  customerName: string;
  payerName: string; // Họ tên người nộp
  payerAddress?: string;
  invoiceId?: string;
  invoiceNumber?: string;
  amount: number;
  amountInWords: string;
  paymentMethod: PaymentMethod;
  bankRefNumber?: string; // Mã tham chiếu giao dịch NH
  reason: string; // Lý do nộp tiền
  collectorName: string; // Người lập / thu
  cashierName: string; // Thủ quỹ / Kế toán
  status: ReceiptStatus;
  cancelReason?: string;
  chain: DocumentChainInfo;
  createdAt: string;
}

// 9. Hoạt động & Lịch hẹn (Activities)
export type ActivityType = 'Cuộc gọi' | 'Cuộc hẹn/Họp' | 'Email' | 'Nhiệm vụ' | 'Ghi chú';
export type ActivityPriority = 'Thấp' | 'Trung bình' | 'Cao' | 'Khẩn cấp';

export interface SalesActivity {
  id: string;
  code: string;
  type: ActivityType;
  title: string;
  description: string;
  targetType: 'lead' | 'customer' | 'opportunity';
  targetId: string;
  targetCode: string;
  targetName: string;
  startTime: string; // ISO datetime
  endTime?: string;
  priority: ActivityPriority;
  assignedTo: string;
  isCompleted: boolean;
  completedAt?: string;
  nextStepPrompt?: string;
  createdAt: string;
}
