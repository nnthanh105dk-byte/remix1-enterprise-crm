import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSettings } from '../../context/SettingsContext';
import { useWarehouse } from '../../context/WarehouseContext';
import {
  FolderKanban,
  Building,
  Package,
  Boxes,
  Ruler,
  Warehouse,
  MapPin,
  Landmark,
  Percent,
  Plus,
  Search,
  Download,
  Upload,
  ArrowRight,
  ExternalLink,
} from 'lucide-react';

export const SettingsDirectoriesView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const {
    suppliers,
    addSupplier,
    warehouses,
    addWarehouse,
    banks,
    vatRates,
    updateVatRate,
    canAccessSettings,
    getFieldVisibilityRule,
  } = useSettings();
  const { products } = useWarehouse();

  const [activeTab, setActiveTab] = useState<
    'suppliers' | 'products' | 'categories' | 'uom' | 'warehouses' | 'regions' | 'banks' | 'vat'
  >('suppliers');

  const [searchTerm, setSearchTerm] = useState('');
  const [isAddSupplierModalOpen, setIsAddSupplierModalOpen] = useState(false);

  // New Supplier Form State
  const [supCode, setSupCode] = useState('');
  const [supName, setSupName] = useState('');
  const [supTaxCode, setSupTaxCode] = useState('');
  const [supContact, setSupContact] = useState('');
  const [supPhone, setSupPhone] = useState('');
  const [supEmail, setSupEmail] = useState('');
  const [supPaymentTerm, setSupPaymentTerm] = useState('Công nợ 30 ngày');
  const [supBank, setSupBank] = useState('');
  const [supGroup, setSupGroup] = useState('Thiết bị & Công nghệ');

  const costVisibility = getFieldVisibilityRule('costAndMargin');

  const handleAddSupplierSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supCode || !supName || !supTaxCode) return;
    addSupplier({
      code: supCode.toUpperCase(),
      name: supName,
      taxCode: supTaxCode,
      address: 'Hà Nội',
      contactPerson: supContact,
      phone: supPhone,
      email: supEmail,
      defaultPaymentTerm: supPaymentTerm,
      bankAccount: '0011008899',
      bankName: supBank || 'Vietcombank',
      groupName: supGroup,
      status: 'active',
    });
    setIsAddSupplierModalOpen(false);
    setSupCode('');
    setSupName('');
    setSupTaxCode('');
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
            <FolderKanban className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              Danh Mục Dữ Liệu Nền (Directories)
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Quản lý Nhà cung cấp, Sản phẩm, Nhóm hàng, Đơn vị tính, Kho bãi, Khu vực giao nhận, Ngân hàng và Thuế suất VAT.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveModule('hr-staff')}
            className="px-3 py-1.5 rounded-xl border border-indigo-200 text-indigo-600 hover:bg-indigo-50 text-xs font-semibold flex items-center gap-1.5"
            title="Phòng ban & Chức vụ quản lý ở Quản lý nhân sự"
          >
            <span>Phòng ban &amp; Chức vụ</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 text-xs overflow-x-auto pb-0.5">
        {[
          { id: 'suppliers', label: `Nhà cung cấp (${(suppliers || []).length})` },
          { id: 'products', label: `Sản phẩm & Dịch vụ (${(products || []).length})` },
          { id: 'categories', label: 'Nhóm hàng' },
          { id: 'uom', label: 'Đơn vị tính' },
          { id: 'warehouses', label: `Kho (${(warehouses || []).length})` },
          { id: 'regions', label: 'Khu vực địa lý' },
          { id: 'banks', label: `Ngân hàng (${(banks || []).length})` },
          { id: 'vat', label: `Thuế suất VAT (${(vatRates || []).length})` },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`px-3.5 py-2 font-bold border-b-2 whitespace-nowrap ${
              activeTab === t.id
                ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400 bg-emerald-50/50 dark:bg-emerald-950/20'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* 1. NHÀ CUNG CẤP */}
      {activeTab === 'suppliers' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex items-center justify-between pb-2 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Danh Mục Nhà Cung Cấp ({suppliers.length} Đơn vị)</h3>
              <p className="text-[11px] text-slate-400">Nguồn cấp cho Đơn mua hàng, Hóa đơn mua hàng và Quản lý kho.</p>
            </div>
            <button
              onClick={() => setIsAddSupplierModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center gap-1.5 shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>Thêm Nhà Cung Cấp</span>
            </button>
          </div>

          <div className="border rounded-xl overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 font-semibold border-b">
                <tr>
                  <th className="px-3 py-2.5">Mã NCC</th>
                  <th className="px-3 py-2.5">Tên nhà cung cấp</th>
                  <th className="px-3 py-2.5">Mã số thuế</th>
                  <th className="px-3 py-2.5">Người liên hệ &amp; SĐT</th>
                  <th className="px-3 py-2.5">Điều khoản TT</th>
                  <th className="px-3 py-2.5">Công nợ phải trả (Chỉ đọc)</th>
                  <th className="px-3 py-2.5">Trạng thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {suppliers.map((sup) => (
                  <tr key={sup.id} className="hover:bg-slate-50/50">
                    <td className="px-3 py-2.5 font-mono font-bold text-emerald-600">{sup.code}</td>
                    <td className="px-3 py-2.5 font-bold text-slate-900 dark:text-white">
                      {sup.name}
                      <span className="block text-[10px] text-slate-400 font-normal">{sup.groupName} &bull; {sup.address}</span>
                    </td>
                    <td className="px-3 py-2.5 font-mono text-slate-600">{sup.taxCode}</td>
                    <td className="px-3 py-2.5">
                      <span className="font-semibold block">{sup.contactPerson}</span>
                      <span className="text-[11px] text-slate-400 font-mono">{sup.phone}</span>
                    </td>
                    <td className="px-3 py-2.5 font-medium text-slate-600">{sup.defaultPaymentTerm}</td>
                    <td className="px-3 py-2.5 font-mono font-bold text-rose-600">
                      {sup.totalPayableDebt.toLocaleString()} đ
                    </td>
                    <td className="px-3 py-2.5">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                        Đang giao dịch
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 2. SẢN PHẨM & DỊCH VỤ */}
      {activeTab === 'products' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex items-center justify-between pb-2 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Sản Phẩm &amp; Dịch Vụ Toàn Hệ Thống ({products.length} Mặt hàng)
              </h3>
              <p className="text-[11px] text-slate-400">
                Dùng chung bản ghi giữa Quản lý kho, Quản lý Sales và Kỹ thuật. Thuộc tính kỹ thuật đồng bộ tại Danh mục kỹ thuật.
              </p>
            </div>
            <button
              onClick={() => setActiveModule('technical-directory')}
              className="px-3 py-1.5 rounded-xl border border-sky-300 text-sky-600 hover:bg-sky-50 font-semibold flex items-center gap-1"
            >
              <span>Xem thông số kỹ thuật (Kỹ thuật &gt; Danh mục)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="border rounded-xl overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 font-semibold border-b">
                <tr>
                  <th className="px-3 py-2.5">Mã SKU</th>
                  <th className="px-3 py-2.5">Tên sản phẩm / Dịch vụ</th>
                  <th className="px-3 py-2.5">Nhóm hàng</th>
                  <th className="px-3 py-2.5">ĐVT</th>
                  <th className="px-3 py-2.5 text-right">Giá niêm yết</th>
                  <th className="px-3 py-2.5 text-right">Giá vốn</th>
                  <th className="px-3 py-2.5 text-center">Tồn khả dụng</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {products.slice(0, 15).map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/50">
                    <td className="px-3 py-2.5 font-mono font-bold text-slate-800 dark:text-slate-200">{p.sku}</td>
                    <td className="px-3 py-2.5 font-bold text-slate-900 dark:text-white">{p.name}</td>
                    <td className="px-3 py-2.5 text-slate-500">{p.category}</td>
                    <td className="px-3 py-2.5">{p.unit}</td>
                    <td className="px-3 py-2.5 text-right font-mono font-bold text-slate-900 dark:text-white">
                      {p.sellingPrice.toLocaleString()} đ
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-slate-500">
                      {costVisibility === 'full' ? `${p.costPrice.toLocaleString()} đ` : costVisibility === 'masked' ? '•••••• đ' : '—'}
                    </td>
                    <td className="px-3 py-2.5 text-center font-mono font-bold text-emerald-600">
                      {Math.max(0, Object.values(p.stocks || {}).reduce((a, b) => a + b, 0) - (p.reserved || 0)).toLocaleString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. NHÓM HÀNG */}
      {activeTab === 'categories' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
          <span className="font-bold text-sm text-slate-900 dark:text-white block">Cây Nhóm Hàng Hóa &amp; Dịch Vụ</span>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 border rounded-xl">
            {[
              { code: 'CAT-NET', name: 'Thiết bị mạng & Hạ tầng viễn thông', itemsCount: 18 },
              { code: 'CAT-SRV', name: 'Máy chủ, Tủ rack & Lưu trữ dữ liệu', itemsCount: 12 },
              { code: 'CAT-SEC', name: 'Thiết bị An ninh & Bảo mật Firewall', itemsCount: 8 },
              { code: 'CAT-SOFT', name: 'Phần mềm bản quyền & License', itemsCount: 6 },
              { code: 'CAT-SVC', name: 'Dịch vụ Tư vấn, Lắp đặt & Bảo trì', itemsCount: 5 },
            ].map((cat) => (
              <div key={cat.code} className="p-3 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">{cat.name}</span>
                  <span className="text-[10px] text-slate-400 font-mono">{cat.code}</span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-slate-100 font-semibold">{cat.itemsCount} sản phẩm</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 4. ĐƠN VỊ TÍNH */}
      {activeTab === 'uom' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
          <span className="font-bold text-sm text-slate-900 dark:text-white block">Danh Mục Đơn Vị Tính &amp; Hệ Số Quy Đổi</span>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { code: 'CAI', name: 'Cái / Chiếc', conversion: 'Đơn vị cơ sở' },
              { code: 'BO', name: 'Bộ (Set)', conversion: '1 Bộ = Nhiều chi tiết' },
              { code: 'THUNG', name: 'Thùng (Carton)', conversion: '1 Thùng = 10 Cái' },
              { code: 'GOI', name: 'Gói dịch vụ', conversion: 'Thời hạn theo hợp đồng' },
              { code: 'MET', name: 'Mét dây cáp', conversion: '1 Cuộn = 305 Mét' },
              { code: 'LICENSE', name: 'Bản quyền / Key', conversion: '1 User / 1 Năm' },
            ].map((u) => (
              <div key={u.code} className="p-3 rounded-xl border bg-slate-50 dark:bg-slate-800/40">
                <span className="font-bold text-slate-900 dark:text-white block">{u.name}</span>
                <span className="text-[10px] text-slate-400 font-mono">{u.code}</span>
                <span className="text-[10px] text-emerald-600 block mt-1">{u.conversion}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. KHO HÀNG */}
      {activeTab === 'warehouses' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
          <span className="font-bold text-sm text-slate-900 dark:text-white block">Danh Mục Kho Hàng ({warehouses.length} Kho)</span>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {warehouses.map((wh) => (
              <div key={wh.id} className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">{wh.name}</span>
                  <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-100">{wh.code}</span>
                </div>
                <p className="text-slate-500 text-[11px]">{wh.address}</p>
                <div className="flex justify-between pt-2 border-t text-[11px]">
                  <span className="text-slate-400">Thủ kho phụ trách:</span>
                  <span className="font-bold">{wh.managerName}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">Tính vào tồn khả dụng:</span>
                  <span className={`font-bold ${wh.includeInAvailableStock ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {wh.includeInAvailableStock ? 'Có tính' : 'Không tính (Kho lỗi/BH)'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 6. KHU VỰC ĐỊA LÝ */}
      {activeTab === 'regions' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
          <span className="font-bold text-sm text-slate-900 dark:text-white block">Phân Vùng Giao Hàng &amp; Quản Lý Theo Khu Vực</span>
          <div className="grid grid-cols-3 gap-3">
            {[
              { region: 'Miền Bắc', hubs: 'Hà Nội, Hải Phòng, Quảng Ninh, Bắc Ninh, Thái Nguyên', count: '14 Tỉnh/TP' },
              { region: 'Miền Trung', hubs: 'Đà Nẵng, Huế, Quảng Nam, Khánh Hòa, Nghệ An', count: '11 Tỉnh/TP' },
              { region: 'Miền Nam', hubs: 'TP. Hồ Chí Minh, Bình Dương, Đồng Nai, Cần Thơ, Bà Rịa - Vũng Tàu', count: '19 Tỉnh/TP' },
            ].map((r) => (
              <div key={r.region} className="p-4 rounded-xl border bg-slate-50 dark:bg-slate-800/40 space-y-1">
                <span className="font-bold text-sm text-slate-900 dark:text-white block">{r.region}</span>
                <span className="text-[11px] text-slate-500 block">{r.hubs}</span>
                <span className="text-[10px] text-emerald-600 font-semibold block pt-1">{r.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7. NGÂN HÀNG */}
      {activeTab === 'banks' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
          <span className="font-bold text-sm text-slate-900 dark:text-white block">Danh Mục Ngân Hàng Hoạt Động Tại Việt Nam</span>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
            {banks.map((b) => (
              <div key={b.id} className="p-3 rounded-xl border flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">{b.shortName}</span>
                  <span className="text-[10px] text-slate-400 block line-clamp-1">{b.fullName}</span>
                </div>
                <span className="font-mono font-bold text-blue-600 text-xs">{b.code}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 8. THUẾ SUẤT VAT */}
      {activeTab === 'vat' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
          <span className="font-bold text-sm text-slate-900 dark:text-white block">Danh Mục Thuế Suất VAT &amp; Thuế Suất Mặc Định</span>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 border rounded-xl">
            {vatRates.map((v) => (
              <div key={v.id} className="p-3 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-base text-slate-900 dark:text-white">{v.ratePercent}%</span>
                  <div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200 block">{v.label}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{v.code}</span>
                  </div>
                </div>
                <div>
                  {v.isDefault ? (
                    <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-700 font-bold text-[10px]">
                      Mặc định hệ thống
                    </span>
                  ) : (
                    <button
                      onClick={() => updateVatRate(v.id, { isDefault: true })}
                      className="px-2.5 py-1 rounded border hover:bg-slate-100 text-[10px] font-semibold"
                    >
                      Đặt làm mặc định
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Modal Thêm Nhà Cung Cấp */}
      {isAddSupplierModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 border shadow-xl space-y-4 text-xs">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Thêm Nhà Cung Cấp Mới</h3>
            <form onSubmit={handleAddSupplierSubmit} className="space-y-3">
              <div>
                <label className="font-semibold block mb-1">Mã NCC *</label>
                <input
                  type="text"
                  value={supCode}
                  onChange={(e) => setSupCode(e.target.value)}
                  placeholder="Ví dụ: NCC-HPE"
                  className="w-full px-3 py-2 rounded-xl border font-mono font-bold uppercase"
                  required
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">Tên nhà cung cấp *</label>
                <input
                  type="text"
                  value={supName}
                  onChange={(e) => setSupName(e.target.value)}
                  placeholder="Ví dụ: Công ty Cổ phần Phân Phối HPE Việt Nam"
                  className="w-full px-3 py-2 rounded-xl border"
                  required
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">Mã số thuế *</label>
                <input
                  type="text"
                  value={supTaxCode}
                  onChange={(e) => setSupTaxCode(e.target.value)}
                  placeholder="10 chữ số"
                  className="w-full px-3 py-2 rounded-xl border font-mono"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold block mb-1">Người liên hệ</label>
                  <input type="text" value={supContact} onChange={(e) => setSupContact(e.target.value)} className="w-full px-3 py-1.5 rounded-xl border" />
                </div>
                <div>
                  <label className="font-semibold block mb-1">Số điện thoại</label>
                  <input type="text" value={supPhone} onChange={(e) => setSupPhone(e.target.value)} className="w-full px-3 py-1.5 rounded-xl border font-mono" />
                </div>
              </div>
              <div>
                <label className="font-semibold block mb-1">Điều khoản thanh toán</label>
                <select value={supPaymentTerm} onChange={(e) => setSupPaymentTerm(e.target.value)} className="w-full px-3 py-1.5 rounded-xl border">
                  <option value="Thanh toán ngay">Thanh toán ngay</option>
                  <option value="Công nợ 15 ngày">Công nợ 15 ngày</option>
                  <option value="Công nợ 30 ngày">Công nợ 30 ngày</option>
                  <option value="Công nợ 45 ngày">Công nợ 45 ngày</option>
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsAddSupplierModalOpen(false)} className="px-3 py-1.5 border rounded-xl">Hủy</button>
                <button type="submit" className="px-4 py-2 bg-emerald-600 text-white font-bold rounded-xl">Lưu nhà cung cấp</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
