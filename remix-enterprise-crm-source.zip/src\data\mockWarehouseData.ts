export interface Warehouse {
  id: string;
  code: string;
  name: string;
  address: string;
  manager: string;
  phone: string;
}

export interface WarehouseProduct {
  id: string;
  sku: string;
  barcode: string;
  name: string;
  category: 'Thiết bị công nghệ & IoT' | 'Phần cứng Máy chủ & Mạng' | 'Linh kiện & Phụ kiện' | 'Vật tư tiêu hao' | 'Dược & Hóa phẩm bảo trì';
  unit: string;
  costPrice: number; // Giá vốn bình quân
  sellingPrice: number;
  minSafeStock: number; // Mức tồn tối thiểu
  optimalStock: number; // Mức tồn tối ưu
  supplierName: string;
  trackExpiry: boolean; // Có theo dõi hạn sử dụng
  stocks: Record<string, number>; // warehouseId -> quantity
  reserved: number; // Đang giữ chỗ cho deal/đơn hàng
}

export interface ProductLot {
  id: string;
  lotNumber: string;
  sku: string;
  productName: string;
  warehouseId: string;
  warehouseName: string;
  quantity: number;
  initialQuantity: number;
  manufactureDate: string;
  expiryDate: string;
  unitCost: number;
}

export interface StockInItem {
  sku: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  lotNumber?: string;
  mfgDate?: string;
  expDate?: string;
  shelfLocation?: string;
  total: number;
}

export interface StockInReceipt {
  id: string;
  receiptNumber: string;
  date: string;
  importType: 'Mua hàng từ nhà cung cấp' | 'Khách trả hàng' | 'Nhập từ kho khác' | 'Nhập điều chỉnh kiểm kê';
  warehouseId: string;
  warehouseName: string;
  supplierName: string;
  invoiceNumber: string;
  purchaseOrderId?: string;
  purchaseOrderCode?: string;
  notes: string;
  items: StockInItem[];
  totalQuantity: number;
  totalAmount: number;
  createdBy: string;
  status: 'Nháp' | 'Chờ duyệt' | 'Đã nhập kho' | 'Đã hủy';
  approvedBy?: string;
  approvedAt?: string;
}

export interface StockOutItem {
  sku: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  lotNumber?: string;
  total: number;
}

export interface StockOutReceipt {
  id: string;
  receiptNumber: string;
  date: string;
  exportReason: 'Bán hàng' | 'Xuất nội bộ' | 'Xuất hủy' | 'Trả nhà cung cấp' | 'Chuyển sang kho khác';
  warehouseId: string;
  warehouseName: string;
  customerName?: string;
  dealCode?: string;
  orderId?: string;
  orderCode?: string;
  notes: string;
  items: StockOutItem[];
  totalQuantity: number;
  totalAmount: number;
  createdBy: string;
  status: 'Yêu cầu xuất' | 'Chờ duyệt' | 'Đang soạn hàng' | 'Đã xuất kho' | 'Đã hủy';
  approvedBy?: string;
  approvedAt?: string;
  wasteApprovalReason?: string; // Bắt buộc khi Xuất hủy
}

export interface StockMove {
  id: string;
  timestamp: string;
  date: string;
  type: 'Nhập mua' | 'Khách trả hàng' | 'Xuất bán' | 'Xuất nội bộ' | 'Xuất hủy' | 'Chuyển kho đi' | 'Chuyển kho đến' | 'Điều chỉnh kiểm kê';
  refCode: string;
  sku: string;
  productName: string;
  lotNumber?: string;
  warehouseId: string;
  warehouseName: string;
  quantity: number; // + cho nhập, - cho xuất
  balanceAfter: number;
  unitPrice: number;
  performedBy: string;
  notes: string;
  isAbnormal?: boolean;
  abnormalReason?: string;
}

export interface StockSnapshotDaily {
  date: string;
  warehouseId: string;
  sku: string;
  openingStock: number;
  totalIn: number;
  totalOut: number;
  closingStock: number;
  closingValue: number;
}

export const INITIAL_WAREHOUSES: Warehouse[] = [
  {
    id: 'wh-hn',
    code: 'WH-HN',
    name: 'Kho Tổng Hà Nội',
    address: 'Lô CN-08, KCN Bắc Thăng Long, Đông Anh, Hà Nội',
    manager: 'Nguyễn Văn Định (Thủ kho trưởng)',
    phone: '0912 345 601',
  },
  {
    id: 'wh-dn',
    code: 'WH-DN',
    name: 'Kho Miền Trung Đà Nẵng',
    address: 'Đường số 3, KCN Hòa Khánh, Liên Chiểu, Đà Nẵng',
    manager: 'Trần Minh Hải (Thủ kho Miền Trung)',
    phone: '0905 889 102',
  },
  {
    id: 'wh-hcm',
    code: 'WH-HCM',
    name: 'Kho Tổng TP.HCM',
    address: 'Số 18 Tây Thạnh, KCN Tân Bình, Tân Phú, TP.HCM',
    manager: 'Lê Hoàng Phong (Thủ kho TP.HCM)',
    phone: '0988 776 503',
  },
];

export const INITIAL_WAREHOUSE_PRODUCTS: WarehouseProduct[] = [
  {
    id: 'prod-01',
    sku: 'HW-SRV-DL380',
    barcode: '8936012345011',
    name: 'Máy chủ HPE ProLiant DL380 Gen10 Xeon 4210R',
    category: 'Phần cứng Máy chủ & Mạng',
    unit: 'Chiếc',
    costPrice: 48500000,
    sellingPrice: 58000000,
    minSafeStock: 4,
    optimalStock: 12,
    supplierName: 'HPE Việt Nam (Phân phối FPT)',
    trackExpiry: false,
    stocks: { 'wh-hn': 5, 'wh-dn': 2, 'wh-hcm': 4 },
    reserved: 3,
  },
  {
    id: 'prod-02',
    sku: 'HW-SW-CISCO-9300',
    barcode: '8936012345028',
    name: 'Switch Cisco Catalyst 9300 48-Port Gigabit PoE+',
    category: 'Phần cứng Máy chủ & Mạng',
    unit: 'Chiếc',
    costPrice: 32000000,
    sellingPrice: 38500000,
    minSafeStock: 5,
    optimalStock: 15,
    supplierName: 'Cisco Systems Synnex FPT',
    trackExpiry: false,
    stocks: { 'wh-hn': 8, 'wh-dn': 3, 'wh-hcm': 7 },
    reserved: 4,
  },
  {
    id: 'prod-03',
    sku: 'IOT-GW-5G-IND',
    barcode: '8936012345035',
    name: 'Bộ Gateway IoT Công nghiệp 5G Advantech',
    category: 'Thiết bị công nghệ & IoT',
    unit: 'Bộ',
    costPrice: 14500000,
    sellingPrice: 18200000,
    minSafeStock: 8,
    optimalStock: 25,
    supplierName: 'Advantech Việt Nam',
    trackExpiry: false,
    stocks: { 'wh-hn': 4, 'wh-dn': 1, 'wh-hcm': 2 }, // Dưới mức tối thiểu!
    reserved: 2,
  },
  {
    id: 'prod-04',
    sku: 'RFID-READER-FX9600',
    barcode: '8936012345042',
    name: 'Đầu đọc RFID Cố định Zebra FX9600 4-Cổng',
    category: 'Thiết bị công nghệ & IoT',
    unit: 'Chiếc',
    costPrice: 22000000,
    sellingPrice: 27500000,
    minSafeStock: 6,
    optimalStock: 20,
    supplierName: 'Zebra Technologies Tân Phát',
    trackExpiry: false,
    stocks: { 'wh-hn': 7, 'wh-dn': 4, 'wh-hcm': 9 },
    reserved: 5,
  },
  {
    id: 'prod-05',
    sku: 'MED-GEL-CLEAN-500',
    barcode: '8936012345059',
    name: 'Dung dịch Khử khuẩn Thiết bị Phòng sạch A+ Clean 500ml',
    category: 'Dược & Hóa phẩm bảo trì',
    unit: 'Chai',
    costPrice: 180000,
    sellingPrice: 260000,
    minSafeStock: 50,
    optimalStock: 200,
    supplierName: 'Công ty Hóa chất Dược phẩm Hà Nội',
    trackExpiry: true,
    stocks: { 'wh-hn': 120, 'wh-dn': 40, 'wh-hcm': 90 },
    reserved: 30,
  },
  {
    id: 'prod-06',
    sku: 'MED-ALCOHOL-70-1L',
    barcode: '8936012345066',
    name: 'Cồn Y tế 70 độ Tiệt trùng Bề mặt Vi mạch 1 Lít',
    category: 'Dược & Hóa phẩm bảo trì',
    unit: 'Chai',
    costPrice: 45000,
    sellingPrice: 70000,
    minSafeStock: 80,
    optimalStock: 300,
    supplierName: 'Dược phẩm OPC',
    trackExpiry: true,
    stocks: { 'wh-hn': 25, 'wh-dn': 10, 'wh-hcm': 15 }, // Dưới tối thiểu!
    reserved: 10,
  },
  {
    id: 'prod-07',
    sku: 'CON-LABEL-100X150',
    barcode: '8936012345073',
    name: 'Cuộn Decal nhiệt in mã vạch vận đơn 100x150mm (500 nhãn)',
    category: 'Vật tư tiêu hao',
    unit: 'Cuộn',
    costPrice: 75000,
    sellingPrice: 110000,
    minSafeStock: 100,
    optimalStock: 400,
    supplierName: 'Công ty Bao bì & Tem nhãn Việt Nhật',
    trackExpiry: false,
    stocks: { 'wh-hn': 250, 'wh-dn': 80, 'wh-hcm': 180 },
    reserved: 60,
  },
  {
    id: 'prod-08',
    sku: 'CON-RIBBON-WAX-110',
    barcode: '8936012345080',
    name: 'Ruy băng mực in mã vạch Wax Resin Ricoh 110mm x 300m',
    category: 'Vật tư tiêu hao',
    unit: 'Cuộn',
    costPrice: 95000,
    sellingPrice: 140000,
    minSafeStock: 60,
    optimalStock: 250,
    supplierName: 'Ricoh Việt Nam',
    trackExpiry: false,
    stocks: { 'wh-hn': 90, 'wh-dn': 40, 'wh-hcm': 75 },
    reserved: 20,
  },
  {
    id: 'prod-09',
    sku: 'COMP-SSD-NVME-2TB',
    barcode: '8936012345097',
    name: 'Ổ cứng SSD Enterprise NVMe Samsung PM9A3 1.92TB U.2',
    category: 'Linh kiện & Phụ kiện',
    unit: 'Chiếc',
    costPrice: 5800000,
    sellingPrice: 7200000,
    minSafeStock: 10,
    optimalStock: 35,
    supplierName: 'Samsung Electronics Vina',
    trackExpiry: false,
    stocks: { 'wh-hn': 0, 'wh-dn': 0, 'wh-hcm': 0 }, // Hết hàng!
    reserved: 0,
  },
  {
    id: 'prod-10',
    sku: 'COMP-RAM-ECC-32GB',
    barcode: '8936012345103',
    name: 'Thanh RAM Máy chủ Kingston Server Premier 32GB DDR4 3200MHz ECC',
    category: 'Linh kiện & Phụ kiện',
    unit: 'Thanh',
    costPrice: 2400000,
    sellingPrice: 3100000,
    minSafeStock: 15,
    optimalStock: 50,
    supplierName: 'Kingston Technology Vina',
    trackExpiry: false,
    stocks: { 'wh-hn': 18, 'wh-dn': 8, 'wh-hcm': 14 },
    reserved: 6,
  },
  {
    id: 'prod-11',
    sku: 'CHEM-PASTE-THERMAL',
    barcode: '8936012345110',
    name: 'Keo tản nhiệt CPU công nghiệp Arctic MX-6 Tuýp 20g',
    category: 'Dược & Hóa phẩm bảo trì',
    unit: 'Tuýp',
    costPrice: 210000,
    sellingPrice: 320000,
    minSafeStock: 20,
    optimalStock: 80,
    supplierName: 'Arctic Cooling Asia',
    trackExpiry: true,
    stocks: { 'wh-hn': 45, 'wh-dn': 15, 'wh-hcm': 30 },
    reserved: 12,
  },
  {
    id: 'prod-12',
    sku: 'CON-CABLE-CAT6A-305M',
    barcode: '8936012345127',
    name: 'Thùng Dây cáp mạng CommScope AMP Cat6A U/UTP 305 mét',
    category: 'Vật tư tiêu hao',
    unit: 'Thùng',
    costPrice: 3450000,
    sellingPrice: 4200000,
    minSafeStock: 12,
    optimalStock: 40,
    supplierName: 'CommScope Việt Nam',
    trackExpiry: false,
    stocks: { 'wh-hn': 14, 'wh-dn': 6, 'wh-hcm': 11 },
    reserved: 4,
  },
];

export const INITIAL_PRODUCT_LOTS: ProductLot[] = [
  // Hết hạn (Đỏ đậm)
  {
    id: 'lot-01',
    lotNumber: 'LOT-EXP-2026-08',
    sku: 'MED-GEL-CLEAN-500',
    productName: 'Dung dịch Khử khuẩn Thiết bị Phòng sạch A+ Clean 500ml',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    quantity: 15,
    initialQuantity: 100,
    manufactureDate: '2024-09-01',
    expiryDate: '2026-09-01', // Đã hết hạn!
    unitCost: 180000,
  },
  // Hết hạn trong <= 30 ngày (Đỏ)
  {
    id: 'lot-02',
    lotNumber: 'LOT-EXP-2026-10',
    sku: 'MED-ALCOHOL-70-1L',
    productName: 'Cồn Y tế 70 độ Tiệt trùng Bề mặt Vi mạch 1 Lít',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    quantity: 25,
    initialQuantity: 150,
    manufactureDate: '2025-10-25',
    expiryDate: '2026-10-25', // Còn 21 ngày!
    unitCost: 45000,
  },
  // Hết hạn trong <= 60 ngày (Cam)
  {
    id: 'lot-03',
    lotNumber: 'LOT-EXP-2026-11',
    sku: 'CHEM-PASTE-THERMAL',
    productName: 'Keo tản nhiệt CPU công nghiệp Arctic MX-6 Tuýp 20g',
    warehouseId: 'wh-hcm',
    warehouseName: 'Kho Tổng TP.HCM',
    quantity: 30,
    initialQuantity: 80,
    manufactureDate: '2024-11-18',
    expiryDate: '2026-11-18', // Còn ~45 ngày!
    unitCost: 210000,
  },
  // Hết hạn trong <= 90 ngày (Vàng)
  {
    id: 'lot-04',
    lotNumber: 'LOT-EXP-2026-12',
    sku: 'MED-GEL-CLEAN-500',
    productName: 'Dung dịch Khử khuẩn Thiết bị Phòng sạch A+ Clean 500ml',
    warehouseId: 'wh-hcm',
    warehouseName: 'Kho Tổng TP.HCM',
    quantity: 45,
    initialQuantity: 120,
    manufactureDate: '2024-12-20',
    expiryDate: '2026-12-20', // Còn ~77 ngày!
    unitCost: 180000,
  },
  // Hạn còn dài an toàn (> 180 ngày)
  {
    id: 'lot-05',
    lotNumber: 'LOT-SAFE-2027-06',
    sku: 'MED-GEL-CLEAN-500',
    productName: 'Dung dịch Khử khuẩn Thiết bị Phòng sạch A+ Clean 500ml',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    quantity: 60,
    initialQuantity: 150,
    manufactureDate: '2025-06-10',
    expiryDate: '2027-06-10',
    unitCost: 180000,
  },
  {
    id: 'lot-06',
    lotNumber: 'LOT-SAFE-2027-09',
    sku: 'MED-ALCOHOL-70-1L',
    productName: 'Cồn Y tế 70 độ Tiệt trùng Bề mặt Vi mạch 1 Lít',
    warehouseId: 'wh-dn',
    warehouseName: 'Kho Miền Trung Đà Nẵng',
    quantity: 10,
    initialQuantity: 50,
    manufactureDate: '2025-09-01',
    expiryDate: '2027-09-01',
    unitCost: 45000,
  },
];

export const INITIAL_STOCK_IN_RECEIPTS: StockInReceipt[] = [
  {
    id: 'pnk-01',
    receiptNumber: 'PNK-2026-1001',
    date: '2026-10-02',
    importType: 'Mua hàng từ nhà cung cấp',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    supplierName: 'HPE Việt Nam (Phân phối FPT)',
    invoiceNumber: 'HD-FPT-88901',
    notes: 'Nhập máy chủ phục vụ dự án số hóa Hoàng Anh Gia Lai',
    items: [
      { sku: 'HW-SRV-DL380', productName: 'Máy chủ HPE ProLiant DL380 Gen10', quantity: 4, unitPrice: 48500000, lotNumber: 'LOT-SRV-2610A', total: 194000000 },
      { sku: 'COMP-RAM-ECC-32GB', productName: 'Thanh RAM Máy chủ Kingston 32GB', quantity: 16, unitPrice: 2400000, total: 38400000 },
    ],
    totalQuantity: 20,
    totalAmount: 232400000,
    createdBy: 'Nguyễn Văn Định (Thủ kho Hà Nội)',
    status: 'Đã nhập kho',
    approvedBy: 'Trần Văn Giám Đốc Kho',
    approvedAt: '2026-10-02 14:30',
  },
  {
    id: 'pnk-02',
    receiptNumber: 'PNK-2026-1002',
    date: '2026-10-03',
    importType: 'Mua hàng từ nhà cung cấp',
    warehouseId: 'wh-hcm',
    warehouseName: 'Kho Tổng TP.HCM',
    supplierName: 'Công ty Bao bì & Tem nhãn Việt Nhật',
    invoiceNumber: 'HD-VJ-55421',
    notes: 'Bổ sung vật tư tem nhãn mã vạch dự trữ Q4',
    items: [
      { sku: 'CON-LABEL-100X150', productName: 'Cuộn Decal nhiệt in mã vạch vận đơn 100x150mm', quantity: 100, unitPrice: 75000, total: 7500000 },
      { sku: 'CON-RIBBON-WAX-110', productName: 'Ruy băng mực in mã vạch Wax Resin 110mm', quantity: 50, unitPrice: 95000, total: 4750000 },
    ],
    totalQuantity: 150,
    totalAmount: 12250000,
    createdBy: 'Lê Hoàng Phong (Thủ kho TP.HCM)',
    status: 'Đã nhập kho',
    approvedBy: 'Trần Văn Giám Đốc Kho',
    approvedAt: '2026-10-03 10:15',
  },
  {
    id: 'pnk-03',
    receiptNumber: 'PNK-2026-1003',
    date: '2026-10-04',
    importType: 'Nhập điều chỉnh kiểm kê',
    warehouseId: 'wh-dn',
    warehouseName: 'Kho Miền Trung Đà Nẵng',
    supplierName: 'Nội bộ công ty A+',
    invoiceNumber: 'BB-KK-2026-DN',
    notes: 'Điều chỉnh số lượng dôi dư sau đợt kiểm kê đột xuất đầu tháng 10',
    items: [
      { sku: 'CON-CABLE-CAT6A-305M', productName: 'Thùng Dây cáp mạng CommScope Cat6A', quantity: 2, unitPrice: 3450000, total: 6900000 },
    ],
    totalQuantity: 2,
    totalAmount: 6900000,
    createdBy: 'Trần Minh Hải (Thủ kho Đà Nẵng)',
    status: 'Chờ duyệt',
  },
];

export const INITIAL_STOCK_OUT_RECEIPTS: StockOutReceipt[] = [
  {
    id: 'pxk-01',
    receiptNumber: 'PXK-2026-1001',
    date: '2026-10-02',
    exportReason: 'Bán hàng',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    customerName: 'Tập đoàn Hoàng Anh Gia Lai',
    dealCode: 'DEAL-WON-2026-001',
    notes: 'Xuất giao thiết bị máy chủ đợt 1 hợp đồng số HAGL-A+-2026',
    items: [
      { sku: 'HW-SRV-DL380', productName: 'Máy chủ HPE ProLiant DL380 Gen10', quantity: 2, unitPrice: 58000000, lotNumber: 'LOT-SRV-2610A', total: 116000000 },
      { sku: 'HW-SW-CISCO-9300', productName: 'Switch Cisco Catalyst 9300 48-Port', quantity: 2, unitPrice: 38500000, total: 77000000 },
    ],
    totalQuantity: 4,
    totalAmount: 193000000,
    createdBy: 'Nguyễn Văn Định (Thủ kho Hà Nội)',
    status: 'Đã xuất kho',
    approvedBy: 'Trần Văn Giám Đốc Kho',
    approvedAt: '2026-10-02 16:45',
  },
  {
    id: 'pxk-02',
    receiptNumber: 'PXK-2026-1002',
    date: '2026-10-03',
    exportReason: 'Xuất hủy',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    notes: 'Xuất tiêu hủy hóa chất phòng sạch đã hết hạn sử dụng',
    wasteApprovalReason: 'Lô hóa chất LOT-EXP-2026-08 hết hạn vào 01/09/2026, đã có biên bản nghiệm thu hủy của Hội đồng thẩm định',
    items: [
      { sku: 'MED-GEL-CLEAN-500', productName: 'Dung dịch Khử khuẩn Thiết bị Phòng sạch A+ Clean', quantity: 15, unitPrice: 180000, lotNumber: 'LOT-EXP-2026-08', total: 2700000 },
    ],
    totalQuantity: 15,
    totalAmount: 2700000,
    createdBy: 'Nguyễn Văn Định (Thủ kho Hà Nội)',
    status: 'Đã xuất kho',
    approvedBy: 'Trần Văn Giám Đốc Kho',
    approvedAt: '2026-10-03 15:00',
  },
  {
    id: 'pxk-03',
    receiptNumber: 'PXK-2026-1003',
    date: '2026-10-04',
    exportReason: 'Bán hàng',
    warehouseId: 'wh-hcm',
    warehouseName: 'Kho Tổng TP.HCM',
    customerName: 'Công ty CP May Sông Hồng',
    dealCode: 'DEAL-WON-2026-002',
    notes: 'Xuất thiết bị đầu đọc mã vạch và vật tư nhãn phục vụ kiểm kê',
    items: [
      { sku: 'RFID-READER-FX9600', productName: 'Đầu đọc RFID Cố định Zebra FX9600', quantity: 2, unitPrice: 27500000, total: 55000000 },
      { sku: 'CON-LABEL-100X150', productName: 'Cuộn Decal nhiệt in mã vạch vận đơn', quantity: 20, unitPrice: 110000, total: 2200000 },
    ],
    totalQuantity: 22,
    totalAmount: 57200000,
    createdBy: 'Lê Hoàng Phong (Thủ kho TP.HCM)',
    status: 'Đang soạn hàng',
  },
];

export const INITIAL_STOCK_MOVES: StockMove[] = [
  {
    id: 'mv-01',
    timestamp: '2026-10-04 09:15',
    date: '2026-10-04',
    type: 'Xuất bán',
    refCode: 'PXK-2026-1001',
    sku: 'HW-SRV-DL380',
    productName: 'Máy chủ HPE ProLiant DL380 Gen10 Xeon 4210R',
    lotNumber: 'LOT-SRV-2610A',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    quantity: -2,
    balanceAfter: 5,
    unitPrice: 48500000,
    performedBy: 'Nguyễn Văn Định',
    notes: 'Giao dự án Hoàng Anh Gia Lai đợt 1',
  },
  {
    id: 'mv-02',
    timestamp: '2026-10-04 09:20',
    date: '2026-10-04',
    type: 'Xuất bán',
    refCode: 'PXK-2026-1001',
    sku: 'HW-SW-CISCO-9300',
    productName: 'Switch Cisco Catalyst 9300 48-Port Gigabit PoE+',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    quantity: -2,
    balanceAfter: 8,
    unitPrice: 32000000,
    performedBy: 'Nguyễn Văn Định',
    notes: 'Giao kèm cụm máy chủ server',
  },
  {
    id: 'mv-03',
    timestamp: '2026-10-03 14:10',
    date: '2026-10-03',
    type: 'Xuất hủy',
    refCode: 'PXK-2026-1002',
    sku: 'MED-GEL-CLEAN-500',
    productName: 'Dung dịch Khử khuẩn Thiết bị Phòng sạch A+ Clean 500ml',
    lotNumber: 'LOT-EXP-2026-08',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    quantity: -15,
    balanceAfter: 120,
    unitPrice: 180000,
    performedBy: 'Nguyễn Văn Định',
    notes: 'Hủy lô quá hạn sử dụng theo biên bản kiểm kê',
    isAbnormal: true,
    abnormalReason: 'Giao dịch xuất hủy do quá hạn sử dụng',
  },
  {
    id: 'mv-04',
    timestamp: '2026-10-03 10:30',
    date: '2026-10-03',
    type: 'Nhập mua',
    refCode: 'PNK-2026-1002',
    sku: 'CON-LABEL-100X150',
    productName: 'Cuộn Decal nhiệt in mã vạch vận đơn 100x150mm',
    warehouseId: 'wh-hcm',
    warehouseName: 'Kho Tổng TP.HCM',
    quantity: 100,
    balanceAfter: 180,
    unitPrice: 75000,
    performedBy: 'Lê Hoàng Phong',
    notes: 'Nhập bổ sung từ Việt Nhật',
  },
  {
    id: 'mv-05',
    timestamp: '2026-10-02 15:45',
    date: '2026-10-02',
    type: 'Nhập mua',
    refCode: 'PNK-2026-1001',
    sku: 'HW-SRV-DL380',
    productName: 'Máy chủ HPE ProLiant DL380 Gen10 Xeon 4210R',
    lotNumber: 'LOT-SRV-2610A',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    quantity: 4,
    balanceAfter: 7,
    unitPrice: 48500000,
    performedBy: 'Nguyễn Văn Định',
    notes: 'Nhập từ FPT Synnex',
  },
  {
    id: 'mv-06',
    timestamp: '2026-10-01 22:30', // Ngoài giờ làm việc!
    date: '2026-10-01',
    type: 'Điều chỉnh kiểm kê',
    refCode: 'DC-2026-0929',
    sku: 'COMP-SSD-NVME-2TB',
    productName: 'Ổ cứng SSD Enterprise NVMe Samsung PM9A3 1.92TB U.2',
    warehouseId: 'wh-hn',
    warehouseName: 'Kho Tổng Hà Nội',
    quantity: -12,
    balanceAfter: 0,
    unitPrice: 5800000,
    performedBy: 'Hệ thống tự động',
    notes: 'Điều chỉnh hao hụt kiểm kê cuối tháng 9',
    isAbnormal: true,
    abnormalReason: 'Giao dịch điều chỉnh số lượng lớn thực hiện ngoài giờ làm việc (22:30)',
  },
];
