import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSettings } from '../../context/SettingsContext';
import { useHR } from '../../context/HRContext';
import { SystemUser } from '../../types/settings';
import {
  Users,
  Search,
  Filter,
  Plus,
  ShieldCheck,
  Lock,
  Unlock,
  KeyRound,
  Mail,
  Smartphone,
  Laptop,
  CheckCircle2,
  AlertTriangle,
  X,
  ExternalLink,
  RefreshCw,
  LogOut,
  Send,
  UserCheck,
  Building,
} from 'lucide-react';

export const SettingsUsersView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    users,
    permissionGroups,
    createUserFromEmployee,
    bulkCreateUsersFromEmployees,
    updateUser,
    toggleUserLock,
    sendPasswordResetInvite,
    terminateAllSessions,
    canAccessSettings,
  } = useSettings();
  const { employees } = useHR();

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Detail Drawer
  const [selectedUser, setSelectedUser] = useState<SystemUser | null>(null);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isBulkModalOpen, setIsBulkModalOpen] = useState(false);

  // Add single user form state
  const [selectedEmpId, setSelectedEmpId] = useState('');
  const [selectedRoleIds, setSelectedRoleIds] = useState<string[]>(['grp-employee']);

  // Bulk create selection
  const [bulkSelectedEmpIds, setBulkSelectedEmpIds] = useState<string[]>([]);
  const [bulkDefaultRoleIds, setBulkDefaultRoleIds] = useState<string[]>(['grp-employee']);

  // Danh sách nhân viên chưa có tài khoản
  const existingEmpIds = useMemo(() => new Set(users.map((u) => u.employeeId).filter(Boolean)), [users]);
  const employeesWithoutAccount = useMemo(() => {
    return employees.filter((e) => !existingEmpIds.has(e.id) && e.status !== 'Đã nghỉ việc');
  }, [employees, existingEmpIds]);

  // Filtered users
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      if (roleFilter !== 'all' && !u.roleIds.includes(roleFilter)) return false;
      if (statusFilter !== 'all' && u.status !== statusFilter) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return (
          u.fullName.toLowerCase().includes(q) ||
          u.email.toLowerCase().includes(q) ||
          u.username.toLowerCase().includes(q) ||
          u.departmentName.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [users, roleFilter, statusFilter, searchTerm]);

  // Stats
  const stats = useMemo(() => {
    return {
      total: users.length,
      active: users.filter((u) => u.status === 'active').length,
      pending: users.filter((u) => u.status === 'pending').length,
      locked: users.filter((u) => u.status === 'locked').length,
      admins: users.filter((u) => u.isSystemAdmin).length,
    };
  }, [users]);

  // Access Denied Banner
  if (!canAccessSettings) {
    return (
      <div className="bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 rounded-2xl p-6 text-center max-w-xl mx-auto my-12">
        <AlertTriangle className="w-12 h-12 text-rose-600 dark:text-rose-400 mx-auto mb-3" />
        <h2 className="text-lg font-bold text-rose-900 dark:text-rose-200">Truy cập bị từ chối</h2>
        <p className="text-xs text-rose-700 dark:text-rose-300 mt-1">
          Chỉ vai trò <strong>Quản trị hệ thống (System Admin)</strong> hoặc <strong>Ban Giám Đốc</strong> mới có quyền truy cập module Cài đặt hệ thống.
        </p>
      </div>
    );
  }

  const handleCreateSingle = (e: React.FormEvent) => {
    e.preventDefault();
    const emp = employees.find((e) => e.id === selectedEmpId);
    if (!emp) {
      showToast('Lỗi', 'Vui lòng chọn nhân viên để tạo tài khoản.', 'warning');
      return;
    }
    createUserFromEmployee(
      {
        id: emp.id,
        fullName: emp.fullName,
        email: emp.email,
        phone: emp.phone,
        departmentName: emp.departmentName,
        positionName: emp.positionName,
        avatar: emp.avatar,
      },
      selectedRoleIds
    );
    setIsAddModalOpen(false);
    setSelectedEmpId('');
  };

  const handleBulkCreate = () => {
    const emps = employees.filter((e) => bulkSelectedEmpIds.includes(e.id));
    if (emps.length === 0) {
      showToast('Lỗi', 'Vui lòng chọn ít nhất 1 nhân viên.', 'warning');
      return;
    }
    bulkCreateUsersFromEmployees(
      emps.map((e) => ({
        id: e.id,
        fullName: e.fullName,
        email: e.email,
        phone: e.phone,
        departmentName: e.departmentName,
        positionName: e.positionName,
        avatar: e.avatar,
      })),
      bulkDefaultRoleIds
    );
    setIsBulkModalOpen(false);
    setBulkSelectedEmpIds([]);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
            <Users className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              Quản Lý Người Dùng &amp; Tài Khoản
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-300 font-bold font-mono">
                {users.length} Tài khoản
              </span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Gắn kết 1-1 với hồ sơ Nhân sự. Phân quyền truy cập, theo dõi phiên hoạt động và lịch sử đăng nhập bảo mật.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => {
              setBulkSelectedEmpIds(employeesWithoutAccount.map((e) => e.id));
              setIsBulkModalOpen(true);
            }}
            disabled={employeesWithoutAccount.length === 0}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
            title="Tạo nhanh tài khoản cho các nhân sự chưa có thông tin đăng nhập"
          >
            <UserCheck className="w-3.5 h-3.5 text-sky-600" />
            <span>Tạo hàng loạt từ Nhân sự ({employeesWithoutAccount.length})</span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm Người Dùng</span>
          </button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] text-slate-400 block font-medium">Tổng người dùng</span>
          <span className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-0.5 block">{stats.total}</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-emerald-200 dark:border-emerald-900/60 shadow-xs bg-emerald-50/20">
          <span className="text-[11px] text-emerald-600 dark:text-emerald-400 block font-medium">Đang hoạt động</span>
          <span className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-0.5 block">{stats.active}</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-amber-200 dark:border-amber-900/60 shadow-xs bg-amber-50/20">
          <span className="text-[11px] text-amber-600 dark:text-amber-400 block font-medium">Chờ kích hoạt</span>
          <span className="text-xl font-bold font-mono text-amber-600 dark:text-amber-400 mt-0.5 block">{stats.pending}</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-rose-200 dark:border-rose-900/60 shadow-xs bg-rose-50/20">
          <span className="text-[11px] text-rose-600 dark:text-rose-400 block font-medium">Bị khóa tài khoản</span>
          <span className="text-xl font-bold font-mono text-rose-600 dark:text-rose-400 mt-0.5 block">{stats.locked}</span>
        </div>
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-purple-200 dark:border-purple-900/60 shadow-xs bg-purple-50/20">
          <span className="text-[11px] text-purple-600 dark:text-purple-400 block font-medium">Quản trị viên (Admin)</span>
          <span className="text-xl font-bold font-mono text-purple-600 dark:text-purple-400 mt-0.5 block">{stats.admins}</span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo Tên, Email, Tên đăng nhập, Phòng ban..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-sky-500"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300"
          >
            <option value="all">Tất cả nhóm quyền</option>
            {permissionGroups.map((g) => (
              <option key={g.id} value={g.id}>{g.name}</option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300"
          >
            <option value="all">Tất cả trạng thái</option>
            <option value="active">Đang hoạt động</option>
            <option value="pending">Chưa kích hoạt</option>
            <option value="locked">Bị khóa</option>
          </select>
        </div>
      </div>

      {/* Users Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800">
              <tr>
                <th className="px-4 py-3">Người dùng</th>
                <th className="px-4 py-3">Phòng ban &amp; Chức vụ</th>
                <th className="px-4 py-3">Nhóm quyền hạn</th>
                <th className="px-4 py-3">Đăng nhập gần nhất</th>
                <th className="px-4 py-3">Trạng thái</th>
                <th className="px-4 py-3 text-right">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-300">
              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-slate-400">
                    Không tìm thấy người dùng nào phù hợp điều kiện lọc.
                  </td>
                </tr>
              ) : (
                filteredUsers.map((u) => {
                  const assignedGroups = permissionGroups.filter((g) => u.roleIds.includes(g.id));
                  return (
                    <tr
                      key={u.id}
                      onClick={() => setSelectedUser(u)}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={u.avatar}
                            alt={u.fullName}
                            className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                          />
                          <div>
                            <span className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                              {u.fullName}
                              {u.isSystemAdmin && (
                                <span className="p-0.5 rounded bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300" title="Quản trị viên">
                                  <ShieldCheck className="w-3 h-3" />
                                </span>
                              )}
                            </span>
                            <span className="text-[11px] text-slate-400 block font-mono">{u.email}</span>
                          </div>
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <span className="font-medium text-slate-900 dark:text-white block">{u.departmentName}</span>
                        <span className="text-[11px] text-slate-400 block">{u.positionName}</span>
                      </td>

                      <td className="px-4 py-3">
                        <div className="flex items-center gap-1 flex-wrap">
                          {assignedGroups.map((g) => (
                            <span
                              key={g.id}
                              className={`px-2 py-0.5 rounded-md text-[10px] font-semibold ${
                                g.code === 'ADMIN'
                                  ? 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300 border border-purple-200 dark:border-purple-800'
                                  : g.code === 'DIRECTOR'
                                  ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                                  : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                              }`}
                            >
                              {g.name.split(' (')[0]}
                            </span>
                          ))}
                        </div>
                      </td>

                      <td className="px-4 py-3">
                        <span className="font-mono text-slate-600 dark:text-slate-400 text-[11px]">
                          {u.lastLogin || 'Chưa đăng nhập'}
                        </span>
                        {u.activeSessions && u.activeSessions.length > 0 && (
                          <span className="text-[10px] text-emerald-600 font-semibold block">
                            &bull; {u.activeSessions.length} phiên đang mở
                          </span>
                        )}
                      </td>

                      <td className="px-4 py-3">
                        {u.status === 'active' && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 flex items-center gap-1 w-fit">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            Hoạt động
                          </span>
                        )}
                        {u.status === 'pending' && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 flex items-center gap-1 w-fit">
                            Chờ kích hoạt
                          </span>
                        )}
                        {u.status === 'locked' && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 flex items-center gap-1 w-fit">
                            <Lock className="w-2.5 h-2.5" /> Bị khóa
                          </span>
                        )}
                      </td>

                      <td className="px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => toggleUserLock(u.id)}
                            className={`p-1.5 rounded-lg border transition-colors ${
                              u.status === 'locked'
                                ? 'border-emerald-300 text-emerald-600 hover:bg-emerald-50'
                                : 'border-rose-200 text-rose-600 hover:bg-rose-50'
                            }`}
                            title={u.status === 'locked' ? 'Mở khóa tài khoản' : 'Khóa tài khoản'}
                          >
                            {u.status === 'locked' ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                          </button>

                          <button
                            onClick={() => sendPasswordResetInvite(u.id)}
                            className="p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100"
                            title="Gửi liên kết đặt lại mật khẩu"
                          >
                            <KeyRound className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drawer Chi tiết Người dùng */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex justify-end">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-200">
            {/* Header */}
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <img
                  src={selectedUser.avatar}
                  alt={selectedUser.fullName}
                  className="w-10 h-10 rounded-full object-cover border"
                />
                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                    {selectedUser.fullName}
                    {selectedUser.isSystemAdmin && (
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-100 text-purple-700 font-bold">
                        Admin
                      </span>
                    )}
                  </h3>
                  <span className="text-xs text-slate-400 font-mono">{selectedUser.email}</span>
                </div>
              </div>
              <button
                onClick={() => setSelectedUser(null)}
                className="p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto p-4 space-y-5 text-xs">
              {/* Thao tác tài khoản */}
              <div className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <span className="font-bold text-slate-700 dark:text-slate-300 block">Hành động bảo mật</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => toggleUserLock(selectedUser.id)}
                    className={`px-3 py-2 rounded-lg font-semibold flex items-center justify-center gap-1.5 border ${
                      selectedUser.status === 'locked'
                        ? 'border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                        : 'border-rose-300 text-rose-700 bg-rose-50 hover:bg-rose-100'
                    }`}
                  >
                    {selectedUser.status === 'locked' ? (
                      <>
                        <Unlock className="w-3.5 h-3.5" />
                        <span>Mở Khóa Tài Khoản</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-3.5 h-3.5" />
                        <span>Khóa Tài Khoản</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => sendPasswordResetInvite(selectedUser.id)}
                    className="px-3 py-2 rounded-lg font-semibold border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 flex items-center justify-center gap-1.5"
                  >
                    <KeyRound className="w-3.5 h-3.5 text-sky-600" />
                    <span>Đặt lại mật khẩu</span>
                  </button>
                </div>
              </div>

              {/* Thông tin nhân sự đồng bộ */}
              <div className="space-y-2">
                <span className="font-bold text-slate-900 dark:text-white block">Hồ sơ Nhân sự liên kết</span>
                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Phòng ban:</span>
                    <span className="font-semibold text-slate-900 dark:text-white">{selectedUser.departmentName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Chức vụ:</span>
                    <span className="font-semibold text-slate-900 dark:text-white">{selectedUser.positionName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Số điện thoại:</span>
                    <span className="font-mono text-slate-900 dark:text-white">{selectedUser.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Ngày tạo tài khoản:</span>
                    <span className="font-mono text-slate-900 dark:text-white">{selectedUser.createdAt}</span>
                  </div>
                </div>
              </div>

              {/* Nhóm quyền gán */}
              <div className="space-y-2">
                <span className="font-bold text-slate-900 dark:text-white block">Nhóm quyền được gán</span>
                <div className="space-y-1.5">
                  {permissionGroups.map((g) => {
                    const isChecked = selectedUser.roleIds.includes(g.id);
                    return (
                      <label
                        key={g.id}
                        className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                          isChecked
                            ? 'bg-sky-50/50 border-sky-300 dark:bg-sky-950/20 dark:border-sky-800'
                            : 'border-slate-200 dark:border-slate-800'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={(e) => {
                              const newRoles = e.target.checked
                                ? [...selectedUser.roleIds, g.id]
                                : selectedUser.roleIds.filter((rid) => rid !== g.id);
                              updateUser(selectedUser.id, { roleIds: newRoles });
                              setSelectedUser((prev) => prev ? { ...prev, roleIds: newRoles } : null);
                            }}
                            className="rounded text-sky-600 focus:ring-sky-500"
                          />
                          <div>
                            <span className="font-semibold text-slate-900 dark:text-white block">{g.name}</span>
                            <span className="text-[10px] text-slate-400 block">{g.description}</span>
                          </div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Phiên đăng nhập đang hoạt động */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900 dark:text-white">Phiên đăng nhập đang hoạt động</span>
                  {selectedUser.activeSessions && selectedUser.activeSessions.length > 0 && (
                    <button
                      onClick={() => terminateAllSessions(selectedUser.id)}
                      className="text-rose-600 hover:text-rose-700 text-[11px] font-semibold flex items-center gap-1"
                    >
                      <LogOut className="w-3 h-3" />
                      <span>Đăng xuất mọi thiết bị</span>
                    </button>
                  )}
                </div>

                <div className="space-y-1.5">
                  {(!selectedUser.activeSessions || selectedUser.activeSessions.length === 0) ? (
                    <p className="text-slate-400 italic py-2">Hiện không có phiên đăng nhập nào.</p>
                  ) : (
                    selectedUser.activeSessions.map((s) => (
                      <div key={s.id} className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Laptop className="w-4 h-4 text-slate-400" />
                          <div>
                            <span className="font-semibold text-slate-900 dark:text-white block">
                              {s.device} ({s.browser})
                              {s.isCurrent && <span className="ml-1 text-[9px] px-1 rounded bg-emerald-100 text-emerald-700 font-bold">Hiện tại</span>}
                            </span>
                            <span className="text-[10px] text-slate-400 font-mono">IP: {s.ipAddress} &bull; {s.loginTime}</span>
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Lịch sử đăng nhập */}
              <div className="space-y-2">
                <span className="font-bold text-slate-900 dark:text-white block">Lịch sử đăng nhập gần đây</span>
                <div className="space-y-1">
                  {(!selectedUser.loginHistories || selectedUser.loginHistories.length === 0) ? (
                    <p className="text-slate-400 italic py-2">Chưa ghi nhận lịch sử đăng nhập.</p>
                  ) : (
                    selectedUser.loginHistories.map((lh) => (
                      <div key={lh.id} className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/40 flex items-center justify-between font-mono text-[11px]">
                        <div>
                          <span>{lh.device} &bull; {lh.browser}</span>
                          <span className="text-slate-400 block text-[10px]">{lh.timestamp} ({lh.ipAddress})</span>
                        </div>
                        <span className={`font-bold ${lh.status === 'SUCCESS' ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {lh.status === 'SUCCESS' ? 'Thành công' : 'Thất bại'}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Thêm người dùng từ Nhân viên */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-sky-600" />
                <span>Thêm Người Dùng Mới</span>
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSingle} className="space-y-4 text-xs">
              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Chọn nhân viên từ Hồ sơ Nhân sự <span className="text-rose-500">*</span>
                </label>
                <select
                  value={selectedEmpId}
                  onChange={(e) => setSelectedEmpId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  required
                >
                  <option value="">-- Chọn nhân sự chưa có tài khoản ({employeesWithoutAccount.length}) --</option>
                  {employeesWithoutAccount.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.fullName} ({e.code}) - {e.departmentName} ({e.positionName})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-1">
                  Dữ liệu Tên, Email, SĐT và Phòng ban được lấy trực tiếp từ Quản lý nhân sự, không cần nhập lại.
                </p>
              </div>

              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Nhóm quyền truy cập
                </label>
                <div className="max-h-40 overflow-y-auto space-y-1.5 p-2 rounded-xl border border-slate-200 dark:border-slate-800">
                  {permissionGroups.map((g) => (
                    <label key={g.id} className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedRoleIds.includes(g.id)}
                        onChange={(e) => {
                          setSelectedRoleIds((prev) =>
                            e.target.checked ? [...prev, g.id] : prev.filter((id) => id !== g.id)
                          );
                        }}
                        className="rounded text-sky-600 focus:ring-sky-500"
                      />
                      <span className="font-medium text-slate-800 dark:text-slate-200">{g.name}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="p-3 bg-sky-50 dark:bg-sky-950/30 rounded-xl text-sky-800 dark:text-sky-300 text-[11px] leading-relaxed">
                Hệ thống sẽ tự động gửi email chứa liên kết tự đặt mật khẩu lần đầu tới địa chỉ email của nhân viên. Quản trị viên không cần khởi tạo mật khẩu thủ công.
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={!selectedEmpId}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold disabled:opacity-50"
                >
                  Tạo tài khoản &amp; Gửi lời mời
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Tạo hàng loạt */}
      {isBulkModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-xl w-full p-5 border border-slate-200 dark:border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-sky-600" />
                <span>Tạo Hàng Loạt Tài Khoản Từ Nhân Sự</span>
              </h3>
              <button onClick={() => setIsBulkModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <p className="text-slate-500">
                Chọn các nhân viên chưa có tài khoản đăng nhập để kích hoạt tài khoản hàng loạt:
              </p>

              <div className="max-h-60 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 border rounded-xl">
                {employeesWithoutAccount.map((e) => {
                  const isChecked = bulkSelectedEmpIds.includes(e.id);
                  return (
                    <label key={e.id} className="p-2.5 flex items-center gap-3 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={(ev) => {
                          setBulkSelectedEmpIds((prev) =>
                            ev.target.checked ? [...prev, e.id] : prev.filter((id) => id !== e.id)
                          );
                        }}
                        className="rounded text-sky-600"
                      />
                      <div className="flex-1">
                        <span className="font-bold text-slate-900 dark:text-white block">{e.fullName} ({e.code})</span>
                        <span className="text-[10px] text-slate-400">{e.email} &bull; {e.departmentName} - {e.positionName}</span>
                      </div>
                    </label>
                  );
                })}
              </div>

              <div className="flex items-center justify-between pt-2">
                <span className="font-semibold text-slate-700 dark:text-slate-300">
                  Đã chọn: <strong className="text-sky-600">{bulkSelectedEmpIds.length}</strong> / {employeesWithoutAccount.length} nhân sự
                </span>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsBulkModalOpen(false)}
                    className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-600"
                  >
                    Hủy
                  </button>
                  <button
                    type="button"
                    onClick={handleBulkCreate}
                    disabled={bulkSelectedEmpIds.length === 0}
                    className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold disabled:opacity-50"
                  >
                    Kích hoạt {bulkSelectedEmpIds.length} tài khoản
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
