import React, { useState } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import {
  Building2,
  Lock,
  Mail,
  User,
  Phone,
  Eye,
  EyeOff,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  Users,
  TrendingUp,
  Settings2,
  ShieldCheck,
  Sparkles,
  UserPlus,
} from 'lucide-react';

export const JoinCompanyView: React.FC = () => {
  const {
    requestJoinCompany,
    setAuthScreenMode,
    allCompanies,
  } = useMultiTenant();

  const [companyCode, setCompanyCode] = useState('');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!companyCode.trim()) {
      setErrorMessage('Vui lòng nhập mã công ty bạn muốn tham gia.');
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Mật khẩu phải chứa ít nhất 6 ký tự.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('Mật khẩu và xác nhận mật khẩu không trùng khớp.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await requestJoinCompany({
        companyCode: companyCode.toUpperCase().trim(),
        fullName,
        email,
        phone,
        password,
      });

      if (res.success) {
        setIsSuccess(true);
      } else {
        setErrorMessage(res.error || 'Không thể gửi yêu cầu tham gia công ty.');
      }
    } catch (err: any) {
      setErrorMessage('Đã xảy ra lỗi hệ thống khi gửi yêu cầu.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-white text-[#172033] flex flex-col lg:flex-row">
      {/* ========================================================= */}
      {/* CỘT TRÁI: HERO SHOWCASE (CHUẨN TEMPLATE THIẾT KẾ)         */}
      {/* ========================================================= */}
      <div className="w-full lg:w-[56%] xl:w-[58%] bg-[#F4F8FD] p-6 sm:p-10 lg:p-14 flex flex-col justify-between relative overflow-hidden border-b lg:border-b-0 lg:border-r border-slate-200/80">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-300/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 right-0 w-[500px] h-[500px] bg-sky-200/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col h-full justify-between gap-6">
          {/* Header Thương Hiệu */}
          <div className="flex items-center gap-3">
            <img
              src="/logo-aplus-transparent.png"
              alt="A+ Enterprise Logo"
              className="w-11 h-11 object-contain drop-shadow-sm select-none"
            />
            <div>
              <div className="text-[19px] font-black tracking-tight text-[#002659] leading-tight font-sans">
                A+ Enterprise CRM
              </div>
              <div className="text-[12px] font-semibold text-[#475467] leading-tight mt-0.5">
                Quản trị thông minh – Tăng trưởng bền vững
              </div>
            </div>
          </div>

          {/* Tiêu Đề Chính & Giới Thiệu */}
          <div className="mt-2 lg:mt-4">
            <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-black tracking-tight text-[#002659] leading-[1.15]">
              Gia nhập đội ngũ<br />
              <span className="text-[#2563EB]">Đồng hành bứt phá</span>
            </h1>
            <p className="mt-3.5 text-[14px] sm:text-[14.5px] text-[#475467] leading-relaxed max-w-xl font-medium">
              Kết nối ngay vào không gian làm việc của công ty bạn để nhận phân quyền, quản lý khách hàng và phối hợp công việc thông suốt.
            </p>

            {/* 4 Feature Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 mt-6">
              {[
                { icon: Users, label: 'Quản lý khách hàng' },
                { icon: TrendingUp, label: 'Tối ưu kinh doanh' },
                { icon: Settings2, label: 'Tự động hóa quy trình' },
                { icon: ShieldCheck, label: 'Bảo mật dữ liệu' },
              ].map((feat, idx) => {
                const IconComponent = feat.icon;
                return (
                  <div
                    key={idx}
                    className="bg-white/95 backdrop-blur-xs border border-blue-100/90 rounded-xl p-3 shadow-2xs hover:shadow-xs transition-all flex flex-col items-center text-center gap-2 group hover:-translate-y-0.5"
                  >
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2563EB] flex items-center justify-center transition-colors group-hover:bg-[#2563EB] group-hover:text-white">
                      <IconComponent className="w-4.5 h-4.5" />
                    </div>
                    <span className="text-[12px] font-bold text-[#1E293B] leading-tight">
                      {feat.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 3D Mockup */}
          <div className="relative mt-2 sm:mt-4 flex flex-col items-center">
            <div className="relative w-full max-w-[560px] rounded-2xl overflow-hidden shadow-xl border border-white/60 bg-white/40 backdrop-blur-xs">
              <img
                src="/crm-login-hero.jpg"
                alt="A+ Enterprise CRM Showcase"
                className="w-full h-auto object-cover select-none"
              />
              <div className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 bg-white/95 backdrop-blur-md shadow-lg rounded-full px-4 py-2 border border-blue-100 flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <UserPlus className="w-3.5 h-3.5" />
                </div>
                <span className="text-[12.5px] font-bold text-[#002659]">
                  Kết nối đồng đội dễ dàng
                </span>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-2 text-center text-[#2563EB]">
              <Sparkles className="w-4 h-4 text-blue-500 shrink-0" />
              <span className="text-[15px] sm:text-[16px] font-semibold italic tracking-wide">
                Cùng doanh nghiệp Việt vươn xa hơn
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* CỘT PHẢI: FORM THAM GIA CÔNG TY                          */}
      {/* ========================================================= */}
      <div className="w-full lg:w-[44%] xl:w-[42%] bg-white p-6 sm:p-10 lg:p-14 flex flex-col justify-between">
        <div className="flex items-center justify-end">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-50 border border-slate-200/80 text-[12px] font-bold text-[#2563EB] tracking-wide">
            <span>A+ Enterprise</span>
            <span className="text-slate-300">—</span>
            <span className="text-slate-500 font-medium">Tham Gia</span>
          </div>
        </div>

        <div className="w-full max-w-[420px] mx-auto my-auto py-4">
          <div className="text-center mb-6">
            <img
              src="/logo-aplus-transparent.png"
              alt="A+ Enterprise Logo"
              className="w-16 h-16 object-contain mx-auto mb-3 drop-shadow-sm select-none"
            />
            <h2 className="text-[25px] sm:text-[27px] font-black tracking-tight text-[#002659] leading-tight">
              Tham Gia Doanh Nghiệp
            </h2>
            <p className="mt-1 text-[13.5px] text-[#667085] font-medium">
              Gửi yêu cầu tham gia vào tổ chức doanh nghiệp của bạn
            </p>
          </div>

          {/* Thông báo thành công */}
          {isSuccess ? (
            <div className="p-5 rounded-2xl bg-emerald-50 border border-emerald-200 text-center space-y-3 animate-in fade-in">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h3 className="text-base font-bold text-emerald-900">
                Đã gửi yêu cầu tham gia thành công!
              </h3>
              <p className="text-xs text-emerald-700 leading-relaxed">
                Yêu cầu của bạn đã được chuyển tới Ban Quản Trị của công ty <strong className="font-mono uppercase">{companyCode}</strong>. Sau khi được duyệt, bạn sẽ có thể đăng nhập bằng tài khoản và mật khẩu đã tạo.
              </p>
              <button
                type="button"
                onClick={() => setAuthScreenMode('LOGIN')}
                className="w-full h-11 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm shadow-sm transition-colors cursor-pointer"
              >
                Trở về trang Đăng nhập
              </button>
            </div>
          ) : (
            <>
              {errorMessage && (
                <div className="mb-4 p-3 rounded-xl bg-[#FDF2E9] border border-[#E96F22] text-[#E96F22] text-[13px] flex items-center gap-2.5 animate-in fade-in">
                  <AlertTriangle className="w-4 h-4 text-[#E96F22] shrink-0" />
                  <span className="font-medium text-xs sm:text-[13px]">{errorMessage}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-3.5">
                {/* 1. Mã công ty */}
                <div>
                  <div className="relative">
                    <Building2 className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={companyCode}
                      onChange={(e) => setCompanyCode(e.target.value.toUpperCase().trim())}
                      placeholder="Mã công ty cần tham gia (VD: APLUS)"
                      required
                      className="w-full pl-10 pr-3 h-12 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14.5px] uppercase font-mono focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all"
                    />
                  </div>
                  {allCompanies.length > 0 && (
                    <div className="mt-1 flex items-center gap-1.5 text-[11px] text-slate-500 overflow-x-auto py-0.5">
                      <span className="shrink-0">Gợi ý mã:</span>
                      {allCompanies.slice(0, 3).map((c) => (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => setCompanyCode(c.code)}
                          className="font-mono text-blue-600 font-bold hover:underline cursor-pointer"
                        >
                          {c.code}
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                {/* 2. Họ và tên */}
                <div>
                  <div className="relative">
                    <User className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Họ và tên của bạn *"
                      required
                      className="w-full pl-10 pr-3 h-12 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14.5px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all"
                    />
                  </div>
                </div>

                {/* 3. Email */}
                <div>
                  <div className="relative">
                    <Mail className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Email làm việc *"
                      required
                      className="w-full pl-10 pr-3 h-12 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14.5px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all"
                    />
                  </div>
                </div>

                {/* 4. Số điện thoại */}
                <div>
                  <div className="relative">
                    <Phone className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="Số điện thoại di động"
                      className="w-full pl-10 pr-3 h-12 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14.5px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all"
                    />
                  </div>
                </div>

                {/* 5. Mật khẩu */}
                <div>
                  <div className="relative">
                    <Lock className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Mật khẩu đăng nhập (ít nhất 6 ký tự) *"
                      required
                      className="w-full pl-10 pr-10 h-12 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14.5px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#98A2B3] hover:text-[#172033] p-1 cursor-pointer transition-colors"
                    >
                      {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                    </button>
                  </div>
                </div>

                {/* 6. Xác nhận mật khẩu */}
                <div>
                  <div className="relative">
                    <Lock className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Xác nhận lại mật khẩu *"
                      required
                      className="w-full pl-10 pr-3 h-12 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14.5px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all font-mono"
                    />
                  </div>
                </div>

                {/* Nút Submit */}
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full h-12 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white font-bold text-[15px] shadow-md hover:shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed mt-2 cursor-pointer"
                >
                  {isLoading ? (
                    <span>Đang gửi yêu cầu...</span>
                  ) : (
                    <>
                      <span>Gửi yêu cầu tham gia</span>
                      <ArrowRight className="w-4.5 h-4.5" />
                    </>
                  )}
                </button>
              </form>
            </>
          )}

          {/* Navigation Links */}
          <div className="mt-6 pt-4 border-t border-slate-100 space-y-2 text-center text-[13px] text-[#667085]">
            <div>
              Đã có tài khoản?{' '}
              <button
                type="button"
                onClick={() => setAuthScreenMode('LOGIN')}
                className="font-bold text-[#2563EB] hover:underline cursor-pointer"
              >
                Đăng nhập ngay
              </button>
            </div>
            <div>
              Chưa có công ty?{' '}
              <button
                type="button"
                onClick={() => setAuthScreenMode('REGISTER')}
                className="font-bold text-[#002659] hover:underline cursor-pointer"
              >
                Đăng ký doanh nghiệp mới
              </button>
              <span className="mx-2 text-slate-300">•</span>
              <button
                type="button"
                onClick={() => setAuthScreenMode('ACCEPT_INVITE')}
                className="text-slate-600 hover:text-blue-600 font-semibold cursor-pointer"
              >
                Có mã lời mời?
              </button>
            </div>
          </div>
        </div>

        {/* Footer Bản Quyền */}
        <div className="text-center text-[12px] text-slate-400 mt-4">
          © 2026 A+ Enterprise. All rights reserved.
        </div>
      </div>
    </div>
  );
};
