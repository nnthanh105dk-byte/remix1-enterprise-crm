import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { SalesInvoice } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import {
  Receipt,
  Search,
  AlertTriangle,
  Clock,
  DollarSign,
  Mail,
  Send,
  Building,
  CheckCircle2,
  X,
  CreditCard,
  Banknote,
  FileCode,
  ExternalLink,
} from 'lucide-react';
import { useColumnVisibility, ColumnDef } from '../../hooks/useColumnVisibility';
import { ColumnVisibilityPicker } from '../../components/common/ColumnVisibilityPicker';

const INVOICE_COLUMNS: ColumnDef[] = [
  { id: 'code', label: 'Số Hóa Đơn', required: true },
  { id: 'customer', label: 'Khách Hàng / Hợp Đồng' },
  { id: 'dates', label: 'Ngày Lập / Hạn TT' },
  { id: 'total', label: 'Tổng Tiền' },
  { id: 'paid', label: 'Đã Thu' },
  { id: 'remaining', label: 'Còn Nợ' },
  { id: 'status', label: 'Trạng Thái' },
  { id: 'actions', label: 'Thao Tác' },
];

export const SalesInvoicesView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const {
    invoices,
    sendInvoicePaymentReminder,
    createReceiptFromInvoice,
  } = useSales();

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const {
    columns: colDefs,
    visibleColumns,
    isVisible,
    toggleColumn,
    selectAll,
    resetToDefault,
  } = useColumnVisibility('sales_invoices', INVOICE_COLUMNS);

  // Selected Invoice for Drawer
  const [selectedInvoice, setSelectedInvoice] = useState<SalesInvoice | null>(null);

  // Payment Recording Modal
  const [isReceiptModalOpen, setIsReceiptModalOpen] = useState(false);
  const [receiptAmount, setReceiptAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<'Chuyển khoản' | 'Tiền mặt' | 'Khác'>('Chuyển khoản');
  const [bankRef, setBankRef] = useState('');
  const [receiptReason, setReceiptReason] = useState('');
  const [payerName, setPayerName] = useState('');

  // Calculate 3 Top KPI Cards
  const totalUnpaid = invoices
    .filter((i) => i.status !== 'Đã thanh toán' && i.status !== 'Hủy')
    .reduce((sum, i) => sum + i.remainingAmount, 0);

  const overdueInvoices = invoices.filter((i) => {
    if (i.status === 'Đã thanh toán' || i.status === 'Hủy') return false;
    const dueTime = new Date(i.dueDate).getTime();
    return !isNaN(dueTime) && dueTime < Date.now();
  });
  const totalOverdue = overdueInvoices.reduce((sum, i) => sum + i.remainingAmount, 0);

  const dueIn7Days = invoices.filter((i) => {
    if (i.status === 'Đã thanh toán' || i.status === 'Hủy') return false;
    const dueTime = new Date(i.dueDate).getTime();
    if (isNaN(dueTime)) return false;
    const diffDays = (dueTime - Date.now()) / (1000 * 60 * 60 * 24);
    return diffDays >= 0 && diffDays <= 7;
  });

  const filteredInvoices = invoices.filter((inv) => {
    if (statusFilter !== 'all' && inv.status !== statusFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        inv.invoiceNumber.toLowerCase().includes(q) ||
        inv.customerName.toLowerCase().includes(q) ||
        (inv.contractCode && inv.contractCode.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const openPaymentModal = (inv: SalesInvoice) => {
    setSelectedInvoice(inv);
    setReceiptAmount(inv.remainingAmount);
    setPayerName(inv.customerName);
    setReceiptReason(`Thanh toán hóa đơn ${inv.invoiceNumber} theo ${inv.milestoneTitle || 'hợp đồng'}`);
    setBankRef(`FT2627${Math.floor(100000 + Math.random() * 900000)}`);
    setIsReceiptModalOpen(true);
  };

  const handleRecordPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedInvoice) return;
    try {
      createReceiptFromInvoice(
        selectedInvoice.id,
        receiptAmount,
        paymentMethod,
        bankRef,
        receiptReason,
        payerName
      );
      setIsReceiptModalOpen(false);
      setActiveModule('sales-receipts');
    } catch (err: any) {
      showToast('Lỗi thu tiền', err.message, 'warning');
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
                <Receipt className="w-5 h-5" />
              </span>
              Hóa Đơn &amp; Quản Lý Công Nợ (Sales Invoices)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {invoices.length} Hóa đơn
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Theo dõi hóa đơn GTGT phát hành, quản lý dư nợ tự động theo phiếu thu và đối soát thông tin hóa đơn điện tử.
          </p>
        </div>
      </div>

      {/* 3 Thẻ Thống Kê Đầu Trang (Tổng chưa thu, Quá hạn, Sắp đến hạn 7 ngày) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200">
          <span className="text-[14.5px] font-bold text-slate-800 dark:text-slate-100 tracking-tight">Tổng tiền chưa thu (Công nợ)</span>
          <h3 className="text-2xl sm:text-[28px] font-black font-mono text-sky-600 dark:text-sky-400 mt-1.5 leading-none tabular-nums">
            {(totalUnpaid / 1000000).toFixed(1)} Tr ₫
          </h3>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-rose-200/90 dark:border-rose-900/60 rounded-xl p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200">
          <span className="text-[14.5px] font-bold text-rose-700 dark:text-rose-400 tracking-tight">Nợ quá hạn thanh toán</span>
          <h3 className="text-2xl sm:text-[28px] font-black font-mono text-rose-600 dark:text-rose-400 mt-1.5 leading-none tabular-nums">
            {(totalOverdue / 1000000).toFixed(1)} Tr ₫
          </h3>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-amber-200/90 dark:border-amber-900/60 rounded-xl p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200">
          <span className="text-[14.5px] font-bold text-amber-700 dark:text-amber-400 tracking-tight">Sắp đến hạn trong 7 ngày</span>
          <h3 className="text-2xl sm:text-[28px] font-black font-mono text-amber-600 dark:text-amber-400 mt-1.5 leading-none tabular-nums">
            {dueIn7Days.length} Hóa đơn
          </h3>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo số hóa đơn (HDON-...), khách hàng, HĐ..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2">
          <ColumnVisibilityPicker
            columns={colDefs}
            visibleColumns={visibleColumns}
            onToggle={toggleColumn}
            onSelectAll={selectAll}
            onReset={resetToDefault}
          />

          <span className="text-slate-500 font-medium">Trạng thái:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
          >
            <option value="all">Tất cả trạng thái</option>
            <option value="Chưa thanh toán">Chưa thanh toán</option>
            <option value="Thanh toán một phần">Thanh toán một phần</option>
            <option value="Đã thanh toán">Đã thanh toán</option>
            <option value="Quá hạn">Quá hạn</option>
          </select>
        </div>
      </div>

      {/* Main Invoices Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="px-5 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="section-title">
            Danh sách Hóa đơn
          </h2>
          <span className="text-[13px] text-slate-500">
            Hiển thị <strong className="text-slate-800 dark:text-slate-200">{filteredInvoices.length}</strong> hóa đơn
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800 uppercase text-[11px]">
              <tr>
                {isVisible('code') && <th className="py-3 px-3">Số Hóa Đơn</th>}
                {isVisible('customer') && <th className="py-3 px-3">Khách Hàng / Hợp Đồng</th>}
                {isVisible('dates') && <th className="py-3 px-3">Ngày Lập / Hạn TT</th>}
                {isVisible('total') && <th className="py-3 px-3 text-right">Tổng Tiền</th>}
                {isVisible('paid') && <th className="py-3 px-3 text-right">Đã Thu</th>}
                {isVisible('remaining') && <th className="py-3 px-3 text-right">Còn Nợ</th>}
                {isVisible('status') && <th className="py-3 px-3">Trạng Thái</th>}
                {isVisible('actions') && <th className="py-3 px-3 text-right">Thao Tác</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={colDefs.filter(c => isVisible(c.id)).length || 1} className="py-8 text-center text-slate-400">
                    Không tìm thấy hóa đơn nào phù hợp.
                  </td>
                </tr>
              ) : (
                filteredInvoices.map((inv) => {
                  const isOverdue = inv.status === 'Quá hạn' || (inv.remainingAmount > 0 && new Date(inv.dueDate).getTime() < Date.now());

                  return (
                    <tr
                      key={inv.id}
                      onClick={() => setSelectedInvoice(inv)}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                    >
                      {isVisible('code') && (
                        <td className="py-3 px-3">
                          <span className="font-mono font-bold text-sky-600 dark:text-sky-400 block">
                            {inv.invoiceNumber}
                          </span>
                          {inv.einvoiceNumber && (
                            <span className="text-[10px] text-slate-400 font-mono">
                              HĐĐT: {inv.einvoiceNumber}
                            </span>
                          )}
                        </td>
                      )}

                      {isVisible('customer') && (
                        <td className="py-3 px-3">
                          <div className="font-bold text-slate-900 dark:text-white line-clamp-1">
                            {inv.customerName}
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5">
                            {inv.contractCode || 'Đơn hàng trực tiếp'} • {inv.milestoneTitle || 'Toàn phần'}
                          </div>
                        </td>
                      )}

                      {isVisible('dates') && (
                        <td className="py-3 px-3 font-mono text-[11px]">
                          <div>{inv.issueDate}</div>
                          <div className={`${isOverdue ? 'text-rose-600 font-bold' : 'text-slate-400'}`}>
                            Hạn: {inv.dueDate}
                          </div>
                        </td>
                      )}

                      {isVisible('total') && (
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                          {inv.totalAmount.toLocaleString()} ₫
                        </td>
                      )}

                      {isVisible('paid') && (
                        <td className="py-3 px-3 text-right font-mono font-semibold text-emerald-600">
                          {inv.paidAmount.toLocaleString()} ₫
                        </td>
                      )}

                      {isVisible('remaining') && (
                        <td className="py-3 px-3 text-right font-mono font-bold text-rose-600">
                          {inv.remainingAmount.toLocaleString()} ₫
                        </td>
                      )}

                      {isVisible('status') && (
                        <td className="py-3 px-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              inv.status === 'Đã thanh toán'
                                ? 'bg-emerald-100 text-emerald-800'
                                : inv.status === 'Quá hạn'
                                ? 'bg-rose-100 text-rose-800'
                                : inv.status === 'Thanh toán một phần'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-sky-100 text-sky-800'
                            }`}
                          >
                            {inv.status}
                          </span>
                        </td>
                      )}

                      {isVisible('actions') && (
                        <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            {inv.remainingAmount > 0 ? (
                              <button
                                onClick={() => openPaymentModal(inv)}
                                className="px-2.5 py-1 rounded bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700 shadow-xs flex items-center gap-1"
                              >
                                <Banknote className="w-3.5 h-3.5" />
                                <span>Thu Tiền</span>
                              </button>
                            ) : (
                              <span className="text-[11px] text-emerald-600 font-bold flex items-center gap-0.5">
                                <CheckCircle2 className="w-3.5 h-3.5" /> Đã thu đủ
                              </span>
                            )}
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Right Drawer: Chi Tiết Hóa Đơn */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 h-full overflow-y-auto flex flex-col p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs px-2.5 py-1 rounded bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-bold">
                  {selectedInvoice.invoiceNumber}
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-semibold">
                  {selectedInvoice.status}
                </span>
              </div>
              <button onClick={() => setSelectedInvoice(null)} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Chain Bar */}
            <div className="mt-4">
              <DocumentChainBar currentType="invoice" chain={selectedInvoice.chain} />
            </div>

            <div className="mt-5 space-y-4 text-xs">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  {selectedInvoice.customerName}
                </h2>
                <p className="text-slate-500 font-medium">HĐ gốc: {selectedInvoice.contractCode || 'Đơn hàng trực tiếp'}</p>
              </div>

              {/* Thông tin nợ & thu */}
              <div className="grid grid-cols-3 gap-2.5 bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800 font-mono">
                <div>
                  <span className="text-slate-400 block text-[10px] font-sans">Tổng tiền HĐ:</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {selectedInvoice.totalAmount.toLocaleString()} ₫
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-sans">Đã thu:</span>
                  <span className="font-bold text-emerald-600">
                    {selectedInvoice.paidAmount.toLocaleString()} ₫
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-sans">Còn nợ:</span>
                  <span className="font-bold text-rose-600">
                    {selectedInvoice.remainingAmount.toLocaleString()} ₫
                  </span>
                </div>
              </div>

              {/* Chỗ lưu hóa đơn điện tử ngoài */}
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2">
                <span className="font-bold text-slate-700 dark:text-slate-300 block text-[11px] flex items-center gap-1.5">
                  <FileCode className="w-3.5 h-3.5 text-indigo-500" />
                  Thông Tin Hóa Đơn Điện Tử Đã Phát Hành (Phần mềm ngoài):
                </span>
                <div className="grid grid-cols-2 gap-2 text-slate-600 dark:text-slate-300">
                  <div>Số HĐĐT: <strong>{selectedInvoice.einvoiceNumber || 'Chưa cập nhật'}</strong></div>
                  <div>Ký hiệu: <strong>{selectedInvoice.einvoiceSymbol || '1C26TBB'}</strong></div>
                  <div>Ngày phát hành: <strong>{selectedInvoice.einvoiceIssuedDate || selectedInvoice.issueDate}</strong></div>
                  <div>Bản thể hiện: <span className="text-sky-600 underline cursor-pointer">Tải PDF HĐĐT</span></div>
                </div>
              </div>

              {/* Nút Hành Động Xuyên Suốt: Nhắc Nợ & Ghi Nhận Thanh Toán */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
                {selectedInvoice.remainingAmount > 0 && (
                  <div className="space-y-2">
                    <button
                      onClick={() => openPaymentModal(selectedInvoice)}
                      className="w-full py-2.5 rounded-xl bg-emerald-600 text-white font-bold flex items-center justify-center gap-2 hover:bg-emerald-700 shadow-md text-xs"
                    >
                      <Banknote className="w-4 h-4" />
                      <span>Ghi Nhận Thanh Toán (Lập Phiếu Thu) →</span>
                    </button>

                    <button
                      onClick={() => sendInvoicePaymentReminder(selectedInvoice.id)}
                      className="w-full py-2 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold flex items-center justify-center gap-2 hover:bg-slate-100 text-xs"
                    >
                      <Mail className="w-3.5 h-3.5 text-sky-600" />
                      <span>Gửi Email Nhắc Thanh Toán Khách Hàng</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Ghi Nhận Thanh Toán (Tạo Phiếu Thu PT-2026-xxxx) */}
      {isReceiptModalOpen && selectedInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <Banknote className="w-5 h-5 text-emerald-600" />
                Lập Phiếu Thu Tiền
              </h3>
              <button onClick={() => setIsReceiptModalOpen(false)} className="text-slate-400 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleRecordPaymentSubmit} className="space-y-3.5 mt-4">
              <div className="p-3 rounded-lg bg-sky-50 dark:bg-sky-950/40 text-sky-800 dark:text-sky-300">
                Hóa đơn: <strong>{selectedInvoice.invoiceNumber}</strong> • Số nợ còn: <strong>{selectedInvoice.remainingAmount.toLocaleString()} ₫</strong>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Số tiền thực thu (VNĐ) *</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={selectedInvoice.remainingAmount}
                  value={receiptAmount}
                  onChange={(e) => setReceiptAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Hình thức thanh toán</label>
                  <select
                    value={paymentMethod}
                    onChange={(e) => setPaymentMethod(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="Chuyển khoản">Chuyển khoản</option>
                    <option value="Tiền mặt">Tiền mặt</option>
                    <option value="Khác">Khác</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Mã GD / Tham chiếu NH</label>
                  <input
                    type="text"
                    value={bankRef}
                    onChange={(e) => setBankRef(e.target.value)}
                    placeholder="Mã tham chiếu ngân hàng..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Họ tên người nộp tiền *</label>
                <input
                  type="text"
                  required
                  value={payerName}
                  onChange={(e) => setPayerName(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Lý do nộp tiền</label>
                <input
                  type="text"
                  value={receiptReason}
                  onChange={(e) => setReceiptReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsReceiptModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-600 text-white font-bold"
                >
                  Xác Nhận &amp; In Phiếu Thu
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
