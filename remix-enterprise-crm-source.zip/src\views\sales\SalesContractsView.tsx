import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useTechnical } from '../../context/TechnicalContext';
import { SalesContract } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import {
  FileCheck2,
  FileText,
  Plus,
  Search,
  Calendar,
  Clock,
  Building,
  DollarSign,
  Download,
  Receipt,
  RotateCw,
  AlertTriangle,
  Paperclip,
  CheckCircle2,
  X,
  Printer,
  ChevronRight,
  Wrench,
} from 'lucide-react';
import { useColumnVisibility, ColumnDef } from '../../hooks/useColumnVisibility';
import { ColumnVisibilityPicker } from '../../components/common/ColumnVisibilityPicker';

const CONTRACT_COLUMNS: ColumnDef[] = [
  { id: 'code', label: 'Số Hợp Đồng', required: true },
  { id: 'title', label: 'Tiêu Đề / Khách Hàng' },
  { id: 'total', label: 'Giá Trị HĐ' },
  { id: 'dates', label: 'Hiệu Lực / Hết Hạn' },
  { id: 'milestones', label: 'Tiến Độ Thu' },
  { id: 'status', label: 'Trạng Thái' },
  { id: 'actions', label: 'Thao Tác' },
];

export const SalesContractsView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const {
    contracts,
    updateContractStatus,
    createInvoiceFromMilestone,
  } = useSales();
  const { acceptContractForDeployment } = useTechnical();

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const {
    columns: colDefs,
    visibleColumns,
    isVisible,
    toggleColumn,
    selectAll,
    resetToDefault,
  } = useColumnVisibility('sales_contracts', CONTRACT_COLUMNS);

  // Selected Contract for Detail Drawer
  const [selectedContract, setSelectedContract] = useState<SalesContract | null>(null);

  // Template Preview Modal
  const [isTemplateModalOpen, setIsTemplateModalOpen] = useState(false);

  // Filtered
  const filteredContracts = contracts.filter((c) => {
    if (statusFilter !== 'all' && c.status !== statusFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        c.contractNumber.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        c.customerName.toLowerCase().includes(q) ||
        (c.orderCode && c.orderCode.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleCreateInvoice = (contractId: string, milestoneId: string) => {
    const inv = createInvoiceFromMilestone(contractId, milestoneId);
    if (selectedContract?.id === contractId) {
      setSelectedContract((prev) =>
        prev
          ? {
              ...prev,
              paymentMilestones: prev.paymentMilestones.map((m) =>
                m.id === milestoneId ? { ...m, invoiceCode: inv.invoiceNumber } : m
              ),
            }
          : null
      );
    }
    setActiveModule('sales-invoices');
  };

  const handleRenewContract = (c: SalesContract) => {
    showToast(
      'Gia hạn hợp đồng',
      `Đã tạo bản dự thảo gia hạn hợp đồng kế thừa thông tin từ ${c.contractNumber}.`,
      'success'
    );
  };

  // Helper check if contract is approaching expiry (within 60 days)
  const isApproachingExpiry = (endDateStr: string) => {
    const end = new Date(endDateStr).getTime();
    if (isNaN(end)) return false;
    const diffDays = (end - Date.now()) / (1000 * 60 * 60 * 24);
    return diffDays > 0 && diffDays <= 60;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
                <FileCheck2 className="w-5 h-5" />
              </span>
              Hợp Đồng Kinh Tế (Contracts)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {contracts.length} Hợp đồng
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Kế thừa từ Đơn hàng đã duyệt, tự động điền mẫu hợp đồng thông minh, quản lý các đợt thanh toán và kích hoạt xuất hóa đơn.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setActiveModule('sales-orders')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Tạo Hợp Đồng Từ Đơn Hàng</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo số HĐ (HD-...), tên khách hàng, đơn hàng..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">Trạng thái:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="Đang hiệu lực">Đang hiệu lực</option>
              <option value="Chờ ký">Chờ ký</option>
              <option value="Hoàn thành">Hoàn thành</option>
              <option value="Hết hạn">Hết hạn</option>
              <option value="Hủy">Hủy</option>
            </select>
          </div>

          <ColumnVisibilityPicker
            columns={colDefs}
            visibleColumns={visibleColumns}
            onToggleColumn={toggleColumn}
            onSelectAll={selectAll}
            onReset={resetToDefault}
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="px-5 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="section-title">
            Danh sách Hợp đồng
          </h2>
          <span className="text-[13px] text-slate-500">
            Hiển thị <strong className="text-slate-800 dark:text-slate-200">{filteredContracts.length}</strong> hợp đồng
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800 uppercase text-[11px]">
              <tr>
                {isVisible('code') && <th className="py-3 px-3">Số Hợp Đồng</th>}
                {isVisible('title') && <th className="py-3 px-3">Tiêu Đề / Khách Hàng</th>}
                {isVisible('total') && <th className="py-3 px-3 text-right">Giá Trị HĐ</th>}
                {isVisible('dates') && <th className="py-3 px-3">Hiệu Lực / Hết Hạn</th>}
                {isVisible('milestones') && <th className="py-3 px-3">Tiến Độ Thu</th>}
                {isVisible('status') && <th className="py-3 px-3">Trạng Thái</th>}
                {isVisible('actions') && <th className="py-3 px-3 text-right">Thao Tác</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredContracts.length === 0 ? (
                <tr>
                  <td
                    colSpan={colDefs.filter((c) => isVisible(c.id)).length || 1}
                    className="py-8 text-center text-slate-400"
                  >
                    Không tìm thấy hợp đồng nào phù hợp với bộ lọc.
                  </td>
                </tr>
              ) : (
                filteredContracts.map((cont) => {
                  const isExpiring = isApproachingExpiry(cont.endDate);
                  const paidMilestones = cont.paymentMilestones.filter((m) => m.isPaid).length;

                  return (
                    <tr
                      key={cont.id}
                      onClick={() => setSelectedContract(cont)}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                    >
                      {isVisible('code') && (
                        <td className="py-3 px-3">
                          <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400 block">
                            {cont.contractNumber}
                          </span>
                          {cont.orderCode && (
                            <span className="text-[10px] text-slate-400 font-mono">
                              Từ đơn: {cont.orderCode}
                            </span>
                          )}
                        </td>
                      )}

                      {isVisible('title') && (
                        <td className="py-3 px-3">
                          <div className="font-bold text-slate-900 dark:text-white line-clamp-1">
                            {cont.title}
                          </div>
                          <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                            <Building className="w-3 h-3 text-slate-400" />
                            <span>{cont.customerName}</span>
                          </div>
                        </td>
                      )}

                      {isVisible('total') && (
                        <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                          {cont.totalValue.toLocaleString()} ₫
                        </td>
                      )}

                      {isVisible('dates') && (
                        <td className="py-3 px-3 font-mono text-[11px]">
                          <div>Từ: {cont.startDate}</div>
                          <div className={`${isExpiring ? 'text-amber-600 font-bold' : 'text-slate-400'}`}>
                            Đến: {cont.endDate}
                            {isExpiring && ' (Cận hạn)'}
                          </div>
                        </td>
                      )}

                      {isVisible('milestones') && (
                        <td className="py-3 px-3">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                            {paidMilestones}/{cont.paymentMilestones.length} đợt
                          </span>
                        </td>
                      )}

                      {isVisible('status') && (
                        <td className="py-3 px-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              cont.status === 'Đang hiệu lực'
                                ? 'bg-emerald-100 text-emerald-800'
                                : cont.status === 'Hoàn thành'
                                ? 'bg-sky-100 text-sky-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {cont.status}
                          </span>
                        </td>
                      )}

                      {isVisible('actions') && (
                        <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => {
                                acceptContractForDeployment(cont.id, 'Trần Văn Nam (Kỹ sư Trưởng)');
                                setActiveModule('technical-contracts');
                              }}
                              title="Bàn giao sang bộ phận Kỹ thuật thi công"
                              className="px-2.5 py-1 rounded bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 font-semibold hover:bg-amber-100 text-xs cursor-pointer flex items-center gap-1 border border-amber-200 dark:border-amber-800/40"
                            >
                              <Wrench className="w-3 h-3 text-amber-600" />
                              <span>Chuyển KT →</span>
                            </button>
                            <button
                              onClick={() => setSelectedContract(cont)}
                              className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-200 text-xs cursor-pointer"
                            >
                              Chi tiết &amp; Đợt thu
                            </button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Right Drawer: Chi Tiết Hợp Đồng & Kích Hoạt Xuất Hóa Đơn Từng Đợt */}
      {selectedContract && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 h-full overflow-y-auto flex flex-col p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs px-2.5 py-1 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold">
                  {selectedContract.contractNumber}
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-semibold">
                  {selectedContract.status}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsTemplateModalOpen(true)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold flex items-center gap-1.5 hover:bg-slate-100"
                >
                  <FileText className="w-3.5 h-3.5" /> Xem Mẫu HĐ (Template)
                </button>
                <button onClick={() => setSelectedContract(null)} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Chain Bar */}
            <div className="mt-4">
              <DocumentChainBar currentType="contract" chain={selectedContract.chain} />
            </div>

            {/* Content */}
            <div className="mt-5 space-y-4 text-xs">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  {selectedContract.title}
                </h2>
                <p className="text-slate-500 font-medium">Bên B: {selectedContract.customerName}</p>
              </div>

              {/* Thông tin chính */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-slate-400 block text-[11px]">Tổng giá trị hợp đồng:</span>
                  <span className="text-base font-bold font-mono text-indigo-600 dark:text-indigo-400">
                    {selectedContract.totalValue.toLocaleString()} ₫
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Người quản trị HĐ:</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {selectedContract.manager}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Ngày bắt đầu hiệu lực:</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono">
                    {selectedContract.startDate}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Ngày hết hạn:</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono">
                    {selectedContract.endDate}
                  </span>
                </div>
              </div>

              {/* Điểm nối Kỹ thuật: Chuyển Kỹ thuật triển khai */}
              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200 dark:border-amber-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div>
                  <span className="font-bold text-amber-900 dark:text-amber-200 block text-xs flex items-center gap-1.5">
                    <Wrench className="w-3.5 h-3.5 text-amber-600" />
                    Triển Khai &amp; Nghiệm Thu Kỹ Thuật
                  </span>
                  <span className="text-[11px] text-amber-700 dark:text-amber-400">
                    Bàn giao hồ sơ hợp đồng đã ký sang bộ phận Kỹ thuật để lập Kế hoạch tổng thể và điều phối thi công.
                  </span>
                </div>
                <button
                  onClick={() => {
                    acceptContractForDeployment(selectedContract.id, 'Trần Văn Nam (Kỹ sư Trưởng)');
                    setActiveModule('technical-contracts');
                  }}
                  className="shrink-0 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                >
                  <Wrench className="w-3.5 h-3.5" />
                  <span>Chuyển Kỹ Thuật Triển Khai →</span>
                </button>
              </div>

              {/* BẢNG ĐỢT THANH TOÁN & NÚT TẠO HÓA ĐƠN TỪNG ĐỢT */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider text-[11px] flex items-center gap-1.5">
                    <Receipt className="w-4 h-4 text-sky-600" />
                    Kế Hoạch Thanh Toán Theo Đợt (Payment Milestones)
                  </h4>
                </div>

                <div className="space-y-2.5">
                  {selectedContract.paymentMilestones.map((m) => (
                    <div
                      key={m.id}
                      className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between gap-3"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                          {m.title}
                          {m.isPaid && (
                            <span className="px-2 py-0.5 rounded text-[10px] bg-emerald-100 text-emerald-800 font-bold">
                              Đã Thu Đủ
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-1 flex items-center gap-3 font-mono">
                          <span>Hạn nộp: {m.dueDate}</span>
                          <span>•</span>
                          <span className="text-indigo-600 font-bold">{m.amount.toLocaleString()} ₫</span>
                          {m.invoiceCode && (
                            <span className="text-sky-600 font-bold">
                              HĐ: {m.invoiceCode}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="shrink-0">
                        {!m.invoiceCode ? (
                          <button
                            onClick={() => handleCreateInvoice(selectedContract.id, m.id)}
                            className="px-3 py-1.5 rounded-lg bg-sky-600 text-white font-bold text-xs flex items-center gap-1 hover:bg-sky-700 shadow-xs"
                          >
                            <Receipt className="w-3.5 h-3.5" />
                            <span>Tạo Hóa Đơn Đợt Này →</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => setActiveModule('sales-invoices')}
                            className="px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 font-semibold text-xs flex items-center gap-1"
                          >
                            <span>Xem Hóa Đơn</span>
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tệp đính kèm & Bản scan đã ký */}
              <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <span className="font-bold text-slate-700 dark:text-slate-300 block text-[11px]">
                  Tệp đính kèm &amp; Bản Scan đã ký:
                </span>
                <div className="flex items-center gap-2 flex-wrap">
                  {selectedContract.attachments.map((file, idx) => (
                    <div
                      key={idx}
                      className="px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 flex items-center gap-2 text-xs"
                    >
                      <Paperclip className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-medium text-slate-800 dark:text-slate-200">{file.name}</span>
                      <span className="text-[10px] text-slate-400">({file.size})</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Cảnh báo hết hạn & Nút Gia hạn */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-500">Cần ký phụ lục hoặc gia hạn hợp đồng?</span>
                </div>
                <button
                  onClick={() => handleRenewContract(selectedContract)}
                  className="px-4 py-2 rounded-xl bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 font-bold text-xs flex items-center gap-1.5 hover:bg-indigo-100"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>Gia Hạn Hợp Đồng</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Xem Mẫu Hợp Đồng với Biến Tự Điền (Template) */}
      {isTemplateModalOpen && selectedContract && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-2xl w-full shadow-2xl max-h-[90vh] overflow-y-auto text-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <FileText className="w-5 h-5 text-indigo-600" />
                Mẫu Hợp Đồng Kinh Tế Tự Điền (Smart Template)
              </h3>
              <button onClick={() => setIsTemplateModalOpen(false)} className="text-slate-400 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-serif leading-relaxed text-slate-800 dark:text-slate-200 space-y-3">
              <div className="text-center space-y-1">
                <p className="font-bold uppercase text-sm">CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM</p>
                <p className="italic">Độc lập - Tự do - Hạnh phúc</p>
                <p className="text-[10px] text-slate-400 font-mono">---o0o---</p>
                <h4 className="font-bold text-base uppercase mt-2">HỢP ĐỒNG CUNG ỨNG HÀNG HÓA VÀ DỊCH VỤ</h4>
                <p className="font-mono text-xs">Số: {selectedContract.contractNumber}</p>
              </div>

              <p className="pt-2">
                Hôm nay, ngày {selectedContract.templateVariables.ngay_ky}, tại văn phòng Công ty A+ Enterprise, chúng tôi gồm có:
              </p>

              <div>
                <p><strong>BÊN A (BÊN BÁN): </strong>CÔNG TY CỔ PHẦN CÔNG NGHỆ VÀ THƯƠNG MẠI A+ ENTERPRISE</p>
                <p>Đại diện: Ông Trần Minh Đức - Chức vụ: Giám đốc Kinh doanh</p>
              </div>

              <div>
                <p><strong>BÊN B (BÊN MUA): </strong>{selectedContract.templateVariables.ten_khach_hang}</p>
                <p>Địa chỉ: {selectedContract.templateVariables.dia_chi}</p>
                <p>Đại diện: {selectedContract.templateVariables.dai_dien} - Chức vụ: {selectedContract.templateVariables.chuc_vu}</p>
              </div>

              <div className="pt-2 border-t border-slate-200 dark:border-slate-700">
                <p><strong>ĐIỀU 1: GIÁ TRỊ HỢP ĐỒNG VÀ PHƯƠNG THỨC THANH TOÁN</strong></p>
                <p>Tổng giá trị hợp đồng là: <strong>{selectedContract.templateVariables.gia_tri}</strong></p>
                <p className="italic">Bằng chữ: {selectedContract.amountInWords}</p>
                <p className="mt-1">Thanh toán theo các đợt thỏa thuận tại bảng phụ lục thanh toán.</p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => showToast('Tải Word', 'Đang tải hợp đồng dưới dạng tệp Microsoft Word (.docx).')}
                className="px-4 py-2 rounded-lg bg-indigo-600 text-white font-bold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Xuất File Word (.docx)</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
