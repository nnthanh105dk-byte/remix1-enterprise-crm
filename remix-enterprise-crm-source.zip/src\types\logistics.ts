import { DocumentChainInfo } from './sales';

export type LogisticsProcessStatus =
  | 'Chờ xác nhận'
  | 'Cần bổ sung'
  | 'Từ chối'
  | 'Đã xác nhận'
  | 'Đang xuất kho'
  | 'Đã xuất kho'
  | 'Đang giao'
  | 'Đã giao'
  | 'Giao một phần'
  | 'Hoàn tất'
  | 'Hủy';

export interface OrderComment {
  id: string;
  sender: string;
  department: 'Sales' | 'Logistics';
  message: string;
  createdAt: string;
}

export interface OrderStatusHistoryItem {
  status: string;
  changedBy: string;
  changedAt: string;
  note?: string;
}

export interface OrderLineStockStatus {
  sku: string;
  requestedQty: number;
  availableStock: number;
  confirmedQty: number;
  action: 'Đủ hàng' | 'Chờ nhập hàng' | 'Loại khỏi đơn';
  purchaseOrderId?: string;
}

// 2. Delivery Note (Phiếu giao hàng: PGH-2026-xxxx)
export type DeliveryNoteStatus =
  | 'Chờ giao'
  | 'Đã xếp chuyến'
  | 'Đang giao'
  | 'Đã giao'
  | 'Giao một phần'
  | 'Giao thất bại'
  | 'Đã hoàn về'
  | 'Hủy';

export interface DeliveryNoteItem {
  sku: string;
  productName: string;
  unit: string;
  quantity: number;
  deliveredQuantity?: number;
  lotNumber?: string;
}

export interface DeliveryNote {
  id: string;
  code: string; // PGH-2026-xxxx
  orderId: string;
  orderCode: string;
  stockOutReceiptId: string;
  stockOutReceiptNumber: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  recipientName: string;
  recipientPhone: string;
  shipmentId?: string;
  shipmentCode?: string;
  date: string;
  items: DeliveryNoteItem[];
  status: DeliveryNoteStatus;
  codAmount: number;
  deliveredAt?: string;
  receiverSignedName?: string;
  proofPhotoUrl?: string;
  failedReason?: string;
  rescheduledDate?: string;
  note?: string;
  driverName?: string;
  chain: DocumentChainInfo;
}

// 3. Vehicles, Drivers, Carriers (Xe, Tài xế, Đơn vị vận chuyển)
export interface Vehicle {
  id: string;
  plateNumber: string;
  vehicleType: string; // 'Tải 1.5 Tấn', 'Tải 2.5 Tấn', 'Bán tải', 'Tải 5 Tấn'
  capacityWeight: number; // Tấn
  mainDriverId?: string;
  mainDriverName?: string;
  status: 'Sẵn sàng' | 'Đang chạy' | 'Bảo trì';
}

export interface Driver {
  id: string;
  fullName: string;
  phone: string;
  licenseNumber: string;
  licenseClass: string; // 'B2', 'C', 'D', 'FC'
  status: 'Sẵn sàng' | 'Đang chạy' | 'Nghỉ';
}

export interface Carrier {
  id: string;
  name: string;
  phone: string;
  serviceType: string; // 'Chuyển phát nhanh', 'Vận tải liên tỉnh', 'Giao hỏa tốc'
  trackingUrlTemplate: string;
  contactPerson: string;
}

// 4. Shipment (Chuyến hàng: CX-2026-xxxx)
export type ShipmentStatus =
  | 'Chờ xuất phát'
  | 'Đã bàn giao'
  | 'Đang giao'
  | 'Hoàn thành'
  | 'Hủy';

export interface ShipmentStop {
  stopNumber: number;
  deliveryNoteId: string;
  deliveryNoteCode: string;
  customerName: string;
  address: string;
  phone: string;
  codAmount: number;
  status: 'Chờ giao' | 'Đang giao' | 'Đã giao' | 'Thất bại';
  arrivedAt?: string;
  note?: string;
}

export interface ShipmentCost {
  feeRental: number;
  feeFuel: number;
  feeTolls: number;
  feeLabor: number;
  feeIncidental: number;
  totalCost: number;
  costPerStop: number;
}

export interface Shipment {
  id: string;
  code: string; // CX-2026-xxxx
  type: 'Giao hàng cho khách' | 'Nhận hàng từ nhà cung cấp';
  departureDate: string;
  vehicleId?: string;
  vehiclePlate?: string;
  vehicleType?: string;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  carrierId?: string;
  carrierName?: string;
  trackingCode?: string;
  deliveryNoteIds: string[];
  purchaseOrderId?: string;
  purchaseOrderCode?: string;
  stops: ShipmentStop[];
  costs: ShipmentCost;
  status: ShipmentStatus;
  handoverDepartureId?: string;
  handoverArrivalId?: string;
  createdAt: string;
}

// 5. Handover (Biên bản bàn giao: BBG-2026-xxxx)
export type HandoverStatus =
  | 'Chờ xác nhận'
  | 'Đã xác nhận'
  | 'Có chênh lệch'
  | 'Hủy';

export interface HandoverItemCheck {
  sku: string;
  productName: string;
  quantityExpected: number;
  quantityActual: number;
  discrepancyNote?: string;
}

export interface HandoverCashCheck {
  codExpected: number;
  codActual: number;
  discrepancyNote?: string;
}

export interface HandoverReturnedItem {
  sku: string;
  productName: string;
  quantityReturned: number;
  reason: string;
  stockInReceiptId?: string;
}

export interface HandoverRecord {
  id: string;
  code: string; // BBG-2026-xxxx
  type: 'Bàn giao xuất phát' | 'Bàn giao cuối chuyến';
  shipmentId: string;
  shipmentCode: string;
  delivererName: string;
  receiverName: string;
  confirmedAt: string;
  status: HandoverStatus;
  itemsCheck: HandoverItemCheck[];
  cashCheck?: HandoverCashCheck;
  returnedItems?: HandoverReturnedItem[];
  notes?: string;
}

// 6. COD Collection (Phiếu thu hộ: TH-2026-xxxx)
export type CodCollectionStatus =
  | 'Đã thu - chờ nộp'
  | 'Đã nộp về công ty'
  | 'Có chênh lệch'
  | 'Hủy';

export interface CodCollection {
  id: string;
  code: string; // TH-2026-xxxx
  date: string;
  customerId: string;
  customerName: string;
  deliveryNoteId: string;
  deliveryNoteCode: string;
  orderCode?: string;
  shipmentId?: string;
  shipmentCode?: string;
  driverName: string;
  amountDue: number;
  amountCollected: number;
  paymentMethod: 'Tiền mặt' | 'Chuyển khoản';
  status: CodCollectionStatus;
  collectedAt: string;
  remittedAt?: string;
  remittedToStaff?: string;
  salesReceiptId?: string;
  salesReceiptNumber?: string;
  notes?: string;
}

// 7. Supplier (Nhà cung cấp)
export interface Supplier {
  id: string;
  code: string;
  name: string;
  taxId: string;
  phone: string;
  email: string;
  address: string;
  contactPerson: string;
  category: string;
}

// 8. Purchase Order (Đơn mua hàng: DMH-2026-xxxx)
export type PurchaseOrderStatus =
  | 'Nháp'
  | 'Chờ duyệt'
  | 'Đã duyệt'
  | 'Đã gửi nhà cung cấp'
  | 'Đang nhận hàng'
  | 'Hoàn tất'
  | 'Hủy';

export interface PurchaseOrderItem {
  sku: string;
  productName: string;
  unit: string;
  quantity: number;
  receivedQuantity: number;
  unitPrice: number;
  discountPercent: number;
  vatRate: number;
  total: number;
  lastPurchasePrice?: number;
}

export interface PurchaseOrder {
  id: string;
  code: string; // DMH-2026-xxxx
  orderDate: string;
  expectedDeliveryDate: string;
  supplierId: string;
  supplierName: string;
  supplierPhone: string;
  supplierAddress: string;
  warehouseId: string;
  warehouseName: string;
  items: PurchaseOrderItem[];
  subTotal: number;
  vatAmount: number;
  totalAmount: number;
  amountInWords: string;
  paymentTerms: string;
  notes?: string;
  status: PurchaseOrderStatus;
  receivingProgress: 'Chưa nhận' | 'Nhận một phần' | 'Đã nhận đủ';
  invoiceStatus: 'Chưa có hóa đơn' | 'Đã lập hóa đơn' | 'Đã thanh toán';
  relatedStockInReceiptIds: string[];
  chain: DocumentChainInfo;
}

// 9. Purchase Invoice (Hóa đơn mua hàng: HDM-2026-xxxx)
export type PurchaseInvoiceStatus =
  | 'Nháp'
  | 'Chờ đối chiếu'
  | 'Đã khớp'
  | 'Chênh lệch'
  | 'Chờ thanh toán'
  | 'Thanh toán một phần'
  | 'Đã thanh toán'
  | 'Hủy';

export interface PurchaseInvoiceItem {
  sku: string;
  productName: string;
  unit: string;
  poQuantity: number;
  stockInQuantity: number;
  invoiceQuantity: number;
  poPrice: number;
  invoicePrice: number;
  lineDiscrepancy: boolean;
  discrepancyDetail?: string;
}

export interface PurchaseInvoice {
  id: string;
  code: string; // HDM-2026-xxxx
  supplierInvoiceNumber: string;
  invoiceSeries: string;
  invoiceDate: string;
  dueDate: string;
  supplierId: string;
  supplierName: string;
  supplierTaxId: string;
  purchaseOrderId: string;
  purchaseOrderCode: string;
  items: PurchaseInvoiceItem[];
  subTotal: number;
  vatAmount: number;
  totalAmount: number;
  paidAmount: number;
  remainingAmount: number;
  status: PurchaseInvoiceStatus;
  threeWayMatchStatus: 'Khớp' | 'Lệch số lượng' | 'Lệch đơn giá' | 'Lệch cả hai';
  exceptionApproval?: {
    approvedBy: string;
    approvedAt: string;
    reason: string;
  };
  paymentRequestId?: string;
  chain: DocumentChainInfo;
}

// 10. Payment Request (Đề nghị thanh toán: DNTT-2026-xxxx)
export type PaymentRequestType =
  | 'Thanh toán nhà cung cấp'
  | 'Cước vận chuyển'
  | 'Chi phí phát sinh'
  | 'Khác';

export type PaymentRequestStatus =
  | 'Nháp'
  | 'Chờ duyệt (Trưởng BP)'
  | 'Chờ duyệt (Giám đốc)'
  | 'Đã duyệt'
  | 'Chờ chi'
  | 'Đã chi'
  | 'Từ chối'
  | 'Hủy';

export interface PaymentRequest {
  id: string;
  code: string; // DNTT-2026-xxxx
  requestDate: string;
  requesterName: string;
  department: string;
  type: PaymentRequestType;
  beneficiaryName: string;
  beneficiaryBank: string;
  beneficiaryAccount: string;
  relatedDocumentIds: string[];
  relatedDocumentCodes: string[];
  totalAmount: number;
  amountInWords: string;
  paymentMethod: 'Chuyển khoản' | 'Tiền mặt';
  dueDate: string;
  reason: string;
  status: PaymentRequestStatus;
  paidAt?: string;
  accountantName?: string;
  approvalNotes?: string;
  chain: DocumentChainInfo;
}

// 11. Document Expiry (Giấy tờ sắp hết hạn)
export type DocumentExpiryType =
  | 'Đăng kiểm xe'
  | 'Bảo hiểm xe'
  | 'Giấy đăng ký xe'
  | 'Bằng lái tài xế'
  | 'Hợp đồng đơn vị vận chuyển'
  | 'Giấy phép/đăng ký sản phẩm'
  | 'Khác';

export type DocumentRelatedTarget =
  | 'Xe'
  | 'Tài xế'
  | 'Đơn vị vận chuyển'
  | 'Nhà cung cấp'
  | 'Sản phẩm';

export interface DocumentExpiry {
  id: string;
  documentNumber: string;
  documentType: DocumentExpiryType;
  relatedType: DocumentRelatedTarget;
  targetId: string;
  targetName: string;
  issueDate: string;
  expiryDate: string;
  daysRemaining: number;
  status: 'Còn hạn' | 'Cận hạn (≤30 ngày)' | 'Cận hạn (31-60 ngày)' | 'Cận hạn (61-90 ngày)' | 'Đã hết hạn';
  fileUrl?: string;
  notes?: string;
  renewedDate?: string;
}
