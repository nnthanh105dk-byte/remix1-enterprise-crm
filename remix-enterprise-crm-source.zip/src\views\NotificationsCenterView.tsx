import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { NotificationItem } from '../types/crm';
import {
  Bell,
  Check,
  CheckCheck,
  ShoppingCart,
  CheckCircle2,
  XCircle,
  CornerUpLeft,
  CalendarCheck,
  MessageSquare,
  AlertTriangle,
  ExternalLink,
  Search,
  Filter,
} from 'lucide-react';

export const NotificationsCenterView: React.FC = () => {
  const {
    notifications,
    unreadNotificationCount,
    markNotificationRead,
    markAllNotificationsRead,
    setActiveModule,
    setCurrentDocCode,
  } = useCRM();

  const [tab, setTab] = useState<'all' | 'unread'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');

  const filtered = notifications.filter((item) => {
    if (tab === 'unread' && item.read) return false;
    if (typeFilter !== 'all' && item.type !== typeFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      return (
        item.title.toLowerCase().includes(q) ||
        item.message.toLowerCase().includes(q) ||
        (item.entityId && item.entityId.toLowerCase().includes(q)) ||
        (item.senderName && item.senderName.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const getNotificationIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'order':
        return <ShoppingCart className="w-5 h-5 text-sky-600 dark:text-sky-400" />;
      case 'approval':
        return <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />;
      case 'rejection':
        return <XCircle className="w-5 h-5 text-rose-600 dark:text-rose-400" />;
      case 'return':
        return <CornerUpLeft className="w-5 h-5 text-amber-600 dark:text-amber-400" />;
      case 'task':
        return <CalendarCheck className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />;
      case 'comment':
        return <MessageSquare className="w-5 h-5 text-purple-600 dark:text-purple-400" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-slate-500 dark:text-slate-400" />;
    }
  };

  const handleItemClick = (item: NotificationItem) => {
    if (!item.read) markNotificationRead(item.id);
    if (item.entityId) setCurrentDocCode(item.entityId);
    if (item.linkModule) setActiveModule(item.linkModule);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-xl bg-sky-50 dark:bg-sky-950/60 text-[#002659] dark:text-sky-400">
              <Bell className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-slate-100">
                Trung Tâm Thông Báo (90 Ngày)
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Các thông báo phát sinh từ hành động của đồng nghiệp (gửi đơn, duyệt/từ chối, trả về, giao việc, bình luận).
              </p>
            </div>
          </div>
        </div>

        {unreadNotificationCount > 0 && (
          <button
            type="button"
            onClick={markAllNotificationsRead}
            className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center gap-2 cursor-pointer shrink-0"
          >
            <CheckCheck className="w-4 h-4 text-emerald-600" />
            <span>Đánh dấu tất cả đã đọc</span>
          </button>
        )}
      </div>

      {/* Filters & Tabs */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Tabs */}
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setTab('all')}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                tab === 'all'
                  ? 'bg-[#002659] dark:bg-sky-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              Tất cả ({notifications.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('unread')}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                tab === 'unread'
                  ? 'bg-[#002659] dark:bg-sky-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              Chưa đọc ({unreadNotificationCount})
            </button>
          </div>

          {/* Search & Type filter */}
          <div className="flex items-center gap-2 flex-1 max-w-md">
            <div className="relative flex-1">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Tìm nội dung thông báo, mã chứng từ..."
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>

            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="px-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-medium shrink-0"
            >
              <option value="all">Tất cả loại</option>
              <option value="order">Đơn hàng</option>
              <option value="approval">Phê duyệt</option>
              <option value="rejection">Từ chối</option>
              <option value="return">Trả về</option>
              <option value="task">Giao việc</option>
              <option value="comment">Bình luận</option>
            </select>
          </div>
        </div>

        {/* List */}
        <div className="divide-y divide-slate-100 dark:divide-slate-800/80">
          {filtered.length > 0 ? (
            filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => handleItemClick(item)}
                className={`py-4 px-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors flex items-start gap-4 cursor-pointer ${
                  !item.read ? 'bg-[#F0F7FD]/60 dark:bg-sky-950/20' : ''
                }`}
              >
                <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 shrink-0 mt-0.5">
                  {getNotificationIcon(item.type)}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h3
                      className={`text-sm ${
                        !item.read
                          ? 'font-bold text-slate-900 dark:text-slate-100'
                          : 'font-semibold text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {item.title}
                    </h3>
                    <span className="text-xs text-slate-400 whitespace-nowrap shrink-0">{item.timestamp}</span>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 leading-relaxed">
                    {item.message}
                  </p>

                  <div className="flex items-center gap-3 mt-2 text-xs">
                    {item.senderName && (
                      <span className="text-slate-500 dark:text-slate-400">
                        Từ: <strong className="text-slate-700 dark:text-slate-300">{item.senderName}</strong>
                      </span>
                    )}

                    {item.entityId && (
                      <span className="font-mono text-[11px] text-[#002659] dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60 px-2 py-0.5 rounded border border-sky-200 dark:border-sky-800">
                        {item.entityId}
                      </span>
                    )}

                    <span className="text-[#002659] dark:text-sky-400 hover:underline flex items-center gap-1 font-semibold ml-auto">
                      Mở chứng từ <ExternalLink className="w-3 h-3" />
                    </span>
                  </div>
                </div>

                {!item.read && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      markNotificationRead(item.id);
                    }}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-slate-800 shrink-0 transition-colors"
                    title="Đánh dấu đã đọc"
                  >
                    <Check className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))
          ) : (
            <div className="py-12 text-center text-xs text-slate-400">
              Không có thông báo nào phù hợp với bộ lọc.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
