import { ThemePreset, CustomThemeSettings } from '../types/crm';

export interface ThemeDefinition {
  id: ThemePreset;
  nameVi: string;
  nameEn: string;
  previewColor: string;
  pastelBgColor: string;
  badgeBg: string;
  isDarkDefault: boolean;
  classes: {
    appBackground: string;
    sidebarBg: string;
    sidebarText: string;
    sidebarActive: string;
    sidebarBorder: string;
    headerBg: string;
    headerBorder: string;
    cardBg: string;
    cardBorder: string;
    cardShadow: string;
    primaryButton: string;
    primaryText: string;
    accentBadge: string;
    tableHeaderBg: string;
  };
}

export const THEME_PRESETS: Record<ThemePreset, ThemeDefinition> = {
  // 1. Navy Slate (Mặc định doanh nghiệp A+)
  'corporate-blue': {
    id: 'corporate-blue',
    nameVi: '1. Navy Slate (Mặc định A+)',
    nameEn: '1. Corporate Navy (Default)',
    previewColor: '#002659',
    pastelBgColor: '#F4F7FC',
    badgeBg: 'bg-[#002659]',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-[#F4F7FC] text-[#172033]',
      sidebarBg: 'bg-white text-[#667085] border-r border-[#E2E8F0]',
      sidebarText: 'text-[#667085] hover:text-[#002659] hover:bg-[#F0F5FA]',
      sidebarActive: 'bg-[#F0F5FA] text-[#002659] font-bold border-l-[3.5px] border-[#002659]',
      sidebarBorder: 'border-[#E2E8F0]',
      headerBg: 'bg-white border-b border-[#E2E8F0]',
      headerBorder: 'border-[#E2E8F0]',
      cardBg: 'bg-white',
      cardBorder: 'border border-[#E2E8F0]',
      cardShadow: 'shadow-xs',
      primaryButton: 'bg-[#002659] hover:bg-[#001a3d] text-white font-medium rounded-[6px] shadow-xs active:scale-[0.99]',
      primaryText: 'text-[#002659]',
      accentBadge: 'bg-[#F0F5FA] text-[#002659] border-[#9CD7F8]',
      tableHeaderBg: 'bg-[#F8FAFC] text-[#667085] border-b border-[#E2E8F0]',
    },
  },

  // 2. Rose Blush (Đỏ Hồng Pastel Mềm Mại)
  'pastel-rose': {
    id: 'pastel-rose',
    nameVi: '2. Rose Blush (Đỏ Pastel Nhẹ)',
    nameEn: '2. Rose Blush (Pastel Red)',
    previewColor: '#BE123C',
    pastelBgColor: '#FFF1F2',
    badgeBg: 'bg-[#BE123C]',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-[#FFF1F2] text-[#172033]',
      sidebarBg: 'bg-white text-[#667085] border-r border-[#FFE4E6]',
      sidebarText: 'text-[#667085] hover:text-[#BE123C] hover:bg-[#FFF1F2]',
      sidebarActive: 'bg-[#FFF1F2] text-[#BE123C] font-bold border-l-[3.5px] border-[#BE123C]',
      sidebarBorder: 'border-[#FFE4E6]',
      headerBg: 'bg-white border-b border-[#FFE4E6]',
      headerBorder: 'border-[#FFE4E6]',
      cardBg: 'bg-white',
      cardBorder: 'border border-[#FCE7F3]',
      cardShadow: 'shadow-xs',
      primaryButton: 'bg-[#BE123C] hover:bg-[#9F1239] text-white font-medium rounded-[6px] shadow-xs active:scale-[0.99]',
      primaryText: 'text-[#BE123C]',
      accentBadge: 'bg-[#FFF1F2] text-[#BE123C] border-[#FDA4AF]',
      tableHeaderBg: 'bg-[#FFF8F8] text-[#667085] border-b border-[#FFE4E6]',
    },
  },

  // 3. Mint Emerald (Xanh Lục Bạc Hà Pastel)
  'pastel-emerald': {
    id: 'pastel-emerald',
    nameVi: '3. Mint Emerald (Xanh Lục Pastel)',
    nameEn: '3. Mint Emerald (Pastel Green)',
    previewColor: '#047857',
    pastelBgColor: '#F0FDF4',
    badgeBg: 'bg-[#047857]',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-[#F0FDF4] text-[#172033]',
      sidebarBg: 'bg-white text-[#667085] border-r border-[#DCFCE7]',
      sidebarText: 'text-[#667085] hover:text-[#047857] hover:bg-[#F0FDF4]',
      sidebarActive: 'bg-[#F0FDF4] text-[#047857] font-bold border-l-[3.5px] border-[#047857]',
      sidebarBorder: 'border-[#DCFCE7]',
      headerBg: 'bg-white border-b border-[#DCFCE7]',
      headerBorder: 'border-[#DCFCE7]',
      cardBg: 'bg-white',
      cardBorder: 'border border-[#E2E8F0]',
      cardShadow: 'shadow-xs',
      primaryButton: 'bg-[#047857] hover:bg-[#065F46] text-white font-medium rounded-[6px] shadow-xs active:scale-[0.99]',
      primaryText: 'text-[#047857]',
      accentBadge: 'bg-[#F0FDF4] text-[#047857] border-[#86EFAC]',
      tableHeaderBg: 'bg-[#F7FEE7] text-[#667085] border-b border-[#DCFCE7]',
    },
  },

  // 4. Warm Amber (Vàng Hổ Phách Pastel)
  'pastel-amber': {
    id: 'pastel-amber',
    nameVi: '4. Warm Amber (Vàng Hổ Phách Pastel)',
    nameEn: '4. Warm Amber (Pastel Honey)',
    previewColor: '#B45309',
    pastelBgColor: '#FFFBEB',
    badgeBg: 'bg-[#B45309]',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-[#FFFBEB] text-[#172033]',
      sidebarBg: 'bg-white text-[#667085] border-r border-[#FEF3C7]',
      sidebarText: 'text-[#667085] hover:text-[#B45309] hover:bg-[#FFFBEB]',
      sidebarActive: 'bg-[#FFFBEB] text-[#B45309] font-bold border-l-[3.5px] border-[#B45309]',
      sidebarBorder: 'border-[#FEF3C7]',
      headerBg: 'bg-white border-b border-[#FEF3C7]',
      headerBorder: 'border-[#FEF3C7]',
      cardBg: 'bg-white',
      cardBorder: 'border border-[#E2E8F0]',
      cardShadow: 'shadow-xs',
      primaryButton: 'bg-[#B45309] hover:bg-[#92400E] text-white font-medium rounded-[6px] shadow-xs active:scale-[0.99]',
      primaryText: 'text-[#B45309]',
      accentBadge: 'bg-[#FFFBEB] text-[#B45309] border-[#FCD34D]',
      tableHeaderBg: 'bg-[#FFFDF5] text-[#667085] border-b border-[#FEF3C7]',
    },
  },

  // 5. Lavender Violet (Tím Oải Hương Pastel)
  'pastel-purple': {
    id: 'pastel-purple',
    nameVi: '5. Lavender Violet (Tím Pastel)',
    nameEn: '5. Lavender Violet (Pastel Purple)',
    previewColor: '#6D28D9',
    pastelBgColor: '#FAF5FF',
    badgeBg: 'bg-[#6D28D9]',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-[#FAF5FF] text-[#172033]',
      sidebarBg: 'bg-white text-[#667085] border-r border-[#F3E8FF]',
      sidebarText: 'text-[#667085] hover:text-[#6D28D9] hover:bg-[#FAF5FF]',
      sidebarActive: 'bg-[#FAF5FF] text-[#6D28D9] font-bold border-l-[3.5px] border-[#6D28D9]',
      sidebarBorder: 'border-[#F3E8FF]',
      headerBg: 'bg-white border-b border-[#F3E8FF]',
      headerBorder: 'border-[#F3E8FF]',
      cardBg: 'bg-white',
      cardBorder: 'border border-[#E2E8F0]',
      cardShadow: 'shadow-xs',
      primaryButton: 'bg-[#6D28D9] hover:bg-[#5B21B6] text-white font-medium rounded-[6px] shadow-xs active:scale-[0.99]',
      primaryText: 'text-[#6D28D9]',
      accentBadge: 'bg-[#FAF5FF] text-[#6D28D9] border-[#D8B4FE]',
      tableHeaderBg: 'bg-[#FDFBFF] text-[#667085] border-b border-[#F3E8FF]',
    },
  },

  // 6. Sky Cyan (Xanh Biển Tươi Pastel)
  'pastel-cyan': {
    id: 'pastel-cyan',
    nameVi: '6. Sky Cyan (Xanh Biển Pastel)',
    nameEn: '6. Sky Cyan (Pastel Ocean)',
    previewColor: '#0284C7',
    pastelBgColor: '#F0F9FF',
    badgeBg: 'bg-[#0284C7]',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-[#F0F9FF] text-[#172033]',
      sidebarBg: 'bg-white text-[#667085] border-r border-[#E0F2FE]',
      sidebarText: 'text-[#667085] hover:text-[#0284C7] hover:bg-[#F0F9FF]',
      sidebarActive: 'bg-[#F0F9FF] text-[#0284C7] font-bold border-l-[3.5px] border-[#0284C7]',
      sidebarBorder: 'border-[#E0F2FE]',
      headerBg: 'bg-white border-b border-[#E0F2FE]',
      headerBorder: 'border-[#E0F2FE]',
      cardBg: 'bg-white',
      cardBorder: 'border border-[#E2E8F0]',
      cardShadow: 'shadow-xs',
      primaryButton: 'bg-[#0284C7] hover:bg-[#0369A1] text-white font-medium rounded-[6px] shadow-xs active:scale-[0.99]',
      primaryText: 'text-[#0284C7]',
      accentBadge: 'bg-[#F0F9FF] text-[#0284C7] border-[#7DD3FC]',
      tableHeaderBg: 'bg-[#F8FCFF] text-[#667085] border-b border-[#E0F2FE]',
    },
  },

  // 7. Peach Coral (Cam Đào San Hô Pastel)
  'pastel-coral': {
    id: 'pastel-coral',
    nameVi: '7. Peach Coral (Cam Đào Pastel)',
    nameEn: '7. Peach Coral (Pastel Tangerine)',
    previewColor: '#C2410C',
    pastelBgColor: '#FFF7ED',
    badgeBg: 'bg-[#C2410C]',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-[#FFF7ED] text-[#172033]',
      sidebarBg: 'bg-white text-[#667085] border-r border-[#FFEDD5]',
      sidebarText: 'text-[#667085] hover:text-[#C2410C] hover:bg-[#FFF7ED]',
      sidebarActive: 'bg-[#FFF7ED] text-[#C2410C] font-bold border-l-[3.5px] border-[#C2410C]',
      sidebarBorder: 'border-[#FFEDD5]',
      headerBg: 'bg-white border-b border-[#FFEDD5]',
      headerBorder: 'border-[#FFEDD5]',
      cardBg: 'bg-white',
      cardBorder: 'border border-[#E2E8F0]',
      cardShadow: 'shadow-xs',
      primaryButton: 'bg-[#C2410C] hover:bg-[#9A3412] text-white font-medium rounded-[6px] shadow-xs active:scale-[0.99]',
      primaryText: 'text-[#C2410C]',
      accentBadge: 'bg-[#FFF7ED] text-[#C2410C] border-[#FDBA74]',
      tableHeaderBg: 'bg-[#FFFBF5] text-[#667085] border-b border-[#FFEDD5]',
    },
  },

  // 8. Sage Teal (Xanh Xô Thơm Pastel)
  'pastel-teal': {
    id: 'pastel-teal',
    nameVi: '8. Sage Teal (Xanh Xô Thơm Pastel)',
    nameEn: '8. Sage Teal (Pastel Sage)',
    previewColor: '#0F766E',
    pastelBgColor: '#F0FDFA',
    badgeBg: 'bg-[#0F766E]',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-[#F0FDFA] text-[#172033]',
      sidebarBg: 'bg-white text-[#667085] border-r border-[#CCFBF1]',
      sidebarText: 'text-[#667085] hover:text-[#0F766E] hover:bg-[#F0FDFA]',
      sidebarActive: 'bg-[#F0FDFA] text-[#0F766E] font-bold border-l-[3.5px] border-[#0F766E]',
      sidebarBorder: 'border-[#CCFBF1]',
      headerBg: 'bg-white border-b border-[#CCFBF1]',
      headerBorder: 'border-[#CCFBF1]',
      cardBg: 'bg-white',
      cardBorder: 'border border-[#E2E8F0]',
      cardShadow: 'shadow-xs',
      primaryButton: 'bg-[#0F766E] hover:bg-[#115E59] text-white font-medium rounded-[6px] shadow-xs active:scale-[0.99]',
      primaryText: 'text-[#0F766E]',
      accentBadge: 'bg-[#F0FDFA] text-[#0F766E] border-[#5EEAD4]',
      tableHeaderBg: 'bg-[#F7FEFD] text-[#667085] border-b border-[#CCFBF1]',
    },
  },

  // 9. Modern Indigo (Xanh Chàm Pastel)
  'pastel-indigo': {
    id: 'pastel-indigo',
    nameVi: '9. Modern Indigo (Xanh Chàm Pastel)',
    nameEn: '9. Modern Indigo (Pastel Slate)',
    previewColor: '#4338CA',
    pastelBgColor: '#EEF2FF',
    badgeBg: 'bg-[#4338CA]',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-[#EEF2FF] text-[#172033]',
      sidebarBg: 'bg-white text-[#667085] border-r border-[#E0E7FF]',
      sidebarText: 'text-[#667085] hover:text-[#4338CA] hover:bg-[#EEF2FF]',
      sidebarActive: 'bg-[#EEF2FF] text-[#4338CA] font-bold border-l-[3.5px] border-[#4338CA]',
      sidebarBorder: 'border-[#E0E7FF]',
      headerBg: 'bg-white border-b border-[#E0E7FF]',
      headerBorder: 'border-[#E0E7FF]',
      cardBg: 'bg-white',
      cardBorder: 'border border-[#E2E8F0]',
      cardShadow: 'shadow-xs',
      primaryButton: 'bg-[#4338CA] hover:bg-[#3730A3] text-white font-medium rounded-[6px] shadow-xs active:scale-[0.99]',
      primaryText: 'text-[#4338CA]',
      accentBadge: 'bg-[#EEF2FF] text-[#4338CA] border-[#A5B4FC]',
      tableHeaderBg: 'bg-[#F8FAFF] text-[#667085] border-b border-[#E0E7FF]',
    },
  },

  // 10. Modern Dark (Chế độ Tối Tinh tế)
  'modern-dark': {
    id: 'modern-dark',
    nameVi: '10. Dark Slate (Chế độ Tối Tinh tế)',
    nameEn: '10. Dark Slate (Modern Dark)',
    previewColor: '#38BDF8',
    pastelBgColor: '#0B0F17',
    badgeBg: 'bg-[#001226]',
    isDarkDefault: true,
    classes: {
      appBackground: 'bg-[#0B0F17] text-slate-100',
      sidebarBg: 'bg-[#070A10] text-slate-300 border-r border-slate-800',
      sidebarText: 'text-slate-400 hover:text-sky-400 hover:bg-[#001a3d]',
      sidebarActive: 'bg-[#001a3d] text-sky-400 border-l-[3.5px] border-sky-400 font-semibold',
      sidebarBorder: 'border-slate-800',
      headerBg: 'bg-[#0A0E17]/95 backdrop-blur-md border-b border-slate-800',
      headerBorder: 'border-slate-800',
      cardBg: 'bg-[#0F172A]',
      cardBorder: 'border border-slate-800',
      cardShadow: 'shadow-lg shadow-black/40',
      primaryButton: 'bg-sky-600 hover:bg-sky-500 text-white font-medium rounded-lg shadow-sm border border-sky-400/30',
      primaryText: 'text-sky-400',
      accentBadge: 'bg-sky-950/80 text-sky-300 border-sky-800',
      tableHeaderBg: 'bg-[#1E293B] text-white border-b border-slate-700',
    },
  },

  // 11. Glassmorphism (Kính mờ Tinh tế)
  'glassmorphism': {
    id: 'glassmorphism',
    nameVi: '11. Glassmorphism (Kính mờ Tinh tế)',
    nameEn: '11. Glassmorphism (Frosted Acrylic)',
    previewColor: '#0284C7',
    pastelBgColor: '#F0F9FF',
    badgeBg: 'bg-sky-500',
    isDarkDefault: false,
    classes: {
      appBackground: 'bg-gradient-to-br from-slate-100 via-sky-50/60 to-indigo-50/50 text-[#0F172A]',
      sidebarBg: 'bg-white/75 backdrop-blur-xl border-r border-white/60 text-slate-700 shadow-sm',
      sidebarText: 'text-slate-600 hover:text-[#002659] hover:bg-white/60',
      sidebarActive: 'bg-white/90 text-[#002659] font-bold border-l-[3.5px] border-[#002659] shadow-xs backdrop-blur-md',
      sidebarBorder: 'border-white/60',
      headerBg: 'bg-white/75 backdrop-blur-xl border-b border-white/60 shadow-xs',
      headerBorder: 'border-white/60',
      cardBg: 'bg-white/75 backdrop-blur-xl',
      cardBorder: 'border border-white/70 shadow-lg shadow-sky-950/5',
      cardShadow: 'shadow-lg shadow-sky-950/5 backdrop-blur-xl',
      primaryButton: 'bg-gradient-to-r from-[#002659] to-[#3661C9] hover:from-[#001a3d] hover:to-[#294eb0] text-white font-medium rounded-lg shadow-sm backdrop-blur-md',
      primaryText: 'text-[#002659]',
      accentBadge: 'bg-sky-100/70 text-sky-800 border-sky-200/80 backdrop-blur-xs',
      tableHeaderBg: 'bg-white/60 backdrop-blur-md text-slate-700 border-b border-white/60',
    },
  },
};

export const DEFAULT_CUSTOM_SETTINGS: CustomThemeSettings = {
  primaryColor: '#2563eb',
  borderRadius: 'md',
  density: 'comfortable',
  fontFamily: 'Roboto',
  sidebarStyle: 'solid',
};
