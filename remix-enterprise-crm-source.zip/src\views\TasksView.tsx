import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import {
  CheckSquare,
  Plus,
  Search,
  Filter,
  Calendar,
  Clock,
  CheckCircle2,
  Circle,
  AlertCircle,
  User,
  Trash2,
} from 'lucide-react';

interface Task {
  id: string;
  title: string;
  customerName: string;
  company: string;
  dueDate: string;
  dueTime: string;
  priority: 'high' | 'medium' | 'normal';
  category: 'Call' | 'Meeting' | 'Proposal' | 'Follow-up';
  completed: boolean;
  assignedTo: string;
}

export const TasksView: React.FC = () => {
  const { language, showToast } = useCRM();
  const isVi = language === 'vi';

  const [tasks, setTasks] = useState<Task[]>([
    {
      id: 't-1',
      title: 'Gọi điện xác nhận nhu cầu triển khai ERP & phân quyền',
      customerName: 'Nguyễn Văn An',
      company: 'Dược Liệu Á Châu',
      dueDate: 'Hôm nay',
      dueTime: '09:30',
      priority: 'high',
      category: 'Call',
      completed: false,
      assignedTo: 'Trần Minh Đức',
    },
    {
      id: 't-2',
      title: 'Gửi bản báo giá chính thức gói Cloud Server v2 cho Ban Giám Đốc',
      customerName: 'Trần Minh Tuấn',
      company: 'VNPAY Solutions',
      dueDate: 'Hôm nay',
      dueTime: '11:00',
      priority: 'medium',
      category: 'Proposal',
      completed: false,
      assignedTo: 'Lê Hoàng Yến',
    },
    {
      id: 't-3',
      title: 'Ký kết hợp đồng kinh tế và đối soát điều khoản thanh toán đợt 1',
      customerName: 'Lê Hoàng Nam',
      company: 'Tập đoàn Masan',
      dueDate: 'Hôm nay',
      dueTime: '14:30',
      priority: 'normal',
      category: 'Meeting',
      completed: true,
      assignedTo: 'Trần Minh Đức',
    },
    {
      id: 't-4',
      title: 'Họp demo tính năng chăm sóc đa kênh Zalo OA và Ticket SLA',
      customerName: 'Phạm Quỳnh Nga',
      company: 'FPT Software',
      dueDate: 'Hôm nay',
      dueTime: '16:00',
      priority: 'high',
      category: 'Meeting',
      completed: false,
      assignedTo: 'Nguyễn Thanh Tùng',
    },
    {
      id: 't-5',
      title: 'Follow-up phản hồi về chiết khấu thanh toán trước 100%',
      customerName: 'Hoàng Quốc Việt',
      company: 'Bất Động Sản An Gia',
      dueDate: 'Ngày mai',
      dueTime: '10:00',
      priority: 'normal',
      category: 'Follow-up',
      completed: false,
      assignedTo: 'Trần Minh Đức',
    },
    {
      id: 't-6',
      title: 'Kiểm kê định kỳ tồn kho server & thiết bị mạng tại Kho Hà Nội',
      customerName: 'Nội bộ',
      company: 'A+ Operations',
      dueDate: '28/10/2026',
      dueTime: '15:00',
      priority: 'normal',
      category: 'Follow-up',
      completed: false,
      assignedTo: 'Hoàng Văn Kho',
    },
  ]);

  const [activeTab, setActiveTab] = useState<'all' | 'today' | 'upcoming' | 'completed'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const toggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    const newTask: Task = {
      id: `task-${Date.now()}`,
      title: newTitle.trim(),
      customerName: 'Khách hàng mới',
      company: 'Công ty đối tác',
      dueDate: 'Hôm nay',
      dueTime: '17:00',
      priority: 'normal',
      category: 'Follow-up',
      completed: false,
      assignedTo: 'Tôi',
    };
    setTasks([newTask, ...tasks]);
    setNewTitle('');
    setShowAddForm(false);
    showToast('Đã thêm task', 'Công việc mới đã được tạo vào danh sách');
  };

  const deleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
    showToast('Đã xóa', 'Đã gỡ bỏ công việc', 'info');
  };

  const filteredTasks = tasks.filter((t) => {
    const matchesSearch =
      t.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.company.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (activeTab === 'today') return t.dueDate === 'Hôm nay' && !t.completed;
    if (activeTab === 'upcoming') return t.dueDate !== 'Hôm nay' && !t.completed;
    if (activeTab === 'completed') return t.completed;
    return true;
  });

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* 01. Context Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-[#0F172A] tracking-tight">
              {isVi ? 'Công việc & Lịch hẹn' : 'Tasks & To-Dos'}
            </h1>
            <span className="text-xs font-mono font-medium text-[#64748B] bg-slate-100 px-2 py-0.5 rounded">
              {tasks.filter((t) => !t.completed).length} {isVi ? 'việc cần làm' : 'pending'}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            {isVi
              ? 'Lên kế hoạch gọi điện, họp, gửi báo giá và chăm sóc khách hàng hàng ngày.'
              : 'Daily priority planner for customer touchpoints, meetings, and follow-ups.'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-1 px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white text-[11px] sm:text-xs font-medium transition-colors shadow-xs whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5 shrink-0" />
            <span className="hidden sm:inline">{isVi ? 'Thêm công việc' : 'New Task'}</span>
            <span className="sm:hidden">{isVi ? 'Việc' : 'Task'}</span>
          </button>
        </div>
      </div>

      {/* 02. Search & Segmented Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-[#E5E7EB]">
        {/* Segmented Filter */}
        <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#F7F9FC] border border-[#E5E7EB] overflow-x-auto">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-2.5 sm:px-3 py-1 text-[11px] sm:text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'all'
                ? 'bg-white text-[#002659] font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isVi ? 'Tất cả' : 'All'}
          </button>
          <button
            onClick={() => setActiveTab('today')}
            className={`px-2.5 sm:px-3 py-1 text-[11px] sm:text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'today'
                ? 'bg-white text-[#002659] font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span className="hidden sm:inline">{isVi ? 'Hôm nay' : 'Today'}</span>
            <span className="sm:hidden">{isVi ? 'Nay' : 'Today'}</span>
          </button>
          <button
            onClick={() => setActiveTab('upcoming')}
            className={`px-2.5 sm:px-3 py-1 text-[11px] sm:text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'upcoming'
                ? 'bg-white text-[#002659] font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {isVi ? 'Sắp tới' : 'Upcoming'}
          </button>
          <button
            onClick={() => setActiveTab('completed')}
            className={`px-2.5 sm:px-3 py-1 text-[11px] sm:text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              activeTab === 'completed'
                ? 'bg-white text-[#002659] font-bold shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <span className="hidden sm:inline">{isVi ? 'Đã hoàn thành' : 'Completed'}</span>
            <span className="sm:hidden">{isVi ? 'Xong' : 'Done'}</span>
          </button>
        </div>

        {/* Search */}
        <div className="relative max-w-xs w-full">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={isVi ? 'Tìm công việc...' : 'Search tasks...'}
            className="w-full h-8 pl-8 pr-3 text-xs rounded-lg border border-[#E5E7EB] bg-[#F7F9FC] focus:bg-white focus:outline-hidden focus:border-[#3661C9]"
          />
        </div>
      </div>

      {/* Quick Add Form */}
      {showAddForm && (
        <form onSubmit={handleAddTask} className="p-4 rounded-xl border border-[#3661C9]/30 bg-[#F0F7FD] flex items-center gap-3">
          <input
            type="text"
            autoFocus
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder={isVi ? 'Nhập nội dung công việc (ví dụ: Gặp khách hàng review hợp đồng)...' : 'Task title...'}
            className="flex-1 h-9 px-3 text-xs bg-white rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
          />
          <button
            type="submit"
            className="px-4 h-9 bg-[#002659] text-white text-xs font-medium rounded-lg hover:bg-[#001a3d]"
          >
            {isVi ? 'Tạo' : 'Add'}
          </button>
          <button
            type="button"
            onClick={() => setShowAddForm(false)}
            className="px-3 h-9 bg-white text-slate-600 text-xs font-medium rounded-lg border border-[#E5E7EB]"
          >
            {isVi ? 'Hủy' : 'Cancel'}
          </button>
        </form>
      )}

      {/* 03. Tasks List (Clean Table / List with subtle borders) */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-xs divide-y divide-[#E5E7EB]">
        {filteredTasks.length === 0 ? (
          <div className="py-12 text-center text-xs text-slate-500">
            {isVi ? 'Không có công việc nào trong danh sách này.' : 'No tasks found.'}
          </div>
        ) : (
          filteredTasks.map((task) => (
            <div
              key={task.id}
              className={`p-3.5 sm:px-5 flex items-center justify-between gap-3 hover:bg-[#F8FAFC] transition-colors ${
                task.completed ? 'bg-slate-50/50 opacity-70' : ''
              }`}
            >
              {/* Checkbox & Details */}
              <div className="flex items-center gap-3 flex-1 min-w-0">
                <button
                  type="button"
                  onClick={() => toggleTask(task.id)}
                  className="text-slate-400 hover:text-[#3661C9] shrink-0"
                >
                  {task.completed ? (
                    <CheckCircle2 className="w-4.5 h-4.5 text-emerald-600" />
                  ) : (
                    <Circle className="w-4.5 h-4.5 text-slate-300" />
                  )}
                </button>

                <div className="min-w-0 flex-1">
                  <div
                    onClick={() => toggleTask(task.id)}
                    className={`text-xs font-medium cursor-pointer truncate ${
                      task.completed ? 'line-through text-slate-400' : 'text-[#0F172A]'
                    }`}
                  >
                    {task.title}
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-[#64748B] mt-0.5 truncate">
                    <span className="font-medium text-slate-800">{task.customerName}</span>
                    <span>•</span>
                    <span>{task.company}</span>
                    <span>•</span>
                    <span className="font-mono text-slate-500">{task.category}</span>
                  </div>
                </div>
              </div>

              {/* Due Date & Owner */}
              <div className="flex items-center gap-3 shrink-0">
                <div className="text-right hidden sm:block">
                  <span className="text-[11px] font-mono text-slate-600 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded">
                    {task.dueDate} {task.dueTime}
                  </span>
                  {task.priority === 'high' && !task.completed && (
                    <span className="block text-[10px] text-[#E96F22] font-semibold mt-0.5">
                      Gấp
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="w-6 h-6 rounded-full bg-slate-200 text-[#002659] font-bold text-[10px] flex items-center justify-center">
                    {task.assignedTo[0]}
                  </span>
                  <button
                    onClick={() => deleteTask(task.id)}
                    className="p-1 text-slate-400 hover:text-rose-600 rounded"
                    title="Xóa task"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
