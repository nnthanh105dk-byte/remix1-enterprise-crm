import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { useTechnical } from '../../context/TechnicalContext';
import { TechnicalCatalogItem } from '../../types/technical';
import {
  BookOpen,
  Search,
  Filter,
  Plus,
  Cpu,
  Layers,
  Wrench,
  CheckCircle2,
  Clock,
  ShieldCheck,
  FileText,
  X,
  Package,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  Sliders,
} from 'lucide-react';

export const TechnicalDirectoryView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { products } = useWarehouse();
  const { technicalCatalog, addCatalogItem, updateCatalogItem } = useTechnical();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGroup, setSelectedGroup] = useState<string>('all');
  const [filterType, setFilterType] = useState<'all' | 'device' | 'service'>('all');
  const [selectedItem, setSelectedItem] = useState<TechnicalCatalogItem | null>(null);

  // Modal thêm hạng mục kỹ thuật mới
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isService, setIsService] = useState(false);
  const [formSku, setFormSku] = useState('');
  const [formName, setFormName] = useState('');
  const [formUnit, setFormUnit] = useState('Bộ');
  const [formTechGroup, setFormTechGroup] = useState<TechnicalCatalogItem['techGroup']>('Hạ tầng mạng & Server');
  const [formWarrantyMonths, setFormWarrantyMonths] = useState(24);
  const [formMaintenanceMonths, setFormMaintenanceMonths] = useState(3);
  const [formTrackSerial, setFormTrackSerial] = useState(true);
  const [formSpecs, setFormSpecs] = useState<{ name: string; value: string }[]>([
    { name: 'Cấu hình tiêu chuẩn', value: '' },
  ]);
  const [formHourlyRate, setFormHourlyRate] = useState(350000);
  const [formStandardHours, setFormStandardHours] = useState(4);
  const [formPackagePrice, setFormPackagePrice] = useState(2500000);

  // Kết hợp thông tin từ kho để lấy Tồn khả dụng (chỉ xem)
  const getProductStockInfo = (sku: string) => {
    const prod = products.find((p) => p.sku === sku);
    if (!prod) return { totalStock: 0, availableStock: 0, costPrice: 0 };
    const total = Object.values(prod.stocks).reduce((a, b) => a + b, 0);
    const avail = Math.max(0, total - (prod.reserved || 0));
    return { totalStock: total, availableStock: avail, costPrice: prod.costPrice };
  };

  const filteredItems = technicalCatalog.filter((item) => {
    if (selectedGroup !== 'all' && item.techGroup !== selectedGroup) return false;
    if (filterType === 'device' && item.isService) return false;
    if (filterType === 'service' && !item.isService) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const matchBasic = item.sku.toLowerCase().includes(q) || item.name.toLowerCase().includes(q);
      const matchSpecs = item.specs.some(
        (s) => s.name.toLowerCase().includes(q) || s.value.toLowerCase().includes(q)
      );
      return matchBasic || matchSpecs;
    }
    return true;
  });

  const handleAddSpecRow = () => {
    setFormSpecs([...formSpecs, { name: '', value: '' }]);
  };

  const handleRemoveSpecRow = (idx: number) => {
    setFormSpecs(formSpecs.filter((_, i) => i !== idx));
  };

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addCatalogItem({
      sku: formSku,
      name: formName,
      category: isService ? 'Dịch vụ Kỹ thuật & Bảo trì' : 'Thiết bị & Vật tư',
      unit: formUnit,
      isService,
      techGroup: formTechGroup,
      specs: formSpecs.filter((s) => s.name.trim() && s.value.trim()),
      defaultWarrantyMonths: formWarrantyMonths,
      trackSerial: isService ? false : formTrackSerial,
      recommendedMaintenanceMonths: formMaintenanceMonths,
      bundledAccessories: [],
      serviceHourlyRate: isService ? formHourlyRate : undefined,
      standardHours: isService ? formStandardHours : undefined,
      packagePrice: isService ? formPackagePrice : undefined,
    });
    setIsCreateModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50">
              <BookOpen className="w-5 h-5" />
            </span>
            Danh Mục Kỹ Thuật (Technical Catalog)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Thư viện chuẩn hóa thiết bị, phụ kiện đi kèm, định mức giờ công và gói dịch vụ kỹ thuật phục vụ bóc tách báo giá
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001c42] shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Thêm hạng mục kỹ thuật</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="relative max-w-sm w-full">
          <input
            type="text"
            placeholder="Tìm theo mã SKU, tên thiết bị, thông số kỹ thuật..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={selectedGroup}
            onChange={(e) => setSelectedGroup(e.target.value)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-medium"
          >
            <option value="all">Tất cả nhóm kỹ thuật</option>
            <option value="Hạ tầng mạng & Server">Hạ tầng mạng &amp; Server</option>
            <option value="Hệ thống Camera & An ninh">Hệ thống Camera &amp; An ninh</option>
            <option value="IoT & Cảm biến">IoT &amp; Cảm biến</option>
            <option value="Cáp & Vật tư phụ trợ">Cáp &amp; Vật tư phụ trợ</option>
            <option value="Dịch vụ Kỹ thuật & Bảo trì">Dịch vụ Kỹ thuật &amp; Bảo trì</option>
          </select>

          <div className="inline-flex rounded-lg bg-slate-100 dark:bg-slate-800 p-0.5">
            <button
              onClick={() => setFilterType('all')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-bold ${
                filterType === 'all'
                  ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Tất cả
            </button>
            <button
              onClick={() => setFilterType('device')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-bold ${
                filterType === 'device'
                  ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Thiết bị &amp; Vật tư
            </button>
            <button
              onClick={() => setFilterType('service')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-bold ${
                filterType === 'service'
                  ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Dịch vụ Kỹ thuật
            </button>
          </div>
        </div>
      </div>

      {/* Main Grid: Danh sách thẻ */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.map((item) => {
          const stock = getProductStockInfo(item.sku);

          return (
            <div
              key={item.id}
              onClick={() => setSelectedItem(item)}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs hover:border-sky-400 dark:hover:border-sky-600 transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      item.isService
                        ? 'bg-purple-100 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300'
                        : 'bg-sky-100 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300'
                    }`}
                  >
                    {item.techGroup}
                  </span>
                  <span className="font-mono text-[10px] text-slate-400 font-semibold">{item.sku}</span>
                </div>

                <h3 className="font-bold text-slate-900 dark:text-white text-sm line-clamp-2 mb-2">
                  {item.name}
                </h3>

                {/* Thông số kỹ thuật tóm tắt */}
                <div className="space-y-1 mb-3 text-xs bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                  {item.specs.slice(0, 3).map((sp, idx) => (
                    <div key={idx} className="flex justify-between gap-2 text-[11px]">
                      <span className="text-slate-400 truncate">{sp.name}:</span>
                      <span className="font-semibold text-slate-700 dark:text-slate-300 truncate max-w-[160px] text-right">
                        {sp.value}
                      </span>
                    </div>
                  ))}
                  {item.specs.length > 3 && (
                    <span className="text-[10px] text-sky-600 font-semibold block text-right">
                      +{item.specs.length - 3} thông số khác...
                    </span>
                  )}
                </div>
              </div>

              {/* Footer thẻ */}
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                {item.isService ? (
                  <div className="text-purple-600 dark:text-purple-400 font-bold">
                    {item.packagePrice ? (
                      <span>{item.packagePrice.toLocaleString()} đ / gói</span>
                    ) : (
                      <span>{item.serviceHourlyRate?.toLocaleString()} đ / giờ</span>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-400 text-[11px]">Tồn khả dụng:</span>
                    <span
                      className={`font-mono font-bold ${
                        stock.availableStock > 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-500'
                      }`}
                    >
                      {stock.availableStock} {item.unit}
                    </span>
                  </div>
                )}

                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-sky-600" />
                  {item.defaultWarrantyMonths}T BH
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Drawer: Chi tiết hạng mục kỹ thuật */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/40 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg h-full shadow-2xl border-l border-slate-200 dark:border-slate-800 flex flex-col p-6 overflow-y-auto space-y-5 animate-in slide-in-from-right duration-200">
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-700">
                  {selectedItem.techGroup}
                </span>
                <h2 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                  {selectedItem.name}
                </h2>
                <span className="font-mono text-xs text-slate-400">SKU: {selectedItem.sku}</span>
              </div>
              <button
                onClick={() => setSelectedItem(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Thông số kỹ thuật đầy đủ */}
            <div>
              <h4 className="font-bold text-slate-800 dark:text-slate-200 text-xs mb-2">
                Thông số kỹ thuật chi tiết:
              </h4>
              <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden text-xs">
                <table className="w-full text-left">
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {selectedItem.specs.map((sp, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="p-2.5 font-medium text-slate-500 bg-slate-50/50 w-1/3">{sp.name}</td>
                        <td className="p-2.5 text-slate-800 dark:text-slate-200 font-semibold">{sp.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Bảo hành & Chu kỳ bảo trì */}
            <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
              <div>
                <span className="text-slate-400 block text-[11px]">Bảo hành tiêu chuẩn:</span>
                <span className="font-bold text-slate-900 dark:text-white">{selectedItem.defaultWarrantyMonths} tháng</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Theo dõi Serial Number:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedItem.trackSerial ? 'Có bắt buộc' : 'Không'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Chu kỳ bảo trì khuyến nghị:</span>
                <span className="font-bold text-slate-900 dark:text-white">
                  {selectedItem.recommendedMaintenanceMonths > 0
                    ? `Định kỳ ${selectedItem.recommendedMaintenanceMonths} tháng/lần`
                    : 'Theo yêu cầu'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[11px]">Đơn vị tính:</span>
                <span className="font-bold text-slate-900 dark:text-white">{selectedItem.unit}</span>
              </div>
            </div>

            {/* Bộ phụ kiện đi kèm nếu có */}
            {selectedItem.bundledAccessories.length > 0 && (
              <div>
                <h4 className="font-bold text-slate-800 dark:text-slate-200 text-xs mb-2">
                  Bộ vật tư / Phụ kiện đi kèm chuẩn:
                </h4>
                <div className="space-y-1.5 text-xs">
                  {selectedItem.bundledAccessories.map((acc, idx) => (
                    <div
                      key={idx}
                      className="p-2 rounded-lg border border-slate-200 dark:border-slate-800 flex justify-between items-center"
                    >
                      <span className="font-semibold text-slate-800 dark:text-slate-200">{acc.name}</span>
                      <span className="font-mono text-slate-500 font-bold">SL: {acc.quantity}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Nút hành động */}
            <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => {
                  showToast('Thêm vào Báo giá kỹ thuật', `Đã chọn ${selectedItem.name} để đưa vào danh sách bóc tách báo giá.`);
                  setActiveModule('technical-quotations');
                }}
                className="w-full py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm"
              >
                <span>Sử dụng bóc tách Báo giá kỹ thuật &rarr;</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Thêm Hạng Mục Kỹ Thuật */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Thêm Mới Vào Danh Mục Kỹ Thuật
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div className="flex items-center gap-4 p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg">
                <label className="flex items-center gap-2 font-bold cursor-pointer">
                  <input
                    type="radio"
                    checked={!isService}
                    onChange={() => setIsService(false)}
                    name="typeChoice"
                  />
                  <span>Thiết bị &amp; Vật tư (Có tồn kho)</span>
                </label>
                <label className="flex items-center gap-2 font-bold cursor-pointer text-purple-600">
                  <input
                    type="radio"
                    checked={isService}
                    onChange={() => setIsService(true)}
                    name="typeChoice"
                  />
                  <span>Dịch vụ Kỹ thuật (Giờ công / Trọn gói)</span>
                </label>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Mã SKU *</label>
                  <input
                    type="text"
                    required
                    placeholder="SRV-xxx hoặc SKU-xxx"
                    value={formSku}
                    onChange={(e) => setFormSku(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Nhóm kỹ thuật *</label>
                  <select
                    value={formTechGroup}
                    onChange={(e) => setFormTechGroup(e.target.value as any)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="Hạ tầng mạng & Server">Hạ tầng mạng &amp; Server</option>
                    <option value="Hệ thống Camera & An ninh">Hệ thống Camera &amp; An ninh</option>
                    <option value="IoT & Cảm biến">IoT &amp; Cảm biến</option>
                    <option value="Cáp & Vật tư phụ trợ">Cáp &amp; Vật tư phụ trợ</option>
                    <option value="Dịch vụ Kỹ thuật & Bảo trì">Dịch vụ Kỹ thuật &amp; Bảo trì</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Tên hạng mục *</label>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: Dịch vụ Triển khai Ảo hóa Server hoặc Switch 48P"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                />
              </div>

              {isService ? (
                <div className="grid grid-cols-3 gap-3 p-3 bg-purple-50 dark:bg-purple-950/30 rounded-lg border border-purple-200 dark:border-purple-800">
                  <div>
                    <label className="block text-purple-900 dark:text-purple-200 font-medium mb-1">Đơn giá giờ công (đ)</label>
                    <input
                      type="number"
                      value={formHourlyRate}
                      onChange={(e) => setFormHourlyRate(Number(e.target.value))}
                      className="w-full p-2 rounded border border-purple-300 dark:border-purple-700 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-purple-900 dark:text-purple-200 font-medium mb-1">Định mức giờ công</label>
                    <input
                      type="number"
                      value={formStandardHours}
                      onChange={(e) => setFormStandardHours(Number(e.target.value))}
                      className="w-full p-2 rounded border border-purple-300 dark:border-purple-700 font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-purple-900 dark:text-purple-200 font-medium mb-1">Giá gói dịch vụ (đ)</label>
                    <input
                      type="number"
                      value={formPackagePrice}
                      onChange={(e) => setFormPackagePrice(Number(e.target.value))}
                      className="w-full p-2 rounded border border-purple-300 dark:border-purple-700 font-mono font-bold"
                    />
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Bảo hành (tháng)</label>
                    <input
                      type="number"
                      value={formWarrantyMonths}
                      onChange={(e) => setFormWarrantyMonths(Number(e.target.value))}
                      className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Chu kỳ bảo trì (tháng)</label>
                    <input
                      type="number"
                      value={formMaintenanceMonths}
                      onChange={(e) => setFormMaintenanceMonths(Number(e.target.value))}
                      className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Đơn vị tính</label>
                    <input
                      type="text"
                      value={formUnit}
                      onChange={(e) => setFormUnit(e.target.value)}
                      className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                    />
                  </div>
                </div>
              )}

              {/* Thông số kỹ thuật động */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="font-bold text-slate-700 dark:text-slate-300">Thông số kỹ thuật chuẩn (Key - Value)</label>
                  <button
                    type="button"
                    onClick={handleAddSpecRow}
                    className="text-sky-600 font-semibold text-[11px] hover:underline"
                  >
                    + Thêm dòng thông số
                  </button>
                </div>
                <div className="space-y-2">
                  {formSpecs.map((sp, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <input
                        type="text"
                        placeholder="Tên thông số (CPU, RAM, Tiêu chuẩn...)"
                        value={sp.name}
                        onChange={(e) => {
                          const updated = [...formSpecs];
                          updated[idx].name = e.target.value;
                          setFormSpecs(updated);
                        }}
                        className="w-1/2 p-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                      <input
                        type="text"
                        placeholder="Giá trị / Quy chuẩn kỹ thuật"
                        value={sp.value}
                        onChange={(e) => {
                          const updated = [...formSpecs];
                          updated[idx].value = e.target.value;
                          setFormSpecs(updated);
                        }}
                        className="w-1/2 p-1.5 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                      {formSpecs.length > 1 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveSpecRow(idx)}
                          className="p-1 text-rose-500 hover:text-rose-700"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#002659] text-white font-semibold shadow-xs"
                >
                  Lưu vào danh mục
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
