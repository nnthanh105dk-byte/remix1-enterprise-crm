import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useLogistics } from '../../context/LogisticsContext';
import { SalesOrder, OrderStatus } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import {
  CheckSquare,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  Building,
  User,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  FileCheck2,
  Truck,
  Package,
  Layers,
  X,
  ExternalLink,
} from 'lucide-react';
import { useColumnVisibility, ColumnDef } from '../../hooks/useColumnVisibility';
import { ColumnVisibilityPicker } from '../../components/common/ColumnVisibilityPicker';

const SALES_ORDER_COLUMNS: ColumnDef[] = [
  { id: 'code', label: 'Số Đơn Hàng', required: true },
  { id: 'customer', label: 'Khách Hàng / Báo Giá' },
  { id: 'dates', label: 'Ngày Đặt / Giao' },
  { id: 'total', label: 'Tổng Tiền' },
  { id: 'approval', label: 'Cấp Duyệt' },
  { id: 'stock', label: 'Tồn Kho' },
  { id: 'status', label: 'Trạng Thái' },
  { id: 'actions', label: 'Thao Tác' },
];

export const SalesOrdersView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { orders, approveOrder, rejectOrder, createContractFromOrder } = useSales();
  const { sendOrderToLogistics } = useLogistics();

  const [activeTab, setActiveTab] = useState<'all' | 'pending_approval'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Selected Order for Detail Drawer
  const [selectedOrder, setSelectedOrder] = useState<SalesOrder | null>(null);

  // Reject Modal
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState('');

  // Pending approval count
  const pendingOrders = orders.filter((o) => o.status === 'Chờ duyệt');
  const pendingCount = pendingOrders.length;

  const {
    columns: colDefs,
    visibleColumns,
    isVisible,
    toggleColumn,
    selectAll,
    resetToDefault,
  } = useColumnVisibility('sales_orders', SALES_ORDER_COLUMNS);

  const filteredOrders = orders.filter((o) => {
    if (activeTab === 'pending_approval' && o.status !== 'Chờ duyệt') return false;
    if (statusFilter !== 'all' && o.status !== statusFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        o.code.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        (o.quotationCode && o.quotationCode.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handleApprove = (order: SalesOrder) => {
    approveOrder(order.id, 'Trần Minh Đức (Giám đốc Sales)');
    setSelectedOrder((prev) => (prev ? { ...prev, status: 'Đã duyệt' } : null));
  };

  const handleRejectSubmit = () => {
    if (!selectedOrder || !rejectReason.trim()) {
      showToast('Lỗi', 'Bắt buộc nhập lý do từ chối đơn hàng.', 'warning');
      return;
    }
    rejectOrder(selectedOrder.id, rejectReason);
    setSelectedOrder((prev) => (prev ? { ...prev, status: 'Từ chối', rejectionReason: rejectReason } : null));
    setIsRejectModalOpen(false);
    setRejectReason('');
  };

  const handleCreateContract = (order: SalesOrder) => {
    createContractFromOrder(order.id);
    setActiveModule('contracts');
  };

  const handleCreateStockOut = (order: SalesOrder) => {
    showToast(
      'Yêu cầu xuất kho',
      `Đã chuyển yêu cầu xuất kho cho đơn ${order.code} sang phân hệ Quản lý kho > Xuất kho.`,
      'success'
    );
    setActiveModule('inventory-stock-out');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
                <CheckSquare className="w-5 h-5" />
              </span>
              Đơn Hàng &amp; Phê Duyệt (Sales Orders &amp; Booking Approval)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {orders.length} Đơn hàng
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Kế thừa từ Báo giá đã chấp thuận, kiểm tra khả dụng tồn kho và phê duyệt đa cấp theo hạn mức doanh nghiệp.
          </p>
        </div>
      </div>

      {/* 2 Tabs: Tất cả đơn hàng & Chờ tôi duyệt */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'all'
              ? 'bg-sky-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          Tất cả đơn hàng ({orders.length})
        </button>

        <button
          onClick={() => setActiveTab('pending_approval')}
          className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
            activeTab === 'pending_approval'
              ? 'bg-amber-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Hộp chờ duyệt của tôi</span>
          {pendingCount > 0 && (
            <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-rose-500 text-white font-mono">
              {pendingCount}
            </span>
          )}
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo số đơn (DH-...), khách hàng, báo giá..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">Trạng thái:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="Chờ duyệt">Chờ duyệt</option>
              <option value="Đã duyệt">Đã duyệt</option>
              <option value="Từ chối">Từ chối</option>
              <option value="Đang thực hiện">Đang thực hiện</option>
              <option value="Hoàn tất">Hoàn tất</option>
              <option value="Hủy">Hủy</option>
            </select>
          </div>

          <ColumnVisibilityPicker
            columns={colDefs}
            visibleColumns={visibleColumns}
            onToggleColumn={toggleColumn}
            onSelectAll={selectAll}
            onReset={resetToDefault}
          />
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800 uppercase text-[11px]">
              <tr>
                {isVisible('code') && <th className="py-3 px-3">Số Đơn Hàng</th>}
                {isVisible('customer') && <th className="py-3 px-3">Khách Hàng / Báo Giá</th>}
                {isVisible('dates') && <th className="py-3 px-3">Ngày Đặt / Giao</th>}
                {isVisible('total') && <th className="py-3 px-3 text-right">Tổng Tiền</th>}
                {isVisible('approval') && <th className="py-3 px-3">Cấp Duyệt</th>}
                {isVisible('stock') && <th className="py-3 px-3">Tồn Kho</th>}
                {isVisible('status') && <th className="py-3 px-3">Trạng Thái</th>}
                {isVisible('actions') && <th className="py-3 px-3 text-right">Thao Tác</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td
                    colSpan={colDefs.filter((c) => isVisible(c.id)).length || 1}
                    className="py-8 text-center text-slate-400"
                  >
                    Không tìm thấy đơn hàng nào phù hợp với bộ lọc.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => (
                  <tr
                    key={order.id}
                    onClick={() => setSelectedOrder(order)}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                  >
                    {isVisible('code') && (
                      <td className="py-3 px-3">
                        <span className="font-mono font-bold text-sky-600 dark:text-sky-400 block">
                          {order.code}
                        </span>
                        <span className="text-[10px] text-slate-400">{order.items.length} mặt hàng</span>
                      </td>
                    )}

                    {isVisible('customer') && (
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900 dark:text-white">
                          {order.customerName}
                        </div>
                        {order.quotationCode && (
                          <span className="font-mono text-[11px] text-slate-400">
                            Từ: {order.quotationCode}
                          </span>
                        )}
                      </td>
                    )}

                    {isVisible('dates') && (
                      <td className="py-3 px-3 font-mono text-[11px]">
                        <div>Đặt: {order.orderDate}</div>
                        <div className="text-slate-400">Giao: {order.expectedDeliveryDate}</div>
                      </td>
                    )}

                    {isVisible('total') && (
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                        {order.totalAmount.toLocaleString()} ₫
                      </td>
                    )}

                    {isVisible('approval') && (
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {order.approvalLevel}
                        </span>
                      </td>
                    )}

                    {isVisible('stock') && (
                      <td className="py-3 px-3">
                        {order.stockSufficient ? (
                          <span className="text-emerald-600 font-semibold flex items-center gap-1 text-[11px]">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Đủ tồn kho
                          </span>
                        ) : (
                          <span className="text-amber-600 font-bold flex items-center gap-1 text-[11px]" title={order.stockWarnings.join('\n')}>
                            <AlertTriangle className="w-3.5 h-3.5" /> Thiếu tồn kho
                          </span>
                        )}
                      </td>
                    )}

                    {isVisible('status') && (
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            order.status === 'Đã duyệt'
                              ? 'bg-emerald-100 text-emerald-800'
                              : order.status === 'Chờ duyệt'
                              ? 'bg-amber-100 text-amber-800'
                              : order.status === 'Từ chối'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {order.status}
                        </span>
                      </td>
                    )}

                    {isVisible('actions') && (
                      <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setSelectedOrder(order)}
                          className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-200 text-xs cursor-pointer"
                        >
                          Chi tiết →
                        </button>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Right Drawer: Chi Tiết Đơn Hàng & Thao Tác Phê Duyệt / Hợp Đồng */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 h-full overflow-y-auto flex flex-col p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs px-2.5 py-1 rounded bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-bold">
                  {selectedOrder.code}
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-semibold">
                  {selectedOrder.status}
                </span>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Chain Bar */}
            <div className="mt-4">
              <DocumentChainBar currentType="order" chain={selectedOrder.chain} />
            </div>

            {/* Content */}
            <div className="mt-5 space-y-4 text-xs">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  {selectedOrder.customerName}
                </h2>
                <p className="text-slate-500 font-medium">Báo giá gốc: {selectedOrder.quotationCode || 'N/A'}</p>
              </div>

              {/* Cảnh báo thiếu tồn kho nếu có */}
              {!selectedOrder.stockSufficient && (
                <div className="bg-amber-50 dark:bg-amber-950/40 p-3.5 rounded-xl border border-amber-300 dark:border-amber-800 text-amber-800 dark:text-amber-200 text-xs">
                  <span className="font-bold flex items-center gap-1.5 mb-1">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    Cảnh báo tồn kho khả dụng không đủ:
                  </span>
                  <ul className="list-disc pl-4 space-y-0.5">
                    {selectedOrder.stockWarnings.map((w, idx) => (
                      <li key={idx}>{w}</li>
                    ))}
                  </ul>
                  <p className="mt-2 text-[11px] text-amber-700">
                    Bạn vẫn có thể duyệt đơn để chuyển lệnh nhập hàng bổ sung cho bộ phận Kho.
                  </p>
                </div>
              )}

              {/* Thông tin đơn */}
              <div className="grid grid-cols-2 gap-3 bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-slate-400 block text-[11px]">Tổng giá trị đơn:</span>
                  <span className="text-base font-bold font-mono text-emerald-600 dark:text-emerald-400">
                    {selectedOrder.totalAmount.toLocaleString()} ₫
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Cấp độ phê duyệt:</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {selectedOrder.approvalLevel}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Ngày giao dự kiến:</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono">
                    {selectedOrder.expectedDeliveryDate}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Người phụ trách:</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {selectedOrder.assignedTo}
                  </span>
                </div>
              </div>

              {/* Dòng hàng */}
              <div>
                <h4 className="font-bold text-slate-700 dark:text-slate-300 mb-2">Chi tiết mặt hàng trong đơn:</h4>
                <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold">
                      <tr>
                        <th className="py-2 px-2.5">Sản Phẩm / SKU</th>
                        <th className="py-2 px-2.5 text-center">SL</th>
                        <th className="py-2 px-2.5 text-right">Đơn Giá</th>
                        <th className="py-2 px-2.5 text-right">Thành Tiền</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {selectedOrder.items.map((item, idx) => (
                        <tr key={idx}>
                          <td className="py-2 px-2.5">
                            <div className="font-bold text-slate-900 dark:text-white">{item.productName}</div>
                            <div className="font-mono text-[10px] text-slate-400">{item.sku}</div>
                          </td>
                          <td className="py-2 px-2.5 text-center font-mono font-bold">{item.quantity}</td>
                          <td className="py-2 px-2.5 text-right font-mono">{item.unitPrice.toLocaleString()} ₫</td>
                          <td className="py-2 px-2.5 text-right font-mono font-bold">{item.total.toLocaleString()} ₫</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Nhật ký duyệt nếu đã duyệt */}
              {selectedOrder.approvedBy && (
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 rounded-lg text-emerald-900 dark:text-emerald-200">
                  <span className="font-bold block">Thông tin phê duyệt:</span>
                  <p className="text-[11px] mt-0.5">Duyệt bởi: {selectedOrder.approvedBy}</p>
                  <p className="text-[10px] text-emerald-700 font-mono">Thời gian: {selectedOrder.approvedAt}</p>
                </div>
              )}

              {/* Nhật ký từ chối nếu có */}
              {selectedOrder.rejectionReason && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 rounded-lg text-rose-900 dark:text-rose-200">
                  <span className="font-bold block">Lý do từ chối:</span>
                  <p className="text-[11px] mt-0.5">{selectedOrder.rejectionReason}</p>
                </div>
              )}

              {/* Nút Hành Động Xuyên Suốt */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
                {selectedOrder.status === 'Chờ duyệt' && (
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setIsRejectModalOpen(true)}
                      className="flex-1 py-2 px-3 rounded-xl border border-rose-300 text-rose-600 font-bold hover:bg-rose-50"
                    >
                      Từ Chối Đơn
                    </button>
                    <button
                      onClick={() => handleApprove(selectedOrder)}
                      className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-700 shadow-sm"
                    >
                      Phê Duyệt Đơn Hàng
                    </button>
                  </div>
                )}

                {/* Trạng thái xử lý Logistics */}
                {selectedOrder.logisticsStatus && (
                  <div className="p-3 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-lg text-sky-900 dark:text-sky-200">
                    <div className="flex items-center justify-between">
                      <span className="font-bold flex items-center gap-1.5">
                        <Truck className="w-4 h-4 text-sky-600" />
                        Tiến độ Logistics:
                      </span>
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-300">
                        {selectedOrder.logisticsStatus}
                      </span>
                    </div>
                    {selectedOrder.logisticsRejectionReason && (
                      <p className="text-[11px] text-rose-600 dark:text-rose-400 mt-1">
                        Phản hồi từ Logistics: {selectedOrder.logisticsRejectionReason}
                      </p>
                    )}
                  </div>
                )}

                {selectedOrder.status === 'Đã duyệt' && (
                  <div className="space-y-2">
                    {(!selectedOrder.logisticsStatus || selectedOrder.logisticsStatus === 'Từ chối' || selectedOrder.logisticsStatus === 'Cần bổ sung') && (
                      <button
                        onClick={() => {
                          sendOrderToLogistics(selectedOrder.id);
                          setSelectedOrder((prev) =>
                            prev ? { ...prev, logisticsStatus: 'Chờ xác nhận' } : null
                          );
                        }}
                        className="w-full py-2.5 rounded-xl bg-sky-600 text-white font-bold flex items-center justify-center gap-2 hover:bg-sky-700 shadow-sm"
                      >
                        <Truck className="w-4 h-4 text-white" />
                        <span>Gửi Sang Bộ Phận Logistics &rarr;</span>
                      </button>
                    )}

                    <button
                      onClick={() => handleCreateContract(selectedOrder)}
                      className="w-full py-2.5 rounded-xl bg-indigo-600 text-white font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 shadow-sm"
                    >
                      <FileCheck2 className="w-4 h-4" />
                      <span>Tạo Hợp Đồng Từ Đơn Này →</span>
                    </button>

                    <button
                      onClick={() => handleCreateStockOut(selectedOrder)}
                      className="w-full py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold flex items-center justify-center gap-2 hover:bg-slate-200 border border-slate-300 dark:border-slate-700"
                    >
                      <Truck className="w-4 h-4 text-sky-600" />
                      <span>Tạo Yêu Cầu Xuất Kho (WMS) →</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Từ Chối Đơn Hàng */}
      {isRejectModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl text-xs">
            <h3 className="font-bold text-rose-600 text-base mb-2">
              Từ Chối Đơn Hàng: {selectedOrder.code}
            </h3>
            <p className="text-slate-500 mb-3">
              Vui lòng nhập lý do từ chối để nhân viên kinh doanh điều chỉnh lại báo giá hoặc tiến độ giao.
            </p>
            <div>
              <label className="block text-slate-600 font-semibold mb-1">Lý do từ chối *</label>
              <textarea
                rows={3}
                required
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                placeholder="Thiếu hàng tồn kho, điều khoản thanh toán rủi ro..."
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>
            <div className="flex items-center justify-end gap-2 mt-4">
              <button
                onClick={() => setIsRejectModalOpen(false)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600 font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={handleRejectSubmit}
                className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
              >
                Xác Nhận Từ Chối
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
