import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useTechnical } from '../../context/TechnicalContext';
import { SalesContract } from '../../types/sales';
import {
  Clock,
  Search,
  Filter,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  DollarSign,
  Calendar,
  CheckCircle2,
  Building,
  User,
  Plus,
} from 'lucide-react';

export const TechnicalExpiringContractsView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { contracts } = useSales();
  const {
    customerEquipments,
    createRenewalOpportunityFromContract,
  } = useTechnical();

  const [searchTerm, setSearchTerm] = useState('');
  const [urgencyFilter, setUrgencyFilter] = useState<'all' | 'expired' | '30days' | '60days' | '90days'>('all');

  const today = new Date('2026-10-04').getTime();

  // Helper tính số ngày còn lại
  const getDaysRemaining = (endDateStr: string) => {
    const end = new Date(endDateStr).getTime();
    return Math.ceil((end - today) / (1000 * 60 * 60 * 24));
  };

  // Tính trạng thái hạn
  const getExpiryStatus = (days: number) => {
    if (days < 0) return { label: 'Đã hết hạn', color: 'bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300' };
    if (days <= 30) return { label: 'Cận hạn (≤ 30 ngày)', color: 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300' };
    if (days <= 60) return { label: 'Cận hạn (31 - 60 ngày)', color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-950/60 dark:text-yellow-300' };
    return { label: 'Còn hạn (> 60 ngày)', color: 'bg-sky-100 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300' };
  };

  const processedContracts = contracts
    .filter((c) => c.status === 'Đang hiệu lực' || c.status === 'Hết hạn')
    .map((c) => {
      const days = getDaysRemaining(c.endDate);
      const statusObj = getExpiryStatus(days);
      const eqCount = customerEquipments.filter((eq) => eq.customerId === c.customerId).length;
      return {
        ...c,
        daysRemaining: days,
        urgency: statusObj,
        equipmentCount: eqCount,
      };
    });

  const filteredList = processedContracts.filter((c) => {
    if (urgencyFilter === 'expired' && c.daysRemaining >= 0) return false;
    if (urgencyFilter === '30days' && (c.daysRemaining < 0 || c.daysRemaining > 30)) return false;
    if (urgencyFilter === '60days' && (c.daysRemaining <= 30 || c.daysRemaining > 60)) return false;
    if (urgencyFilter === '90days' && (c.daysRemaining <= 60 || c.daysRemaining > 90)) return false;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        c.contractNumber.toLowerCase().includes(q) ||
        c.customerName.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // KPI Calculations
  const expiredCount = processedContracts.filter((c) => c.daysRemaining < 0).length;
  const in30DaysCount = processedContracts.filter((c) => c.daysRemaining >= 0 && c.daysRemaining <= 30).length;
  const in60DaysCount = processedContracts.filter((c) => c.daysRemaining > 30 && c.daysRemaining <= 60).length;
  const totalRenewalValue = processedContracts
    .filter((c) => c.daysRemaining <= 60)
    .reduce((sum, c) => sum + c.totalValue, 0);

  const handlePushToSales = (contractId: string) => {
    createRenewalOpportunityFromContract(contractId);
    showToast(
      'Chuyển cơ hội tái ký',
      'Đã tự động tạo Deal mới trong Quản lý Sales > Cơ hội bán hàng để Sales tiếp cận gia hạn.',
      'success'
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
              <Clock className="w-5 h-5" />
            </span>
            Hợp Đồng Sắp Hết Hạn &amp; Tái Ký (Expiring Contracts)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Theo dõi thời hạn hợp đồng bảo trì, SLA dịch vụ kỹ thuật cận hạn để chủ động tạo cơ hội gia hạn chuyển về bộ phận Sales
          </p>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-rose-200 dark:border-rose-900 shadow-xs">
          <span className="text-slate-400 text-xs block">Đã quá hạn bảo trì</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-bold text-rose-600 font-mono">{expiredCount}</span>
            <span className="p-2 rounded-lg bg-rose-50 text-rose-600 text-xs font-bold">Cần xử lý</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-amber-200 dark:border-amber-900 shadow-xs">
          <span className="text-slate-400 text-xs block">Hết hạn trong 30 ngày</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-bold text-amber-600 font-mono">{in30DaysCount}</span>
            <span className="p-2 rounded-lg bg-amber-50 text-amber-600 text-xs font-bold">Cận kề</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-yellow-200 dark:border-yellow-900 shadow-xs">
          <span className="text-slate-400 text-xs block">Hết hạn trong 31 - 60 ngày</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-2xl font-bold text-yellow-600 font-mono">{in60DaysCount}</span>
            <span className="p-2 rounded-lg bg-yellow-50 text-yellow-600 text-xs font-bold">Chuẩn bị</span>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-emerald-200 dark:border-emerald-900 shadow-xs">
          <span className="text-slate-400 text-xs block">Quy mô giá trị cần tái ký</span>
          <div className="flex items-center justify-between mt-1">
            <span className="text-lg font-bold text-emerald-600 font-mono">
              {(totalRenewalValue / 1000000).toFixed(0)} tr đ
            </span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="relative max-w-sm w-full">
          <input
            type="text"
            placeholder="Tìm theo số HĐ, tên khách hàng..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={urgencyFilter}
            onChange={(e) => setUrgencyFilter(e.target.value as any)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-medium"
          >
            <option value="all">Tất cả mức độ cận hạn</option>
            <option value="expired">Đã hết hạn (&lt; 0 ngày)</option>
            <option value="30days">Cận hạn &le; 30 ngày</option>
            <option value="60days">Cận hạn 31 - 60 ngày</option>
            <option value="90days">Cận hạn 61 - 90 ngày</option>
          </select>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden text-xs">
        <table className="w-full text-left">
          <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300">
            <tr>
              <th className="p-3">Số Hợp Đồng &amp; Tên Dự Án</th>
              <th className="p-3">Khách Hàng</th>
              <th className="p-3 text-center">Số Thiết Bị Quản Lý</th>
              <th className="p-3 text-center">Ngày Hết Hạn</th>
              <th className="p-3 text-center">Thời Gian Còn Lại</th>
              <th className="p-3 text-right">Giá Trị HĐ (đ)</th>
              <th className="p-3 text-center w-48">Hành Động Điểm Nối</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-slate-400 italic">
                  Không có hợp đồng nào trong ngưỡng cảnh báo đã chọn.
                </td>
              </tr>
            ) : (
              filteredList.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="p-3">
                    <span className="font-mono font-bold text-sky-600 block">{c.contractNumber}</span>
                    <span className="font-semibold text-slate-900 dark:text-white">{c.title}</span>
                  </td>
                  <td className="p-3">
                    <div className="font-semibold text-slate-900 dark:text-white">{c.customerName}</div>
                    <span className="text-[11px] text-slate-400">Sales: {c.manager}</span>
                  </td>
                  <td className="p-3 text-center font-mono font-bold">
                    {c.equipmentCount} thiết bị
                  </td>
                  <td className="p-3 text-center font-mono font-bold text-slate-900 dark:text-white">
                    {c.endDate}
                  </td>
                  <td className="p-3 text-center">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${c.urgency.color}`}>
                      {c.daysRemaining < 0
                        ? `Quá hạn ${Math.abs(c.daysRemaining)} ngày`
                        : `Còn ${c.daysRemaining} ngày`}
                    </span>
                  </td>
                  <td className="p-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                    {c.totalValue.toLocaleString()} đ
                  </td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => handlePushToSales(c.id)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-[11px] shadow-xs"
                      title="Tạo Deal mới trong Quản lý Sales > Cơ hội bán hàng"
                    >
                      <ArrowRight className="w-3.5 h-3.5" />
                      <span>Đẩy Cơ Hội Về Sales &rarr;</span>
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
