import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useAccounting } from '../../context/AccountingContext';
import {
  FileText,
  Download,
  Printer,
  Calendar,
  Filter,
  TrendingUp,
  TrendingDown,
  BarChart3,
  PieChart,
  Layers,
  Users,
  AlertTriangle,
  Info,
  DollarSign,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck,
} from 'lucide-react';

export const AccountingReportsView: React.FC = () => {
  const { showToast } = useCRM();
  const { plStatement, revenueByProduct, revenueBySalesStaff, customerDebts } = useAccounting();

  const [activeReportTab, setActiveReportTab] = useState<'pnl' | 'aging' | 'profit_analysis'>('pnl');
  const [selectedPeriod, setSelectedPeriod] = useState('Quý 1/2026');
  const [displayUnit, setDisplayUnit] = useState<'vnd' | 'million'>('vnd');

  // Format currency helper
  const fmt = (val: number) => {
    if (displayUnit === 'million') {
      return `${(val / 1000000).toLocaleString('vi-VN', { maximumFractionDigits: 1 })} tr`;
    }
    return `${val.toLocaleString('vi-VN')} đ`;
  };

  // Aging totals
  const agingTotals = {
    current: customerDebts.reduce((sum, c) => sum + c.aging.current, 0),
    days1_30: customerDebts.reduce((sum, c) => sum + c.aging.days1_30, 0),
    days31_60: customerDebts.reduce((sum, c) => sum + c.aging.days31_60, 0),
    days61_90: customerDebts.reduce((sum, c) => sum + c.aging.days61_90, 0),
    over90: customerDebts.reduce((sum, c) => sum + c.aging.over90, 0),
  };
  const totalReceivables = Object.values(agingTotals).reduce((a, b) => a + b, 0);

  // Dự phòng nợ phải thu khó đòi ước tính (Ví dụ: 10% cho 31-60, 30% cho 61-90, 50% cho >90)
  const estimatedBadDebtProvision =
    agingTotals.days31_60 * 0.1 + agingTotals.days61_90 * 0.3 + agingTotals.over90 * 0.5;

  return (
    <div className="space-y-6">
      {/* 1. Header with Mandatory Legal Disclaimer */}
      <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                Báo cáo Quản trị Doanh nghiệp
              </span>
              <span className="text-xs text-slate-400">P&L • Aging • Margin Analysis</span>
            </div>
            <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-1">
              Báo cáo Tài chính Quản trị (Financial Reports)
            </h1>
          </div>

          <div className="flex items-center gap-2.5">
            <select
              value={selectedPeriod}
              onChange={(e) => setSelectedPeriod(e.target.value)}
              className="px-3 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200 outline-none"
            >
              <option value="Tháng 03/2026">Tháng 03/2026</option>
              <option value="Quý 1/2026">Quý 1/2026 (01/01 - 31/03/2026)</option>
              <option value="Năm 2026">Cả năm 2026</option>
            </select>

            <div className="flex items-center border border-slate-300 dark:border-slate-600 rounded-lg p-0.5 bg-slate-50 dark:bg-slate-900">
              <button
                onClick={() => setDisplayUnit('vnd')}
                className={`px-2.5 py-1 text-xs font-semibold rounded ${
                  displayUnit === 'vnd'
                    ? 'bg-white dark:bg-slate-800 text-emerald-600 shadow-sm'
                    : 'text-slate-500'
                }`}
              >
                VND
              </button>
              <button
                onClick={() => setDisplayUnit('million')}
                className={`px-2.5 py-1 text-xs font-semibold rounded ${
                  displayUnit === 'million'
                    ? 'bg-white dark:bg-slate-800 text-emerald-600 shadow-sm'
                    : 'text-slate-500'
                }`}
              >
                Triệu đ
              </button>
            </div>

            <button
              onClick={() =>
                showToast('In báo cáo', 'Đã chuyển báo cáo quản trị ra định dạng in ấn PDF')
              }
              className="p-2 border border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg text-slate-700 dark:text-slate-200"
              title="In báo cáo"
            >
              <Printer className="w-4 h-4" />
            </button>

            <button
              onClick={() =>
                showToast('Xuất báo cáo', 'Đã tải xuống file Excel báo cáo tài chính quản trị')
              }
              className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm"
            >
              <Download className="w-4 h-4" />
              Xuất Excel
            </button>
          </div>
        </div>

        {/* ⚠️ Mandatory Legal Disclaimer Notice */}
        <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 rounded-lg flex items-center gap-2.5 text-xs text-amber-800 dark:text-amber-300">
          <Info className="w-4 h-4 text-amber-600 flex-shrink-0" />
          <span>
            <strong>Lưu ý:</strong> Báo cáo quản trị, không thay thế báo cáo tài chính theo quy định
            của pháp luật kế toán và cơ quan thuế. Số liệu được tổng hợp tự động từ hệ thống chứng từ
            CRM, Sales, Kho, Logistics và Nhân sự.
          </span>
        </div>
      </div>

      {/* 2. Main Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 rounded-t-xl">
        <button
          onClick={() => setActiveReportTab('pnl')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeReportTab === 'pnl'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          1. Kết quả kinh doanh quản trị (P&L)
        </button>

        <button
          onClick={() => setActiveReportTab('aging')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeReportTab === 'aging'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <PieChart className="w-4 h-4" />
          2. Phân tích tuổi nợ & Dự phòng
        </button>

        <button
          onClick={() => setActiveReportTab('profit_analysis')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeReportTab === 'profit_analysis'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Layers className="w-4 h-4" />
          3. Phân tích Biên LN theo Sản phẩm / Sales
        </button>
      </div>

      {/* ======================================================== */}
      {/* TAB 1: BÁO CÁO P&L QUẢN TRỊ */}
      {/* ======================================================== */}
      {activeReportTab === 'pnl' && (
        <div className="space-y-6">
          {/* Highlight KPI Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Doanh thu thuần</span>
              <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                {fmt(plStatement.netRevenue)}
              </div>
              <span className="text-[11px] text-emerald-600 flex items-center gap-0.5 mt-0.5">
                <ArrowUpRight className="w-3 h-3" />
                +{plStatement.previousPeriodComparison?.netRevenueChangePct}% cùng kỳ
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Lợi nhuận gộp (Gross Profit)</span>
              <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                {fmt(plStatement.grossProfit)}
              </div>
              <span className="text-[11px] font-mono text-slate-500">
                Biên LNG: <strong>{plStatement.grossMarginPercentage}%</strong>
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Lợi nhuận hoạt động (EBIT)</span>
              <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
                {fmt(plStatement.operatingProfit)}
              </div>
              <span className="text-[11px] font-mono text-slate-500">
                Tỷ suất EBIT: <strong>{plStatement.operatingMarginPercentage}%</strong>
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/20 dark:bg-emerald-950/10 shadow-sm">
              <span className="text-xs font-medium text-emerald-800 dark:text-emerald-300">
                Lợi nhuận trước thuế quản trị
              </span>
              <div className="text-lg font-bold text-emerald-700 dark:text-emerald-400 mt-1">
                {fmt(plStatement.netProfitBeforeTax)}
              </div>
              <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-0.5 mt-0.5">
                <ArrowUpRight className="w-3 h-3" />
                Tỷ suất LN ròng: {plStatement.netMarginPercentage}%
              </span>
            </div>
          </div>

          {/* Detailed Statement Table */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <h2 className="section-title">
                Bảng Tổng Hợp Doanh Thu - Giá Vốn - Lợi Nhuận ({selectedPeriod})
              </h2>
              <span className="text-xs text-slate-400 font-mono">Đơn vị tính: {displayUnit === 'million' ? 'Triệu VND' : 'VND'}</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-900 uppercase font-semibold text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="px-5 py-3">Chỉ tiêu tài chính</th>
                    <th className="px-4 py-3 text-right">Mã số</th>
                    <th className="px-5 py-3 text-right font-bold text-slate-900 dark:text-white">
                      Thực hiện kỳ này
                    </th>
                    <th className="px-5 py-3 text-right">Tỷ trọng / Doanh thu</th>
                    <th className="px-5 py-3 text-right">Nguồn dữ liệu đối chiếu</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {/* 1. Doanh thu */}
                  <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-750">
                    <td className="px-5 py-3 font-bold text-slate-900 dark:text-white font-sans">
                      1. Doanh thu bán hàng và cung cấp dịch vụ
                    </td>
                    <td className="px-4 py-3 text-right text-slate-400">01</td>
                    <td className="px-5 py-3 text-right font-bold text-slate-900 dark:text-white">
                      {fmt(plStatement.grossRevenue)}
                    </td>
                    <td className="px-5 py-3 text-right text-slate-500">101.0%</td>
                    <td className="px-5 py-3 text-right text-slate-500 font-sans">
                      Hóa đơn Sales đã xuất
                    </td>
                  </tr>

                  <tr className="text-slate-500">
                    <td className="px-5 py-2.5 pl-9 font-sans">
                      - Các khoản giảm trừ doanh thu (chiết khấu, hàng trả lại)
                    </td>
                    <td className="px-4 py-2.5 text-right">02</td>
                    <td className="px-5 py-2.5 text-right text-red-500">
                      -{fmt(plStatement.revenueDeductions)}
                    </td>
                    <td className="px-5 py-2.5 text-right">1.0%</td>
                    <td className="px-5 py-2.5 text-right font-sans">Chứng từ điều chỉnh giảm</td>
                  </tr>

                  <tr className="bg-emerald-50/30 dark:bg-emerald-950/20 font-bold">
                    <td className="px-5 py-3 text-emerald-900 dark:text-emerald-300 font-sans">
                      2. Doanh thu thuần (Mã 01 - Mã 02)
                    </td>
                    <td className="px-4 py-3 text-right text-emerald-700">10</td>
                    <td className="px-5 py-3 text-right text-emerald-600 dark:text-emerald-400">
                      {fmt(plStatement.netRevenue)}
                    </td>
                    <td className="px-5 py-3 text-right text-emerald-700">100.0%</td>
                    <td className="px-5 py-3 text-right font-sans">Đã đối soát kế toán</td>
                  </tr>

                  {/* 2. Giá vốn */}
                  <tr className="text-slate-700 dark:text-slate-300">
                    <td className="px-5 py-3 font-bold font-sans">
                      3. Giá vốn hàng bán (COGS)
                    </td>
                    <td className="px-4 py-3 text-right text-slate-400">11</td>
                    <td className="px-5 py-3 text-right text-red-600 font-bold">
                      -{fmt(plStatement.cogs)}
                    </td>
                    <td className="px-5 py-3 text-right text-slate-500">68.0%</td>
                    <td className="px-5 py-3 text-right font-sans">Phiếu xuất kho & Hóa đơn mua</td>
                  </tr>

                  <tr className="bg-blue-50/30 dark:bg-blue-950/20 font-bold">
                    <td className="px-5 py-3 text-blue-900 dark:text-blue-300 font-sans">
                      4. Lợi nhuận gộp (Mã 10 - Mã 11)
                    </td>
                    <td className="px-4 py-3 text-right text-blue-700">20</td>
                    <td className="px-5 py-3 text-right text-blue-600 dark:text-blue-400">
                      {fmt(plStatement.grossProfit)}
                    </td>
                    <td className="px-5 py-3 text-right text-blue-700">
                      {plStatement.grossMarginPercentage}%
                    </td>
                    <td className="px-5 py-3 text-right font-sans">Biên lợi nhuận gộp</td>
                  </tr>

                  {/* 3. Chi phí hoạt động */}
                  <tr className="text-slate-500">
                    <td className="px-5 py-2.5 pl-9 font-sans">
                      - Chi phí bán hàng (Vận chuyển logistics, hoa hồng Sales)
                    </td>
                    <td className="px-4 py-2.5 text-right">21</td>
                    <td className="px-5 py-2.5 text-right text-red-500">
                      -{fmt(plStatement.sellingExpenses)}
                    </td>
                    <td className="px-5 py-2.5 text-right">7.2%</td>
                    <td className="px-5 py-2.5 text-right font-sans">Cước xe, hoa hồng KD</td>
                  </tr>

                  <tr className="text-slate-500">
                    <td className="px-5 py-2.5 pl-9 font-sans">
                      - Chi phí quản lý doanh nghiệp (Lương & BHXH nhân viên, VP)
                    </td>
                    <td className="px-4 py-2.5 text-right">22</td>
                    <td className="px-5 py-2.5 text-right text-red-500">
                      -{fmt(plStatement.adminExpenses)}
                    </td>
                    <td className="px-5 py-2.5 text-right">12.1%</td>
                    <td className="px-5 py-2.5 text-right font-sans">Quỹ lương HR 50 người & BHXH</td>
                  </tr>

                  <tr className="bg-purple-50/30 dark:bg-purple-950/20 font-bold">
                    <td className="px-5 py-3 text-purple-900 dark:text-purple-300 font-sans">
                      5. Lợi nhuận thuần từ hoạt động kinh doanh (EBIT)
                    </td>
                    <td className="px-4 py-3 text-right text-purple-700">30</td>
                    <td className="px-5 py-3 text-right text-purple-600 dark:text-purple-400">
                      {fmt(plStatement.operatingProfit)}
                    </td>
                    <td className="px-5 py-3 text-right text-purple-700">
                      {plStatement.operatingMarginPercentage}%
                    </td>
                    <td className="px-5 py-3 text-right font-sans">Hiệu quả cốt lõi</td>
                  </tr>

                  {/* 4. Tài chính */}
                  <tr className="text-slate-500">
                    <td className="px-5 py-2.5 pl-9 font-sans">+ Doanh thu tài chính (Lãi tiền gửi)</td>
                    <td className="px-4 py-2.5 text-right">31</td>
                    <td className="px-5 py-2.5 text-right text-emerald-600">
                      +{fmt(plStatement.financialIncome)}
                    </td>
                    <td className="px-5 py-2.5 text-right">0.7%</td>
                    <td className="px-5 py-2.5 text-right font-sans">Sổ quỹ & Lãi ngân hàng</td>
                  </tr>

                  <tr className="text-slate-500">
                    <td className="px-5 py-2.5 pl-9 font-sans">- Chi phí tài chính (Phí ngân hàng)</td>
                    <td className="px-4 py-2.5 text-right">32</td>
                    <td className="px-5 py-2.5 text-right text-red-500">
                      -{fmt(plStatement.financialExpenses)}
                    </td>
                    <td className="px-5 py-2.5 text-right">0.4%</td>
                    <td className="px-5 py-2.5 text-right font-sans">Phí dịch vụ VCB/TCB</td>
                  </tr>

                  {/* 5. Lợi nhuận trước thuế */}
                  <tr className="bg-emerald-100/40 dark:bg-emerald-900/30 font-bold text-sm">
                    <td className="px-5 py-3.5 text-slate-900 dark:text-white font-sans">
                      6. TỔNG LỢI NHUẬN TRƯỚC THUẾ QUẢN TRỊ
                    </td>
                    <td className="px-4 py-3.5 text-right text-slate-500">50</td>
                    <td className="px-5 py-3.5 text-right text-emerald-600 dark:text-emerald-400 font-bold text-base">
                      {fmt(plStatement.netProfitBeforeTax)}
                    </td>
                    <td className="px-5 py-3.5 text-right text-emerald-700">
                      {plStatement.netMarginPercentage}%
                    </td>
                    <td className="px-5 py-3.5 text-right font-sans">Báo cáo Ban Giám Đốc</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: BÁO CÁO TUỔI NỢ & DỰ PHÒNG */}
      {/* ======================================================== */}
      {activeReportTab === 'aging' && (
        <div className="space-y-6">
          <div className="grid grid-cols-2 md:grid-cols-6 gap-3.5">
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs text-slate-500">Tổng công nợ</span>
              <div className="text-base font-bold text-slate-900 dark:text-white mt-1">
                {fmt(totalReceivables)}
              </div>
              <span className="text-[11px] text-slate-400">100% nợ phải thu</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/30 shadow-sm">
              <span className="text-xs text-emerald-600">Chưa đến hạn</span>
              <div className="text-base font-bold text-emerald-600 mt-1">
                {fmt(agingTotals.current)}
              </div>
              <span className="text-[11px] text-slate-400">
                {((agingTotals.current / totalReceivables) * 100).toFixed(1)}%
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-amber-200 dark:border-amber-900/30 shadow-sm">
              <span className="text-xs text-amber-600">Quá hạn 1 - 30 ngày</span>
              <div className="text-base font-bold text-amber-600 mt-1">
                {fmt(agingTotals.days1_30)}
              </div>
              <span className="text-[11px] text-slate-400">
                {((agingTotals.days1_30 / totalReceivables) * 100).toFixed(1)}%
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-orange-200 dark:border-orange-900/30 shadow-sm">
              <span className="text-xs text-orange-600">Quá hạn 31 - 60 ngày</span>
              <div className="text-base font-bold text-orange-600 mt-1">
                {fmt(agingTotals.days31_60)}
              </div>
              <span className="text-[11px] text-slate-400">
                {((agingTotals.days31_60 / totalReceivables) * 100).toFixed(1)}%
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-red-200 dark:border-red-900/30 shadow-sm">
              <span className="text-xs text-red-600">Quá hạn 61 - 90 ngày</span>
              <div className="text-base font-bold text-red-600 mt-1">
                {fmt(agingTotals.days61_90)}
              </div>
              <span className="text-[11px] text-slate-400">
                {((agingTotals.days61_90 / totalReceivables) * 100).toFixed(1)}%
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-red-300 dark:border-red-800 shadow-sm bg-red-50/20">
              <span className="text-xs text-red-700 font-bold">Quá hạn &gt; 90 ngày</span>
              <div className="text-base font-bold text-red-700 mt-1">
                {fmt(agingTotals.over90)}
              </div>
              <span className="text-[11px] text-red-600 font-bold">Rủi ro khó đòi</span>
            </div>
          </div>

          {/* Provision Estimator Banner */}
          <div className="p-4 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800/40 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <div>
                <span className="font-bold text-red-900 dark:text-red-300 text-sm">
                  Ước tính trích lập Dự phòng nợ phải thu khó đòi:
                </span>
                <p className="text-xs text-red-700 dark:text-red-400 mt-0.5">
                  Áp dụng hệ số trích lập (10% cho nợ 31-60 ngày; 30% cho nợ 61-90 ngày; 50% cho nợ &gt;90 ngày).
                </p>
              </div>
            </div>
            <div className="text-right">
              <div className="text-lg font-bold text-red-600 font-mono">
                {fmt(estimatedBadDebtProvision)}
              </div>
              <span className="text-[11px] text-slate-400">Tác động giảm trừ lợi nhuận</span>
            </div>
          </div>

          {/* Aging Details Table */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-900 uppercase font-semibold text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="px-4 py-3">Khách hàng</th>
                    <th className="px-3 py-3">Sales phụ trách</th>
                    <th className="px-3 py-3 text-right">Tổng nợ</th>
                    <th className="px-3 py-3 text-right text-emerald-600">Chưa đến hạn</th>
                    <th className="px-3 py-3 text-right text-amber-600">1 - 30 ngày</th>
                    <th className="px-3 py-3 text-right text-orange-600">31 - 60 ngày</th>
                    <th className="px-3 py-3 text-right text-red-600">61 - 90 ngày</th>
                    <th className="px-3 py-3 text-right text-red-700 font-bold">&gt; 90 ngày</th>
                    <th className="px-3 py-3 text-center">Đánh giá rủi ro</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {customerDebts.map((c) => (
                    <tr key={c.customerId} className="hover:bg-slate-50/50 dark:hover:bg-slate-750">
                      <td className="px-4 py-3 font-sans font-medium text-slate-900 dark:text-white">
                        {c.customerName}
                        <div className="text-[11px] text-slate-400">{c.customerCode}</div>
                      </td>
                      <td className="px-3 py-3 font-sans text-slate-600 dark:text-slate-400">
                        {c.assignedSalesStaff}
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-slate-900 dark:text-white">
                        {fmt(c.closingDebt)}
                      </td>
                      <td className="px-3 py-3 text-right text-emerald-600">
                        {c.aging.current > 0 ? fmt(c.aging.current) : '-'}
                      </td>
                      <td className="px-3 py-3 text-right text-amber-600">
                        {c.aging.days1_30 > 0 ? fmt(c.aging.days1_30) : '-'}
                      </td>
                      <td className="px-3 py-3 text-right text-orange-600">
                        {c.aging.days31_60 > 0 ? fmt(c.aging.days31_60) : '-'}
                      </td>
                      <td className="px-3 py-3 text-right text-red-600">
                        {c.aging.days61_90 > 0 ? fmt(c.aging.days61_90) : '-'}
                      </td>
                      <td className="px-3 py-3 text-right text-red-700 font-bold">
                        {c.aging.over90 > 0 ? fmt(c.aging.over90) : '-'}
                      </td>
                      <td className="px-3 py-3 text-center font-sans">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                            c.riskStatus === 'Bình thường'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300'
                              : c.riskStatus === 'Cần nhắc'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
                              : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                          }`}
                        >
                          {c.riskStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 3: PHÂN TÍCH DOANH THU & BIÊN LỢI NHUẬN */}
      {/* ======================================================== */}
      {activeReportTab === 'profit_analysis' && (
        <div className="space-y-6">
          {/* By Product Line */}
          <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <h2 className="section-title">
              <Layers className="w-4.5 h-4.5 text-emerald-600 mr-2 shrink-0" />
              1. Hiệu quả kinh doanh & Biên LNG theo Dòng sản phẩm / Dịch vụ
            </h2>

            <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-900 uppercase font-semibold text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="px-4 py-3">Nhóm sản phẩm / Dịch vụ</th>
                    <th className="px-3 py-3 text-center">Số đơn hàng</th>
                    <th className="px-4 py-3 text-right">Doanh thu</th>
                    <th className="px-4 py-3 text-right">Giá vốn (COGS)</th>
                    <th className="px-4 py-3 text-right">Lợi nhuận gộp</th>
                    <th className="px-3 py-3 text-center">Biên LNG (%)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {revenueByProduct.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-750">
                      <td className="px-4 py-3 font-sans font-semibold text-slate-900 dark:text-white">
                        {p.dimensionName}
                      </td>
                      <td className="px-3 py-3 text-center font-sans text-slate-500">
                        {p.ordersCount} đơn
                      </td>
                      <td className="px-4 py-3 text-right font-bold text-slate-900 dark:text-white">
                        {fmt(p.revenue)}
                      </td>
                      <td className="px-4 py-3 text-right text-slate-500">{fmt(p.cogs)}</td>
                      <td className="px-4 py-3 text-right font-bold text-emerald-600">
                        {fmt(p.grossProfit)}
                      </td>
                      <td className="px-3 py-3 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-xs font-bold ${
                            p.grossMarginPct >= 35
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                              : 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300'
                          }`}
                        >
                          {p.grossMarginPct.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* By Sales Staff */}
          <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <h2 className="section-title">
              <Users className="w-4.5 h-4.5 text-emerald-600 mr-2 shrink-0" />
              2. Đóng góp Doanh thu & Tỷ suất lợi nhuận theo Nhân viên Kinh doanh
            </h2>

            <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-900 uppercase font-semibold text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="px-4 py-3">Nhân viên Sales</th>
                    <th className="px-3 py-3 text-center">Đơn đã chốt</th>
                    <th className="px-4 py-3 text-right">Doanh số thực tế</th>
                    <th className="px-4 py-3 text-right">Lợi nhuận gộp mang về</th>
                    <th className="px-3 py-3 text-center">Biên LNG trung bình</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {revenueBySalesStaff.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-750">
                      <td className="px-4 py-3 font-sans font-semibold text-slate-900 dark:text-white">
                        {s.dimensionName}
                      </td>
                      <td className="px-3 py-3 text-center font-sans text-slate-500">
                        {s.ordersCount} hợp đồng
                      </td>
                      <td className="px-4 py-3 text-right font-bold text-slate-900 dark:text-white">
                        {fmt(s.revenue)}
                      </td>
                      <td className="px-4 py-3 text-right font-bold text-emerald-600">
                        {fmt(s.grossProfit)}
                      </td>
                      <td className="px-3 py-3 text-center font-bold text-blue-600">
                        {s.grossMarginPct.toFixed(1)}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
