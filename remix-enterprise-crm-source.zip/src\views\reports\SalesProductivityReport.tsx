import React from 'react';
import { useCRM } from '../../context/CRMContext';
import { ReportFilterState } from '../../types/crm';
import { ReportFilterBar } from '../../components/reports/ReportFilterBar';
import { ExecutiveStatCard } from '../../components/reports/ReportCharts';
import { MOCK_SALES_REPS, MockSalesRep } from '../../data/mockReportsData';
import {
  Award,
  TrendingUp,
  PhoneCall,
  CalendarCheck,
  CheckSquare,
  AlertTriangle,
  Trophy,
  Medal,
  Users,
} from 'lucide-react';

interface SalesProductivityReportProps {
  filter: ReportFilterState;
  onChangeFilter: (updated: Partial<ReportFilterState>) => void;
}

export const SalesProductivityReport: React.FC<SalesProductivityReportProps> = ({
  filter,
  onChangeFilter,
}) => {
  const { themeDef } = useCRM();

  // If user role is manager, force team filter to their team
  const effectiveTeamId = filter.viewRole === 'manager' && filter.teamId === 'all' ? 'team-north' : filter.teamId;

  // Filter reps
  const filteredReps = MOCK_SALES_REPS.filter((r) => {
    if (effectiveTeamId !== 'all' && r.teamId !== effectiveTeamId) return false;
    if (filter.salesRepId !== 'all' && r.id !== filter.salesRepId) return false;
    if (filter.region !== 'all' && r.region !== filter.region) return false;
    return true;
  });

  // Sort by revenue descending for leaderboard
  const sortedReps = [...filteredReps].sort((a, b) => b.actualRevenue - a.actualRevenue);

  // Calculate Team Average
  const teamAvgRevenue =
    sortedReps.length > 0 ? Math.round(sortedReps.reduce((sum, r) => sum + r.actualRevenue, 0) / sortedReps.length) : 0;
  const teamAvgCalls =
    sortedReps.length > 0 ? Math.round(sortedReps.reduce((sum, r) => sum + r.callsCount, 0) / sortedReps.length) : 0;
  const teamAvgMeetings =
    sortedReps.length > 0 ? Math.round(sortedReps.reduce((sum, r) => sum + r.meetingsCount, 0) / sortedReps.length) : 0;

  // Count under 70% quota
  const under70Count = sortedReps.filter((r) => (r.actualRevenue / r.monthlyQuota) < 0.7).length;

  return (
    <div className="space-y-6">
      {/* Shared Filter Bar */}
      <ReportFilterBar
        filter={filter}
        onChangeFilter={onChangeFilter}
        reportTitle="Báo cáo Hiệu suất nhân viên (Productivity)"
      />

      {/* Top Benchmark Summary Cards (Executive Style: Chỉ hiển thị Tiêu đề và Con số, bấm ! xem giải thích) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <ExecutiveStatCard
          title="Doanh thu TB / Nhân viên"
          value={`${(teamAvgRevenue / 1000000).toLocaleString('vi-VN')} Tr`}
          icon={TrendingUp}
          iconColor="bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-800"
          explanation="Mức doanh thu bình quân tính trên mỗi nhân viên kinh doanh trong kỳ đánh giá."
        />

        <ExecutiveStatCard
          title="Số cuộc gọi TB / Tháng"
          value={`${teamAvgCalls} cuộc`}
          valueColor="text-emerald-600 dark:text-emerald-400"
          icon={PhoneCall}
          iconColor="bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
          explanation="Chỉ tiêu định mức tối thiểu là 120 cuộc/tháng để đảm bảo tương tác liên tục với khách hàng."
        />

        <ExecutiveStatCard
          title="Số cuộc gặp khách hàng TB"
          value={`${teamAvgMeetings} cuộc hẹn`}
          valueColor="text-purple-600 dark:text-purple-400"
          icon={CalendarCheck}
          iconColor="bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800"
          explanation="Gặp gỡ trực tiếp hoặc demo giải pháp trực tuyến để tư vấn chuyên sâu cho khách hàng."
        />

        <ExecutiveStatCard
          title="Cảnh báo tiến độ (< 70% Quota)"
          value={`${under70Count} nhân viên`}
          valueColor="text-amber-600 dark:text-amber-400"
          icon={AlertTriangle}
          iconColor="bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800"
          explanation="Số lượng nhân viên đạt dưới 70% chỉ tiêu KPI, cần trưởng bộ phận hỗ trợ huấn luyện và can thiệp kịp thời."
        />
      </div>

      {/* Main Leaderboard Table */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-4`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="section-title">
              <Trophy className="w-4.5 h-4.5 text-amber-500 mr-2 shrink-0" />
              Bảng xếp hạng Hiệu suất kinh doanh (Sales Leaderboard)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {filter.viewRole === 'manager'
                ? 'Đang xem danh sách nhân sự thuộc nhóm phụ trách của bạn'
                : 'Theo dõi toàn diện các chỉ số năng suất cá nhân và mức độ hoàn thành chỉ tiêu'}
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3 text-center">Hạng</th>
                <th className="py-3 px-3">Nhân viên sales</th>
                <th className="py-3 px-3">Đội Sales</th>
                <th className="py-3 px-3 text-right">Doanh thu đạt</th>
                <th className="py-3 px-3 text-right">Mục tiêu (Quota)</th>
                <th className="py-3 px-3 w-48">Tiến độ Quota (%)</th>
                <th className="py-3 px-3 text-center">Deal thắng / Tổng</th>
                <th className="py-3 px-3 text-center">Tỷ lệ thắng</th>
                <th className="py-3 px-3 text-center">Cuộc gọi</th>
                <th className="py-3 px-3 text-center">Cuộc hẹn</th>
                <th className="py-3 px-3 text-center">Task hoàn tất</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {sortedReps.map((rep, idx) => {
                const quotaPct = Math.round((rep.actualRevenue / rep.monthlyQuota) * 100);
                const isUnder70 = quotaPct < 70;
                const winRate = rep.totalDeals > 0 ? Math.round((rep.wonDealsCount / rep.totalDeals) * 100) : 0;

                return (
                  <tr
                    key={rep.id}
                    className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${
                      isUnder70 ? 'bg-amber-50/20 dark:bg-amber-950/10' : ''
                    }`}
                  >
                    {/* Rank Badge */}
                    <td className="py-3 px-3 text-center">
                      {idx === 0 ? (
                        <span className="w-6 h-6 rounded-full bg-amber-100 text-amber-800 font-bold inline-flex items-center justify-center text-xs shadow-xs">
                          🥇
                        </span>
                      ) : idx === 1 ? (
                        <span className="w-6 h-6 rounded-full bg-slate-200 text-slate-800 font-bold inline-flex items-center justify-center text-xs shadow-xs">
                          🥈
                        </span>
                      ) : idx === 2 ? (
                        <span className="w-6 h-6 rounded-full bg-amber-50 text-amber-700 font-bold inline-flex items-center justify-center text-xs shadow-xs">
                          🥉
                        </span>
                      ) : (
                        <span className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 font-bold inline-flex items-center justify-center text-slate-600 dark:text-slate-400 text-xs">
                          {idx + 1}
                        </span>
                      )}
                    </td>

                    {/* Rep Info */}
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <img src={rep.avatar} alt="" className="w-7 h-7 rounded-full object-cover shrink-0" />
                        <div>
                          <p className="font-bold text-slate-900 dark:text-white">{rep.name}</p>
                          <span className="text-[10px] text-slate-400">{rep.region}</span>
                        </div>
                      </div>
                    </td>

                    {/* Team */}
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                      {rep.teamName.replace('Đội ', '')}
                    </td>

                    {/* Revenue */}
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                      {(rep.actualRevenue / 1000000).toLocaleString('vi-VN')} Tr
                    </td>

                    {/* Quota */}
                    <td className="py-3 px-3 text-right font-mono text-slate-500">
                      {(rep.monthlyQuota / 1000000).toLocaleString('vi-VN')} Tr
                    </td>

                    {/* Quota Progress Bar with Warning Alert for < 70% */}
                    <td className="py-3 px-3">
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-[11px]">
                          <span
                            className={`font-bold ${
                              isUnder70 ? 'text-amber-600 dark:text-amber-400 flex items-center gap-1' : 'text-slate-700 dark:text-slate-300'
                            }`}
                          >
                            {isUnder70 && <AlertTriangle className="w-3 h-3 text-amber-500 shrink-0" />}
                            {quotaPct}%
                          </span>
                          {isUnder70 && (
                            <span className="text-[10px] text-amber-700 dark:text-amber-400 font-bold">
                              Dưới 70%
                            </span>
                          )}
                        </div>
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                          <div
                            style={{ width: `${Math.min(100, quotaPct)}%` }}
                            className={`h-full rounded-full transition-all duration-300 ${
                              isUnder70
                                ? 'bg-amber-500'
                                : quotaPct >= 100
                                ? 'bg-emerald-500'
                                : 'bg-sky-500'
                            }`}
                          />
                        </div>
                      </div>
                    </td>

                    {/* Deals won/total */}
                    <td className="py-3 px-3 text-center font-mono">
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">{rep.wonDealsCount}</span>
                      <span className="text-slate-400"> / {rep.totalDeals}</span>
                    </td>

                    {/* Win rate */}
                    <td className="py-3 px-3 text-center font-semibold text-slate-800 dark:text-slate-200">
                      {winRate}%
                    </td>

                    {/* Calls */}
                    <td className="py-3 px-3 text-center font-mono text-slate-700 dark:text-slate-300">
                      {rep.callsCount}
                    </td>

                    {/* Meetings */}
                    <td className="py-3 px-3 text-center font-mono text-slate-700 dark:text-slate-300">
                      {rep.meetingsCount}
                    </td>

                    {/* Tasks */}
                    <td className="py-3 px-3 text-center font-mono text-slate-700 dark:text-slate-300">
                      {rep.completedTasksCount}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
