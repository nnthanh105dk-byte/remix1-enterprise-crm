import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSettings } from '../../context/SettingsContext';
import { PermissionGroup, PermissionActionType, DataScope, FieldVisibility } from '../../types/settings';
import {
  ShieldCheck,
  Plus,
  Copy,
  Trash2,
  Edit,
  Save,
  Check,
  X,
  Eye,
  EyeOff,
  Users,
  Search,
  CheckSquare,
  Square,
  FileSpreadsheet,
  AlertCircle,
  FolderTree,
  ChevronRight,
  ChevronDown,
  Layers,
} from 'lucide-react';

const MODULES_TREE = [
  { id: 'reports', label: 'Báo cáo thông minh', group: 'Báo cáo' },
  { id: 'inventory', label: 'Quản lý kho & Tồn kho', group: 'Quản lý kho' },
  { id: 'sales', label: 'Quản lý Sales (Khách hàng & Bán hàng)', group: 'Quản lý Sales' },
  { id: 'logistics', label: 'Vận chuyển & Mua hàng', group: 'Vận chuyển' },
  { id: 'accounting', label: 'Kế toán & Sổ quỹ', group: 'Kế toán' },
  { id: 'technical', label: 'Kỹ thuật & Dự án công trình', group: 'Kỹ thuật' },
  { id: 'hr', label: 'Quản lý nhân sự & BHXH', group: 'Quản lý nhân sự' },
  { id: 'settings', label: 'Cài đặt hệ thống & Cấu hình', group: 'Cài đặt hệ thống' },
];

const ACTIONS_COLUMNS: { key: PermissionActionType; label: string }[] = [
  { key: 'view', label: 'Xem' },
  { key: 'create', label: 'Tạo' },
  { key: 'edit', label: 'Sửa' },
  { key: 'delete', label: 'Hủy/Xóa' },
  { key: 'approve', label: 'Duyệt' },
  { key: 'export', label: 'Xuất DL' },
  { key: 'print', label: 'In ấn' },
];

const SCOPES_OPTIONS: { key: DataScope; label: string }[] = [
  { key: 'personal', label: 'Cá nhân' },
  { key: 'team', label: 'Đội / Nhóm' },
  { key: 'department', label: 'Phòng ban' },
  { key: 'all', label: 'Toàn công ty' },
];

export const SettingsPermissionsView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    permissionGroups,
    createPermissionGroup,
    clonePermissionGroup,
    updatePermissionGroup,
    deletePermissionGroup,
    users,
    canAccessSettings,
  } = useSettings();

  const [activeTab, setActiveTab] = useState<'matrix' | 'effective_report' | 'menu_preview'>('matrix');
  const [selectedGroupId, setSelectedGroupId] = useState<string>((permissionGroups || [])[0]?.id || '');
  const [isNewGroupModalOpen, setIsNewGroupModalOpen] = useState(false);
  const [isCloneModalOpen, setIsCloneModalOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');

  // Selected Group
  const activeGroup = useMemo(() => {
    return (permissionGroups || []).find((g) => g.id === selectedGroupId) || (permissionGroups || [])[0];
  }, [permissionGroups, selectedGroupId]);

  // Form edit state for active group matrix
  const [matrixRules, setMatrixRules] = useState(activeGroup?.moduleRules || []);
  const [fieldRules, setFieldRules] = useState(activeGroup?.fieldRules || []);

  // Update local state when selected group changes
  React.useEffect(() => {
    if (activeGroup) {
      setMatrixRules(activeGroup.moduleRules || []);
      setFieldRules(activeGroup.fieldRules || []);
    }
  }, [selectedGroupId, activeGroup]);

  // Report: effective user permission inspection
  const [inspectUserId, setInspectUserId] = useState((users || [])[0]?.id || '');
  const [inspectFunctionId, setInspectFunctionId] = useState('sales');

  const inspectedUser = useMemo(() => {
    return (users || []).find((u) => u.id === inspectUserId);
  }, [users, inspectUserId]);

  const usersWithInspectedFunction = useMemo(() => {
    return (users || []).filter((u) => {
      const userGroups = (permissionGroups || []).filter((g) => (u.roleIds || []).includes(g.id));
      return userGroups.some((g) => (g.moduleRules || []).some((r) => r.moduleId === inspectFunctionId && (r.actions || []).includes('view')));
    });
  }, [users, permissionGroups, inspectFunctionId]);

  // Toggle single action in matrix
  const handleToggleAction = (moduleId: string, action: PermissionActionType) => {
    setMatrixRules((prev) => {
      const existing = prev.find((r) => r.moduleId === moduleId);
      if (!existing) {
        return [
          ...prev,
          {
            moduleId,
            moduleLabel: MODULES_TREE.find((m) => m.id === moduleId)?.label || moduleId,
            parentGroup: MODULES_TREE.find((m) => m.id === moduleId)?.group || '',
            actions: [action],
            dataScope: 'personal',
          },
        ];
      }
      const hasAction = existing.actions.includes(action);
      const newActions = hasAction ? existing.actions.filter((a) => a !== action) : [...existing.actions, action];
      return prev.map((r) => (r.moduleId === moduleId ? { ...r, actions: newActions } : r));
    });
  };

  // Toggle all actions in row
  const handleToggleRow = (moduleId: string) => {
    setMatrixRules((prev) => {
      const existing = prev.find((r) => r.moduleId === moduleId);
      const allActions: PermissionActionType[] = ['view', 'create', 'edit', 'delete', 'approve', 'export', 'print'];
      const hasAll = existing && allActions.every((a) => existing.actions.includes(a));
      const targetActions = hasAll ? [] : allActions;

      if (!existing) {
        return [
          ...prev,
          {
            moduleId,
            moduleLabel: MODULES_TREE.find((m) => m.id === moduleId)?.label || moduleId,
            parentGroup: MODULES_TREE.find((m) => m.id === moduleId)?.group || '',
            actions: targetActions,
            dataScope: 'department',
          },
        ];
      }
      return prev.map((r) => (r.moduleId === moduleId ? { ...r, actions: targetActions } : r));
    });
  };

  // Toggle entire column across all modules
  const handleToggleColumn = (action: PermissionActionType) => {
    setMatrixRules((prev) => {
      const allModulesHaveAction = MODULES_TREE.every((m) => {
        const rule = prev.find((r) => r.moduleId === m.id);
        return rule && rule.actions.includes(action);
      });

      return MODULES_TREE.map((m) => {
        const existing = prev.find((r) => r.moduleId === m.id);
        let newActions: PermissionActionType[] = existing ? [...existing.actions] : [];
        if (allModulesHaveAction) {
          newActions = newActions.filter((a) => a !== action);
        } else {
          if (!newActions.includes(action)) newActions.push(action);
        }
        return {
          moduleId: m.id,
          moduleLabel: m.label,
          parentGroup: m.group,
          actions: newActions,
          dataScope: existing ? existing.dataScope : 'department',
        };
      });
    });
  };

  // Change data scope
  const handleChangeScope = (moduleId: string, scope: DataScope) => {
    setMatrixRules((prev) => {
      const existing = prev.find((r) => r.moduleId === moduleId);
      if (!existing) {
        return [
          ...prev,
          {
            moduleId,
            moduleLabel: MODULES_TREE.find((m) => m.id === moduleId)?.label || moduleId,
            parentGroup: MODULES_TREE.find((m) => m.id === moduleId)?.group || '',
            actions: ['view'],
            dataScope: scope,
          },
        ];
      }
      return prev.map((r) => (r.moduleId === moduleId ? { ...r, dataScope: scope } : r));
    });
  };

  // Change field visibility
  const handleChangeFieldRule = (fieldKey: any, visibility: FieldVisibility) => {
    setFieldRules((prev) => {
      return prev.map((f) => (f.fieldKey === fieldKey ? { ...f, visibility } : f));
    });
  };

  // Save matrix changes
  const handleSaveMatrix = () => {
    if (!activeGroup) return;
    updatePermissionGroup(activeGroup.id, {
      moduleRules: matrixRules,
      fieldRules: fieldRules,
    });
  };

  // Submit new group
  const handleCreateGroupSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;
    const created = createPermissionGroup({
      code: `CUSTOM_${Math.floor(Math.random() * 9000 + 1000)}`,
      name: newGroupName,
      description: newGroupDesc || 'Nhóm quyền tùy chỉnh',
      moduleRules: MODULES_TREE.map((m) => ({
        moduleId: m.id,
        moduleLabel: m.label,
        parentGroup: m.group,
        actions: ['view'],
        dataScope: 'department',
      })),
      fieldRules: [
        { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'masked' },
        { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'hidden' },
        { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'masked' },
        { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'masked' },
        { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'full' },
      ],
    });
    setIsNewGroupModalOpen(false);
    setNewGroupName('');
    setNewGroupDesc('');
    setSelectedGroupId(created.id);
  };

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-800">
            <ShieldCheck className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              Nhóm Quyền &amp; Ma Trận Phân Quyền
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300 font-bold font-mono">
                {permissionGroups.length} Nhóm
              </span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Kiểm soát quyền truy cập tập trung theo Module, Chức năng, Phạm vi dữ liệu và Quyền theo trường nhạy cảm.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsCloneModalOpen(true)}
            disabled={!activeGroup}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 text-xs font-semibold flex items-center gap-1.5"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Nhân bản nhóm</span>
          </button>

          <button
            onClick={() => setIsNewGroupModalOpen(true)}
            className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Tạo Nhóm Quyền</span>
          </button>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 text-xs">
        <button
          onClick={() => setActiveTab('matrix')}
          className={`px-4 py-2.5 font-bold border-b-2 flex items-center gap-2 ${
            activeTab === 'matrix'
              ? 'border-purple-600 text-purple-600 dark:text-purple-400 bg-purple-50/50 dark:bg-purple-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Ma Trận Phân Quyền Chi Tiết</span>
        </button>

        <button
          onClick={() => setActiveTab('effective_report')}
          className={`px-4 py-2.5 font-bold border-b-2 flex items-center gap-2 ${
            activeTab === 'effective_report'
              ? 'border-purple-600 text-purple-600 dark:text-purple-400 bg-purple-50/50 dark:bg-purple-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Báo Cáo Quyền Hiệu Lực</span>
        </button>

        <button
          onClick={() => setActiveTab('menu_preview')}
          className={`px-4 py-2.5 font-bold border-b-2 flex items-center gap-2 ${
            activeTab === 'menu_preview'
              ? 'border-purple-600 text-purple-600 dark:text-purple-400 bg-purple-50/50 dark:bg-purple-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <FolderTree className="w-4 h-4" />
          <span>Xem Thử Menu Theo Nhóm</span>
        </button>
      </div>

      {/* TAB 1: MA TRẬN PHÂN QUYỀN */}
      {activeTab === 'matrix' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Cột trái: Danh sách các Nhóm quyền */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3 shadow-xs space-y-2 lg:col-span-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block px-1">
              Danh sách nhóm ({permissionGroups.length})
            </span>
            <div className="space-y-1 max-h-[600px] overflow-y-auto">
              {permissionGroups.map((g) => {
                const isSelected = g.id === selectedGroupId;
                return (
                  <div
                    key={g.id}
                    onClick={() => setSelectedGroupId(g.id)}
                    className={`p-2.5 rounded-xl border cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-purple-50/80 border-purple-300 dark:bg-purple-950/30 dark:border-purple-800'
                        : 'border-transparent hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`font-bold text-xs ${isSelected ? 'text-purple-700 dark:text-purple-300' : 'text-slate-800 dark:text-slate-200'}`}>
                        {g.name}
                      </span>
                      {g.isSystem ? (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-slate-200 text-slate-600 dark:bg-slate-800 font-mono">
                          Hệ thống
                        </span>
                      ) : (
                        <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-100 text-amber-700 font-mono">
                          Tùy chỉnh
                        </span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{g.description}</p>
                    <span className="text-[10px] text-slate-500 font-medium block mt-1">
                      {users.filter((u) => u.roleIds.includes(g.id)).length} người dùng
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Cột phải: Bảng Ma trận phân quyền cho nhóm đang chọn */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs lg:col-span-3 space-y-5">
            {/* Header thông tin nhóm đang chọn */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-base text-slate-900 dark:text-white">{activeGroup.name}</h3>
                  {activeGroup.isSystem && (
                    <span className="text-[10px] px-2 py-0.5 rounded bg-purple-100 text-purple-700 font-bold">
                      Nhóm Hệ Thống Mặc Định
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 mt-0.5">{activeGroup.description}</p>
              </div>

              <div className="flex items-center gap-2">
                {!activeGroup.isSystem && (
                  <button
                    onClick={() => deletePermissionGroup(activeGroup.id)}
                    className="p-2 rounded-xl text-rose-600 hover:bg-rose-50 border border-rose-200 text-xs font-semibold flex items-center gap-1"
                    title="Xóa nhóm quyền tùy chỉnh"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Xóa nhóm</span>
                  </button>
                )}

                <button
                  onClick={handleSaveMatrix}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm"
                >
                  <Save className="w-4 h-4" />
                  <span>Lưu Phân Quyền</span>
                </button>
              </div>
            </div>

            {/* BẢNG MA TRẬN */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-800 dark:text-slate-200">
                  Phân quyền chức năng theo Module &amp; Menu
                </span>
                <span className="text-[11px] text-slate-400">
                  * Nhấp tiêu đề cột để Bật/Tắt cả cột; nhấp tên Module để Bật/Tắt cả dòng
                </span>
              </div>

              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 font-semibold border-b">
                    <tr>
                      <th className="px-3 py-2.5 min-w-[200px]">Module / Chức năng</th>
                      {ACTIONS_COLUMNS.map((col) => (
                        <th
                          key={col.key}
                          onClick={() => handleToggleColumn(col.key)}
                          className="px-2 py-2.5 text-center cursor-pointer hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                          title={`Nhấp để Bật/Tắt tất cả ${col.label}`}
                        >
                          <span className="underline decoration-dotted">{col.label}</span>
                        </th>
                      ))}
                      <th className="px-3 py-2.5 min-w-[130px]">Phạm vi dữ liệu</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {MODULES_TREE.map((mod) => {
                      const rule = matrixRules.find((r) => r.moduleId === mod.id);
                      const activeActions = rule ? rule.actions : [];
                      const scope = rule ? rule.dataScope : 'department';

                      return (
                        <tr key={mod.id} className="hover:bg-slate-50/50">
                          <td className="px-3 py-2.5">
                            <button
                              onClick={() => handleToggleRow(mod.id)}
                              className="font-bold text-slate-900 dark:text-white text-left hover:text-purple-600 transition-colors flex items-center gap-1.5"
                              title="Nhấp để Bật/Tắt toàn bộ quyền trong dòng"
                            >
                              <span>{mod.label}</span>
                            </button>
                            <span className="text-[10px] text-slate-400 block">{mod.group}</span>
                          </td>

                          {ACTIONS_COLUMNS.map((col) => {
                            const isChecked = activeActions.includes(col.key);
                            return (
                              <td key={col.key} className="px-2 py-2.5 text-center">
                                <button
                                  type="button"
                                  onClick={() => handleToggleAction(mod.id, col.key)}
                                  className={`w-6 h-6 rounded flex items-center justify-center mx-auto transition-colors ${
                                    isChecked
                                      ? 'bg-purple-600 text-white'
                                      : 'bg-slate-100 text-slate-400 hover:bg-slate-200 dark:bg-slate-800'
                                  }`}
                                >
                                  {isChecked ? <Check className="w-3.5 h-3.5" /> : null}
                                </button>
                              </td>
                            );
                          })}

                          <td className="px-3 py-2.5">
                            <select
                              value={scope}
                              onChange={(e) => handleChangeScope(mod.id, e.target.value as DataScope)}
                              className="px-2 py-1 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-[11px] font-semibold w-full"
                            >
                              {SCOPES_OPTIONS.map((s) => (
                                <option key={s.key} value={s.key}>
                                  {s.label}
                                </option>
                              ))}
                            </select>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* QUYỀN THEO TRƯỜNG DỮ LIỆU NHẠY CẢM */}
            <div className="space-y-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <span className="font-bold text-slate-800 dark:text-slate-200 text-xs block">
                Phân quyền theo Trường Dữ liệu Nhạy Cảm (Field-level Security)
              </span>
              <p className="text-[11px] text-slate-400">
                Kiểm soát hiển thị chi tiết đối với dữ liệu tài chính, lương thưởng, giấy tờ cá nhân và thông tin ngân hàng.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-1">
                {fieldRules.map((f) => (
                  <div key={f.fieldKey} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-900 dark:text-white block text-xs">{f.fieldLabel}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{f.fieldKey}</span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleChangeFieldRule(f.fieldKey, 'full')}
                        className={`px-2 py-1 rounded-md text-[10px] font-bold ${
                          f.visibility === 'full'
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800'
                        }`}
                      >
                        Hiện đủ
                      </button>
                      <button
                        type="button"
                        onClick={() => handleChangeFieldRule(f.fieldKey, 'masked')}
                        className={`px-2 py-1 rounded-md text-[10px] font-bold ${
                          f.visibility === 'masked'
                            ? 'bg-amber-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800'
                        }`}
                      >
                        Che bớt (••••)
                      </button>
                      <button
                        type="button"
                        onClick={() => handleChangeFieldRule(f.fieldKey, 'hidden')}
                        className={`px-2 py-1 rounded-md text-[10px] font-bold ${
                          f.visibility === 'hidden'
                            ? 'bg-rose-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800'
                        }`}
                      >
                        Ẩn
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BÁO CÁO QUYỀN HIỆU LỰC */}
      {activeTab === 'effective_report' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* View 1: Chọn User để xem tổng hợp quyền cộng dồn */}
            <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
              <span className="font-bold text-sm text-slate-900 dark:text-white block">
                Tổng hợp quyền hiệu lực theo Người Dùng
              </span>
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Chọn người dùng cần kiểm tra:</label>
                <select
                  value={inspectUserId}
                  onChange={(e) => setInspectUserId(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold"
                >
                  {users.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.fullName} ({u.email}) - {u.departmentName}
                    </option>
                  ))}
                </select>
              </div>

              {inspectedUser && (
                <div className="space-y-2 pt-2 border-t">
                  <div className="flex items-center gap-2">
                    <img src={inspectedUser.avatar} alt="" className="w-8 h-8 rounded-full border" />
                    <div>
                      <span className="font-bold text-xs text-slate-900 dark:text-white block">{inspectedUser.fullName}</span>
                      <span className="text-[10px] text-slate-400">{inspectedUser.positionName}</span>
                    </div>
                  </div>
                  <div className="text-xs space-y-1">
                    <span className="font-semibold text-slate-600 dark:text-slate-400 block">Các nhóm quyền sở hữu:</span>
                    <div className="flex flex-wrap gap-1">
                      {permissionGroups
                        .filter((g) => inspectedUser.roleIds.includes(g.id))
                        .map((g) => (
                          <span key={g.id} className="px-2 py-0.5 rounded bg-purple-100 text-purple-700 font-bold text-[10px]">
                            {g.name}
                          </span>
                        ))}
                    </div>
                  </div>
                  <p className="text-[11px] text-emerald-600 font-medium">
                    * Quyền của người dùng được tự động cộng dồn ở mức cao nhất và phạm vi rộng nhất từ tất cả các nhóm quyền trên.
                  </p>
                </div>
              )}
            </div>

            {/* View 2: Chọn Chức năng để xem ai có quyền */}
            <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3 shadow-xs">
              <span className="font-bold text-sm text-slate-900 dark:text-white block">
                Truy vết người dùng có quyền theo Chức năng
              </span>
              <div>
                <label className="text-[11px] text-slate-400 block mb-1">Chọn Module / Chức năng:</label>
                <select
                  value={inspectFunctionId}
                  onChange={(e) => setInspectFunctionId(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold"
                >
                  {MODULES_TREE.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.label} ({m.group})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1 pt-2 border-t max-h-48 overflow-y-auto">
                <span className="text-[11px] font-semibold text-slate-500 block">
                  Có {usersWithInspectedFunction.length} người dùng có quyền truy cập chức năng này:
                </span>
                {usersWithInspectedFunction.map((u) => (
                  <div key={u.id} className="p-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/40 flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-800 dark:text-slate-200">{u.fullName}</span>
                    <span className="text-[10px] text-slate-400">{u.departmentName}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: XEM THỬ MENU THEO NHÓM */}
      {activeTab === 'menu_preview' && (
        <div className="p-4 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Mô phỏng Giao diện Menu của nhóm: <span className="text-purple-600">{activeGroup.name}</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Chế độ chỉ xem trước danh mục menu mà nhân viên thuộc nhóm này sẽ nhìn thấy khi đăng nhập CRM. Không thay đổi phiên hiện tại.
              </p>
            </div>
          </div>

          <div className="max-w-xs p-3 rounded-2xl bg-slate-950 text-slate-200 border border-slate-800 space-y-1 text-xs">
            <span className="text-[10px] text-slate-400 uppercase font-mono tracking-wider block px-2 py-1">
              Menu điều hướng mô phỏng
            </span>
            {MODULES_TREE.map((m) => {
              const rule = activeGroup.moduleRules?.find((r) => r.moduleId === m.id);
              const canView = rule && rule.actions?.includes('view');

              if (!canView) return null; // Ẩn hoàn toàn menu không có quyền

              return (
                <div key={m.id} className="px-3 py-2 rounded-lg bg-slate-900/80 flex items-center justify-between text-xs font-semibold">
                  <span>{m.label}</span>
                  <span className="text-[9px] px-1 rounded bg-slate-800 text-slate-400 font-mono">
                    {rule.dataScope}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Modal Tạo nhóm mới */}
      {isNewGroupModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 border shadow-xl space-y-4">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Tạo Nhóm Quyền Mới</h3>
            <form onSubmit={handleCreateGroupSubmit} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Tên nhóm quyền *</label>
                <input
                  type="text"
                  value={newGroupName}
                  onChange={(e) => setNewGroupName(e.target.value)}
                  placeholder="Ví dụ: Nhân viên Chăm sóc khách hàng VIP"
                  className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
                  required
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Mô tả nhiệm vụ &amp; quyền hạn</label>
                <textarea
                  value={newGroupDesc}
                  onChange={(e) => setNewGroupDesc(e.target.value)}
                  rows={2}
                  className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsNewGroupModalOpen(false)} className="px-3 py-1.5 border rounded-xl">
                  Hủy
                </button>
                <button type="submit" className="px-4 py-2 bg-purple-600 text-white font-bold rounded-xl">
                  Tạo nhóm
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Clone nhóm */}
      {isCloneModalOpen && activeGroup && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 border shadow-xl space-y-4">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Nhân bản từ: {activeGroup.name}</h3>
            <div className="space-y-3 text-xs">
              <input
                type="text"
                defaultValue={`${activeGroup.name} (Bản sao)`}
                id="cloneNameInput"
                className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
              />
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsCloneModalOpen(false)} className="px-3 py-1.5 border rounded-xl">
                  Hủy
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const input = document.getElementById('cloneNameInput') as HTMLInputElement;
                    clonePermissionGroup(activeGroup.id, input.value || `${activeGroup.name} (Bản sao)`);
                    setIsCloneModalOpen(false);
                  }}
                  className="px-4 py-2 bg-purple-600 text-white font-bold rounded-xl"
                >
                  Xác nhận nhân bản
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
