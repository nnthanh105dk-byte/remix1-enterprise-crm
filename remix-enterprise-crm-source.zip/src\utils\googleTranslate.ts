/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * Google Translate Element Integration Helper
 * Tự động dịch toàn bộ trang web (Full Page Dynamic Translation) mà không cần viết thủ công từng từ.
 */

export interface SupportedLanguage {
  code: string;
  crmCode?: 'vi' | 'en' | 'ja';
  shortLabel: string;
  label: string;
  flag: string;
  nativeName: string;
}

export const SUPPORTED_LANGUAGES: SupportedLanguage[] = [
  {
    code: 'vi',
    crmCode: 'vi',
    shortLabel: 'VI',
    label: 'Tiếng Việt',
    flag: '🇻🇳',
    nativeName: 'Việt Nam (Ngôn ngữ gốc)',
  },
  {
    code: 'en',
    crmCode: 'en',
    shortLabel: 'EN',
    label: 'English',
    flag: '🇬🇧',
    nativeName: 'United States / Global',
  },
  {
    code: 'ja',
    crmCode: 'ja',
    shortLabel: 'JA',
    label: '日本語',
    flag: '🇯🇵',
    nativeName: 'Japan / 日本語',
  },
  {
    code: 'zh-CN',
    shortLabel: 'ZH',
    label: '中文 (简体)',
    flag: '🇨🇳',
    nativeName: 'Chinese (Simplified)',
  },
  {
    code: 'ko',
    shortLabel: 'KO',
    label: '한국어',
    flag: '🇰🇷',
    nativeName: 'Korean / 한국어',
  },
  {
    code: 'fr',
    shortLabel: 'FR',
    label: 'Français',
    flag: '🇫🇷',
    nativeName: 'French / France',
  },
  {
    code: 'de',
    shortLabel: 'DE',
    label: 'Deutsch',
    flag: '🇩🇪',
    nativeName: 'German / Deutschland',
  },
  {
    code: 'th',
    shortLabel: 'TH',
    label: 'ไทย',
    flag: '🇹🇭',
    nativeName: 'Thai / ประเทศไทย',
  },
  {
    code: 'ru',
    shortLabel: 'RU',
    label: 'Русский',
    flag: '🇷🇺',
    nativeName: 'Russian / Россия',
  },
  {
    code: 'es',
    shortLabel: 'ES',
    label: 'Español',
    flag: '🇪🇸',
    nativeName: 'Spanish / España',
  },
];

/**
 * Lấy mã ngôn ngữ hiện tại đang được lưu trong cookie hoặc URL
 */
export const getActiveGoogleTranslateLang = (): string => {
  if (typeof document === 'undefined') return 'vi';
  const match = document.cookie.match(/(^|;\s*)googtrans=\/vi\/([a-zA-Z-]+)/);
  if (match && match[2]) {
    return match[2];
  }
  return 'vi';
};

/**
 * Kích hoạt công cụ dịch toàn trang theo mã ngôn ngữ
 */
export const triggerFullPageTranslation = (targetLangCode: string): boolean => {
  if (typeof document === 'undefined') return false;

  const hostname = window.location.hostname;

  // 1. Nếu quay về Tiếng Việt (gốc)
  if (targetLangCode === 'vi') {
    // Xóa cookie googtrans
    document.cookie = 'googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
    document.cookie = `googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=${hostname};`;
    document.cookie = `googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=.${hostname};`;

    const select = document.querySelector<HTMLSelectElement>('.goog-te-combo');
    if (select) {
      select.value = 'vi';
      select.dispatchEvent(new Event('change'));
    }

    // Nếu vẫn còn trạng thái dịch, tải lại trang để phục hồi 100% nguyên gốc
    setTimeout(() => {
      if (document.cookie.includes('googtrans')) {
        window.location.reload();
      }
    }, 150);

    return true;
  }

  // 2. Ghi cookie googtrans để duy trì khi chuyển trang
  document.cookie = `googtrans=/vi/${targetLangCode}; path=/;`;
  document.cookie = `googtrans=/vi/${targetLangCode}; path=/; domain=${hostname};`;

  // 3. Kích hoạt trực tiếp trên select combo của Google Translate Widget
  const select = document.querySelector<HTMLSelectElement>('.goog-te-combo');
  if (select) {
    select.value = targetLangCode;
    select.dispatchEvent(new Event('change'));
    return true;
  }

  // 4. Fallback: Nếu widget chưa khởi tạo xong, chờ tối đa 3 giây và kích hoạt
  let attempts = 0;
  const interval = setInterval(() => {
    attempts++;
    const combo = document.querySelector<HTMLSelectElement>('.goog-te-combo');
    if (combo) {
      combo.value = targetLangCode;
      combo.dispatchEvent(new Event('change'));
      clearInterval(interval);
    }
    if (attempts > 15) {
      clearInterval(interval);
    }
  }, 200);

  return false;
};
