import { UserRole } from './crm';

// 1. Loại hợp đồng lao động
export type LaborContractType =
  | 'Thử việc'
  | 'Xác định thời hạn'
  | 'Không xác định thời hạn'
  | 'Thời vụ/Dịch vụ';

export type EmployeeStatus =
  | 'Thử việc'
  | 'Chính thức'
  | 'Nghỉ dài hạn'
  | 'Đã nghỉ việc';

// 2. Hợp đồng lao động của nhân viên
export interface EmployeeContract {
  id: string;
  employeeId: string;
  contractNumber: string;
  type: LaborContractType;
  startDate: string; // YYYY-MM-DD
  endDate?: string; // YYYY-MM-DD (nếu có kỳ hạn)
  baseSalary: number; // Lương cơ bản
  allowances: { name: string; amount: number }[];
  insuranceSalary: number; // Mức lương đóng BHXH
  status: 'Còn hạn' | 'Sắp hết hạn' | 'Hết hạn' | 'Đã thanh lý';
  signedDate?: string;
  attachments?: { name: string; size: string; uploadDate: string }[];
  notes?: string;
}

// 3. Quá trình công tác (Dòng thời gian TỰ GHI)
export interface WorkHistoryRecord {
  id: string;
  employeeId: string;
  date: string;
  type:
    | 'Vào làm'
    | 'Chuyển chính thức'
    | 'Điều chuyển phòng ban'
    | 'Thăng chức'
    | 'Điều chỉnh lương'
    | 'Ký hợp đồng'
    | 'Nghỉ dài hạn'
    | 'Nghỉ việc';
  changeSummary: string;
  performedBy: string;
  notes?: string;
}

// 4. Tài liệu nhân sự
export interface EmployeeDocument {
  id: string;
  employeeId: string;
  category: 'CCCD' | 'Bằng cấp/Chứng chỉ' | 'Sơ yếu lý lịch' | 'Hợp đồng' | 'Quyết định' | 'Giấy khám sức khỏe' | 'Khác';
  name: string;
  fileName: string;
  fileSize: string;
  uploadDate: string;
}

// 5. Checklist tiếp nhận / nghỉ việc
export interface ChecklistItem {
  id: string;
  title: string;
  assignedTo: string;
  dueDate: string;
  completed: boolean;
  completedAt?: string;
}

export interface EmployeeChecklists {
  onboarding: ChecklistItem[];
  offboarding: ChecklistItem[];
}

// 6. Yêu cầu cập nhật hồ sơ (Tự phục vụ của nhân viên)
export interface ProfileUpdateRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  requestDate: string;
  requestedChanges: {
    field: string;
    label: string;
    oldValue: any;
    newValue: any;
  }[];
  status: 'Chờ duyệt' | 'Đã duyệt' | 'Từ chối';
  approvedBy?: string;
  approvedAt?: string;
  rejectReason?: string;
}

// 7. Thực thể Nhân viên chính (NGUỒN DỮ LIỆU GỐC HỆ THỐNG)
export interface Employee {
  id: string;
  code: string; // NV-0001
  fullName: string;
  avatar?: string;
  gender: 'Nam' | 'Nữ' | 'Khác';
  dob: string; // YYYY-MM-DD
  phone: string;
  email: string;
  permanentAddress: string; // Thường trú
  currentAddress: string; // Tạm trú

  // Giấy tờ cá nhân (nhạy cảm)
  idCardNumber: string; // CCCD (12 số)
  idCardDate: string;
  idCardPlace: string;
  personalTaxCode: string; // Mã số thuế cá nhân
  bankAccount: {
    bankName: string;
    accountNumber: string;
    accountHolder: string;
  };
  educationLevel: string;
  emergencyContact: {
    name: string;
    relationship: string;
    phone: string;
  };

  // Công việc
  departmentId: string;
  departmentName: string;
  teamId?: string;
  teamName?: string;
  positionId: string;
  positionName: string;
  jobLevel: 'Nhân viên' | 'Chuyên viên' | 'Trưởng nhóm' | 'Phó phòng' | 'Trưởng phòng' | 'Giám đốc';
  directManagerId?: string;
  directManagerName?: string;
  workLocation: string; // Văn phòng Hà Nội, Chi nhánh TP.HCM, v.v.
  workRegion: 'Vùng I' | 'Vùng II' | 'Vùng III' | 'Vùng IV';
  joinDate: string;
  officialDate?: string;
  status: EmployeeStatus;

  // Quyền truy cập hệ thống & Đăng nhập
  systemRole: UserRole;
  accountStatus: 'active' | 'locked';
  loginUsername?: string;

  // Tóm tắt BHXH
  socialInsuranceNumber?: string;
  healthInsuranceCardNumber?: string;
  healthInsuranceExpiry?: string;
  healthClinicName?: string; // Nơi KCB ban đầu
  insuranceStatus: 'Chưa đăng ký' | 'Chờ báo tăng' | 'Đang tham gia' | 'Chờ báo giảm' | 'Đã dừng';
  insuranceSalary: number;

  notes?: string;
  createdAt: string;
}

// 8. Phòng ban & Nhóm & Chức danh
export interface Department {
  id: string;
  code: string;
  name: string;
  parentId?: string;
  parentName?: string;
  managerId?: string;
  managerName?: string;
  status: 'active' | 'inactive';
  memberCount: number;
}

export interface TeamCategory {
  id: string;
  departmentId: string;
  departmentName: string;
  name: string;
  leaderId?: string;
  leaderName?: string;
  region: 'Miền Bắc' | 'Miền Trung' | 'Miền Nam' | 'Toàn quốc';
  memberCount: number;
  status: 'active' | 'inactive';
}

export interface PositionCategory {
  id: string;
  name: string;
  departmentId?: string;
  departmentName?: string;
  level: 'Nhân viên' | 'Chuyên viên' | 'Trưởng nhóm' | 'Phó phòng' | 'Trưởng phòng' | 'Giám đốc';
  status: 'active' | 'inactive';
}

// ==========================================
// 9. BẢO HIỂM XÃ HỘI (SOCIAL INSURANCE)
// ==========================================

export interface InsuranceParticipant {
  id: string;
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  departmentName: string;
  socialInsuranceNumber: string; // 10 số (che bớt)
  healthInsuranceCardNumber: string; // 15 ký tự
  healthInsuranceExpiry: string;
  healthClinicName: string;
  startDate: string;
  insuranceSalary: number;
  employeeRate: number; // 10.5%
  employerRate: number; // 21.5%
  employeeAmount: number;
  employerAmount: number;
  totalAmount: number;
  status: 'Chưa đăng ký' | 'Chờ báo tăng' | 'Đang tham gia' | 'Chờ báo giảm' | 'Đã dừng';
}

// Biến động BHXH (báo tăng/giảm/điều chỉnh)
export interface InsuranceChangeRecord {
  id: string;
  code: string; // BD-2026-xxxx
  type: 'Báo tăng' | 'Báo giảm' | 'Điều chỉnh' | 'Tạm dừng đóng';
  employeeId: string;
  employeeName: string;
  departmentName: string;
  effectiveDate: string;
  reason: string;
  oldSalary?: number;
  newSalary?: number;
  status: 'Đề xuất' | 'Đã xác nhận' | 'Đã nộp CQ BHXH' | 'Đã duyệt' | 'Bị trả lại';
  submissionDate?: string;
  submissionCode?: string;
  rejectionReason?: string;
  notes?: string;
  isAutoGenerated?: boolean;
  createdAt: string;
}

// Kỳ đóng BHXH hàng tháng
export interface InsurancePeriodLine {
  employeeId: string;
  employeeCode: string;
  employeeName: string;
  departmentName: string;
  salary: number;
  pensionNLĐ: number;
  pensionDN: number;
  maternityDN: number;
  accidentDN: number;
  healthNLĐ: number;
  healthDN: number;
  unempNLĐ: number;
  unempDN: number;
  unionFeeDN: number;
  totalNLĐ: number;
  totalDN: number;
  grandTotal: number;
}

export interface InsuranceMonthlyPeriod {
  id: string;
  periodMonth: string; // MM/YYYY ví dụ: 10/2026
  totalEmployees: number;
  totalSalaryFund: number;
  // Các quỹ:
  pensionFund: { employee: number; employer: number; total: number };
  maternityFund: { employer: number; total: number };
  accidentFund: { employer: number; total: number };
  healthFund: { employee: number; employer: number; total: number };
  unemploymentFund: { employee: number; employer: number; total: number };
  tradeUnionFee: number; // Công đoàn 2% do DN đóng
  totalEmployeePaid: number;
  totalEmployerPaid: number;
  grandTotal: number;
  status: 'Nháp' | 'Đã chốt' | 'Đã nộp tiền';
  paymentDate?: string;
  paymentRefNumber?: string;
  paidAmount?: number;
  notes?: string;
  unlockedReason?: string;
  lines: InsurancePeriodLine[];
}

// Hồ sơ hưởng chế độ BHXH
export interface InsuranceClaimRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  departmentName: string;
  type: 'Ốm đau' | 'Thai sản' | 'Dưỡng sức phục hồi sức khỏe' | 'Tai nạn lao động/Bệnh nghề nghiệp' | 'Khác';
  startDate: string;
  endDate: string;
  leaveDays: number;
  submittedDate?: string;
  expectedAmount: number;
  actualAmount?: number;
  status: 'Đang chuẩn bị hồ sơ' | 'Đã nộp' | 'Đã duyệt' | 'Đã chi trả' | 'Bị trả lại';
  attachments: { name: string; size: string }[];
  notes?: string;
}

// Cấu hình BHXH theo ngày hiệu lực
export interface InsuranceConfigItem {
  id: string;
  effectiveDate: string; // YYYY-MM-DD
  title: string;
  rates: {
    employee: {
      pension: number; // 8%
      maternity: number; // 0%
      accident: number; // 0%
      health: number; // 1.5%
      unemployment: number; // 1%
      total: number; // 10.5%
    };
    employer: {
      pension: number; // 14%
      maternity: number; // 3%
      accident: number; // 0.5%
      health: number; // 3%
      unemployment: number; // 1%
      total: number; // 21.5%
    };
    tradeUnion: number; // 2%
  };
  regionMinimumWages: {
    I: number; // 5.310.000
    II: number; // 4.730.000
    III: number; // 4.140.000
    IV: number; // 3.700.000
  };
  baseSalary: number; // 2.530.000 (từ 01/07/2026) hoặc 2.340.000
  ceilingSocialInsurance: number; // 20 x baseSalary = 50.600.000
  ceilingUnemploymentInsuranceRegionI: number; // 20 x Vùng I = 106.200.000
  unpaidLeaveDaysThreshold: number; // 14 ngày
  paymentDueDayOfMonth: number; // 25
  reminderDaysBefore: number; // 5 ngày
  companyCode: string; // QL00123
  managingAgency: string; // BHXH TP. Hà Nội
}

// Nhật ký truy cập dữ liệu nhạy cảm
export interface SensitiveDataAccessLog {
  id: string;
  timestamp: string;
  actorName: string;
  actorRole: string;
  action: 'VIEW_UNMASKED' | 'EDIT_SENSITIVE' | 'EXPORT_DATA' | 'HANDOVER_DATA';
  targetEmployeeName: string;
  fieldsAccessed: string[];
  ipAddress: string;
  details?: string;
}
