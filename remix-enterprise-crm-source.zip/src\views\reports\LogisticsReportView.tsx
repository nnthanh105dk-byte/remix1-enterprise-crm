import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import {
  Truck,
  CheckCircle2,
  Clock,
  AlertTriangle,
  DollarSign,
  TrendingUp,
  Download,
  Printer,
  Search,
  Filter,
  Calendar,
  Layers,
  FileCheck,
  ShieldAlert,
  UserCheck,
} from 'lucide-react';

export const LogisticsReportView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    deliveryNotes,
    shipments,
    drivers,
    vehicles,
    codCollections,
    documentExpiries,
  } = useLogistics();

  const [activeTab, setActiveTab] = useState<'shipments' | 'cod' | 'expiries'>('shipments');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDriver, setSelectedDriver] = useState('all');

  // 1. KPI Metrics
  const kpis = useMemo(() => {
    const totalDeliveries = deliveryNotes.length;
    const deliveredSuccess = deliveryNotes.filter((d) => d.status === 'Đã giao').length;
    const failedDeliveries = deliveryNotes.filter((d) => d.status === 'Thất bại - hẹn giao lại').length;
    const onTimeRate = totalDeliveries > 0 ? Math.round((deliveredSuccess / totalDeliveries) * 100) : 0;

    const totalCodCollected = codCollections.reduce((sum, c) => sum + c.amountCollected, 0);
    const remittedCod = codCollections
      .filter((c) => c.status === 'Đã nộp về công ty')
      .reduce((sum, c) => sum + c.amountCollected, 0);
    const pendingRemitCod = totalCodCollected - remittedCod;

    const completedShipmentsCount = shipments.filter((s) => s.status === 'Hoàn tất').length;
    const avgCostPerShipment = 450000; // Chi phí trung bình mỗi chuyến xe (nhiên liệu + khấu hao)

    const urgentDocumentsCount = documentExpiries.filter((d) => d.daysRemaining <= 30).length;

    return {
      onTimeRate,
      deliveredSuccess,
      failedDeliveries,
      totalCodCollected,
      remittedCod,
      pendingRemitCod,
      completedShipmentsCount,
      avgCostPerShipment,
      urgentDocumentsCount,
    };
  }, [deliveryNotes, codCollections, shipments, documentExpiries]);

  // 2. Filtered Shipments
  const filteredShipments = useMemo(() => {
    return shipments.filter((s) => {
      const matchDriver = selectedDriver === 'all' || s.driverName.includes(selectedDriver);
      const matchSearch =
        s.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.driverName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.vehiclePlate.toLowerCase().includes(searchTerm.toLowerCase());
      return matchDriver && matchSearch;
    });
  }, [shipments, selectedDriver, searchTerm]);

  // 3. Filtered COD
  const filteredCod = useMemo(() => {
    return codCollections.filter((c) => {
      const matchSearch =
        c.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.deliveryNoteCode.toLowerCase().includes(searchTerm.toLowerCase());
      return matchSearch;
    });
  }, [codCollections, searchTerm]);

  return (
    <div className="space-y-6">
      {/* 1. Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300">
              Báo cáo Vận chuyển &amp; Giao nhận (Logistics Analytics)
            </span>
            <span className="text-xs text-slate-400">Đội xe &amp; Thu hộ COD</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-1">
            Báo cáo Hiệu suất Giao hàng (OTD) &amp; Đối soát Tiền thu hộ COD
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Đo lường tỷ lệ giao hàng đúng hẹn (On-Time Delivery), đối soát tiền nộp quỹ công ty, kiểm soát chi phí vận tải và an toàn giấy tờ xe.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-sm"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            In Báo cáo
          </button>
          <button
            onClick={() => showToast('Xuất báo cáo', 'Đã tải xuống file Excel báo cáo vận chuyển & đối soát COD.')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-colors shadow-sm"
          >
            <Download className="w-4 h-4" />
            Xuất Excel
          </button>
        </div>
      </div>

      {/* 2. Top KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Tỷ lệ giao đúng hẹn (OTD)</span>
          <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {kpis.onTimeRate}%
          </div>
          <span className="text-[11px] text-slate-400">
            {kpis.deliveredSuccess}/{deliveryNotes.length} phiếu giao thành công
          </span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Tổng tiền thu hộ COD</span>
          <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
            {kpis.totalCodCollected.toLocaleString('vi-VN')} đ
          </div>
          <span className="text-[11px] text-slate-400">{codCollections.length} phiếu thu tiền</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">COD đã nộp quỹ công ty</span>
          <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
            {kpis.remittedCod.toLocaleString('vi-VN')} đ
          </div>
          <span className="text-[11px] text-emerald-500">Đã sinh Phiếu thu Sales</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">COD tài xế còn giữ</span>
          <div className="text-lg font-bold text-amber-600 dark:text-amber-400 mt-1">
            {kpis.pendingRemitCod.toLocaleString('vi-VN')} đ
          </div>
          <span className="text-[11px] text-amber-500">Chờ bàn giao cuối ca</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Giấy tờ xe &amp; tài xế cận hạn</span>
          <div className="text-lg font-bold text-red-600 dark:text-red-400 mt-1">
            {kpis.urgentDocumentsCount} giấy tờ
          </div>
          <span className="text-[11px] text-red-500">Đăng kiểm &amp; bằng lái</span>
        </div>
      </div>

      {/* 3. Filter Bar */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="flex-1 w-full md:w-auto relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo mã chuyến, mã phiếu, tài xế, biển số xe..."
            className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <select
            value={selectedDriver}
            onChange={(e) => setSelectedDriver(e.target.value)}
            className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
          >
            <option value="all">Tất cả tài xế phụ trách</option>
            {drivers.map((d) => (
              <option key={d.id} value={d.name}>
                {d.name} ({d.phone})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 4. Tab Navigation */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 rounded-t-xl">
        <button
          onClick={() => setActiveTab('shipments')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'shipments'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Truck className="w-4 h-4" />
          Hiệu Suất Chuyến Hàng ({filteredShipments.length})
        </button>

        <button
          onClick={() => setActiveTab('cod')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'cod'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          Đối Soát Tiền Thu Hộ COD ({filteredCod.length})
        </button>

        <button
          onClick={() => setActiveTab('expiries')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'expiries'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <ShieldAlert className="w-4 h-4 text-red-500" />
          Cảnh Báo Hạn Giấy Tờ Xe &amp; Tài Xế ({documentExpiries.length})
        </button>
      </div>

      {/* 5. TAB 1: HIỆU SUẤT CHUYẾN HÀNG */}
      {activeTab === 'shipments' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã Chuyến Hàng</th>
                  <th className="px-4 py-3.5">Tài Xế &amp; Xe Vận Tải</th>
                  <th className="px-3 py-3.5 text-center">Ngày Chạy</th>
                  <th className="px-3 py-3.5 text-center">Số Điểm Dừng</th>
                  <th className="px-3 py-3.5 text-right font-bold">Tổng Thu COD</th>
                  <th className="px-3 py-3.5 text-right">Chi Phí Chuyến</th>
                  <th className="px-3 py-3.5 text-center">Trạng Thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {filteredShipments.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{s.code}</td>
                    <td className="px-4 py-3.5">
                      <div className="font-medium text-slate-900 dark:text-white">{s.driverName}</div>
                      <div className="text-xs text-slate-400 font-mono">Biển số: {s.vehiclePlate}</div>
                    </td>
                    <td className="px-3 py-3.5 text-center text-xs font-mono">{s.shipDate}</td>
                    <td className="px-3 py-3.5 text-center">
                      <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-700">
                        {s.deliveryStops?.length || 2} điểm
                      </span>
                    </td>
                    <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                      {(s.totalCodAmount || 0).toLocaleString('vi-VN')} đ
                    </td>
                    <td className="px-3 py-3.5 text-right text-xs text-slate-500">
                      450.000 đ
                    </td>
                    <td className="px-3 py-3.5 text-center">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-xs font-semibold ${
                          s.status === 'Hoàn tất'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                            : s.status === 'Đang giao'
                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300'
                        }`}
                      >
                        {s.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. TAB 2: ĐỐI SOÁT TIỀN THU HỘ COD */}
      {activeTab === 'cod' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã Phiếu Thu Hộ</th>
                  <th className="px-4 py-3.5">Khách Hàng &amp; Phiếu Giao</th>
                  <th className="px-4 py-3.5">Tài Xế Thu Tiền</th>
                  <th className="px-3 py-3.5 text-right font-bold">Số Tiền Thu</th>
                  <th className="px-3 py-3.5 text-center">Hình Thức</th>
                  <th className="px-3 py-3.5 text-center">Trạng Thái Nộp Quỹ</th>
                  <th className="px-4 py-3.5 text-center">Phiếu Thu Kế Thừa</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {filteredCod.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{c.code}</td>
                    <td className="px-4 py-3.5">
                      <div className="font-medium text-slate-900 dark:text-white">{c.customerName}</div>
                      <div className="text-xs text-blue-600 font-mono">Phiếu: {c.deliveryNoteCode}</div>
                    </td>
                    <td className="px-4 py-3.5 text-xs text-slate-700 dark:text-slate-300">{c.driverName}</td>
                    <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                      {c.amountCollected.toLocaleString('vi-VN')} đ
                    </td>
                    <td className="px-3 py-3.5 text-center text-xs">{c.paymentMethod}</td>
                    <td className="px-3 py-3.5 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          c.status === 'Đã nộp về công ty'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300'
                        }`}
                      >
                        {c.status}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-center font-mono text-xs text-slate-600 dark:text-slate-300">
                      {c.salesReceiptNumber ? (
                        <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                          {c.salesReceiptNumber}
                        </span>
                      ) : (
                        <span className="text-slate-400">Chưa sinh phiếu thu</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. TAB 3: CẢNH BÁO GIẤY TỜ XE & TÀI XẾ */}
      {activeTab === 'expiries' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mục Kiểm Tra</th>
                  <th className="px-4 py-3.5">Đối Tượng (Xe / Tài Xế)</th>
                  <th className="px-4 py-3.5">Loại Giấy Tờ</th>
                  <th className="px-3 py-3.5 text-center">Ngày Hết Hạn</th>
                  <th className="px-3 py-3.5 text-center">Số Ngày Còn Lại</th>
                  <th className="px-4 py-3.5 text-center">Trạng Thái Cảnh Báo</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {documentExpiries.map((d) => {
                  const isUrgent = d.daysRemaining <= 15;
                  const isWarning = d.daysRemaining > 15 && d.daysRemaining <= 45;
                  return (
                    <tr key={d.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                      <td className="px-4 py-3.5 font-bold text-slate-900 dark:text-white">{d.name}</td>
                      <td className="px-4 py-3.5 font-medium text-slate-800 dark:text-slate-200">{d.targetEntity}</td>
                      <td className="px-4 py-3.5 text-xs text-slate-500">{d.type}</td>
                      <td className="px-3 py-3.5 text-center font-mono text-xs">{d.expiryDate}</td>
                      <td className="px-3 py-3.5 text-center font-bold font-mono">
                        <span
                          className={`px-2 py-0.5 rounded text-xs ${
                            isUrgent
                              ? 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300'
                              : isWarning
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300'
                              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                          }`}
                        >
                          {d.daysRemaining} ngày
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                          {isUrgent ? 'Cần gia hạn khẩn cấp' : isWarning ? 'Chuẩn bị gia hạn' : 'An toàn'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
