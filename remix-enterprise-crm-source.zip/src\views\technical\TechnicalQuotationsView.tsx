import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { useTechnical } from '../../context/TechnicalContext';
import {
  TechnicalQuotationRequest,
  TechnicalQuotationLineItem,
  TechLineItemType,
} from '../../types/technical';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import {
  FileSpreadsheet,
  Search,
  CheckCircle2,
  Clock,
  AlertTriangle,
  User,
  Plus,
  Trash2,
  Send,
  RotateCcw,
  Check,
  X,
  Printer,
  ChevronRight,
  Package,
  Layers,
} from 'lucide-react';

export const TechnicalQuotationsView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { products } = useWarehouse();
  const {
    quotationRequests,
    technicalCatalog,
    acceptQuotationRequest,
    returnQuotationRequest,
    saveQuotationLines,
    completeTechnicalQuotation,
  } = useTechnical();

  // Tabs
  const [activeTab, setActiveTab] = useState<'pending' | 'mine' | 'all'>('pending');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedReq, setSelectedReq] = useState<TechnicalQuotationRequest | null>(null);

  // Return modal
  const [isReturnModalOpen, setIsReturnModalOpen] = useState(false);
  const [returnReason, setReturnReason] = useState('');

  // Accept modal
  const [isAcceptModalOpen, setIsAcceptModalOpen] = useState(false);
  const [assignedEngineer, setAssignedEngineer] = useState('Trần Văn Nam (Kỹ sư Trưởng)');

  // Bóc tách BOM items state
  const [lineItems, setLineItems] = useState<TechnicalQuotationLineItem[]>([]);
  const [surveyNotes, setSurveyNotes] = useState('');
  const [internalNotes, setInternalNotes] = useState('');

  // Pending queue count
  const pendingCount = quotationRequests.filter(
    (r) => r.status === 'Chờ tiếp nhận' || r.status === 'Cần chỉnh sửa'
  ).length;

  const filteredRequests = quotationRequests.filter((req) => {
    if (activeTab === 'pending') {
      if (req.status !== 'Chờ tiếp nhận' && req.status !== 'Cần chỉnh sửa') return false;
    }
    if (activeTab === 'mine') {
      if (!req.assignedTechStaff?.includes('Trần Văn Nam')) return false;
    }
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        req.code.toLowerCase().includes(q) ||
        req.customerName.toLowerCase().includes(q) ||
        req.opportunityCode.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleSelectRequest = (req: TechnicalQuotationRequest) => {
    setSelectedReq(req);
    setLineItems(req.items || []);
    setSurveyNotes(req.surveyNotes || '');
    setInternalNotes(req.notes || '');
  };

  const handleAcceptSubmit = () => {
    if (!selectedReq) return;
    acceptQuotationRequest(selectedReq.id, assignedEngineer);
    setSelectedReq((prev) => (prev ? { ...prev, status: 'Đang khảo sát', assignedTechStaff: assignedEngineer } : null));
    setIsAcceptModalOpen(false);
  };

  const handleReturnSubmit = () => {
    if (!selectedReq || !returnReason.trim()) {
      showToast('Yêu cầu lý do', 'Vui lòng nhập lý do trả lại yêu cầu kỹ thuật.', 'warning');
      return;
    }
    returnQuotationRequest(selectedReq.id, returnReason);
    setSelectedReq((prev) => (prev ? { ...prev, status: 'Cần chỉnh sửa', returnReason } : null));
    setIsReturnModalOpen(false);
    setReturnReason('');
  };

  // Thêm dòng bóc tách mới
  const handleAddLine = (type: TechLineItemType) => {
    const newLine: TechnicalQuotationLineItem = {
      id: `line-${Date.now()}`,
      lineType: type,
      name: type === 'Nhân công' ? 'Nhân công Kỹ thuật / Lắp đặt' : '',
      unit: type === 'Nhân công' ? 'Giờ' : type === 'Dịch vụ' ? 'Gói' : 'Bộ',
      quantity: 1,
      unitPrice: type === 'Nhân công' ? 250000 : 0,
      total: type === 'Nhân công' ? 250000 : 0,
      hours: type === 'Nhân công' ? 1 : undefined,
      hourlyRate: type === 'Nhân công' ? 250000 : undefined,
    };
    setLineItems([...lineItems, newLine]);
  };

  const handleCatalogSelect = (index: number, sku: string) => {
    const catItem = technicalCatalog.find((c) => c.sku === sku);
    const prod = products.find((p) => p.sku === sku);
    const totalStock = prod ? Object.values(prod.stocks).reduce((a, b) => a + b, 0) : 0;
    const avail = Math.max(0, totalStock - (prod?.reserved || 0));

    if (!catItem) return;

    setLineItems((prev) =>
      prev.map((item, idx) =>
        idx === index
          ? {
              ...item,
              sku: catItem.sku,
              name: catItem.name,
              unit: catItem.unit,
              unitPrice: catItem.packagePrice || catItem.serviceHourlyRate || (prod ? prod.costPrice * 1.3 : 1000000),
              total: (catItem.packagePrice || catItem.serviceHourlyRate || 1000000) * item.quantity,
              availableStock: avail,
              costPrice: prod?.costPrice,
            }
          : item
      )
    );
  };

  const handleUpdateLine = (index: number, updates: Partial<TechnicalQuotationLineItem>) => {
    setLineItems((prev) =>
      prev.map((item, idx) => {
        if (idx !== index) return item;
        const merged = { ...item, ...updates };
        if (merged.lineType === 'Nhân công') {
          merged.total = (merged.hours || 1) * (merged.hourlyRate || 250000);
        } else {
          merged.total = merged.quantity * merged.unitPrice;
        }
        return merged;
      })
    );
  };

  const handleRemoveLine = (index: number) => {
    setLineItems(lineItems.filter((_, idx) => idx !== index));
  };

  const handleSaveQuotation = () => {
    if (!selectedReq) return;
    saveQuotationLines(selectedReq.id, lineItems, surveyNotes, internalNotes);
    setSelectedReq((prev) => (prev ? { ...prev, items: lineItems, surveyNotes, notes: internalNotes } : null));
  };

  const handleCompleteQuotation = () => {
    if (!selectedReq) return;
    if (lineItems.length === 0) {
      showToast('Chưa có hạng mục', 'Vui lòng bóc tách ít nhất một hạng mục kỹ thuật.', 'warning');
      return;
    }
    saveQuotationLines(selectedReq.id, lineItems, surveyNotes, internalNotes);
    completeTechnicalQuotation(selectedReq.id);
    setSelectedReq((prev) =>
      prev ? { ...prev, status: 'Hoàn tất phần kỹ thuật', items: lineItems } : null
    );
  };

  const calculateTotalBOM = () => {
    return lineItems.reduce((sum, item) => sum + item.total, 0);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50">
              <FileSpreadsheet className="w-5 h-5" />
            </span>
            Báo Giá Kỹ Thuật (Technical Quotation)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Tiếp nhận yêu cầu giải pháp từ Sales, khảo sát hiện trường, bóc tách BOM (thiết bị, nhân công, dịch vụ) và đối soát tồn kho
          </p>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('pending')}
            className={`py-2.5 px-4 font-bold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'pending'
                ? 'border-sky-600 text-sky-600 dark:text-sky-400 bg-sky-50/50 dark:bg-sky-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span>Yêu cầu từ Sales</span>
            {pendingCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500 text-white">
                {pendingCount}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('mine')}
            className={`py-2.5 px-4 font-bold border-b-2 transition-colors ${
              activeTab === 'mine'
                ? 'border-sky-600 text-sky-600 dark:text-sky-400 bg-sky-50/50 dark:bg-sky-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Báo giá của tôi
          </button>
          <button
            onClick={() => setActiveTab('all')}
            className={`py-2.5 px-4 font-bold border-b-2 transition-colors ${
              activeTab === 'all'
                ? 'border-sky-600 text-sky-600 dark:text-sky-400 bg-sky-50/50 dark:bg-sky-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Tất cả báo giá
          </button>
        </div>

        <div className="relative max-w-xs w-full pb-1">
          <input
            type="text"
            placeholder="Tìm theo mã YCKT, cơ hội, khách hàng..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
        </div>
      </div>

      {/* Main Layout: 2 Cột */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Danh sách yêu cầu kỹ thuật bên trái */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col h-[750px] overflow-hidden">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 font-bold text-xs text-slate-700 dark:text-slate-300">
            Hàng Đợi Yêu Cầu ({filteredRequests.length})
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {filteredRequests.map((req) => {
              const isSelected = selectedReq?.id === req.id;
              const isOverdue = new Date(req.deadlineDate).getTime() < Date.now();

              return (
                <div
                  key={req.id}
                  onClick={() => handleSelectRequest(req)}
                  className={`p-3.5 cursor-pointer transition-colors text-xs space-y-1.5 ${
                    isSelected
                      ? 'bg-sky-50/80 dark:bg-sky-950/40 border-l-4 border-sky-600'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-sky-600 dark:text-sky-400">{req.code}</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        req.status === 'Chờ tiếp nhận'
                          ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                          : req.status === 'Hoàn tất phần kỹ thuật'
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : 'bg-sky-100 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300'
                      }`}
                    >
                      {req.status}
                    </span>
                  </div>

                  <h4 className="font-bold text-slate-900 dark:text-white line-clamp-1">{req.customerName}</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-[11px] line-clamp-2">
                    {req.requirementDetails}
                  </p>

                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100 dark:border-slate-800/60">
                    <span className="text-slate-400 font-mono">Cơ hội: {req.opportunityCode}</span>
                    <span
                      className={`flex items-center gap-1 font-mono font-bold ${
                        isOverdue ? 'text-rose-600' : 'text-slate-500'
                      }`}
                    >
                      <Clock className="w-3 h-3" />
                      Hạn: {req.deadlineDate}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Khung làm việc bóc tách kỹ thuật bên phải */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col h-[750px] overflow-hidden">
          {selectedReq ? (
            <>
              {/* Header chi tiết yêu cầu */}
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono font-bold text-sky-600 bg-sky-50 dark:bg-sky-950 px-2 py-0.5 rounded">
                      {selectedReq.code}
                    </span>
                    <span className="text-slate-400">Từ Cơ hội: {selectedReq.opportunityCode}</span>
                  </div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base">
                    {selectedReq.customerName}
                  </h3>
                  <p className="text-slate-500 text-[11px]">{selectedReq.siteAddress}</p>
                </div>

                {/* Các nút hành động quy trình */}
                <div className="flex items-center gap-2">
                  {selectedReq.status === 'Chờ tiếp nhận' && (
                    <>
                      <button
                        onClick={() => setIsReturnModalOpen(true)}
                        className="px-3 py-1.5 rounded-lg border border-rose-300 text-rose-600 hover:bg-rose-50 font-semibold"
                      >
                        Trả lại Sales
                      </button>
                      <button
                        onClick={() => setIsAcceptModalOpen(true)}
                        className="px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-semibold shadow-xs"
                      >
                        Tiếp nhận khảo sát &rarr;
                      </button>
                    </>
                  )}

                  {selectedReq.status !== 'Chờ tiếp nhận' && (
                    <>
                      <button
                        onClick={handleSaveQuotation}
                        className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                      >
                        Lưu nháp bóc tách
                      </button>
                      <button
                        onClick={handleCompleteQuotation}
                        className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs flex items-center gap-1.5"
                      >
                        <Check className="w-4 h-4" />
                        <span>Hoàn tất &amp; Gửi Sales &rarr;</span>
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Document Chain Bar */}
              <div className="p-3 bg-slate-100/60 dark:bg-slate-950/40 border-b border-slate-200 dark:border-slate-800 shrink-0">
                <DocumentChainBar chain={selectedReq.chain} currentType="quotation" />
              </div>

              {/* Nội dung bóc tách BOM */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 text-xs">
                {/* Thông tin yêu cầu từ Sales */}
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between font-bold text-slate-800 dark:text-slate-200">
                    <span>Nhu cầu giải pháp từ Sales:</span>
                    <span className="text-slate-400 font-normal">
                      Phụ trách: <strong>{selectedReq.assignedTechStaff || 'Chưa gán'}</strong>
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-300 leading-relaxed">
                    {selectedReq.requirementDetails}
                  </p>
                  {selectedReq.returnReason && (
                    <p className="text-rose-600 font-medium">Lý do yêu cầu điều chỉnh: {selectedReq.returnReason}</p>
                  )}
                </div>

                {/* Khảo sát hiện trường */}
                <div className="space-y-1.5">
                  <label className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                    <span>Ghi chú khảo sát hiện trường:</span>
                  </label>
                  <textarea
                    rows={2}
                    placeholder="Mặt bằng thi công, hạ tầng nguồn điện, khoảng cách tuyến cáp..."
                    value={surveyNotes}
                    onChange={(e) => setSurveyNotes(e.target.value)}
                    className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>

                {/* Bảng bóc tách hạng mục (BOM) */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      Bóc Tách Hạng Mục Kỹ Thuật (BOM)
                    </h4>
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => handleAddLine('Thiết bị')}
                        className="px-2 py-1 rounded bg-sky-50 text-sky-700 border border-sky-200 font-bold hover:bg-sky-100"
                      >
                        + Thiết bị
                      </button>
                      <button
                        onClick={() => handleAddLine('Vật tư')}
                        className="px-2 py-1 rounded bg-amber-50 text-amber-700 border border-amber-200 font-bold hover:bg-amber-100"
                      >
                        + Vật tư
                      </button>
                      <button
                        onClick={() => handleAddLine('Nhân công')}
                        className="px-2 py-1 rounded bg-emerald-50 text-emerald-700 border border-emerald-200 font-bold hover:bg-emerald-100"
                      >
                        + Nhân công
                      </button>
                      <button
                        onClick={() => handleAddLine('Dịch vụ')}
                        className="px-2 py-1 rounded bg-purple-50 text-purple-700 border border-purple-200 font-bold hover:bg-purple-100"
                      >
                        + Dịch vụ
                      </button>
                    </div>
                  </div>

                  <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300">
                        <tr>
                          <th className="p-2.5 w-24">Loại</th>
                          <th className="p-2.5">Tên Hạng Mục / SKU</th>
                          <th className="p-2.5 w-16 text-center">ĐVT</th>
                          <th className="p-2.5 w-20 text-center">SL / Giờ</th>
                          <th className="p-2.5 w-28 text-right">Đơn Giá</th>
                          <th className="p-2.5 w-32 text-right">Thành Tiền</th>
                          <th className="p-2.5 w-8 text-center"></th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {lineItems.length === 0 ? (
                          <tr>
                            <td colSpan={7} className="p-6 text-center text-slate-400 italic">
                              Chưa có hạng mục nào. Bấm các nút phía trên để thêm Thiết bị, Vật tư, Nhân công hoặc Dịch vụ.
                            </td>
                          </tr>
                        ) : (
                          lineItems.map((item, idx) => (
                            <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                              <td className="p-2">
                                <span
                                  className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                    item.lineType === 'Thiết bị'
                                      ? 'bg-sky-100 text-sky-700'
                                      : item.lineType === 'Vật tư'
                                      ? 'bg-amber-100 text-amber-700'
                                      : item.lineType === 'Nhân công'
                                      ? 'bg-emerald-100 text-emerald-700'
                                      : 'bg-purple-100 text-purple-700'
                                  }`}
                                >
                                  {item.lineType}
                                </span>
                              </td>
                              <td className="p-2 space-y-1">
                                {item.lineType === 'Thiết bị' || item.lineType === 'Dịch vụ' ? (
                                  <select
                                    value={item.sku || ''}
                                    onChange={(e) => handleCatalogSelect(idx, e.target.value)}
                                    className="w-full p-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                                  >
                                    <option value="">-- Chọn từ danh mục kỹ thuật --</option>
                                    {technicalCatalog
                                      .filter((c) => (item.lineType === 'Dịch vụ' ? c.isService : !c.isService))
                                      .map((cat) => (
                                        <option key={cat.sku} value={cat.sku}>
                                          {cat.sku} - {cat.name}
                                        </option>
                                      ))}
                                  </select>
                                ) : (
                                  <input
                                    type="text"
                                    placeholder="Tên vật tư, nhân công hoặc hạng mục..."
                                    value={item.name}
                                    onChange={(e) => handleUpdateLine(idx, { name: e.target.value })}
                                    className="w-full p-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                                  />
                                )}

                                {item.availableStock !== undefined && (
                                  <div className="flex items-center gap-1.5 text-[10px]">
                                    <span className="text-slate-400">Tồn khả dụng:</span>
                                    <span
                                      className={`font-mono font-bold ${
                                        item.availableStock >= item.quantity
                                          ? 'text-emerald-600'
                                          : 'text-rose-600'
                                      }`}
                                    >
                                      {item.availableStock} {item.unit}
                                    </span>
                                    {item.availableStock < item.quantity && (
                                      <span className="text-rose-500 font-semibold">(Cần nhập thêm)</span>
                                    )}
                                  </div>
                                )}
                              </td>
                              <td className="p-2 text-center">
                                <input
                                  type="text"
                                  value={item.unit}
                                  onChange={(e) => handleUpdateLine(idx, { unit: e.target.value })}
                                  className="w-12 text-center p-1 rounded border border-slate-300 dark:border-slate-700"
                                />
                              </td>
                              <td className="p-2 text-center">
                                <input
                                  type="number"
                                  min={1}
                                  value={item.lineType === 'Nhân công' ? item.hours || 1 : item.quantity}
                                  onChange={(e) =>
                                    handleUpdateLine(
                                      idx,
                                      item.lineType === 'Nhân công'
                                        ? { hours: Number(e.target.value) }
                                        : { quantity: Number(e.target.value) }
                                    )
                                  }
                                  className="w-16 text-center p-1 rounded border border-slate-300 dark:border-slate-700 font-mono font-bold"
                                />
                              </td>
                              <td className="p-2 text-right">
                                <input
                                  type="number"
                                  value={item.lineType === 'Nhân công' ? item.hourlyRate || 250000 : item.unitPrice}
                                  onChange={(e) =>
                                    handleUpdateLine(
                                      idx,
                                      item.lineType === 'Nhân công'
                                        ? { hourlyRate: Number(e.target.value) }
                                        : { unitPrice: Number(e.target.value) }
                                    )
                                  }
                                  className="w-24 text-right p-1 rounded border border-slate-300 dark:border-slate-700 font-mono"
                                />
                              </td>
                              <td className="p-2 text-right font-mono font-bold text-slate-900 dark:text-white">
                                {item.total.toLocaleString()} đ
                              </td>
                              <td className="p-2 text-center">
                                <button
                                  onClick={() => handleRemoveLine(idx)}
                                  className="text-slate-400 hover:text-rose-600"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </td>
                            </tr>
                          ))
                        )}
                      </tbody>
                      {lineItems.length > 0 && (
                        <tfoot className="bg-slate-50 dark:bg-slate-800/80 font-bold border-t border-slate-200 dark:border-slate-700">
                          <tr>
                            <td colSpan={5} className="p-3 text-right text-slate-700 dark:text-slate-300">
                              Tổng cộng Phần Kỹ Thuật (Chưa VAT):
                            </td>
                            <td className="p-3 text-right font-mono text-base text-sky-600 dark:text-sky-400">
                              {calculateTotalBOM().toLocaleString()} đ
                            </td>
                            <td></td>
                          </tr>
                        </tfoot>
                      )}
                    </table>
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-400 p-8 text-center">
              <FileSpreadsheet className="w-12 h-12 text-slate-300 dark:text-slate-700 mb-3" />
              <p className="font-medium text-sm">
                Chọn một yêu cầu kỹ thuật từ danh sách bên trái để tiến hành bóc tách định mức BOM
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Modal: Tiếp nhận yêu cầu */}
      {isAcceptModalOpen && selectedReq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2">
              Tiếp Nhận Yêu Cầu Kỹ Thuật
            </h3>
            <p className="text-slate-500 mb-3">
              Phân công kỹ sư chủ trì khảo sát và lập báo giá kỹ thuật cho yêu cầu {selectedReq.code}.
            </p>
            <div className="space-y-3">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Kỹ sư phụ trách</label>
                <select
                  value={assignedEngineer}
                  onChange={(e) => setAssignedEngineer(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                >
                  <option value="Trần Văn Nam (Kỹ sư Trưởng)">Trần Văn Nam (Kỹ sư Trưởng)</option>
                  <option value="Nguyễn Văn Tuấn (Kỹ sư Mạng)">Nguyễn Văn Tuấn (Kỹ sư Mạng)</option>
                  <option value="Lê Hữu Đạt (Kỹ sư Hệ thống)">Lê Hữu Đạt (Kỹ sư Hệ thống)</option>
                  <option value="Vũ Quốc Bảo (Kỹ thuật viên)">Vũ Quốc Bảo (Kỹ thuật viên)</option>
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setIsAcceptModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700"
                >
                  Hủy
                </button>
                <button
                  onClick={handleAcceptSubmit}
                  className="px-3 py-1.5 rounded-lg bg-sky-600 text-white font-semibold shadow-xs"
                >
                  Xác nhận tiếp nhận
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Trả lại yêu cầu cho Sales */}
      {isReturnModalOpen && selectedReq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-xs">
            <h3 className="font-bold text-rose-600 text-sm mb-2">
              Trả Lại Yêu Cầu Cho Sales
            </h3>
            <p className="text-slate-500 mb-3">
              Vui lòng nhập lý do cụ thể (thiếu thông tin mặt bằng, ngân sách không khả thi, thời hạn quá gấp...)
            </p>
            <div className="space-y-3">
              <textarea
                rows={3}
                required
                placeholder="Nhập lý do trả lại bắt buộc..."
                value={returnReason}
                onChange={(e) => setReturnReason(e.target.value)}
                className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
              <div className="flex justify-end gap-2">
                <button
                  onClick={() => setIsReturnModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700"
                >
                  Hủy
                </button>
                <button
                  onClick={handleReturnSubmit}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-semibold shadow-xs"
                >
                  Trả lại cho Sales
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
