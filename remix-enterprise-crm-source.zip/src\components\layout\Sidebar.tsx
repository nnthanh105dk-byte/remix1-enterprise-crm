import React, { useState, useEffect } from 'react';
import { useCRM } from '../../context/CRMContext';
import { ActiveModule } from '../../types/crm';
import { getMenuTitle } from '../../i18n/translations';
import {
  LayoutDashboard,
  FileBarChart,
  Warehouse,
  Wallet,
  Truck,
  Calculator,
  Wrench,
  Users,
  Settings,
  ChevronDown,
  ChevronRight,
  PanelLeftClose,
  PanelLeftOpen,
  X,
  ShieldAlert,
  BarChart2,
  TrendingUp,
  Target,
  Filter,
  CheckCircle2,
  XCircle,
  Award,
} from 'lucide-react';
import { APlusLogo } from '../common/APlusLogo';
import { useMultiTenant } from '../../context/MultiTenantContext';

export interface MenuItem {
  id: string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  path?: string;
  children: MenuItem[];
  isHeader?: boolean;
}

/**
 * Quy ước cấu trúc dữ liệu menu:
 * - Cấp 1 "-" : menu lớn
 * - Cấp 2 ">" : nhóm báo cáo
 * - Cấp 3 ">>": từng báo cáo cụ thể
 */
export const menuItems: MenuItem[] = [
  // 1. - Dashboard
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    path: '/dashboard',
    children: [],
  },

  // 2. - Báo cáo (3 cấp)
  {
    id: 'reports',
    label: 'Báo cáo',
    icon: FileBarChart,
    path: '/reports',
    children: [
      // > Sales
      {
        id: 'report-group-sales',
        label: 'Sales',
        icon: Wallet,
        path: '/reports/sales',
        children: [
          // >> Tổng quan Sales
          {
            id: 'sales-overview',
            label: 'Tổng quan Sales',
            icon: BarChart2,
            path: '/reports/sales/overview',
            children: [],
          },
          // >> Doanh thu
          {
            id: 'sales-revenue',
            label: 'Doanh thu',
            icon: TrendingUp,
            path: '/reports/sales/revenue',
            children: [],
          },
          // >> Dự báo doanh số
          {
            id: 'sales-forecast',
            label: 'Dự báo doanh số',
            icon: Target,
            path: '/reports/sales/forecast',
            children: [],
          },
          // >> Phễu bán hàng
          {
            id: 'sales-funnel',
            label: 'Phễu bán hàng',
            icon: Filter,
            path: '/reports/sales/funnel',
            children: [],
          },
          // >> Deal thắng
          {
            id: 'sales-won',
            label: 'Deal thắng',
            icon: CheckCircle2,
            path: '/reports/sales/won',
            children: [],
          },
          // >> Deal thua
          {
            id: 'sales-lost',
            label: 'Deal thua',
            icon: XCircle,
            path: '/reports/sales/lost',
            children: [],
          },
          // >> Hiệu suất nhân viên
          {
            id: 'sales-productivity',
            label: 'Hiệu suất nhân viên',
            icon: Award,
            path: '/reports/sales/productivity',
            children: [],
          },
          // >> Quản lý & phân tích Lead
          {
            id: 'sales-leads',
            label: 'Quản lý & phân tích Lead',
            icon: Users,
            path: '/reports/sales/leads',
            children: [],
          },
        ],
      },
      // > Kho
      {
        id: 'reports-inventory',
        label: 'Kho',
        icon: Warehouse,
        path: '/reports/inventory',
        children: [],
      },
      // > Vận chuyển
      {
        id: 'reports-logistics',
        label: 'Vận chuyển',
        icon: Truck,
        path: '/reports/logistics',
        children: [],
      },
      // > Kế toán
      {
        id: 'reports-accounting',
        label: 'Kế toán',
        icon: Calculator,
        path: '/reports/accounting',
        children: [],
      },
      // > Kỹ thuật
      {
        id: 'reports-technical',
        label: 'Kỹ thuật',
        icon: Wrench,
        path: '/reports/technical',
        children: [],
      },
      // > Nhân sự
      {
        id: 'reports-hr',
        label: 'Nhân sự',
        icon: Users,
        path: '/reports/hr',
        children: [],
      },
    ],
  },

  // 3. - Quản lý kho
  {
    id: 'inventory',
    label: 'Quản lý kho',
    icon: Warehouse,
    path: '/inventory',
    children: [
      // > Tổng quan tồn kho
      {
        id: 'inventory-overview',
        label: 'Tổng quan tồn kho',
        path: '/inventory/overview',
        children: [],
      },
      // > Nhập kho
      {
        id: 'inventory-stock-in',
        label: 'Nhập kho',
        path: '/inventory/stock-in',
        children: [],
      },
      // > Xuất kho
      {
        id: 'inventory-stock-out',
        label: 'Xuất kho',
        path: '/inventory/stock-out',
        children: [],
      },
      // > Lịch sử kho theo ngày
      {
        id: 'inventory-history',
        label: 'Lịch sử kho theo ngày',
        path: '/inventory/history',
        children: [],
      },
      // > Hàng sắp hết hạn
      {
        id: 'inventory-expiry',
        label: 'Hàng sắp hết hạn',
        path: '/inventory/expiry',
        children: [],
      },
    ],
  },

  // 4. - Quản lý Sales
  {
    id: 'sales',
    label: 'Quản lý Sales',
    icon: Wallet,
    path: '/sales',
    children: [
      // > Lead
      {
        id: 'leads',
        label: 'Lead',
        path: '/sales/leads',
        children: [],
      },
      // > Khách hàng (Account)
      {
        id: 'customers',
        label: 'Khách hàng',
        path: '/sales/customers',
        children: [],
      },
      // > Cơ hội bán hàng (Opportunity)
      {
        id: 'opportunities',
        label: 'Cơ hội bán hàng',
        path: '/sales/opportunities',
        children: [],
      },
      // > Báo giá (Quote)
      {
        id: 'quotations',
        label: 'Báo giá',
        path: '/sales/quotations',
        children: [],
      },
      // > Đơn hàng & Phê duyệt (Booking Approval)
      {
        id: 'sales-orders',
        label: 'Đơn hàng & Phê duyệt',
        path: '/sales/orders',
        children: [],
      },
      // > Hợp đồng (Contract)
      {
        id: 'contracts',
        label: 'Hợp đồng',
        path: '/sales/contracts',
        children: [],
      },
      // > Hóa đơn (Invoice)
      {
        id: 'sales-invoices',
        label: 'Hóa đơn',
        path: '/sales/invoices',
        children: [],
      },
      // > Phiếu thu (Printed Receipt)
      {
        id: 'sales-receipts',
        label: 'Phiếu thu',
        path: '/sales/receipts',
        children: [],
      },
      // > Hoạt động & Lịch hẹn
      {
        id: 'sales-activities',
        label: 'Hoạt động & Lịch hẹn',
        path: '/sales/activities',
        children: [],
      },
      // > Công việc
      {
        id: 'tasks',
        label: 'Công việc',
        path: '/tasks',
        children: [],
      },
      // > Lịch làm việc
      {
        id: 'calendar',
        label: 'Lịch làm việc',
        path: '/calendar',
        children: [],
      },
    ],
  },

  // 5. - Quản lý Vận chuyển
  {
    id: 'logistics',
    label: 'Quản lý Vận chuyển',
    icon: Truck,
    path: '/logistics',
    children: [
      // [Xử lý đơn & giao hàng]
      {
        id: 'header-logistics-orders',
        label: '[Xử lý đơn & giao hàng]',
        isHeader: true,
        children: [],
      },
      // > Duyệt đơn hàng (Booking Approval)
      {
        id: 'logistics-order-approval',
        label: 'Duyệt đơn hàng',
        path: '/logistics/order-approval',
        children: [],
      },
      // > Xuất kho (Stock out)
      {
        id: 'logistics-stock-out',
        label: 'Xuất kho',
        path: '/logistics/stock-out',
        children: [],
      },
      // > Phiếu giao hàng (Delivery Notes)
      {
        id: 'logistics-delivery-notes',
        label: 'Phiếu giao hàng',
        path: '/logistics/delivery-notes',
        children: [],
      },
      // > Chuyến hàng (Shipment)
      {
        id: 'logistics-shipments',
        label: 'Chuyến hàng',
        path: '/logistics/shipments',
        children: [],
      },
      // > Bàn giao (Handover)
      {
        id: 'logistics-handover',
        label: 'Bàn giao',
        path: '/logistics/handover',
        children: [],
      },
      // > Thu hộ (Collection Form)
      {
        id: 'logistics-cod-collections',
        label: 'Thu hộ',
        path: '/logistics/cod-collections',
        children: [],
      },
      // [Mua hàng & nhập kho]
      {
        id: 'header-logistics-purchasing',
        label: '[Mua hàng & nhập kho]',
        isHeader: true,
        children: [],
      },
      // > Đơn mua hàng (Purchase Order)
      {
        id: 'logistics-purchase-orders',
        label: 'Đơn mua hàng',
        path: '/logistics/purchase-orders',
        children: [],
      },
      // > Hóa đơn mua hàng (Purchase Invoice)
      {
        id: 'logistics-purchase-invoices',
        label: 'Hóa đơn mua hàng',
        path: '/logistics/purchase-invoices',
        children: [],
      },
      // > Nhập kho (Stock in)
      {
        id: 'logistics-stock-in',
        label: 'Nhập kho',
        path: '/logistics/stock-in',
        children: [],
      },
      // > Đề nghị thanh toán (Payment Request)
      {
        id: 'logistics-payment-requests',
        label: 'Đề nghị thanh toán',
        path: '/logistics/payment-requests',
        children: [],
      },
      // [Theo dõi & cảnh báo]
      {
        id: 'header-logistics-tracking',
        label: '[Theo dõi & cảnh báo]',
        isHeader: true,
        children: [],
      },
      // > Lịch sử kho theo ngày (Stock out transition)
      {
        id: 'logistics-stock-history',
        label: 'Lịch sử kho theo ngày',
        path: '/logistics/stock-history',
        children: [],
      },
      // > Hàng sắp hết hạn (Approching expiry)
      {
        id: 'logistics-approaching-expiry',
        label: 'Hàng sắp hết hạn',
        path: '/logistics/approaching-expiry',
        children: [],
      },
      // > Giấy tờ sắp hết hạn (Registration expiry)
      {
        id: 'logistics-document-expiry',
        label: 'Giấy tờ sắp hết hạn',
        path: '/logistics/document-expiry',
        children: [],
      },
    ],
  },

  // 6. - Kế toán
  {
    id: 'accounting',
    label: 'Kế toán',
    icon: Calculator,
    path: '/accounting',
    children: [
      {
        id: 'accounting-debt',
        label: 'Công nợ',
        path: '/accounting/debt',
        children: [],
      },
      {
        id: 'accounting-invoices',
        label: 'Hóa đơn & Báo giá',
        path: '/accounting/invoices',
        children: [],
      },
      {
        id: 'accounting-transactions',
        label: 'Giao dịch & Dòng tiền',
        path: '/accounting/transactions',
        children: [],
      },
      {
        id: 'accounting-reports',
        label: 'Báo cáo tài chính',
        path: '/accounting/reports',
        children: [],
      },
    ],
  },

  // 7. - Kỹ thuật
  {
    id: 'technical',
    label: 'Kỹ thuật',
    icon: Wrench,
    path: '/technical',
    children: [
      // [Khách hàng & báo giá]
      {
        id: 'header-tech-cust-quote',
        label: '[Khách hàng & báo giá]',
        isHeader: true,
        children: [],
      },
      // > Hồ sơ khách hàng (Customer Name)
      {
        id: 'technical-customers',
        label: 'Hồ sơ khách hàng',
        path: '/technical/customers',
        children: [],
      },
      // > Danh mục kỹ thuật (Directory)
      {
        id: 'technical-directory',
        label: 'Danh mục kỹ thuật',
        path: '/technical/directory',
        children: [],
      },
      // > Báo giá kỹ thuật (Quotation)
      {
        id: 'technical-quotations',
        label: 'Báo giá kỹ thuật',
        path: '/technical/quotations',
        children: [],
      },
      // [Triển khai & hợp đồng]
      {
        id: 'header-tech-deploy-contract',
        label: '[Triển khai & hợp đồng]',
        isHeader: true,
        children: [],
      },
      // > Hợp đồng (Contract)
      {
        id: 'technical-contracts',
        label: 'Hợp đồng',
        path: '/technical/contracts',
        children: [],
      },
      // > Kế hoạch tổng thể (Master planning)
      {
        id: 'technical-master-planning',
        label: 'Kế hoạch tổng thể',
        path: '/technical/master-planning',
        children: [],
      },
      // > Đề nghị thanh toán (Payment Request)
      {
        id: 'technical-payment-requests',
        label: 'Đề nghị thanh toán',
        path: '/technical/payment-requests',
        children: [],
      },
      // [Bảo hành & gia hạn]
      {
        id: 'header-tech-warranty-renew',
        label: '[Bảo hành & gia hạn]',
        isHeader: true,
        children: [],
      },
      // > Xuất kho bảo hành (Stock out for Warranty)
      {
        id: 'technical-warranty-stock-out',
        label: 'Xuất kho bảo hành',
        path: '/technical/warranty-stock-out',
        children: [],
      },
      // > Hợp đồng sắp hết hạn (Contract going to Expired)
      {
        id: 'technical-expiring-contracts',
        label: 'Hợp đồng sắp hết hạn',
        path: '/technical/expiring-contracts',
        children: [],
      },
    ],
  },

  // 8. - Quản lý nhân sự
  {
    id: 'hr',
    label: 'Quản lý nhân sự',
    icon: Users,
    path: '/hr',
    children: [
      {
        id: 'hr-staff',
        label: 'Nhân viên',
        path: '/hr/staff',
        children: [],
      },
      {
        id: 'hr-insurance',
        label: 'Bảo hiểm xã hội',
        path: '/hr/insurance',
        children: [],
      },
      {
        id: 'my-profile',
        label: 'Hồ sơ của tôi',
        path: '/hr/my-profile',
        children: [],
      },
    ],
  },

  // 9. - Cài đặt hệ thống
  {
    id: 'settings',
    label: 'Cài đặt hệ thống',
    icon: Settings,
    path: '/settings',
    children: [
      // [Tài khoản & phân quyền]
      {
        id: 'header-settings-auth',
        label: '[Tài khoản & phân quyền]',
        isHeader: true,
        children: [],
      },
      // > Người dùng & Thành viên (User & Membership)
      {
        id: 'settings-users',
        label: 'Nhân sự & Thành viên',
        path: '/settings/users',
        children: [],
      },
      // > Nhóm quyền & Scopes (Group Permission)
      {
        id: 'settings-permissions',
        label: 'Cơ cấu & Phân quyền',
        path: '/settings/permissions',
        children: [],
      },
      // > Sơ đồ kiến trúc CSDL & Phân giải (System Architecture)
      {
        id: 'system-architecture',
        label: 'Sơ đồ kiến trúc CSDL',
        path: '/settings/architecture',
        children: [],
      },
      // [Cấu hình]
      {
        id: 'header-settings-config',
        label: '[Cấu hình]',
        isHeader: true,
        children: [],
      },
      // > Cấu hình hệ thống (System Configuration)
      {
        id: 'settings-system',
        label: 'Cấu hình hệ thống',
        path: '/settings/system',
        children: [],
      },
      // > Cấu hình nghiệp vụ (Application Config)
      {
        id: 'settings-app',
        label: 'Cấu hình nghiệp vụ',
        path: '/settings/app',
        children: [],
      },
      // [Danh mục]
      {
        id: 'header-settings-catalogs',
        label: '[Danh mục]',
        isHeader: true,
        children: [],
      },
      // > Từ điển giá trị (Dictionary)
      {
        id: 'settings-dictionary',
        label: 'Từ điển giá trị',
        path: '/settings/dictionary',
        children: [],
      },
      // > Danh mục dữ liệu (Directories)
      {
        id: 'settings-directories',
        label: 'Danh mục dữ liệu',
        path: '/settings/directories',
        children: [],
      },
      // [Giám sát]
      {
        id: 'header-settings-monitoring',
        label: '[Giám sát]',
        isHeader: true,
        children: [],
      },
      // > Nhật ký đồng bộ (Synchronization Log)
      {
        id: 'settings-sync-logs',
        label: 'Nhật ký đồng bộ',
        path: '/settings/sync-logs',
        children: [],
      },
    ],
  },
];

interface SidebarProps {
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ mobileOpen, onCloseMobile }) => {
  const {
    activeModule,
    setActiveModule,
    sidebarCollapsed,
    toggleSidebarCollapsed,
    currentTenant,
    themeDef,
    customTheme,
    isDarkMode,
    currentRole,
    currentUser,
    language,
  } = useCRM();

  const themeColor = customTheme?.primaryColor || themeDef?.previewColor || '#002659';
  const { logout, currentCompany, isPlatformMode, setIsPlatformMode, pendingCompanyRegistrations } = useMultiTenant();

  const pendingRequestsCount = React.useMemo(() => {
    return pendingCompanyRegistrations?.filter((r) => r.status === 'PENDING').length || 0;
  }, [pendingCompanyRegistrations]);

  // Filter menu items by role
  const filteredMenuItems = React.useMemo(() => {
    // 1. Super Admin & Admin: Toàn quyền xem mọi menu
    if (currentRole === 'Super Admin' || currentRole === 'Admin') {
      return menuItems;
    }

    // 2. Ban Giám Đốc (Hồ Minh Châu): Dashboard + Toàn bộ Báo cáo + Hồ sơ cá nhân
    if (currentRole === 'Director') {
      return menuItems
        .filter((item) => ['dashboard', 'reports', 'hr'].includes(item.id))
        .map((item) => {
          if (item.id === 'hr') {
            return {
              ...item,
              children: item.children.filter((c) => c.id === 'my-profile'),
            };
          }
          return item;
        });
    }

    // 3. Trưởng phòng Kỹ thuật (Nguyễn Nhật Thanh): Dashboard + Module Kỹ thuật + Báo cáo Kỹ thuật + Hồ sơ cá nhân
    if (currentRole === 'Technical Manager') {
      return menuItems
        .filter((item) => ['dashboard', 'technical', 'reports', 'hr'].includes(item.id))
        .map((item) => {
          if (item.id === 'reports') {
            return {
              ...item,
              children: item.children.filter((c) => c.id === 'reports-technical'),
            };
          }
          if (item.id === 'hr') {
            return {
              ...item,
              children: item.children.filter((c) => c.id === 'my-profile'),
            };
          }
          return item;
        });
    }

    // 4. Trưởng phòng Sale (Hồ Hoàng Long): Dashboard + Toàn bộ Module Sale + 8 Báo cáo Sales + Hồ sơ cá nhân
    if (currentRole === 'Sales Manager') {
      return menuItems
        .filter((item) => ['dashboard', 'sales', 'reports', 'hr'].includes(item.id))
        .map((item) => {
          if (item.id === 'reports') {
            return {
              ...item,
              children: item.children.filter((c) => c.id === 'report-group-sales'),
            };
          }
          if (item.id === 'hr') {
            return {
              ...item,
              children: item.children.filter((c) => c.id === 'my-profile'),
            };
          }
          return item;
        });
    }

    // 5. Nhân viên phòng Sale (Nguyễn Văn A): Dashboard cá nhân + Lead/Deal/Khách hàng/Báo giá phân bổ + Hồ sơ cá nhân
    if (currentRole === 'Sales Staff') {
      const allowedSalesItemIds = [
        'leads',
        'customers',
        'opportunities',
        'quotations',
        'sales-activities',
        'tasks',
        'calendar',
      ];
      return menuItems
        .filter((item) => ['dashboard', 'sales', 'hr'].includes(item.id))
        .map((item) => {
          if (item.id === 'sales') {
            return {
              ...item,
              children: item.children.filter((c) => allowedSalesItemIds.includes(c.id)),
            };
          }
          if (item.id === 'hr') {
            return {
              ...item,
              children: item.children.filter((c) => c.id === 'my-profile'),
            };
          }
          return item;
        });
    }

    return menuItems;
  }, [currentRole]);

  // State to track accordion expanded menu items
  // Mặc định nhóm "Báo cáo" được mở, nhóm con "Sales" chỉ mở khi người dùng bấm vào hoặc đang ở trang sales
  const [expandedIds, setExpandedIds] = useState<string[]>(['reports']);

  // Hover-to-expand state when collapsed on desktop
  const [isHovered, setIsHovered] = useState(false);
  const hoverTimeoutRef = React.useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleMouseEnter = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
      hoverTimeoutRef.current = null;
    }
    if (sidebarCollapsed && !mobileOpen) {
      setIsHovered(true);
    }
  };

  const handleMouseLeave = () => {
    if (hoverTimeoutRef.current) {
      clearTimeout(hoverTimeoutRef.current);
    }
    hoverTimeoutRef.current = setTimeout(() => {
      setIsHovered(false);
    }, 150);
  };

  useEffect(() => {
    return () => {
      if (hoverTimeoutRef.current) {
        clearTimeout(hoverTimeoutRef.current);
      }
    };
  }, []);

  // When sidebarCollapsed is true, but user hovers, isEffectiveCollapsed is FALSE so menu expands out
  const isEffectiveCollapsed = mobileOpen ? false : sidebarCollapsed && !isHovered;

  // Handle ESC key to close mobile drawer
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && mobileOpen) {
        onCloseMobile();
      }
    };
    if (mobileOpen) {
      document.body.style.overflow = 'hidden';
      window.addEventListener('keydown', handleKeyDown);
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [mobileOpen, onCloseMobile]);

  // Auto-expand accordion when activeModule belongs to a group
  useEffect(() => {
    if (
      activeModule === 'sales' ||
      activeModule === 'leads' ||
      activeModule === 'customers' ||
      activeModule === 'contacts' ||
      activeModule === 'opportunities' ||
      activeModule === 'quotations' ||
      activeModule === 'sales-orders' ||
      activeModule === 'contracts' ||
      activeModule === 'sales-invoices' ||
      activeModule === 'sales-receipts' ||
      activeModule === 'sales-activities' || activeModule === 'tasks' || activeModule === 'calendar'
    ) {
      setExpandedIds((prev) => Array.from(new Set([...prev, 'sales'])));
    } else if (
      activeModule === 'sales-overview' ||
      activeModule === 'sales-revenue' ||
      activeModule === 'sales-forecast' ||
      activeModule === 'sales-funnel' ||
      activeModule === 'sales-won' ||
      activeModule === 'sales-lost' ||
      activeModule === 'sales-productivity' ||
      activeModule === 'sales-leads'
    ) {
      setExpandedIds((prev) => Array.from(new Set([...prev, 'reports', 'report-group-sales'])));
    } else if (activeModule === 'reports' || activeModule.startsWith('reports-')) {
      // Khi chọn Báo cáo Kho, Vận chuyển, Kế toán, Kỹ thuật, Nhân sự: chỉ mở nhóm 'reports' và đóng 'report-group-sales'
      setExpandedIds((prev) => Array.from(new Set([...prev.filter((id) => id !== 'report-group-sales'), 'reports'])));
    } else if (activeModule.startsWith('inventory-') || activeModule === 'inventory') {
      setExpandedIds((prev) => Array.from(new Set([...prev, 'inventory'])));
    } else if (activeModule.startsWith('logistics-') || activeModule === 'logistics') {
      setExpandedIds((prev) => Array.from(new Set([...prev, 'logistics'])));
    } else if (activeModule.startsWith('accounting-') || activeModule === 'accounting') {
      setExpandedIds((prev) => Array.from(new Set([...prev, 'accounting'])));
    } else if (activeModule.startsWith('technical-') || activeModule === 'technical') {
      setExpandedIds((prev) => Array.from(new Set([...prev, 'technical'])));
    } else if (activeModule.startsWith('hr-') || activeModule === 'hr') {
      setExpandedIds((prev) => Array.from(new Set([...prev, 'hr'])));
    } else if (activeModule.startsWith('settings-') || activeModule === 'settings') {
      setExpandedIds((prev) => Array.from(new Set([...prev, 'settings'])));
    }
  }, [activeModule]);

  const toggleAccordion = (id: string) => {
    setExpandedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleMenuClick = (item: MenuItem) => {
    setIsPlatformMode(false);
    if (item.children && item.children.length > 0) {
      toggleAccordion(item.id);
      if (item.id === 'logistics' && !activeModule.startsWith('logistics-')) {
        setActiveModule('logistics-order-approval');
      }
      if (item.id === 'accounting' && !activeModule.startsWith('accounting-')) {
        setActiveModule('accounting-debt');
      }
      if (item.id === 'technical' && !activeModule.startsWith('technical-')) {
        setActiveModule('technical-customers');
      }
      if (item.id === 'hr' && !activeModule.startsWith('hr-')) {
        setActiveModule('hr-staff');
      }
      if (item.id === 'settings' && !activeModule.startsWith('settings-')) {
        setActiveModule('settings-users');
      }
    } else {
      setActiveModule(item.id as ActiveModule);
      onCloseMobile();
    }
  };

  // Helper to check if any child is active
  const isDescendantActive = (item: MenuItem): boolean => {
    if (activeModule === item.id) return true;
    if (item.id === 'customers' && activeModule === 'contacts') return true;
    if (item.id === 'leads' && activeModule === 'sales') return true;
    if (item.id === 'inventory-overview' && activeModule === 'inventory') return true;

    // Danh sách 8 báo cáo Sales cụ thể thuộc Module Báo cáo
    const isSalesReportModule =
      activeModule === 'sales-overview' ||
      activeModule === 'sales-revenue' ||
      activeModule === 'sales-forecast' ||
      activeModule === 'sales-funnel' ||
      activeModule === 'sales-won' ||
      activeModule === 'sales-lost' ||
      activeModule === 'sales-productivity' ||
      activeModule === 'sales-leads';

    if (item.id === 'report-group-sales') {
      return isSalesReportModule;
    }

    if (item.id === 'reports') {
      return (
        activeModule === 'reports' ||
        activeModule.startsWith('reports-') ||
        isSalesReportModule
      );
    }

    if (item.id === 'sales') {
      return (
        activeModule === 'sales' ||
        activeModule === 'leads' ||
        activeModule === 'customers' ||
        activeModule === 'contacts' ||
        activeModule === 'opportunities' ||
        activeModule === 'quotations' ||
        activeModule === 'sales-orders' ||
        activeModule === 'contracts' ||
        activeModule === 'sales-invoices' ||
        activeModule === 'sales-receipts' ||
        activeModule === 'sales-activities' ||
        activeModule === 'tasks' ||
        activeModule === 'calendar'
      );
    }
    if (item.id === 'inventory') return activeModule.startsWith('inventory-') || activeModule === 'inventory';
    if (item.id === 'logistics') return activeModule.startsWith('logistics-') || activeModule === 'logistics';
    if (item.id === 'accounting') return activeModule.startsWith('accounting-') || activeModule === 'accounting';
    if (item.id === 'technical') return activeModule.startsWith('technical-') || activeModule === 'technical';
    if (item.id === 'hr') return activeModule.startsWith('hr-') || activeModule === 'hr' || activeModule === 'my-profile';
    if (item.id === 'settings') return activeModule.startsWith('settings-') || activeModule === 'settings' || activeModule === 'spec-suite';
    if (item.children && item.children.length > 0) {
      return item.children.some((child) => isDescendantActive(child));
    }
    return false;
  };

  // Role badge display calculation
  const userRoleBadge = React.useMemo(() => {
    const role = currentUser?.role || currentRole || 'Super Admin';
    const roleLabels: Record<string, { vi: string; en: string; ja: string }> = {
      'Super Admin': { vi: 'Super Admin', en: 'Super Admin', ja: 'スーパー管理者' },
      'Admin': { vi: 'Admin', en: 'Admin', ja: '管理者' },
      'Tenant Admin': { vi: 'Admin', en: 'Admin', ja: '管理者' },
      'Director': { vi: 'Ban Giám Đốc', en: 'Board of Directors', ja: '役員会' },
      'Sales Manager': { vi: 'Trưởng Phòng Sale', en: 'Sales Manager', ja: '営業部長' },
      'Sales Staff': { vi: 'Nhân Viên Sale', en: 'Sales Representative', ja: '営業担当' },
      'Accountant': { vi: 'Kế Toán', en: 'Accountant', ja: '経理担当' },
      'HR Staff': { vi: 'Nhân Sự', en: 'HR Specialist', ja: '人事担当' },
      'Technical Manager': { vi: 'Trưởng Phòng KT', en: 'Technical Manager', ja: '技術部長' },
    };
    const translatedLabel = roleLabels[role]?.[language] || role;

    switch (role) {
      case 'Super Admin':
        return {
          label: translatedLabel,
          badgeClass: 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300 border-purple-200 dark:border-purple-800',
        };
      case 'Admin':
      case 'Tenant Admin':
        return {
          label: translatedLabel,
          badgeClass: 'bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300 border-blue-200 dark:border-blue-800',
        };
      case 'Director':
        return {
          label: translatedLabel,
          badgeClass: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
        };
      case 'Sales Manager':
        return {
          label: translatedLabel,
          badgeClass: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border-amber-200 dark:border-amber-800',
        };
      case 'Sales Staff':
        return {
          label: translatedLabel,
          badgeClass: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800',
        };
      case 'Accountant':
        return {
          label: translatedLabel,
          badgeClass: 'bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 border-teal-200 dark:border-teal-800',
        };
      case 'HR Staff':
        return {
          label: translatedLabel,
          badgeClass: 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border-rose-200 dark:border-rose-800',
        };
      default:
        return {
          label: translatedLabel,
          badgeClass: 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700',
        };
    }
  }, [currentUser?.role, currentRole, language]);

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileOpen && (
        <div
          onClick={onCloseMobile}
          className="fixed inset-0 z-40 bg-slate-950/70 backdrop-blur-xs md:hidden transition-opacity"
          aria-hidden="true"
        />
      )}

      {/* Desktop Layout Placeholder (prevents page content jump when sidebar floats on hover) */}
      <div
        className={`hidden md:block shrink-0 transition-all duration-200 ease-out ${
          sidebarCollapsed ? 'w-[70px]' : 'w-[275px] lg:w-[285px]'
        }`}
        aria-hidden="true"
      />

      {/* Main Sidebar Shell (Supports hover-to-expand when collapsed) */}
      <aside
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        className={`fixed top-0 bottom-0 left-0 bg-white dark:bg-[#0A1020] text-slate-800 dark:text-slate-200 flex flex-col border-r border-slate-200 dark:border-slate-800 transition-all duration-200 ease-out select-none ${
          isEffectiveCollapsed
            ? 'w-[70px] z-30'
            : 'w-[275px] lg:w-[285px] ' + (sidebarCollapsed && isHovered ? 'shadow-2xl ring-1 ring-black/20 z-50' : 'z-30')
        } ${
          mobileOpen
            ? 'w-[290px] max-w-[88vw] translate-x-0 shadow-2xl z-50'
            : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div
          className={`min-h-[64px] py-2 flex items-center ${
            isEffectiveCollapsed ? 'justify-center px-2' : 'justify-between px-4'
          } border-b border-slate-200 dark:border-slate-800 shrink-0 bg-white dark:bg-[#070D1A]`}
        >
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-8.5 h-8.5 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 flex items-center justify-center p-1 shrink-0 overflow-hidden shadow-2xs">
              <APlusLogo size={25} />
            </div>
            {!isEffectiveCollapsed && (
              <div className="flex flex-col min-w-0">
                <span className="text-[14.5px] font-bold text-[#002659] dark:text-white tracking-tight leading-tight truncate">
                  A+ Enterprise CRM
                </span>
                <span className="text-[11.5px] text-slate-500 dark:text-slate-400 font-medium tracking-tight truncate leading-tight mt-0.5">
                  {currentCompany?.name || currentTenant?.name || 'Công ty Aplus'}
                </span>
              </div>
            )}
          </div>

          {/* Close button on mobile drawer */}
          <button
            type="button"
            onClick={onCloseMobile}
            className="md:hidden p-1.5 rounded-md text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Đóng menu"
            title="Đóng menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Menu Items List: Liền nhau, không bo góc, ngăn cách bằng 1 đường kẻ */}
        <div className="flex-1 overflow-y-auto p-0 m-0 space-y-0 scrollbar-thin scrollbar-thumb-slate-300 dark:scrollbar-thumb-slate-700">
          {/* Super Admin Portal button */}
          {(currentRole === 'Super Admin' || currentUser?.role === 'Super Admin') && (
            <div className="border-b border-purple-200 dark:border-purple-900/50">
              <button
                type="button"
                onClick={() => {
                  setIsPlatformMode(true);
                  setActiveModule('platform-admin');
                  onCloseMobile();
                }}
                className={`w-full p-2.5 flex items-center transition-colors cursor-pointer rounded-none ${
                  isEffectiveCollapsed ? 'justify-center' : 'justify-between px-4'
                } ${
                  isPlatformMode || activeModule === 'platform-admin'
                    ? 'bg-purple-800 text-white font-bold ring-2 ring-purple-400/90 ring-inset shadow-inner'
                    : 'bg-purple-900 hover:bg-purple-800 text-white'
                }`}
                title={
                  language === 'vi'
                    ? 'Vào Cổng Super Admin để duyệt đăng ký doanh nghiệp & cấp CSDL'
                    : language === 'ja'
                    ? 'スーパー管理者ポータル（企業登録承認・DB発行）'
                    : 'Super Admin Portal for tenant approval and DB provisioning'
                }
              >
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-6 h-6 rounded bg-purple-700/60 flex items-center justify-center text-purple-200 shrink-0">
                    <ShieldAlert className="w-3.5 h-3.5 text-purple-200" />
                  </div>
                  {!isEffectiveCollapsed && (
                    <div className="text-left min-w-0">
                      <div className="text-[12px] font-bold leading-tight truncate">
                        {language === 'vi' ? 'Cổng Super Admin' : language === 'ja' ? '特権管理者ポータル' : 'Super Admin Portal'}
                      </div>
                    </div>
                  )}
                </div>
                {!isEffectiveCollapsed && pendingRequestsCount > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-400 text-slate-900 shrink-0">
                    {pendingRequestsCount}
                  </span>
                )}
              </button>
            </div>
          )}

          <nav aria-label="Menu chính" className="divide-y divide-slate-200 dark:divide-slate-800">
            {filteredMenuItems.map((item) => {
              const Icon = item.icon;
              const hasLevel2 = item.children && item.children.length > 0;
              const isLevel1Expanded = expandedIds.includes(item.id);
              const isDirectActive = activeModule === item.id;
              const hasActiveChild = hasLevel2 && isDescendantActive(item);

              // Level 1 là banner Aplus khi mở hoặc active (y chang banner màu vàng trong hình mẫu, đổi sang màu Aplus)
              const isLevel1Banner = isLevel1Expanded || isDirectActive || hasActiveChild;

              return (
                <div key={item.id} className="w-full">
                  {/* CẤP 1: Liền nhau, không bo góc, ngăn cách bằng 1 đường kẻ */}
                  <button
                    type="button"
                    onClick={() => handleMenuClick(item)}
                    title={isEffectiveCollapsed ? getMenuTitle(item.id, item.label, language) : undefined}
                    className={`w-full flex items-center ${
                      isEffectiveCollapsed ? 'justify-center py-3 px-2' : 'justify-between px-4 py-3'
                    } text-left transition-colors cursor-pointer select-none rounded-none ${
                      isLevel1Banner
                        ? 'bg-[#002659] text-white font-bold'
                        : 'bg-white dark:bg-[#0A1020] text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/60 font-semibold'
                    }`}
                  >
                    <div className={`flex items-center ${isEffectiveCollapsed ? 'justify-center' : 'gap-2.5 min-w-0 flex-1'}`}>
                      {Icon && (
                        <Icon
                          className={`w-5 h-5 shrink-0 transition-colors ${
                            isLevel1Banner ? 'text-white' : 'text-slate-600 dark:text-slate-400'
                          }`}
                        />
                      )}
                      {!isEffectiveCollapsed && (
                        <span className="text-[15px] font-inherit truncate leading-tight">
                          {getMenuTitle(item.id, item.label, language)}
                        </span>
                      )}
                    </div>

                    {!isEffectiveCollapsed && hasLevel2 && (
                      <ChevronDown
                        className={`w-4 h-4 shrink-0 transition-transform duration-200 ml-1.5 ${
                          isLevel1Banner ? 'text-white' : 'text-slate-400'
                        } ${isLevel1Expanded ? 'rotate-180' : ''}`}
                      />
                    )}
                  </button>

                  {/* CẤP 2 & CẤP 3 (Khi Cấp 1 mở) */}
                  {!isEffectiveCollapsed && hasLevel2 && isLevel1Expanded && (
                    <div className="bg-white dark:bg-[#070D1A] divide-y divide-slate-100 dark:divide-slate-800/70 border-b border-slate-200 dark:border-slate-800">
                      {item.children.map((group) => {
                        const hasLevel3 = group.children && group.children.length > 0;
                        const isLevel2Expanded = expandedIds.includes(group.id);
                        const isGroupDirectActive =
                          activeModule === group.id ||
                          (group.id === 'customers' && activeModule === 'contacts') ||
                          (group.id === 'leads' && activeModule === 'sales') ||
                          (group.id === 'inventory-overview' && activeModule === 'inventory');
                        const hasActiveLevel3Child =
                          hasLevel3 && group.children.some((c) => c.id === activeModule);

                        if (group.isHeader) {
                          const rawTitle = getMenuTitle(group.id, group.label, language);
                          const cleanTitle = rawTitle.replace(/^\[|\]$/g, '').trim();
                          return (
                            <div
                              key={group.id}
                              className="px-4 pt-3 pb-1.5 text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider bg-slate-50/70 dark:bg-slate-900/50 select-none"
                            >
                              {cleanTitle}
                            </div>
                          );
                        }

                        // Nhóm có Cấp 3 (như Sales trong Báo cáo: "v Sales")
                        if (hasLevel3) {
                          return (
                            <div key={group.id} className="w-full">
                              {/* CẤP 2: Header có chevron v bên trái, y chang hình mẫu */}
                              <button
                                type="button"
                                onClick={() => {
                                  toggleAccordion(group.id);
                                  if (group.id === 'report-group-sales' && !hasActiveLevel3Child) {
                                    setActiveModule('sales-overview');
                                  }
                                }}
                                className={`w-full flex items-center gap-2 px-5 py-2.5 text-left text-[14px] font-bold transition-colors cursor-pointer select-none rounded-none ${
                                  hasActiveLevel3Child
                                    ? 'text-[#002659] dark:text-sky-400 bg-slate-50/80 dark:bg-slate-900/40'
                                    : 'text-slate-800 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                                }`}
                              >
                                <ChevronDown
                                  className={`w-3.5 h-3.5 shrink-0 transition-transform duration-200 ${
                                    isLevel2Expanded ? 'rotate-0' : '-rotate-90'
                                  } ${hasActiveLevel3Child ? 'text-[#002659] dark:text-sky-400' : 'text-slate-500'}`}
                                />
                                <span className="truncate leading-tight font-inherit">
                                  {getMenuTitle(group.id, group.label, language)}
                                </span>
                              </button>

                              {/* CẤP 3: Danh sách từng mục có dấu > bên trái, ngăn cách bằng đường kẻ mỏng */}
                              {isLevel2Expanded && (
                                <div className="divide-y divide-slate-100 dark:divide-slate-800/60 bg-slate-50/30 dark:bg-slate-900/20">
                                  {group.children.map((sub) => {
                                    const isSubActive = activeModule === sub.id;

                                    return (
                                      <button
                                        key={sub.id}
                                        type="button"
                                        onClick={() => {
                                          setActiveModule(sub.id as ActiveModule);
                                          onCloseMobile();
                                        }}
                                        className={`w-full flex items-center gap-2 pl-9 pr-4 py-2.5 text-left text-[13.5px] transition-colors cursor-pointer select-none rounded-none ${
                                          isSubActive
                                            ? 'bg-blue-50/90 dark:bg-blue-950/40 text-[#002659] dark:text-sky-300 font-bold border-l-4 border-l-[#002659] dark:border-l-sky-400 pl-8'
                                            : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/40 font-normal'
                                        }`}
                                      >
                                        <ChevronRight
                                          className={`w-3 h-3 shrink-0 ${
                                            isSubActive
                                              ? 'text-[#002659] dark:text-sky-300 stroke-[2.5]'
                                              : 'text-slate-400 dark:text-slate-500'
                                          }`}
                                        />
                                        <span className="truncate leading-tight font-inherit">
                                          {getMenuTitle(sub.id, sub.label, language)}
                                        </span>
                                      </button>
                                    );
                                  })}
                                </div>
                              )}
                            </div>
                          );
                        }

                        // Mục Cấp 2 đơn (như Kho, Vận chuyển, Kế toán... hoặc Lead, Khách hàng...): có dấu > bên trái
                        const isLeafActive = isGroupDirectActive;

                        return (
                          <button
                            key={group.id}
                            type="button"
                            onClick={() => {
                              setActiveModule(group.id as ActiveModule);
                              if (group.id.startsWith('reports-')) {
                                setExpandedIds((prev) => prev.filter((id) => id !== 'report-group-sales'));
                              }
                              onCloseMobile();
                            }}
                            className={`w-full flex items-center gap-2 px-5 py-2.5 text-left text-[13.5px] transition-colors cursor-pointer select-none rounded-none ${
                              isLeafActive
                                ? 'bg-blue-50/90 dark:bg-blue-950/40 text-[#002659] dark:text-sky-300 font-bold border-l-4 border-l-[#002659] dark:border-l-sky-400 pl-4'
                                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/40 font-normal'
                            }`}
                          >
                            <ChevronRight
                              className={`w-3.5 h-3.5 shrink-0 ${
                                isLeafActive
                                  ? 'text-[#002659] dark:text-sky-300 stroke-[2.5]'
                                  : 'text-slate-400 dark:text-slate-500'
                              }`}
                            />
                            <span className="truncate leading-tight font-inherit">
                              {getMenuTitle(group.id, group.label, language)}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </nav>
        </div>

        {/* Footer: User Role Display & Collapse/Expand Toggle */}
        <div className="p-2.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-[#070D1A] shrink-0">
          <div className="flex items-center justify-between px-1.5 py-0.5">
            {!isEffectiveCollapsed ? (
              <>
                <div className="flex items-center gap-1.5 min-w-0">
                  <span className="text-[12px] text-slate-600 dark:text-slate-400 font-semibold truncate">
                    {userRoleBadge.label}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={toggleSidebarCollapsed}
                  className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                  title={
                    sidebarCollapsed
                      ? language === 'vi'
                        ? 'Ghim mở rộng menu cố định'
                        : language === 'ja'
                        ? 'サイドバー固定'
                        : 'Pin expand menu'
                      : language === 'vi'
                      ? 'Thu gọn menu'
                      : language === 'ja'
                      ? 'サイドバー格納'
                      : 'Collapse menu'
                  }
                  aria-label={
                    sidebarCollapsed
                      ? language === 'vi'
                        ? 'Ghim mở rộng menu cố định'
                        : language === 'ja'
                        ? 'サイドバー固定'
                        : 'Pin expand menu'
                      : language === 'vi'
                      ? 'Thu gọn menu'
                      : language === 'ja'
                      ? 'サイドバー格納'
                      : 'Collapse menu'
                  }
                >
                  {sidebarCollapsed ? (
                    <PanelLeftOpen className="w-4.5 h-4.5 text-[#002659] dark:text-sky-400" />
                  ) : (
                    <PanelLeftClose className="w-4.5 h-4.5" />
                  )}
                </button>
              </>
            ) : (
              <div className="w-full flex justify-center">
                <button
                  type="button"
                  onClick={toggleSidebarCollapsed}
                  className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors cursor-pointer"
                  title={language === 'vi' ? 'Mở rộng menu' : language === 'ja' ? 'メニューを展開' : 'Expand menu'}
                  aria-label={language === 'vi' ? 'Mở rộng thanh bên' : language === 'ja' ? 'サイドバーを展開' : 'Expand sidebar'}
                >
                  <PanelLeftOpen className="w-4.5 h-4.5 text-[#002659] dark:text-sky-400" />
                </button>
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};
