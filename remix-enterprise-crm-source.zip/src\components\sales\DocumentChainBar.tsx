import React from 'react';
import { useCRM } from '../../context/CRMContext';
import { DocumentChainInfo } from '../../types/sales';
import {
  UserCheck,
  Building2,
  Target,
  FileSpreadsheet,
  CheckSquare,
  FileCheck2,
  Receipt,
  Banknote,
  ChevronRight,
  ExternalLink,
  Wrench,
  ArrowUpFromLine,
  Truck,
  Briefcase,
  ClipboardCheck,
} from 'lucide-react';

interface DocumentChainBarProps {
  currentType?: string;
  chain: DocumentChainInfo;
  className?: string;
}

export const DocumentChainBar: React.FC<DocumentChainBarProps> = ({
  currentType,
  chain,
  className = '',
}) => {
  const { setActiveModule } = useCRM();

  const allPossibleSteps = [
    {
      type: 'lead',
      label: 'Lead',
      code: chain.leadCode,
      hasEntity: Boolean(chain.leadId || chain.leadCode),
      targetModule: 'leads',
      icon: UserCheck,
    },
    {
      type: 'customer',
      label: 'Khách hàng',
      code: chain.customerCode,
      hasEntity: Boolean(chain.customerId || chain.customerCode),
      targetModule: 'customers',
      icon: Building2,
    },
    {
      type: 'opportunity',
      label: 'Cơ hội',
      code: chain.opportunityCode,
      hasEntity: Boolean(chain.opportunityId || chain.opportunityCode),
      targetModule: 'opportunities',
      icon: Target,
    },
    ...(chain.technicalRequestCode
      ? [
          {
            type: 'technicalRequest',
            label: 'YCKT',
            code: chain.technicalRequestCode,
            hasEntity: true,
            targetModule: 'technical-quotations',
            icon: Wrench,
          },
        ]
      : []),
    {
      type: 'quotation',
      label: 'Báo giá',
      code: chain.quotationCode,
      hasEntity: Boolean(chain.quotationId || chain.quotationCode),
      targetModule: 'quotations',
      icon: FileSpreadsheet,
    },
    {
      type: 'order',
      label: 'Đơn hàng',
      code: chain.orderCode,
      hasEntity: Boolean(chain.orderId || chain.orderCode),
      targetModule: 'sales-orders',
      icon: CheckSquare,
    },
    ...(chain.stockOutCode
      ? [
          {
            type: 'stockOut',
            label: 'Phiếu xuất',
            code: chain.stockOutCode,
            hasEntity: true,
            targetModule: 'inventory-stock-out',
            icon: ArrowUpFromLine,
          },
        ]
      : []),
    ...(chain.deliveryNoteCode
      ? [
          {
            type: 'delivery',
            label: 'Giao hàng',
            code: chain.deliveryNoteCode,
            hasEntity: true,
            targetModule: 'logistics-delivery-notes',
            icon: Truck,
          },
        ]
      : []),
    {
      type: 'contract',
      label: 'Hợp đồng',
      code: chain.contractCode,
      hasEntity: Boolean(chain.contractId || chain.contractCode),
      targetModule: 'contracts',
      icon: FileCheck2,
    },
    ...(chain.projectCode
      ? [
          {
            type: 'project',
            label: 'Dự án KT',
            code: chain.projectCode,
            hasEntity: true,
            targetModule: 'technical-projects',
            icon: Briefcase,
          },
        ]
      : []),
    ...(chain.acceptanceCode
      ? [
          {
            type: 'acceptance',
            label: 'Nghiệm thu',
            code: chain.acceptanceCode,
            hasEntity: true,
            targetModule: 'technical-acceptance',
            icon: ClipboardCheck,
          },
        ]
      : []),
    {
      type: 'invoice',
      label: 'Hóa đơn',
      code: chain.invoiceCode,
      hasEntity: Boolean(chain.invoiceId || chain.invoiceCode),
      targetModule: 'sales-invoices',
      icon: Receipt,
    },
    {
      type: 'receipt',
      label: 'Phiếu thu',
      code: chain.receiptCode,
      hasEntity: Boolean(chain.receiptId || chain.receiptCode),
      targetModule: 'sales-receipts',
      icon: Banknote,
    },
  ];

  const steps = allPossibleSteps;

  return (
    <div className={`bg-slate-900/90 dark:bg-slate-950 border border-slate-800 rounded-xl p-3 shadow-xs ${className}`}>
      <div className="flex items-center justify-between gap-2 mb-2">
        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-sky-400 animate-pulse" />
          Chuỗi chứng từ liên quan (Sales Lifecycle Chain)
        </span>
        <span className="text-[11px] text-slate-500 hidden sm:inline">
          Bấm vào chứng từ đã phát hành để chuyển ngay tới trang chi tiết
        </span>
      </div>

      <div className="flex items-center gap-1 overflow-x-auto pb-1 text-xs scrollbar-thin">
        {steps.map((step, idx) => {
          const isCurrent = step.type === currentType;
          const isAvailable = step.hasEntity;
          const StepIcon = step.icon;

          return (
            <React.Fragment key={step.type}>
              <button
                type="button"
                disabled={!isAvailable}
                onClick={() => {
                  if (isAvailable) {
                    setActiveModule(step.targetModule as any);
                  }
                }}
                className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border transition-all text-left shrink-0 ${
                  isCurrent
                    ? 'bg-sky-600/20 border-sky-500 text-sky-300 font-bold shadow-xs'
                    : isAvailable
                    ? 'bg-slate-800/80 border-slate-700 text-slate-200 hover:bg-slate-700 hover:border-slate-600 cursor-pointer'
                    : 'bg-slate-900/40 border-slate-800/60 text-slate-600 cursor-not-allowed opacity-45'
                }`}
              >
                <StepIcon
                  className={`w-3.5 h-3.5 shrink-0 ${
                    isCurrent ? 'text-sky-400' : isAvailable ? 'text-slate-300' : 'text-slate-600'
                  }`}
                />
                <div className="flex flex-col min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="font-semibold text-[11px] leading-tight">{step.label}</span>
                    {isAvailable && !isCurrent && (
                      <ExternalLink className="w-2.5 h-2.5 opacity-60" />
                    )}
                  </div>
                  <span className="font-mono text-[10px] text-slate-400 leading-tight truncate">
                    {step.code || 'Chưa tạo'}
                  </span>
                </div>
              </button>

              {idx < steps.length - 1 && (
                <ChevronRight className="w-3.5 h-3.5 text-slate-600 shrink-0 mx-0.5" />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
};
