import React from 'react';
import { useCRM } from '../../context/CRMContext';
import {
  TrendingUp,
  DollarSign,
  PieChart,
  Truck,
  Wrench,
  Users,
  FileBarChart,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  ArrowUpRight,
  Building2,
  Warehouse,
  Percent,
} from 'lucide-react';

export const DirectorDashboard: React.FC = () => {
  const { currentUser, setActiveModule } = useCRM();

  const reportShortcuts = [
    {
      id: 'sales-revenue',
      title: 'Báo cáo Doanh thu & Dự báo Sales',
      desc: 'Phân tích doanh số lũy kế theo nhóm ngành, khu vực và chu kỳ chốt hợp đồng.',
      icon: DollarSign,
      color: 'text-sky-600 bg-sky-50 dark:bg-sky-950 dark:text-sky-300 border-sky-200',
    },
    {
      id: 'reports-accounting',
      title: 'Báo cáo Kết quả Kinh doanh P&L',
      desc: 'Doanh thu, giá vốn hàng bán, lợi nhuận gộp và phân tích tuổi nợ khách hàng.',
      icon: PieChart,
      color: 'text-indigo-600 bg-indigo-50 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200',
    },
    {
      id: 'reports-inventory',
      title: 'Báo cáo Quản lý Kho Vận',
      desc: 'Tổng tài sản lưu kho, hàng khả dụng vs tạm giữ theo đơn và cảnh báo cận date FEFO.',
      icon: Warehouse,
      color: 'text-amber-600 bg-amber-50 dark:bg-amber-950 dark:text-amber-300 border-amber-200',
    },
    {
      id: 'reports-logistics',
      title: 'Báo cáo Vận chuyển & Giao nhận',
      desc: 'Tỷ lệ giao đúng hẹn OTD (94.8%), đối soát thu hộ COD và định mức chi phí chuyến.',
      icon: Truck,
      color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200',
    },
    {
      id: 'reports-technical',
      title: 'Báo cáo Khối Kỹ thuật & Dự án',
      desc: 'Tiến độ thi công công trình, nghiệm thu ký kết bàn giao hóa đơn và cam kết SLA.',
      icon: Wrench,
      color: 'text-rose-600 bg-rose-50 dark:bg-rose-950 dark:text-rose-300 border-rose-200',
    },
    {
      id: 'reports-hr',
      title: 'Báo cáo Nhân sự & BHXH',
      desc: 'Cơ cấu phòng ban, tỷ lệ nhân viên chính thức và tổng quỹ trích nộp bảo hiểm xã hội.',
      icon: Users,
      color: 'text-purple-600 bg-purple-50 dark:bg-purple-950 dark:text-purple-300 border-purple-200',
    },
  ];

  return (
    <div className="space-y-6 max-w-[1400px] mx-auto pb-12">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden border border-indigo-900/50">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-radial from-indigo-500/20 via-transparent to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.fullName}
              className="w-16 h-16 rounded-full border-2 border-indigo-400/80 object-cover shadow-lg shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight">
                  Chào ông {currentUser.fullName}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                  Ban Giám Đốc (Executive Board)
                </span>
              </div>
              <p className="text-slate-300 text-sm mt-1">
                Góc nhìn tổng hợp &amp; Báo cáo điều hành doanh nghiệp. Tất cả số liệu kinh doanh, kho bãi, kỹ thuật và dòng tiền được đồng bộ trực tiếp theo thời gian thực.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setActiveModule('reports-accounting')}
              className="px-4 py-2 bg-indigo-500 hover:bg-indigo-600 text-white rounded-lg text-sm font-bold shadow-md transition-colors flex items-center gap-2 cursor-pointer"
            >
              <FileBarChart className="w-4 h-4" />
              <span>Xem Báo Cáo Tài Chính P&amp;L</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. 4 Executive Board KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Doanh thu thực tế vs Mục tiêu */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Doanh thu thực tế / Kế hoạch
            </span>
            <div className="w-8 h-8 rounded-lg bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              5.450.000.000 ₫
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
              <span>Chỉ tiêu: 8.500.000.000 ₫</span>
              <span className="font-bold text-sky-600">64.1%</span>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full mt-2 overflow-hidden">
              <div className="bg-sky-500 h-full rounded-full" style={{ width: '64.1%' }} />
            </div>
          </div>
        </div>

        {/* KPI 2: Lợi nhuận gộp P&L */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Lợi nhuận gộp P&amp;L
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400">
              2.340.000.000 ₫
            </div>
            <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
              <span>Biên lợi nhuận gộp:</span>
              <span className="font-bold text-emerald-600">42.9%</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 font-mono">
              Giá vốn (COGS): 3.110.000.000 ₫
            </div>
          </div>
        </div>

        {/* KPI 3: Tỷ lệ giao hàng đúng hạn OTD */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Giao đúng hạn OTD
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Truck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-indigo-600 dark:text-indigo-400">
              94.8%
            </div>
            <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
              <span>Tổng chuyến tháng: 128</span>
              <span className="font-semibold text-emerald-600">+1.8% MoM</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 font-mono">
              COD đã đối soát: 100% khớp quỹ
            </div>
          </div>
        </div>

        {/* KPI 4: Nghiệm thu dự án kỹ thuật */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Nghiệm thu dự án kỹ thuật
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-purple-600 dark:text-purple-400">
              92.5%
            </div>
            <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
              <span>Dự án đúng tiến độ: 11 / 12</span>
              <span className="font-semibold text-purple-600">Đạt chuẩn</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1 font-mono">
              Biên bản đã ký: Chuyển xuất HĐ
            </div>
          </div>
        </div>
      </div>

      {/* 3. Phím tắt 6 Báo cáo trọng điểm dành cho Ban Giám Đốc */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <FileBarChart className="w-5 h-5 text-indigo-600" />
              <span>Trung tâm Báo cáo Quản trị Doanh nghiệp</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Ban Giám Đốc có quyền truy cập trực tiếp toàn bộ 6 báo cáo chuyên sâu các phân hệ.
            </p>
          </div>
          <span className="text-xs text-indigo-600 font-semibold bg-indigo-50 dark:bg-indigo-950 px-2.5 py-1 rounded-full border border-indigo-200 dark:border-indigo-800">
            6 Phân hệ Báo cáo
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-5">
          {reportShortcuts.map((rep) => {
            const Icon = rep.icon;
            return (
              <div
                key={rep.id}
                onClick={() => setActiveModule(rep.id as any)}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 hover:border-indigo-500 dark:hover:border-indigo-500 hover:shadow-md transition-all cursor-pointer group flex flex-col justify-between bg-slate-50/50 dark:bg-slate-850"
              >
                <div>
                  <div className="flex items-center justify-between mb-2.5">
                    <div className={`w-9 h-9 rounded-lg border flex items-center justify-center shrink-0 ${rep.color}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-indigo-600 transition-colors" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white group-hover:text-indigo-600 transition-colors">
                    {rep.title}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">
                    {rep.desc}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs font-semibold text-indigo-600 dark:text-indigo-400">
                  <span>Mở phân tích chi tiết</span>
                  <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
