import React, { createContext, useContext, useState, useMemo, useEffect } from 'react';
import { useCRM } from './CRMContext';
import { useSales } from './SalesContext';
import { useMultiTenant } from './MultiTenantContext';
import {
  Employee,
  Department,
  TeamCategory,
  PositionCategory,
  EmployeeContract,
  WorkHistoryRecord,
  EmployeeDocument,
  ChecklistItem,
  ProfileUpdateRequest,
  InsuranceParticipant,
  InsuranceChangeRecord,
  InsuranceMonthlyPeriod,
  InsuranceClaimRecord,
  InsuranceConfigItem,
  SensitiveDataAccessLog,
} from '../types/hr';
import {
  INITIAL_EMPLOYEES,
  INITIAL_DEPARTMENTS,
  INITIAL_TEAMS,
  INITIAL_POSITIONS,
  INITIAL_EMPLOYEE_CONTRACTS,
  INITIAL_WORK_HISTORIES,
  SAMPLE_CHECKLISTS,
  INITIAL_PROFILE_REQUESTS,
  INITIAL_INSURANCE_PARTICIPANTS,
  INITIAL_INSURANCE_CHANGES,
  INITIAL_MONTHLY_PERIODS,
  INITIAL_INSURANCE_CLAIMS,
  INITIAL_INSURANCE_CONFIG,
  INITIAL_ACCESS_LOGS,
} from '../data/mockHRData';

interface HRContextType {
  // 1. Employees & Structure
  employees: Employee[];
  departments: Department[];
  teams: TeamCategory[];
  positions: PositionCategory[];
  contracts: EmployeeContract[];
  workHistories: WorkHistoryRecord[];
  documents: EmployeeDocument[];
  profileRequests: ProfileUpdateRequest[];
  accessLogs: SensitiveDataAccessLog[];

  // Employee Methods
  addEmployee: (
    empData: Omit<Employee, 'id' | 'code' | 'createdAt'>,
    contractData?: {
      type: EmployeeContract['type'];
      startDate: string;
      endDate?: string;
      baseSalary: number;
      allowances: { name: string; amount: number }[];
      insuranceSalary: number;
    },
    checklistItems?: ChecklistItem[]
  ) => Employee;

  updateEmployee: (id: string, updates: Partial<Employee>, reason?: string) => void;
  deleteEmployee: (id: string) => void;

  // Contracts
  renewOrSignContract: (
    employeeId: string,
    contractData: Omit<EmployeeContract, 'id' | 'employeeId' | 'status'>
  ) => EmployeeContract;
  convertProbationToOfficial: (employeeId: string, newInsuranceSalary?: number) => void;

  // Handover on Offboarding
  handoverEmployeeData: (
    leavingEmployeeId: string,
    targetEmployeeId: string,
    notes?: string
  ) => { leadsCount: number; customersCount: number; oppsCount: number };

  // Profile Update Requests (Self-service)
  createProfileUpdateRequest: (
    employeeId: string,
    requestedChanges: ProfileUpdateRequest['requestedChanges']
  ) => void;
  approveProfileUpdateRequest: (requestId: string) => void;
  rejectProfileUpdateRequest: (requestId: string, reason: string) => void;

  // Checklist updates
  updateChecklistItem: (
    employeeId: string,
    type: 'onboarding' | 'offboarding',
    itemId: string,
    completed: boolean
  ) => void;

  // Department & Team & Position Management
  addDepartment: (dept: Omit<Department, 'id' | 'memberCount'>) => void;
  updateDepartment: (id: string, updates: Partial<Department>) => void;
  addTeam: (team: Omit<TeamCategory, 'id' | 'memberCount'>) => void;
  updateTeam: (id: string, updates: Partial<TeamCategory>) => void;
  addPosition: (pos: Omit<PositionCategory, 'id'>) => void;
  updatePosition: (id: string, updates: Partial<PositionCategory>) => void;

  // 2. Social Insurance
  insuranceParticipants: InsuranceParticipant[];
  insuranceChanges: InsuranceChangeRecord[];
  monthlyPeriods: InsuranceMonthlyPeriod[];
  insuranceClaims: InsuranceClaimRecord[];
  insuranceConfigs: InsuranceConfigItem[];
  activeConfig: InsuranceConfigItem;

  addInsuranceChange: (change: Omit<InsuranceChangeRecord, 'id' | 'code' | 'createdAt'>) => void;
  confirmInsuranceChange: (id: string) => void;
  batchConfirmInsuranceChanges: (ids: string[]) => void;
  submitInsuranceChangeToAgency: (id: string, submissionCode: string) => void;
  approveInsuranceChange: (id: string) => void;
  rejectInsuranceChange: (id: string, reason: string) => void;

  // Monthly Period actions
  generateMonthlyPeriod: (monthStr: string) => InsuranceMonthlyPeriod;
  lockMonthlyPeriod: (id: string) => void;
  unlockMonthlyPeriod: (id: string, reason: string) => void;
  recordPeriodPayment: (id: string, refNumber: string, amount: number) => void;

  // Claims
  addInsuranceClaim: (claim: Omit<InsuranceClaimRecord, 'id'>) => void;
  updateClaimStatus: (id: string, status: InsuranceClaimRecord['status'], actualAmount?: number) => void;

  // Config
  addInsuranceConfig: (cfg: Omit<InsuranceConfigItem, 'id'>) => void;

  // Sensitive Access Log & Masking
  logSensitiveAccess: (
    action: SensitiveDataAccessLog['action'],
    targetEmployeeName: string,
    fields: string[],
    details?: string
  ) => void;
  maskSensitive: (val?: string, visibleChars?: number) => string;
}

const HRContext = createContext<HRContextType | undefined>(undefined);

export const HRProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { showToast } = useCRM();
  const { currentCompany, currentAccount } = useMultiTenant();
  const { leads, updateLead, customers, updateCustomer, opportunities, updateOpportunity, orders, updateOrder } = useSales();

  // State
  const [employees, setEmployees] = useState<Employee[]>(INITIAL_EMPLOYEES);

  // Sync employees for clean multi-tenant company (aplus)
  useEffect(() => {
    if (currentCompany) {
      const isCleanTenant =
        currentCompany.code?.toUpperCase() === 'APLUS' ||
        currentCompany.slug?.toLowerCase() === 'aplus' ||
        currentCompany.id?.startsWith('tenant_');

      if (isCleanTenant) {
        const adminEmp: Employee = {
          id: `emp_${currentCompany.code.toLowerCase()}_admin`,
          code: `${currentCompany.code}-0001`,
          fullName: currentAccount?.fullName || 'Quản trị viên',
          gender: 'Nam',
          dob: '1990-01-01',
          phone: currentAccount?.phone || '0901234567',
          email: currentAccount?.email || 'admin@apluscorp.vn',
          idCardNumber: '001090000001',
          personalTaxCode: '8000000001',
          bankAccount: {
            bankName: 'Vietcombank',
            accountNumber: '999988887777',
            accountHolder: (currentAccount?.fullName || 'QUẢN TRỊ VIÊN').toUpperCase(),
          },
          educationLevel: 'Đại học',
          emergencyContact: {
            name: 'Người thân',
            relationship: 'Gia đình',
            phone: '0901234567',
          },
          departmentId: 'dept-1',
          departmentName: 'Ban Lãnh Đạo & Điều Hành',
          positionId: 'pos-1',
          positionName: 'Giám Đốc / Quản Trị Viên',
          jobLevel: 'C-Level',
          workLocation: 'Trụ sở chính',
          workRegion: 'Toàn quốc',
          joinDate: new Date().toISOString().split('T')[0],
          status: 'Chính thức',
          systemRole: 'Admin' as any,
          accountStatus: 'active',
          loginUsername: currentAccount?.email || 'admin',
          socialInsuranceNumber: '0123456789',
          healthInsuranceCardNumber: 'DN4010123456789',
          healthClinicName: 'BV Đa Khoa',
          insuranceStatus: 'Đang tham gia',
          insuranceSalary: 20000000,
        };

        const saved = localStorage.getItem(`crm_employees_${currentCompany.id}`);
        if (saved) {
          try {
            setEmployees(JSON.parse(saved));
          } catch (e) {
            setEmployees(INITIAL_EMPLOYEES.slice(0, 5));
          }
        } else {
          setEmployees(INITIAL_EMPLOYEES.slice(0, 5));
        }
      }
    }
  }, [currentCompany?.id, currentAccount?.id]);
  const [departments, setDepartments] = useState<Department[]>(INITIAL_DEPARTMENTS);
  const [teams, setTeams] = useState<TeamCategory[]>(INITIAL_TEAMS);
  const [positions, setPositions] = useState<PositionCategory[]>(INITIAL_POSITIONS);
  const [contracts, setContracts] = useState<EmployeeContract[]>(INITIAL_EMPLOYEE_CONTRACTS);
  const [workHistories, setWorkHistories] = useState<WorkHistoryRecord[]>(INITIAL_WORK_HISTORIES);
  const [documents, setDocuments] = useState<EmployeeDocument[]>([]);
  const [profileRequests, setProfileRequests] = useState<ProfileUpdateRequest[]>(INITIAL_PROFILE_REQUESTS);
  const [checklistsMap, setChecklistsMap] = useState<Record<string, { onboarding: ChecklistItem[]; offboarding: ChecklistItem[] }>>({
    'emp-11': SAMPLE_CHECKLISTS,
    'emp-12': SAMPLE_CHECKLISTS,
    'emp-14': SAMPLE_CHECKLISTS,
  });

  // Insurance State
  const [insuranceParticipants, setInsuranceParticipants] = useState<InsuranceParticipant[]>(INITIAL_INSURANCE_PARTICIPANTS);
  const [insuranceChanges, setInsuranceChanges] = useState<InsuranceChangeRecord[]>(INITIAL_INSURANCE_CHANGES);
  const [monthlyPeriods, setMonthlyPeriods] = useState<InsuranceMonthlyPeriod[]>(INITIAL_MONTHLY_PERIODS);
  const [insuranceClaims, setInsuranceClaims] = useState<InsuranceClaimRecord[]>(INITIAL_INSURANCE_CLAIMS);
  const [insuranceConfigs, setInsuranceConfigs] = useState<InsuranceConfigItem[]>(INITIAL_INSURANCE_CONFIG);
  const [accessLogs, setAccessLogs] = useState<SensitiveDataAccessLog[]>(INITIAL_ACCESS_LOGS);

  // Active config (lấy cấu hình có ngày hiệu lực mới nhất)
  const activeConfig = useMemo(() => {
    return [...insuranceConfigs].sort((a, b) => b.effectiveDate.localeCompare(a.effectiveDate))[0];
  }, [insuranceConfigs]);

  // Helper mask sensitive
  const maskSensitive = (val?: string, visibleChars = 4) => {
    if (!val) return '—';
    if (val.length <= visibleChars) return val;
    const maskedPart = '•'.repeat(Math.max(4, val.length - visibleChars));
    return maskedPart + val.slice(-visibleChars);
  };

  // Helper logging
  const logSensitiveAccess = (
    action: SensitiveDataAccessLog['action'],
    targetEmployeeName: string,
    fields: string[],
    details?: string
  ) => {
    const newLog: SensitiveDataAccessLog = {
      id: `log-${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      actorName: 'Người dùng hiện tại',
      actorRole: 'Nhân sự / Giám đốc',
      action,
      targetEmployeeName,
      fieldsAccessed: fields,
      ipAddress: '192.168.1.50',
      details,
    };
    setAccessLogs((prev) => [newLog, ...prev]);
  };

  // 1. ADD EMPLOYEE (WIZARD & AUTO PROPOSE BHXH)
  const addEmployee = (
    empData: Omit<Employee, 'id' | 'code' | 'createdAt'>,
    contractData?: {
      type: EmployeeContract['type'];
      startDate: string;
      endDate?: string;
      baseSalary: number;
      allowances: { name: string; amount: number }[];
      insuranceSalary: number;
    },
    checklistItems?: ChecklistItem[]
  ): Employee => {
    const nextIdx = employees.length + 1;
    const code = `NV-${String(nextIdx).padStart(4, '0')}`;
    const id = `emp-${nextIdx}`;

    const newEmp: Employee = {
      ...empData,
      id,
      code,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setEmployees((prev) => [newEmp, ...prev]);

    // Thêm Hợp đồng lao động nếu có
    if (contractData) {
      const newContract: EmployeeContract = {
        id: `hd-${Date.now()}`,
        employeeId: id,
        contractNumber: `HĐLĐ-2026-${String(nextIdx).padStart(4, '0')}`,
        type: contractData.type,
        startDate: contractData.startDate,
        endDate: contractData.endDate,
        baseSalary: contractData.baseSalary,
        allowances: contractData.allowances || [],
        insuranceSalary: contractData.insuranceSalary,
        status: 'Còn hạn',
        signedDate: contractData.startDate,
      };
      setContracts((prev) => [newContract, ...prev]);

      // TỰ ĐỘNG ĐỀ XUẤT BÁO TĂNG BHXH nếu hợp đồng từ đủ 1 tháng trở lên
      // Thêm vào danh sách người tham gia nếu có đóng BHXH
      if (contractData.type !== 'Thời vụ/Dịch vụ' && contractData.insuranceSalary > 0) {
        const salary = contractData.insuranceSalary;
        const eeAmount = Math.round(salary * (activeConfig.rates.employee.total / 100));
        const erAmount = Math.round(salary * (activeConfig.rates.employer.total / 100));

        const participant: InsuranceParticipant = {
          id: `ip-${id}`,
          employeeId: id,
          employeeCode: code,
          employeeName: newEmp.fullName,
          departmentName: newEmp.departmentName,
          socialInsuranceNumber: newEmp.socialInsuranceNumber || 'Chưa cấp',
          healthInsuranceCardNumber: newEmp.healthInsuranceCardNumber || 'Chưa cấp',
          healthInsuranceExpiry: '2026-12-31',
          healthClinicName: newEmp.healthClinicName || 'Bệnh viện Đa khoa Nông Nghiệp',
          startDate: contractData.startDate,
          insuranceSalary: salary,
          employeeRate: activeConfig.rates.employee.total,
          employerRate: activeConfig.rates.employer.total,
          employeeAmount: eeAmount,
          employerAmount: erAmount,
          totalAmount: eeAmount + erAmount,
          status: 'Chờ báo tăng',
        };
        setInsuranceParticipants((prev) => [participant, ...prev]);
      }
    }

    // Tự ghi quá trình công tác
    const initialHistory: WorkHistoryRecord = {
      id: `wh-${Date.now()}`,
      employeeId: id,
      date: newEmp.joinDate,
      type: 'Vào làm',
      changeSummary: `Tiếp nhận nhân sự mới vào phòng ${newEmp.departmentName}, chức vụ: ${newEmp.positionName}`,
      performedBy: 'Bộ phận Nhân sự',
      notes: `Trạng thái: ${newEmp.status}`,
    };
    setWorkHistories((prev) => [initialHistory, ...prev]);

    // Checklist tiếp nhận
    if (checklistItems && checklistItems.length > 0) {
      setChecklistsMap((prev) => ({
        ...prev,
        [id]: {
          onboarding: checklistItems,
          offboarding: SAMPLE_CHECKLISTS.offboarding,
        },
      }));
    }

    showToast('Thêm nhân viên thành công', `Đã lưu hồ sơ ${newEmp.fullName} (${code}) và tự động đề xuất báo tăng BHXH.`, 'success');
    return newEmp;
  };

  // UPDATE EMPLOYEE
  const updateEmployee = (id: string, updates: Partial<Employee>, reason?: string) => {
    const oldEmp = employees.find((e) => e.id === id);
    if (!oldEmp) return;

    setEmployees((prev) =>
      prev.map((e) => (e.id === id ? { ...e, ...updates } : e))
    );

    // Nếu đổi chức danh hoặc phòng ban -> tự ghi quá trình công tác
    if (updates.departmentName && updates.departmentName !== oldEmp.departmentName) {
      setWorkHistories((prev) => [
        {
          id: `wh-${Date.now()}`,
          employeeId: id,
          date: new Date().toISOString().split('T')[0],
          type: 'Điều chuyển phòng ban',
          changeSummary: `Điều chuyển từ "${oldEmp.departmentName}" sang "${updates.departmentName}"`,
          performedBy: 'Ban Giám Đốc',
          notes: reason,
        },
        ...prev,
      ]);
    }

    if (updates.positionName && updates.positionName !== oldEmp.positionName) {
      setWorkHistories((prev) => [
        {
          id: `wh-${Date.now() + 1}`,
          employeeId: id,
          date: new Date().toISOString().split('T')[0],
          type: 'Thăng chức',
          changeSummary: `Bổ nhiệm chức vụ mới: ${updates.positionName} (trước đó: ${oldEmp.positionName})`,
          performedBy: 'Ban Giám Đốc',
          notes: reason,
        },
        ...prev,
      ]);
    }

    showToast('Cập nhật nhân viên', `Đã lưu các thông tin thay đổi cho ${oldEmp.fullName}.`, 'info');
  };

  const deleteEmployee = (id: string) => {
    setEmployees((prev) => prev.filter((e) => e.id !== id));
    showToast('Xóa nhân viên', 'Đã xóa hồ sơ nhân viên khỏi hệ thống.', 'warning');
  };

  // CONVERT PROBATION TO OFFICIAL
  const convertProbationToOfficial = (employeeId: string, newInsuranceSalary?: number) => {
    const emp = employees.find((e) => e.id === employeeId);
    if (!emp) return;

    const today = new Date().toISOString().split('T')[0];
    const updatedSalary = newInsuranceSalary || emp.insuranceSalary;

    setEmployees((prev) =>
      prev.map((e) =>
        e.id === employeeId
          ? {
              ...e,
              status: 'Chính thức',
              officialDate: today,
              insuranceSalary: updatedSalary,
              insuranceStatus: 'Đang tham gia',
            }
          : e
      )
    );

    // Ký HĐLĐ chính thức mới
    const newContractNumber = `HĐLĐ-2026-${emp.code.replace('NV-', '')}`;
    const newContract: EmployeeContract = {
      id: `hd-${Date.now()}`,
      employeeId,
      contractNumber: newContractNumber,
      type: 'Xác định thời hạn',
      startDate: today,
      endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      baseSalary: updatedSalary,
      allowances: [],
      insuranceSalary: updatedSalary,
      status: 'Còn hạn',
      signedDate: today,
    };
    setContracts((prev) => [newContract, ...prev]);

    // Ghi quá trình công tác
    setWorkHistories((prev) => [
      {
        id: `wh-${Date.now()}`,
        employeeId,
        date: today,
        type: 'Chuyển chính thức',
        changeSummary: `Đạt đánh giá thử việc, chuyển chính thức với mức lương đóng BHXH: ${updatedSalary.toLocaleString()} đ`,
        performedBy: 'Ban Giám Đốc',
      },
      ...prev,
    ]);

    // Cập nhật người tham gia BHXH
    setInsuranceParticipants((prev) =>
      prev.map((p) =>
        p.employeeId === employeeId
          ? {
              ...p,
              insuranceSalary: updatedSalary,
              status: 'Đang tham gia',
              employeeAmount: Math.round(updatedSalary * 0.105),
              employerAmount: Math.round(updatedSalary * 0.215),
              totalAmount: Math.round(updatedSalary * 0.32),
            }
          : p
      )
    );

    showToast('Chuyển chính thức', `Chúc mừng ${emp.fullName} đã ký Hợp đồng lao động chính thức!`, 'success');
  };

  // RENEW / SIGN NEW CONTRACT
  const renewOrSignContract = (
    employeeId: string,
    contractData: Omit<EmployeeContract, 'id' | 'employeeId' | 'status'>
  ): EmployeeContract => {
    const emp = employees.find((e) => e.id === employeeId);
    const newContract: EmployeeContract = {
      ...contractData,
      id: `hd-${Date.now()}`,
      employeeId,
      status: 'Còn hạn',
    };

    // Đánh dấu hợp đồng cũ là đã thanh lý/hết hạn
    setContracts((prev) => [
      newContract,
      ...prev.map((c) =>
        c.employeeId === employeeId && c.id !== newContract.id
          ? { ...c, status: 'Đã thanh lý' as const }
          : c
      ),
    ]);

    // Kiểm tra nếu lương đóng BHXH thay đổi -> TỰ ĐỘNG ĐỀ XUẤT ĐIỀU CHỈNH LƯƠNG ĐÓNG BHXH
    if (emp && emp.insuranceSalary !== contractData.insuranceSalary) {
      const bdCode = `BD-2026-${String(insuranceChanges.length + 1).padStart(4, '0')}`;
      setInsuranceChanges((prev) => [
        {
          id: `bd-${Date.now()}`,
          code: bdCode,
          type: 'Điều chỉnh',
          employeeId,
          employeeName: emp.fullName,
          departmentName: emp.departmentName,
          effectiveDate: contractData.startDate,
          reason: 'Ký phụ lục / gia hạn HĐLĐ mới có điều chỉnh mức lương đóng BHXH',
          oldSalary: emp.insuranceSalary,
          newSalary: contractData.insuranceSalary,
          status: 'Đề xuất',
          isAutoGenerated: true,
          createdAt: new Date().toISOString().split('T')[0],
        },
        ...prev,
      ]);

      // Cập nhật lại lương ở employee
      setEmployees((prev) =>
        prev.map((e) =>
          e.id === employeeId ? { ...e, insuranceSalary: contractData.insuranceSalary } : e
        )
      );
    }

    // Ghi quá trình công tác
    setWorkHistories((prev) => [
      {
        id: `wh-${Date.now()}`,
        employeeId,
        date: contractData.startDate,
        type: 'Ký hợp đồng',
        changeSummary: `Ký gia hạn/mới hợp đồng ${contractData.contractNumber} (${contractData.type})`,
        performedBy: 'Bộ phận Nhân sự',
      },
      ...prev,
    ]);

    showToast('Ký hợp đồng mới', `Đã lưu hợp đồng số ${contractData.contractNumber} thành công.`, 'success');
    return newContract;
  };

  // HANDOVER ON OFFBOARDING (BÀN GIAO DỮ LIỆU CRM & KHÓA TÀI KHOẢN)
  const handoverEmployeeData = (
    leavingEmployeeId: string,
    targetEmployeeId: string,
    notes?: string
  ) => {
    const leavingEmp = employees.find((e) => e.id === leavingEmployeeId);
    const targetEmp = employees.find((e) => e.id === targetEmployeeId);

    if (!leavingEmp || !targetEmp) {
      throw new Error('Không tìm thấy nhân viên bàn giao hoặc người nhận');
    }

    const leavingName = leavingEmp.fullName;
    const targetName = targetEmp.fullName;

    // 1. Chuyển Lead phụ trách
    const affectedLeads = leads.filter((l) => l.assignedTo === leavingName);
    affectedLeads.forEach((l) => updateLead(l.id, { assignedTo: targetName }));

    // 2. Chuyển Khách hàng phụ trách
    const affectedCusts = customers.filter((c) => c.assignedTo === leavingName);
    affectedCusts.forEach((c) => updateCustomer(c.id, { assignedTo: targetName }));

    // 3. Chuyển Cơ hội (Deals) phụ trách
    const affectedOpps = opportunities.filter((o) => o.assignedTo === leavingName);
    affectedOpps.forEach((o) => updateOpportunity(o.id, { assignedTo: targetName }));

    // 4. Khóa tài khoản nhân viên & đổi trạng thái Đã nghỉ việc
    setEmployees((prev) =>
      prev.map((e) =>
        e.id === leavingEmployeeId
          ? {
              ...e,
              status: 'Đã nghỉ việc',
              accountStatus: 'locked',
              insuranceStatus: 'Chờ báo giảm',
            }
          : e
      )
    );

    // 5. TỰ ĐỘNG ĐỀ XUẤT BÁO GIẢM BHXH
    const bdCode = `BD-2026-${String(insuranceChanges.length + 1).padStart(4, '0')}`;
    setInsuranceChanges((prev) => [
      {
        id: `bd-${Date.now()}`,
        code: bdCode,
        type: 'Báo giảm',
        employeeId: leavingEmployeeId,
        employeeName: leavingName,
        departmentName: leavingEmp.departmentName,
        effectiveDate: new Date().toISOString().split('T')[0],
        reason: 'Chấm dứt hợp đồng lao động thôi việc và hoàn tất thủ tục bàn giao',
        oldSalary: leavingEmp.insuranceSalary,
        status: 'Đề xuất',
        notes: `Đã bàn giao ${affectedCusts.length} KH, ${affectedLeads.length} Leads, ${affectedOpps.length} Cơ hội sang ${targetName}.`,
        isAutoGenerated: true,
        createdAt: new Date().toISOString().split('T')[0],
      },
      ...prev,
    ]);

    // 6. Ghi Quá trình công tác
    setWorkHistories((prev) => [
      {
        id: `wh-${Date.now()}`,
        employeeId: leavingEmployeeId,
        date: new Date().toISOString().split('T')[0],
        type: 'Nghỉ việc',
        changeSummary: `Hoàn tất thủ tục thôi việc. Đã bàn giao toàn bộ dữ liệu phụ trách (${affectedCusts.length} KH, ${affectedLeads.length} Leads, ${affectedOpps.length} Cơ hội) sang ${targetName}. Khóa tài khoản hệ thống.`,
        performedBy: 'Hệ thống CRM & Nhân sự',
        notes,
      },
      ...prev,
    ]);

    // 7. Ghi nhật ký truy cập nhạy cảm
    logSensitiveAccess(
      'HANDOVER_DATA',
      leavingName,
      ['Khách hàng', 'Leads', 'Cơ hội', 'Khóa tài khoản'],
      `Bàn giao dữ liệu sang ${targetName}`
    );

    showToast(
      'Bàn giao hoàn tất',
      `Đã chuyển ${affectedCusts.length} KH, ${affectedLeads.length} Leads, ${affectedOpps.length} Cơ hội sang ${targetName} và khóa tài khoản của ${leavingName}.`,
      'success'
    );

    return {
      leadsCount: affectedLeads.length,
      customersCount: affectedCusts.length,
      oppsCount: affectedOpps.length,
    };
  };

  // PROFILE UPDATE REQUESTS (Self-service)
  const createProfileUpdateRequest = (
    employeeId: string,
    requestedChanges: ProfileUpdateRequest['requestedChanges']
  ) => {
    const emp = employees.find((e) => e.id === employeeId);
    if (!emp) return;

    const newReq: ProfileUpdateRequest = {
      id: `req-${Date.now()}`,
      employeeId,
      employeeName: emp.fullName,
      requestDate: new Date().toISOString().split('T')[0],
      requestedChanges,
      status: 'Chờ duyệt',
    };

    setProfileRequests((prev) => [newReq, ...prev]);
    showToast('Gửi yêu cầu thành công', 'Yêu cầu cập nhật thông tin đã được gửi đến bộ phận Nhân sự phê duyệt.', 'success');
  };

  const approveProfileUpdateRequest = (requestId: string) => {
    const req = profileRequests.find((r) => r.id === requestId);
    if (!req) return;

    setEmployees((prev) =>
      prev.map((e) => {
        if (e.id !== req.employeeId) return e;
        const updated = { ...e };
        req.requestedChanges.forEach((ch) => {
          if (ch.field === 'bankAccount' && typeof ch.newValue === 'object') {
            updated.bankAccount = ch.newValue;
          } else if (ch.field in updated) {
            (updated as any)[ch.field] = ch.newValue;
          }
        });
        return updated;
      })
    );

    setProfileRequests((prev) =>
      prev.map((r) =>
        r.id === requestId
          ? {
              ...r,
              status: 'Đã duyệt',
              approvedBy: 'Đặng Thu Thảo (HR Leader)',
              approvedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            }
          : r
      )
    );

    showToast('Phê duyệt yêu cầu', `Đã cập nhật hồ sơ cho ${req.employeeName}.`, 'success');
  };

  const rejectProfileUpdateRequest = (requestId: string, reason: string) => {
    setProfileRequests((prev) =>
      prev.map((r) =>
        r.id === requestId ? { ...r, status: 'Từ chối', rejectReason: reason } : r
      )
    );
    showToast('Từ chối yêu cầu', `Đã từ chối yêu cầu cập nhật với lý do: ${reason}`, 'info');
  };

  // CHECKLIST UPDATE
  const updateChecklistItem = (
    employeeId: string,
    type: 'onboarding' | 'offboarding',
    itemId: string,
    completed: boolean
  ) => {
    setChecklistsMap((prev) => {
      const current = prev[employeeId] || SAMPLE_CHECKLISTS;
      const updatedList = current[type].map((item) =>
        item.id === itemId
          ? {
              ...item,
              completed,
              completedAt: completed ? new Date().toISOString().split('T')[0] : undefined,
            }
          : item
      );
      return {
        ...prev,
        [employeeId]: {
          ...current,
          [type]: updatedList,
        },
      };
    });
  };

  // DEPARTMENTS & TEAMS & POSITIONS
  const addDepartment = (dept: Omit<Department, 'id' | 'memberCount'>) => {
    const newDept: Department = {
      ...dept,
      id: `dept-${Date.now()}`,
      memberCount: 0,
    };
    setDepartments((prev) => [...prev, newDept]);
    showToast('Thêm phòng ban', `Đã lưu phòng ban ${newDept.name}.`, 'success');
  };

  const updateDepartment = (id: string, updates: Partial<Department>) => {
    setDepartments((prev) => prev.map((d) => (d.id === id ? { ...d, ...updates } : d)));
    showToast('Cập nhật phòng ban', 'Đã lưu thay đổi phòng ban.', 'info');
  };

  const addTeam = (team: Omit<TeamCategory, 'id' | 'memberCount'>) => {
    const newTeam: TeamCategory = {
      ...team,
      id: `team-${Date.now()}`,
      memberCount: 0,
    };
    setTeams((prev) => [...prev, newTeam]);
    showToast('Thêm nhóm', `Đã bổ sung nhóm ${newTeam.name}.`, 'success');
  };

  const updateTeam = (id: string, updates: Partial<TeamCategory>) => {
    setTeams((prev) => prev.map((t) => (t.id === id ? { ...t, ...updates } : t)));
    showToast('Cập nhật nhóm', 'Đã lưu thay đổi nhóm.', 'info');
  };

  const addPosition = (pos: Omit<PositionCategory, 'id'>) => {
    const newPos: PositionCategory = {
      ...pos,
      id: `pos-${Date.now()}`,
    };
    setPositions((prev) => [...prev, newPos]);
    showToast('Thêm chức vụ', `Đã lưu chức vụ ${newPos.name}.`, 'success');
  };

  const updatePosition = (id: string, updates: Partial<PositionCategory>) => {
    setPositions((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));
    showToast('Cập nhật chức vụ', 'Đã lưu thay đổi chức vụ.', 'info');
  };

  // ==========================================
  // SOCIAL INSURANCE METHODS
  // ==========================================

  const addInsuranceChange = (change: Omit<InsuranceChangeRecord, 'id' | 'code' | 'createdAt'>) => {
    const code = `BD-2026-${String(insuranceChanges.length + 1).padStart(4, '0')}`;
    const newChange: InsuranceChangeRecord = {
      ...change,
      id: `bd-${Date.now()}`,
      code,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setInsuranceChanges((prev) => [newChange, ...prev]);
    showToast('Thêm biến động BHXH', `Đã lập phiếu ${code}: ${change.type} cho ${change.employeeName}.`, 'success');
  };

  const confirmInsuranceChange = (id: string) => {
    setInsuranceChanges((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: 'Đã xác nhận' } : c))
    );
    showToast('Xác nhận biến động', 'Nhân sự đã xác nhận thông tin biến động BHXH.', 'info');
  };

  const batchConfirmInsuranceChanges = (ids: string[]) => {
    setInsuranceChanges((prev) =>
      prev.map((c) => (ids.includes(c.id) ? { ...c, status: 'Đã xác nhận' } : c))
    );
    showToast('Xác nhận hàng loạt', `Đã xác nhận ${ids.length} phiếu biến động BHXH.`, 'success');
  };

  const submitInsuranceChangeToAgency = (id: string, submissionCode: string) => {
    setInsuranceChanges((prev) =>
      prev.map((c) =>
        c.id === id
          ? {
              ...c,
              status: 'Đã nộp CQ BHXH',
              submissionDate: new Date().toISOString().split('T')[0],
              submissionCode,
            }
          : c
      )
    );
    showToast('Đã nộp cơ quan BHXH', `Phiếu biến động đã nộp kèm số hồ sơ: ${submissionCode}.`, 'success');
  };

  const approveInsuranceChange = (id: string) => {
    const target = insuranceChanges.find((c) => c.id === id);
    if (!target) return;

    setInsuranceChanges((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: 'Đã duyệt' } : c))
    );

    // Đồng bộ trạng thái vào InsuranceParticipant và Employee
    if (target.type === 'Báo tăng') {
      setInsuranceParticipants((prev) =>
        prev.map((p) =>
          p.employeeId === target.employeeId ? { ...p, status: 'Đang tham gia' } : p
        )
      );
      setEmployees((prev) =>
        prev.map((e) =>
          e.id === target.employeeId ? { ...e, insuranceStatus: 'Đang tham gia' } : e
        )
      );
    } else if (target.type === 'Báo giảm') {
      setInsuranceParticipants((prev) =>
        prev.map((p) =>
          p.employeeId === target.employeeId ? { ...p, status: 'Đã dừng' } : p
        )
      );
      setEmployees((prev) =>
        prev.map((e) =>
          e.id === target.employeeId ? { ...e, insuranceStatus: 'Đã dừng' } : e
        )
      );
    } else if (target.type === 'Điều chỉnh' && target.newSalary) {
      setInsuranceParticipants((prev) =>
        prev.map((p) =>
          p.employeeId === target.employeeId
            ? {
                ...p,
                insuranceSalary: target.newSalary!,
                employeeAmount: Math.round(target.newSalary! * 0.105),
                employerAmount: Math.round(target.newSalary! * 0.215),
                totalAmount: Math.round(target.newSalary! * 0.32),
              }
            : p
        )
      );
      setEmployees((prev) =>
        prev.map((e) =>
          e.id === target.employeeId ? { ...e, insuranceSalary: target.newSalary! } : e
        )
      );
    }

    showToast('Cơ quan BHXH phê duyệt', `Hồ sơ ${target.code} đã được cơ quan BHXH chấp thuận.`, 'success');
  };

  const rejectInsuranceChange = (id: string, reason: string) => {
    setInsuranceChanges((prev) =>
      prev.map((c) => (c.id === id ? { ...c, status: 'Bị trả lại', rejectionReason: reason } : c))
    );
    showToast('Hồ sơ bị trả lại', `Cơ quan BHXH trả lại hồ sơ với lý do: ${reason}`, 'warning');
  };

  // GENERATE MONTHLY PERIOD (TỰ ĐỘNG TẠO TỪ DANH SÁCH THAM GIA & CẤU HÌNH HIỆU LỰC)
  const generateMonthlyPeriod = (monthStr: string): InsuranceMonthlyPeriod => {
    const activeParticipants = insuranceParticipants.filter(
      (p) => p.status === 'Đang tham gia' || p.status === 'Chờ báo tăng'
    );

    const r = activeConfig.rates;
    let totalSalaryFund = 0;
    let pensionEE = 0;
    let pensionER = 0;
    let maternityER = 0;
    let accidentER = 0;
    let healthEE = 0;
    let healthER = 0;
    let unempEE = 0;
    let unempER = 0;
    let tradeUnionFee = 0;

    const lines = activeParticipants.map((p) => {
      // Áp trần BHXH = 20 x lương cơ sở (50.600.000)
      const cappedSalarySocial = Math.min(p.insuranceSalary, activeConfig.ceilingSocialInsurance);
      // Áp trần BHTN = 20 x lương tối thiểu vùng I (106.200.000)
      const cappedSalaryUnemp = Math.min(p.insuranceSalary, activeConfig.ceilingUnemploymentInsuranceRegionI);

      totalSalaryFund += p.insuranceSalary;

      const pEE = Math.round(cappedSalarySocial * (r.employee.pension / 100));
      const pER = Math.round(cappedSalarySocial * (r.employer.pension / 100));
      const mER = Math.round(cappedSalarySocial * (r.employer.maternity / 100));
      const aER = Math.round(cappedSalarySocial * (r.employer.accident / 100));
      const hEE = Math.round(cappedSalarySocial * (r.employee.health / 100));
      const hER = Math.round(cappedSalarySocial * (r.employer.health / 100));
      const uEE = Math.round(cappedSalaryUnemp * (r.employee.unemployment / 100));
      const uER = Math.round(cappedSalaryUnemp * (r.employer.unemployment / 100));
      const uFee = Math.round(cappedSalarySocial * (r.tradeUnion / 100));

      pensionEE += pEE;
      pensionER += pER;
      maternityER += mER;
      accidentER += aER;
      healthEE += hEE;
      healthER += hER;
      unempEE += uEE;
      unempER += uER;
      tradeUnionFee += uFee;

      const totalNLĐ = pEE + hEE + uEE;
      const totalDN = pER + mER + aER + hER + uER + uFee;

      return {
        employeeId: p.employeeId,
        employeeCode: p.employeeCode,
        employeeName: p.employeeName,
        departmentName: p.departmentName,
        salary: p.insuranceSalary,
        pensionNLĐ: pEE,
        pensionDN: pER,
        maternityDN: mER,
        accidentDN: aER,
        healthNLĐ: hEE,
        healthDN: hER,
        unempNLĐ: uEE,
        unempDN: uER,
        unionFeeDN: uFee,
        totalNLĐ,
        totalDN,
        grandTotal: totalNLĐ + totalDN,
      };
    });

    const totalEmployeePaid = pensionEE + healthEE + unempEE;
    const totalEmployerPaid = pensionER + maternityER + accidentER + healthER + unempER;
    const grandTotal = totalEmployeePaid + totalEmployerPaid + tradeUnionFee;

    const newPeriod: InsuranceMonthlyPeriod = {
      id: `period-${monthStr.replace('/', '-')}`,
      periodMonth: monthStr,
      totalEmployees: activeParticipants.length,
      totalSalaryFund,
      pensionFund: { employee: pensionEE, employer: pensionER, total: pensionEE + pensionER },
      maternityFund: { employer: maternityER, total: maternityER },
      accidentFund: { employer: accidentER, total: accidentER },
      healthFund: { employee: healthEE, employer: healthER, total: healthEE + healthER },
      unemploymentFund: { employee: unempEE, employer: unempER, total: unempEE + unempER },
      tradeUnionFee,
      totalEmployeePaid,
      totalEmployerPaid,
      grandTotal,
      status: 'Nháp',
      lines,
    };

    setMonthlyPeriods((prev) => [newPeriod, ...prev.filter((p) => p.periodMonth !== monthStr)]);
    showToast('Tạo kỳ đóng BHXH', `Đã tổng hợp số liệu kỳ đóng tháng ${monthStr} cho ${activeParticipants.length} lao động.`, 'success');
    return newPeriod;
  };

  const lockMonthlyPeriod = (id: string) => {
    setMonthlyPeriods((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status: 'Đã chốt' } : p))
    );
    showToast('Khóa số liệu kỳ đóng', 'Đã chốt kỳ đóng BHXH. Số liệu được lưu giữ để đồng bộ sang Kế toán và Lương.', 'info');
  };

  const unlockMonthlyPeriod = (id: string, reason: string) => {
    setMonthlyPeriods((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status: 'Nháp', unlockedReason: reason } : p))
    );
    showToast('Mở lại kỳ đóng', `Đã mở lại kỳ đóng với lý do: ${reason}`, 'warning');
  };

  const recordPeriodPayment = (id: string, refNumber: string, amount: number) => {
    const today = new Date().toISOString().split('T')[0];
    setMonthlyPeriods((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              status: 'Đã nộp tiền',
              paymentDate: today,
              paymentRefNumber: refNumber,
              paidAmount: amount,
            }
          : p
      )
    );
    showToast('Xác nhận nộp tiền', `Đã ghi nhận nộp tiền BHXH tháng kèm số chứng từ: ${refNumber}.`, 'success');
  };

  // CLAIMS
  const addInsuranceClaim = (claim: Omit<InsuranceClaimRecord, 'id'>) => {
    const newClaim: InsuranceClaimRecord = {
      ...claim,
      id: `claim-${Date.now()}`,
    };
    setInsuranceClaims((prev) => [newClaim, ...prev]);
    logSensitiveAccess('EDIT_SENSITIVE', claim.employeeName, ['Chế độ BHXH', claim.type], 'Tạo hồ sơ hưởng chế độ');
    showToast('Tạo hồ sơ chế độ', `Đã lưu hồ sơ hưởng chế độ ${claim.type} cho ${claim.employeeName}.`, 'success');
  };

  const updateClaimStatus = (id: string, status: InsuranceClaimRecord['status'], actualAmount?: number) => {
    setInsuranceClaims((prev) =>
      prev.map((c) =>
        c.id === id
          ? {
              ...c,
              status,
              actualAmount: actualAmount !== undefined ? actualAmount : c.actualAmount,
            }
          : c
      )
    );
    showToast('Cập nhật chế độ', `Hồ sơ đã chuyển trạng thái: ${status}.`, 'info');
  };

  // CONFIG
  const addInsuranceConfig = (cfg: Omit<InsuranceConfigItem, 'id'>) => {
    const newCfg: InsuranceConfigItem = {
      ...cfg,
      id: `cfg-${Date.now()}`,
    };
    setInsuranceConfigs((prev) => [newCfg, ...prev]);
    showToast('Thêm cấu hình hiệu lực mới', `Đã lưu cấu hình áp dụng từ ngày ${cfg.effectiveDate}.`, 'success');
  };

  return (
    <HRContext.Provider
      value={{
        employees,
        departments,
        teams,
        positions,
        contracts,
        workHistories,
        documents,
        profileRequests,
        accessLogs,

        addEmployee,
        updateEmployee,
        deleteEmployee,
        renewOrSignContract,
        convertProbationToOfficial,
        handoverEmployeeData,
        createProfileUpdateRequest,
        approveProfileUpdateRequest,
        rejectProfileUpdateRequest,
        updateChecklistItem,

        addDepartment,
        updateDepartment,
        addTeam,
        updateTeam,
        addPosition,
        updatePosition,

        insuranceParticipants,
        insuranceChanges,
        monthlyPeriods,
        insuranceClaims,
        insuranceConfigs,
        activeConfig,

        addInsuranceChange,
        confirmInsuranceChange,
        batchConfirmInsuranceChanges,
        submitInsuranceChangeToAgency,
        approveInsuranceChange,
        rejectInsuranceChange,

        generateMonthlyPeriod,
        lockMonthlyPeriod,
        unlockMonthlyPeriod,
        recordPeriodPayment,

        addInsuranceClaim,
        updateClaimStatus,

        addInsuranceConfig,
        logSensitiveAccess,
        maskSensitive,
      }}
    >
      {children}
    </HRContext.Provider>
  );
};

export const useHR = () => {
  const context = useContext(HRContext);
  if (!context) {
    throw new Error('useHR must be used within an HRProvider');
  }
  return context;
};
