import React from 'react';
import { useCRM } from '../../context/CRMContext';
import { ActiveModule } from '../../types/crm';
import { getMenuTitle } from '../../i18n/translations';
import { ChevronRight, ArrowLeft } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  targetModule?: ActiveModule;
  isAction?: boolean;
}

const BREADCRUMB_MAP: Record<string, { group: string; label: string; groupModule?: ActiveModule }> = {
  dashboard: { group: 'Tổng quan', label: 'Bàn làm việc', groupModule: 'dashboard' },
  reports: { group: 'Báo cáo', label: 'Tổng quan báo cáo', groupModule: 'reports' },
  'sales-overview': { group: 'Báo cáo', label: 'Tổng quan Sales', groupModule: 'reports' },
  'sales-revenue': { group: 'Báo cáo', label: 'Doanh thu Sales', groupModule: 'reports' },
  'sales-forecast': { group: 'Báo cáo', label: 'Dự báo doanh số', groupModule: 'reports' },
  'sales-funnel': { group: 'Báo cáo', label: 'Phễu bán hàng', groupModule: 'reports' },
  'sales-won': { group: 'Báo cáo', label: 'Deal thành công', groupModule: 'reports' },
  'sales-lost': { group: 'Báo cáo', label: 'Deal thất bại', groupModule: 'reports' },
  'sales-productivity': { group: 'Báo cáo', label: 'Hiệu suất nhân viên', groupModule: 'reports' },
  'sales-leads': { group: 'Báo cáo', label: 'Phân tích Leads', groupModule: 'reports' },
  'reports-inventory': { group: 'Báo cáo', label: 'Báo cáo Kho', groupModule: 'reports' },
  'reports-logistics': { group: 'Báo cáo', label: 'Báo cáo Vận chuyển', groupModule: 'reports' },
  'reports-accounting': { group: 'Báo cáo', label: 'Báo cáo Kế toán', groupModule: 'reports' },
  'reports-technical': { group: 'Báo cáo', label: 'Báo cáo Kỹ thuật', groupModule: 'reports' },
  'reports-hr': { group: 'Báo cáo', label: 'Báo cáo Nhân sự', groupModule: 'reports' },

  // Sales Module
  sales: { group: 'Quản lý Sales', label: 'Tổng quan Sales', groupModule: 'sales' },
  leads: { group: 'Quản lý Sales', label: 'Lead tiềm năng', groupModule: 'sales' },
  customers: { group: 'Quản lý Sales', label: 'Khách hàng', groupModule: 'sales' },
  contacts: { group: 'Quản lý Sales', label: 'Người liên hệ', groupModule: 'sales' },
  opportunities: { group: 'Quản lý Sales', label: 'Cơ hội bán hàng', groupModule: 'sales' },
  quotations: { group: 'Quản lý Sales', label: 'Báo giá & Đề xuất', groupModule: 'sales' },
  'sales-orders': { group: 'Quản lý Sales', label: 'Đơn hàng & Phê duyệt', groupModule: 'sales' },
  contracts: { group: 'Quản lý Sales', label: 'Hợp đồng kinh tế', groupModule: 'sales' },
  'sales-invoices': { group: 'Quản lý Sales', label: 'Hóa đơn bán hàng', groupModule: 'sales' },
  'sales-receipts': { group: 'Quản lý Sales', label: 'Phiếu thu tiền', groupModule: 'sales' },
  'sales-activities': { group: 'Quản lý Sales', label: 'Hoạt động & Lịch hẹn', groupModule: 'sales' },
  tasks: { group: 'Quản lý Sales', label: 'Công việc cần làm', groupModule: 'sales' },
  calendar: { group: 'Quản lý Sales', label: 'Lịch làm việc', groupModule: 'calendar' },

  // Warehouse Module (Inventory)
  inventory: { group: 'Quản lý kho', label: 'Tổng quan tồn kho', groupModule: 'inventory' },
  'inventory-overview': { group: 'Quản lý kho', label: 'Tổng quan tồn kho', groupModule: 'inventory' },
  'inventory-stock-in': { group: 'Quản lý kho', label: 'Nhập kho', groupModule: 'inventory' },
  'inventory-stock-out': { group: 'Quản lý kho', label: 'Xuất kho', groupModule: 'inventory' },
  'inventory-history': { group: 'Quản lý kho', label: 'Lịch sử kho', groupModule: 'inventory' },
  'inventory-expiry': { group: 'Quản lý kho', label: 'Hàng sắp hết hạn', groupModule: 'inventory' },

  // Logistics Module
  logistics: { group: 'Quản lý Vận chuyển', label: 'Duyệt đơn hàng', groupModule: 'logistics' },
  'logistics-order-approval': { group: 'Quản lý Vận chuyển', label: 'Duyệt đơn hàng', groupModule: 'logistics' },
  'logistics-stock-out': { group: 'Quản lý Vận chuyển', label: 'Xuất kho vận chuyển', groupModule: 'logistics' },
  'logistics-delivery-notes': { group: 'Quản lý Vận chuyển', label: 'Phiếu giao hàng', groupModule: 'logistics' },
  'logistics-shipments': { group: 'Quản lý Vận chuyển', label: 'Chuyến hàng', groupModule: 'logistics' },
  'logistics-handover': { group: 'Quản lý Vận chuyển', label: 'Biên bản bàn giao', groupModule: 'logistics' },
  'logistics-cod-collections': { group: 'Quản lý Vận chuyển', label: 'Thu hộ tiền COD', groupModule: 'logistics' },
  'logistics-purchase-orders': { group: 'Quản lý Vận chuyển', label: 'Đơn mua hàng', groupModule: 'logistics' },
  'logistics-purchase-invoices': { group: 'Quản lý Vận chuyển', label: 'Hóa đơn mua hàng', groupModule: 'logistics' },
  'logistics-stock-in': { group: 'Quản lý Vận chuyển', label: 'Nhập kho mua hàng', groupModule: 'logistics' },
  'logistics-payment-requests': { group: 'Quản lý Vận chuyển', label: 'Đề nghị thanh toán', groupModule: 'logistics' },
  'logistics-stock-history': { group: 'Quản lý Vận chuyển', label: 'Lịch sử vận chuyển', groupModule: 'logistics' },
  'logistics-approaching-expiry': { group: 'Quản lý Vận chuyển', label: 'Hàng cận hạn', groupModule: 'logistics' },
  'logistics-document-expiry': { group: 'Quản lý Vận chuyển', label: 'Giấy tờ sắp hết hạn', groupModule: 'logistics' },

  // Accounting Module
  accounting: { group: 'Kế toán', label: 'Công nợ', groupModule: 'accounting' },
  'accounting-debt': { group: 'Kế toán', label: 'Công nợ phải thu', groupModule: 'accounting' },
  'accounting-invoices': { group: 'Kế toán', label: 'Hóa đơn & Báo giá', groupModule: 'accounting' },
  'accounting-transactions': { group: 'Kế toán', label: 'Giao dịch & Dòng tiền', groupModule: 'accounting' },
  'accounting-reports': { group: 'Kế toán', label: 'Báo cáo tài chính', groupModule: 'accounting' },

  // Technical Module
  technical: { group: 'Kỹ thuật', label: 'Hồ sơ khách hàng', groupModule: 'technical' },
  'technical-customers': { group: 'Kỹ thuật', label: 'Hồ sơ khách hàng kỹ thuật', groupModule: 'technical' },
  'technical-directory': { group: 'Kỹ thuật', label: 'Danh mục kỹ thuật', groupModule: 'technical' },
  'technical-quotations': { group: 'Kỹ thuật', label: 'Báo giá kỹ thuật', groupModule: 'technical' },
  'technical-contracts': { group: 'Kỹ thuật', label: 'Hợp đồng kỹ thuật', groupModule: 'technical' },
  'technical-master-planning': { group: 'Kỹ thuật', label: 'Kế hoạch tổng thể', groupModule: 'technical' },
  'technical-payment-requests': { group: 'Kỹ thuật', label: 'Đề nghị thanh toán KT', groupModule: 'technical' },
  'technical-warranty-stock-out': { group: 'Kỹ thuật', label: 'Xuất kho bảo hành', groupModule: 'technical' },
  'technical-expiring-contracts': { group: 'Kỹ thuật', label: 'Hợp đồng sắp hết hạn', groupModule: 'technical' },

  // HR Module
  hr: { group: 'Quản lý nhân sự', label: 'Danh sách nhân sự', groupModule: 'hr' },
  'hr-staff': { group: 'Quản lý nhân sự', label: 'Nhân viên', groupModule: 'hr' },
  'hr-insurance': { group: 'Quản lý nhân sự', label: 'Bảo hiểm xã hội', groupModule: 'hr' },
  'my-profile': { group: 'Quản lý nhân sự', label: 'Hồ sơ của tôi', groupModule: 'hr' },

  // Settings Module
  settings: { group: 'Cài đặt hệ thống', label: 'Người dùng', groupModule: 'settings' },
  'settings-users': { group: 'Cài đặt hệ thống', label: 'Người dùng & Thành viên', groupModule: 'settings' },
  'settings-permissions': { group: 'Cài đặt hệ thống', label: 'Nhóm quyền & Cơ cấu', groupModule: 'settings' },
  'system-architecture': { group: 'Cài đặt hệ thống', label: 'Sơ đồ Kiến trúc CSDL', groupModule: 'settings' },
  'settings-system': { group: 'Cài đặt hệ thống', label: 'Cấu hình hệ thống', groupModule: 'settings' },
  'settings-app': { group: 'Cài đặt hệ thống', label: 'Cấu hình nghiệp vụ', groupModule: 'settings' },
  'settings-dictionary': { group: 'Cài đặt hệ thống', label: 'Từ điển giá trị', groupModule: 'settings' },
  'settings-directories': { group: 'Cài đặt hệ thống', label: 'Danh mục dữ liệu', groupModule: 'settings' },
  'settings-sync-logs': { group: 'Cài đặt hệ thống', label: 'Nhật ký đồng bộ', groupModule: 'settings' },

  // System & Special Pages
  'notifications-center': { group: 'Hệ thống', label: 'Trung tâm thông báo' },
  'customer-care': { group: 'Chăm sóc khách hàng', label: 'Hỗ trợ & Ticket' },
  specifications: { group: 'Đặc tả hệ thống', label: 'Bộ 24 Đặc tả A+' },
  'platform-admin': { group: 'Cổng Super Admin', label: 'Quản trị Nền tảng (Platform Hub)' },
};

export const HeaderBreadcrumb: React.FC = () => {
  const { activeModule, setActiveModule, currentDocCode, setCurrentDocCode, language } = useCRM();

  const info = BREADCRUMB_MAP[activeModule] || {
    group: 'Hệ thống',
    label: activeModule,
    groupModule: undefined,
  };

  // Group label translation: use parent group module if present, otherwise group fallback
  const groupLabel = info.groupModule && info.groupModule !== activeModule
    ? getMenuTitle(info.groupModule, info.group, language)
    : info.group;

  // Module label translation
  const moduleLabel = getMenuTitle(activeModule, info.label, language);

  // Check if group and module have the same label or if this is a top-level screen
  const isTopLevel =
    !info.groupModule ||
    info.groupModule === activeModule ||
    groupLabel.trim().toLowerCase() === moduleLabel.trim().toLowerCase();

  // Build items array: Group -> Module Page -> Document Code (if any)
  const items: BreadcrumbItem[] = isTopLevel
    ? [{ label: moduleLabel, targetModule: activeModule }]
    : [
        { label: groupLabel, targetModule: info.groupModule },
        { label: moduleLabel, targetModule: activeModule },
      ];

  if (currentDocCode) {
    items.push({ label: currentDocCode });
  }

  const handleItemClick = (index: number) => {
    if (index === items.length - 1) return; // Last item is current, do nothing

    if (currentDocCode && index === items.length - 2) {
      // Clicked on the module level while inside document view -> clear document view
      setCurrentDocCode(null);
      return;
    }

    const item = items[index];
    if (item.targetModule) {
      setCurrentDocCode(null);
      setActiveModule(item.targetModule);
    }
  };

  const handleMobileBack = () => {
    if (currentDocCode) {
      setCurrentDocCode(null);
    } else if (items.length > 1 && items[0].targetModule && activeModule !== items[0].targetModule) {
      setActiveModule(items[0].targetModule);
    } else {
      setActiveModule('dashboard');
    }
  };

  const currentLevelLabel = currentDocCode || moduleLabel;

  return (
    <nav aria-label="Breadcrumb" className="flex items-center min-w-0 max-w-full">
      {/* Mobile view: Back button + current level label */}
      <div className="flex md:hidden items-center gap-1 min-w-0">
        <button
          onClick={handleMobileBack}
          className="p-1 -ml-1 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md shrink-0 transition-colors"
          title={language === 'vi' ? 'Quay lại' : language === 'ja' ? '戻る' : 'Go back'}
          aria-label={language === 'vi' ? 'Quay lại cấp trước' : language === 'ja' ? '前の階層に戻る' : 'Back to previous level'}
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <span className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate max-w-[140px] xs:max-w-[180px]">
          {currentLevelLabel}
        </span>
      </div>

      {/* Desktop view: Full hierarchical breadcrumb */}
      <ol className="hidden md:flex items-center gap-1.5 text-[13px] text-slate-600 dark:text-slate-300 min-w-0">
        {items.map((item, idx) => {
          const isLast = idx === items.length - 1;
          const isDocCode = isLast && !!currentDocCode;

          return (
            <li key={idx} className="flex items-center gap-1.5 min-w-0">
              {idx > 0 && (
                <ChevronRight className="w-4 h-4 text-slate-400 dark:text-slate-500 shrink-0" />
              )}
              {isLast ? (
                <span
                  className={`truncate max-w-[240px] font-bold ${
                    isDocCode
                      ? 'text-[#002659] dark:text-sky-400 bg-sky-50 dark:bg-sky-950/70 border border-sky-200 dark:border-sky-800/80 px-2 py-0.5 rounded font-mono text-[12px]'
                      : 'text-slate-900 dark:text-white'
                  }`}
                  title={item.label}
                >
                  {item.label}
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => handleItemClick(idx)}
                  className="font-medium hover:font-semibold hover:text-[#002659] dark:hover:text-sky-300 hover:underline transition-colors truncate max-w-[160px] cursor-pointer"
                  title={`Đi đến ${item.label}`}
                >
                  {item.label}
                </button>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
};
