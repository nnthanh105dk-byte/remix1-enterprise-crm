import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSettings } from '../../context/SettingsContext';
import { AppParameterItem, DocumentApprovalRule, ApprovalDelegation } from '../../types/settings';
import {
  Sliders,
  RotateCcw,
  Save,
  CheckCircle2,
  Check,
  X,
  Plus,
  Trash2,
  ShieldCheck,
  Calendar,
  AlertCircle,
  Clock,
  ArrowRight,
} from 'lucide-react';

export const SettingsAppConfigView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const {
    appParameters,
    updateAppParameter,
    resetAppParameterToDefault,
    approvalRules,
    updateApprovalRule,
    toggleApprovalRule,
    approvalDelegations,
    addApprovalDelegation,
    revokeApprovalDelegation,
    canAccessSettings,
  } = useSettings();

  const [activeTab, setActiveTab] = useState<'general' | 'sales' | 'inventory' | 'logistics' | 'technical' | 'hr' | 'approval_rules'>('sales');

  // Delegation Modal
  const [isDelegationModalOpen, setIsDelegationModalOpen] = useState(false);
  const [delegator, setDelegator] = useState('Trần Minh Đức (Tổng Giám Đốc)');
  const [delegatee, setDelegatee] = useState('Lê Hoàng Yến (Trưởng Khối Kinh Doanh)');
  const [delFromDate, setDelFromDate] = useState('2026-10-15');
  const [delToDate, setDelToDate] = useState('2026-10-25');
  const [delReason, setDelReason] = useState('Nghỉ phép và đi công tác');

  const currentTabParams = (appParameters || []).filter((p) => {
    if (activeTab === 'general') return p.tabGroup === 'general';
    if (activeTab === 'sales') return p.tabGroup === 'sales';
    if (activeTab === 'inventory') return p.tabGroup === 'inventory';
    if (activeTab === 'logistics') return p.tabGroup === 'logistics';
    if (activeTab === 'technical') return p.tabGroup === 'technical';
    if (activeTab === 'hr') return p.tabGroup === 'hr';
    return false;
  });

  const handleAddDelegation = (e: React.FormEvent) => {
    e.preventDefault();
    addApprovalDelegation({
      delegatorName: delegator,
      delegateeName: delegatee,
      fromDate: delFromDate,
      toDate: delToDate,
      docTypes: ['Báo giá', 'Đơn hàng', 'Đề nghị thanh toán'],
      reason: delReason,
    });
    setIsDelegationModalOpen(false);
  };

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
            <Sliders className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              Cấu Hình Nghiệp Vụ &amp; Quy Tắc Duyệt
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Thiết lập ngưỡng SLA, chính sách xuất nhập kho, thời hạn cảnh báo và ma trận phê duyệt đa cấp xuyên suốt các module.
            </p>
          </div>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 text-xs overflow-x-auto pb-0.5">
        {[
          { id: 'sales', label: 'Quản lý Sales' },
          { id: 'inventory', label: 'Quản lý kho' },
          { id: 'logistics', label: 'Vận chuyển' },
          { id: 'technical', label: 'Kỹ thuật' },
          { id: 'hr', label: 'Quản lý nhân sự' },
          { id: 'approval_rules', label: 'Quy tắc duyệt (Ma trận)' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-3.5 py-2 font-bold border-b-2 whitespace-nowrap ${
              activeTab === tab.id
                ? 'border-amber-600 text-amber-600 dark:text-amber-400 bg-amber-50/50 dark:bg-amber-950/20'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* PARAMETERS TABLE */}
      {activeTab !== 'approval_rules' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex items-center justify-between pb-2 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Bảng Thông Số Cấu Hình ({currentTabParams.length} Thông số)
              </h3>
              <p className="text-[11px] text-slate-400">
                Mọi thay đổi thông số đều được các module đọc lại tức thời và ghi vết trong Nhật ký hệ thống.
              </p>
            </div>
            {activeTab === 'hr' && (
              <button
                type="button"
                onClick={() => setActiveModule('hr-insurance')}
                className="px-3 py-1.5 rounded-xl border border-indigo-200 text-indigo-600 font-semibold hover:bg-indigo-50 flex items-center gap-1"
              >
                <span>Xem Cấu hình BHXH (Mức lương tối thiểu vùng &amp; trần)</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="border rounded-xl overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 font-semibold border-b">
                <tr>
                  <th className="px-3 py-2.5 min-w-[220px]">Tên thông số &amp; Mô tả</th>
                  <th className="px-3 py-2.5 min-w-[160px]">Giá trị thiết lập</th>
                  <th className="px-3 py-2.5">Đơn vị</th>
                  <th className="px-3 py-2.5">Mặc định</th>
                  <th className="px-3 py-2.5">Cập nhật gần nhất</th>
                  <th className="px-3 py-2.5 text-right">Thao tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {currentTabParams.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="px-4 py-8 text-center text-slate-400">
                      Không có thông số nào trong nhóm này.
                    </td>
                  </tr>
                ) : (
                  currentTabParams.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50/50">
                      <td className="px-3 py-2.5">
                        <span className="font-bold text-slate-900 dark:text-white block">{p.name}</span>
                        <span className="text-[11px] text-slate-400 block">{p.description}</span>
                        <span className="text-[10px] text-slate-400 font-mono block mt-0.5">Key: {p.key}</span>
                      </td>

                      <td className="px-3 py-2.5">
                        {p.valueType === 'boolean' ? (
                          <label className="flex items-center gap-2 cursor-pointer font-semibold">
                            <input
                              type="checkbox"
                              checked={Boolean(p.value)}
                              onChange={(e) => updateAppParameter(p.id, e.target.checked)}
                              className="rounded text-amber-600"
                            />
                            <span>{p.value ? 'Bật (Cho phép)' : 'Tắt (Chặn)'}</span>
                          </label>
                        ) : p.valueType === 'number' ? (
                          <input
                            type="number"
                            defaultValue={p.value}
                            onBlur={(e) => updateAppParameter(p.id, Number(e.target.value))}
                            className="px-2.5 py-1.5 rounded-lg border bg-white dark:bg-slate-800 font-bold w-28 text-slate-900 dark:text-white"
                          />
                        ) : (
                          <input
                            type="text"
                            defaultValue={p.value}
                            onBlur={(e) => updateAppParameter(p.id, e.target.value)}
                            className="px-2.5 py-1.5 rounded-lg border bg-white dark:bg-slate-800 font-semibold w-40 text-slate-900 dark:text-white"
                          />
                        )}
                      </td>

                      <td className="px-3 py-2.5 font-medium text-slate-600">{p.unit || '—'}</td>

                      <td className="px-3 py-2.5 font-mono text-slate-400">
                        {String(p.defaultValue)}
                      </td>

                      <td className="px-3 py-2.5 text-[11px] text-slate-500">
                        {p.updatedBy} &bull; {p.updatedAt}
                      </td>

                      <td className="px-3 py-2.5 text-right">
                        <button
                          type="button"
                          onClick={() => resetAppParameterToDefault(p.id)}
                          className="px-2.5 py-1 rounded-lg border border-slate-300 hover:bg-slate-100 text-slate-600 flex items-center gap-1 ml-auto"
                          title="Khôi phục giá trị mặc định của hệ thống"
                        >
                          <RotateCcw className="w-3 h-3 text-amber-600" />
                          <span>Khôi phục</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB QUY TẮC DUYỆT (APPROVAL RULES) */}
      {activeTab === 'approval_rules' && (
        <div className="space-y-5 text-xs">
          {/* Rules Table */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b">
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  Ma Trận Phê Duyệt Đa Cấp Toàn Hệ Thống ({(approvalRules || []).length} Quy tắc)
                </h3>
                <p className="text-[11px] text-slate-400">
                  Áp dụng cho Báo giá, Đơn mua hàng, Đề nghị thanh toán, Xuất kho hủy. Ô cấp duyệt để trống nghĩa là bỏ qua cấp đó.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setIsDelegationModalOpen(true)}
                className="px-3 py-1.5 rounded-xl border border-amber-300 text-amber-700 bg-amber-50 hover:bg-amber-100 font-semibold flex items-center gap-1.5"
              >
                <Clock className="w-3.5 h-3.5" />
                <span>Ủy quyền duyệt tạm thời</span>
              </button>
            </div>

            <div className="border rounded-xl overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 font-semibold border-b">
                  <tr>
                    <th className="px-3 py-2.5">Loại chứng từ</th>
                    <th className="px-3 py-2.5">Điều kiện kích hoạt duyệt</th>
                    <th className="px-3 py-2.5">Cấp 1</th>
                    <th className="px-3 py-2.5">Cấp 2</th>
                    <th className="px-3 py-2.5">Cấp 3</th>
                    <th className="px-3 py-2.5 text-center">Bật/Tắt</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {(approvalRules || []).map((rule) => (
                    <tr key={rule.id} className="hover:bg-slate-50/50">
                      <td className="px-3 py-2.5 font-bold text-slate-900 dark:text-white">
                        {rule.docTypeName}
                      </td>
                      <td className="px-3 py-2.5 font-medium text-amber-700 dark:text-amber-300">
                        {rule.conditionDescription}
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-semibold block text-[11px]">
                          {rule.tier1Approver?.approverTarget || '—'}
                        </span>
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-semibold block text-[11px]">
                          {rule.tier2Approver?.approverTarget || '—'}
                        </span>
                      </td>
                      <td className="px-3 py-2.5">
                        <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-semibold block text-[11px]">
                          {rule.tier3Approver?.approverTarget || '—'}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        <input
                          type="checkbox"
                          checked={rule.isEnabled}
                          onChange={() => toggleApprovalRule(rule.id)}
                          className="rounded text-amber-600 w-4 h-4 cursor-pointer"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Delegations List */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <span className="font-bold text-sm text-slate-900 dark:text-white block">
              Danh Sách Ủy Quyền Duyệt Tạm Thời Đang Hiệu Lực
            </span>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 border rounded-xl">
              {(approvalDelegations || []).map((del) => (
                <div key={del.id} className="p-3 flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 dark:text-white">{del.delegatorName}</span>
                      <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                      <span className="font-bold text-amber-600">{del.delegateeName}</span>
                      <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-700 font-bold">
                        Đang hiệu lực
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      Hiệu lực: {del.fromDate} &rarr; {del.toDate} &bull; Lý do: {del.reason}
                    </span>
                  </div>

                  <button
                    onClick={() => revokeApprovalDelegation(del.id)}
                    className="px-2.5 py-1 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg text-xs font-semibold"
                  >
                    Hủy ủy quyền
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modal Thêm Ủy Quyền Duyệt */}
      {isDelegationModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 border shadow-xl space-y-4 text-xs">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Thiết Lập Ủy Quyền Duyệt Tạm Thời</h3>
            <form onSubmit={handleAddDelegation} className="space-y-3">
              <div>
                <label className="font-semibold block mb-1">Người ủy quyền</label>
                <input type="text" readOnly value={delegator} className="w-full px-3 py-2 rounded-xl border bg-slate-50 font-semibold" />
              </div>
              <div>
                <label className="font-semibold block mb-1">Người được ủy quyền duyệt thay *</label>
                <input
                  type="text"
                  value={delegatee}
                  onChange={(e) => setDelegatee(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800 font-semibold"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-semibold block mb-1">Từ ngày</label>
                  <input type="date" value={delFromDate} onChange={(e) => setDelFromDate(e.target.value)} className="w-full px-3 py-1.5 rounded-xl border" />
                </div>
                <div>
                  <label className="font-semibold block mb-1">Đến ngày</label>
                  <input type="date" value={delToDate} onChange={(e) => setDelToDate(e.target.value)} className="w-full px-3 py-1.5 rounded-xl border" />
                </div>
              </div>
              <div>
                <label className="font-semibold block mb-1">Lý do ủy quyền</label>
                <input
                  type="text"
                  value={delReason}
                  onChange={(e) => setDelReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsDelegationModalOpen(false)} className="px-3 py-1.5 border rounded-xl">Hủy</button>
                <button type="submit" className="px-4 py-2 bg-amber-600 text-white font-bold rounded-xl">Xác nhận ủy quyền</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
