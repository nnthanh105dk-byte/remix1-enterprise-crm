import React, { useState, useMemo, useEffect } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useHR } from '../../context/HRContext';
import { ProfileTab, ThemeMode, AccentColor, FontSizePreference, TableDensityPreference, ActiveModule, ThemePreset } from '../../types/crm';
import { THEME_PRESETS } from '../../theme/themeEngine';
import {
  User,
  ShieldCheck,
  Palette,
  BellRing,
  History,
  Building2,
  Mail,
  Phone,
  Calendar,
  Lock,
  Smartphone,
  Laptop,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Check,
  X,
  Upload,
  Eye,
  EyeOff,
  Clock,
  Filter,
  ExternalLink,
  ChevronRight,
  Shield,
  KeyRound,
  FileText,
  Sun,
  Moon,
} from 'lucide-react';

export const MyProfileView: React.FC = () => {
  const {
    currentUser,
    currentTenant,
    profileActiveTab,
    setProfileActiveTab,
    theme,
    setTheme,
    themeMode,
    setThemeMode,
    userPreferences,
    updateUserPreferences,
    updateCurrentUser,
    auditLogs,
    setActiveModule,
    setCurrentDocCode,
    showToast,
  } = useCRM();

  const { employees, updateEmployee, createProfileUpdateRequest } = useHR();

  // Find linked Employee record (matching by email, fullName, or ID)
  const linkedEmployee = useMemo(() => {
    return (
      employees.find((e) => e.email === currentUser.email) ||
      employees.find((e) => e.fullName === currentUser.fullName) ||
      employees[0]
    );
  }, [employees, currentUser]);

  // Tab A: Editable self-service personal fields
  const [personalForm, setPersonalForm] = useState({
    displayName: currentUser.fullName,
    gender: linkedEmployee?.gender || 'Nam',
    phone: currentUser.phone || linkedEmployee?.phone || '',
    internalPhone: '102',
    contactEmail: currentUser.email,
    currentAddress: linkedEmployee?.currentAddress || 'Hà Nội, Việt Nam',
    emergencyName: linkedEmployee?.emergencyContact?.name || 'Nguyễn Mai Phương',
    emergencyRelationship: linkedEmployee?.emergencyContact?.relationship || 'Người thân',
    emergencyPhone: linkedEmployee?.emergencyContact?.phone || '0912 999 888',
    avatarUrl: currentUser.avatar,
    textSignature: `Trân trọng,\n${currentUser.fullName}\n${currentTenant.name}\nSĐT: ${currentUser.phone}`,
  });

  // Modal: HR Approval Request for sensitive fields
  const [isHrRequestModalOpen, setIsHrRequestModalOpen] = useState(false);
  const [hrRequestForm, setHrRequestForm] = useState({
    legalName: linkedEmployee?.fullName || '',
    dob: linkedEmployee?.dob || '1985-05-15',
    idCardNumber: linkedEmployee?.idCardNumber || '',
    personalTaxCode: linkedEmployee?.personalTaxCode || '',
    bankName: linkedEmployee?.bankAccount?.bankName || 'Vietcombank',
    accountNumber: linkedEmployee?.bankAccount?.accountNumber || '',
    accountHolder: linkedEmployee?.bankAccount?.accountHolder || '',
    reason: '',
  });

  // Sync form when active user profile changes
  useEffect(() => {
    setPersonalForm({
      displayName: currentUser.fullName,
      gender: linkedEmployee?.gender || 'Nam',
      phone: currentUser.phone || linkedEmployee?.phone || '',
      internalPhone: '102',
      contactEmail: currentUser.email,
      currentAddress: linkedEmployee?.currentAddress || 'Hà Nội, Việt Nam',
      emergencyName: linkedEmployee?.emergencyContact?.name || 'Người thân',
      emergencyRelationship: linkedEmployee?.emergencyContact?.relationship || 'Người thân',
      emergencyPhone: linkedEmployee?.emergencyContact?.phone || '0912 999 888',
      avatarUrl: currentUser.avatar,
      textSignature: `Trân trọng,\n${currentUser.fullName}\n${currentTenant.name}\nSĐT: ${currentUser.phone}`,
    });
    setHrRequestForm({
      legalName: linkedEmployee?.fullName || currentUser.fullName,
      dob: linkedEmployee?.dob || '1985-05-15',
      idCardNumber: linkedEmployee?.idCardNumber || '',
      personalTaxCode: linkedEmployee?.personalTaxCode || '',
      bankName: linkedEmployee?.bankAccount?.bankName || 'Vietcombank',
      accountNumber: linkedEmployee?.bankAccount?.accountNumber || '',
      accountHolder: linkedEmployee?.bankAccount?.accountHolder || currentUser.fullName,
      reason: '',
    });
  }, [currentUser, linkedEmployee, currentTenant]);

  // Tab B: Password change form
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });
  const [showPassword, setShowPassword] = useState(false);

  // Active Sessions
  const [sessions, setSessions] = useState([
    {
      id: 'sess-1',
      device: 'Windows 11 • Google Chrome 129',
      location: 'Hà Nội, Việt Nam (118.70.192.44)',
      time: 'Đang hoạt động (Phiên này)',
      isCurrent: true,
    },
    {
      id: 'sess-2',
      device: 'macOS Sonoma • Safari 17.5',
      location: 'TP. Hồ Chí Minh (14.161.22.10)',
      time: 'Hoạt động 3 giờ trước',
      isCurrent: false,
    },
    {
      id: 'sess-3',
      device: 'iPhone 15 Pro • Safari Mobile',
      location: 'Hà Nội, Việt Nam (27.72.63.18)',
      time: 'Hoạt động hôm qua',
      isCurrent: false,
    },
  ]);

  // Tab E: Filter for Activity History
  const [activityDays, setActivityDays] = useState<'7' | '30' | '90'>('30');
  const [activityModuleFilter, setActivityModuleFilter] = useState('all');

  // Password Strength Calculator
  const passwordStrength = useMemo(() => {
    const p = passwordForm.newPassword;
    if (!p) return { score: 0, label: 'Chưa nhập', color: 'bg-slate-200' };
    let s = 0;
    if (p.length >= 8) s += 1;
    if (p.length >= 12) s += 1;
    if (/[A-Z]/.test(p)) s += 1;
    if (/[0-9]/.test(p)) s += 1;
    if (/[^A-Za-z0-9]/.test(p)) s += 1;

    if (s <= 2) return { score: 1, label: 'Yếu', color: 'bg-rose-500', text: 'text-rose-500' };
    if (s <= 3) return { score: 2, label: 'Trung bình', color: 'bg-amber-500', text: 'text-amber-500' };
    if (s <= 4) return { score: 3, label: 'Mạnh', color: 'bg-emerald-500', text: 'text-emerald-500' };
    return { score: 4, label: 'Rất mạnh', color: 'bg-sky-500', text: 'text-sky-500' };
  }, [passwordForm.newPassword]);

  // Mask sensitive string: show last 4 chars
  const maskString = (val?: string, visibleChars = 4) => {
    if (!val) return '—';
    const str = String(val);
    if (str.length <= visibleChars) return str;
    return '•'.repeat(Math.min(8, str.length - visibleChars)) + str.slice(-visibleChars);
  };

  // Handle Save Personal Info
  const handleSavePersonalInfo = (e: React.FormEvent) => {
    e.preventDefault();
    // 1. Update CRM current user
    updateCurrentUser({
      fullName: personalForm.displayName,
      phone: personalForm.phone,
      avatar: personalForm.avatarUrl,
    });

    // 2. Update linked Employee in HRContext
    if (linkedEmployee) {
      updateEmployee(linkedEmployee.id, {
        fullName: personalForm.displayName,
        phone: personalForm.phone,
        currentAddress: personalForm.currentAddress,
        avatar: personalForm.avatarUrl,
        emergencyContact: {
          name: personalForm.emergencyName,
          relationship: personalForm.emergencyRelationship,
          phone: personalForm.emergencyPhone,
        },
      });
    }

    showToast('Cập nhật thành công', 'Thông tin cá nhân của bạn đã được lưu đồng bộ.');
  };

  // Handle Submit HR Change Request
  const handleSubmitHrRequest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!linkedEmployee) return;

    const changes: { field: string; label: string; oldValue: any; newValue: any }[] = [];

    if (hrRequestForm.legalName !== linkedEmployee.fullName) {
      changes.push({ field: 'fullName', label: 'Họ tên pháp lý', oldValue: linkedEmployee.fullName, newValue: hrRequestForm.legalName });
    }
    if (hrRequestForm.dob !== linkedEmployee.dob) {
      changes.push({ field: 'dob', label: 'Ngày sinh', oldValue: linkedEmployee.dob, newValue: hrRequestForm.dob });
    }
    if (hrRequestForm.idCardNumber !== linkedEmployee.idCardNumber) {
      changes.push({ field: 'idCardNumber', label: 'Số CCCD', oldValue: linkedEmployee.idCardNumber, newValue: hrRequestForm.idCardNumber });
    }
    if (hrRequestForm.personalTaxCode !== linkedEmployee.personalTaxCode) {
      changes.push({ field: 'personalTaxCode', label: 'Mã số thuế cá nhân', oldValue: linkedEmployee.personalTaxCode, newValue: hrRequestForm.personalTaxCode });
    }
    if (hrRequestForm.accountNumber !== linkedEmployee.bankAccount?.accountNumber) {
      changes.push({
        field: 'bankAccount',
        label: 'Tài khoản ngân hàng',
        oldValue: linkedEmployee.bankAccount,
        newValue: {
          bankName: hrRequestForm.bankName,
          accountNumber: hrRequestForm.accountNumber,
          accountHolder: hrRequestForm.accountHolder,
        },
      });
    }

    if (changes.length === 0) {
      showToast('Thông báo', 'Bạn chưa thay đổi trường dữ liệu pháp lý nào.', 'warning');
      return;
    }

    createProfileUpdateRequest(linkedEmployee.id, changes);
    setIsHrRequestModalOpen(false);
    showToast('Đã gửi yêu cầu', 'Yêu cầu cập nhật thông tin pháp lý đã được chuyển sang phòng Nhân sự duyệt.');
  };

  // Handle Password Update
  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!passwordForm.currentPassword) {
      showToast('Lỗi', 'Vui lòng nhập mật khẩu hiện tại.', 'error');
      return;
    }
    if (passwordForm.newPassword.length < 8) {
      showToast('Lỗi', 'Mật khẩu mới phải có tối thiểu 8 ký tự.', 'error');
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      showToast('Lỗi', 'Mật khẩu xác nhận không khớp.', 'error');
      return;
    }

    setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    showToast('Thành công', 'Mật khẩu đăng nhập của bạn đã được đổi thành công.');
  };

  // Filter My Activity Logs (90 days, matching current user)
  const myActivities = useMemo(() => {
    const daysLimit = parseInt(activityDays, 10);
    const limitTime = Date.now() - daysLimit * 24 * 60 * 60 * 1000;

    return auditLogs.filter((log) => {
      // Filter by current user
      if (log.userName !== currentUser.fullName && log.userName !== 'Nguyễn Khắc Huy') return false;
      // Filter by days
      const logTime = new Date(log.timestamp.replace(' ', 'T')).getTime();
      if (!isNaN(logTime) && logTime < limitTime) return false;
      // Filter by module if selected
      if (activityModuleFilter !== 'all' && log.entity.toLowerCase() !== activityModuleFilter.toLowerCase()) {
        return false;
      }
      return true;
    });
  }, [auditLogs, currentUser.fullName, activityDays, activityModuleFilter]);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner & Profile Overview */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative">
              <img
                src={currentUser.avatar}
                alt={currentUser.fullName}
                className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover border-2 border-white dark:border-slate-800 shadow-md"
              />
              <span className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-white dark:border-slate-900" title="Trạng thái: Đang hoạt động" />
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-slate-100">
                  {currentUser.fullName}
                </h1>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-sky-100 dark:bg-sky-950 text-[#002659] dark:text-sky-300">
                  {currentUser.role}
                </span>
                <span className="text-xs font-mono px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                  {linkedEmployee?.code || 'NV-0001'}
                </span>
              </div>

              <div className="flex items-center gap-4 text-xs text-slate-500 dark:text-slate-400 mt-1.5 flex-wrap">
                <span className="flex items-center gap-1">
                  <Building2 className="w-3.5 h-3.5 text-[#002659] dark:text-sky-400" />
                  {currentTenant.name} ({currentTenant.code})
                </span>
                <span className="flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5" />
                  {currentUser.email}
                </span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5" />
                  {currentUser.phone}
                </span>
              </div>
            </div>
          </div>

          <div className="text-left sm:text-right text-xs text-slate-500 dark:text-slate-400 shrink-0">
            <div>Đăng nhập gần nhất: <span className="font-semibold text-slate-800 dark:text-slate-200">{currentUser.lastLogin}</span></div>
            <div className="mt-0.5">Ngày tham gia: <span className="font-semibold text-slate-800 dark:text-slate-200">{currentUser.createdAt}</span></div>
          </div>
        </div>

        {/* 5 Tabs Navigation Bar */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 mt-6 -mb-5 sm:-mb-6 overflow-x-auto no-scrollbar gap-1 sm:gap-2">
          {[
            { id: 'personal', label: 'A. Thông tin cá nhân', icon: User },
            { id: 'security', label: 'B. Bảo mật', icon: ShieldCheck },
            { id: 'appearance', label: 'C. Giao diện & hiển thị', icon: Palette },
            { id: 'notifications', label: 'D. Tùy chọn thông báo', icon: BellRing },
            { id: 'activity', label: 'E. Lịch sử thao tác', icon: History },
          ].map((t) => {
            const IconC = t.icon;
            const isActive = profileActiveTab === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setProfileActiveTab(t.id as ProfileTab)}
                className={`flex items-center gap-2 py-3 px-3 sm:px-4 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors cursor-pointer ${
                  isActive
                    ? 'border-[#002659] dark:border-sky-500 text-[#002659] dark:text-sky-400 bg-sky-50/40 dark:bg-sky-950/20'
                    : 'border-transparent text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-200 hover:border-slate-300'
                }`}
              >
                <IconC className="w-4 h-4" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Tab Contents */}
      {/* =========================================================================
          TAB A: THÔNG TIN CÁ NHÂN
          ========================================================================= */}
      {profileActiveTab === 'personal' && (
        <div className="space-y-6">
          <form onSubmit={handleSavePersonalInfo} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left: Thông tin chỉ đọc (Do Quản trị / Nhân sự quản lý) */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-amber-500" />
                  Chỉ đọc (Nhân sự &amp; Admin)
                </h3>
                <span className="text-[10px] font-bold bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 border border-amber-200 dark:border-amber-800 px-2 py-0.5 rounded">
                  Khóa chỉnh sửa
                </span>
              </div>

              {/* Thông báo chính sách khóa quyền ID & Email */}
              <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                <div className="flex items-start gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-[#002659] dark:text-sky-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Mã nhân viên (ID)</strong> và <strong>Email đăng nhập</strong> được bảo vệ cấp hệ thống. Chỉ Quản trị viên (Admin) hoặc nhân sự được phân quyền mới có thể chỉnh sửa.
                  </span>
                </div>
              </div>

              <div className="space-y-3.5 text-xs">
                <div className="p-2.5 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/40 dark:bg-rose-950/20">
                  <div className="flex items-center justify-between">
                    <label className="text-slate-500 text-[11px] font-semibold flex items-center gap-1">
                      <Lock className="w-3 h-3 text-rose-500" /> Mã nhân viên (ID)
                    </label>
                    <span className="text-[9px] font-bold text-rose-600 bg-rose-100 dark:bg-rose-900/80 px-1.5 py-0.2 rounded">Khóa</span>
                  </div>
                  <div className="font-mono font-bold text-sm text-slate-900 dark:text-slate-100 mt-1">{linkedEmployee?.code || 'NV-0001'}</div>
                  <span className="text-[10px] text-slate-400">Định danh nhân sự cố định</span>
                </div>

                <div className="p-2.5 rounded-xl border border-rose-200 dark:border-rose-900/60 bg-rose-50/40 dark:bg-rose-950/20">
                  <div className="flex items-center justify-between">
                    <label className="text-slate-500 text-[11px] font-semibold flex items-center gap-1">
                      <Lock className="w-3 h-3 text-rose-500" /> Email đăng nhập chính
                    </label>
                    <span className="text-[9px] font-bold text-rose-600 bg-rose-100 dark:bg-rose-900/80 px-1.5 py-0.2 rounded">Khóa</span>
                  </div>
                  <div className="font-semibold text-slate-900 dark:text-slate-100 mt-1">{currentUser.email}</div>
                  <span className="text-[10px] text-slate-400">Tài khoản xác thực hệ thống</span>
                </div>

                <div>
                  <label className="text-slate-400 text-[11px]">Tên đăng nhập</label>
                  <div className="font-mono font-medium text-slate-800 dark:text-slate-200 mt-0.5">{currentUser.email.split('@')[0]}</div>
                </div>
                <div>
                  <label className="text-slate-400 text-[11px]">Doanh nghiệp (Công ty)</label>
                  <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5">{currentTenant.name} ({currentTenant.code})</div>
                </div>
                <div>
                  <label className="text-slate-400 text-[11px]">Phòng ban / Nhóm</label>
                  <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5">{linkedEmployee?.departmentName || currentUser.department}</div>
                </div>
                <div>
                  <label className="text-slate-400 text-[11px]">Chức vụ</label>
                  <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5">{linkedEmployee?.positionName || 'Lãnh đạo bộ phận'}</div>
                </div>
                <div>
                  <label className="text-slate-400 text-[11px]">Quản lý trực tiếp</label>
                  <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5">{linkedEmployee?.directManagerName || 'Hội Đồng Quản Trị'}</div>
                </div>
                <div>
                  <label className="text-slate-400 text-[11px]">Nhóm quyền hệ thống</label>
                  <div className="font-semibold text-[#002659] dark:text-sky-400 mt-0.5">{currentUser.role}</div>
                </div>
                <div>
                  <label className="text-slate-400 text-[11px]">Ngày tham gia hệ thống</label>
                  <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5">{linkedEmployee?.joinDate || currentUser.createdAt}</div>
                </div>
              </div>
            </div>

            {/* Middle & Right: Tự sửa & Cần HR duyệt */}
            <div className="lg:col-span-2 space-y-6">
              {/* Box 1: Tự sửa */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
                <div className="pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                    Thông tin tự chỉnh sửa
                  </h3>
                  <span className="text-[11px] text-slate-400">Lưu ngay vào hồ sơ</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Tên hiển thị (Tự đặt)</label>
                    <input
                      type="text"
                      value={personalForm.displayName}
                      onChange={(e) => setPersonalForm({ ...personalForm, displayName: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Giới tính</label>
                    <select
                      value={personalForm.gender}
                      onChange={(e) => setPersonalForm({ ...personalForm, gender: e.target.value as any })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    >
                      <option value="Nam">Nam</option>
                      <option value="Nữ">Nữ</option>
                      <option value="Khác">Khác</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">SĐT di động</label>
                    <input
                      type="text"
                      value={personalForm.phone}
                      onChange={(e) => setPersonalForm({ ...personalForm, phone: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">SĐT nội bộ / Máy lẻ</label>
                    <input
                      type="text"
                      value={personalForm.internalPhone}
                      onChange={(e) => setPersonalForm({ ...personalForm, internalPhone: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">
                      Email liên hệ phụ (Không dùng đăng nhập)
                    </label>
                    <input
                      type="email"
                      value={personalForm.contactEmail}
                      onChange={(e) => setPersonalForm({ ...personalForm, contactEmail: e.target.value })}
                      placeholder="email.phu@gmail.com"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Địa chỉ liên hệ (Tạm trú)</label>
                    <input
                      type="text"
                      value={personalForm.currentAddress}
                      onChange={(e) => setPersonalForm({ ...personalForm, currentAddress: e.target.value })}
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                    />
                  </div>

                  {/* Ảnh đại diện cá nhân (Avatar Customization) */}
                  <div className="sm:col-span-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                    <label className="block text-slate-700 dark:text-slate-200 font-bold mb-1">
                      Ảnh đại diện cá nhân (Avatar)
                    </label>
                    <p className="text-[11px] text-slate-400 mb-2">
                      Mỗi nhân sự tự do tùy biến ảnh đại diện của mình (nhập đường dẫn URL ảnh hoặc chọn avatar mẫu bên dưới):
                    </p>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full border-2 border-slate-300 dark:border-slate-600 overflow-hidden shrink-0 shadow-2xs">
                        <img
                          src={personalForm.avatarUrl || currentUser.avatar}
                          alt="Avatar preview"
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <input
                        type="text"
                        value={personalForm.avatarUrl}
                        onChange={(e) => setPersonalForm({ ...personalForm, avatarUrl: e.target.value })}
                        placeholder="https://images.unsplash.com/photo-..."
                        className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs font-mono"
                      />
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-[11px] text-slate-400">Chọn mẫu nhanh:</span>
                      {[
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
                        'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
                        'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80',
                        'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
                        'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&auto=format&fit=crop&q=80',
                      ].map((av, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setPersonalForm({ ...personalForm, avatarUrl: av })}
                          className={`w-7 h-7 rounded-full overflow-hidden border-2 cursor-pointer transition-transform hover:scale-110 ${
                            personalForm.avatarUrl === av ? 'border-[#002659] ring-2 ring-blue-400' : 'border-slate-300'
                          }`}
                        >
                          <img src={av} alt="Preset" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Liên hệ khẩn cấp */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                  <h4 className="text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">Liên hệ khẩn cấp</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                    <div>
                      <label className="text-[11px] text-slate-400">Họ và tên</label>
                      <input
                        type="text"
                        value={personalForm.emergencyName}
                        onChange={(e) => setPersonalForm({ ...personalForm, emergencyName: e.target.value })}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-slate-400">Quan hệ</label>
                      <input
                        type="text"
                        value={personalForm.emergencyRelationship}
                        onChange={(e) => setPersonalForm({ ...personalForm, emergencyRelationship: e.target.value })}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] text-slate-400">Số điện thoại</label>
                      <input
                        type="text"
                        value={personalForm.emergencyPhone}
                        onChange={(e) => setPersonalForm({ ...personalForm, emergencyPhone: e.target.value })}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                      />
                    </div>
                  </div>
                </div>

                {/* Chữ ký văn bản */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800">
                  <label className="block text-slate-600 dark:text-slate-300 font-medium text-xs mb-1">
                    Chữ ký văn bản (Chèn cuối email / báo giá)
                  </label>
                  <textarea
                    rows={3}
                    value={personalForm.textSignature}
                    onChange={(e) => setPersonalForm({ ...personalForm, textSignature: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs font-mono"
                  />
                </div>

                <div className="text-right pt-2">
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-[#002659] hover:bg-[#001a3d] dark:bg-sky-600 dark:hover:bg-sky-500 text-white font-semibold text-xs transition-colors cursor-pointer"
                  >
                    Lưu thông tin cá nhân
                  </button>
                </div>
              </div>

              {/* Box 2: Thông tin pháp lý & Ngân hàng (Cần HR duyệt) */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
                <div className="pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                      Thông tin pháp lý & Ngân hàng nhận lương
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Các trường nhạy cảm được che bớt; cần Nhân sự duyệt qua quy trình "Yêu cầu cập nhật".
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsHrRequestModalOpen(true)}
                    className="px-3 py-1.5 rounded-lg border border-[#002659] text-[#002659] dark:border-sky-500 dark:text-sky-400 hover:bg-[#002659]/5 text-xs font-semibold cursor-pointer shrink-0"
                  >
                    Gửi yêu cầu cập nhật
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 text-[11px]">Họ tên pháp lý</span>
                    <div className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{linkedEmployee?.fullName || currentUser.fullName}</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 text-[11px]">Ngày sinh</span>
                    <div className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{linkedEmployee?.dob || '15/05/1985'}</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 text-[11px]">Số CCCD / Hộ chiếu (Bảo mật)</span>
                    <div className="font-mono font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{maskString(linkedEmployee?.idCardNumber || '001082004567')}</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 text-[11px]">Mã số thuế cá nhân</span>
                    <div className="font-mono font-semibold text-slate-800 dark:text-slate-200 mt-0.5">{maskString(linkedEmployee?.personalTaxCode || '8023456789')}</div>
                  </div>
                  <div className="sm:col-span-2 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 text-[11px]">Tài khoản ngân hàng nhận lương</span>
                    <div className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5">
                      {linkedEmployee?.bankAccount?.bankName || 'Vietcombank'} • {maskString(linkedEmployee?.bankAccount?.accountNumber || '0011001234567')} ({linkedEmployee?.bankAccount?.accountHolder || currentUser.fullName})
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* =========================================================================
          TAB B: BẢO MẬT TÀI KHOẢN
          ========================================================================= */}
      {profileActiveTab === 'security' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 1. Đổi mật khẩu */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
            <div className="pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-[#002659] dark:text-sky-400" />
                <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                  Đổi mật khẩu tài khoản
                </h3>
              </div>
            </div>

            <form onSubmit={handleUpdatePassword} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Mật khẩu hiện tại</label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={passwordForm.currentPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, currentPassword: e.target.value })}
                  placeholder="Nhập mật khẩu hiện tại"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Mật khẩu mới</label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={passwordForm.newPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, newPassword: e.target.value })}
                  placeholder="Tối thiểu 8 ký tự, bao gồm chữ hoa, số"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />

                {/* Password strength bar */}
                {passwordForm.newPassword && (
                  <div className="mt-2 space-y-1">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Độ mạnh theo chính sách:</span>
                      <span className={`font-semibold ${passwordStrength.text}`}>{passwordStrength.label}</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${passwordStrength.color} transition-all duration-300`}
                        style={{ width: `${(passwordStrength.score / 4) * 100}%` }}
                      />
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Nhập lại mật khẩu mới</label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={passwordForm.confirmPassword}
                  onChange={(e) => setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })}
                  placeholder="Xác nhận mật khẩu mới"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center justify-between pt-1">
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  <span>{showPassword ? 'Ẩn mật khẩu' : 'Hiện mật khẩu'}</span>
                </button>

                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#002659] hover:bg-[#001a3d] dark:bg-sky-600 dark:hover:bg-sky-500 text-white font-semibold transition-colors cursor-pointer"
                >
                  Cập nhật mật khẩu
                </button>
              </div>
            </form>
          </div>

          {/* 2. Thiết bị & Phiên đang đăng nhập */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
            <div className="pb-3 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Laptop className="w-4 h-4 text-[#002659] dark:text-sky-400" />
                <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
                  Phiên & Thiết bị đăng nhập
                </h3>
              </div>

              <button
                type="button"
                onClick={() => {
                  setSessions(sessions.filter((s) => s.isCurrent));
                  showToast('Đăng xuất tất cả', 'Đã hủy phiên trên tất cả các thiết bị khác.');
                }}
                className="text-xs text-rose-600 hover:underline font-semibold cursor-pointer"
              >
                Đăng xuất tất cả thiết bị khác
              </button>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {sessions.map((sess) => (
                <div key={sess.id} className="py-3 flex items-start justify-between gap-3 text-xs">
                  <div className="flex items-start gap-2.5">
                    <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 mt-0.5">
                      {sess.device.includes('iPhone') ? <Smartphone className="w-4 h-4" /> : <Laptop className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                        {sess.device}
                        {sess.isCurrent && (
                          <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.2 rounded">
                            Thiết bị này
                          </span>
                        )}
                      </div>
                      <div className="text-slate-500 text-[11px] mt-0.5">{sess.location}</div>
                      <div className="text-slate-400 text-[10px] mt-0.5">{sess.time}</div>
                    </div>
                  </div>

                  {!sess.isCurrent && (
                    <button
                      type="button"
                      onClick={() => {
                        setSessions(sessions.filter((s) => s.id !== sess.id));
                        showToast('Đã đăng xuất', `Đã kết thúc phiên trên ${sess.device}`);
                      }}
                      className="text-xs text-rose-500 hover:text-rose-700 font-medium hover:underline cursor-pointer"
                    >
                      Đăng xuất
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* 3. Lịch sử đăng nhập gần đây (20 lần gần nhất) */}
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-3">
            <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider flex items-center gap-2">
              <Clock className="w-4 h-4 text-slate-400" />
              Lịch sử đăng nhập gần đây (20 lần gần nhất)
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 text-[11px] font-semibold">
                    <th className="py-2 px-3">Thời gian</th>
                    <th className="py-2 px-3">Địa điểm & IP</th>
                    <th className="py-2 px-3">Trình duyệt / Thiết bị</th>
                    <th className="py-2 px-3">Kết quả</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                  {[
                    { time: '2026-10-06 11:25:33', ip: '118.70.192.44 (Hà Nội)', device: 'Chrome 129 / Windows 11', success: true },
                    { time: '2026-10-06 08:15:10', ip: '118.70.192.44 (Hà Nội)', device: 'Chrome 129 / Windows 11', success: true },
                    { time: '2026-10-05 17:40:22', ip: '14.161.22.10 (TP.HCM)', device: 'Safari 17.5 / macOS', success: true },
                    { time: '2026-10-05 14:10:05', ip: '14.161.22.10 (TP.HCM)', device: 'Safari 17.5 / macOS', success: false, reason: 'Sai mật khẩu' },
                    { time: '2026-10-05 09:00:18', ip: '118.70.192.44 (Hà Nội)', device: 'Chrome 129 / Windows 11', success: true },
                    { time: '2026-10-04 19:35:40', ip: '27.72.63.18 (Hà Nội)', device: 'Safari Mobile / iPhone', success: true },
                    { time: '2026-10-04 08:30:12', ip: '118.70.192.44 (Hà Nội)', device: 'Chrome 129 / Windows 11', success: true },
                  ].map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-mono text-slate-600 dark:text-slate-300">{row.time}</td>
                      <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300">{row.ip}</td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">{row.device}</td>
                      <td className="py-2.5 px-3">
                        {row.success ? (
                          <span className="inline-flex items-center gap-1 font-semibold text-emerald-600 dark:text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Thành công
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 font-semibold text-rose-500">
                            <AlertCircle className="w-3.5 h-3.5" /> Thất bại ({row.reason})
                          </span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB C: GIAO DIỆN & HIỂN THỊ
          ========================================================================= */}
      {profileActiveTab === 'appearance' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
              Tùy biến Giao diện & Hiển thị Toàn hệ thống
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Áp dụng tức thời cho toàn bộ bảng biểu, form nhập liệu, biểu đồ và menu của bạn.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* 1. Chế độ giao diện */}
            <div className="space-y-2">
              <label className="block font-semibold text-slate-800 dark:text-slate-200">
                1. Chế độ giao diện (Toàn bộ ứng dụng)
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { mode: 'light', label: 'Sáng', desc: 'Sáng chuẩn A+ CRM', icon: Sun },
                  { mode: 'dark', label: 'Tối', desc: 'Tối dịu mắt chuyên sâu', icon: Moon },
                  { mode: 'system', label: 'Theo thiết bị', desc: 'Tự động theo hệ điều hành', icon: Laptop },
                ].map((item) => {
                  const IconC = item.icon;
                  const isSel = themeMode === item.mode;
                  return (
                    <button
                      key={item.mode}
                      type="button"
                      onClick={() => {
                        setThemeMode(item.mode as ThemeMode);
                        showToast('Giao diện', `Đã chuyển sang chế độ ${item.label}`);
                      }}
                      className={`p-3 rounded-xl border text-left flex flex-col justify-between transition-all cursor-pointer ${
                        isSel
                          ? 'border-[#002659] bg-[#F0F7FD] dark:bg-sky-950/60 dark:border-sky-500 ring-2 ring-[#002659]/10'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <IconC className={`w-4 h-4 ${isSel ? 'text-[#002659] dark:text-sky-400' : 'text-slate-400'}`} />
                        {isSel && <Check className="w-3.5 h-3.5 text-[#002659] dark:text-sky-400" />}
                      </div>
                      <div className="mt-2 font-bold text-slate-900 dark:text-slate-100">{item.label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{item.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 2. Bộ 10 Tông Màu Pastel Doanh Nghiệp (Soft Pastel Enterprise Canvas) */}
            <div className="md:col-span-2 space-y-2.5 pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
                <div>
                  <label className="block font-bold text-sm text-slate-800 dark:text-slate-100">
                    2. Bộ 10 Tông Màu Pastel Doanh Nghiệp (Soft Pastel Canvas)
                  </label>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Khung nền ngoài chuyển sang màu pastel nhẹ, menu sidebar đồng bộ chi tiết nhấn. Các thẻ bảng biểu giữ nguyên nền trắng chuẩn mực, đảm bảo 100% độ tương phản cao.
                  </p>
                </div>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 w-fit">
                  10 Phong cách
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
                {(Object.keys(THEME_PRESETS) as ThemePreset[]).slice(0, 10).map((presetKey) => {
                  const pItem = THEME_PRESETS[presetKey];
                  const isSel = theme === presetKey;

                  return (
                    <button
                      key={presetKey}
                      type="button"
                      onClick={() => {
                        setTheme(presetKey);
                        showToast('Giao diện Pastel', `Đã kích hoạt ${pItem.nameVi}`);
                      }}
                      className={`group relative p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        isSel
                          ? 'border-slate-900 dark:border-white ring-2 ring-slate-900/15 shadow-sm bg-white dark:bg-slate-800/80'
                          : 'border-slate-200 dark:border-slate-800 hover:border-slate-400 dark:hover:border-slate-700 bg-white dark:bg-slate-800/40'
                      }`}
                    >
                      {/* Pastel background simulation card */}
                      <div
                        className="w-full h-10 rounded-lg p-1.5 flex items-center justify-between mb-2.5 border border-black/5"
                        style={{ backgroundColor: pItem.pastelBgColor }}
                      >
                        <div className="h-full w-2.5 rounded-sm" style={{ backgroundColor: pItem.previewColor }} />
                        <div className="h-full flex-1 ml-1.5 bg-white/90 dark:bg-slate-900/80 rounded-sm shadow-2xs border border-black/5 flex items-center justify-end px-1">
                          {isSel && (
                            <Check className="w-3 h-3 text-slate-800 dark:text-white" />
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <span
                          className="w-3 h-3 rounded-full shrink-0 shadow-2xs border border-white"
                          style={{ backgroundColor: pItem.previewColor }}
                        />
                        <div className="font-bold text-xs text-slate-800 dark:text-slate-200 truncate">
                          {pItem.nameVi.replace(/^\d+\.\s*/, '').split('(')[0].trim()}
                        </div>
                      </div>
                      <div className="text-[10px] text-slate-400 truncate mt-0.5">
                        {pItem.nameVi.includes('(') ? pItem.nameVi.split('(')[1].replace(')', '') : pItem.nameEn}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Cỡ chữ */}
            <div className="space-y-2">
              <label className="block font-semibold text-slate-800 dark:text-slate-200">
                3. Cỡ chữ hiển thị
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'small', label: 'Nhỏ (13px)', desc: 'Nhiều dữ liệu hơn' },
                  { id: 'medium', label: 'Vừa (14px)', desc: 'Mặc định chuẩn' },
                  { id: 'large', label: 'Lớn (15px)', desc: 'Dễ đọc, mắt yếu' },
                ].map((item) => {
                  const isSel = userPreferences.fontSize === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => updateUserPreferences({ fontSize: item.id as FontSizePreference })}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isSel
                          ? 'border-[#002659] bg-[#F0F7FD] dark:bg-sky-950/60 dark:border-sky-500'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-slate-900 dark:text-slate-100">{item.label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{item.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 4. Mật độ bảng (Table Density) */}
            <div className="space-y-2">
              <label className="block font-semibold text-slate-800 dark:text-slate-200">
                4. Mật độ dòng bảng (Table Density)
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'compact', label: 'Gọn (Compact)', desc: 'Tối đa số dòng' },
                  { id: 'normal', label: 'Vừa (Normal)', desc: 'Mặc định' },
                  { id: 'relaxed', label: 'Thoáng (Relaxed)', desc: 'Rộng rãi' },
                ].map((item) => {
                  const isSel = userPreferences.tableDensity === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => updateUserPreferences({ tableDensity: item.id as TableDensityPreference })}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isSel
                          ? 'border-[#002659] bg-[#F0F7FD] dark:bg-sky-950/60 dark:border-sky-500'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      <div className="font-bold text-slate-900 dark:text-slate-100">{item.label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{item.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 5. Menu trái mặc định & Trang khởi động */}
            <div className="space-y-2">
              <label className="block font-semibold text-slate-800 dark:text-slate-200">
                5. Trạng thái Menu trái khi mở ứng dụng
              </label>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { val: true, label: 'Mở rộng (Mặc định)' },
                  { val: false, label: 'Thu gọn (Icon only)' },
                ].map((item) => {
                  const isSel = userPreferences.defaultSidebarOpen === item.val;
                  return (
                    <button
                      key={String(item.val)}
                      type="button"
                      onClick={() => updateUserPreferences({ defaultSidebarOpen: item.val })}
                      className={`p-2.5 rounded-xl border text-left font-bold transition-all cursor-pointer ${
                        isSel
                          ? 'border-[#002659] bg-[#F0F7FD] dark:bg-sky-950/60 dark:border-sky-500 text-slate-900 dark:text-slate-100'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 6. Trang khởi động & Phân trang */}
            <div className="space-y-3">
              <div>
                <label className="block font-semibold text-slate-800 dark:text-slate-200 mb-1">
                  6. Trang khởi động sau khi đăng nhập
                </label>
                <select
                  value={userPreferences.startupPage}
                  onChange={(e) => updateUserPreferences({ startupPage: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-medium"
                >
                  <option value="dashboard">Bàn làm việc (Dashboard)</option>
                  <option value="leads">Quản lý Lead</option>
                  <option value="opportunities">Cơ hội bán hàng</option>
                  <option value="quotations">Báo giá & Đề xuất</option>
                  <option value="sales-orders">Đơn hàng</option>
                  <option value="inventory-overview">Quản lý kho</option>
                  <option value="hr-staff">Quản lý nhân sự</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-800 dark:text-slate-200 mb-1">
                  Số dòng mỗi trang mặc định
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[10, 25, 50, 100].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => updateUserPreferences({ rowsPerPage: num as any })}
                      className={`py-1.5 rounded-lg border font-bold text-center cursor-pointer ${
                        userPreferences.rowsPerPage === num
                          ? 'border-[#002659] bg-[#F0F7FD] dark:bg-sky-950 text-[#002659] dark:text-sky-400'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                      }`}
                    >
                      {num} dòng
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* 7. Định dạng ngày, số, múi giờ */}
            <div className="space-y-3 sm:col-span-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-800 dark:text-slate-200 mb-1">Định dạng ngày</label>
                  <select
                    value={userPreferences.dateFormat}
                    onChange={(e) => updateUserPreferences({ dateFormat: e.target.value as any })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  >
                    <option value="DD/MM/YYYY">DD/MM/YYYY (Chuẩn Việt Nam)</option>
                    <option value="YYYY-MM-DD">YYYY-MM-DD (ISO Chuẩn)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 dark:text-slate-200 mb-1">Định dạng số</label>
                  <input
                    type="text"
                    readOnly
                    value="1.000.000 ₫ (Dấu chấm hàng nghìn)"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-800 dark:text-slate-200 mb-1">Múi giờ</label>
                  <input
                    type="text"
                    readOnly
                    value="(GMT+07:00) Bangkok, Hanoi, Jakarta"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-mono"
                  />
                </div>
              </div>
            </div>

            {/* 8. Ngôn ngữ hiển thị (Cá nhân hóa cho mỗi người dùng) */}
            <div className="space-y-2 sm:col-span-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <div className="flex items-center justify-between">
                <div>
                  <label className="block font-bold text-sm text-slate-800 dark:text-slate-200">
                    8. Ngôn ngữ hiển thị (Language)
                  </label>
                  <p className="text-xs text-slate-500">Mỗi cá nhân tự do tùy chỉnh ngôn ngữ giao diện theo nhu cầu làm việc.</p>
                </div>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
                  Cá nhân hóa
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {[
                  { code: 'vi', label: 'Tiếng Việt', desc: 'Giao diện chuẩn Việt Nam (Mặc định)', flag: '🇻🇳' },
                  { code: 'en', label: 'English', desc: 'International English Interface', flag: '🇬🇧' },
                  { code: 'ja', label: '日本語 (Japanese)', desc: 'Japanese Enterprise Localization', flag: '🇯🇵' },
                ].map((lang) => {
                  const isSel = (userPreferences.language || 'vi') === lang.code;
                  return (
                    <button
                      key={lang.code}
                      type="button"
                      onClick={() => {
                        updateUserPreferences({ language: lang.code as any });
                        showToast('Ngôn ngữ', `Đã chuyển ngôn ngữ sang ${lang.label}`);
                      }}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                        isSel
                          ? 'border-[#002659] bg-[#F0F7FD] dark:bg-sky-950/60 dark:border-sky-500 ring-2 ring-[#002659]/15'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xl">{lang.flag}</span>
                        {isSel && <Check className="w-4 h-4 text-[#002659] dark:text-sky-400" />}
                      </div>
                      <div className="mt-2 font-bold text-slate-900 dark:text-slate-100">{lang.label}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">{lang.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB D: TÙY CHỌN THÔNG BÁO
          ========================================================================= */}
      {profileActiveTab === 'notifications' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-6">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider">
              Tùy chọn Nhận Thông Báo theo Nhóm Sự Kiện
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Bật/tắt các loại thông báo phát sinh từ thao tác của người dùng khác trong hệ thống.
            </p>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {[
              {
                key: 'ordersAndApprovals',
                title: 'Đơn hàng & Phê duyệt',
                desc: 'Khi có đơn hàng mới gửi duyệt, đơn được chấp thuận hoặc từ chối, báo giá ký kết.',
              },
              {
                key: 'shippingAndLogistics',
                title: 'Giao hàng & Vận chuyển',
                desc: 'Khi tạo chuyến hàng, giao hàng thành công, bàn giao biên bản, thu hộ COD.',
              },
              {
                key: 'warehouseAndInventory',
                title: 'Kho & Tồn kho',
                desc: 'Khi nhập kho, xuất kho, điều chuyển, hoặc cảnh báo cận date/tồn dưới an toàn.',
              },
              {
                key: 'technicalAndWarranty',
                title: 'Kỹ thuật & Bảo hành',
                desc: 'Yêu cầu kỹ thuật khảo sát, tiếp nhận sửa chữa, xuất linh kiện bảo hành.',
              },
              {
                key: 'debtsAndPayments',
                title: 'Công nợ & Thanh toán',
                desc: 'Đề nghị thanh toán mới, đối soát hóa đơn, cảnh báo công nợ khách hàng quá hạn.',
              },
              {
                key: 'hrAndStaff',
                title: 'Nhân sự',
                desc: 'Yêu cầu cập nhật hồ sơ, phân công công việc, giao chỉ tiêu OKR/KPI.',
              },
              {
                key: 'systemAlerts',
                title: 'Hệ thống',
                desc: 'Thông báo bảo trì, cảnh báo bảo mật, thay đổi phân quyền từ Admin.',
              },
            ].map((row) => {
              const isChecked = (userPreferences.notificationChannels as any)[row.key];
              return (
                <div key={row.key} className="py-3.5 flex items-center justify-between gap-4">
                  <div className="max-w-xl">
                    <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">{row.title}</h4>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">{row.desc}</p>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer shrink-0">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={(e) => {
                        updateUserPreferences({
                          notificationChannels: {
                            ...userPreferences.notificationChannels,
                            [row.key]: e.target.checked,
                          },
                        });
                      }}
                      className="sr-only peer"
                    />
                    <div className="w-10 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#002659] dark:peer-checked:bg-sky-600 dark:bg-slate-700" />
                  </label>
                </div>
              );
            })}
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-4">
            <div>
              <h4 className="text-xs font-bold text-slate-900 dark:text-slate-100">
                Hiển thị chấm đỏ số lượng trên biểu tượng chuông
              </h4>
              <p className="text-[11px] text-slate-500">Badge số lượng chưa đọc ở thanh điều hướng trên cùng</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer shrink-0">
              <input
                type="checkbox"
                checked={userPreferences.notificationChannels.showBadgeOnBell}
                onChange={(e) => {
                  updateUserPreferences({
                    notificationChannels: {
                      ...userPreferences.notificationChannels,
                      showBadgeOnBell: e.target.checked,
                    },
                  });
                }}
                className="sr-only peer"
              />
              <div className="w-10 h-5 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[#002659] dark:peer-checked:bg-sky-600 dark:bg-slate-700" />
            </label>
          </div>
        </div>
      )}

      {/* =========================================================================
          TAB E: LỊCH SỬ THAO TÁC (AUDIT LOG CỦA TÔI - 90 NGÀY)
          ========================================================================= */}
      {profileActiveTab === 'activity' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider flex items-center gap-2">
                <History className="w-4 h-4 text-[#002659] dark:text-sky-400" />
                Hoạt động của tôi (Nhật ký 90 ngày)
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Chỉ đọc, tự động lưu vết mọi thao tác khởi tạo, chỉnh sửa, phê duyệt của tài khoản này.
              </p>
            </div>

            {/* Filters */}
            <div className="flex items-center gap-2 flex-wrap">
              <select
                value={activityDays}
                onChange={(e) => setActivityDays(e.target.value as any)}
                className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium text-slate-700 dark:text-slate-300"
              >
                <option value="7">7 ngày qua</option>
                <option value="30">30 ngày qua</option>
                <option value="90">90 ngày qua (Tối đa)</option>
              </select>

              <select
                value={activityModuleFilter}
                onChange={(e) => setActivityModuleFilter(e.target.value)}
                className="px-2.5 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium text-slate-700 dark:text-slate-300"
              >
                <option value="all">Tất cả phân hệ</option>
                <option value="opportunity">Cơ hội bán hàng</option>
                <option value="quote">Báo giá</option>
                <option value="contract">Hợp đồng</option>
                <option value="lead">Lead</option>
                <option value="inventory_tx">Kho</option>
                <option value="auth_session">Đăng nhập</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 text-[11px] font-semibold">
                  <th className="py-2.5 px-3">Thời gian</th>
                  <th className="py-2.5 px-3">Phân hệ</th>
                  <th className="py-2.5 px-3">Hành động</th>
                  <th className="py-2.5 px-3">Đối tượng liên quan</th>
                  <th className="py-2.5 px-3">Chi tiết</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {myActivities.length > 0 ? (
                  myActivities.map((act) => (
                    <tr key={act.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="py-2.5 px-3 font-mono text-slate-500 whitespace-nowrap">{act.timestamp}</td>
                      <td className="py-2.5 px-3">
                        <span className="font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-[11px]">
                          {act.entity}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-semibold text-slate-800 dark:text-slate-200">
                        {act.action}
                      </td>
                      <td className="py-2.5 px-3">
                        <button
                          type="button"
                          onClick={() => {
                            if (act.entityId) {
                              setCurrentDocCode(act.entityId);
                              if (act.entity.includes('QUOTE')) setActiveModule('quotations');
                              if (act.entity.includes('CONTRACT')) setActiveModule('contracts');
                              if (act.entity.includes('OPPORTUNITY')) setActiveModule('opportunities');
                              if (act.entity.includes('LEAD')) setActiveModule('leads');
                            }
                          }}
                          className="font-mono text-[11px] text-[#002659] dark:text-sky-400 font-semibold hover:underline inline-flex items-center gap-1 cursor-pointer"
                        >
                          {act.entityId}
                          <ExternalLink className="w-3 h-3 opacity-60" />
                        </button>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400 line-clamp-1">
                        {act.details}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-400">
                      Không có hoạt động nào trong khoảng thời gian này.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* MODAL: Yêu cầu cập nhật thông tin pháp lý & ngân hàng gửi HR duyệt */}
      {isHrRequestModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#002659] dark:text-sky-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Gửi Yêu Cầu Cập Nhật Thông Tin Pháp Lý
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsHrRequestModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmitHrRequest} className="space-y-3.5 text-xs">
              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed">
                Các trường thông tin sau liên quan đến hợp đồng lao động, bảo hiểm xã hội và quyết toán thuế thu nhập cá nhân. Sau khi gửi, phòng Nhân sự sẽ phê duyệt trước khi cập nhật chính thức.
              </p>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Họ và tên pháp lý</label>
                <input
                  type="text"
                  value={hrRequestForm.legalName}
                  onChange={(e) => setHrRequestForm({ ...hrRequestForm, legalName: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Ngày sinh</label>
                  <input
                    type="date"
                    value={hrRequestForm.dob}
                    onChange={(e) => setHrRequestForm({ ...hrRequestForm, dob: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Số CCCD mới</label>
                  <input
                    type="text"
                    value={hrRequestForm.idCardNumber}
                    onChange={(e) => setHrRequestForm({ ...hrRequestForm, idCardNumber: e.target.value })}
                    placeholder="12 số căn cước"
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Mã số thuế cá nhân mới</label>
                <input
                  type="text"
                  value={hrRequestForm.personalTaxCode}
                  onChange={(e) => setHrRequestForm({ ...hrRequestForm, personalTaxCode: e.target.value })}
                  placeholder="10 số mã số thuế"
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Tên ngân hàng</label>
                  <input
                    type="text"
                    value={hrRequestForm.bankName}
                    onChange={(e) => setHrRequestForm({ ...hrRequestForm, bankName: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Số tài khoản nhận lương</label>
                  <input
                    type="text"
                    value={hrRequestForm.accountNumber}
                    onChange={(e) => setHrRequestForm({ ...hrRequestForm, accountNumber: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-medium mb-1">Lý do yêu cầu cập nhật</label>
                <textarea
                  rows={2}
                  required
                  value={hrRequestForm.reason}
                  onChange={(e) => setHrRequestForm({ ...hrRequestForm, reason: e.target.value })}
                  placeholder="Ví dụ: Đổi CCCD gắn chip mới, đổi số tài khoản ngân hàng..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsHrRequestModalOpen(false)}
                  className="px-4 py-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#002659] hover:bg-[#001a3d] dark:bg-sky-600 dark:hover:bg-sky-500 text-white font-semibold text-xs cursor-pointer"
                >
                  Gửi duyệt cho Nhân sự
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
