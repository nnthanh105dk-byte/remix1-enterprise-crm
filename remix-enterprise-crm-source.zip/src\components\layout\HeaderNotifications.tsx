import React, { useState, useRef, useEffect } from 'react';
import { useCRM } from '../../context/CRMContext';
import { NotificationItem } from '../../types/crm';
import {
  Bell,
  Check,
  CheckCheck,
  ExternalLink,
  ShoppingCart,
  CheckCircle2,
  XCircle,
  CornerUpLeft,
  CalendarCheck,
  MessageSquare,
  UserCheck,
  FileText,
  AlertTriangle,
} from 'lucide-react';

export const HeaderNotifications: React.FC = () => {
  const {
    notifications,
    unreadNotificationCount,
    markNotificationRead,
    markAllNotificationsRead,
    setActiveModule,
    setCurrentDocCode,
    userPreferences,
  } = useCRM();

  const [isOpen, setIsOpen] = useState(false);
  const [tab, setTab] = useState<'all' | 'unread'>('all');
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const displayedList = tab === 'unread' ? notifications.filter((n) => !n.read) : notifications;

  const getNotificationIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'lead':
        return <UserCheck className="w-4 h-4 text-sky-600 dark:text-sky-400" />;
      case 'contract':
        return <FileText className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
      case 'order':
        return <ShoppingCart className="w-4 h-4 text-sky-600 dark:text-sky-400" />;
      case 'approval':
        return <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />;
      case 'rejection':
        return <XCircle className="w-4 h-4 text-rose-600 dark:text-rose-400" />;
      case 'return':
        return <CornerUpLeft className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
      case 'task':
        return <CalendarCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />;
      case 'comment':
        return <MessageSquare className="w-4 h-4 text-purple-600 dark:text-purple-400" />;
      default:
        return <AlertTriangle className="w-4 h-4 text-slate-500 dark:text-slate-400" />;
    }
  };

  const handleItemClick = (item: NotificationItem) => {
    if (!item.read) {
      markNotificationRead(item.id);
    }
    if (item.entityId) {
      setCurrentDocCode(item.entityId);
    }
    if (item.linkModule) {
      setActiveModule(item.linkModule);
    }
    setIsOpen(false);
  };

  const handleViewAll = () => {
    setActiveModule('notifications-center');
    setIsOpen(false);
  };

  return (
    <div className="relative shrink-0" ref={dropdownRef}>
      {/* Bell Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`relative h-9 w-9 rounded-xl border flex items-center justify-center transition-all cursor-pointer ${
          isOpen
            ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-400 dark:border-blue-600 text-blue-600 dark:text-blue-400 shadow-xs'
            : 'bg-white/90 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/80 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-750 hover:text-slate-900 dark:hover:text-white hover:border-slate-300 dark:hover:border-slate-600'
        }`}
        title="Thông báo hệ thống"
        aria-label="Thông báo"
      >
        <Bell className="w-4.5 h-4.5" />
        {userPreferences?.notificationChannels?.showBadgeOnBell !== false && unreadNotificationCount > 0 && (
          <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] px-1 text-[10px] font-bold text-white bg-rose-500 rounded-full flex items-center justify-center ring-2 ring-white dark:ring-slate-900 shadow-xs">
            {unreadNotificationCount > 99 ? '99+' : unreadNotificationCount}
          </span>
        )}
      </button>

      {/* Notifications Popover */}
      {isOpen && (
        <div className="absolute right-0 mt-1.5 w-[calc(100vw-24px)] sm:w-96 max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl z-50 animate-in fade-in duration-100 overflow-hidden flex flex-col">
          {/* Header */}
          <div className="p-3.5 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100">Thông báo</h3>
              {unreadNotificationCount > 0 && (
                <span className="text-[10px] font-semibold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/60 px-1.5 py-0.5 rounded-full">
                  {unreadNotificationCount} chưa đọc
                </span>
              )}
            </div>

            {unreadNotificationCount > 0 && (
              <button
                type="button"
                onClick={markAllNotificationsRead}
                className="text-[11px] font-medium text-[#002659] dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                Đánh dấu tất cả đã đọc
              </button>
            )}
          </div>

          {/* Filter Tabs: Tất cả | Chưa đọc */}
          <div className="flex border-b border-slate-100 dark:border-slate-800 px-3 pt-1 text-xs bg-slate-50/50 dark:bg-slate-900/50">
            <button
              type="button"
              onClick={() => setTab('all')}
              className={`pb-2 px-2 font-semibold transition-colors cursor-pointer ${
                tab === 'all'
                  ? 'border-b-2 border-[#002659] dark:border-sky-500 text-[#002659] dark:text-sky-400'
                  : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
              }`}
            >
              Tất cả ({notifications.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('unread')}
              className={`pb-2 px-2 font-semibold transition-colors cursor-pointer ${
                tab === 'unread'
                  ? 'border-b-2 border-[#002659] dark:border-sky-500 text-[#002659] dark:text-sky-400'
                  : 'text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
              }`}
            >
              Chưa đọc ({unreadNotificationCount})
            </button>
          </div>

          {/* Notification List */}
          <div className="max-h-80 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {displayedList.length > 0 ? (
              displayedList.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleItemClick(item)}
                  className={`p-3.5 hover:bg-slate-50 dark:hover:bg-slate-800/80 transition-colors flex items-start gap-3 cursor-pointer group ${
                    !item.read ? 'bg-[#F0F7FD]/60 dark:bg-sky-950/20' : ''
                  }`}
                >
                  <div className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 shrink-0 mt-0.5">
                    {getNotificationIcon(item.type)}
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-1">
                      <h4
                        className={`text-xs truncate ${
                          !item.read
                            ? 'font-bold text-slate-900 dark:text-slate-100'
                            : 'font-semibold text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        {item.title}
                      </h4>
                      <span className="text-[10px] text-slate-400 shrink-0 whitespace-nowrap">
                        {item.timestamp}
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 line-clamp-2 leading-relaxed">
                      {item.message}
                    </p>

                    {item.entityId && (
                      <span className="inline-block mt-1 font-mono text-[10px] text-[#002659] dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60 px-1.5 py-0.2 rounded border border-sky-100 dark:border-sky-900/60">
                        {item.entityId}
                      </span>
                    )}
                  </div>

                  {!item.read && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        markNotificationRead(item.id);
                      }}
                      className="p-1 rounded text-slate-400 hover:text-emerald-600 hover:bg-white dark:hover:bg-slate-800 shrink-0 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Đánh dấu đã đọc"
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-xs text-slate-400">
                {tab === 'unread' ? 'Không có thông báo chưa đọc nào.' : 'Không có thông báo nào.'}
              </div>
            )}
          </div>

          {/* Footer: Xem tất cả (trang riêng) */}
          <div className="p-2.5 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/80 text-center">
            <button
              type="button"
              onClick={handleViewAll}
              className="text-xs font-semibold text-[#002659] dark:text-sky-400 hover:underline inline-flex items-center gap-1.5 cursor-pointer"
            >
              <span>Xem tất cả thông báo</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
