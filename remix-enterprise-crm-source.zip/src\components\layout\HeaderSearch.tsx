import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useHR } from '../../context/HRContext';
import { ActiveModule } from '../../types/crm';
import {
  Search,
  X,
  Clock,
  Trash2,
  Users,
  Target,
  Briefcase,
  FileSpreadsheet,
  ShoppingCart,
  FileCheck2,
  Receipt,
  Package,
  UserCheck,
  ChevronRight,
  ArrowRight,
} from 'lucide-react';

interface SearchResultItem {
  id: string;
  code: string;
  title: string;
  subtitle: string;
  module: ActiveModule;
  tag?: string;
}

interface GroupedResults {
  typeKey: string;
  typeLabel: string;
  icon: React.ComponentType<{ className?: string }>;
  targetModule: ActiveModule;
  items: SearchResultItem[];
  totalCount: number;
}

export const HeaderSearch: React.FC = () => {
  const {
    currentTenant,
    hasPermission,
    setActiveModule,
    setCurrentDocCode,
    products,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
    language,
  } = useCRM();

  const {
    customers,
    leads,
    opportunities,
    quotations,
    orders,
    contracts,
    invoices,
  } = useSales();

  const { employees } = useHR();

  const [query, setQuery] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const [mobileFullscreenOpen, setMobileFullscreenOpen] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const mobileInputRef = useRef<HTMLInputElement>(null);

  // Keyboard shortcut '/' on desktop to focus search input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ignore if user is already typing in an input, textarea or contenteditable element
      const activeTag = (document.activeElement?.tagName || '').toLowerCase();
      if (activeTag === 'input' || activeTag === 'textarea' || (document.activeElement as HTMLElement)?.isContentEditable) {
        return;
      }

      if (e.key === '/') {
        e.preventDefault();
        inputRef.current?.focus();
        setIsOpen(true);
      } else if (e.key === 'Escape') {
        setIsOpen(false);
        setMobileFullscreenOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };

    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Focus mobile input on opening fullscreen
  useEffect(() => {
    if (mobileFullscreenOpen) {
      setTimeout(() => {
        mobileInputRef.current?.focus();
      }, 100);
    }
  }, [mobileFullscreenOpen]);

  // Compute Grouped Search Results
  const groupedResults = useMemo((): GroupedResults[] => {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const groups: GroupedResults[] = [];

    // Helper: matches keyword in string
    const match = (val?: string | number | null) => {
      if (val === undefined || val === null) return false;
      return String(val).toLowerCase().includes(q);
    };

    // 1. Khách hàng
    if (hasPermission('customers', 'view')) {
      const matched = customers.filter(
        (c) =>
          match(c.code) ||
          match(c.name) ||
          match(c.phone) ||
          match(c.email) ||
          match(c.taxId)
      );
      if (matched.length > 0) {
        groups.push({
          typeKey: 'customers',
          typeLabel: 'Khách hàng',
          icon: Users,
          targetModule: 'customers',
          totalCount: matched.length,
          items: matched.slice(0, 5).map((c) => ({
            id: c.id,
            code: c.code,
            title: c.name,
            subtitle: [c.phone, c.email, c.taxId ? `MST: ${c.taxId}` : ''].filter(Boolean).join(' • '),
            module: 'customers',
            tag: c.group,
          })),
        });
      }
    }

    // 2. Lead (Tiềm năng)
    if (hasPermission('leads', 'view')) {
      const matched = leads.filter(
        (l) =>
          match(l.code) ||
          match(l.fullName) ||
          match(l.company) ||
          match(l.phone) ||
          match(l.email)
      );
      if (matched.length > 0) {
        groups.push({
          typeKey: 'leads',
          typeLabel: 'Lead tiềm năng',
          icon: Target,
          targetModule: 'leads',
          totalCount: matched.length,
          items: matched.slice(0, 5).map((l) => ({
            id: l.id,
            code: l.code,
            title: l.fullName,
            subtitle: [l.company, l.phone, l.source].filter(Boolean).join(' • '),
            module: 'leads',
            tag: l.status,
          })),
        });
      }
    }

    // 3. Cơ hội bán hàng (Opportunity)
    if (hasPermission('opportunities', 'view')) {
      const matched = opportunities.filter(
        (o) =>
          match(o.code) ||
          match(o.title) ||
          match(o.customerName)
      );
      if (matched.length > 0) {
        groups.push({
          typeKey: 'opportunities',
          typeLabel: 'Cơ hội bán hàng',
          icon: Briefcase,
          targetModule: 'opportunities',
          totalCount: matched.length,
          items: matched.slice(0, 5).map((o) => ({
            id: o.id,
            code: o.code,
            title: o.title,
            subtitle: `${o.customerName} • ${Number(o.amount).toLocaleString('vi-VN')} ₫`,
            module: 'opportunities',
            tag: o.stage,
          })),
        });
      }
    }

    // 4. Báo giá (Quotation)
    if (hasPermission('quotations', 'view')) {
      const matched = quotations.filter(
        (quote) =>
          match(quote.code) ||
          match(quote.customerName) ||
          match(quote.opportunityCode)
      );
      if (matched.length > 0) {
        groups.push({
          typeKey: 'quotations',
          typeLabel: 'Báo giá & Đề xuất',
          icon: FileSpreadsheet,
          targetModule: 'quotations',
          totalCount: matched.length,
          items: matched.slice(0, 5).map((quote) => ({
            id: quote.id,
            code: quote.code,
            title: quote.code,
            subtitle: `${quote.customerName} • ${Number(quote.grandTotal).toLocaleString('vi-VN')} ₫`,
            module: 'quotations',
            tag: quote.status,
          })),
        });
      }
    }

    // 5. Đơn hàng (Order)
    if (hasPermission('sales-orders', 'view')) {
      const matched = orders.filter(
        (o) =>
          match(o.code) ||
          match(o.customerName) ||
          match(o.quotationCode)
      );
      if (matched.length > 0) {
        groups.push({
          typeKey: 'sales-orders',
          typeLabel: 'Đơn hàng',
          icon: ShoppingCart,
          targetModule: 'sales-orders',
          totalCount: matched.length,
          items: matched.slice(0, 5).map((o) => ({
            id: o.id,
            code: o.code,
            title: o.code,
            subtitle: `${o.customerName} • ${Number(o.totalAmount).toLocaleString('vi-VN')} ₫`,
            module: 'sales-orders',
            tag: o.status,
          })),
        });
      }
    }

    // 6. Hợp đồng (Contract)
    if (hasPermission('contracts', 'view')) {
      const matched = contracts.filter(
        (c) =>
          match(c.contractNumber) ||
          match(c.title) ||
          match(c.customerName)
      );
      if (matched.length > 0) {
        groups.push({
          typeKey: 'contracts',
          typeLabel: 'Hợp đồng kinh tế',
          icon: FileCheck2,
          targetModule: 'contracts',
          totalCount: matched.length,
          items: matched.slice(0, 5).map((c) => ({
            id: c.id,
            code: c.contractNumber,
            title: c.title,
            subtitle: `${c.customerName} • ${Number(c.totalValue).toLocaleString('vi-VN')} ₫`,
            module: 'contracts',
            tag: c.status,
          })),
        });
      }
    }

    // 7. Hóa đơn (Invoice)
    if (hasPermission('sales-invoices', 'view')) {
      const matched = invoices.filter(
        (inv) =>
          match(inv.invoiceNumber) ||
          match(inv.customerName) ||
          match(inv.customerTaxId)
      );
      if (matched.length > 0) {
        groups.push({
          typeKey: 'sales-invoices',
          typeLabel: 'Hóa đơn',
          icon: Receipt,
          targetModule: 'sales-invoices',
          totalCount: matched.length,
          items: matched.slice(0, 5).map((inv) => ({
            id: inv.id,
            code: inv.invoiceNumber,
            title: `HĐ #${inv.invoiceNumber}`,
            subtitle: `${inv.customerName} • ${Number(inv.totalAmount).toLocaleString('vi-VN')} ₫`,
            module: 'sales-invoices',
            tag: inv.status,
          })),
        });
      }
    }

    // 8. Sản phẩm (Product)
    if (hasPermission('inventory', 'view')) {
      const matched = products.filter(
        (p) =>
          p.tenantId === currentTenant.id &&
          (match(p.sku) || match(p.name) || match(p.category))
      );
      if (matched.length > 0) {
        groups.push({
          typeKey: 'products',
          typeLabel: 'Sản phẩm & Tồn kho',
          icon: Package,
          targetModule: 'inventory-overview',
          totalCount: matched.length,
          items: matched.slice(0, 5).map((p) => ({
            id: p.id,
            code: p.sku,
            title: p.name,
            subtitle: `${p.category} • Giá bán: ${Number(p.sellingPrice).toLocaleString('vi-VN')} ₫`,
            module: 'inventory-overview',
            tag: p.status,
          })),
        });
      }
    }

    // 9. Nhân viên (Employee)
    if (hasPermission('hr-staff', 'view')) {
      const matched = employees.filter(
        (emp) =>
          match(emp.code) ||
          match(emp.fullName) ||
          match(emp.email) ||
          match(emp.phone) ||
          match(emp.personalTaxCode)
      );
      if (matched.length > 0) {
        groups.push({
          typeKey: 'employees',
          typeLabel: 'Nhân viên',
          icon: UserCheck,
          targetModule: 'hr-staff',
          totalCount: matched.length,
          items: matched.slice(0, 5).map((emp) => ({
            id: emp.id,
            code: emp.code,
            title: emp.fullName,
            subtitle: `${emp.positionName || 'Nhân viên'} • ${emp.departmentName || ''}`,
            module: 'hr-staff',
            tag: emp.status,
          })),
        });
      }
    }

    return groups;
  }, [
    query,
    hasPermission,
    customers,
    leads,
    opportunities,
    quotations,
    orders,
    contracts,
    invoices,
    products,
    employees,
    currentTenant.id,
  ]);

  const handleSelectItem = (item: SearchResultItem) => {
    addRecentSearch(query.trim() || item.code);
    setCurrentDocCode(item.code);
    setActiveModule(item.module);
    setIsOpen(false);
    setMobileFullscreenOpen(false);
  };

  const handleViewAllGroup = (group: GroupedResults) => {
    addRecentSearch(query.trim());
    setCurrentDocCode(null);
    setActiveModule(group.targetModule);
    setIsOpen(false);
    setMobileFullscreenOpen(false);
  };

  const handleRecentClick = (text: string) => {
    setQuery(text);
    inputRef.current?.focus();
    mobileInputRef.current?.focus();
  };

  return (
    <div className="relative flex-1 max-w-sm lg:max-w-md mx-2 sm:mx-3" ref={containerRef}>
      {/* Mobile: Search Icon Trigger */}
      <div className="sm:hidden flex justify-end">
        <button
          type="button"
          onClick={() => setMobileFullscreenOpen(true)}
          className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          title="Tìm kiếm từ khóa"
          aria-label="Mở tìm kiếm"
        >
          <Search className="w-4 h-4" />
        </button>
      </div>

      {/* Desktop Search Input Box */}
      <div className="hidden sm:block relative w-full">
        <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none shrink-0" />
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setIsOpen(true);
          }}
          onFocus={() => setIsOpen(true)}
          placeholder={
            language === 'vi'
              ? 'Tìm theo mã, tên, SĐT, email, MST... (phím /)'
              : language === 'ja'
              ? 'コード、名前、電話、メール、納税番号で検索... (/)'
              : 'Search by code, name, phone, email, tax ID... (/)'
          }
          className="w-full h-8.5 pl-8 pr-12 text-xs bg-slate-100/80 hover:bg-slate-100 focus:bg-white dark:bg-slate-900/80 dark:hover:bg-slate-900 dark:focus:bg-slate-950 border border-slate-200 dark:border-slate-800 focus:border-[#002659] dark:focus:border-sky-500 rounded-lg text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-hidden transition-all shadow-2xs"
        />
        {query ? (
          <button
            type="button"
            onClick={() => {
              setQuery('');
              inputRef.current?.focus();
            }}
            className="absolute right-2.5 top-1/2 -translate-y-1/2 p-0.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded"
            title={language === 'vi' ? 'Xóa từ khóa' : language === 'ja' ? 'キーワードをクリア' : 'Clear search'}
          >
            <X className="w-3.5 h-3.5" />
          </button>
        ) : (
          <kbd className="absolute right-2.5 top-1/2 -translate-y-1/2 px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded shadow-2xs pointer-events-none">
            /
          </kbd>
        )}
      </div>

      {/* Desktop Results Dropdown */}
      {isOpen && (
        <div className="hidden sm:block absolute left-0 right-0 mt-1.5 max-h-[460px] overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl z-50 animate-in fade-in duration-100 divide-y divide-slate-100 dark:divide-slate-800/80">
          {/* Recent Searches Header */}
          {!query.trim() && (
            <div className="p-3">
              <div className="flex items-center justify-between text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" />
                  {language === 'vi' ? 'Tìm kiếm gần đây' : language === 'ja' ? '最近の検索' : 'Recent Searches'}
                </span>
                {recentSearches.length > 0 && (
                  <button
                    type="button"
                    onClick={clearRecentSearches}
                    className="flex items-center gap-1 text-[11px] text-slate-400 hover:text-rose-500 lowercase transition-colors"
                  >
                    <Trash2 className="w-3 h-3" />
                    {language === 'vi' ? 'Xóa lịch sử' : language === 'ja' ? '履歴を削除' : 'Clear history'}
                  </button>
                )}
              </div>

              {recentSearches.length > 0 ? (
                <div className="flex flex-wrap gap-1.5">
                  {recentSearches.map((tag, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleRecentClick(tag)}
                      className="px-2.5 py-1 text-xs bg-slate-100 dark:bg-slate-800 hover:bg-[#F0F7FD] dark:hover:bg-sky-950 text-slate-700 dark:text-slate-200 hover:text-[#002659] dark:hover:text-sky-400 rounded-md transition-colors"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 py-1">
                  {language === 'vi' ? 'Chưa có lịch sử tìm kiếm.' : language === 'ja' ? '検索履歴はありません。' : 'No recent searches.'}
                </p>
              )}
            </div>
          )}

          {/* Search Query Results Grouped */}
          {query.trim() && groupedResults.length > 0 && (
            <div className="p-2 space-y-3">
              {groupedResults.map((group) => {
                const IconComp = group.icon;
                return (
                  <div key={group.typeKey} className="space-y-1">
                    <div className="flex items-center justify-between px-2 pt-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      <span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300">
                        <IconComp className="w-3.5 h-3.5 text-[#002659] dark:text-sky-400" />
                        {group.typeLabel} ({group.totalCount})
                      </span>
                      {group.totalCount > 5 && (
                        <button
                          type="button"
                          onClick={() => handleViewAllGroup(group)}
                          className="text-[11px] text-[#002659] dark:text-sky-400 hover:underline flex items-center gap-0.5"
                        >
                          {language === 'vi' ? 'Xem tất cả' : language === 'ja' ? 'すべて見る' : 'View all'} ({group.totalCount})
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}
                    </div>

                    <div className="space-y-0.5">
                      {group.items.map((item) => (
                        <button
                          key={item.id}
                          type="button"
                          onClick={() => handleSelectItem(item)}
                          className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between gap-2 transition-colors cursor-pointer"
                        >
                          <div className="min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                                {item.title}
                              </span>
                              <span className="text-[10px] font-mono text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800 px-1 rounded">
                                {item.code}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                              {item.subtitle}
                            </p>
                          </div>
                          {item.tag && (
                            <span className="text-[10px] font-medium text-slate-500 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded shrink-0">
                              {item.tag}
                            </span>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* No results notice */}
          {query.trim() && groupedResults.length === 0 && (
            <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
              {language === 'vi' ? (
                <>Không tìm thấy kết quả nào phù hợp với từ khóa <strong className="text-slate-800 dark:text-slate-200">"{query}"</strong> trong công ty hiện tại.</>
              ) : language === 'ja' ? (
                <>キーワード <strong className="text-slate-800 dark:text-slate-200">"{query}"</strong> に一致する結果はありませんでした。</>
              ) : (
                <>No results found matching keyword <strong className="text-slate-800 dark:text-slate-200">"{query}"</strong> in current tenant.</>
              )}
            </div>
          )}
        </div>
      )}

      {/* Mobile Fullscreen Search Overlay */}
      {mobileFullscreenOpen && (
        <div className="sm:hidden fixed inset-0 z-50 bg-white dark:bg-slate-950 flex flex-col animate-in fade-in duration-150">
          {/* Header Bar */}
          <div className="h-14 border-b border-slate-200 dark:border-slate-800 flex items-center px-3 gap-2 shrink-0">
            <Search className="w-4 h-4 text-slate-400 shrink-0" />
            <input
              ref={mobileInputRef}
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={
                language === 'vi'
                  ? 'Tìm mã, tên, SĐT, email, MST...'
                  : language === 'ja'
                  ? 'コード、名前、電話、メールで検索...'
                  : 'Search by code, name, phone, email...'
              }
              className="flex-1 h-9 text-sm bg-transparent border-0 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-hidden"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery('')}
                className="p-1 text-slate-400 hover:text-slate-600 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button
              type="button"
              onClick={() => setMobileFullscreenOpen(false)}
              className="text-xs font-medium text-slate-600 dark:text-slate-300 px-2 py-1 rounded-md"
            >
              {language === 'vi' ? 'Đóng' : language === 'ja' ? '閉じる' : 'Close'}
            </button>
          </div>

          {/* Content Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {!query.trim() && (
              <div>
                <div className="flex items-center justify-between text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                  <span className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5" />
                    {language === 'vi' ? 'Tìm kiếm gần đây' : language === 'ja' ? '最近の検索' : 'Recent Searches'}
                  </span>
                  {recentSearches.length > 0 && (
                    <button
                      type="button"
                      onClick={clearRecentSearches}
                      className="text-xs text-rose-500 hover:underline"
                    >
                      {language === 'vi' ? 'Xóa tất cả' : language === 'ja' ? 'すべて削除' : 'Clear all'}
                    </button>
                  )}
                </div>

                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((tag, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleRecentClick(tag)}
                      className="px-3 py-1.5 text-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-lg"
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {query.trim() && groupedResults.length > 0 && (
              <div className="space-y-4">
                {groupedResults.map((group) => {
                  const IconComp = group.icon;
                  return (
                    <div key={group.typeKey} className="space-y-2">
                      <div className="flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
                        <span className="flex items-center gap-1.5">
                          <IconComp className="w-4 h-4 text-[#002659] dark:text-sky-400" />
                          {group.typeLabel} ({group.totalCount})
                        </span>
                        {group.totalCount > 5 && (
                          <button
                            type="button"
                            onClick={() => handleViewAllGroup(group)}
                            className="text-xs text-[#002659] dark:text-sky-400 underline"
                          >
                            {language === 'vi' ? 'Xem tất cả' : language === 'ja' ? 'すべて見る' : 'View all'} ({group.totalCount})
                          </button>
                        )}
                      </div>

                      <div className="divide-y divide-slate-100 dark:divide-slate-800 rounded-xl border border-slate-100 dark:border-slate-800 overflow-hidden">
                        {group.items.map((item) => (
                          <button
                            key={item.id}
                            type="button"
                            onClick={() => handleSelectItem(item)}
                            className="w-full text-left p-3 hover:bg-slate-50 dark:hover:bg-slate-900 flex items-center justify-between gap-2"
                          >
                            <div className="min-w-0">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                                  {item.title}
                                </span>
                                <span className="text-[10px] font-mono text-slate-400 bg-slate-100 dark:bg-slate-800 px-1 rounded">
                                  {item.code}
                                </span>
                              </div>
                              <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5">
                                {item.subtitle}
                              </p>
                            </div>
                            <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {query.trim() && groupedResults.length === 0 && (
              <div className="py-12 text-center text-xs text-slate-500 dark:text-slate-400">
                Không tìm thấy kết quả nào phù hợp.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
