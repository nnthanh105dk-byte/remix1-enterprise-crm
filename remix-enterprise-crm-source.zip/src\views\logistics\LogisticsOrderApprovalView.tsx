import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useLogistics } from '../../context/LogisticsContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { SalesOrder } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import {
  CheckCircle2,
  Clock,
  AlertTriangle,
  Search,
  Filter,
  Package,
  Calendar,
  User,
  Building,
  Check,
  X,
  MessageSquare,
  Send,
  ArrowRight,
  ShieldAlert,
  ChevronRight,
  AlertCircle,
  Truck,
  RotateCcw,
} from 'lucide-react';

export const LogisticsOrderApprovalView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { orders, updateOrder } = useSales();
  const {
    confirmOrder,
    requestMoreInfoOrder,
    rejectLogisticsOrder,
    addOrderComment,
  } = useLogistics();
  const { products, lots, createStockOutReceipt } = useWarehouse();

  // Tab: 'pending' (Chờ xác nhận) | 'all' (Tất cả đơn)
  const [activeTab, setActiveTab] = useState<'pending' | 'all'>('pending');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Selected Order for Detail Drawer
  const [selectedOrder, setSelectedOrder] = useState<SalesOrder | null>(null);

  // Modals for actions
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isRequestInfoModalOpen, setIsRequestInfoModalOpen] = useState(false);
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);

  // Form values
  const [requestInfoReason, setRequestInfoReason] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [expectedShipDate, setExpectedShipDate] = useState(
    new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [confirmNote, setConfirmNote] = useState('');
  const [commentText, setCommentText] = useState('');

  // Per-line decisions during partial/full confirm
  const [lineDecisions, setLineDecisions] = useState<
    Record<string, { confirmedQty: number; action: 'Đủ hàng' | 'Chờ nhập hàng' | 'Loại khỏi đơn' }>
  >({});

  // Filter orders
  // Chỉ hiện các đơn hàng đã được Sales duyệt và gửi sang Logistics (sentToLogisticsAt hoặc có logisticsStatus)
  const logisticsOrders = orders.filter((o) => o.sentToLogisticsAt || o.logisticsStatus);

  const pendingOrders = logisticsOrders.filter(
    (o) => o.logisticsStatus === 'Chờ xác nhận' || !o.logisticsStatus
  );

  const filteredOrders = logisticsOrders.filter((o) => {
    if (activeTab === 'pending') {
      if (o.logisticsStatus !== 'Chờ xác nhận' && o.logisticsStatus) return false;
    } else {
      if (statusFilter !== 'all' && o.logisticsStatus !== statusFilter) return false;
    }

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        o.code.toLowerCase().includes(q) ||
        o.customerName.toLowerCase().includes(q) ||
        o.assignedTo.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Calculate waiting time in hours
  const getWaitingHours = (sentAt?: string): number => {
    if (!sentAt) return 0;
    const sentTime = new Date(sentAt).getTime();
    if (isNaN(sentTime)) return 0;
    return Math.max(0, Math.round((Date.now() - sentTime) / (1000 * 60 * 60)));
  };

  // Open drawer and initialize line decisions
  const handleOpenDetail = (order: SalesOrder) => {
    setSelectedOrder(order);
    const initialDecisions: Record<
      string,
      { confirmedQty: number; action: 'Đủ hàng' | 'Chờ nhập hàng' | 'Loại khỏi đơn' }
    > = {};

    order.items.forEach((item) => {
      const whProd = products.find((p) => p.sku === item.sku);
      const totalStock = whProd ? Object.values(whProd.stocks).reduce((a, b) => a + b, 0) : 0;
      const allocated = whProd?.reserved || 0;
      const available = Math.max(0, totalStock - allocated);
      const isSufficient = available >= item.quantity;

      initialDecisions[item.sku] = {
        confirmedQty: isSufficient ? item.quantity : available,
        action: isSufficient ? 'Đủ hàng' : 'Chờ nhập hàng',
      };
    });

    setLineDecisions(initialDecisions);
  };

  const handleConfirmSubmit = () => {
    if (!selectedOrder) return;
    const decisionsArray = selectedOrder.items.map((it) => {
      const d = lineDecisions[it.sku] || {
        confirmedQty: it.quantity,
        action: 'Đủ hàng' as const,
      };
      return {
        sku: it.sku,
        confirmedQty: d.confirmedQty,
        action: d.action,
      };
    });

    confirmOrder(selectedOrder.id, decisionsArray, expectedShipDate, confirmNote);
    setIsConfirmModalOpen(false);
    setSelectedOrder((prev) =>
      prev ? { ...prev, logisticsStatus: 'Đã xác nhận', expectedShipDate } : null
    );
  };

  const handleRequestInfoSubmit = () => {
    if (!selectedOrder || !requestInfoReason.trim()) {
      showToast('Lỗi', 'Bắt buộc nhập lý do yêu cầu bổ sung.', 'warning');
      return;
    }
    requestMoreInfoOrder(selectedOrder.id, requestInfoReason);
    setIsRequestInfoModalOpen(false);
    setRequestInfoReason('');
    setSelectedOrder((prev) =>
      prev ? { ...prev, logisticsStatus: 'Cần bổ sung', isLockedForSales: false } : null
    );
  };

  const handleRejectSubmit = () => {
    if (!selectedOrder || !rejectReason.trim()) {
      showToast('Lỗi', 'Bắt buộc nhập lý do từ chối.', 'warning');
      return;
    }
    rejectLogisticsOrder(selectedOrder.id, rejectReason);
    setIsRejectModalOpen(false);
    setRejectReason('');
    setSelectedOrder((prev) =>
      prev ? { ...prev, logisticsStatus: 'Từ chối' } : null
    );
  };

  const handleSendComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedOrder || !commentText.trim()) return;
    addOrderComment(selectedOrder.id, 'Điều phối Logistics', 'Logistics', commentText.trim());
    setCommentText('');
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header & Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
              <Package className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Duyệt Đơn Hàng (Logistics Tiếp Nhận)
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Xác nhận đơn hàng Sales gửi sang, kiểm tra tồn kho, giữ chỗ hàng khả dụng và chuẩn bị xuất kho giao hàng.
          </p>
        </div>

        {/* Quick link to Stock Out */}
        <button
          onClick={() => setActiveModule('logistics-stock-out')}
          className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors"
        >
          <span>Xem Đơn chờ xuất</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Chờ xác nhận</span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
          </div>
          <p className="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-1">
            {pendingOrders.length} <span className="text-xs text-slate-500 font-normal">đơn</span>
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Hàng đợi xử lý của Logistics</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Cảnh báo &gt;4h</span>
            <Clock className="w-4 h-4 text-rose-500" />
          </div>
          <p className="text-2xl font-bold text-rose-600 dark:text-rose-400 mt-1">
            {pendingOrders.filter((o) => getWaitingHours(o.sentToLogisticsAt) >= 4).length}
          </p>
          <p className="text-[11px] text-rose-500 mt-1">Cần phản hồi gấp cho Sales</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Đã xác nhận</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {logisticsOrders.filter((o) => o.logisticsStatus === 'Đã xác nhận').length}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Đã giữ chỗ tồn kho</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Cần bổ sung thông tin</span>
            <AlertTriangle className="w-4 h-4 text-sky-500" />
          </div>
          <p className="text-2xl font-bold text-sky-600 dark:text-sky-400 mt-1">
            {logisticsOrders.filter((o) => o.logisticsStatus === 'Cần bổ sung').length}
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Chờ Sales cập nhật lại</p>
        </div>
      </div>

      {/* Tabs & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('pending')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 ${
                activeTab === 'pending'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              <span>Hàng đợi Chờ xác nhận</span>
              <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/20">
                {pendingOrders.length}
              </span>
            </button>

            <button
              onClick={() => setActiveTab('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeTab === 'all'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              Tất cả đơn hàng Logistics ({logisticsOrders.length})
            </button>
          </div>

          {activeTab === 'all' && (
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <option value="all">Tất cả trạng thái xử lý</option>
              <option value="Chờ xác nhận">Chờ xác nhận</option>
              <option value="Đã xác nhận">Đã xác nhận</option>
              <option value="Cần bổ sung">Cần bổ sung</option>
              <option value="Từ chối">Từ chối</option>
              <option value="Đang xuất kho">Đang xuất kho</option>
              <option value="Đã xuất kho">Đã xuất kho</option>
              <option value="Đang giao">Đang giao</option>
              <option value="Đã giao">Đã giao</option>
              <option value="Hoàn tất">Hoàn tất</option>
            </select>
          )}
        </div>

        {/* Search box */}
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo mã đơn (DH-2026-xxxx), tên khách hàng hoặc nhân viên Sales..."
            className="w-full pl-9 pr-4 py-2 rounded-lg text-xs bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-100 focus:outline-hidden focus:ring-1 focus:ring-sky-500"
          />
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Mã đơn & Ngày gửi</th>
                <th className="py-3 px-4">Khách hàng</th>
                <th className="py-3 px-4">Sales phụ trách</th>
                <th className="py-3 px-4">Ngày giao mong muốn</th>
                <th className="py-3 px-4 text-right">Tổng giá trị</th>
                <th className="py-3 px-4 text-center">Tình trạng tồn</th>
                <th className="py-3 px-4 text-center">Thời gian chờ</th>
                <th className="py-3 px-4 text-center">Trạng thái xử lý</th>
                <th className="py-3 px-4 text-center">Hành động</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-200">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-slate-400">
                    Không tìm thấy đơn hàng nào phù hợp với bộ lọc.
                  </td>
                </tr>
              ) : (
                filteredOrders.map((order) => {
                  const waitHrs = getWaitingHours(order.sentToLogisticsAt);
                  const isOverdue = waitHrs >= 4 && order.logisticsStatus === 'Chờ xác nhận';

                  return (
                    <tr
                      key={order.id}
                      className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors ${
                        isOverdue ? 'bg-rose-50/30 dark:bg-rose-950/10' : ''
                      }`}
                    >
                      <td className="py-3 px-4 font-mono font-bold text-sky-600 dark:text-sky-400">
                        {order.code}
                        <div className="text-[10px] text-slate-400 font-sans font-normal mt-0.5">
                          {order.sentToLogisticsAt || order.orderDate}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-medium max-w-[200px] truncate" title={order.customerName}>
                        {order.customerName}
                        <div className="text-[10px] text-slate-400 font-mono">{order.customerCode}</div>
                      </td>
                      <td className="py-3 px-4">{order.assignedTo}</td>
                      <td className="py-3 px-4 font-medium">
                        {order.expectedDeliveryDate}
                        {order.expectedShipDate && (
                          <div className="text-[10px] text-emerald-600 font-medium">
                            Dự kiến xuất: {order.expectedShipDate}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-bold text-slate-900 dark:text-white">
                        {order.totalAmount.toLocaleString()} đ
                      </td>
                      <td className="py-3 px-4 text-center">
                        {order.stockSufficient ? (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                            <CheckCircle2 className="w-3 h-3" /> Đủ hàng
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
                            <AlertTriangle className="w-3 h-3" /> Thiếu tồn kho
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        {order.logisticsStatus === 'Chờ xác nhận' ? (
                          <span
                            className={`font-semibold px-2 py-0.5 rounded-full text-[10px] ${
                              isOverdue
                                ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 border border-rose-300 font-bold animate-pulse'
                                : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300'
                            }`}
                          >
                            {waitHrs} giờ
                          </span>
                        ) : (
                          <span className="text-slate-400">-</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`inline-block px-2.5 py-1 rounded-full text-[10.5px] font-bold ${
                            order.logisticsStatus === 'Đã xác nhận'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/80 dark:text-emerald-300'
                              : order.logisticsStatus === 'Chờ xác nhận'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300'
                              : order.logisticsStatus === 'Cần bổ sung'
                              ? 'bg-sky-100 text-sky-800 dark:bg-sky-950/80 dark:text-sky-300'
                              : order.logisticsStatus === 'Đã xuất kho'
                              ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/80 dark:text-purple-300'
                              : order.logisticsStatus === 'Đang giao'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-950/80 dark:text-blue-300'
                              : order.logisticsStatus === 'Đã giao' || order.logisticsStatus === 'Hoàn tất'
                              ? 'bg-teal-100 text-teal-800 dark:bg-teal-950/80 dark:text-teal-300'
                              : 'bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300'
                          }`}
                        >
                          {order.logisticsStatus || 'Chờ xác nhận'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => handleOpenDetail(order)}
                          className="px-3 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 dark:bg-sky-950/50 dark:hover:bg-sky-900/60 text-sky-700 dark:text-sky-300 font-semibold transition-colors"
                        >
                          Chi tiết &amp; Duyệt
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Drawer Chi tiết đơn hàng cho Logistics */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end animate-fade-in">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col overflow-hidden border-l border-slate-200 dark:border-slate-800">
            {/* Drawer Header */}
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-800/60 shrink-0">
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-mono text-base font-bold text-sky-600 dark:text-sky-400">
                    {selectedOrder.code}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                      selectedOrder.logisticsStatus === 'Đã xác nhận'
                        ? 'bg-emerald-100 text-emerald-800'
                        : selectedOrder.logisticsStatus === 'Cần bổ sung'
                        ? 'bg-sky-100 text-sky-800'
                        : 'bg-amber-100 text-amber-800'
                    }`}
                  >
                    {selectedOrder.logisticsStatus || 'Chờ xác nhận'}
                  </span>
                </div>
                <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-100 mt-0.5">
                  {selectedOrder.customerName}
                </h3>
              </div>

              <button
                onClick={() => setSelectedOrder(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200/50"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Chain Bar */}
            <div className="p-4 bg-slate-100/60 dark:bg-slate-950/40 border-b border-slate-200 dark:border-slate-800 shrink-0">
              <DocumentChainBar chain={selectedOrder.chain} currentType="order" />
            </div>

            {/* Drawer Body */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
              {/* General Order Info */}
              <div className="grid grid-cols-2 gap-3 text-xs bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700">
                <div>
                  <span className="text-slate-400 block">Sales phụ trách:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {selectedOrder.assignedTo}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Ngày gửi sang Logistics:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {selectedOrder.sentToLogisticsAt || selectedOrder.orderDate}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Ngày giao mong muốn:</span>
                  <span className="font-semibold text-amber-600 dark:text-amber-400">
                    {selectedOrder.expectedDeliveryDate}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block">Điều khoản thanh toán:</span>
                  <span className="font-semibold text-slate-800 dark:text-slate-200">
                    {selectedOrder.paymentTerms}
                  </span>
                </div>
              </div>

              {/* Line Items Table with Stock Check */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Danh sách sản phẩm &amp; Tồn khả dụng</span>
                  <span className="text-[11px] font-normal text-slate-400">
                    Tổng: {selectedOrder.totalAmount.toLocaleString()} đ
                  </span>
                </h4>

                <div className="border border-slate-200 dark:border-slate-700 rounded-xl overflow-hidden">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[11px]">
                      <tr>
                        <th className="p-2.5">Sản phẩm (SKU)</th>
                        <th className="p-2.5 text-center">Số lượng</th>
                        <th className="p-2.5 text-center">Tồn khả dụng</th>
                        <th className="p-2.5 text-center">Trạng thái dòng</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {selectedOrder.items.map((item) => {
                        const whProd = products.find((p) => p.sku === item.sku);
                        const totalStock = whProd
                          ? Object.values(whProd.stocks).reduce((a, b) => a + b, 0)
                          : 0;
                        const allocated = whProd?.reserved || 0;
                        const available = Math.max(0, totalStock - allocated);
                        const isSufficient = available >= item.quantity;

                        return (
                          <tr key={item.sku} className="hover:bg-slate-50 dark:hover:bg-slate-800/30">
                            <td className="p-2.5">
                              <div className="font-semibold text-slate-800 dark:text-slate-200">
                                {item.productName}
                              </div>
                              <div className="text-[10px] text-slate-400 font-mono">{item.sku}</div>
                            </td>
                            <td className="p-2.5 text-center font-bold">
                              {item.quantity} {item.unit}
                            </td>
                            <td className="p-2.5 text-center">
                              <span
                                className={`font-semibold ${
                                  isSufficient
                                    ? 'text-emerald-600 dark:text-emerald-400'
                                    : 'text-rose-600 dark:text-rose-400'
                                }`}
                              >
                                {available} {item.unit}
                              </span>
                            </td>
                            <td className="p-2.5 text-center">
                              {isSufficient ? (
                                <span className="inline-flex items-center gap-1 text-[10px] text-emerald-600 font-bold bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full">
                                  <Check className="w-3 h-3" /> Đủ hàng
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[10px] text-amber-600 font-bold bg-amber-50 dark:bg-amber-950/60 px-2 py-0.5 rounded-full">
                                  <AlertTriangle className="w-3 h-3" /> Thiếu {item.quantity - available}
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Status History Timeline */}
              {selectedOrder.statusHistory && selectedOrder.statusHistory.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
                    Lịch sử trạng thái xử lý
                  </h4>
                  <div className="space-y-2 border-l-2 border-slate-200 dark:border-slate-700 ml-2 pl-3">
                    {selectedOrder.statusHistory.map((h, i) => (
                      <div key={i} className="text-xs relative">
                        <div className="w-2 h-2 rounded-full bg-sky-500 absolute -left-[17px] top-1.5" />
                        <div className="font-semibold text-slate-800 dark:text-slate-200">
                          {h.status} - <span className="font-normal text-slate-500">{h.changedBy}</span>
                        </div>
                        <div className="text-[10px] text-slate-400">{h.changedAt}</div>
                        {h.note && <div className="text-slate-600 dark:text-slate-400 italic text-[11px] mt-0.5">"{h.note}"</div>}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Chat / Comments Thread between Sales & Logistics */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 bg-slate-50/50 dark:bg-slate-900/50">
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 mb-2.5 flex items-center gap-1.5">
                  <MessageSquare className="w-3.5 h-3.5 text-sky-500" />
                  <span>Trao đổi giữa Sales &amp; Logistics (@nhắc tên)</span>
                </h4>

                <div className="space-y-2 max-h-48 overflow-y-auto mb-3 pr-1 text-xs">
                  {selectedOrder.comments && selectedOrder.comments.length > 0 ? (
                    selectedOrder.comments.map((c) => (
                      <div
                        key={c.id}
                        className={`p-2.5 rounded-lg ${
                          c.department === 'Logistics'
                            ? 'bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 text-sky-900 dark:text-sky-200 ml-4'
                            : 'bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 mr-4'
                        }`}
                      >
                        <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
                          <span className="font-bold text-slate-700 dark:text-slate-300">
                            {c.sender} ({c.department})
                          </span>
                          <span>{c.createdAt}</span>
                        </div>
                        <p>{c.message}</p>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-slate-400 py-3 text-[11px]">
                      Chưa có trao đổi nào. Nhập tin nhắn bên dưới để gửi phản hồi cho Sales.
                    </p>
                  )}
                </div>

                <form onSubmit={handleSendComment} className="flex gap-2">
                  <input
                    type="text"
                    value={commentText}
                    onChange={(e) => setCommentText(e.target.value)}
                    placeholder="Nhập nội dung trao đổi hoặc nhắc @sales..."
                    className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                  <button
                    type="submit"
                    className="px-3 py-1.5 rounded-lg bg-sky-600 text-white font-semibold text-xs flex items-center gap-1 hover:bg-sky-700"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Gửi</span>
                  </button>
                </form>
              </div>
            </div>

            {/* Drawer Footer Actions */}
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/80 flex items-center justify-between gap-2 shrink-0">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsRejectModalOpen(true)}
                  className="px-3 py-2 rounded-lg border border-rose-200 text-rose-600 hover:bg-rose-50 dark:border-rose-800 dark:text-rose-400 text-xs font-semibold"
                >
                  Từ chối đơn
                </button>
                <button
                  onClick={() => setIsRequestInfoModalOpen(true)}
                  className="px-3 py-2 rounded-lg border border-slate-300 text-slate-700 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 text-xs font-semibold"
                >
                  Yêu cầu bổ sung
                </button>
              </div>

              <div className="flex items-center gap-2">
                {selectedOrder.logisticsStatus === 'Đã xác nhận' || selectedOrder.logisticsStatus === 'Đang xuất kho' ? (
                  <button
                    onClick={() => {
                      const stockOutItems = selectedOrder.items.map((it) => {
                        const matchingLot = lots
                          .filter((l) => l.sku === it.sku && l.warehouseId === 'wh-hn' && l.quantity > 0)
                          .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime())[0];
                        return {
                          sku: it.sku,
                          productName: it.productName,
                          quantity: it.quantity,
                          unitPrice: it.unitPrice,
                          lotNumber: matchingLot?.lotNumber || `LOT-2026-${it.sku}`,
                          total: it.total,
                        };
                      });

                      createStockOutReceipt({
                        date: new Date().toISOString().split('T')[0],
                        exportReason: 'Bán hàng',
                        warehouseId: 'wh-hn',
                        warehouseName: 'Kho Tổng Hà Nội',
                        customerName: selectedOrder.customerName,
                        dealCode: selectedOrder.code,
                        orderId: selectedOrder.id,
                        orderCode: selectedOrder.code,
                        items: stockOutItems,
                        totalQuantity: stockOutItems.reduce((sum, it) => sum + it.quantity, 0),
                        totalAmount: selectedOrder.totalAmount,
                        createdBy: 'Logistics - Quản lý điều phối',
                        notes: `Xuất kho giao hàng theo Đơn hàng ${selectedOrder.code} của ${selectedOrder.customerName}`,
                        chain: {
                          ...selectedOrder.chain,
                          orderId: selectedOrder.id,
                          orderCode: selectedOrder.code,
                        },
                      });

                      updateOrder(selectedOrder.id, { logisticsStatus: 'Đang xuất kho' });
                      setSelectedOrder((prev) => (prev ? { ...prev, logisticsStatus: 'Đang xuất kho' } : null));

                      showToast(
                        'Tạo Phiếu xuất kho thành công',
                        `Đã sinh Phiếu xuất kho từ Đơn hàng ${selectedOrder.code}. Chuyển sang Quản lý Kho để duyệt xuất!`,
                        'success'
                      );
                      setActiveModule('inventory-stock-out');
                    }}
                    className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
                  >
                    <Truck className="w-3.5 h-3.5" />
                    <span>Tạo Phiếu Xuất Kho (WMS) →</span>
                  </button>
                ) : (
                  <button
                    onClick={() => setIsConfirmModalOpen(true)}
                    className="px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Xác Nhận Đơn Hàng</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Xác nhận đơn hàng & Giữ chỗ tồn kho */}
      {isConfirmModalOpen && selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                <span>Xác Nhận Đơn Hàng {selectedOrder.code}</span>
              </h3>
              <button onClick={() => setIsConfirmModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <p className="text-xs text-slate-600 dark:text-slate-300">
              Hệ thống sẽ giữ chỗ số lượng khả dụng cho đơn hàng này. Vui lòng thiết lập ngày xuất kho dự kiến:
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Ngày xuất kho dự kiến</label>
                <input
                  type="date"
                  value={expectedShipDate}
                  onChange={(e) => setExpectedShipDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Ghi chú xác nhận (tùy chọn)</label>
                <textarea
                  rows={2}
                  value={confirmNote}
                  onChange={(e) => setConfirmNote(e.target.value)}
                  placeholder="Ví dụ: Đã bố trí xe tải 2.5T, đóng gói ngày mai..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <button
                onClick={() => setIsConfirmModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 text-slate-600 font-semibold text-xs"
              >
                Hủy
              </button>
              <button
                onClick={handleConfirmSubmit}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700"
              >
                Xác Nhận &amp; Giữ Chỗ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Yêu cầu bổ sung thông tin */}
      {isRequestInfoModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-sky-500" />
              <span>Yêu Cầu Bổ Sung Thông Tin Đơn</span>
            </h3>

            <p className="text-xs text-slate-500">
              Đơn hàng sẽ được chuyển lại cho Sales và mở khóa để sửa đổi thông tin. Bắt buộc nêu rõ lý do:
            </p>

            <textarea
              rows={3}
              value={requestInfoReason}
              onChange={(e) => setRequestInfoReason(e.target.value)}
              placeholder="Ví dụ: Thiếu số điện thoại người nhận tại kho, địa chỉ giao chưa rõ ràng..."
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsRequestInfoModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 text-slate-600 text-xs font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={handleRequestInfoSubmit}
                className="px-4 py-1.5 rounded-lg bg-sky-600 text-white text-xs font-bold hover:bg-sky-700"
              >
                Gửi Yêu Cầu Bổ Sung
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Từ chối đơn hàng */}
      {isRejectModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4">
            <h3 className="font-bold text-sm text-rose-600 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4" />
              <span>Từ Chối Tiếp Nhận Đơn Hàng</span>
            </h3>

            <p className="text-xs text-slate-500">
              Vui lòng nhập lý do từ chối để phản hồi chính thức cho Sales:
            </p>

            <textarea
              rows={3}
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              placeholder="Ví dụ: Hàng hết trong toàn hệ thống, không có phương tiện vận tải phù hợp..."
              className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
            />

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsRejectModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 text-slate-600 text-xs font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={handleRejectSubmit}
                className="px-4 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold hover:bg-rose-700"
              >
                Xác Nhận Từ Chối
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
