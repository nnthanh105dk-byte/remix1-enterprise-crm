/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * A+ CRM — CƠ CẤU TỔ CHỨC & QUẢN TRỊ NHÂN SỰ ĐA DOANH NGHIỆP
 * Tuân thủ tuyệt đối Section 05, 06, 11, 12, 13:
 * - Layer độc lập: User -> Membership -> Department -> Position -> Level -> Role -> Permission -> Scope.
 * - Human-readable identifier: SALE-0001 & APLUS-SALE-0001 (UUID là ID hệ thống).
 * - Tự động map Database từ Tenant hiện tại (không cho Admin tự nhập Database).
 * - Modal chi tiết User đủ 5 Tabs: Thông tin, Quyền & Scope, Hoạt động, Thiết bị, Lịch sử.
 */

import React, { useState, useMemo } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import { useCRM } from '../../context/CRMContext';
import {
  Department,
  Position,
  Level,
  Role,
  Membership,
  PermissionScope,
  ModulePermission,
} from '../../types/auth';
import {
  Users,
  Building2,
  Briefcase,
  Layers,
  ShieldCheck,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Database,
  ExternalLink,
  Laptop,
  Smartphone,
  History,
  Activity,
  KeyRound,
  Eye,
  Edit,
  Trash2,
  ChevronRight,
  Server,
  Lock,
  ArrowRight,
  Clock,
  ShieldAlert,
} from 'lucide-react';

export const OrganizationManagementView: React.FC = () => {
  const {
    currentCompany,
    sessionContext,
    tenantMemberships,
    allAccounts,
    allDepartments,
    tenantDepartments,
    allPositions,
    allLevels,
    allRoles,
    createEmployeeUser,
    updateMembershipScope,
    deleteMembership,
    updateEmployeeAccountByAdmin,
  } = useMultiTenant();

  const { showToast } = useCRM();

  // Active top tab
  const [activeMainTab, setActiveMainTab] = useState<'users' | 'departments' | 'positions' | 'roles'>('users');

  // Filters for users
  const [searchTerm, setSearchTerm] = useState('');
  const [deptFilter, setDeptFilter] = useState('all');
  const [roleFilter, setRoleFilter] = useState('all');

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedMembership, setSelectedMembership] = useState<Membership | null>(null);
  const [detailActiveTab, setDetailActiveTab] = useState<'info' | 'permissions' | 'activity' | 'devices' | 'history'>('info');

  // Create User Form State (Section 12)
  const [formFullName, setFormFullName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formDeptId, setFormDeptId] = useState('');
  const [formPosId, setFormPosId] = useState('');
  const [formLevelId, setFormLevelId] = useState('');
  const [formRoleId, setFormRoleId] = useState('');
  const [formEmpCode, setFormEmpCode] = useState('');

  // Admin User Edit Form State
  const [isEditingUser, setIsEditingUser] = useState(false);
  const [editDisplayId, setEditDisplayId] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editFullName, setEditFullName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editDeptId, setEditDeptId] = useState('');
  const [editPosId, setEditPosId] = useState('');
  const [editRoleId, setEditRoleId] = useState('');

  const handleStartEditUser = () => {
    if (!selectedMembership || !selectedUserAccount) return;
    setEditDisplayId(selectedMembership.displayId || selectedMembership.username);
    setEditEmail(selectedUserAccount.email);
    setEditFullName(selectedUserAccount.fullName);
    setEditPhone(selectedUserAccount.phone || '');
    setEditDeptId(selectedMembership.departmentId || '');
    setEditPosId(selectedMembership.positionId || '');
    setEditRoleId(selectedMembership.roleId || '');
    setIsEditingUser(true);
  };

  const handleSaveUserByAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMembership || !selectedUserAccount) return;
    if (!editEmail || !editDisplayId || !editFullName) {
      showToast('Lỗi thông tin', 'Vui lòng điền đầy đủ Email, ID và Họ tên.', 'warning');
      return;
    }

    const success = updateEmployeeAccountByAdmin({
      membershipId: selectedMembership.id,
      userId: selectedUserAccount.id,
      fullName: editFullName,
      email: editEmail,
      phone: editPhone,
      displayId: editDisplayId,
      departmentId: editDeptId,
      positionId: editPosId,
      roleId: editRoleId,
    });

    if (success) {
      setSelectedMembership((prev) =>
        prev
          ? {
              ...prev,
              displayId: editDisplayId,
              departmentId: editDeptId,
              positionId: editPosId,
              roleId: editRoleId,
            }
          : null
      );
      setIsEditingUser(false);
      showToast('Cập nhật thành công', `Đã đổi ID & Email cho nhân viên ${editFullName}.`, 'success');
    }
  };

  const currentTenantCode = sessionContext?.tenantCode || currentCompany?.code || 'APLUS';
  const currentDbName = sessionContext?.database || currentCompany?.database || 'DB_APLUS';

  // Filtered memberships in current tenant
  const filteredMemberships = useMemo(() => {
    return (tenantMemberships || []).filter((mem) => {
      const user = (allAccounts || []).find((u) => u.id === mem.userId);
      const dept = (allDepartments || []).find((d) => d.id === mem.departmentId);
      const role = (allRoles || []).find((r) => r.id === mem.roleId);

      if (deptFilter !== 'all' && mem.departmentId !== deptFilter) return false;
      if (roleFilter !== 'all' && mem.roleId !== roleFilter) return false;

      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        const matchesName = user?.fullName?.toLowerCase().includes(q) || false;
        const matchesEmail = user?.email?.toLowerCase().includes(q) || false;
        const matchesUsername = mem.username?.toLowerCase().includes(q) || false;
        const matchesDisplayId = mem.displayId?.toLowerCase().includes(q) || false;
        return matchesName || matchesEmail || matchesUsername || matchesDisplayId;
      }
      return true;
    });
  }, [tenantMemberships, allAccounts, allDepartments, allRoles, deptFilter, roleFilter, searchTerm]);

  // Selected user account for detail view
  const selectedUserAccount = useMemo(() => {
    if (!selectedMembership) return null;
    return (allAccounts || []).find((u) => u.id === selectedMembership.userId) || null;
  }, [selectedMembership, allAccounts]);

  const selectedDept = useMemo(() => {
    if (!selectedMembership) return null;
    return (allDepartments || []).find((d) => d.id === selectedMembership.departmentId) || null;
  }, [selectedMembership, allDepartments]);

  const selectedPos = useMemo(() => {
    if (!selectedMembership) return null;
    return (allPositions || []).find((p) => p.id === selectedMembership.positionId) || null;
  }, [selectedMembership, allPositions]);

  const selectedRole = useMemo(() => {
    if (!selectedMembership) return null;
    return (allRoles || []).find((r) => r.id === selectedMembership.roleId) || null;
  }, [selectedMembership, allRoles]);

  // Handle Create User Submit (Section 12)
  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formFullName || !formEmail || !formDeptId || !formPosId || !formLevelId || !formRoleId) {
      showToast('Thiếu thông tin', 'Vui lòng điền đầy đủ các trường bắt buộc (*)', 'warning');
      return;
    }

    try {
      const newMem = createEmployeeUser({
        fullName: formFullName,
        email: formEmail,
        phone: formPhone,
        departmentId: formDeptId,
        positionId: formPosId,
        levelId: formLevelId,
        roleId: formRoleId,
        employeeCode: formEmpCode,
      });

      showToast(
        'Tạo thành công',
        `Đã tạo nhân viên ${formFullName} • Username: ${newMem.username} (${newMem.displayId}) • CSDL: ${currentDbName}`,
        'success'
      );

      setIsCreateModalOpen(false);
      // Reset form
      setFormFullName('');
      setFormEmail('');
      setFormPhone('');
      setFormDeptId('');
      setFormPosId('');
      setFormLevelId('');
      setFormRoleId('');
      setFormEmpCode('');
    } catch (err: any) {
      showToast('Lỗi tạo nhân viên', err.message || 'Không thể tạo nhân sự.', 'error');
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16 font-sans">
      {/* 01. TENANT & DATABASE CONTEXT HEADER */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-[#002659] text-white flex items-center justify-center shrink-0 shadow-md">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
                Cơ Cấu Tổ Chức &amp; Quản Lý Nhân Sự (Organization &amp; RBAC)
              </h1>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                CSDL: {currentDbName}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Doanh nghiệp: <strong>{currentCompany?.name}</strong> ({currentTenantCode}) • Dữ liệu nhân sự và phân quyền được cách ly 100% trong Tenant Database.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            // Pre-select first values
            if (tenantDepartments.length > 0) setFormDeptId(tenantDepartments[0].id);
            if (allPositions.length > 0) setFormPosId(allPositions[0].id);
            if (allLevels.length > 0) setFormLevelId(allLevels[0].id);
            if (allRoles.length > 0) setFormRoleId(allRoles[0].id);
            setIsCreateModalOpen(true);
          }}
          className="px-4 py-2.5 rounded-xl bg-[#002659] hover:bg-[#001f47] text-white font-bold text-xs shadow-sm flex items-center justify-center gap-2 shrink-0 transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>+ Thêm Nhân Viên Mới</span>
        </button>
      </div>

      {/* 02. MAIN TABS (Sections 05, 06, 11) */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 text-xs font-bold gap-1 sm:gap-2 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveMainTab('users')}
          className={`py-3 px-4 border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeMainTab === 'users'
              ? 'border-[#002659] text-[#002659] dark:border-sky-400 dark:text-sky-300'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>1. Nhân sự &amp; Thành viên ({tenantMemberships.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('departments')}
          className={`py-3 px-4 border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeMainTab === 'departments'
              ? 'border-[#002659] text-[#002659] dark:border-sky-400 dark:text-sky-300'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <Building2 className="w-4 h-4" />
          <span>2. Phòng ban ({tenantDepartments.length})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('positions')}
          className={`py-3 px-4 border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeMainTab === 'positions'
              ? 'border-[#002659] text-[#002659] dark:border-sky-400 dark:text-sky-300'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span>3. Chức vụ &amp; Cấp độ ({allPositions.length} chức vụ / {allLevels.length} cấp)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveMainTab('roles')}
          className={`py-3 px-4 border-b-2 flex items-center gap-2 whitespace-nowrap transition-colors cursor-pointer ${
            activeMainTab === 'roles'
              ? 'border-[#002659] text-[#002659] dark:border-sky-400 dark:text-sky-300'
              : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-300'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>4. Vai trò &amp; Scopes (RBAC Matrix)</span>
        </button>
      </div>

      {/* 03. TAB CONTENT */}

      {/* TAB A: USERS & MEMBERSHIPS (Section 11) */}
      {activeMainTab === 'users' && (
        <div className="space-y-4">
          {/* Search & Filter Bar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xs">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Tìm tên, SALE-0001, email..."
                className="w-full pl-9 pr-3 h-9 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs focus:outline-hidden focus:border-[#002659]"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-300"
              >
                <option value="all">Tất cả phòng ban</option>
                {tenantDepartments.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name} ({d.code})
                  </option>
                ))}
              </select>

              <select
                value={roleFilter}
                onChange={(e) => setRoleFilter(e.target.value)}
                className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-xs text-slate-700 dark:text-slate-300"
              >
                <option value="all">Tất cả vai trò</option>
                {allRoles.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* User Table (Section 11) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-bold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-3 px-4">Nhân viên</th>
                    <th className="py-3 px-3">Mã (Username)</th>
                    <th className="py-3 px-3">Phòng ban</th>
                    <th className="py-3 px-3">Chức vụ</th>
                    <th className="py-3 px-3">Vai trò &amp; Scope</th>
                    <th className="py-3 px-3">CSDL Đích</th>
                    <th className="py-3 px-3 text-center">Trạng thái</th>
                    <th className="py-3 px-4 text-right">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredMemberships.map((mem) => {
                    const acc = allAccounts.find((u) => u.id === mem.userId);
                    const dept = allDepartments.find((d) => d.id === mem.departmentId);
                    const pos = allPositions.find((p) => p.id === mem.positionId);
                    const role = allRoles.find((r) => r.id === mem.roleId);

                    return (
                      <tr
                        key={mem.id}
                        onClick={() => {
                          setSelectedMembership(mem);
                          setDetailActiveTab('info');
                        }}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                      >
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-3">
                            <img
                              src={acc?.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces'}
                              alt={acc?.fullName || 'User'}
                              className="w-8 h-8 rounded-full object-cover border border-slate-200 shrink-0"
                            />
                            <div>
                              <span className="font-bold text-slate-900 dark:text-white block">
                                {acc?.fullName || 'Người dùng'}
                              </span>
                              <span className="text-[11px] text-slate-400">
                                {acc?.email || ''}
                              </span>
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span className="font-mono font-bold text-[#002659] dark:text-sky-300 block">
                            {mem.username}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            {mem.displayId}
                          </span>
                        </td>

                        <td className="py-3 px-3 font-semibold text-slate-700 dark:text-slate-300">
                          {dept?.name || 'Chưa gán'}
                        </td>

                        <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                          {pos?.title || mem.roleTitle}
                        </td>

                        <td className="py-3 px-3">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-semibold text-slate-900 dark:text-white">
                              {role?.name || mem.roleTitle}
                            </span>
                            <span className="px-1.5 py-0.2 rounded text-[10px] font-mono font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                              {role?.defaultScope || 'OWN'}
                            </span>
                          </div>
                        </td>

                        <td className="py-3 px-3">
                          <span className="font-mono text-[11px] font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                            {currentDbName}
                          </span>
                        </td>

                        <td className="py-3 px-3 text-center">
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                            Active
                          </span>
                        </td>

                        <td className="py-3 px-4 text-right">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedMembership(mem);
                              setDetailActiveTab('permissions');
                            }}
                            className="px-2.5 py-1 rounded-md text-xs font-semibold text-[#002659] dark:text-sky-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                          >
                            Chi tiết →
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB B: DEPARTMENTS (Section 05) */}
      {activeMainTab === 'departments' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {tenantDepartments.map((dept) => {
            const memberCount = tenantMemberships.filter((m) => m.departmentId === dept.id).length;
            return (
              <div
                key={dept.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 dark:bg-blue-950 text-[#002659] dark:text-sky-300 flex items-center justify-center font-bold">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <span className="px-2 py-0.5 rounded font-mono text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300">
                    {dept.code}
                  </span>
                </div>

                <div>
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    {dept.name}
                  </h3>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {dept.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400">
                  <span>Nhân sự trực thuộc:</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono">
                    {memberCount} nhân viên
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TAB C: POSITIONS & LEVELS (Section 05) */}
      {activeMainTab === 'positions' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Positions */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
            <div className="flex items-center gap-2 font-bold text-sm text-slate-900 dark:text-white">
              <Briefcase className="w-4 h-4 text-[#002659]" />
              <span>Chức vụ chuyên môn (Positions)</span>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {allPositions.map((pos) => (
                <div key={pos.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-800 dark:text-slate-200 block">{pos.title}</span>
                    <span className="text-[11px] text-slate-400 font-mono">Mã: {pos.code}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-semibold">
                    Cấp {pos.levelRank}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Levels */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs space-y-4">
            <div className="flex items-center gap-2 font-bold text-sm text-slate-900 dark:text-white">
              <Layers className="w-4 h-4 text-indigo-600" />
              <span>Cấp bậc nhân sự (Levels)</span>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {allLevels.map((lvl) => (
                <div key={lvl.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-800 dark:text-slate-200 block">{lvl.name}</span>
                    <span className="text-[11px] text-slate-400 font-mono">Rank Level: {lvl.rank}</span>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] bg-indigo-50 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300 font-mono font-bold">
                    {lvl.code}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB D: ROLES & RBAC SCOPE MATRIX (Section 06) */}
      {activeMainTab === 'roles' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {allRoles.map((role) => (
              <div
                key={role.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs space-y-3"
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-slate-900 dark:text-white truncate">
                    {role.name}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                    {role.defaultScope}
                  </span>
                </div>
                <p className="text-xs text-slate-500 line-clamp-2">
                  {role.description}
                </p>
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
                  <span>Mã vai trò: <strong className="font-mono text-slate-600 dark:text-slate-300">{role.code}</strong></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 04. MODAL TẠO NHÂN VIÊN MỚI (Section 12) */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-2xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-[#002659] text-white flex items-center justify-center font-bold">
                  <Plus className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                    Tạo Nhân Viên &amp; Phân Giải Thành Viên
                  </h3>
                  <span className="text-[11px] text-slate-400 font-mono">
                    CSDL Đích: {currentDbName} (Tự động)
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Họ và tên *
                  </label>
                  <input
                    type="text"
                    value={formFullName}
                    onChange={(e) => setFormFullName(e.target.value)}
                    placeholder="Nguyễn Văn A"
                    required
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-[#002659]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Email công ty *
                  </label>
                  <input
                    type="email"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="vana.sales@apluscorp.vn"
                    required
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-[#002659]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Số điện thoại
                  </label>
                  <input
                    type="text"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="0912 345 678"
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-[#002659]"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Mã số nhân viên (Tùy chọn)
                  </label>
                  <input
                    type="text"
                    value={formEmpCode}
                    onChange={(e) => setFormEmpCode(e.target.value)}
                    placeholder="Ví dụ: 0001"
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono focus:outline-hidden focus:border-[#002659]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Phòng ban *
                  </label>
                  <select
                    value={formDeptId}
                    onChange={(e) => setFormDeptId(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-[#002659]"
                  >
                    {tenantDepartments.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Chức vụ *
                  </label>
                  <select
                    value={formPosId}
                    onChange={(e) => setFormPosId(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-[#002659]"
                  >
                    {allPositions.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.title}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Cấp độ (Level) *
                  </label>
                  <select
                    value={formLevelId}
                    onChange={(e) => setFormLevelId(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-[#002659]"
                  >
                    {allLevels.map((l) => (
                      <option key={l.id} value={l.id}>
                        {l.name} ({l.code})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Vai trò &amp; Scope *
                  </label>
                  <select
                    value={formRoleId}
                    onChange={(e) => setFormRoleId(e.target.value)}
                    className="w-full h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-[#002659]"
                  >
                    {allRoles.map((r) => (
                      <option key={r.id} value={r.id}>
                        {r.name} [Scope: {r.defaultScope}]
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Auto Resolution Preview (Section 12) */}
              <div className="p-3 bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-xl space-y-1">
                <span className="text-[11px] font-bold text-[#002659] dark:text-sky-300 block">
                  Cơ chế tự động sinh định danh (Section 12):
                </span>
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-600 dark:text-slate-300">
                  <span>Username:</span>
                  <span className="font-bold text-[#002659] dark:text-sky-300">
                    {formDeptId ? (tenantDepartments.find((d) => d.id === formDeptId)?.code || 'DEPT') : 'DEPT'}-{formEmpCode || '0001'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-600 dark:text-slate-300">
                  <span>Display ID:</span>
                  <span className="font-bold text-[#002659] dark:text-sky-300">
                    {currentTenantCode}-{formDeptId ? (tenantDepartments.find((d) => d.id === formDeptId)?.code || 'DEPT') : 'DEPT'}-{formEmpCode || '0001'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-600 dark:text-slate-300">
                  <span>CSDL ánh xạ:</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">
                    {currentDbName}
                  </span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#002659] text-white font-bold hover:bg-[#001f47] cursor-pointer shadow-xs"
                >
                  Tạo Tài Khoản
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 05. MÀN HÌNH CHI TIẾT USER - 5 TABS (Section 13) */}
      {selectedMembership && selectedUserAccount && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-2xs flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5">
            {/* Modal Header Profile (Section 13) */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-3.5">
                <img
                  src={selectedUserAccount.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces'}
                  alt={selectedUserAccount.fullName}
                  className="w-12 h-12 rounded-full object-cover border border-slate-200"
                />
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base font-bold text-slate-900 dark:text-white">
                      {selectedUserAccount.fullName}
                    </h2>
                    <span className="font-mono text-xs font-bold text-[#002659] dark:text-sky-300 bg-sky-100 dark:bg-sky-950 px-2 py-0.5 rounded">
                      {selectedMembership.username}
                    </span>
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-600">
                      <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      Đang hoạt động
                    </span>
                  </div>
                  <div className="text-xs text-slate-500 dark:text-slate-400 flex items-center gap-2 mt-1">
                    <span>Công ty: <strong>{currentCompany?.name}</strong></span>
                    <span>•</span>
                    <span>Phòng: <strong>{selectedDept?.name}</strong></span>
                    <span>•</span>
                    <span>Chức vụ: <strong>{selectedPos?.title || selectedMembership.roleTitle}</strong></span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedMembership(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* 5 Tabs Navigation (Section 13) */}
            <div className="flex border-b border-slate-200 dark:border-slate-800 text-xs font-bold gap-2">
              <button
                type="button"
                onClick={() => setDetailActiveTab('info')}
                className={`pb-2.5 px-3 border-b-2 transition-colors cursor-pointer ${
                  detailActiveTab === 'info'
                    ? 'border-[#002659] text-[#002659] dark:border-sky-400 dark:text-sky-300'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                1. Thông tin
              </button>
              <button
                type="button"
                onClick={() => setDetailActiveTab('permissions')}
                className={`pb-2.5 px-3 border-b-2 transition-colors cursor-pointer ${
                  detailActiveTab === 'permissions'
                    ? 'border-[#002659] text-[#002659] dark:border-sky-400 dark:text-sky-300'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                2. Quyền truy cập &amp; Scope
              </button>
              <button
                type="button"
                onClick={() => setDetailActiveTab('activity')}
                className={`pb-2.5 px-3 border-b-2 transition-colors cursor-pointer ${
                  detailActiveTab === 'activity'
                    ? 'border-[#002659] text-[#002659] dark:border-sky-400 dark:text-sky-300'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                3. Hoạt động
              </button>
              <button
                type="button"
                onClick={() => setDetailActiveTab('devices')}
                className={`pb-2.5 px-3 border-b-2 transition-colors cursor-pointer ${
                  detailActiveTab === 'devices'
                    ? 'border-[#002659] text-[#002659] dark:border-sky-400 dark:text-sky-300'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                4. Thiết bị đăng nhập
              </button>
              <button
                type="button"
                onClick={() => setDetailActiveTab('history')}
                className={`pb-2.5 px-3 border-b-2 transition-colors cursor-pointer ${
                  detailActiveTab === 'history'
                    ? 'border-[#002659] text-[#002659] dark:border-sky-400 dark:text-sky-300'
                    : 'border-transparent text-slate-500 hover:text-slate-800'
                }`}
              >
                5. Lịch sử thay đổi
              </button>
            </div>

            {/* TAB 1: THÔNG TIN (Admin được sửa ID và Email) */}
            {detailActiveTab === 'info' && (
              <div className="space-y-4 text-xs">
                {/* Thanh công cụ phân quyền Admin */}
                <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-amber-500" />
                    <div>
                      <span className="font-bold text-slate-800 dark:text-slate-100 block">
                        Đặc Quyền Quản Trị Viên (Admin)
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Cá nhân bị khóa quyền sửa ID và Email. Chỉ Admin mới được can thiệp sửa đổi tại đây.
                      </span>
                    </div>
                  </div>
                  {!isEditingUser ? (
                    <button
                      type="button"
                      onClick={handleStartEditUser}
                      className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-1.5 cursor-pointer shadow-2xs"
                    >
                      <Edit className="w-3.5 h-3.5" />
                      <span>Chỉnh sửa ID &amp; Email</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => setIsEditingUser(false)}
                      className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold cursor-pointer"
                    >
                      Hủy bỏ
                    </button>
                  )}
                </div>

                {!isEditingUser ? (
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-1">
                      <span className="text-slate-400 text-[11px] block">Mã định danh hệ thống (UUID):</span>
                      <span className="font-mono text-slate-700 dark:text-slate-300 select-all block truncate">
                        {selectedUserAccount.id}
                      </span>
                    </div>
                    <div className="p-3 bg-blue-50/60 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-xl space-y-1">
                      <span className="text-slate-500 text-[11px] block font-semibold">Display ID Doanh nghiệp (Mã NV):</span>
                      <span className="font-mono font-bold text-sm text-[#002659] dark:text-sky-300 block">
                        {selectedMembership.displayId}
                      </span>
                    </div>
                    <div className="p-3 bg-blue-50/60 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 rounded-xl space-y-1">
                      <span className="text-slate-500 text-[11px] block font-semibold">Email đăng nhập:</span>
                      <span className="font-medium text-sm text-slate-900 dark:text-white block">
                        {selectedUserAccount.email}
                      </span>
                    </div>
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-1">
                      <span className="text-slate-400 text-[11px] block">CSDL đang kết nối:</span>
                      <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 block">
                        {currentDbName} (Cách ly 100%)
                      </span>
                    </div>
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-1">
                      <span className="text-slate-400 text-[11px] block">Số điện thoại liên hệ:</span>
                      <span className="font-medium text-slate-800 dark:text-slate-200 block">
                        {selectedUserAccount.phone || 'Chưa cập nhật'}
                      </span>
                    </div>
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-1">
                      <span className="text-slate-400 text-[11px] block">Phòng ban:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                        {selectedDept?.name || 'Chưa phân bổ'}
                      </span>
                    </div>
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-1">
                      <span className="text-slate-400 text-[11px] block">Ngày tham gia Tenant:</span>
                      <span className="text-slate-800 dark:text-slate-200 block">
                        {selectedMembership.joinedAt}
                      </span>
                    </div>
                    <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl space-y-1">
                      <span className="text-slate-400 text-[11px] block">Cấp bậc (Level):</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                        {allLevels.find((l) => l.id === selectedMembership.levelId)?.name || 'Nhân viên'}
                      </span>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleSaveUserByAdmin} className="p-4 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/30 dark:bg-blue-950/20 space-y-3">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="font-bold text-slate-800 dark:text-slate-200 block mb-1">
                          Display ID / Mã định danh nhân viên *
                        </label>
                        <input
                          type="text"
                          value={editDisplayId}
                          onChange={(e) => setEditDisplayId(e.target.value)}
                          required
                          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                        />
                        <span className="text-[10px] text-slate-400 mt-0.5 block">Ví dụ: APLUS-SALE-0001 hoặc SALE-0001</span>
                      </div>

                      <div>
                        <label className="font-bold text-slate-800 dark:text-slate-200 block mb-1">
                          Email đăng nhập chính *
                        </label>
                        <input
                          type="email"
                          value={editEmail}
                          onChange={(e) => setEditEmail(e.target.value)}
                          required
                          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                        />
                        <span className="text-[10px] text-slate-400 mt-0.5 block">Dùng làm tài khoản đăng nhập CRM</span>
                      </div>

                      <div>
                        <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                          Họ và tên *
                        </label>
                        <input
                          type="text"
                          value={editFullName}
                          onChange={(e) => setEditFullName(e.target.value)}
                          required
                          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                        />
                      </div>

                      <div>
                        <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                          Số điện thoại
                        </label>
                        <input
                          type="text"
                          value={editPhone}
                          onChange={(e) => setEditPhone(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                        />
                      </div>

                      <div>
                        <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                          Phòng ban
                        </label>
                        <select
                          value={editDeptId}
                          onChange={(e) => setEditDeptId(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                        >
                          {tenantDepartments.map((d) => (
                            <option key={d.id} value={d.id}>{d.name} ({d.code})</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                          Vai trò &amp; Quyền
                        </label>
                        <select
                          value={editRoleId}
                          onChange={(e) => setEditRoleId(e.target.value)}
                          className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                        >
                          {allRoles.map((r) => (
                            <option key={r.id} value={r.id}>{r.name} [{r.defaultScope}]</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-700">
                      <button
                        type="button"
                        onClick={() => setIsEditingUser(false)}
                        className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-600 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold cursor-pointer"
                      >
                        Hủy
                      </button>
                      <button
                        type="submit"
                        className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold cursor-pointer shadow-xs"
                      >
                        Lưu Cập Nhật Tài Khoản
                      </button>
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* TAB 2: QUYỀN TRUY CẬP & SCOPE (Section 13) */}
            {detailActiveTab === 'permissions' && (
              <div className="space-y-4 text-xs">
                <div className="flex items-center justify-between p-3 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900">
                  <div>
                    <span className="font-bold text-[#002659] dark:text-sky-300 block">
                      Vai trò: {selectedRole?.name || selectedMembership.roleTitle}
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Phạm vi truy cập mặc định: <strong>{selectedRole?.defaultScope || 'OWN'}</strong>
                    </span>
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-[#002659] text-white font-mono font-bold text-[11px]">
                    SCOPE: {selectedRole?.defaultScope || 'OWN'}
                  </span>
                </div>

                <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 font-bold text-slate-600 dark:text-slate-300">
                      <tr>
                        <th className="py-2.5 px-3">Module CRM</th>
                        <th className="py-2.5 px-2 text-center">Xem</th>
                        <th className="py-2.5 px-2 text-center">Tạo</th>
                        <th className="py-2.5 px-2 text-center">Sửa</th>
                        <th className="py-2.5 px-2 text-center">Xóa</th>
                        <th className="py-2.5 px-3 text-right">Phạm vi (Scope)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {['Customer', 'Lead', 'Deal', 'Product', 'Report', 'Settings'].map((mod) => {
                        const hasPerm = selectedMembership.permissions.find((p) => p.module === mod);
                        const scope = hasPerm?.scope || selectedRole?.defaultScope || 'OWN';
                        const canView = hasPerm ? hasPerm.actions.includes('view') : true;
                        const canCreate = hasPerm ? hasPerm.actions.includes('create') : mod !== 'Settings';
                        const canEdit = hasPerm ? hasPerm.actions.includes('edit') : mod !== 'Settings';
                        const canDelete = hasPerm ? hasPerm.actions.includes('delete') : false;

                        return (
                          <tr key={mod} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                            <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                              {mod === 'Customer' ? 'Khách hàng' : mod === 'Lead' ? 'Leads' : mod === 'Deal' ? 'Cơ hội (Deals)' : mod === 'Product' ? 'Sản phẩm' : mod === 'Report' ? 'Báo cáo' : 'Cài đặt'}
                            </td>
                            <td className="py-2.5 px-2 text-center text-emerald-600 font-bold">{canView ? '✓' : '✕'}</td>
                            <td className="py-2.5 px-2 text-center text-emerald-600 font-bold">{canCreate ? '✓' : '✕'}</td>
                            <td className="py-2.5 px-2 text-center text-emerald-600 font-bold">{canEdit ? '✓' : '✕'}</td>
                            <td className="py-2.5 px-2 text-center font-bold text-slate-400">{canDelete ? '✓' : '✕'}</td>
                            <td className="py-2.5 px-3 text-right">
                              <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                                {scope}
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* TAB 3: HOẠT ĐỘNG */}
            {detailActiveTab === 'activity' && (
              <div className="space-y-3 text-xs">
                {[
                  { action: 'Đăng nhập thành công qua Subdomain aplus.crm.aplus.vn', time: '10 phút trước', badge: 'Auth' },
                  { action: 'Cập nhật tiến độ Cơ hội Deal: Hợp đồng triển khai A+', time: '1 giờ trước', badge: 'Deal' },
                  { action: 'Tiếp nhận Lead mới: Công ty TNHH Giải Pháp Việt', time: 'Hôm nay 09:30', badge: 'Lead' },
                  { action: 'Đổi mật khẩu tài khoản cá nhân', time: '3 ngày trước', badge: 'Security' },
                ].map((act, i) => (
                  <div key={i} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block">{act.action}</span>
                      <span className="text-[10px] text-slate-400 mt-0.5 block">{act.time}</span>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 font-mono">
                      {act.badge}
                    </span>
                  </div>
                ))}
              </div>
            )}

            {/* TAB 4: THIẾT BỊ ĐĂNG NHẬP */}
            {detailActiveTab === 'devices' && (
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl border border-emerald-200 bg-emerald-50/50 dark:bg-emerald-950/30 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Laptop className="w-5 h-5 text-emerald-600" />
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block">
                        Chrome 122 • Windows 11 (Thiết bị hiện tại)
                      </span>
                      <span className="text-[11px] text-slate-500 font-mono">
                        IP: 113.190.234.12 • Hà Nội, Việt Nam
                      </span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                    Online
                  </span>
                </div>

                <div className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/60 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Smartphone className="w-5 h-5 text-slate-500" />
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                        Safari Mobile • iPhone 15 Pro Max
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">
                        IP: 14.162.155.88 • Hoạt động 2 ngày trước
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => showToast('Đăng xuất thành công', 'Đã hủy phiên làm việc trên thiết bị này.', 'info')}
                    className="text-rose-600 hover:underline text-[11px] font-semibold cursor-pointer"
                  >
                    Đăng xuất
                  </button>
                </div>
              </div>
            )}

            {/* TAB 5: LỊCH SỬ THAY ĐỔI */}
            {detailActiveTab === 'history' && (
              <div className="space-y-3 text-xs">
                {[
                  { desc: 'Gán vai trò Sales Executive và cấu hình Scope OWN', actor: 'Admin Hệ thống', time: '2026-01-15 08:30' },
                  { desc: 'Khởi tạo Membership trong Tenant APLUS (DB_APLUS)', actor: 'Hệ thống tự động', time: '2026-01-15 08:00' },
                ].map((item, i) => (
                  <div key={i} className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl flex items-center justify-between">
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block">{item.desc}</span>
                      <span className="text-[10px] text-slate-400 mt-0.5 block">Thực hiện bởi: {item.actor}</span>
                    </div>
                    <span className="font-mono text-[10px] text-slate-400">{item.time}</span>
                  </div>
                ))}
              </div>
            )}

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedMembership(null)}
                className="px-4 py-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700 font-bold text-xs cursor-pointer"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
