export type UserRole = 
  | 'Super Admin' 
  | 'Admin'
  | 'Director'
  | 'Technical Manager'
  | 'Sales Manager' 
  | 'Sales Staff' 
  | 'Tenant Admin' 
  | 'Customer Care Staff' 
  | 'Warehouse Staff'
  | 'Logistics Staff'
  | 'Technical Staff'
  | 'Accountant'
  | 'HR Staff';

export type LanguageCode = 'vi' | 'en' | 'ja';

export type ThemePreset =
  | 'corporate-blue'
  | 'pastel-rose'
  | 'pastel-emerald'
  | 'pastel-amber'
  | 'pastel-purple'
  | 'pastel-cyan'
  | 'pastel-coral'
  | 'pastel-teal'
  | 'pastel-indigo'
  | 'modern-dark'
  | 'glassmorphism';

export type ActiveModule =
  | 'dashboard'
  | 'reports'
  | 'inventory'
  | 'inventory-overview'
  | 'inventory-stock-in'
  | 'inventory-stock-out'
  | 'inventory-history'
  | 'inventory-expiry'
  | 'sales'
  | 'logistics'
  | 'logistics-order-approval'
  | 'logistics-stock-out'
  | 'logistics-delivery-notes'
  | 'logistics-shipments'
  | 'logistics-handover'
  | 'logistics-cod-collections'
  | 'logistics-purchase-orders'
  | 'logistics-purchase-invoices'
  | 'logistics-stock-in'
  | 'logistics-payment-requests'
  | 'logistics-stock-history'
  | 'logistics-approaching-expiry'
  | 'logistics-document-expiry'
  | 'accounting'
  | 'accounting-debt'
  | 'accounting-invoices'
  | 'accounting-transactions'
  | 'accounting-reports'
  | 'technical'
  | 'technical-customers'
  | 'technical-directory'
  | 'technical-quotations'
  | 'technical-contracts'
  | 'technical-master-planning'
  | 'technical-payment-requests'
  | 'technical-warranty-stock-out'
  | 'technical-expiring-contracts'
  | 'hr'
  | 'hr-staff'
  | 'hr-insurance'
  | 'settings'
  | 'settings-users'
  | 'settings-permissions'
  | 'settings-system'
  | 'settings-app'
  | 'settings-dictionary'
  | 'settings-directories'
  | 'settings-sync-logs'
  | 'sales-overview'
  | 'sales-revenue'
  | 'sales-forecast'
  | 'sales-funnel'
  | 'sales-won'
  | 'sales-lost'
  | 'sales-productivity'
  | 'sales-leads'
  | 'reports-inventory'
  | 'reports-logistics'
  | 'reports-accounting'
  | 'reports-technical'
  | 'reports-hr'
  | 'okr'
  | 'leads'
  | 'contacts'
  | 'customers'
  | 'opportunities'
  | 'quotations'
  | 'sales-orders'
  | 'contracts'
  | 'sales-invoices'
  | 'sales-receipts'
  | 'sales-activities'
  | 'customer-care'
  | 'automation'
  | 'specifications'
  | 'tasks'
  | 'calendar'
  | 'my-profile'
  | 'notifications-center'
  | 'system-architecture'
  | 'platform-admin';

export interface KeyResult {
  id: string;
  title: string;
  metricType: 'currency' | 'number' | 'percentage';
  targetValue: number;
  currentActual: number;
  unit: string;
  autoSyncKey?: 'revenue' | 'pipeline' | 'leads' | 'conversion' | 'won_deals' | 'open_deals';
  owner: string;
  dueDate: string;
  weight?: number; // % importance in Objective
}

export interface OKRObjective {
  id: string;
  code: string;
  title: string;
  category: 'Company' | 'Sales' | 'Marketing' | 'Customer Care';
  quarter: 'Q1' | 'Q2' | 'Q3' | 'Q4' | 'Year';
  year: number;
  owner: string;
  ownerAvatar?: string;
  status: 'on_track' | 'exceeded' | 'behind' | 'at_risk';
  keyResults: KeyResult[];
}

export interface OKRTargetConfig {
  periodId: string;
  quarter: string;
  year: number;
  targetRevenue: number;
  targetPipeline: number;
  targetLeads: number;
  targetConversionRate: number;
  targetWonDeals: number;
  targetOpenDeals: number;
  notes?: string;
}

export interface Tenant {
  id: string;
  code: string;
  name: string;
  domain: string;
  taxId: string;
  currency: string;
  timezone: string;
  plan: 'Enterprise Plus' | 'Business Pro' | 'Standard';
  maxUsers: number;
  activeUsers: number;
  logoUrl?: string;
  status: 'active' | 'suspended' | 'trial';
}

export interface User {
  id: string;
  tenantId: string;
  fullName: string;
  email: string;
  phone: string;
  role: UserRole;
  department: string;
  avatar: string;
  status: 'active' | 'inactive' | 'locked';
  lastLogin: string;
  createdAt: string;
}

export type PermissionAction = 'view' | 'create' | 'edit' | 'delete' | 'export' | 'approve';

export interface RolePermissionConfig {
  role: UserRole;
  permissions: {
    [module in ActiveModule]?: PermissionAction[];
  };
}

export interface Lead {
  id: string;
  tenantId: string;
  code: string;
  fullName: string;
  title: string;
  company: string;
  email: string;
  phone: string;
  source: 'Website' | 'Facebook' | 'Zalo' | 'Referral' | 'Exhibition' | 'Cold Call';
  status: 'Mới' | 'Đang liên hệ' | 'Đạt chuẩn' | 'Không tiềm năng' | 'Đã chuyển đổi';
  score: number; // 0 - 100
  estimatedValue: number;
  assignedTo: string; // User fullName
  assignedToId: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}

export interface Contact {
  id: string;
  tenantId: string;
  code: string;
  fullName: string;
  company: string;
  title: string;
  email: string;
  phone: string;
  type: 'Khách hàng VIP' | 'Khách hàng thân thiết' | 'Khách hàng mới' | 'Đối tác';
  address: string;
  city: string;
  dealsCount: number;
  totalSpent: number;
  assignedTo: string;
  createdAt: string;
}

export type OpportunityStage = 
  | 'Khám phá nhu cầu' 
  | 'Báo giá & Đề xuất' 
  | 'Đàm phán' 
  | 'Thành công (Won)' 
  | 'Thất bại (Lost)';

export interface Opportunity {
  id: string;
  tenantId: string;
  code: string;
  title: string;
  contactName: string;
  company: string;
  stage: OpportunityStage;
  amount: number;
  probability: number; // %
  expectedCloseDate: string;
  assignedTo: string;
  leadSource: string;
  priority: 'Cao' | 'Trung bình' | 'Thấp';
  createdAt: string;
}

export interface QuotationItem {
  id: string;
  productId: string;
  productName: string;
  sku: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  discountPercent: number;
  total: number;
}

export interface Quotation {
  id: string;
  tenantId: string;
  code: string;
  title: string;
  opportunityCode?: string;
  customerName: string;
  customerCompany: string;
  customerEmail: string;
  customerPhone: string;
  taxRate: number; // 8% or 10%
  subTotal: number;
  discountTotal: number;
  taxTotal: number;
  grandTotal: number;
  status: 'Bản nháp' | 'Chờ phê duyệt' | 'Đã gửi' | 'Được chấp thuận' | 'Từ chối';
  validUntil: string;
  createdByName: string;
  items: QuotationItem[];
  paymentTerms: string;
  notes: string;
  createdAt: string;
}

export interface Contract {
  id: string;
  tenantId: string;
  contractNumber: string;
  title: string;
  customerName: string;
  quotationCode?: string;
  totalValue: number;
  startDate: string;
  endDate: string;
  status: 'Đang soạn thảo' | 'Chờ ký duyệt' | 'Đang hiệu lực' | 'Sắp hết hạn' | 'Đã hoàn tất' | 'Đã hủy';
  signedDate?: string;
  paymentMilestones: {
    title: string;
    percentage: number;
    amount: number;
    dueDate: string;
    isPaid: boolean;
  }[];
  manager: string;
  createdAt: string;
}

export interface Ticket {
  id: string;
  tenantId: string;
  ticketNumber: string;
  customerName: string;
  customerPhone: string;
  channel: 'Hotline' | 'Email' | 'Zalo OA' | 'Cổng Khách Hàng' | 'Trực tiếp';
  subject: string;
  description: string;
  priority: 'P1 - Khẩn cấp' | 'P2 - Cao' | 'P3 - Trung bình' | 'P4 - Thấp';
  status: 'Mới tạo' | 'Đang xử lý' | 'Chờ khách hàng' | 'Đã giải quyết' | 'Đóng ticket';
  assignedTo: string;
  slaMinutesRemaining: number;
  csatScore?: number; // 1 - 5
  createdAt: string;
  updatedAt: string;
}

export interface Product {
  id: string;
  tenantId: string;
  sku: string;
  name: string;
  category: 'Thiết bị công nghệ' | 'Phần mềm & Bản quyền' | 'Dịch vụ tư vấn' | 'Vật tư tiêu hao' | 'Linh kiện điện tử';
  unit: string;
  costPrice: number;
  sellingPrice: number;
  stockHanoi: number;
  stockDanang: number;
  stockHCM: number;
  minSafeStock: number;
  status: 'Đang kinh doanh' | 'Sắp hết hàng' | 'Ngừng phân phối';
}

export interface InventoryTransaction {
  id: string;
  tenantId: string;
  txCode: string;
  type: 'Nhập kho' | 'Xuất kho' | 'Chuyển kho nội bộ' | 'Kiểm kê điều chỉnh';
  warehouse: 'Kho Hà Nội' | 'Kho Đà Nẵng' | 'Kho TP.HCM';
  productName: string;
  sku: string;
  quantity: number;
  unit: string;
  performedBy: string;
  reason: string;
  createdAt: string;
}

export type ThemeMode = 'light' | 'dark' | 'system';
export type AccentColor = 'amber' | 'blue' | 'emerald' | 'purple' | 'ruby';
export type FontSizePreference = 'small' | 'medium' | 'large';
export type TableDensityPreference = 'relaxed' | 'normal' | 'compact';
export type ProfileTab = 'personal' | 'security' | 'appearance' | 'notifications' | 'activity';

export interface UserPreferences {
  themeMode: ThemeMode;
  accentColor: AccentColor;
  fontSize: FontSizePreference;
  tableDensity: TableDensityPreference;
  defaultSidebarOpen: boolean;
  startupPage: string;
  rowsPerPage: 10 | 25 | 50 | 100;
  dateFormat: 'DD/MM/YYYY' | 'YYYY-MM-DD';
  numberFormat: 'vi-VN' | 'en-US';
  timezone: string;
  language: LanguageCode;
  notificationChannels: {
    ordersAndApprovals: boolean;
    shippingAndLogistics: boolean;
    warehouseAndInventory: boolean;
    technicalAndWarranty: boolean;
    debtsAndPayments: boolean;
    hrAndStaff: boolean;
    systemAlerts: boolean;
    showBadgeOnBell: boolean;
    playSound: boolean;
  };
}

export interface NotificationItem {
  id: string;
  recipientId?: string;
  tenantId?: string;
  title: string;
  message: string;
  type: 'order' | 'approval' | 'rejection' | 'return' | 'task' | 'comment' | 'lead' | 'quote' | 'sla' | 'contract' | 'inventory' | 'security';
  timestamp: string;
  createdAt?: string; // ISO date format for 90-day retention
  read: boolean;
  linkModule?: ActiveModule;
  entityId?: string;
  senderName?: string;
  senderAvatar?: string;
}

export interface AuditLog {
  id: string;
  tenantId: string;
  timestamp: string;
  userName: string;
  userRole: UserRole;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'LOGIN' | 'EXPORT' | 'PERMISSION_CHANGE' | 'APPROVE';
  entity: string;
  entityId: string;
  ipAddress: string;
  details: string;
  status: 'SUCCESS' | 'WARNING' | 'FAILED';
}

export interface ActivityLog {
  id: string;
  timestamp: string;
  userName: string;
  userAvatar: string;
  actionSummary: string;
  module: ActiveModule;
  timeAgo: string;
}

export interface CustomThemeSettings {
  primaryColor: string; // hex
  borderRadius: 'sm' | 'md' | 'lg' | 'xl' | 'full';
  density: 'compact' | 'comfortable' | 'spacious';
  fontFamily: 'Roboto' | 'Inter' | 'JetBrains Mono';
  sidebarStyle: 'solid' | 'transparent' | 'gradient';
}

export type ReportDateRangePreset = 'today' | 'week' | 'month' | 'quarter' | 'year' | 'custom';

export interface ReportFilterState {
  dateRangePreset: ReportDateRangePreset;
  customStartDate?: string;
  customEndDate?: string;
  salesRepId: string; // 'all' or specific rep id
  teamId: string; // 'all' or specific team id
  productId: string; // 'all' or product id
  region: string; // 'all' | 'Miền Bắc' | 'Miền Trung' | 'Miền Nam'
  source: string; // 'all' | 'Facebook' | 'Zalo' | 'Website' | 'Giới thiệu' | 'Hotline' | 'Triển lãm' | 'Khác'
  viewRole: 'director' | 'manager' | 'rep'; // view perspective
}

export interface SavedReportFilter {
  id: string;
  name: string;
  filters: ReportFilterState;
  createdAt: string;
}

