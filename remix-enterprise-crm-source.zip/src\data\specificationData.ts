export interface SpecSection {
  id: string;
  number: number;
  titleVi: string;
  titleEn: string;
  category: 'architecture' | 'ux-flow' | 'security' | 'components' | 'system';
  summaryVi: string;
  summaryEn: string;
  contentMarkdownVi: string;
  contentMarkdownEn: string;
}

export interface ScreenSpecDetail {
  code: string;
  nameVi: string;
  nameEn: string;
  purposeVi: string;
  purposeEn: string;
  uiLayoutVi: string;
  uiLayoutEn: string;
  userActionsVi: string[];
  userActionsEn: string[];
  componentsVi: string[];
  componentsEn: string[];
  dataFields: {
    field: string;
    labelVi: string;
    labelEn: string;
    type: string;
    required: boolean;
    validation: string;
  }[];
  validationRulesVi: string[];
  validationRulesEn: string[];
  apiIntegration: {
    endpoint: string;
    method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
    descriptionVi: string;
    descriptionEn: string;
    samplePayload?: string;
  }[];
  permissionRulesVi: string[];
  permissionRulesEn: string[];
  mobileResponsiveRulesVi: string[];
  mobileResponsiveRulesEn: string[];
}

export const SPEC_SECTIONS: SpecSection[] = [
  {
    id: 'sitemap',
    number: 1,
    titleVi: '1. Sơ đồ Trang web (Sitemap)',
    titleEn: '1. Sitemap Hierarchy',
    category: 'architecture',
    summaryVi: 'Cây phân cấp cấu trúc điều hướng toàn diện cho nền tảng A+ Enterprise CRM đa doanh nghiệp với mô hình Quản trị Nền tảng (Platform Core) và Không gian Doanh nghiệp Độc lập (Tenant Workspaces).',
    summaryEn: 'Comprehensive hierarchical site tree for A+ Enterprise CRM multi-tenant platform and isolated workspaces.',
    contentMarkdownVi: `### SƠ ĐỒ ĐIỀU HƯỚNG TỔNG THỂ (A+ ENTERPRISE CRM SITEMAP)
\`\`\`text
/ (Root Authentication & Database Router)
│
├── /auth/login (Đăng nhập doanh nghiệp: Mã công ty + Email/Tên đăng nhập + Mật khẩu)
├── /auth/register (Đăng ký Doanh nghiệp mới -> Gửi yêu cầu PENDING tới Super Admin)
├── /auth/join-company (Nhân sự tìm mã doanh nghiệp & Gửi yêu cầu gia nhập)
├── /auth/accept-invite (Kích hoạt tài khoản nhân sự từ Link / Token lời mời)
├── /auth/select-workspace (Chọn Không gian Doanh nghiệp nếu tài khoản thuộc nhiều Tenant)
│
├── /platform (Bảng điều khiển Quản trị Nền tảng Toàn cầu - Super Admin Root)
│   ├── /tenants-registry (Quản trị danh mục Doanh nghiệp & Cấp phát Database)
│   ├── /pending-approvals (Phê duyệt yêu cầu Đăng ký Doanh nghiệp mới & Auto-provision DB)
│   ├── /system-architecture (Sơ đồ Kiến trúc CSDL CRM_CORE & Các DB Tenant độc lập)
│   └── /global-audit (Nhật ký An ninh & Giám sát Tải toàn hệ thống)
│
└── /app/:tenantId/* (Không gian Làm việc Doanh nghiệp Độc lập - VD: DB_APLUS)
    │
    ├── /dashboard (Executive Overview, KPI Cockpit & Phân tích Điều hành)
    │
    ├── /sales (Kinh doanh & Quản trị Bán hàng Toàn diện)
    │   ├── /leads (Khách hàng tiềm năng, Chấm điểm Lead Score, Chuyển đổi Cơ hội)
    │   ├── /customers (Danh bạ Khách hàng & Hồ sơ 360 độ)
    │   ├── /opportunities (Phễu Cơ hội Bán hàng: Kanban kéo thả 5 giai đoạn & Bảng Table)
    │   ├── /quotations (Báo giá thương mại, Bộ tính giá đa dòng, Chiết khấu & Duyệt cấp quản lý)
    │   ├── /contracts (Hợp đồng kinh tế, Quản lý mốc nghiệm thu & Cảnh báo gia hạn)
    │   ├── /activities (Lịch sử cuộc gọi, Nhật ký họp & Chăm sóc định kỳ)
    │   └── /tasks-calendar (Quản lý công việc & Lịch công tác kinh doanh)
    │
    ├── /technical (Khối Kỹ thuật & Dự án Triển khai - TP. Kỹ thuật)
    │   ├── /surveys (Khảo sát hiện trường & Đo đạc công trình)
    │   ├── /bom (Bóc tách Định mức Vật tư & Dự toán Thiết bị)
    │   └── /acceptance (Nghiệm thu Kỹ thuật & Bàn giao Dự án)
    │
    ├── /logistics (Vận hành Kho & Chuỗi Cung ứng)
    │   ├── /inventory (Danh mục Sản phẩm, SKU, Quản lý Tồn kho 3 Chi nhánh Bắc - Trung - Nam)
    │   ├── /stock-in-out (Phiếu Nhập - Xuất - Chuyển kho nội bộ)
    │   └── /delivery (Điều phối vận chuyển & Bàn giao thiết bị)
    │
    ├── /accounting (Tài chính - Kế toán & Dòng tiền)
    │   ├── /debt (Quản trị Công nợ Phải thu / Phải trả khách hàng)
    │   ├── /invoices (Xuất Hóa đơn Điện tử VAT & Đối soát Doanh thu)
    │   └── /cashflow (Sổ quỹ & Báo cáo Dòng tiền Thực thu - Thực chi)
    │
    ├── /hr (Nhân sự & Tổ chức Nội bộ)
    │   ├── /employees (Hồ sơ Nhân sự & Hợp đồng Lao động)
    │   └── /my-profile (Hồ sơ Cá nhân & Đổi mật khẩu)
    │
    ├── /reports (Báo cáo & Phân tích Đa chiều)
    │   ├── /sales-analytics (Doanh thu theo Phòng ban, Xếp hạng Sales Reps & Dự báo Doanh số)
    │   ├── /executive-pnl (Báo cáo P&L & Hiệu quả Dự án dành cho Ban Giám Đốc)
    │   └── /inventory-reports (Báo cáo Vòng quay Hàng tồn & Cảnh báo an toàn)
    │
    └── /settings (Cài đặt Hệ thống Doanh nghiệp - Company Admin)
        ├── /organization (Cơ cấu Tổ chức: Phòng ban, Chức vụ, Cấp bậc & Nhân sự)
        ├── /permissions (Ma trận Nhóm quyền RBAC & Phạm vi Phân quyền Scopes: OWN/TEAM/DEPT/COMPANY)
        ├── /invitations (Tạo Link Lời mời & Phê duyệt Yêu cầu Xin gia nhập)
        ├── /architecture (Sơ đồ Kết nối Database độc lập của Tenant)
        ├── /themes (Bộ máy Giao diện: 10 Templates Doanh nghiệp & Custom Theme Builder)
        └── /specs (Hồ sơ Đặc tả Kỹ thuật Hệ thống 24 Chương Chuẩn hóa)
\`\`\``,
    contentMarkdownEn: `### A+ ENTERPRISE CRM SITEMAP SPECIFICATION
Comprehensive multi-tenant root structure, module routing, nested resources, and parameter mappings across Platform Core and Tenant Workspaces.`,
  },
  {
    id: 'info-architecture',
    number: 2,
    titleVi: '2. Kiến trúc Thông tin (Information Architecture)',
    titleEn: '2. Information Architecture (IA)',
    category: 'architecture',
    summaryVi: 'Mô hình lưu trữ dữ liệu cô lập theo kiến trúc Database-per-Tenant, đảm bảo toàn vẹn dữ liệu và phân tách ranh giới doanh nghiệp tuyệt đối.',
    summaryEn: 'Isolated Database-per-Tenant model with CRM_CORE registry and dedicated physical tenant databases.',
    contentMarkdownVi: `### MÔ HÌNH KIẾN TRÚC DỮ LIỆU A+ ENTERPRISE CRM
1. **Mức độ Cô lập Vật lý (Database-per-Tenant Isolation):**
   - **Control Database (\`CRM_CORE\`):** Quản lý định danh toàn cầu bao gồm Registry danh bạ Tenant, User Accounts toàn nền tảng, Memberships, Yêu cầu đăng ký công ty mới (\`pending_registrations\`) và Nhật ký an ninh hệ thống.
   - **Tenant Databases riêng biệt (\`DB_APLUS\`, \`DB_ABC\`, \`DB_XYZ\`,...):** Mỗi công ty sở hữu một CSDL vật lý độc lập chứa toàn bộ dữ liệu nghiệp vụ: Khách hàng, Báo giá, Hợp đồng, Kho bãi, Kế toán, Kỹ thuật, Lịch sử giao dịch. Tuyệt đối không lưu lẫn dữ liệu giữa các công ty.
2. **Dòng Luân chuyển Dữ liệu Nghiệp vụ (End-to-End Pipeline):**
   \`Tiếp nhận Lead\`
     ➔ Phân công Nhân viên Sales (\`Scope: OWN\`)
     ➔ Chuyển đổi thành \`Contact\` & \`Khách hàng Doanh nghiệp\`
     ➔ Khởi tạo \`Opportunity (Cơ hội bán hàng)\` qua Pipeline 5 bước
     ➔ Phòng Kỹ thuật khảo sát & bóc tách \`BOM Vật tư\` (nếu có dự án kỹ thuật)
     ➔ Phát hành \`Quotation (Báo giá)\` ➔ Trưởng phòng Sale duyệt chiết khấu
     ➔ Ký kết \`Contract (Hợp đồng kinh tế)\`
     ➔ Kế toán mở \`Công nợ & Hóa đơn VAT\`
     ➔ Kho vận xuất \`Phiếu Xuất kho & Giao hàng\`
     ➔ Kích hoạt \`CSKH & Bảo hành định kỳ\`.`,
    contentMarkdownEn: `### INFORMATION ARCHITECTURE SPECIFICATION
Complete physical database boundary isolation with CRM_CORE control cluster and tenant-specific databases.`,
  },
  {
    id: 'user-journey',
    number: 3,
    titleVi: '3. Hành trình Người dùng & Phân cấp Vai trò (User Journeys)',
    titleEn: '3. User Journeys by Role',
    category: 'ux-flow',
    summaryVi: 'Quy trình trải nghiệm người dùng được cá nhân hóa chặt chẽ theo 5 vai trò hạt nhân và các vai trò mở rộng trong hệ thống A+ Enterprise CRM.',
    summaryEn: 'End-to-end journey maps for all 5 enterprise personas from platform root to operational daily tasks.',
    contentMarkdownVi: `### HÀNH TRÌNH CÁC VAI TRÒ CHÍNH (5 TÀI KHOẢN MẪU THỰC TẾ)
- **Super Admin Nền tảng (Nguyễn Khắc Huy):** Truy cập \`/platform\` ➔ Thẩm định các yêu cầu Đăng ký Doanh nghiệp mới (VD: APLUS) ➔ Bấm Duyệt ➔ Tự động kích hoạt Provisioning Database (\`DB_APLUS\`) và cấp tài khoản Admin công ty ➔ Giám sát hạ tầng và Audit Log toàn hệ thống.
- **Admin Doanh nghiệp (Nguyễn Nhật Thanh):** Toàn quyền quản trị \`tenant_aplus\` (\`DB_APLUS\`) ➔ Thiết lập cơ cấu tổ chức (Phòng ban, Chức vụ, Cấp bậc) ➔ Tạo tài khoản nhân sự hoặc phát hành Link lời mời / Duyệt yêu cầu xin gia nhập ➔ Gán vai trò RBAC và thiết lập Scope phạm vi dữ liệu (OWN/TEAM/DEPT/COMPANY) ➔ Cấu hình thương hiệu và Theme.
- **Ban Giám Đốc (Hồ Minh Châu):** Quyền xem toàn diện cấp Doanh nghiệp (\`Scope: COMPANY\`) ➔ Xem Executive Dashboard & KPI Cockpit thời gian thực (Doanh thu, P&L, Pipeline, Hợp đồng lớn) ➔ Truy cập Báo cáo điều hành và ra quyết định chiến lược.
- **Trưởng Phòng Sale (Hồ Hoàng Long):** Toàn quyền quản trị phòng Kinh Doanh (\`Scope: DEPARTMENT\`) ➔ Theo dõi Dashboard doanh số phòng và KPI của từng nhân viên ➔ Phân bổ Leads mới ➔ Phê duyệt Báo giá chiết khấu ➔ Giám sát Pipeline và xem 8 báo cáo phân tích chuyên sâu của phòng Sale.
- **Nhân Viên Sale (Nguyễn Văn A):** Chỉ xem và thao tác trên tập dữ liệu được phân bổ (\`Scope: OWN\`) ➔ Khai thác danh sách Lead cá nhân, gọi điện tư vấn ➔ Chuyển đổi thành Cơ hội trên Kanban ➔ Tạo Báo giá gửi Trưởng phòng duyệt ➔ Theo dõi tiến độ Hợp đồng và hoa hồng cá nhân.`,
    contentMarkdownEn: `### DETAILED USER PERSONA JOURNEYS
Journey mapping across 5 distinct enterprise user archetypes (Platform Super Admin, Company Admin, Board Director, Sales Manager, Sales Staff).`,
  },
  {
    id: 'navigation-structure',
    number: 4,
    titleVi: '4. Cấu trúc Điều hướng (Navigation Structure)',
    titleEn: '4. Navigation Structure',
    category: 'ux-flow',
    summaryVi: 'Mô hình điều hướng đa cấp: Global Header, Sub-navigation, Tab bars, và Breadcrumbs.',
    summaryEn: 'Multi-level navigation model including header bar, context breadcrumbs, and tabs.',
    contentMarkdownVi: `### CẤU TRÚC ĐIỀU HƯỚNG ĐA TẦNG
1. **Global Header:**
   - Bộ chọn Doanh nghiệp (Tenant Selector)
   - Bộ giả lập Vai trò (Role Switcher dùng cho kiểm thử nhanh)
   - Chuyển đổi Ngôn ngữ (VI / EN)
   - Chuyển đổi Giao diện (10 Templates & Dark Mode Toggle)
   - Trung tâm thông báo đẩy (Notification Dropdown)
   - Nút bật nhanh "Xem Đặc tả Kỹ thuật (Screen Spec)"
2. **Breadcrumb Hierarchy:**
   - \`Trang chủ / Module / Mã bản ghi / Tác vụ chi tiết\`
3. **Tab Panels:**
   - Tabs chuyển đổi Dạng xem (Kanban vs Table tại Opportunities)
   - Tabs danh mục cấu hình hệ thống tại Settings (7 sub-tabs).`,
    contentMarkdownEn: `### MULTI-TIER NAVIGATION SPECIFICATION
Header controllers, role switchers, tenant isolation switchers, breadcrumb generators, and nested tab navigation.`,
  },
  {
    id: 'sidebar-menu',
    number: 5,
    titleVi: '5. Cấu trúc Menu Sidebar (Sidebar Structure)',
    titleEn: '5. Sidebar Menu Structure',
    category: 'ux-flow',
    summaryVi: 'Phân nhóm menu thanh bên, kiểm soát hiển thị theo vai trò (RBAC) và cơ chế thu gọn/mở rộng.',
    summaryEn: 'Sidebar grouping, dynamic role-based visibility filtering, and collapse state handling.',
    contentMarkdownVi: `### CẤU TRÚC 9 PHÂN HỆ MENU SIDEBAR A+ ENTERPRISE CRM
- **1. Tổng quan (Dashboard):** KPI Cockpit, biểu đồ doanh thu và phễu bán hàng.
- **2. Kinh doanh & Bán hàng (Sales Hub):** Leads, Khách hàng, Cơ hội (Kanban & Table), Báo giá đa dòng, Hợp đồng kinh tế, Hoạt động & Lịch hẹn.
- **3. Khối Kỹ thuật (Technical Projects):** Khảo sát hiện trường, Bóc tách định mức BOM vật tư, Nghiệm thu kỹ thuật.
- **4. Kho vận & Logistics:** Quản lý kho 3 miền (Bắc - Trung - Nam), Phiếu nhập xuất, Điều phối giao vận.
- **5. Tài chính - Kế toán (Accounting):** Công nợ khách hàng, Hóa đơn VAT, Sổ quỹ dòng tiền, Báo cáo tài chính.
- **6. Nhân sự (HR):** Hồ sơ nhân sự doanh nghiệp và Hồ sơ cá nhân.
- **7. Báo cáo & Phân tích (Reports):** Báo cáo Doanh thu, Hiệu suất Sales Reps, P&L Điều hành cho Ban Giám Đốc.
- **8. Cài đặt Hệ thống (Settings):** Cơ cấu tổ chức (Phòng ban/Chức vụ/Cấp bậc), Phân quyền RBAC & Scopes, Bộ nhận diện giao diện.
- **9. Hồ sơ Đặc tả Kỹ thuật (Specifications):** Trung tâm tra cứu 24 chương đặc tả hệ thống và tài liệu kỹ thuật chuẩn A+.`,
    contentMarkdownEn: `### SIDEBAR MENU SPECIFICATION
Grouped accordion sections, icon standards, collapsed icon tooltips, and active state pill highlights.`,
  },
  {
    id: 'header-layout',
    number: 6,
    titleVi: '6. Thiết kế Thanh Đầu trang (Header Layout)',
    titleEn: '6. Header Layout & Controls',
    category: 'ux-flow',
    summaryVi: 'Quy cách bố cục thanh Header: Search nhanh, Tenant dropdown, Role switcher, Theme menu, Chuông thông báo.',
    summaryEn: 'Header component anatomy with search triggers, tenant switchers, role simulators, and notifications.',
    contentMarkdownVi: `### QUY CÁCH HEADER ENTERPRISE
- Chiều cao cố định: \`h-16 (64px)\`.
- Sticky cố định trên đỉnh trình duyệt (\`sticky top-0 z-30\`).
- Hỗ trợ Backdrop Blur kính mờ đối với template Glassmorphism.
- Tích hợp ô tìm kiếm toàn cục (Global Omni-Search) tìm kiếm tức thì theo mã và tên.
- Hiển thị nhãn Tenant đang hoạt động và Vai trò đang giả lập với huy hiệu màu nổi bật.`,
    contentMarkdownEn: `### HEADER COMPONENT SPECIFICATIONS
Fixed height 64px bar with blur backdrop, responsive drawer toggle, tenant switch dropdown, and real-time badge counters.`,
  },
  {
    id: 'dashboard-layout',
    number: 7,
    titleVi: '7. Bố cục Màn hình Dashboard (Dashboard Layout)',
    titleEn: '7. Dashboard Layout Architecture',
    category: 'components',
    summaryVi: 'Kiến trúc lưới widget Dashboard: 4 Thẻ KPI chính, Biểu đồ Doanh thu, Phễu bán hàng, Bảng Deal và Cảnh báo SLA.',
    summaryEn: 'Multi-widget cockpit layout featuring KPI metric blocks, revenue SVG charts, and SLA tickets.',
    contentMarkdownVi: `### BỐ CỤC LƯỚI WIDGET DASHBOARD
1. **Hàng 1 (Row 1): 4 Thẻ KPI Metrix (Grid 1x4 trên Desktop, 1x2 trên Tablet, 1x1 trên Mobile)**
   - Tổng doanh thu thực tế (so sánh +14.8% cùng kỳ)
   - Giá trị Pipeline cơ hội đang theo đuổi (8.2 Tỷ VNĐ)
   - Leads mới trong tháng (148 leads, đạt 112% KPI)
   - Tỷ lệ chốt thành công Win Rate (34.5%)
2. **Hàng 2 (Row 2): Biểu đồ phân tích kép (Grid 2 cột 60% / 40%)**
   - Biểu đồ Doanh thu theo tháng & Dự phóng
   - Phễu chuyển đổi bán hàng Sales Funnel 5 tầng
3. **Hàng 3 (Row 3): Giám sát Vận hành & Cảnh báo (Grid 3 cột)**
   - Cơ hội sắp chốt hợp đồng (Closing Soon)
   - Cảnh báo SLA CSKH khẩn cấp (Sắp hết giờ)
   - Cảnh báo Tồn kho chạm ngưỡng an toàn.`,
    contentMarkdownEn: `### DASHBOARD LAYOUT SPECIFICATION
Responsive grid breakdown, widget flex ordering, dynamic KPI cards, and operational urgency monitors.`,
  },
  {
    id: 'screen-list',
    number: 8,
    titleVi: '8. Danh mục Tất cả Màn hình (Screen List)',
    titleEn: '8. Complete Screen Inventory',
    category: 'ux-flow',
    summaryVi: 'Bảng kê danh mục toàn bộ các phân hệ chính (A - L) từ Quản trị Nền tảng tới Không gian Nghiệp vụ Doanh nghiệp.',
    summaryEn: 'Complete catalogue of primary screens A through L across Platform Root and Tenant Workspaces.',
    contentMarkdownVi: `### DANH MỤC MÀN HÌNH CHÍNH
- **Màn hình A:** Dashboard Tổng quan Điều hành Doanh nghiệp
- **Màn hình B:** Quản lý Khách hàng Tiềm năng (Leads Management)
- **Màn hình C:** Danh bạ Khách hàng & Hồ sơ 360 độ (Customers & Contacts)
- **Màn hình D:** Phễu Cơ hội Bán hàng (Opportunities Pipeline - Kanban & Table)
- **Màn hình E:** Quản lý Báo giá & Bộ tính giá đa dòng (Quotations Generator)
- **Màn hình F:** Quản lý Hợp đồng Kinh tế & Mốc Thanh toán (Contracts)
- **Màn hình G:** Quản lý Kỹ thuật, Khảo sát & Dự toán BOM (Technical Projects)
- **Màn hình H:** Quản lý Kho bãi & Chuỗi Cung ứng 3 Miền (Inventory & Depots)
- **Màn hình I:** Báo cáo & Phân tích Đa chiều (BI Reports & P&L)
- **Màn hình J:** Quản trị Doanh nghiệp, Nhân sự & Phân quyền RBAC (Settings & Org)
- **Màn hình K:** Quản trị Nền tảng Toàn cầu dành cho Super Admin (Platform Admin & DB Provisioning)
- **Màn hình L:** Xác thực & Gia nhập Doanh nghiệp (Login, Register, Join Company, Accept Invite)`,
    contentMarkdownEn: `### SYSTEM SCREEN INVENTORY
Comprehensive enumeration of modules A through L, unique screen IDs, parent routes, and authorization levels.`,
  },
  {
    id: 'screen-flow',
    number: 9,
    titleVi: '9. Luồng Màn hình & Chuyển tiếp Nghiệp vụ (Screen Flow)',
    titleEn: '9. Screen Flow & Business Transitions',
    category: 'ux-flow',
    summaryVi: 'Sơ đồ chuyển tiếp nghiệp vụ: Đăng ký doanh nghiệp -> Super Admin duyệt DB -> Phân quyền nhân sự -> Bán hàng khép kín.',
    summaryEn: 'Inter-screen transitions across tenant registration, provisioning, RBAC delegation, and commerce flow.',
    contentMarkdownVi: `### SƠ ĐỒ CHUYỂN TIẾP MÀN HÌNH (SCREEN FLOW DIAGRAM)
\`\`\`text
[Dashboard] ──(Click Lead Alert)──> [Leads List]
                                        │
                                  (Click "Chuyển đổi")
                                        ▼
                                [Opportunities Pipeline]
                                        │
                                  (Click "Tạo Báo Giá")
                                        ▼
                                 [Quotation Form]
                                        │
                                (Khách duyệt Báo giá)
                                        ▼
                                [Contract Creation]
                                        │
                                (Ký kết Hợp đồng)
                                  ┌─────┴─────┐
                                  ▼           ▼
                         [Kho xuất hàng] [Ticket Bảo hành]
\`\`\``,
    contentMarkdownEn: `### SCREEN FLOW TRANSITION SPECIFICATION
Visual and state transitions across customer lifecycle stages from lead intake to warranty ticket generation.`,
  },
  {
    id: 'rbac-matrix',
    number: 10,
    titleVi: '10. Ma trận Phân quyền & Phạm vi Scopes (Permissions Matrix)',
    titleEn: '10. RBAC & Data Scopes Matrix',
    category: 'security',
    summaryVi: 'Ma trận phân quyền kết hợp giữa Vai trò Nghiệp vụ (RBAC) và 4 Tầng Phạm vi Dữ liệu (Scopes: OWN, TEAM, DEPARTMENT, COMPANY).',
    summaryEn: 'Granular permissions matrix combining Role-Based Access Control and 4-tier Data Access Scopes.',
    contentMarkdownVi: `### MA TRẬN PHÂN QUYỀN RBAC & SCOPE THEO VAI TRÒ HẠT NHÂN
| Phân hệ / Module | Super Admin (Nền tảng) | Company Admin (Công ty) | Ban Giám Đốc (Director) | Trưởng Phòng Sale (Sale Mgr) | Nhân Viên Sale (Sale Staff) | TP. Kỹ Thuật (Tech Mgr) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Phạm vi mặc định** | SYSTEM / ROOT | COMPANY | COMPANY | DEPARTMENT | OWN | DEPARTMENT |
| **Bảng điều khiển (Dashboard)** | Xem hạ tầng toàn cầu | Xem toàn công ty | Xem toàn công ty (KPI, P&L) | Xem phòng Kinh doanh | Xem chỉ tiêu cá nhân | Xem khối Kỹ thuật |
| **Khách hàng tiềm năng (Leads)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ | Full phòng Sales | Xem, Tạo, Sửa (Lead của mình) | - |
| **Khách hàng (Customers)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ | Full phòng Sales | Xem, Tạo, Sửa (Khách của mình) | Xem hồ sơ kỹ thuật |
| **Cơ hội (Opportunities)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ | Full phòng Sales | Xem, Tạo, Sửa (Deal của mình) | - |
| **Báo giá (Quotations)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ | Xem, Tạo, Sửa, Duyệt chiết khấu | Xem, Tạo, Sửa (Chờ duyệt) | Xem định mức giá |
| **Hợp đồng (Contracts)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ, Duyệt | Xem, Tạo, Phê duyệt | Xem hợp đồng phụ trách | Xem điều khoản kỹ thuật |
| **Kỹ thuật & Dự toán BOM** | Giám sát Audit | Toàn quyền (Full) | Xem tiến độ dự án | Xem BOM liên quan | - | Toàn quyền (Khảo sát, BOM, NT) |
| **Kho vận (Inventory)** | Giám sát Audit | Toàn quyền (Full) | Xem tồn kho 3 miền | Xem danh mục sản phẩm | Xem tồn khả dụng | Xem vật tư kỹ thuật |
| **Kế toán & Công nợ** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ dòng tiền | Xem công nợ khách của phòng | Xem công nợ khách của mình | - |
| **Cài đặt & Cơ cấu tổ chức** | Quản trị Nền tảng | Toàn quyền cấu hình | Xem cơ cấu | - | - | - |
| **Duyệt Đăng ký Doanh nghiệp** | Toàn quyền độc quyền | - | - | - | - | - |`,
    contentMarkdownEn: `### RBAC ACCESS CONTROL & SCOPE MATRIX
Strict matrix defining privileges and data visibility scopes across all enterprise roles.`,
  },
  {
    id: 'business-workflow',
    number: 11,
    titleVi: '11. Quy trình Nghiệp vụ Khép kín (Business Workflow)',
    titleEn: '11. Closed-Loop Enterprise Workflow',
    category: 'system',
    summaryVi: 'Chu trình khép kín: Đăng ký doanh nghiệp -> Cấp phát Database -> Phân bổ Lead -> Khảo sát kỹ thuật -> Báo giá -> Hợp đồng -> Kho vận -> Kế toán.',
    summaryEn: 'End-to-end commercial sales lifecycle and logistics delivery workflow rules.',
    contentMarkdownVi: `### QUY TRÌNH NGHIỆP VỤ BÁN HÀNG DOANH NGHIỆP (A+ ENTERPRISE WORKFLOW)
1. **Bước 1 - Đăng ký Doanh nghiệp & Provisioning DB:** Chủ doanh nghiệp đăng ký ➔ Super Admin duyệt tại Platform ➔ Tự động sinh Database \`DB_[CODE]\` và cấp tài khoản Company Admin.
2. **Bước 2 - Thu thập & Phân bổ Lead:** Tiếp nhận qua Đa kênh (Web/Zalo/Triển lãm), hệ thống tính điểm Lead Score và tự động gán cho Nhân viên Sale theo Scope OWN.
3. **Bước 3 - Khảo sát Kỹ thuật & Bóc tách BOM:** Với sản phẩm dự án/kỹ thuật, chuyển tiếp yêu cầu sang Phòng Kỹ thuật để khảo sát và lập định mức vật tư BOM.
4. **Bước 4 - Tạo Báo giá & Phê duyệt Quản lý:** Nhân viên Sale lập Báo giá từ danh mục Kho. Các báo giá có mức chiết khấu >10% hoặc giá trị lớn tự động chuyển Trưởng phòng Sale duyệt.
5. **Bước 5 - Ký kết Hợp đồng Kinh tế:** Chuyển đổi báo giá thành Hợp đồng, phân bổ tiến độ thanh toán từng đợt theo mốc nghiệm thu.
6. **Bước 6 - Bàn giao Kho vận & Kế toán:** Kho tạo phiếu xuất hàng, Kế toán đối soát xuất hóa đơn điện tử VAT và theo dõi công nợ.`,
    contentMarkdownEn: `### BUSINESS PROCESS LIFECYCLE
Comprehensive step-by-step state machine from inbound ingestion through fulfillment and SLA post-sale guarantees.`,
  },
  {
    id: 'crud-operations',
    number: 12,
    titleVi: '12. Thao tác Dữ liệu CRUD (CRUD Operations)',
    titleEn: '12. Standardized CRUD Operations',
    category: 'system',
    summaryVi: 'Quy chuẩn Create, Read, Update, Delete đối với toàn bộ các thực thể, bảo toàn liên kết dữ liệu.',
    summaryEn: 'Standardized create, read, update, soft-delete operations and relational constraints.',
    contentMarkdownVi: `### QUY CHUẨN THAO TÁC CRUD
- **Create (Tạo mới):** Tự động sinh mã định danh có tiền tố (\`LEAD-\`, \`OPP-\`, \`BG-\`, \`HD-\`, \`TICK-\`, \`PNK-\`, \`PXK-\`), lưu người tạo và timestamp hiện tại.
- **Read (Truy vấn):** Hỗ trợ lọc theo trạng thái, từ khóa full-text, và phân trang server-side.
- **Update (Cập nhật):** Tự động ghi nhận \`updatedAt\`, tự động lưu vào Activity Feed và ghi nhận sai khác dữ liệu vào Audit Log nếu là hành động nhạy cảm.
- **Delete (Xóa bỏ):** Bắt buộc hiển thị Hộp thoại Xác nhận (Confirmation Modal) cảnh báo hành động sẽ được lưu vào Security Audit Log.`,
    contentMarkdownEn: `### CRUD OPERATION SPECIFICATION
Standardized payloads, optimistic UI updates, validation hooks, and cascade safety rules.`,
  },
  {
    id: 'validation-rules',
    number: 13,
    titleVi: '13. Quy tắc Xác thực Dữ liệu (Validation Rules)',
    titleEn: '13. Form & Data Validation Rules',
    category: 'system',
    summaryVi: 'Quy tắc Regex số điện thoại VN, Email RFC 5322, Mã số thuế 10-13 chữ số, Tiền tệ không âm.',
    summaryEn: 'Comprehensive regex specifications, Vietnamese phone formats, tax ID length, and financial constraints.',
    contentMarkdownVi: `### QUY TẮC VALIDATION PHÍA CLIENT VÀ SERVER
- **Email:** Theo chuẩn RFC 5322 regex: \`^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$\`
- **Số điện thoại Việt Nam:** \`^(0[3|5|7|8|9])+([0-9]{8})$\` (Độ dài đúng 10 chữ số).
- **Mã số thuế doanh nghiệp (Tax ID):** 10 chữ số hoặc 13 chữ số có dấu gạch ngang (VD: 0101245486 hoặc 0314567890-001).
- **Giá tiền & Số lượng:** Số nguyên dương lớn hơn 0, không cho phép nhập số âm.
- **Tỷ lệ phần trăm (%):** Giới hạn từ 0 đến 100.
- **Thời hạn hợp đồng:** \`endDate >= startDate\`.`,
    contentMarkdownEn: `### VALIDATION RULES MATRIX
Field-level schema constraints, synchronous client checks, and server-side duplicate prevention checks.`,
  },
  {
    id: 'error-handling',
    number: 14,
    titleVi: '14. Xử lý Lỗi & Thông báo (Error Handling)',
    titleEn: '14. Error Handling & Feedback Architecture',
    category: 'system',
    summaryVi: 'Chuẩn mã phản hồi HTTP (400, 401, 403, 404, 409, 422, 500) và giao diện Toast thông báo lỗi.',
    summaryEn: 'HTTP status codes, user-friendly toast error alerts, retry mechanisms, and offline state handling.',
    contentMarkdownVi: `### KIẾN TRÚC XỬ LÝ LỖI
1. **Lỗi 400 Bad Request:** Hiển thị thông báo trường dữ liệu bị thiếu hoặc không đúng định dạng.
2. **Lỗi 401 Unauthorized:** Tự động xóa phiên lưu trữ và chuyển hướng về màn hình đăng nhập.
3. **Lỗi 403 Forbidden:** Hiển thị banner cảnh báo: "Bạn không có quyền thực hiện thao tác này theo ma trận RBAC hiện tại".
4. **Lỗi 409 Conflict:** Cảnh báo trùng lặp Email, Mã số thuế hoặc Mã hợp đồng đã tồn tại trong cùng Tenant.
5. **Lỗi 500 Internal Server Error:** Ghi log mã lỗi Trace ID và cung cấp nút "Thử lại (Retry)".`,
    contentMarkdownEn: `### ERROR HANDLING SPECIFICATION
Structured error response protocols, UI error boundary fallback screens, and network interruption handling.`,
  },
  {
    id: 'ui-components',
    number: 15,
    titleVi: '15. Thư viện Thành phần Giao diện (UI Components)',
    titleEn: '15. UI Component Library Architecture',
    category: 'components',
    summaryVi: 'Hệ thống thiết kế theo chuẩn Atomic Design: Atoms, Molecules, Organisms phù hợp TailwindCSS.',
    summaryEn: 'Atomic design hierarchy with Tailwind styling tokens and accessible interactive states.',
    contentMarkdownVi: `### NGUYÊN TẮC THIẾT KẾ COMPONENT
- **Typography:** Phông chữ chính \`Plus Jakarta Sans\`, dữ liệu số và mã SKU dùng \`JetBrains Mono\`.
- **Button Standards:** Primary, Secondary, Outline, Ghost, Danger với các trạng thái Hover, Focus-visible, Disabled, Loading spinner.
- **Badges:** Các huy hiệu phân loại trạng thái có viền mờ và màu nền dịu mắt theo WCAG 2.1 Contrast Ratio.
- **Card Surfaces:** Card có độ bo viền đồng nhất (\`rounded-xl\`), viền mỏng (\`border border-slate-200/90 dark:border-slate-800\`).`,
    contentMarkdownEn: `### UI COMPONENT FOUNDATIONS
Color tokens, typography scale, surface depth, focus ring accessibility, and responsive spacing units.`,
  },
  {
    id: 'reusable-components',
    number: 16,
    titleVi: '16. Thành phần Tái sử dụng (Reusable Components)',
    titleEn: '16. Reusable Components Library',
    category: 'components',
    summaryVi: 'Danh mục các khối dùng chung: Breadcrumb, PageHeader, StatCard, EmptyState, ConfirmDialog.',
    summaryEn: 'Core reusable patterns across views including empty states, confirm dialogs, and stat cards.',
    contentMarkdownVi: `### DANH MỤC THÀNH PHẦN TÁI SỬ DỤNG
1. \`<PageHeader title action breadcrumb />\`: Đầu trang kèm nút hành động chính.
2. \`<StatCard label value trend icon />\`: Thẻ chỉ số kèm mũi tên tăng trưởng.
3. \`<EmptyState message icon actionLabel onAction />\`: Giao diện khi bảng không có dữ liệu.
4. \`<ConfirmDialog isOpen title message onConfirm onCancel />\`: Hộp thoại xác nhận an toàn.
5. \`<StatusBadge status colorMap />\`: Huy hiệu trạng thái tự động nhận diện màu sắc.`,
    contentMarkdownEn: `### REUSABLE PATTERN SPECIFICATION
Shared component APIs, prop types, slot structures, and accessibility compliance.`,
  },
  {
    id: 'form-components',
    number: 17,
    titleVi: '17. Thành phần Biểu mẫu (Form Components)',
    titleEn: '17. Form Components Specification',
    category: 'components',
    summaryVi: 'Quy cách Input, Select, DatePicker, CurrencyInput, Slider, Switch, RadioGroup, Checkbox.',
    summaryEn: 'Input fields, currency masks, date pickers, dropdown selects, and validation message displays.',
    contentMarkdownVi: `### QUY CÁCH BIỂU MẪU NHẬP LIỆU
- Mọi trường bắt buộc đều có dấu hoa thị đỏ \`*\`.
- Dưới mỗi Input có dòng hướng dẫn hoặc thông báo lỗi màu đỏ khi không hợp lệ.
- Trường tiền tệ có ký hiệu đơn vị tiền tệ rõ ràng (\`VNĐ\`, \`USD\`) và tự động định dạng phân cách hàng nghìn.
- Trường tỷ lệ xác suất có Slider trực quan từ 0% đến 100%.`,
    contentMarkdownEn: `### FORM COMPONENT SPECIFICATION
Controlled form components, masked inputs, floating labels, inline error feedback, and keyboard tab flow.`,
  },
  {
    id: 'table-components',
    number: 18,
    titleVi: '18. Thành phần Bảng Dữ liệu (Table Components)',
    titleEn: '18. Data Table Component Standards',
    category: 'components',
    summaryVi: 'Bảng dữ liệu doanh nghiệp: Cột cố định, Sắp xếp đa cột, Phân trang, Tìm kiếm, Xuất Excel.',
    summaryEn: 'Enterprise data table standards including sorting, pagination, multi-select, and export hooks.',
    contentMarkdownVi: `### BẢNG DỮ LIỆU ENTERPRISE (DATA TABLE)
- Thanh tiêu đề bảng (\`thead\`) có màu tương phản nhẹ, hỗ trợ Sticky Header khi cuộn dài.
- Cột thao tác (\`Actions\`) cố định bên phải với nút Xem, Sửa, Xóa nhanh.
- Thanh công cụ phía trên gồm: Ô tìm kiếm nhanh, nút Bộ lọc nâng cao, nút Xuất dữ liệu Excel/CSV.
- Thanh phân trang phía dưới hiển thị tổng số bản ghi và bộ chọn số dòng mỗi trang (10, 25, 50).`,
    contentMarkdownEn: `### DATA TABLE COMPONENT DESIGN
Column definitions, sticky headers, horizontal scroll indicators, empty state fallbacks, and row action triggers.`,
  },
  {
    id: 'modal-components',
    number: 19,
    titleVi: '19. Thành phần Hộp thoại & Drawer (Modal & Drawer Components)',
    titleEn: '19. Modal & Drawer Component Specifications',
    category: 'components',
    summaryVi: 'Quy chuẩn hiển thị Modal tạo mới/chỉnh sửa, Slide-over Drawer xem chi tiết, và Backdrop mờ.',
    summaryEn: 'Dialog overlay specifications, accessibility focus traps, ESC key listeners, and slide drawers.',
    contentMarkdownVi: `### QUY CHUẨN MODAL & DRAWER
- Lớp phủ nền mờ (\`backdrop-blur-sm bg-black/40\`).
- Đóng hộp thoại khi bấm phím ESC hoặc bấm ra ngoài nền (Click-outside).
- Khóa cuộn trang nền (\`body overflow-hidden\`) khi Modal đang mở.
- Nút đóng "X" cố định góc trên cùng bên phải.`,
    contentMarkdownEn: `### MODAL ARCHITECTURE SPECIFICATION
Focus trapping, screen reader aria attributes, responsive full-width mobile adaptation, and smooth exit animations.`,
  },
  {
    id: 'dashboard-widgets',
    number: 20,
    titleVi: '20. Widget Màn hình Tổng quan (Dashboard Widgets)',
    titleEn: '20. Dashboard Widgets Library',
    category: 'components',
    summaryVi: 'Chi tiết kỹ thuật 7 widget: Revenue Trend, Sales Funnel, Recent Deals, Urgent Tickets, Low Stock Alert.',
    summaryEn: 'Technical specifications for 7 dashboard widgets including data binding and responsive scaling.',
    contentMarkdownVi: `### THƯ VIỆN WIDGET DASHBOARD
1. **Widget Doanh thu:** Trực quan hóa đường cong doanh thu thực tế so với mục tiêu kế hoạch theo từng tháng.
2. **Widget Phễu Bán hàng (Sales Funnel):** Đo lường tỷ lệ rớt khách qua 5 nấc: Leads (100%) ➔ Qualified (60%) ➔ Proposal (40%) ➔ Negotiation (25%) ➔ Won (15%).
3. **Widget Ticket Khẩn cấp:** Đồng hồ đếm ngược SLA thời gian thực cảnh báo vi phạm hợp đồng dịch vụ.
4. **Widget Tồn kho an toàn:** Cảnh báo đỏ các sản phẩm có số lượng tồn dưới định mức an toàn.`,
    contentMarkdownEn: `### DASHBOARD WIDGET ARCHITECTURE
Data feeding pipelines, calculation algorithms, refresh rates, and interactive hover tooltip triggers.`,
  },
  {
    id: 'report-widgets',
    number: 21,
    titleVi: '21. Widget Báo cáo & Phân tích (Report Widgets)',
    titleEn: '21. Report & Analytics Widgets',
    category: 'components',
    summaryVi: 'Biểu đồ phân tích doanh thu theo nhân viên kinh doanh, cơ cấu sản phẩm và chỉ số hài lòng CSAT.',
    summaryEn: 'Sales rep leaderboards, product category breakdowns, and CSAT customer satisfaction trends.',
    contentMarkdownVi: `### WIDGET BÁO CÁO CHUYÊN SÂU
- **Bảng Xếp hạng Doanh số (Sales Rep Leaderboard):** Doanh số thực đạt, số lượng deal đã chốt, tỷ lệ hoàn thành chỉ tiêu tháng.
- **Biểu đồ Cơ cấu Sản phẩm:** Doanh thu phân bổ theo mảng Bản quyền Phần mềm, Thiết bị Công nghệ và Dịch vụ Tư vấn.
- **Báo cáo Tuân thủ SLA:** Tỷ lệ giải quyết Ticket đúng hạn trong vòng 2h, 4h, 8h.`,
    contentMarkdownEn: `### REPORTING WIDGET SPECIFICATION
Aggregated metrics, date-range filtering parameters, chart rendering options, and downloadable summary data.`,
  },
  {
    id: 'notification-widgets',
    number: 22,
    titleVi: '22. Widget Trung tâm Thông báo (Notification Widgets)',
    titleEn: '22. Notification Center Widgets',
    category: 'components',
    summaryVi: 'Chuông thông báo, menu trượt hiển thị thông báo theo loại (SLA, Lead, Quote, Security) và Toast nổi.',
    summaryEn: 'Real-time bell badge, categorized notification drawer, mark-as-read, and transient toast popups.',
    contentMarkdownVi: `### HỆ THỐNG THÔNG BÁO TỨC THÌ
- Chuông thông báo hiển thị số lượng tin chưa đọc màu đỏ nổi bật.
- Menu trượt phân loại tin: Tất cả, Cảnh báo SLA, Lead mới, Báo giá được duyệt, Cảnh báo An ninh.
- Nút "Đánh dấu tất cả đã đọc" thao tác trong 1 cú nhấp.
- Nhấp vào thông báo sẽ tự động điều hướng đến đúng Module liên quan.`,
    contentMarkdownEn: `### NOTIFICATION SYSTEM SPECIFICATION
Push alert schema, categorization tags, unread counter badges, dismiss workflows, and module deep-links.`,
  },
  {
    id: 'theme-engine',
    number: 23,
    titleVi: '23. Bộ máy Giao diện & 10 Templates (Theme Engine)',
    titleEn: '23. Theme Engine Architecture & 10 Templates',
    category: 'system',
    summaryVi: 'Đặc tả 10 mẫu giao diện doanh nghiệp, chuyển đổi chế độ Sáng/Tối, và Custom Theme Builder.',
    summaryEn: 'Architectural specifications for all 10 theme templates, CSS tokens, and live builder controls.',
    contentMarkdownVi: `### ĐẶC TẢ BỘ MÁY GIAO DIỆN (THEME ENGINE)
Hệ thống hỗ trợ 10 bộ giao diện chuẩn mực chuyển đổi tức thì:
1. **Corporate Blue:** Xanh Navy truyền thống doanh nghiệp, thanh lịch và tin cậy.
2. **Modern Dark:** Nền tối công nghệ cao cấp, tương phản cao, phù hợp màn hình OLED.
3. **Professional Gray:** Đơn sắc xám trung tính hiện đại, tập trung cao độ vào dữ liệu.
4. **Enterprise Green:** Xanh ngọc lục bảo và teal, phong cách tập đoàn phát triển bền vững.
5. **Fintech Purple:** Tím đậm & Indigo, phong cách ngân hàng số & tài chính hiện đại.
6. **Startup Orange:** Cam ấm & Hổ phách tràn đầy năng lượng, phù hợp các công ty công nghệ năng động.
7. **Material Design:** Chuẩn mực thiết kế Google Material với bo góc lớn và độ nổi bóng đổ.
8. **Glassmorphism:** Hiệu ứng kính mờ Acrylic trong suốt với lớp lọc mờ (\`backdrop-blur\`).
9. **Minimalist:** Thiết kế tối giản tinh gọn, loại bỏ bóng đổ, chỉ dùng đường viền mảnh (Border-first).
10. **Custom Theme Builder:** Cho phép người dùng tùy chọn mã màu Hex chủ đạo, độ bo góc, độ giãn dòng và kiểu thanh bên.`,
    contentMarkdownEn: `### THEME ENGINE TECHNICAL SPECIFICATION
Dynamic Tailwind class resolution, CSS variable injection, local storage persistence, and accessible contrast checks.`,
  },
  {
    id: 'i18n-engine',
    number: 24,
    titleVi: '24. Bộ máy Đa ngôn ngữ (Multi Language Engine)',
    titleEn: '24. Multi-Language (i18n) Engine',
    category: 'system',
    summaryVi: 'Đặc tả hệ thống bản địa hóa (L10n/i18n), mặc định Tiếng Việt, quản lý từ điển và định dạng số/ngày.',
    summaryEn: 'i18n dictionary system with Vietnamese as primary default, locale formatters, and translation keys.',
    contentMarkdownVi: `### BỘ MÁY ĐA NGÔN NGỮ (I18N ARCHITECTURE)
- **Ngôn ngữ mặc định:** Tiếng Việt (\`vi\`).
- **Ngôn ngữ mở rộng:** Tiếng Anh (\`en\`), Tiếng Nhật (\`ja\`).
- **Định dạng số và tiền tệ:**
  - Tiếng Việt: Phân cách hàng nghìn bằng dấu chấm (\`1.200.000.000 ₫\`).
  - Tiếng Anh: Phân cách bằng dấu phẩy (\`$1,200,000,000\`).
- **Định dạng ngày tháng:**
  - Tiếng Việt: \`DD/MM/YYYY HH:mm\`.
  - Tiếng Anh: \`YYYY-MM-DD HH:mm\`.
- **Trình chỉnh sửa từ điển trực quan:** Có giao diện cho phép Tenant Admin cập nhật các chuỗi dịch thuật trực tiếp trong module Settings.`,
    contentMarkdownEn: `### MULTI-LANGUAGE ENGINE SPECIFICATION
Dictionary key hierarchies, pluralization rules, date/currency Intl formatting, and runtime dictionary overrides.`,
  },
];

export const SCREEN_DETAILED_SPECS: ScreenSpecDetail[] = [
  {
    code: 'SCR-DASHBOARD',
    nameVi: 'Màn hình A: Dashboard Tổng quan Doanh nghiệp',
    nameEn: 'Screen A: Enterprise Executive Dashboard',
    purposeVi: 'Cung cấp cái nhìn toàn cảnh về tình hình kinh doanh, doanh thu, cơ hội bán hàng, cảnh báo khẩn cấp và hiệu suất vận hành thời gian thực.',
    purposeEn: 'Provide an executive cockpit for real-time revenue analytics, sales pipeline progression, and urgent operational alerts.',
    uiLayoutVi: 'Bố cục lưới Grid đa tầng gồm 4 thẻ KPI đầu trang, 2 biểu đồ phân tích kép giữa trang, và 3 danh sách theo dõi cảnh báo vận hành cuối trang.',
    uiLayoutEn: 'Multi-row responsive grid with top KPI stat cards, central analytics charts, and lower operational triage lists.',
    userActionsVi: [
      'Xem nhanh các chỉ số doanh thu, pipeline, lead mới, win rate',
      'Lọc dữ liệu theo kỳ báo cáo (Tháng này, Quý này, Năm nay)',
      'Nhấp vào cảnh báo Ticket SLA khẩn cấp để mở trực tiếp hồ sơ hỗ trợ',
      'Nhấp vào cảnh báo sản phẩm sắp hết hàng để mở kho vận',
      'Sử dụng các nút tắt "Tác vụ xử lý nhanh" để tạo Lead, Báo giá hoặc Ticket',
    ],
    userActionsEn: [
      'View key revenue, pipeline, lead intake, and win rate metrics',
      'Filter data by reporting period (This Month, Quarter, Year)',
      'Click SLA breach alert to deep-link to support ticket',
      'Click low stock warnings to open inventory depot',
      'Use quick action triggers to create leads, quotes, or tickets',
    ],
    componentsVi: [
      'TopHeader với Tenant & Role switchers',
      'StatCard (KPI Metrix cards with percentage delta)',
      'RevenueChart (Biểu đồ đường cong SVG trực quan)',
      'SalesFunnelWidget (Biểu đồ phễu 5 giai đoạn)',
      'UrgentTicketsWidget (Hàng đợi ticket vi phạm SLA)',
      'InventoryAlertsWidget (Danh sách sản phẩm chạm ngưỡng an toàn)',
    ],
    componentsEn: [
      'TopHeader with Tenant & Role switchers',
      'StatCard (KPI metric cards with delta indicators)',
      'RevenueChart (Interactive SVG revenue trend)',
      'SalesFunnelWidget (5-stage conversion funnel)',
      'UrgentTicketsWidget (SLA countdown triage)',
      'InventoryAlertsWidget (Safety stock warning list)',
    ],
    dataFields: [
      { field: 'totalRevenue', labelVi: 'Tổng doanh thu', labelEn: 'Total Revenue', type: 'Currency', required: true, validation: '>= 0' },
      { field: 'pipelineValue', labelVi: 'Giá trị Pipeline', labelEn: 'Pipeline Value', type: 'Currency', required: true, validation: '>= 0' },
      { field: 'newLeads', labelVi: 'Số Lead mới', labelEn: 'New Leads Count', type: 'Integer', required: true, validation: '>= 0' },
      { field: 'winRate', labelVi: 'Tỷ lệ chốt', labelEn: 'Win Rate %', type: 'Percentage', required: true, validation: '0 - 100%' },
    ],
    validationRulesVi: ['Dữ liệu tài chính không được mang giá trị âm', 'Tỷ lệ hoàn thành mục tiêu chuẩn hóa từ 0 - 100%'],
    validationRulesEn: ['Financial figures must be non-negative', 'Percentage values strictly bounded between 0 and 100%'],
    apiIntegration: [
      { endpoint: '/api/v1/dashboard/metrics', method: 'GET', descriptionVi: 'Lấy các chỉ số KPI tổng hợp cho tenant hiện tại', descriptionEn: 'Fetch aggregated KPI metrics for current tenant' },
      { endpoint: '/api/v1/dashboard/charts', method: 'GET', descriptionVi: 'Lấy dữ liệu chuỗi thời gian doanh thu và phễu bán hàng', descriptionEn: 'Fetch time-series revenue and funnel data' },
    ],
    permissionRulesVi: ['Mọi vai trò đăng nhập đều có quyền xem (View) Dashboard phù hợp với phạm vi phòng ban.'],
    permissionRulesEn: ['All authenticated roles have View access scoped to their operational domain.'],
    mobileResponsiveRulesVi: ['Lưới 4 KPI tự động co giãn về 1 cột trên Mobile', 'Biểu đồ hỗ trợ cuộn ngang hoặc tự thu nhỏ'],
    mobileResponsiveRulesEn: ['4-column KPI cards collapse into single column on mobile', 'Charts scale down gracefully with horizontal touch scrolling'],
  },
  {
    code: 'SCR-LEAD',
    nameVi: 'Màn hình B: Quản lý Khách hàng tiềm năng (Leads)',
    nameEn: 'Screen B: Lead Management',
    purposeVi: 'Tiếp nhận, theo dõi, phân loại nguồn gốc và chuyển đổi khách hàng tiềm năng thành Cơ hội bán hàng thực tế.',
    purposeEn: 'Ingest, score, nurture, and convert marketing leads into qualified commercial opportunities.',
    uiLayoutVi: 'Thanh tìm kiếm và lọc nguồn gốc ở trên; Bảng dữ liệu trung tâm kèm điểm tiềm năng Lead Score; Modal tạo mới/chỉnh sửa; Nút chuyển đổi nhanh.',
    uiLayoutEn: 'Top search and source filters; main data table with score indicators; slide/dialog creation modal; instant convert CTA.',
    userActionsVi: [
      'Tìm kiếm Lead theo tên, số điện thoại, email, doanh nghiệp',
      'Lọc theo nguồn (Website, Zalo, Referral, Triển lãm)',
      'Tạo Lead mới với đầy đủ thông tin liên hệ và giá trị dự kiến',
      'Chỉnh sửa thông tin và ghi chú tiến độ chăm sóc',
      'Chuyển đổi (Convert) Lead đạt chuẩn thành Cơ hội bán hàng (Opportunity)',
      'Xuất danh sách Lead ra file Excel/CSV',
    ],
    userActionsEn: [
      'Search leads by name, phone, email, company',
      'Filter by lead source (Website, Zalo, Referral, Exhibition)',
      'Create new lead with contact info and estimated budget',
      'Edit lead details and add call notes',
      'Convert qualified lead to commercial opportunity',
      'Export lead directory to Excel/CSV',
    ],
    componentsVi: [
      'PageHeader kèm nút Tạo mới và Xuất Excel',
      'LeadFilterBar (Tìm kiếm, Trạng thái, Nguồn tiếp cận)',
      'LeadTable (Cột mã, tên, cty, sđt, điểm score, người phụ trách, thao tác)',
      'LeadModal (Form tạo/sửa Lead với validation chuẩn)',
      'ConvertModal (Hộp thoại chuyển đổi sang Opportunity)',
    ],
    componentsEn: [
      'PageHeader with Add Lead and Export buttons',
      'LeadFilterBar (Search, Status, Source filters)',
      'LeadTable (Code, contact, score pill, owner, action buttons)',
      'LeadModal (Creation/edit dialog with schema validation)',
      'ConvertModal (Opportunity conversion trigger)',
    ],
    dataFields: [
      { field: 'code', labelVi: 'Mã Lead', labelEn: 'Lead Code', type: 'String', required: true, validation: 'Regex: LEAD-[0-9]{4}-[0-9]{3}' },
      { field: 'fullName', labelVi: 'Họ tên', labelEn: 'Full Name', type: 'String', required: true, validation: 'Min 2 ký tự' },
      { field: 'company', labelVi: 'Doanh nghiệp', labelEn: 'Company', type: 'String', required: true, validation: 'Không được để trống' },
      { field: 'phone', labelVi: 'Số điện thoại', labelEn: 'Phone Number', type: 'String', required: true, validation: 'Số điện thoại VN 10 chữ số' },
      { field: 'email', labelVi: 'Email', labelEn: 'Email', type: 'String', required: true, validation: 'Đúng định dạng RFC 5322' },
      { field: 'score', labelVi: 'Điểm tiềm năng', labelEn: 'Lead Score', type: 'Integer', required: true, validation: '0 - 100' },
    ],
    validationRulesVi: ['Số điện thoại phải bắt đầu bằng đầu số hợp lệ tại Việt Nam (03, 05, 07, 08, 09)', 'Email không được trùng lặp trong cùng Tenant'],
    validationRulesEn: ['Phone number must follow valid Vietnamese telecom prefixes', 'Email must be unique within tenant scope'],
    apiIntegration: [
      { endpoint: '/api/v1/leads', method: 'GET', descriptionVi: 'Truy vấn danh sách Lead theo bộ lọc', descriptionEn: 'Query filtered lead list' },
      { endpoint: '/api/v1/leads', method: 'POST', descriptionVi: 'Khởi tạo Lead mới', descriptionEn: 'Create new lead entity' },
      { endpoint: '/api/v1/leads/:id/convert', method: 'POST', descriptionVi: 'Chuyển đổi Lead sang Opportunity & Contact', descriptionEn: 'Convert lead to opportunity and contact' },
    ],
    permissionRulesVi: ['Sales Staff chỉ được xem và sửa Lead được phân công; Sales Manager và Admin có toàn quyền.'],
    permissionRulesEn: ['Sales Staff can only edit assigned leads; Sales Managers and Admins hold full CRUD.'],
    mobileResponsiveRulesVi: ['Ẩn các cột phụ (Email, Ngày tạo) trên màn hình điện thoại, chỉ hiển thị Tên, Cty và SĐT.'],
    mobileResponsiveRulesEn: ['Hide secondary columns (Email, Created Date) on mobile viewports; prioritize Name, Company, and Phone.'],
  },
  {
    code: 'SCR-CONTACT',
    nameVi: 'Màn hình C: Danh bạ Khách hàng (Contacts)',
    nameEn: 'Screen C: Contact Directory',
    purposeVi: 'Lưu trữ thông tin liên hệ của khách hàng, đối tác, lịch sử giao dịch và tổng doanh số đã chi tiêu.',
    purposeEn: 'Central repository of customer accounts, key decision-makers, and historical transaction volume.',
    uiLayoutVi: 'Thanh công cụ lọc theo phân nhóm (VIP, Thân thiết, Mới); Bảng danh bạ chi tiết; Modal cập nhật thông tin.',
    uiLayoutEn: 'Segmented contact filters (VIP, Repeat, New); rich directory table; contact update modal.',
    userActionsVi: ['Xem danh sách khách hàng VIP', 'Thêm mới liên hệ đối tác', 'Cập nhật địa chỉ và người phụ trách', 'Xem tổng doanh số đã ký hợp đồng'],
    userActionsEn: ['Filter VIP accounts', 'Add new partner contact', 'Update address and account manager', 'View aggregate contract revenue'],
    componentsVi: ['ContactStatsBar', 'ContactDirectoryTable', 'ContactDetailModal', 'VIPBadge'],
    componentsEn: ['ContactStatsBar', 'ContactDirectoryTable', 'ContactDetailModal', 'VIPBadge'],
    dataFields: [
      { field: 'fullName', labelVi: 'Họ tên', labelEn: 'Full Name', type: 'String', required: true, validation: 'Bắt buộc' },
      { field: 'type', labelVi: 'Phân loại', labelEn: 'Contact Tier', type: 'Enum', required: true, validation: 'VIP | Thân thiết | Mới' },
      { field: 'totalSpent', labelVi: 'Tổng chi tiêu', labelEn: 'Total Spent', type: 'Currency', required: false, validation: '>= 0' },
    ],
    validationRulesVi: ['Mã định danh liên hệ không được trùng lặp'],
    validationRulesEn: ['Contact code must be unique within tenant'],
    apiIntegration: [
      { endpoint: '/api/v1/contacts', method: 'GET', descriptionVi: 'Lấy danh bạ khách hàng', descriptionEn: 'Get customer directory' },
      { endpoint: '/api/v1/contacts', method: 'POST', descriptionVi: 'Tạo khách hàng mới', descriptionEn: 'Create customer contact' },
    ],
    permissionRulesVi: ['Super Admin, Tenant Admin, Sales Manager, Sales Staff, CSKH đều có quyền truy cập.'],
    permissionRulesEn: ['Accessible to Super Admin, Tenant Admin, Sales Manager, Sales Staff, CSKH.'],
    mobileResponsiveRulesVi: ['Chuyển đổi giao diện sang dạng Card thu gọn trên Mobile.'],
    mobileResponsiveRulesEn: ['Transform table rows into compact contact cards on mobile screens.'],
  },
  {
    code: 'SCR-OPPORTUNITY',
    nameVi: 'Màn hình D: Cơ hội bán hàng (Opportunities Pipeline)',
    nameEn: 'Screen D: Opportunity Pipeline & Kanban',
    purposeVi: 'Trực quan hóa quy trình bán hàng qua 5 giai đoạn, quản lý giá trị thương vụ và dự phóng doanh số.',
    purposeEn: 'Visualize deal pipeline progression across 5 sales stages, deal values, and revenue forecasts.',
    uiLayoutVi: 'Nút chuyển đổi chế độ xem (Kanban Board kéo thả 5 cột vs Bảng danh sách Table); Modal khởi tạo cơ hội.',
    uiLayoutEn: 'Toggle between 5-stage drag-and-drop Kanban Board and detailed Table view; deal creation modal.',
    userActionsVi: [
      'Chuyển đổi giữa chế độ xem Kanban và Danh sách',
      'Kéo thả hoặc cập nhật giai đoạn cơ hội bán hàng',
      'Điều chỉnh giá trị thương vụ và xác suất chốt thành công (%)',
      'Tạo nhanh Báo giá trực tiếp từ Cơ hội',
    ],
    userActionsEn: [
      'Toggle between Kanban board and Tabular list',
      'Move deals between sales stages',
      'Adjust expected deal amount and close probability (%)',
      'Trigger quick quotation creation from active deal',
    ],
    componentsVi: ['PipelineStageColumn', 'OpportunityCard', 'StageProbabilityBadge', 'DealCreateModal'],
    componentsEn: ['PipelineStageColumn', 'OpportunityCard', 'StageProbabilityBadge', 'DealCreateModal'],
    dataFields: [
      { field: 'title', labelVi: 'Tên cơ hội', labelEn: 'Deal Title', type: 'String', required: true, validation: 'Bắt buộc' },
      { field: 'stage', labelVi: 'Giai đoạn', labelEn: 'Sales Stage', type: 'Enum', required: true, validation: '5 nấc pipeline' },
      { field: 'amount', labelVi: 'Giá trị dự kiến', labelEn: 'Estimated Value', type: 'Currency', required: true, validation: '> 0' },
      { field: 'probability', labelVi: 'Xác suất (%)', labelEn: 'Probability', type: 'Integer', required: true, validation: '0 - 100' },
    ],
    validationRulesVi: ['Xác suất giai đoạn Won tự động đặt là 100%, Lost là 0%'],
    validationRulesEn: ['Won stage automatically locks probability to 100%, Lost to 0%'],
    apiIntegration: [
      { endpoint: '/api/v1/opportunities', method: 'GET', descriptionVi: 'Lấy pipeline cơ hội', descriptionEn: 'Fetch opportunity pipeline' },
      { endpoint: '/api/v1/opportunities/:id/stage', method: 'PATCH', descriptionVi: 'Cập nhật giai đoạn cơ hội', descriptionEn: 'Update opportunity stage' },
    ],
    permissionRulesVi: ['Sales Staff xem và sửa cơ hội của mình; Sales Manager quản lý toàn phòng.'],
    permissionRulesEn: ['Sales Staff manage own deals; Sales Managers manage team deals.'],
    mobileResponsiveRulesVi: ['Kanban board hỗ trợ cuộn ngang mượt mà trên thiết bị di động.'],
    mobileResponsiveRulesEn: ['Kanban lanes enable smooth horizontal snap scrolling on mobile devices.'],
  },
  {
    code: 'SCR-QUOTATION',
    nameVi: 'Màn hình E: Quản lý Báo giá (Quotations)',
    nameEn: 'Screen E: Quotation & Proposal Engine',
    purposeVi: 'Tạo lập báo giá thương mại đa dòng, tính toán chiết khấu và thuế VAT tự động, phê duyệt và xuất bản in PDF.',
    purposeEn: 'Generate multi-line commercial proposals, automate VAT and discount calculations, and export PDFs.',
    uiLayoutVi: 'Bảng quản lý báo giá; Trình tạo báo giá với bộ tính giá chi tiết nhiều sản phẩm; Modal xem trước bản in PDF.',
    uiLayoutEn: 'Quotation management table; multi-line quote builder with automated math; printable PDF preview modal.',
    userActionsVi: [
      'Tạo báo giá mới kèm chọn sản phẩm từ kho',
      'Tự động tính thuế VAT (8% hoặc 10%) và chiết khấu',
      'Gửi phê duyệt nội bộ hoặc gửi trực tiếp cho khách hàng',
      'Xem trước bản in báo giá chuẩn mẫu doanh nghiệp và In/Xuất PDF',
      'Phê duyệt hoặc Từ chối báo giá (Dành cho Manager)',
    ],
    userActionsEn: [
      'Create new quotation with line items from catalog',
      'Automate VAT (8% or 10%) and customer discount calculation',
      'Submit for manager approval or dispatch to customer',
      'Preview enterprise-styled printable quotation PDF',
      'Approve or reject quotation proposals (Managers only)',
    ],
    componentsVi: ['QuotationTable', 'LineItemBuilder', 'TaxCalculationSummary', 'QuotationPdfPreviewModal'],
    componentsEn: ['QuotationTable', 'LineItemBuilder', 'TaxCalculationSummary', 'QuotationPdfPreviewModal'],
    dataFields: [
      { field: 'code', labelVi: 'Mã báo giá', labelEn: 'Quote Code', type: 'String', required: true, validation: 'BG-YYYY-XXXX' },
      { field: 'customerName', labelVi: 'Khách hàng', labelEn: 'Customer Name', type: 'String', required: true, validation: 'Bắt buộc' },
      { field: 'grandTotal', labelVi: 'Tổng cộng', labelEn: 'Grand Total', type: 'Currency', required: true, validation: '> 0' },
      { field: 'validUntil', labelVi: 'Hạn hiệu lực', labelEn: 'Valid Until', type: 'Date', required: true, validation: '>= Ngày hiện tại' },
    ],
    validationRulesVi: ['Báo giá phải có ít nhất 1 dòng sản phẩm/dịch vụ', 'Hạn báo giá không được ở quá khứ'],
    validationRulesEn: ['Quotation must contain at least 1 line item', 'Validity date cannot be in the past'],
    apiIntegration: [
      { endpoint: '/api/v1/quotations', method: 'GET', descriptionVi: 'Lấy danh sách báo giá', descriptionEn: 'List quotations' },
      { endpoint: '/api/v1/quotations', method: 'POST', descriptionVi: 'Tạo báo giá mới', descriptionEn: 'Create quotation' },
      { endpoint: '/api/v1/quotations/:id/approve', method: 'POST', descriptionVi: 'Phê duyệt báo giá', descriptionEn: 'Approve quote' },
    ],
    permissionRulesVi: ['Quyền phê duyệt (Approve) chỉ dành cho Sales Manager, Tenant Admin và Super Admin.'],
    permissionRulesEn: ['Approval action restricted to Sales Manager, Tenant Admin, and Super Admin.'],
    mobileResponsiveRulesVi: ['Bản in PDF tự động co giãn fit theo chiều ngang màn hình.'],
    mobileResponsiveRulesEn: ['PDF preview automatically scales viewport width with responsive zoom controls.'],
  },
  {
    code: 'SCR-CONTRACT',
    nameVi: 'Màn hình F: Quản lý Hợp đồng (Contracts)',
    nameEn: 'Screen F: Contract Lifecycle Management',
    purposeVi: 'Theo dõi vòng đời hợp đồng kinh tế, giá trị cam kết, các mốc thanh toán từng đợt và cảnh báo sắp đáo hạn.',
    purposeEn: 'Oversee economic contract lifecycle, milestone payments, renewal alerts, and legally binding signers.',
    uiLayoutVi: 'Bảng theo dõi hợp đồng; Thanh tiến độ thanh toán %; Chi tiết các đợt thanh toán (Milestones); Modal tạo hợp đồng.',
    uiLayoutEn: 'Contract tracking registry; visual milestone payment progress bar; payment schedule drawer; create modal.',
    userActionsVi: ['Xem tiến độ thanh toán từng đợt', 'Đánh dấu đợt thanh toán đã hoàn tất', 'Cảnh báo hợp đồng sắp hết hạn', 'Lập hợp đồng mới từ báo giá đã duyệt'],
    userActionsEn: ['Track milestone payment percentages', 'Mark milestone as paid', 'Flag upcoming contract expirations', 'Draft contract from approved quotation'],
    componentsVi: ['ContractTable', 'PaymentMilestoneProgress', 'ContractStatusBadge', 'NewContractModal'],
    componentsEn: ['ContractTable', 'PaymentMilestoneProgress', 'ContractStatusBadge', 'NewContractModal'],
    dataFields: [
      { field: 'contractNumber', labelVi: 'Số hợp đồng', labelEn: 'Contract #', type: 'String', required: true, validation: 'HD-YYYY/MM/...' },
      { field: 'totalValue', labelVi: 'Giá trị hợp đồng', labelEn: 'Total Value', type: 'Currency', required: true, validation: '> 0' },
      { field: 'startDate', labelVi: 'Ngày bắt đầu', labelEn: 'Start Date', type: 'Date', required: true, validation: 'Bắt buộc' },
      { field: 'endDate', labelVi: 'Ngày kết thúc', labelEn: 'End Date', type: 'Date', required: true, validation: '>= startDate' },
    ],
    validationRulesVi: ['Tổng tỷ lệ các đợt thanh toán phải bằng chính xác 100%'],
    validationRulesEn: ['Sum of payment milestone percentages must equal exactly 100%'],
    apiIntegration: [
      { endpoint: '/api/v1/contracts', method: 'GET', descriptionVi: 'Lấy danh sách hợp đồng', descriptionEn: 'List contracts' },
      { endpoint: '/api/v1/contracts/:id/milestones', method: 'PATCH', descriptionVi: 'Cập nhật trạng thái thanh toán', descriptionEn: 'Update milestone payment' },
    ],
    permissionRulesVi: ['Sales Manager và Admin có quyền tạo/sửa; Nhân viên chỉ có quyền xem.'],
    permissionRulesEn: ['Sales Managers and Admins hold edit rights; staff roles have read-only access.'],
    mobileResponsiveRulesVi: ['Hiển thị thanh tiến độ thanh toán dạng mini progress bar trên Mobile.'],
    mobileResponsiveRulesEn: ['Display payment milestones as compact stacked progress bars on mobile.'],
  },
  {
    code: 'SCR-CUSTOMER-CARE',
    nameVi: 'Màn hình G: Chăm sóc Khách hàng & Ticket (Customer Care)',
    nameEn: 'Screen G: Customer Care & Ticket Helpdesk',
    purposeVi: 'Tiếp nhận sự cố đa kênh (Hotline, Email, Zalo OA), theo dõi đồng hồ đếm ngược SLA và khảo sát điểm hài lòng CSAT.',
    purposeEn: 'Omnichannel support ticketing, SLA countdown timers, priority dispatch, and CSAT satisfaction measurement.',
    uiLayoutVi: 'Thống kê Ticket theo mức độ ưu tiên P1-P4; Bảng danh sách Ticket; Đồng hồ đếm ngược thời gian SLA; Modal xử lý sự cố.',
    uiLayoutEn: 'Priority summary banners (P1-P4); helpdesk ticket table; real-time SLA countdown chip; resolution modal.',
    userActionsVi: [
      'Tiếp nhận Ticket sự cố từ Hotline, Email hoặc Zalo OA',
      'Xem đồng hồ đếm ngược vi phạm cam kết SLA (P1: 2h, P2: 4h)',
      'Cập nhật tiến độ xử lý và phản hồi khách hàng',
      'Giải quyết và đóng Ticket kèm ghi nhận điểm CSAT (1-5 sao)',
    ],
    userActionsEn: [
      'Ingest support tickets from Hotline, Email, or Zalo OA',
      'Monitor real-time SLA countdown timers (P1: 2h, P2: 4h)',
      'Update resolution progress notes and notify customer',
      'Resolve ticket and record 1-5 star CSAT feedback score',
    ],
    componentsVi: ['TicketPriorityChips', 'SlaCountdownBadge', 'TicketResolutionModal', 'CsatStarRating'],
    componentsEn: ['TicketPriorityChips', 'SlaCountdownBadge', 'TicketResolutionModal', 'CsatStarRating'],
    dataFields: [
      { field: 'ticketNumber', labelVi: 'Mã Ticket', labelEn: 'Ticket #', type: 'String', required: true, validation: 'TICK-YYYY-XXXX' },
      { field: 'priority', labelVi: 'Độ ưu tiên', labelEn: 'Priority', type: 'Enum', required: true, validation: 'P1 | P2 | P3 | P4' },
      { field: 'slaMinutesRemaining', labelVi: 'Phút SLA còn lại', labelEn: 'SLA Minutes Left', type: 'Integer', required: true, validation: '>= 0' },
      { field: 'csatScore', labelVi: 'Điểm CSAT', labelEn: 'CSAT Rating', type: 'Integer', required: false, validation: '1 - 5' },
    ],
    validationRulesVi: ['Ticket P1 bắt buộc phải có nội dung mô tả sự cố kỹ thuật chi tiết'],
    validationRulesEn: ['P1 urgent tickets require detailed incident diagnostic descriptions'],
    apiIntegration: [
      { endpoint: '/api/v1/tickets', method: 'GET', descriptionVi: 'Lấy danh sách Ticket CSKH', descriptionEn: 'List support tickets' },
      { endpoint: '/api/v1/tickets/:id/resolve', method: 'POST', descriptionVi: 'Đóng ticket và ghi nhận điểm CSAT', descriptionEn: 'Resolve ticket with CSAT score' },
    ],
    permissionRulesVi: ['Chuyên viên CSKH và Admin có toàn quyền tạo, cập nhật và đóng ticket.'],
    permissionRulesEn: ['Customer Care Staff and Admins hold full ticket lifecycle privileges.'],
    mobileResponsiveRulesVi: ['Cảnh báo vi phạm SLA hiển thị viền đỏ nhấp nháy trên giao diện điện thoại.'],
    mobileResponsiveRulesEn: ['SLA breach risk displays prominent pulsing alert badge on mobile header.'],
  },
  {
    code: 'SCR-INVENTORY',
    nameVi: 'Màn hình H: Quản lý Kho & Sản phẩm (Inventory)',
    nameEn: 'Screen H: Inventory Catalog & Multi-Depot Operations',
    purposeVi: 'Quản lý danh mục sản phẩm, mã SKU, theo dõi số lượng tồn kho tại 3 chi nhánh (Hà Nội, Đà Nẵng, TP.HCM) và lập phiếu xuất nhập kho.',
    purposeEn: 'Track multi-warehouse stock levels (Hanoi, Danang, HCMC depots), safety thresholds, and stock movements.',
    uiLayoutVi: 'Thống kê tồn kho 3 miền; Bảng danh mục sản phẩm kèm cảnh báo thiếu hàng; Lịch sử phiếu Nhập/Xuất kho; Modal lập phiếu kho.',
    uiLayoutEn: 'Regional depot summary cards; product SKU table with safety alerts; stock movement log; receipt/dispatch modal.',
    userActionsVi: [
      'Kiểm tra tồn kho tức thời tại Kho Hà Nội, Kho Đà Nẵng, Kho TP.HCM',
      'Nhận cảnh báo đỏ khi tồn kho dưới mức an toàn',
      'Lập phiếu Nhập kho mới khi nhập hàng về kho',
      'Lập phiếu Xuất kho phục vụ bàn giao hợp đồng kinh doanh',
      'Theo dõi lịch sử dịch chuyển hàng hóa',
    ],
    userActionsEn: [
      'Inspect real-time stock at Hanoi, Danang, and HCMC depots',
      'Receive red alerts when inventory drops below safety baseline',
      'Issue Inward Stock-In receipt when goods arrive',
      'Issue Outward Stock-Out dispatch for contracted deliverables',
      'Audit itemized movement transaction logs',
    ],
    componentsVi: ['DepotStockCards', 'ProductSkuTable', 'StockInModal', 'StockOutModal', 'TransactionHistoryDrawer'],
    componentsEn: ['DepotStockCards', 'ProductSkuTable', 'StockInModal', 'StockOutModal', 'TransactionHistoryDrawer'],
    dataFields: [
      { field: 'sku', labelVi: 'Mã SKU', labelEn: 'SKU Code', type: 'String', required: true, validation: 'Unique' },
      { field: 'name', labelVi: 'Tên sản phẩm', labelEn: 'Product Name', type: 'String', required: true, validation: 'Bắt buộc' },
      { field: 'minSafeStock', labelVi: 'Ngưỡng an toàn', labelEn: 'Safety Stock Limit', type: 'Integer', required: true, validation: '> 0' },
      { field: 'stockHanoi', labelVi: 'Kho Hà Nội', labelEn: 'Hanoi Depot Qty', type: 'Integer', required: true, validation: '>= 0' },
    ],
    validationRulesVi: ['Số lượng xuất kho không được vượt quá số lượng hàng tồn khả dụng tại kho tương ứng'],
    validationRulesEn: ['Dispatch quantity cannot exceed available stock at selected regional depot'],
    apiIntegration: [
      { endpoint: '/api/v1/inventory/products', method: 'GET', descriptionVi: 'Lấy danh mục sản phẩm và tồn kho', descriptionEn: 'List catalog products with stock' },
      { endpoint: '/api/v1/inventory/transactions', method: 'POST', descriptionVi: 'Tạo phiếu nhập/xuất kho', descriptionEn: 'Post stock movement receipt' },
    ],
    permissionRulesVi: ['Thủ kho (Warehouse Staff) và Admin có quyền tạo phiếu kho; các vai trò khác chỉ xem.'],
    permissionRulesEn: ['Warehouse Staff and Admins hold stock movement authority; others view-only.'],
    mobileResponsiveRulesVi: ['Cho phép quét mã vạch SKU bằng camera điện thoại trong phiên bản di động.'],
    mobileResponsiveRulesEn: ['Support mobile camera barcode scanning for rapid stock auditing.'],
  },
  {
    code: 'SCR-REPORTS',
    nameVi: 'Màn hình I: Báo cáo & Phân tích (Reports & Analytics)',
    nameEn: 'Screen I: Enterprise Business Intelligence & Reports',
    purposeVi: 'Cung cấp báo cáo phân tích đa chiều: Doanh thu theo tháng, Hiệu suất nhân viên kinh doanh, Báo cáo thời gian phản hồi SLA và cơ cấu sản phẩm.',
    purposeEn: 'Provide deep analytical reporting on monthly revenue trends, sales representative leaderboards, and SLA metrics.',
    uiLayoutVi: 'Bộ chọn khoảng thời gian (Từ ngày - Đến ngày); Nút xuất Excel/PDF; 4 bảng biểu phân tích chuyên sâu.',
    uiLayoutEn: 'Date-range filter bar; Excel/PDF export buttons; 4 specialized analytical metric dashboards.',
    userActionsVi: [
      'Chọn khoảng thời gian phân tích (Quý này, Năm nay, Tùy chọn)',
      'Xem bảng xếp hạng doanh số nhân viên kinh doanh (Sales Rep Leaderboard)',
      'Phân tích cơ cấu doanh thu theo nhóm sản phẩm phần mềm vs thiết bị',
      'Xuất báo cáo tổng hợp ra định dạng Excel hoặc in trực tiếp',
    ],
    userActionsEn: [
      'Select reporting timeframe (Quarter, Year, Custom range)',
      'Inspect sales representative revenue leaderboard and targets',
      'Analyze revenue composition across software vs hardware categories',
      'Export consolidated intelligence reports to Excel or printable format',
    ],
    componentsVi: ['DateRangePicker', 'RepLeaderboardTable', 'RevenueBreakdownChart', 'ReportExportToolbar'],
    componentsEn: ['DateRangePicker', 'RepLeaderboardTable', 'RevenueBreakdownChart', 'ReportExportToolbar'],
    dataFields: [
      { field: 'dateRange', labelVi: 'Khoảng thời gian', labelEn: 'Date Range', type: 'DateRange', required: true, validation: 'Valid range' },
      { field: 'department', labelVi: 'Phòng ban', labelEn: 'Department', type: 'Enum', required: false, validation: 'All or Selected' },
    ],
    validationRulesVi: ['Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc'],
    validationRulesEn: ['Start date must precede or equal end date'],
    apiIntegration: [
      { endpoint: '/api/v1/reports/revenue', method: 'GET', descriptionVi: 'Lấy dữ liệu phân tích doanh thu', descriptionEn: 'Fetch revenue analytics' },
      { endpoint: '/api/v1/reports/reps', method: 'GET', descriptionVi: 'Lấy bảng xếp hạng sales reps', descriptionEn: 'Fetch sales rep leaderboard' },
    ],
    permissionRulesVi: ['Super Admin, Tenant Admin, Sales Manager có quyền xem và xuất toàn bộ báo cáo.'],
    permissionRulesEn: ['Admins and Sales Managers have access to complete cross-departmental reports.'],
    mobileResponsiveRulesVi: ['Bảng xếp hạng thu gọn hiển thị top 3 nhân sự xuất sắc trên điện thoại.'],
    mobileResponsiveRulesEn: ['Leaderboard table condenses to highlight top 3 reps on mobile viewports.'],
  },
  {
    code: 'SCR-SETTINGS',
    nameVi: 'Màn hình J: Cài đặt Hệ thống (Settings)',
    nameEn: 'Screen J: Enterprise System Settings & Administration',
    purposeVi: 'Trung tâm quản trị toàn diện: Cấu hình Tenant đa doanh nghiệp, Quản lý tài khoản người dùng, Ma trận RBAC 6 vai trò, Theme Engine 10 mẫu, Đa ngôn ngữ và Nhật ký an ninh Audit Log.',
    purposeEn: 'Consolidated admin hub: Multi-tenant profiles, User CRUD, 6-role RBAC matrix, Theme engine, i18n manager, and Audit logs.',
    uiLayoutVi: 'Thanh điều hướng 8 phân khu con (Sub-tabs); Bảng cấu hình chi tiết theo từng chuyên mục; Trình tùy biến Theme trực quan.',
    uiLayoutEn: '8-section horizontal tab navigation; detailed settings panels; live interactive Theme Builder.',
    userActionsVi: [
      'Chuyển đổi Doanh nghiệp (Tenant Switcher) hoặc cập nhật thông tin MST, Domain',
      'Thêm, sửa, phân quyền tài khoản nhân viên (User Management)',
      'Điều chỉnh Ma trận phân quyền 6 vai trò (RBAC Matrix)',
      'Chuyển đổi 10 Templates giao diện hoặc tùy biến màu sắc trực tiếp',
      'Chỉnh sửa bộ từ điển đa ngôn ngữ i18n (Tiếng Việt & Tiếng Anh)',
      'Kiểm tra Nhật ký hành động (Activity Log) và Nhật ký an ninh (Audit Log)',
    ],
    userActionsEn: [
      'Switch active Tenant or update tax ID, company domain, and currency',
      'Add, edit, lock employee accounts (User Directory CRUD)',
      'Adjust granular permissions across the 6-role RBAC matrix',
      'Switch between 10 UI templates or customize color palettes live',
      'Manage multi-language translation dictionary entries',
      'Audit system activity logs and security compliance logs',
    ],
    componentsVi: [
      'SettingsTabsNavigation',
      'TenantProfileEditor',
      'UserManagementTable',
      'RbacMatrixGrid',
      'ThemeCustomizerPanel',
      'LanguageDictionaryEditor',
      'AuditLogViewer',
    ],
    componentsEn: [
      'SettingsTabsNavigation',
      'TenantProfileEditor',
      'UserManagementTable',
      'RbacMatrixGrid',
      'ThemeCustomizerPanel',
      'LanguageDictionaryEditor',
      'AuditLogViewer',
    ],
    dataFields: [
      { field: 'tenantName', labelVi: 'Tên Doanh nghiệp', labelEn: 'Tenant Name', type: 'String', required: true, validation: 'Bắt buộc' },
      { field: 'taxId', labelVi: 'Mã số thuế', labelEn: 'Tax ID', type: 'String', required: true, validation: '10 hoặc 13 chữ số' },
      { field: 'currency', labelVi: 'Tiền tệ', labelEn: 'Currency', type: 'Enum', required: true, validation: 'VND | USD' },
    ],
    validationRulesVi: ['Chỉ Super Admin và Tenant Admin mới được chỉnh sửa cấu hình hệ thống và ma trận phân quyền'],
    validationRulesEn: ['Only Super Admin and Tenant Admin may modify RBAC permissions and organization profile'],
    apiIntegration: [
      { endpoint: '/api/v1/settings/tenant', method: 'PUT', descriptionVi: 'Cập nhật cấu hình doanh nghiệp', descriptionEn: 'Update tenant organization' },
      { endpoint: '/api/v1/settings/users', method: 'POST', descriptionVi: 'Tạo tài khoản nhân viên', descriptionEn: 'Create user account' },
      { endpoint: '/api/v1/settings/rbac', method: 'PUT', descriptionVi: 'Lưu ma trận phân quyền RBAC', descriptionEn: 'Save RBAC matrix' },
      { endpoint: '/api/v1/settings/audit-logs', method: 'GET', descriptionVi: 'Truy vấn nhật ký kiểm toán an ninh', descriptionEn: 'Query security audit logs' },
    ],
    permissionRulesVi: ['Super Admin toàn quyền; Tenant Admin quản lý trong tenant; các vai trò khác không có quyền truy cập tab này.'],
    permissionRulesEn: ['Super Admin has universal scope; Tenant Admin manages tenant domain; operational staff restricted.'],
    mobileResponsiveRulesVi: ['Thanh 8 Sub-tabs hỗ trợ cuộn ngang mượt mà với chỉ báo tab đang chọn.'],
    mobileResponsiveRulesEn: ['8-subtab navigation bar features touch horizontal swipe with active pill indicator.'],
  },
];
