import React from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import {
  DollarSign,
  TrendingUp,
  Award,
  Users,
  CheckCircle2,
  FileCheck2,
  Clock,
  ArrowRight,
  Flame,
  ChevronRight,
  Filter,
  Layers,
} from 'lucide-react';

export const SalesManagerDashboard: React.FC = () => {
  const { currentUser, setActiveModule, showToast } = useCRM();
  const { orders, opportunities, leads } = useSales();

  const handleApproveOrder = (orderId: string, orderCode: string) => {
    showToast('Phê duyệt đơn hàng', `Đã duyệt đơn hàng ${orderCode} thành công. Chuyển tiếp Logistics xuất kho.`);
  };

  const salesRepLeaderboard = [
    { name: 'Nguyễn Văn A', target: 1000000000, revenue: 820000000, wonDeals: 4, rank: 1, avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop&crop=faces' },
    { name: 'Lê Hoàng Yến', target: 1200000000, revenue: 950000000, wonDeals: 5, rank: 2, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&crop=faces' },
    { name: 'Trần Anh Tuấn', target: 1000000000, revenue: 760000000, wonDeals: 3, rank: 3, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=faces' },
    { name: 'Phan Quốc Bảo', target: 800000000, revenue: 610000000, wonDeals: 3, rank: 4, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=faces' },
    { name: 'Đặng Thanh Tùng', target: 900000000, revenue: 580000000, wonDeals: 2, rank: 5, avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=100&h=100&fit=crop&crop=faces' },
  ];

  return (
    <div className="space-y-6 max-w-[1400px] mx-auto pb-12">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden border border-amber-900/50">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-radial from-amber-500/20 via-transparent to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.fullName}
              className="w-16 h-16 rounded-full border-2 border-amber-400/80 object-cover shadow-lg shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight">
                  Chào anh {currentUser.fullName}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/30 text-amber-200 border border-amber-400/30">
                  Trưởng Phòng Kinh Doanh (Sales Head)
                </span>
              </div>
              <p className="text-slate-300 text-sm mt-1">
                Bảng chỉ huy &amp; Quản trị toàn bộ phân hệ Sales: Phễu bán hàng toàn team, Duyệt đơn hàng Booking, và 8 Báo cáo hiệu suất kinh doanh.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setActiveModule('sales-orders')}
              className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-sm font-bold shadow-md transition-colors flex items-center gap-2 cursor-pointer"
            >
              <FileCheck2 className="w-4 h-4" />
              <span>Duyệt Đơn Hàng Booking</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. 4 Sales Leadership KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Doanh số toàn đội */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Doanh số toàn đội B2B
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              5.450.000.000 ₫
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
              <span>Mục tiêu: 8.500.000.000 ₫</span>
              <span className="font-bold text-amber-600">64.1%</span>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full mt-2 overflow-hidden">
              <div className="bg-amber-500 h-full rounded-full" style={{ width: '64.1%' }} />
            </div>
          </div>
        </div>

        {/* KPI 2: Tỷ lệ chốt deal (Won Rate) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Tỷ lệ thắng Deal (Won Rate)
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400">
              31.2%
            </div>
            <div className="text-xs text-slate-500 mt-1">
              18 Deals chốt thành công trong kỳ
            </div>
          </div>
        </div>

        {/* KPI 3: Pipeline đang mở */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Tổng giá trị Pipeline
            </span>
            <div className="w-8 h-8 rounded-lg bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400 flex items-center justify-center">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-sky-600 dark:text-sky-400">
              18.600.000.000 ₫
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Phân bổ trên 25 cơ hội bán hàng lớn
            </div>
          </div>
        </div>

        {/* KPI 4: Đơn hàng chờ duyệt */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Đơn hàng chờ duyệt
            </span>
            <div className="w-8 h-8 rounded-lg bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <FileCheck2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400">
              5 Đơn hàng
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Cần Trưởng phòng duyệt để đẩy sang Kho
            </div>
          </div>
        </div>
      </div>

      {/* 3. Bảng xếp hạng Sales Rep Leaderboard & Đơn hàng chờ duyệt */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Bảng xếp hạng nhân viên */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-500" />
                <span>Bảng xếp hạng Hiệu suất Đội ngũ Sales</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Theo dõi tiến độ chỉ tiêu doanh số và số lượng deal đã chốt trong tháng.
              </p>
            </div>
            <button
              onClick={() => setActiveModule('sales-productivity')}
              className="text-xs font-semibold text-amber-700 dark:text-amber-400 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Xem Báo cáo NS</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
            {salesRepLeaderboard.map((rep) => {
              const rate = Math.round((rep.revenue / rep.target) * 100);
              return (
                <div key={rep.name} className="py-3 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="w-5 text-center font-bold text-xs text-slate-400 font-mono">
                      #{rep.rank}
                    </span>
                    <img
                      src={rep.avatar}
                      alt={rep.name}
                      className="w-9 h-9 rounded-full object-cover border border-slate-200 shrink-0"
                    />
                    <div className="min-w-0">
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                        {rep.name}
                      </h4>
                      <div className="text-xs text-slate-400">
                        Đã chốt: <strong className="text-slate-700 dark:text-slate-300">{rep.wonDeals} deals</strong> • Mục tiêu: {rep.target.toLocaleString('vi-VN')} ₫
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="font-mono font-bold text-sm text-emerald-600 dark:text-emerald-400">
                      {rep.revenue.toLocaleString('vi-VN')} ₫
                    </div>
                    <div className="text-xs text-slate-500 flex items-center justify-end gap-1.5 mt-0.5">
                      <span>Tiến độ:</span>
                      <span className={`font-bold ${rate >= 80 ? 'text-emerald-600' : 'text-amber-600'}`}>
                        {rate}%
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column: 8 Báo cáo Sales Shortcuts */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              8 Báo cáo Khối Sales
            </h3>
            <div className="space-y-2 text-xs">
              {[
                { id: 'sales-overview', label: '1. Tổng quan Sales' },
                { id: 'sales-revenue', label: '2. Báo cáo Doanh thu' },
                { id: 'sales-forecast', label: '3. Dự báo Doanh số' },
                { id: 'sales-funnel', label: '4. Phễu Bán hàng' },
                { id: 'sales-won', label: '5. Deal Thành công' },
                { id: 'sales-lost', label: '6. Deal Thất bại' },
                { id: 'sales-productivity', label: '7. Hiệu suất Nhân viên' },
                { id: 'sales-leads', label: '8. Quản lý & Phân tích Lead' },
              ].map((r) => (
                <button
                  key={r.id}
                  onClick={() => setActiveModule(r.id as any)}
                  className="w-full text-left p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:border-amber-500 hover:bg-amber-50/40 dark:hover:bg-amber-950/20 font-semibold transition-all flex items-center justify-between cursor-pointer group"
                >
                  <span className="text-slate-800 dark:text-slate-200 group-hover:text-amber-800 dark:group-hover:text-amber-300">
                    {r.label}
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-amber-700 group-hover:translate-x-0.5 transition-transform" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
