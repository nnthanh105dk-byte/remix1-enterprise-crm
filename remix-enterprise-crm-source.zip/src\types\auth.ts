/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * A+ CRM — MULTI-TENANT AUTHENTICATION & ORGANIZATION MANAGEMENT DATA TYPES
 * Kiến trúc Multi-Tenant độc lập theo Database riêng biệt & RBAC có Scope
 */

export type DatabaseStatus = 'READY' | 'PROVISIONING' | 'MIGRATING' | 'SUSPENDED' | 'ERROR';
export type TenantStatus = 'active' | 'trial' | 'suspended';
export type TenantPlan = 'Starter' | 'Business' | 'Enterprise';

export type PermissionScope = 'OWN' | 'TEAM' | 'DEPARTMENT' | 'COMPANY';
export type PermissionAction = 'view' | 'create' | 'edit' | 'delete';

/**
 * 01. TENANT (Doanh nghiệp thuê bao A+ CRM)
 * Mỗi Tenant có cơ sở dữ liệu riêng biệt (DB_{CODE}).
 */
export interface Tenant {
  id: string; // UUID hệ thống (e.g. tenant_8f92...)
  code: string; // Human-readable unique code (e.g. APLUS, ABC, XYZ)
  slug: string; // Subdomain slug (e.g. aplus, abc, xyz)
  name: string; // Tên công ty đầy đủ
  database: string; // Tên CSDL riêng biệt (e.g. DB_APLUS, DB_ABC)
  databaseStatus: DatabaseStatus;
  schemaVersion: string;
  storageGb: number;
  plan: TenantPlan;
  status: TenantStatus;
  userCount: number;
  maxUsers: number;
  departmentCount: number;
  customerCount: number;
  dealCount: number;
  taxCode: string;
  phone: string;
  address: string;
  email: string;
  website?: string;
  logoUrl?: string;
  createdAt: string;
  lastBackup: string;
  lastActivity: string;
}

// Alias tương thích ngược
export type Company = Tenant;
export type CompanyStatus = TenantStatus;

/**
 * 02. USER (Người dùng duy nhất toàn nền tảng A+)
 * User sở hữu định danh UUID toàn cục và không trực tiếp thuộc Tenant.
 */
export interface UserAccount {
  id: string; // UUID hệ thống (e.g. usr_72jd...)
  email: string;
  fullName: string;
  phone: string;
  avatar: string;
  passwordHash: string;
  isPlatformAdmin?: boolean; // Super Admin quản trị nền tảng (/platform)
  status: 'active' | 'locked';
  failedAttempts: number;
  lockedUntil?: string;
  createdAt: string;
}

/**
 * 03. DEPARTMENT (Phòng ban trong Tenant)
 */
export interface Department {
  id: string; // UUID (e.g. dept_sale_01)
  tenantId: string;
  code: string; // Human-readable code (e.g. SALE, MKT, TECH, HR, ACCOUNTING, OPERATIONS)
  name: string; // e.g. Phòng Kinh Doanh (Sales)
  description: string;
  managerName?: string;
  userCount: number;
}

/**
 * 04. POSITION (Chức vụ trong Phòng ban)
 */
export interface Position {
  id: string; // UUID
  tenantId: string;
  departmentId: string;
  code: string; // e.g. SALE_EXEC, SALE_LEAD, SALE_MGR
  name: string; // e.g. Sales Executive, Sales Leader, Sales Manager
  levelId: string;
}

/**
 * 05. LEVEL (Cấp bậc nhân sự)
 */
export interface Level {
  id: string; // UUID
  tenantId: string;
  name: string; // e.g. Staff, Leader, Manager, Director
  code: string; // e.g. LV_STAFF, LV_LEAD, LV_MGR, LV_DIR
  rank: number; // 1 (Staff), 2 (Leader), 3 (Manager), 4 (Director)
}

/**
 * 06. PERMISSION & SCOPE (Phân quyền theo phạm vi dữ liệu)
 */
export interface ModulePermission {
  module: 'Customer' | 'Lead' | 'Deal' | 'Product' | 'Order' | 'Contract' | 'Inventory' | 'Technical' | 'Report' | 'Settings';
  moduleLabel: string;
  actions: PermissionAction[];
  scope: PermissionScope; // OWN | TEAM | DEPARTMENT | COMPANY
}

/**
 * 07. ROLE (Vai trò hệ thống)
 */
export interface Role {
  id: string; // UUID
  tenantId: string;
  code: string; // e.g. SALE_STAFF, SALE_LEADER, SALE_MANAGER, COMPANY_ADMIN, TECH_STAFF
  name: string;
  description: string;
  defaultScope: PermissionScope;
  permissions: ModulePermission[];
}

/**
 * 08. MEMBERSHIP (Quan hệ giữa User và Tenant)
 * Một User có thể có nhiều Membership ở nhiều Tenant khác nhau.
 */
export interface Membership {
  id: string; // UUID (e.g. mem_81ks...)
  tenantId: string;
  userId: string;
  departmentId: string;
  positionId: string;
  levelId: string;
  roleId: string;
  employeeCode: string; // e.g. 0001
  username: string; // e.g. SALE-0001
  displayId: string; // e.g. APLUS-SALE-0001
  roleTitle: string; // Tên hiển thị vai trò (e.g. Sales Executive)
  status: 'active' | 'pending' | 'locked';
  joinedAt: string;
  permissions: ModulePermission[];
}

// Alias tương thích ngược
export type CompanyMember = Membership & {
  accountId: string; // mapping to userId
  companyId: string; // mapping to tenantId
  roleGroupId: string; // mapping to roleId
};

/**
 * 09. SESSION CONTEXT (Ngữ cảnh phiên làm việc sau khi Resolve)
 * Trả lời 5 câu hỏi cốt lõi tại mọi màn hình:
 * 1. Tôi đang ở công ty nào?
 * 2. Tôi đang thuộc phòng ban nào?
 * 3. Tôi đang có vai trò gì?
 * 4. Tôi được phép làm gì (Scope nào)?
 * 5. Dữ liệu tôi đang xem thuộc Tenant / Database nào?
 */
export interface SessionContext {
  userId: string;
  tenantId: string;
  membershipId: string;
  tenantCode: string;
  tenantName: string;
  database: string;
  databaseStatus: DatabaseStatus;
  username: string; // SALE-0001
  displayId: string; // APLUS-SALE-0001
  fullName: string;
  roleCode: string;
  roleTitle: string;
  departmentCode: string;
  departmentName: string;
  positionName: string;
  levelName: string;
  primaryScope: PermissionScope;
  permissions: ModulePermission[];
}

/**
 * 10. DATABASE PROVISIONING STEPS (Tiến trình tạo Tenant & Database)
 */
export interface ProvisioningStep {
  id: number;
  label: string;
  subtext: string;
  status: 'pending' | 'running' | 'completed' | 'error';
}

export interface JoinRequest {
  id: string;
  companyId: string;
  accountId: string;
  fullName: string;
  email: string;
  phone: string;
  requestedAt: string;
  status: 'pending' | 'approved' | 'rejected';
  roleGroupId?: string;
  employeeId?: string;
  reviewedBy?: string;
  reviewedAt?: string;
  rejectReason?: string;
}

export interface CompanyInvitation {
  id: string;
  companyId: string;
  code: string;
  roleGroupId: string;
  roleTitle: string;
  expiresAt: string;
  maxUses: number;
  usedCount: number;
  createdAt: string;
  createdBy: string;
  status: 'active' | 'expired' | 'revoked';
  linkUrl: string;
}

export interface PlatformConfig {
  allowNewCompanyRegistration: boolean;
  maxCompaniesAllowed: number;
  platformNotice?: string;
  activeControlDb: string; // 'CRM_CORE'
  totalDatabasesOnline: number;
}

export interface CompanyRegistrationRequest {
  id: string;
  companyName: string;
  companyCode: string;
  taxCode?: string;
  phone?: string;
  address?: string;
  adminName: string;
  email: string;
  adminPhone?: string;
  password: string;
  requestedAt: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  approvedAt?: string;
  databaseName?: string;
}

export type AuthScreenMode = 
  | 'LOGIN'
  | 'REGISTER'
  | 'PROVISIONING'
  | 'FORGOT_PASSWORD'
  | 'ACCEPT_INVITE'
  | 'JOIN_COMPANY'
  | 'SELECT_WORKSPACE';
