import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { Opportunity, OpportunityStage } from '../types/crm';
import {
  Briefcase,
  Plus,
  Kanban,
  Table as TableIcon,
  Search,
  Filter,
  DollarSign,
  Calendar,
  User,
  ArrowRight,
  ArrowLeft,
  X,
  Clock,
  CheckCircle2,
  Trash2,
  Edit,
  GitBranch,
} from 'lucide-react';

const STAGES: OpportunityStage[] = [
  'Khám phá nhu cầu',
  'Báo giá & Đề xuất',
  'Đàm phán',
  'Thành công (Won)',
  'Thất bại (Lost)',
];

export const OpportunitiesView: React.FC = () => {
  const {
    opportunities,
    addOpportunity,
    updateOpportunityStage,
    updateOpportunity,
    deleteOpportunity,
    hasPermission,
    language,
    showToast,
    setActiveModule,
  } = useCRM();

  const isVi = language === 'vi';
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [searchTerm, setSearchTerm] = useState('');
  const [stageFilter, setStageFilter] = useState<string>('all');

  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDeal, setEditingDeal] = useState<Opportunity | null>(null);

  const [formData, setFormData] = useState({
    title: '',
    contactName: 'Nguyễn Văn An',
    company: 'Dược Liệu Á Châu',
    stage: 'Khám phá nhu cầu' as OpportunityStage,
    amount: 350000000,
    probability: 40,
    expectedCloseDate: '2026-11-20',
    assignedTo: 'Trần Minh Đức',
    leadSource: 'Website',
    priority: 'Cao' as Opportunity['priority'],
  });

  const canCreate = hasPermission('opportunities', 'create');
  const canEdit = hasPermission('opportunities', 'edit');
  const canDelete = hasPermission('opportunities', 'delete');

  const formatVND = (num: number) => {
    if (num >= 1000000000) {
      return (num / 1000000000).toFixed(1) + ' Tỷ ₫';
    }
    if (num >= 1000000) {
      return (num / 1000000).toFixed(0) + ' Tr ₫';
    }
    return num.toLocaleString() + ' ₫';
  };

  const filteredOpportunities = opportunities.filter((opp) => {
    const matchesSearch =
      opp.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      opp.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      opp.contactName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStage = stageFilter === 'all' || opp.stage === stageFilter;
    return matchesSearch && matchesStage;
  });

  // Calculate totals per stage
  const getStageTotal = (stage: OpportunityStage) => {
    const stageDeals = opportunities.filter((o) => o.stage === stage);
    const sum = stageDeals.reduce((acc, curr) => acc + curr.amount, 0);
    return {
      count: stageDeals.length,
      amount: formatVND(sum),
    };
  };

  const openCreateModal = () => {
    setEditingDeal(null);
    setFormData({
      title: '',
      contactName: 'Nguyễn Văn An',
      company: 'Dược Liệu Á Châu',
      stage: 'Khám phá nhu cầu',
      amount: 250000000,
      probability: 30,
      expectedCloseDate: '2026-11-15',
      assignedTo: 'Trần Minh Đức',
      leadSource: 'Website',
      priority: 'Cao',
    });
    setIsModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    if (editingDeal) {
      updateOpportunity(editingDeal.id, formData);
      showToast('Thành công', 'Cập nhật cơ hội thành công');
    } else {
      addOpportunity(formData);
      showToast('Thành công', 'Đã thêm cơ hội mới vào Pipeline');
    }
    setIsModalOpen(false);
  };

  const advanceStage = (opp: Opportunity, next: boolean) => {
    const currentIndex = STAGES.indexOf(opp.stage);
    if (currentIndex === -1) return;
    const newIndex = next ? currentIndex + 1 : currentIndex - 1;
    if (newIndex >= 0 && newIndex < STAGES.length) {
      const newStage = STAGES[newIndex];
      updateOpportunityStage(opp.id, newStage);
      showToast('Cập nhật Pipeline', `Đã chuyển "${opp.title}" sang giai đoạn ${newStage}`);
    }
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-12">
      {/* 01. Context Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-[#0F172A] tracking-tight truncate">
              {isVi ? 'Cơ hội' : 'Opportunities'}
            </h1>
            <span className="text-xs font-mono font-medium text-[#64748B] bg-slate-100 px-2 py-0.5 rounded shrink-0">
              {opportunities.length} deals
            </span>
          </div>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5 truncate">
            {isVi
              ? 'Theo dõi luồng doanh thu tiềm năng từ Khám phá đến Chốt hợp đồng.'
              : 'End-to-end sales funnel tracking from Discovery to Closing.'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 flex-wrap">
          {/* View Mode Toggle */}
          <div className="flex items-center p-0.5 rounded-lg border border-[#E5E7EB] bg-[#F7F9FC] shrink-0">
            <button
              onClick={() => setViewMode('kanban')}
              className={`flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded-md text-[11px] sm:text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                viewMode === 'kanban'
                  ? 'bg-white shadow-xs text-[#002659] font-bold'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Kanban className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">Pipeline</span>
              <span className="sm:hidden">Board</span>
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`flex items-center gap-1 px-2 sm:px-2.5 py-1 rounded-md text-[11px] sm:text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                viewMode === 'table'
                  ? 'bg-white shadow-xs text-[#002659] font-bold'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">{isVi ? 'Bảng' : 'Table'}</span>
              <span className="sm:hidden">{isVi ? 'Bảng' : 'List'}</span>
            </button>
          </div>

          {canCreate && (
            <button
              onClick={openCreateModal}
              className="flex items-center gap-1 px-2 py-1 sm:px-3.5 sm:py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white text-[11px] sm:text-xs font-medium transition-colors shadow-xs whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">{isVi ? 'Tạo deal' : 'New Deal'}</span>
              <span className="sm:hidden">{isVi ? 'Deal' : 'New'}</span>
            </button>
          )}
        </div>
      </div>

      {/* 01.1 Pipeline Illustrated Funnel Card: 2/3 Stage Breakdown + 1/3 Illustrated Funnel */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl p-4 sm:p-5 shadow-xs">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
          {/* Left Column: Stage Performance Bars */}
          <div className="md:col-span-7 space-y-2.5">
            <div className="flex items-center justify-between mb-1">
              <div>
                <h3 className="text-xs sm:text-sm font-bold text-[#0F172A]">
                  {isVi ? 'Tổng quan Dòng chảy Pipeline' : 'Pipeline Flow Overview'}
                </h3>
                <p className="text-[11px] text-[#64748B]">
                  {isVi ? 'Khối lượng và giá trị phân bổ qua các tầng' : 'Stage deal distribution and closing trajectory'}
                </p>
              </div>
              <div className="text-right">
                <span className="text-xs sm:text-sm font-bold text-[#002659] font-mono tabular-nums">
                  {formatVND(opportunities.reduce((acc, curr) => acc + curr.amount, 0))}
                </span>
                <span className="block text-[10px] text-slate-400">
                  {opportunities.length} {isVi ? 'cơ hội' : 'deals'}
                </span>
              </div>
            </div>

            {/* Stages bars */}
            <div className="space-y-2 pt-1">
              {STAGES.map((stg) => {
                const { count, amount } = getStageTotal(stg);
                const totalDeals = opportunities.length || 1;
                const pct = Math.round((count / totalDeals) * 100);
                const isWon = stg === 'Thành công (Won)';
                const isLost = stg === 'Thất bại (Lost)';

                return (
                  <div key={stg} className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2 truncate">
                        <span className="font-medium text-[#0F172A] truncate max-w-[140px] sm:max-w-[200px]">
                          {stg}
                        </span>
                        <span className="text-slate-400 font-mono text-[11px] shrink-0">
                          {count} deals
                        </span>
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <span className="text-[10px] text-slate-400 font-mono">{pct}%</span>
                        <span className="font-semibold text-slate-700 font-mono tabular-nums text-xs">
                          {amount}
                        </span>
                      </div>
                    </div>
                    <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isWon ? 'bg-emerald-600' : isLost ? 'bg-rose-500' : 'bg-[#3661C9]'
                        }`}
                        style={{ width: `${Math.max(8, pct)}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Illustrated Funnel Diagram with TEXT OUTSIDE THE FUNNEL */}
          <div className="md:col-span-5 md:border-l md:border-[#E5E7EB] md:pl-4 flex flex-col justify-between">
            <div className="w-full flex items-center justify-between text-[11px] font-semibold text-[#64748B] uppercase tracking-wider mb-2.5">
              <span className="truncate">{isVi ? 'Mô tả Phễu Minh Họa' : 'Illustrated Funnel'}</span>
              <span className="text-[10px] font-mono text-[#002659] bg-[#F0F7FD] px-1.5 py-0.5 rounded border border-[#9CD7F8]/40 shrink-0">
                5 Giai đoạn
              </span>
            </div>

            {/* Funnel Geometry on the left + Clean Text Descriptions strictly OUTSIDE on the right */}
            <div className="flex items-stretch gap-3 py-1">
              {/* Visual Funnel Stack (Trapezoids only, zero text inside to avoid overlap) */}
              <div className="w-14 sm:w-16 shrink-0 flex flex-col items-center justify-between py-0.5">
                {/* Tier 1: Khám phá */}
                <div
                  className="w-full h-5 rounded-t-sm shadow-xs transition-transform hover:scale-105"
                  style={{
                    backgroundColor: '#002659',
                    clipPath: 'polygon(0% 0%, 100% 0%, 86% 100%, 14% 100%)',
                  }}
                  title="Tier 1: Khám phá nhu cầu"
                />
                {/* Tier 2: Báo giá */}
                <div
                  className="w-[84%] h-5 shadow-xs transition-transform hover:scale-105"
                  style={{
                    backgroundColor: '#1E4CB0',
                    clipPath: 'polygon(0% 0%, 100% 0%, 82% 100%, 18% 100%)',
                  }}
                  title="Tier 2: Báo giá & Đề xuất"
                />
                {/* Tier 3: Đàm phán */}
                <div
                  className="w-[66%] h-5 shadow-xs transition-transform hover:scale-105"
                  style={{
                    backgroundColor: '#3661C9',
                    clipPath: 'polygon(0% 0%, 100% 0%, 78% 100%, 22% 100%)',
                  }}
                  title="Tier 3: Đàm phán"
                />
                {/* Tier 4: Thành công */}
                <div
                  className="w-[48%] h-5 shadow-xs transition-transform hover:scale-105"
                  style={{
                    backgroundColor: '#16A34A',
                    clipPath: 'polygon(0% 0%, 100% 0%, 75% 100%, 25% 100%)',
                  }}
                  title="Tier 4: Thành công (Won)"
                />
                {/* Tier 5: Thất bại */}
                <div
                  className="w-[32%] h-5 rounded-b-sm shadow-xs transition-transform hover:scale-105"
                  style={{
                    backgroundColor: '#E11D48',
                    clipPath: 'polygon(0% 0%, 100% 0%, 85% 100%, 15% 100%)',
                  }}
                  title="Tier 5: Thất bại (Lost)"
                />
              </div>

              {/* External Description List: Positioned 100% outside the funnel, impossible to be covered */}
              <div className="flex-1 flex flex-col justify-between min-w-0 space-y-1">
                {/* Row 1: Khám phá */}
                <div className="flex items-center justify-between text-[11px] leading-none py-0.5 border-b border-slate-100">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#002659] shrink-0" />
                    <span className="font-semibold text-[#0F172A] truncate">Khám phá</span>
                  </div>
                  <span className="font-mono text-slate-500 font-medium ml-1 shrink-0 text-[10px]">
                    {getStageTotal('Khám phá nhu cầu').count} <span className="text-slate-400">• 100%</span>
                  </span>
                </div>

                {/* Row 2: Báo giá */}
                <div className="flex items-center justify-between text-[11px] leading-none py-0.5 border-b border-slate-100">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#1E4CB0] shrink-0" />
                    <span className="font-semibold text-[#0F172A] truncate">Báo giá</span>
                  </div>
                  <span className="font-mono text-slate-500 font-medium ml-1 shrink-0 text-[10px]">
                    {getStageTotal('Báo giá & Đề xuất').count} <span className="text-slate-400">• 75%</span>
                  </span>
                </div>

                {/* Row 3: Đàm phán */}
                <div className="flex items-center justify-between text-[11px] leading-none py-0.5 border-b border-slate-100">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#3661C9] shrink-0" />
                    <span className="font-semibold text-[#0F172A] truncate">Đàm phán</span>
                  </div>
                  <span className="font-mono text-slate-500 font-medium ml-1 shrink-0 text-[10px]">
                    {getStageTotal('Đàm phán').count} <span className="text-slate-400">• 50%</span>
                  </span>
                </div>

                {/* Row 4: Won */}
                <div className="flex items-center justify-between text-[11px] leading-none py-0.5 border-b border-slate-100">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#16A34A] shrink-0" />
                    <span className="font-bold text-emerald-700 truncate">Won</span>
                  </div>
                  <span className="font-mono text-emerald-600 font-bold ml-1 shrink-0 text-[10px]">
                    {getStageTotal('Thành công (Won)').count} <span className="text-emerald-500">• 25%</span>
                  </span>
                </div>

                {/* Row 5: Lost */}
                <div className="flex items-center justify-between text-[11px] leading-none py-0.5">
                  <div className="flex items-center gap-1.5 truncate">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#E11D48] shrink-0" />
                    <span className="font-medium text-rose-700 truncate">Lost</span>
                  </div>
                  <span className="font-mono text-rose-600 font-medium ml-1 shrink-0 text-[10px]">
                    {getStageTotal('Thất bại (Lost)').count}
                  </span>
                </div>
              </div>
            </div>

            {/* Bottom Conversion Metric */}
            <div className="w-full mt-2 pt-2 border-t border-[#F1F5F9] flex items-center justify-between text-[11px]">
              <span className="text-slate-500 truncate">{isVi ? 'Tỷ lệ thắng:' : 'Win Rate:'}</span>
              <span className="font-bold text-emerald-600 font-mono bg-emerald-50 px-1.5 py-0.5 rounded border border-emerald-200 shrink-0">
                {Math.round((getStageTotal('Thành công (Won)').count / (opportunities.length || 1)) * 100)}%
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* 02. Search & Quick Filters */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-[#E5E7EB]">
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={isVi ? 'Tìm theo tên deal, khách hàng, công ty...' : 'Search deals, customers, companies...'}
            className="w-full h-8.5 pl-8.5 pr-3 text-xs rounded-lg border border-[#E5E7EB] bg-[#F7F9FC] focus:bg-white focus:outline-hidden focus:border-[#3661C9] transition-colors"
          />
        </div>

        {viewMode === 'table' && (
          <select
            value={stageFilter}
            onChange={(e) => setStageFilter(e.target.value)}
            className="h-8.5 px-2.5 text-xs rounded-lg border border-[#E5E7EB] bg-white text-slate-700"
          >
            <option value="all">{isVi ? 'Tất cả giai đoạn' : 'All Stages'}</option>
            {STAGES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        )}
      </div>

      {/* 03. Pipeline Kanban View (Pipedrive inspired with Tấm 1 clean aesthetic) */}
      {viewMode === 'kanban' ? (
        <div className="flex gap-3.5 overflow-x-auto pb-4 items-start xl:grid xl:grid-cols-5 xl:overflow-x-visible snap-x snap-mandatory scroll-smooth">
          {STAGES.map((stage) => {
            const { count, amount } = getStageTotal(stage);
            const stageDeals = filteredOpportunities.filter((o) => o.stage === stage);
            const isWon = stage === 'Thành công (Won)';
            const isLost = stage === 'Thất bại (Lost)';

            return (
              <div
                key={stage}
                className="w-[260px] sm:w-[270px] md:w-[280px] shrink-0 xl:w-auto xl:shrink snap-start bg-[#F8FAFC] border border-[#E5E7EB] rounded-xl flex flex-col max-h-[calc(100vh-230px)]"
              >
                {/* Column Header */}
                <div className="p-3 border-b border-[#E5E7EB] bg-white rounded-t-xl">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#0F172A] truncate">
                      {stage}
                    </span>
                    <span className="text-[11px] font-mono text-[#64748B] bg-slate-100 px-1.5 py-0.2 rounded">
                      {count}
                    </span>
                  </div>
                  <div className="text-[11px] font-semibold text-[#002659] font-mono tabular-nums mt-0.5">
                    {amount}
                  </div>
                </div>

                {/* Cards Container */}
                <div className="p-2.5 overflow-y-auto space-y-2.5 flex-1 min-h-[200px]">
                  {stageDeals.length === 0 ? (
                    <div className="py-8 text-center text-[11px] text-[#94A3B8]">
                      {isVi ? 'Không có deal' : 'Empty stage'}
                    </div>
                  ) : (
                    stageDeals.map((opp) => (
                      <div
                        key={opp.id}
                        className="bg-white border border-[#E5E7EB] rounded-lg p-3 hover:border-slate-300 hover:shadow-xs transition-all group"
                      >
                        {/* Company & Deal Title */}
                        <div className="text-[11px] font-medium text-[#64748B] truncate">
                          {opp.company}
                        </div>
                        <h4 className="text-xs font-bold text-[#0F172A] mt-0.5 line-clamp-2 leading-snug">
                          {opp.title}
                        </h4>

                        {/* Deal Value */}
                        <div className="text-sm font-bold text-[#002659] font-mono tabular-nums mt-1.5">
                          {formatVND(opp.amount)}
                        </div>

                        {/* Next Action & Date */}
                        <div className="mt-2 pt-2 border-t border-[#F1F5F9] flex items-center justify-between text-[10px] text-[#64748B]">
                          <div className="flex items-center gap-1 truncate max-w-[120px]">
                            <Clock className="w-3 h-3 text-slate-400 shrink-0" />
                            <span className="truncate">{opp.expectedCloseDate}</span>
                          </div>
                          <span className="font-medium text-slate-700 font-mono">
                            {opp.probability}%
                          </span>
                        </div>

                        {/* Stage transition controls */}
                        <div className="mt-2 pt-1 flex items-center justify-between border-t border-slate-100">
                          <button
                            type="button"
                            onClick={() => advanceStage(opp, false)}
                            disabled={STAGES.indexOf(opp.stage) === 0}
                            className="p-1 text-slate-400 hover:text-slate-800 disabled:opacity-20"
                            title="Lùi 1 giai đoạn"
                          >
                            <ArrowLeft className="w-3 h-3" />
                          </button>

                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-slate-400">{opp.assignedTo.split(' ').pop()}</span>
                          </div>

                          <button
                            type="button"
                            onClick={() => advanceStage(opp, true)}
                            disabled={STAGES.indexOf(opp.stage) === STAGES.length - 1}
                            className="p-1 text-[#3661C9] hover:text-[#002659] disabled:opacity-20"
                            title="Tiến 1 giai đoạn"
                          >
                            <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* 04. Pipeline Table View */
        <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#E5E7EB] bg-[#F8FAFC] text-[11px] font-semibold uppercase tracking-wider text-[#64748B]">
                  <th className="py-2.5 px-4">{isVi ? 'Tên Cơ hội / Deal' : 'Deal Title'}</th>
                  <th className="py-2.5 px-4">{isVi ? 'Khách hàng & Công ty' : 'Customer'}</th>
                  <th className="py-2.5 px-4">{isVi ? 'Giai đoạn' : 'Stage'}</th>
                  <th className="py-2.5 px-4 text-right">{isVi ? 'Giá trị' : 'Amount'}</th>
                  <th className="py-2.5 px-4 text-center">{isVi ? 'Xác suất' : 'Probability'}</th>
                  <th className="py-2.5 px-4">{isVi ? 'Dự kiến chốt' : 'Expected Close'}</th>
                  <th className="py-2.5 px-4 text-right">{isVi ? 'Thao tác' : 'Actions'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E5E7EB] text-xs">
                {filteredOpportunities.map((opp) => (
                  <tr key={opp.id} className="hover:bg-[#F8FAFC] transition-colors">
                    <td className="py-3 px-4 font-semibold text-[#0F172A]">
                      {opp.title}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-800">{opp.contactName}</div>
                      <div className="text-[11px] text-slate-500">{opp.company}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#3661C9] dark:text-sky-400 whitespace-nowrap">
                        <span className="w-1.5 h-1.5 rounded-full bg-[#3661C9] dark:bg-sky-400 shrink-0" />
                        <span>{opp.stage}</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-[#002659] tabular-nums">
                      {formatVND(opp.amount)}
                    </td>
                    <td className="py-3 px-4 text-center font-mono font-medium text-slate-700">
                      {opp.probability}%
                    </td>
                    <td className="py-3 px-4 text-[11px] font-mono text-slate-500">
                      {opp.expectedCloseDate}
                    </td>
                    <td className="py-3 px-4 text-right">
                      {canDelete && (
                        <button
                          onClick={() => {
                            if (window.confirm(`Xóa deal ${opp.title}?`)) {
                              deleteOpportunity(opp.id);
                              showToast('Đã xóa deal', 'Đã gỡ bỏ deal khỏi pipeline', 'info');
                            }
                          }}
                          className="p-1 text-slate-400 hover:text-rose-600 rounded"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 05. Create / Edit Deal Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#E5E7EB] max-w-lg w-full shadow-2xl overflow-hidden animate-in fade-in duration-150">
            <div className="px-5 py-4 border-b border-[#E5E7EB] flex items-center justify-between bg-[#F8FAFC]">
              <h3 className="text-sm font-bold text-[#0F172A]">
                {editingDeal ? 'Chỉnh sửa cơ hội' : 'Tạo mới cơ hội (New Deal)'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">
                  {isVi ? 'Tên cơ hội / Dự án *' : 'Deal Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Ví dụ: Triển khai CRM & ERP cho chuỗi nhà thuốc"
                  className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Công ty khách hàng *' : 'Company *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Người liên hệ' : 'Contact Person'}
                  </label>
                  <input
                    type="text"
                    value={formData.contactName}
                    onChange={(e) => setFormData({ ...formData, contactName: e.target.value })}
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Giá trị deal (VNĐ)' : 'Amount (VND)'}
                  </label>
                  <input
                    type="number"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] font-mono focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Giai đoạn khởi tạo' : 'Stage'}
                  </label>
                  <select
                    value={formData.stage}
                    onChange={(e) => setFormData({ ...formData, stage: e.target.value as OpportunityStage })}
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] bg-white focus:outline-hidden focus:border-[#3661C9]"
                  >
                    {STAGES.map((s) => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Xác suất thành công (%)' : 'Probability (%)'}
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={formData.probability}
                    onChange={(e) => setFormData({ ...formData, probability: Number(e.target.value) })}
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] font-mono focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Ngày dự kiến chốt' : 'Expected Close Date'}
                  </label>
                  <input
                    type="date"
                    value={formData.expectedCloseDate}
                    onChange={(e) => setFormData({ ...formData, expectedCloseDate: e.target.value })}
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-[#E5E7EB] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-[#E5E7EB] text-slate-700 hover:bg-slate-50 font-medium"
                >
                  {isVi ? 'Hủy bỏ' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#002659] text-white font-medium hover:bg-[#001a3d] shadow-xs"
                >
                  {isVi ? 'Lưu Deal' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
