import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { ReportFilterState } from '../../types/crm';
import { ReportFilterBar } from '../../components/reports/ReportFilterBar';
import { ExecutiveStatCard } from '../../components/reports/ReportCharts';
import {
  MOCK_LEADS_ANALYSIS,
  MockLeadAnalysis,
  MOCK_SALES_REPS,
} from '../../data/mockReportsData';
import {
  UserPlus,
  PhoneForwarded,
  CheckCircle2,
  Clock,
  AlertTriangle,
  UserCheck,
  Send,
  Briefcase,
  Share2,
  Filter,
} from 'lucide-react';

interface SalesLeadsReportProps {
  filter: ReportFilterState;
  onChangeFilter: (updated: Partial<ReportFilterState>) => void;
}

export const SalesLeadsReport: React.FC<SalesLeadsReportProps> = ({
  filter,
  onChangeFilter,
}) => {
  const { showToast, themeDef } = useCRM();
  const [leadsList, setLeadsList] = useState<MockLeadAnalysis[]>(MOCK_LEADS_ANALYSIS);
  const [selectedLeadIds, setSelectedLeadIds] = useState<string[]>([]);
  const [assignRepModalOpen, setAssignRepModalOpen] = useState(false);
  const [targetRepId, setTargetRepId] = useState<string>('rep-01');

  // Filter leads
  const filteredLeads = leadsList.filter((l) => {
    if (filter.teamId !== 'all' && l.teamId !== filter.teamId) return false;
    if (filter.salesRepId !== 'all' && l.repId !== filter.salesRepId) return false;
    if (filter.source !== 'all' && l.source !== filter.source) return false;
    return true;
  });

  // Top KPIs
  const newLeadsCount = filteredLeads.filter((l) => l.status === 'Mới tạo').length;
  const contactedCount = filteredLeads.filter((l) => l.status === 'Đã liên hệ' || l.status === 'Đã thẩm định').length;
  const convertedCount = filteredLeads.filter((l) => l.status === 'Chuyển đổi thành Cơ hội').length;
  const conversionRate = filteredLeads.length > 0 ? Math.round((convertedCount / filteredLeads.length) * 100) : 0;
  const validResponseMinutes = filteredLeads.filter((l) => l.firstResponseMinutes > 0);
  const avgResponseTime =
    validResponseMinutes.length > 0
      ? Math.round(validResponseMinutes.reduce((sum, l) => sum + l.firstResponseMinutes, 0) / validResponseMinutes.length)
      : 15;

  // Source Analysis Aggregation
  const sourcesList: ('Facebook' | 'Zalo' | 'Website' | 'Giới thiệu' | 'Hotline' | 'Triển lãm')[] = [
    'Facebook',
    'Zalo',
    'Website',
    'Giới thiệu',
    'Hotline',
    'Triển lãm',
  ];

  const sourceMetrics = sourcesList.map((src) => {
    const srcLeads = filteredLeads.filter((l) => l.source === src);
    const count = srcLeads.length;
    const conv = srcLeads.filter((l) => l.status === 'Chuyển đổi thành Cơ hội').length;
    const rate = count > 0 ? Math.round((conv / count) * 100) : 0;
    const totalCost = srcLeads.reduce((sum, l) => sum + (l.campaignCost || 0), 0);
    const costPerLead = count > 0 ? Math.round(totalCost / count) : 0;

    return {
      source: src,
      count,
      converted: conv,
      rate,
      costPerLead,
    };
  });

  // Stagnant Leads (>24 hours) or Unassigned
  const stagnantLeads = filteredLeads.filter((l) => l.isStagnant || l.unassigned);

  // Toggle selection
  const handleToggleSelectLead = (id: string) => {
    setSelectedLeadIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedLeadIds(filteredLeads.map((l) => l.id));
    } else {
      setSelectedLeadIds([]);
    }
  };

  // Bulk Reassign Action
  const handleBulkReassign = () => {
    if (selectedLeadIds.length === 0) return;
    const rep = MOCK_SALES_REPS.find((r) => r.id === targetRepId);
    if (!rep) return;

    setLeadsList((prev) =>
      prev.map((l) => {
        if (selectedLeadIds.includes(l.id)) {
          return {
            ...l,
            repId: rep.id,
            repName: rep.name,
            teamId: rep.teamId,
            unassigned: false,
            isStagnant: false,
          };
        }
        return l;
      })
    );

    showToast(
      'Phân bổ thành công',
      `Đã chuyển giao ${selectedLeadIds.length} Lead cho chuyên viên ${rep.name} (${rep.teamName}).`,
      'success'
    );
    setSelectedLeadIds([]);
    setAssignRepModalOpen(false);
  };

  // Quick Action: Convert to Opportunity
  const handleConvertToOpportunity = (lead: MockLeadAnalysis) => {
    setLeadsList((prev) =>
      prev.map((l) => (l.id === lead.id ? { ...l, status: 'Chuyển đổi thành Cơ hội' } : l))
    );
    showToast(
      'Chuyển đổi thành công',
      `Lead "${lead.name}" đã được chuyển thành Cơ hội bán hàng chính thức.`,
      'success'
    );
  };

  return (
    <div className="space-y-6">
      {/* Shared Filter Bar */}
      <ReportFilterBar
        filter={filter}
        onChangeFilter={onChangeFilter}
        reportTitle="Báo cáo Quản lý & Phân tích Lead"
      />

      {/* 5 KPI Cards (Executive Style: Chỉ hiển thị Tiêu đề và Con số, bấm ! xem giải thích) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        <ExecutiveStatCard
          title="Lead Mới tạo"
          value={`${newLeadsCount} Lead`}
          icon={UserPlus}
          iconColor="bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-800"
          explanation="Tổng số khách hàng tiềm năng mới tiếp nhận trong kỳ, cần tiếp nhận và phân bổ chuyên viên xử lý."
        />

        <ExecutiveStatCard
          title="Đã liên hệ & thẩm định"
          value={`${contactedCount} Lead`}
          valueColor="text-indigo-600 dark:text-indigo-400"
          icon={PhoneForwarded}
          iconColor="bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400 border-indigo-200 dark:border-indigo-800"
          explanation="Các khách hàng tiềm năng đã được chuyên viên gọi điện hoặc trao đổi trực tiếp để thẩm định nhu cầu."
        />

        <ExecutiveStatCard
          title="Thành Cơ hội"
          value={`${convertedCount} Deal`}
          valueColor="text-emerald-600 dark:text-emerald-400"
          icon={Briefcase}
          iconColor="bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
          explanation="Số lượng Lead đạt tiêu chuẩn ngân sách và tiến trình để chuyển giao vào phễu bán hàng chính thức."
        />

        <ExecutiveStatCard
          title="Tỷ lệ chuyển đổi"
          value={`${conversionRate}%`}
          valueColor="text-purple-600 dark:text-purple-400"
          icon={CheckCircle2}
          iconColor="bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800"
          explanation="Tỷ lệ Lead trở thành Cơ hội bán hàng thực tế trên tổng số khách hàng tiềm năng tiếp nhận."
        />

        <ExecutiveStatCard
          title="Thời gian phản hồi TB"
          value={`${avgResponseTime} phút`}
          valueColor="text-amber-600 dark:text-amber-400"
          icon={Clock}
          iconColor="bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800"
          explanation="Thời gian bình quân từ lúc Lead phát sinh đến khi nhân viên thực hiện cuộc gọi đầu tiên (Chuẩn SLA: < 30 phút)."
        />
      </div>

      {/* Source Analysis Table */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-3`}>
        <h3 className="section-title">
          <Share2 className="w-4.5 h-4.5 text-sky-500 mr-2 shrink-0" />
          Phân tích hiệu quả theo Nguồn khách hàng (Lead Sources)
        </h3>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          So sánh số lượng, tỷ lệ chuyển đổi và chi phí bình quân trên mỗi Lead thu về
        </p>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Kênh nguồn</th>
                <th className="py-2.5 px-3 text-center">Số lượng Lead</th>
                <th className="py-2.5 px-3 text-center">Chuyển đổi thành Deal</th>
                <th className="py-2.5 px-3 text-center">Tỷ lệ chuyển đổi</th>
                <th className="py-2.5 px-3 text-right">Chi phí / Lead (VND)</th>
                <th className="py-2.5 px-3">Đánh giá chất lượng</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {sourceMetrics.map((sm, idx) => (
                <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-3 font-bold text-slate-900 dark:text-white">{sm.source}</td>
                  <td className="py-3 px-3 text-center font-mono font-bold text-sky-600">{sm.count}</td>
                  <td className="py-3 px-3 text-center font-mono font-bold text-emerald-600">{sm.converted}</td>
                  <td className="py-3 px-3 text-center">
                    <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {sm.rate}%
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-600 dark:text-slate-400">
                    {sm.costPerLead > 0 ? `${sm.costPerLead.toLocaleString('vi-VN')} đ` : '0 đ (Organic)'}
                  </td>
                  <td className="py-3 px-3">
                    {sm.rate >= 30 ? (
                      <span className="text-emerald-600 font-semibold text-[11px]">Rất cao (Ưu tiên ngân sách)</span>
                    ) : sm.rate >= 15 ? (
                      <span className="text-sky-600 font-semibold text-[11px]">Trung bình khá</span>
                    ) : (
                      <span className="text-slate-400 text-[11px]">Cần tối ưu đối tượng</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Stagnant & Unassigned Leads Alert Table with Quick Bulk Actions */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-4`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="section-title">
              <AlertTriangle className="w-4.5 h-4.5 text-rose-500 mr-2 shrink-0" />
              Cảnh báo: Lead chưa xử lý (&gt;24h) &amp; Lead chưa phân bổ
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Có thể chọn nhiều dòng để phân bổ lại hàng loạt cho nhân sự sales đang rảnh
            </p>
          </div>

          {/* Bulk Action Buttons */}
          {selectedLeadIds.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-sky-600">
                Đã chọn {selectedLeadIds.length} lead
              </span>
              <button
                onClick={() => setAssignRepModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#002659] text-white hover:bg-[#001c42] text-xs font-semibold shadow-xs transition-colors"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Phân bổ cho Sale</span>
              </button>
            </div>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3 w-8">
                  <input
                    type="checkbox"
                    aria-label="Chọn tất cả lead"
                    onChange={handleSelectAll}
                    checked={selectedLeadIds.length === filteredLeads.length && filteredLeads.length > 0}
                    className="rounded border-slate-300 text-sky-600"
                  />
                </th>
                <th className="py-3 px-3">Mã &amp; Họ tên Lead</th>
                <th className="py-3 px-3">Doanh nghiệp</th>
                <th className="py-3 px-3">Liên hệ</th>
                <th className="py-3 px-3">Nguồn</th>
                <th className="py-3 px-3">Tình trạng</th>
                <th className="py-3 px-3">Nhân sự phụ trách</th>
                <th className="py-3 px-3 text-center">Thao tác nhanh</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredLeads.map((lead) => {
                const isSelected = selectedLeadIds.includes(lead.id);

                return (
                  <tr
                    key={lead.id}
                    className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors ${
                      lead.isStagnant ? 'bg-rose-50/20 dark:bg-rose-950/10' : ''
                    } ${isSelected ? 'bg-sky-50/60 dark:bg-sky-950/30' : ''}`}
                  >
                    <td className="py-3 px-3">
                      <input
                        type="checkbox"
                        aria-label={`Chọn lead ${lead.name}`}
                        checked={isSelected}
                        onChange={() => handleToggleSelectLead(lead.id)}
                        className="rounded border-slate-300 text-sky-600"
                      />
                    </td>
                    <td className="py-3 px-3">
                      <p className="font-bold text-slate-900 dark:text-white">{lead.name}</p>
                      <span className="font-mono text-[10px] text-slate-400">{lead.code}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-800 dark:text-slate-200">
                      {lead.company}
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                      <p>{lead.phone}</p>
                      <p className="text-[10px] text-slate-400">{lead.email}</p>
                    </td>
                    <td className="py-3 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {lead.source}
                      </span>
                    </td>
                    <td className="py-3 px-3">
                      {lead.unassigned ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 animate-pulse">
                          Chưa phân bổ
                        </span>
                      ) : lead.isStagnant ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                          Quá 24h chưa gọi
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {lead.status}
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                      {lead.repName ? (
                        <span>{lead.repName}</span>
                      ) : (
                        <span className="text-amber-600 font-bold italic">Chưa giao</span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-center">
                      {lead.status !== 'Chuyển đổi thành Cơ hội' ? (
                        <button
                          onClick={() => handleConvertToOpportunity(lead)}
                          className="px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 transition-colors border border-emerald-200 dark:border-emerald-800 shadow-xs"
                        >
                          Lên Cơ hội
                        </button>
                      ) : (
                        <span className="text-emerald-600 font-semibold text-[11px]">Đã chuyển</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assign Sales Modal */}
      {assignRepModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <UserCheck className="w-5 h-5 text-sky-500" />
              Phân bổ {selectedLeadIds.length} Lead
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Chọn chuyên viên kinh doanh để tiếp nhận danh sách khách hàng tiềm năng đã chọn:
            </p>

            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Chuyên viên nhận bàn giao
              </label>
              <select
                value={targetRepId}
                onChange={(e) => setTargetRepId(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
              >
                {MOCK_SALES_REPS.map((rep) => (
                  <option key={rep.id} value={rep.id}>
                    {rep.name} - {rep.teamName} ({rep.region})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setAssignRepModalOpen(false)}
                className="px-3 py-1.5 text-xs font-medium rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                Hủy
              </button>
              <button
                onClick={handleBulkReassign}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001f4a] shadow-xs transition-colors"
              >
                Xác nhận bàn giao
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
