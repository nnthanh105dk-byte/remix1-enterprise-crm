import React, { createContext, useContext, useState } from 'react';
import { useCRM } from './CRMContext';
import { useSales } from './SalesContext';
import { useWarehouse } from './WarehouseContext';
import {
  Vehicle,
  Driver,
  Carrier,
  Supplier,
  PurchaseOrder,
  PurchaseInvoice,
  PaymentRequest,
  DeliveryNote,
  DeliveryNoteStatus,
  Shipment,
  HandoverRecord,
  CodCollection,
  DocumentExpiry,
  LogisticsProcessStatus,
} from '../types/logistics';
import {
  INITIAL_VEHICLES,
  INITIAL_DRIVERS,
  INITIAL_CARRIERS,
  INITIAL_SUPPLIERS,
  INITIAL_PURCHASE_ORDERS,
  INITIAL_PURCHASE_INVOICES,
  INITIAL_PAYMENT_REQUESTS,
  INITIAL_DELIVERY_NOTES,
  INITIAL_SHIPMENTS,
  INITIAL_HANDOVERS,
  INITIAL_COD_COLLECTIONS,
  INITIAL_DOCUMENT_EXPIRIES,
} from '../data/mockLogisticsData';
import { numberToVietnameseWords } from '../utils/vietnameseNumberWords';

interface LogisticsContextType {
  // Master data
  vehicles: Vehicle[];
  drivers: Driver[];
  carriers: Carrier[];
  suppliers: Supplier[];
  documentExpiries: DocumentExpiry[];
  addVehicle: (v: Omit<Vehicle, 'id'>) => Vehicle;
  updateVehicle: (id: string, updates: Partial<Vehicle>) => void;
  addDriver: (d: Omit<Driver, 'id'>) => Driver;
  updateDriver: (id: string, updates: Partial<Driver>) => void;
  addCarrier: (c: Omit<Carrier, 'id'>) => Carrier;
  addSupplier: (s: Omit<Supplier, 'id' | 'code'>) => Supplier;
  renewDocument: (id: string, newDocNumber: string, newExpiryDate: string, notes?: string) => void;
  addDocumentExpiry: (doc: Omit<DocumentExpiry, 'id'>) => DocumentExpiry;

  // Order Logistics Processing
  confirmOrder: (
    orderId: string,
    lineDecisions: { sku: string; confirmedQty: number; action: 'Đủ hàng' | 'Chờ nhập hàng' | 'Loại khỏi đơn' }[],
    expectedShipDate?: string,
    note?: string
  ) => void;
  requestMoreInfoOrder: (orderId: string, reason: string) => void;
  rejectLogisticsOrder: (orderId: string, reason: string) => void;
  addOrderComment: (orderId: string, sender: string, department: 'Sales' | 'Logistics', message: string) => void;
  sendOrderToLogistics: (orderId: string, note?: string) => void;
  pullBackOrder: (orderId: string) => void;

  // Delivery Notes
  deliveryNotes: DeliveryNote[];
  createDeliveryNoteFromStockOut: (
    orderId: string,
    stockOutReceiptId: string,
    stockOutReceiptNumber: string,
    recipientName: string,
    recipientPhone: string,
    deliveryAddress: string,
    codAmount: number,
    items: DeliveryNote['items'],
    note?: string
  ) => DeliveryNote;
  updateDeliveryNoteStatus: (
    id: string,
    status: DeliveryNoteStatus,
    details?: {
      deliveredAt?: string;
      receiverSignedName?: string;
      failedReason?: string;
      rescheduledDate?: string;
      proofPhotoUrl?: string;
    }
  ) => void;

  // Shipments
  shipments: Shipment[];
  createShipment: (data: Omit<Shipment, 'id' | 'code' | 'createdAt' | 'status'>) => Shipment;
  updateShipmentStatus: (id: string, status: Shipment['status']) => void;
  updateShipmentStopStatus: (
    shipmentId: string,
    stopNumber: number,
    status: 'Chờ giao' | 'Đang giao' | 'Đã giao' | 'Thất bại',
    arrivedAt?: string,
    note?: string
  ) => void;

  // Handovers
  handovers: HandoverRecord[];
  createHandoverRecord: (data: Omit<HandoverRecord, 'id' | 'code'>) => HandoverRecord;
  confirmHandoverRecord: (id: string) => void;
  createStockInForReturnedGoods: (handoverId: string) => void;

  // COD Collections
  codCollections: CodCollection[];
  createCodCollection: (data: Omit<CodCollection, 'id' | 'code' | 'status' | 'collectedAt'>) => CodCollection;
  remitCodCollections: (ids: string[], remittedToStaff: string) => void;

  // Purchase Orders (Mua hàng)
  purchaseOrders: PurchaseOrder[];
  createPurchaseOrder: (
    data: Omit<PurchaseOrder, 'id' | 'code' | 'status' | 'receivingProgress' | 'invoiceStatus' | 'relatedStockInReceiptIds' | 'chain'>
  ) => PurchaseOrder;
  approvePurchaseOrder: (id: string) => void;
  sendPurchaseOrderToSupplier: (id: string) => void;

  // Purchase Invoices (Hóa đơn mua)
  purchaseInvoices: PurchaseInvoice[];
  setPurchaseInvoices: React.Dispatch<React.SetStateAction<PurchaseInvoice[]>>;
  createPurchaseInvoice: (
    data: Omit<PurchaseInvoice, 'id' | 'code' | 'status' | 'threeWayMatchStatus' | 'chain'>
  ) => PurchaseInvoice;
  approveInvoiceException: (id: string, approverName: string, reason: string) => void;

  // Payment Requests (Đề nghị thanh toán)
  paymentRequests: PaymentRequest[];
  setPaymentRequests: React.Dispatch<React.SetStateAction<PaymentRequest[]>>;
  createPaymentRequest: (
    data: Omit<PaymentRequest, 'id' | 'code' | 'status' | 'chain'>
  ) => PaymentRequest;
  approvePaymentRequest: (id: string, approverName: string, level: 'Trưởng BP' | 'Giám đốc') => void;
  rejectPaymentRequest: (id: string, reason: string) => void;
  markPaymentRequestPaid: (id: string, accountantName: string) => void;
}

const LogisticsContext = createContext<LogisticsContextType | undefined>(undefined);

export const LogisticsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { showToast } = useCRM();
  const { orders, updateOrder, addDirectReceipt } = useSales();
  const { products, createStockInReceipt, createStockOutReceipt } = useWarehouse();

  // State
  const [vehicles, setVehicles] = useState<Vehicle[]>(INITIAL_VEHICLES);
  const [drivers, setDrivers] = useState<Driver[]>(INITIAL_DRIVERS);
  const [carriers, setCarriers] = useState<Carrier[]>(INITIAL_CARRIERS);
  const [suppliers, setSuppliers] = useState<Supplier[]>(INITIAL_SUPPLIERS);
  const [documentExpiries, setDocumentExpiries] = useState<DocumentExpiry[]>(INITIAL_DOCUMENT_EXPIRIES);
  const [deliveryNotes, setDeliveryNotes] = useState<DeliveryNote[]>(INITIAL_DELIVERY_NOTES);
  const [shipments, setShipments] = useState<Shipment[]>(INITIAL_SHIPMENTS);
  const [handovers, setHandovers] = useState<HandoverRecord[]>(INITIAL_HANDOVERS);
  const [codCollections, setCodCollections] = useState<CodCollection[]>(INITIAL_COD_COLLECTIONS);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(INITIAL_PURCHASE_ORDERS);
  const [purchaseInvoices, setPurchaseInvoices] = useState<PurchaseInvoice[]>(INITIAL_PURCHASE_INVOICES);
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>(INITIAL_PAYMENT_REQUESTS);

  // 1. MASTER DATA ACTIONS
  const addVehicle = (v: Omit<Vehicle, 'id'>): Vehicle => {
    const newV: Vehicle = { ...v, id: `veh-${Date.now()}` };
    setVehicles((prev) => [newV, ...prev]);
    showToast('Thêm xe thành công', `Phương tiện ${v.plateNumber} đã được thêm vào hệ thống.`);
    return newV;
  };

  const updateVehicle = (id: string, updates: Partial<Vehicle>) => {
    setVehicles((prev) => prev.map((v) => (v.id === id ? { ...v, ...updates } : v)));
    showToast('Cập nhật xe', 'Đã lưu thay đổi thông tin phương tiện.');
  };

  const addDriver = (d: Omit<Driver, 'id'>): Driver => {
    const newD: Driver = { ...d, id: `drv-${Date.now()}` };
    setDrivers((prev) => [newD, ...prev]);
    showToast('Thêm tài xế', `Tài xế ${d.fullName} đã được thêm vào danh sách đội xe.`);
    return newD;
  };

  const updateDriver = (id: string, updates: Partial<Driver>) => {
    setDrivers((prev) => prev.map((d) => (d.id === id ? { ...d, ...updates } : d)));
    showToast('Cập nhật tài xế', 'Đã lưu thay đổi thông tin tài xế.');
  };

  const addCarrier = (c: Omit<Carrier, 'id'>): Carrier => {
    const newC: Carrier = { ...c, id: `car-${Date.now()}` };
    setCarriers((prev) => [newC, ...prev]);
    showToast('Thêm đối tác vận chuyển', `Đơn vị vận tải ${c.name} đã được thêm.`);
    return newC;
  };

  const addSupplier = (s: Omit<Supplier, 'id' | 'code'>): Supplier => {
    const idx = suppliers.length + 1;
    const code = `NCC-${idx.toString().padStart(4, '0')}`;
    const newS: Supplier = { ...s, id: `supp-${Date.now()}`, code };
    setSuppliers((prev) => [newS, ...prev]);
    showToast('Tạo Nhà cung cấp', `Đã thêm NCC ${newS.name} (${code}).`);
    return newS;
  };

  const renewDocument = (id: string, newDocNumber: string, newExpiryDate: string, notes?: string) => {
    setDocumentExpiries((prev) =>
      prev.map((doc) => {
        if (doc.id !== id) return doc;
        const now = Date.now();
        const expTime = new Date(newExpiryDate).getTime();
        const daysRemaining = Math.round((expTime - now) / (1000 * 60 * 60 * 24));
        let status: DocumentExpiry['status'] = 'Còn hạn';
        if (daysRemaining < 0) status = 'Đã hết hạn';
        else if (daysRemaining <= 30) status = 'Cận hạn (≤30 ngày)';
        else if (daysRemaining <= 60) status = 'Cận hạn (31-60 ngày)';
        else if (daysRemaining <= 90) status = 'Cận hạn (61-90 ngày)';

        return {
          ...doc,
          documentNumber: newDocNumber,
          expiryDate: newExpiryDate,
          issueDate: new Date().toISOString().split('T')[0],
          daysRemaining,
          status,
          renewedDate: new Date().toISOString().split('T')[0],
          notes: notes || doc.notes,
        };
      })
    );
    showToast('Gia hạn giấy tờ thành công', `Giấy tờ ${newDocNumber} đã được gia hạn đến ${newExpiryDate}.`);
  };

  const addDocumentExpiry = (doc: Omit<DocumentExpiry, 'id'>): DocumentExpiry => {
    const newDoc: DocumentExpiry = { ...doc, id: `doc-${Date.now()}` };
    setDocumentExpiries((prev) => [newDoc, ...prev]);
    showToast('Thêm hồ sơ giấy tờ', `Đã lưu giấy tờ số ${newDoc.documentNumber}.`);
    return newDoc;
  };

  // 2. ORDER LOGISTICS PROCESSING
  const confirmOrder = (
    orderId: string,
    lineDecisions: { sku: string; confirmedQty: number; action: 'Đủ hàng' | 'Chờ nhập hàng' | 'Loại khỏi đơn' }[],
    expectedShipDate?: string,
    note?: string
  ) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;

    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const updatedItems = order.items.map((it) => {
      const decision = lineDecisions.find((d) => d.sku === it.sku);
      if (decision) {
        return {
          ...it,
          confirmedQuantity: decision.confirmedQty,
          lineAction: decision.action,
        };
      }
      return it;
    });

    const newHistory = [
      ...(order.statusHistory || []),
      {
        status: 'Đã xác nhận',
        changedBy: 'Logistics',
        changedAt: now,
        note: note || 'Logistics xác nhận đơn và giữ chỗ số lượng khả dụng.',
      },
    ];

    updateOrder(orderId, {
      logisticsStatus: 'Đã xác nhận',
      stockAllocated: true,
      items: updatedItems,
      expectedShipDate: expectedShipDate || order.expectedShipDate,
      statusHistory: newHistory,
    });

    showToast(
      'Xác nhận đơn hàng thành công',
      `Đơn hàng ${order.code} đã chuyển trạng thái "Đã xác nhận". Hệ thống đã giữ chỗ số lượng tồn kho.`,
      'success'
    );
  };

  const requestMoreInfoOrder = (orderId: string, reason: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const newComments = [
      ...(order.comments || []),
      {
        id: `cm-${Date.now()}`,
        sender: 'Logistics',
        department: 'Logistics' as const,
        message: `Yêu cầu bổ sung: ${reason}`,
        createdAt: now,
      },
    ];

    updateOrder(orderId, {
      logisticsStatus: 'Cần bổ sung',
      logisticsNeedInfoReason: reason,
      isLockedForSales: false, // Mở khóa để Sales sửa thông tin
      comments: newComments,
      statusHistory: [
        ...(order.statusHistory || []),
        { status: 'Cần bổ sung', changedBy: 'Logistics', changedAt: now, note: reason },
      ],
    });

    showToast('Đã trả về cho Sales', `Đơn hàng ${order.code} đã được chuyển về Sales để bổ sung thông tin.`);
  };

  const rejectLogisticsOrder = (orderId: string, reason: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

    updateOrder(orderId, {
      logisticsStatus: 'Từ chối',
      logisticsRejectionReason: reason,
      isLockedForSales: false,
      stockAllocated: false,
      statusHistory: [
        ...(order.statusHistory || []),
        { status: 'Từ chối bởi Logistics', changedBy: 'Logistics', changedAt: now, note: reason },
      ],
    });

    showToast('Từ chối đơn hàng', `Đã từ chối đơn hàng ${order.code} với lý do: ${reason}`, 'warning');
  };

  const addOrderComment = (orderId: string, sender: string, department: 'Sales' | 'Logistics', message: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const newComments = [
      ...(order.comments || []),
      {
        id: `cm-${Date.now()}`,
        sender,
        department,
        message,
        createdAt: now,
      },
    ];

    updateOrder(orderId, { comments: newComments });
    showToast('Đã gửi phản hồi', `Bình luận đã gửi cho đơn hàng ${order.code}.`);
  };

  const sendOrderToLogistics = (orderId: string, note?: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const comments = order.comments || [];
    if (note) {
      comments.push({
        id: `cm-${Date.now()}`,
        sender: 'Sales',
        department: 'Sales',
        message: note,
        createdAt: now,
      });
    }

    updateOrder(orderId, {
      logisticsStatus: 'Chờ xác nhận',
      sentToLogisticsAt: now,
      isLockedForSales: true,
      comments,
      statusHistory: [
        ...(order.statusHistory || []),
        { status: 'Gửi sang Logistics', changedBy: 'Sales', changedAt: now, note: note || 'Chuyển đơn sang bộ phận Logistics' },
      ],
    });

    showToast('Đã gửi Logistics', `Đơn hàng ${order.code} đã được chuyển sang hàng đợi xác nhận của Logistics.`, 'success');
  };

  const pullBackOrder = (orderId: string) => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) return;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

    updateOrder(orderId, {
      logisticsStatus: undefined,
      sentToLogisticsAt: undefined,
      isLockedForSales: false,
      stockAllocated: false,
      statusHistory: [
        ...(order.statusHistory || []),
        { status: 'Rút đơn về', changedBy: 'Sales', changedAt: now, note: 'Sales rút đơn khi Logistics chưa xác nhận' },
      ],
    });

    showToast('Rút đơn thành công', `Đơn hàng ${order.code} đã rút khỏi Logistics và mở khóa chỉnh sửa.`);
  };

  // 3. DELIVERY NOTES
  const createDeliveryNoteFromStockOut = (
    orderId: string,
    stockOutReceiptId: string,
    stockOutReceiptNumber: string,
    recipientName: string,
    recipientPhone: string,
    deliveryAddress: string,
    codAmount: number,
    items: DeliveryNote['items'],
    note?: string
  ): DeliveryNote => {
    const order = orders.find((o) => o.id === orderId);
    const id = `dn-${Date.now()}`;
    const code = `PGH-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newDN: DeliveryNote = {
      id,
      code,
      orderId,
      orderCode: order?.code || 'DH-2026-xxxx',
      stockOutReceiptId,
      stockOutReceiptNumber,
      customerId: order?.customerId || 'cust-1',
      customerName: order?.customerName || 'Khách hàng',
      customerPhone: recipientPhone,
      deliveryAddress,
      recipientName,
      recipientPhone,
      date: new Date().toISOString().split('T')[0],
      items,
      status: 'Chờ giao',
      codAmount,
      note,
      chain: {
        customerId: order?.customerId,
        customerCode: order?.customerCode,
        customerName: order?.customerName,
        orderId,
        orderCode: order?.code,
      },
    };

    setDeliveryNotes((prev) => [newDN, ...prev]);

    // Cập nhật đơn hàng: Đã xuất kho
    if (order) {
      updateOrder(orderId, { logisticsStatus: 'Đã xuất kho' });
    }

    showToast('Tạo Phiếu giao hàng thành công', `Phiếu giao ${code} đã sẵn sàng để xếp chuyến giao hàng.`);
    return newDN;
  };

  const updateDeliveryNoteStatus = (
    id: string,
    status: DeliveryNoteStatus,
    details?: {
      deliveredAt?: string;
      receiverSignedName?: string;
      failedReason?: string;
      rescheduledDate?: string;
      proofPhotoUrl?: string;
    }
  ) => {
    const dn = deliveryNotes.find((d) => d.id === id);
    if (!dn) return;

    setDeliveryNotes((prev) =>
      prev.map((d) => (d.id === id ? { ...d, status, ...details } : d))
    );

    // Cập nhật ngược về Đơn hàng để Sales nhìn thấy
    if (dn.orderId) {
      if (status === 'Đã giao') {
        updateOrder(dn.orderId, { logisticsStatus: 'Đã giao' });
      } else if (status === 'Giao một phần') {
        updateOrder(dn.orderId, { logisticsStatus: 'Giao một phần' });
      } else if (status === 'Đang giao') {
        updateOrder(dn.orderId, { logisticsStatus: 'Đang giao' });
      }
    }

    showToast('Cập nhật giao hàng', `Phiếu giao ${dn.code} đã cập nhật sang trạng thái "${status}".`);
  };

  // 4. SHIPMENTS
  const createShipment = (data: Omit<Shipment, 'id' | 'code' | 'createdAt' | 'status'>): Shipment => {
    const id = `sh-${Date.now()}`;
    const code = `CX-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newSh: Shipment = {
      ...data,
      id,
      code,
      status: 'Chờ xuất phát',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    setShipments((prev) => [newSh, ...prev]);

    // Cập nhật các Phiếu giao hàng liên quan -> Đã xếp chuyến
    setDeliveryNotes((prev) =>
      prev.map((dn) =>
        data.deliveryNoteIds.includes(dn.id)
          ? { ...dn, status: 'Đã xếp chuyến', shipmentId: id, shipmentCode: code, driverName: data.driverName }
          : dn
      )
    );

    showToast('Tạo chuyến hàng thành công', `Chuyến hàng ${code} đã được lập với ${data.stops.length} điểm dừng.`);
    return newSh;
  };

  const updateShipmentStatus = (id: string, status: Shipment['status']) => {
    const sh = shipments.find((s) => s.id === id);
    if (!sh) return;

    setShipments((prev) => prev.map((s) => (s.id === id ? { ...s, status } : s)));

    // Đồng bộ trạng thái phiếu giao
    if (status === 'Đang giao') {
      setDeliveryNotes((prev) =>
        prev.map((dn) => (sh.deliveryNoteIds.includes(dn.id) ? { ...dn, status: 'Đang giao' } : dn))
      );
    }

    showToast('Cập nhật chuyến hàng', `Chuyến ${sh.code} đã chuyển trạng thái sang "${status}".`);
  };

  const updateShipmentStopStatus = (
    shipmentId: string,
    stopNumber: number,
    status: 'Chờ giao' | 'Đang giao' | 'Đã giao' | 'Thất bại',
    arrivedAt?: string,
    note?: string
  ) => {
    const sh = shipments.find((s) => s.id === shipmentId);
    if (!sh) return;

    const stop = sh.stops.find((st) => st.stopNumber === stopNumber);
    if (stop && stop.deliveryNoteId) {
      const dnStatus: DeliveryNoteStatus = status === 'Đã giao' ? 'Đã giao' : status === 'Thất bại' ? 'Giao thất bại' : 'Đang giao';
      updateDeliveryNoteStatus(stop.deliveryNoteId, dnStatus, { deliveredAt: arrivedAt, failedReason: note });
    }

    setShipments((prev) =>
      prev.map((s) => {
        if (s.id !== shipmentId) return s;
        return {
          ...s,
          stops: s.stops.map((st) =>
            st.stopNumber === stopNumber ? { ...st, status, arrivedAt, note } : st
          ),
        };
      })
    );

    showToast('Cập nhật điểm giao', `Điểm dừng #${stopNumber} đã cập nhật sang "${status}".`);
  };

  // 5. HANDOVERS
  const createHandoverRecord = (data: Omit<HandoverRecord, 'id' | 'code'>): HandoverRecord => {
    const id = `bbg-${Date.now()}`;
    const code = `BBG-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newH: HandoverRecord = {
      ...data,
      id,
      code,
    };

    setHandovers((prev) => [newH, ...prev]);

    // Nếu là Bàn giao xuất phát: chuyến hàng tự chuyển sang Đang giao
    if (data.type === 'Bàn giao xuất phát') {
      updateShipmentStatus(data.shipmentId, 'Đang giao');
    }

    showToast('Lập Biên bản bàn giao', `Biên bản ${code} (${data.type}) đã được lập.`);
    return newH;
  };

  const createStockInForReturnedGoods = (handoverId: string) => {
    const handover = handovers.find((h) => h.id === handoverId);
    if (!handover || !handover.returnedItems || handover.returnedItems.length === 0) {
      showToast('Không có hàng hoàn', 'Biên bản này không có danh mục hàng hoàn về.', 'warning');
      return;
    }

    createStockInReceipt({
      date: new Date().toISOString().split('T')[0],
      importType: 'Khách trả hàng',
      warehouseId: 'wh-hn',
      warehouseName: 'Kho Tổng Hà Nội',
      supplierName: handover.receiverName || 'Khách hàng trả về từ chuyến',
      invoiceNumber: handover.code,
      items: handover.returnedItems.map((r) => ({
        sku: r.sku,
        productName: r.productName,
        quantity: r.quantityReturned,
        unitPrice: 0,
        total: 0,
      })),
      totalQuantity: handover.returnedItems.reduce((s, r) => s + r.quantityReturned, 0),
      totalAmount: 0,
      createdBy: 'Thủ kho tiếp nhận hoàn về',
      notes: `Tạo từ Biên bản bàn giao ${handover.code} của Chuyến ${handover.shipmentCode}`,
    });
    showToast('Tạo phiếu nhập kho thành công', `Đã lập phiếu nhập kho hàng hoàn về cho biên bản ${handover.code}.`);
  };

  const confirmHandoverRecord = (id: string) => {
    setHandovers((prev) =>
      prev.map((h) => (h.id === id ? { ...h, status: 'Đã xác nhận' } : h))
    );
    showToast('Đã xác nhận bàn giao', 'Biên bản bàn giao đã được cả hai bên ký nhận xác thực.');
  };

  // 6. COD COLLECTIONS
  const createCodCollection = (data: Omit<CodCollection, 'id' | 'code' | 'status' | 'collectedAt'>): CodCollection => {
    const id = `cod-${Date.now()}`;
    const code = `TH-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

    const newCod: CodCollection = {
      ...data,
      id,
      code,
      status: 'Đã thu - chờ nộp',
      collectedAt: now,
    };

    setCodCollections((prev) => [newCod, ...prev]);
    showToast('Ghi nhận thu tiền hộ', `Đã ghi nhận thu hộ ${newCod.amountCollected.toLocaleString()} đ từ phiếu ${data.deliveryNoteCode}.`);
    return newCod;
  };

  const remitCodCollections = (ids: string[], remittedToStaff: string) => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const today = new Date().toISOString().split('T')[0];

    const generatedReceipts: Record<string, { id: string; number: string }> = {};

    ids.forEach((id) => {
      const cod = codCollections.find((c) => c.id === id);
      if (cod && cod.status !== 'Đã nộp về công ty') {
        const receiptCode = `PT-2026-${Math.floor(1000 + Math.random() * 9000)}`;
        const rec = addDirectReceipt({
          receiptNumber: receiptCode,
          date: today,
          customerId: cod.customerId || '',
          customerCode: 'KH-COD',
          customerName: cod.customerName,
          payerName: cod.driverName || 'Tài xế giao hàng',
          amount: cod.amountCollected,
          amountInWords: numberToVietnameseWords(cod.amountCollected),
          paymentMethod: cod.paymentMethod === 'Chuyển khoản' ? 'Chuyển khoản' : 'Tiền mặt',
          reason: `Nộp tiền thu hộ COD từ phiếu giao ${cod.deliveryNoteCode}`,
          collectorName: remittedToStaff || 'Thủ quỹ công ty',
          status: 'Hoàn tất',
        });
        generatedReceipts[id] = { id: rec.id, number: rec.receiptNumber };
      }
    });

    setCodCollections((prev) =>
      prev.map((cod) => {
        if (!ids.includes(cod.id)) return cod;
        const recInfo = generatedReceipts[cod.id];
        return {
          ...cod,
          status: 'Đã nộp về công ty',
          remittedAt: now,
          remittedToStaff,
          salesReceiptId: recInfo ? recInfo.id : cod.salesReceiptId,
          salesReceiptNumber: recInfo ? recInfo.number : cod.salesReceiptNumber,
        };
      })
    );

    showToast(
      'Nộp tiền về công ty thành công',
      `Đã xác nhận nộp ${ids.length} phiếu thu hộ về quỹ công ty và sinh Phiếu thu bên Quản lý Sales.`,
      'success'
    );
  };

  // 7. PURCHASE ORDERS
  const createPurchaseOrder = (
    data: Omit<PurchaseOrder, 'id' | 'code' | 'status' | 'receivingProgress' | 'invoiceStatus' | 'relatedStockInReceiptIds' | 'chain'>
  ): PurchaseOrder => {
    const id = `po-${Date.now()}`;
    const code = `DMH-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newPo: PurchaseOrder = {
      ...data,
      id,
      code,
      status: 'Chờ duyệt',
      receivingProgress: 'Chưa nhận',
      invoiceStatus: 'Chưa có hóa đơn',
      relatedStockInReceiptIds: [],
      chain: {
        customerId: data.supplierId,
        customerCode: 'NCC',
        customerName: data.supplierName,
        orderCode: code,
      },
    };

    setPurchaseOrders((prev) => [newPo, ...prev]);
    showToast('Tạo Đơn mua hàng thành công', `Đơn mua ${code} đã lập và gửi lên cấp quản lý phê duyệt.`);
    return newPo;
  };

  const approvePurchaseOrder = (id: string) => {
    setPurchaseOrders((prev) =>
      prev.map((po) => (po.id === id ? { ...po, status: 'Đã duyệt' } : po))
    );
    showToast('Phê duyệt Đơn mua hàng', `Đơn mua đã duyệt, có thể gửi nhà cung cấp hoặc lập phiếu nhập kho.`);
  };

  const sendPurchaseOrderToSupplier = (id: string) => {
    setPurchaseOrders((prev) =>
      prev.map((po) => (po.id === id ? { ...po, status: 'Đã gửi nhà cung cấp' } : po))
    );
    showToast('Đã gửi Nhà cung cấp', `Đơn mua hàng đã được gửi email thông báo chính thức tới đối tác.`);
  };

  // 8. PURCHASE INVOICES
  const createPurchaseInvoice = (
    data: Omit<PurchaseInvoice, 'id' | 'code' | 'status' | 'threeWayMatchStatus' | 'chain'>
  ): PurchaseInvoice => {
    const id = `pi-${Date.now()}`;
    const code = `HDM-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    // Kiểm tra đối chiếu 3 bên (PO - Phiếu Nhập - Hóa đơn)
    let qtyMismatch = false;
    let priceMismatch = false;

    data.items.forEach((it) => {
      if (it.stockInQuantity < it.invoiceQuantity) qtyMismatch = true;
      if (Math.abs(it.poPrice - it.invoicePrice) > 1000) priceMismatch = true;
    });

    let matchStatus: PurchaseInvoice['threeWayMatchStatus'] = 'Khớp';
    let status: PurchaseInvoice['status'] = 'Chờ thanh toán';

    if (qtyMismatch && priceMismatch) {
      matchStatus = 'Lệch cả hai';
      status = 'Chênh lệch';
    } else if (qtyMismatch) {
      matchStatus = 'Lệch số lượng';
      status = 'Chênh lệch';
    } else if (priceMismatch) {
      matchStatus = 'Lệch đơn giá';
      status = 'Chênh lệch';
    }

    const newPi: PurchaseInvoice = {
      ...data,
      id,
      code,
      status,
      threeWayMatchStatus: matchStatus,
      chain: {
        customerId: data.supplierId,
        customerCode: 'NCC',
        customerName: data.supplierName,
        orderCode: data.purchaseOrderCode,
        invoiceCode: code,
      },
    };

    setPurchaseInvoices((prev) => [newPi, ...prev]);

    if (status === 'Chênh lệch') {
      showToast(
        'Cảnh báo đối chiếu 3 bên',
        `Hóa đơn ${code} bị CHÊNH LỆCH (${matchStatus}). Đã chặn tạo đề nghị thanh toán cho đến khi duyệt ngoại lệ.`,
        'warning'
      );
    } else {
      showToast('Khớp hóa đơn mua thành công', `Hóa đơn ${code} đối chiếu 3 bên khớp 100%.`);
    }

    return newPi;
  };

  const approveInvoiceException = (id: string, approverName: string, reason: string) => {
    setPurchaseInvoices((prev) =>
      prev.map((pi) =>
        pi.id === id
          ? {
              ...pi,
              status: 'Chờ thanh toán',
              exceptionApproval: {
                approvedBy: approverName,
                approvedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
                reason,
              },
            }
          : pi
      )
    );
    showToast('Duyệt ngoại lệ chênh lệch', `Hóa đơn đã được mở khóa để có thể tạo Đề nghị thanh toán.`);
  };

  // 9. PAYMENT REQUESTS
  const createPaymentRequest = (
    data: Omit<PaymentRequest, 'id' | 'code' | 'status' | 'chain'>
  ): PaymentRequest => {
    const id = `dntt-${Date.now()}`;
    const code = `DNTT-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newReq: PaymentRequest = {
      ...data,
      id,
      code,
      status: 'Chờ duyệt (Trưởng BP)',
      chain: {},
    };

    setPaymentRequests((prev) => [newReq, ...prev]);
    showToast('Tạo Đề nghị thanh toán', `Phiếu đề nghị ${code} đã được gửi lên Trưởng bộ phận phê duyệt.`);
    return newReq;
  };

  const approvePaymentRequest = (id: string, approverName: string, level: 'Trưởng BP' | 'Giám đốc') => {
    setPaymentRequests((prev) =>
      prev.map((pr) => {
        if (pr.id !== id) return pr;
        if (level === 'Trưởng BP') {
          // Nếu số tiền > 100.000.000 cần Giám đốc duyệt tiếp
          if (pr.totalAmount > 100000000) {
            return {
              ...pr,
              status: 'Chờ duyệt (Giám đốc)',
              approvalNotes: `Trưởng BP (${approverName}) đã duyệt, chuyển Giám đốc phê duyệt do giá trị > 100 triệu.`,
            };
          }
          return { ...pr, status: 'Đã duyệt', approvalNotes: `Trưởng BP (${approverName}) đã duyệt.` };
        } else {
          return { ...pr, status: 'Đã duyệt', approvalNotes: `Giám đốc (${approverName}) đã duyệt chi.` };
        }
      })
    );
    showToast('Phê duyệt Đề nghị thanh toán', `Đề nghị thanh toán đã được phê duyệt ở cấp ${level}.`);
  };

  const rejectPaymentRequest = (id: string, reason: string) => {
    setPaymentRequests((prev) =>
      prev.map((pr) => (pr.id === id ? { ...pr, status: 'Từ chối', approvalNotes: reason } : pr))
    );
    showToast('Từ chối Đề nghị thanh toán', `Đã từ chối phiếu với lý do: ${reason}`, 'warning');
  };

  const markPaymentRequestPaid = (id: string, accountantName: string) => {
    const pr = paymentRequests.find((p) => p.id === id);
    if (!pr) return;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);

    setPaymentRequests((prev) =>
      prev.map((p) => (p.id === id ? { ...p, status: 'Đã chi', paidAt: now, accountantName } : p))
    );

    // Cập nhật các Hóa đơn mua hàng liên quan -> Đã thanh toán
    if (pr.relatedDocumentCodes && pr.relatedDocumentCodes.length > 0) {
      setPurchaseInvoices((prev) =>
        prev.map((pi) =>
          pr.relatedDocumentCodes.includes(pi.code)
            ? { ...pi, status: 'Đã thanh toán', paidAmount: pi.totalAmount, remainingAmount: 0 }
            : pi
        )
      );
    }

    showToast('Xác nhận Đã chi tiền', `Kế toán ${accountantName} đã xác nhận chi tiền phiếu ${pr.code}.`, 'success');
  };

  return (
    <LogisticsContext.Provider
      value={{
        vehicles,
        drivers,
        carriers,
        suppliers,
        documentExpiries,
        addVehicle,
        updateVehicle,
        addDriver,
        updateDriver,
        addCarrier,
        addSupplier,
        renewDocument,
        addDocumentExpiry,

        confirmOrder,
        requestMoreInfoOrder,
        rejectLogisticsOrder,
        addOrderComment,
        sendOrderToLogistics,
        pullBackOrder,

        deliveryNotes,
        createDeliveryNoteFromStockOut,
        updateDeliveryNoteStatus,

        shipments,
        createShipment,
        updateShipmentStatus,
        updateShipmentStopStatus,

        handovers,
        createHandoverRecord,
        confirmHandoverRecord,
        createStockInForReturnedGoods,

        codCollections,
        createCodCollection,
        remitCodCollections,

        purchaseOrders,
        createPurchaseOrder,
        approvePurchaseOrder,
        sendPurchaseOrderToSupplier,

        purchaseInvoices,
        setPurchaseInvoices,
        createPurchaseInvoice,
        approveInvoiceException,

        paymentRequests,
        setPaymentRequests,
        createPaymentRequest,
        approvePaymentRequest,
        rejectPaymentRequest,
        markPaymentRequestPaid,
      }}
    >
      {children}
    </LogisticsContext.Provider>
  );
};

export const useLogistics = () => {
  const context = useContext(LogisticsContext);
  if (!context) {
    throw new Error('useLogistics must be used within a LogisticsProvider');
  }
  return context;
};
