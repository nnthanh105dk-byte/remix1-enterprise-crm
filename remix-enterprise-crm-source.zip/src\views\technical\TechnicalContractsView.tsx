import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useTechnical } from '../../context/TechnicalContext';
import { SalesContract } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import {
  FileCheck2,
  Search,
  CheckCircle2,
  Clock,
  User,
  Calendar,
  Layers,
  Wrench,
  Check,
  X,
  Plus,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  FolderKanban,
  FileText,
} from 'lucide-react';

export const TechnicalContractsView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { contracts, updateContract } = useSales();
  const {
    acceptContractForDeployment,
    createAcceptanceCertificate,
    acceptanceCertificates,
    customerEquipments,
    projects,
  } = useTechnical();

  // Tabs
  const [activeTab, setActiveTab] = useState<'pending' | 'all'>('pending');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedContract, setSelectedContract] = useState<SalesContract | null>(null);
  const [detailTab, setDetailTab] = useState<'scope' | 'equipments' | 'maintenance' | 'acceptance' | 'docs'>('scope');

  // Modal Tiếp nhận hợp đồng
  const [isAcceptModalOpen, setIsAcceptModalOpen] = useState(false);
  const [assignedPM, setAssignedPM] = useState('Trần Văn Nam (Kỹ sư Trưởng)');

  // Modal Lập Biên Bản Nghiệm Thu (BBNT)
  const [isBBNTModalOpen, setIsBBNTModalOpen] = useState(false);
  const [confirmRecordEquipments, setConfirmRecordEquipments] = useState(true);
  const [isMaintenanceModalOpen, setIsMaintenanceModalOpen] = useState(false);
  const [maintenanceForm, setMaintenanceForm] = useState({
    intervalMonths: 3,
    totalRounds: 4,
    startDate: '2026-03-15',
    assignedTech: 'Trần Văn Nam',
  });
  const [contractMaintenanceSchedules, setContractMaintenanceSchedules] = useState<Record<string, Array<{ period: string; date: string; status: string; tech: string }>>>({
    'contract-1': [
      { period: 'Đợt 1 - Quý I/2026', date: '2026-03-15', status: 'Đã hoàn tất', tech: 'Trần Văn Nam' },
      { period: 'Đợt 2 - Quý II/2026', date: '2026-06-15', status: 'Đã hoàn tất', tech: 'Nguyễn Văn Tuấn' },
      { period: 'Đợt 3 - Quý III/2026', date: '2026-09-15', status: 'Đã hoàn tất', tech: 'Lê Hữu Đạt' },
      { period: 'Đợt 4 - Quý IV/2026', date: '2026-12-15', status: 'Sắp tới hạn', tech: 'Trần Văn Nam' },
    ],
  });
  const [bbntForm, setBbntForm] = useState({
    customerRepresentative: '',
    customerRepRole: 'Đại diện kỹ thuật khách hàng',
    techRepresentative: 'Trần Văn Nam',
    scopeAccepted: 'Nghiệm thu toàn bộ thiết bị và chạy thử tải hệ thống',
    result: 'Đạt' as 'Đạt' | 'Không đạt',
    milestoneTitle: '',
    notes: 'Toàn bộ tiêu chí đo kiểm đạt yêu cầu kỹ thuật.',
  });

  // Hợp đồng kỹ thuật (hoặc tất cả hợp đồng có trạng thái chuyển kỹ thuật)
  const techContracts = contracts.filter((c) => c.status === 'Đang hiệu lực' || c.status === 'Chờ ký');

  const pendingContracts = techContracts.filter((c) => {
    // Nếu chưa có dự án tương ứng trong Kỹ thuật thì là chờ tiếp nhận
    return !projects.some((p) => p.contractId === c.id);
  });

  const filteredContracts = (activeTab === 'pending' ? pendingContracts : techContracts).filter((c) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        c.contractNumber.toLowerCase().includes(q) ||
        c.title.toLowerCase().includes(q) ||
        c.customerName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleAcceptSubmit = () => {
    if (!selectedContract) return;
    acceptContractForDeployment(selectedContract.id, assignedPM);
    setIsAcceptModalOpen(false);
  };

  const handleCreateBBNT = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedContract) return;

    createAcceptanceCertificate({
      projectId: projects.find((p) => p.contractId === selectedContract.id)?.id || 'proj-1',
      projectCode: projects.find((p) => p.contractId === selectedContract.id)?.code || 'DA-2026-0001',
      contractId: selectedContract.id,
      contractCode: selectedContract.contractNumber,
      customerId: selectedContract.customerId,
      customerName: selectedContract.customerName,
      acceptanceDate: new Date().toISOString().split('T')[0],
      customerRepresentative: bbntForm.customerRepresentative || 'Đại diện khách hàng',
      customerRepRole: bbntForm.customerRepRole,
      techRepresentative: bbntForm.techRepresentative,
      scopeAccepted: bbntForm.scopeAccepted,
      result: bbntForm.result,
      milestoneTitleToTrigger: bbntForm.milestoneTitle,
      activatedEquipmentsCount: 2,
      notes: bbntForm.notes,
    });

    setIsBBNTModalOpen(false);
  };

  const contractEquipments = customerEquipments.filter(
    (eq) => selectedContract && eq.customerId === selectedContract.customerId
  );

  const contractCertificates = acceptanceCertificates.filter(
    (cert) => selectedContract && cert.contractId === selectedContract.id
  );

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50">
              <FileCheck2 className="w-5 h-5" />
            </span>
            Hợp Đồng Triển Khai Kỹ Thuật (Contracts)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Tiếp nhận hợp đồng đã ký từ Sales, lập dự án thi công lắp đặt, nghiệm thu theo giai đoạn (BBNT) và kích hoạt mốc thanh toán
          </p>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('pending')}
            className={`py-2.5 px-4 font-bold border-b-2 flex items-center gap-2 transition-colors ${
              activeTab === 'pending'
                ? 'border-sky-600 text-sky-600 dark:text-sky-400 bg-sky-50/50 dark:bg-sky-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <span>Chờ tiếp nhận triển khai</span>
            {pendingContracts.length > 0 && (
              <span className="px-1.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-amber-500 text-white">
                {pendingContracts.length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('all')}
            className={`py-2.5 px-4 font-bold border-b-2 transition-colors ${
              activeTab === 'all'
                ? 'border-sky-600 text-sky-600 dark:text-sky-400 bg-sky-50/50 dark:bg-sky-950/30'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Tất cả hợp đồng ({techContracts.length})
          </button>
        </div>

        <div className="relative max-w-xs w-full pb-1">
          <input
            type="text"
            placeholder="Tìm số hợp đồng, tên khách hàng..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-8 pr-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-3" />
        </div>
      </div>

      {/* Main 2 Cột */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Danh sách hợp đồng bên trái */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col h-[750px] overflow-hidden">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 font-bold text-xs text-slate-700 dark:text-slate-300">
            Danh Sách Hợp Đồng ({filteredContracts.length})
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {filteredContracts.map((ctr) => {
              const isSelected = selectedContract?.id === ctr.id;
              const hasProject = projects.some((p) => p.contractId === ctr.id);

              return (
                <div
                  key={ctr.id}
                  onClick={() => setSelectedContract(ctr)}
                  className={`p-3.5 cursor-pointer transition-colors text-xs space-y-1.5 ${
                    isSelected
                      ? 'bg-sky-50/80 dark:bg-sky-950/40 border-l-4 border-sky-600'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono font-bold text-sky-600 dark:text-sky-400">{ctr.contractNumber}</span>
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        hasProject
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                          : 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                      }`}
                    >
                      {hasProject ? 'Đang triển khai' : 'Chờ tiếp nhận'}
                    </span>
                  </div>

                  <h4 className="font-bold text-slate-900 dark:text-white line-clamp-1">{ctr.title}</h4>
                  <p className="text-slate-500 dark:text-slate-400 text-[11px]">{ctr.customerName}</p>

                  <div className="flex items-center justify-between text-[11px] pt-1 border-t border-slate-100 dark:border-slate-800/60">
                    <span className="text-slate-400 font-mono">
                      Giá trị: {ctr.totalValue.toLocaleString()} đ
                    </span>
                    <span className="text-slate-400 font-mono">
                      Hạn: {ctr.endDate}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Khung chi tiết hợp đồng bên phải */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col h-[750px] overflow-hidden">
          {selectedContract ? (
            <>
              {/* Header */}
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-mono font-bold text-sky-600 bg-sky-50 dark:bg-sky-950 px-2 py-0.5 rounded">
                      {selectedContract.contractNumber}
                    </span>
                    <span className="text-slate-400">Hiệu lực: {selectedContract.startDate} &rarr; {selectedContract.endDate}</span>
                  </div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base">
                    {selectedContract.title}
                  </h3>
                  <p className="text-slate-500 text-[11px]">{selectedContract.customerName}</p>
                </div>

                <div className="flex items-center gap-2">
                  {!projects.some((p) => p.contractId === selectedContract.id) ? (
                    <button
                      onClick={() => setIsAcceptModalOpen(true)}
                      className="px-3.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold shadow-xs flex items-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      <span>Tiếp nhận &amp; Lập dự án &rarr;</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => {
                        setActiveModule('technical-master-planning');
                      }}
                      className="px-3 py-1.5 rounded-lg border border-sky-300 text-sky-600 hover:bg-sky-50 font-semibold flex items-center gap-1"
                    >
                      <FolderKanban className="w-4 h-4" />
                      <span>Kế hoạch tổng thể</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setBbntForm({
                        ...bbntForm,
                        milestoneTitle: selectedContract.paymentMilestones[0]?.title || '',
                      });
                      setIsBBNTModalOpen(true);
                    }}
                    className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs flex items-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Lập Biên bản nghiệm thu (BBNT)</span>
                  </button>
                </div>
              </div>

              {/* Document Chain Bar */}
              <div className="p-3 bg-slate-100/60 dark:bg-slate-950/40 border-b border-slate-200 dark:border-slate-800 shrink-0">
                <DocumentChainBar chain={selectedContract.chain} currentType="contract" />
              </div>

              {/* Sub-tabs Switcher */}
              <div className="flex items-center gap-1 overflow-x-auto px-4 border-b border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-950/40 text-xs scrollbar-none">
                {[
                  { id: 'scope', label: 'Phạm vi & Tiến độ' },
                  { id: 'equipments', label: `Thiết bị liên quan (${contractEquipments.length})` },
                  { id: 'maintenance', label: 'Lịch bảo trì định kỳ' },
                  { id: 'acceptance', label: `Nghiệm thu (${contractCertificates.length})` },
                  { id: 'docs', label: 'Tài liệu đính kèm' },
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setDetailTab(t.id as any)}
                    className={`py-2.5 px-3 font-semibold whitespace-nowrap border-b-2 transition-colors ${
                      detailTab === t.id
                        ? 'border-sky-600 text-sky-600 dark:text-sky-400 bg-white dark:bg-slate-900'
                        : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {/* Sub-tab Contents */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 text-xs space-y-4">
                {/* 1. Phạm vi & Mốc thanh toán gắn nghiệm thu */}
                {detailTab === 'scope' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 block text-[11px]">SLA phản hồi</span>
                        <span className="text-base font-bold text-slate-900 dark:text-white">Trong vòng 02 giờ</span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 block text-[11px]">SLA khắc phục</span>
                        <span className="text-base font-bold text-slate-900 dark:text-white">Tối đa 08 giờ</span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 block text-[11px]">Chu kỳ bảo trì</span>
                        <span className="text-base font-bold text-sky-600 dark:text-sky-400">03 tháng / lần</span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 block text-[11px]">Người phụ trách Sales</span>
                        <span className="text-base font-bold text-slate-800 dark:text-slate-200">{selectedContract.manager}</span>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-bold text-slate-900 dark:text-white text-sm mb-2">
                        Các Mốc Nghiệm Thu &amp; Kích Hoạt Thanh Toán:
                      </h4>
                      <div className="space-y-2">
                        {selectedContract.paymentMilestones.map((m, idx) => (
                          <div
                            key={idx}
                            className={`p-3 rounded-xl border flex items-center justify-between ${
                              m.isPaid
                                ? 'bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                                : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800'
                            }`}
                          >
                            <div className="flex items-center gap-3">
                              <span
                                className={`w-6 h-6 rounded-full flex items-center justify-center font-bold text-xs ${
                                  m.isPaid ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                                }`}
                              >
                                {idx + 1}
                              </span>
                              <div>
                                <h5 className="font-bold text-slate-900 dark:text-white">{m.title}</h5>
                                <span className="text-[11px] text-slate-500">
                                  Tỷ lệ: {m.percentage}% | Hạn: {m.dueDate}
                                </span>
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="font-mono font-bold text-slate-900 dark:text-white block">
                                {m.amount.toLocaleString()} đ
                              </span>
                              <span
                                className={`text-[10px] font-bold ${
                                  m.isPaid ? 'text-emerald-600' : 'text-amber-600'
                                }`}
                              >
                                {m.isPaid ? '✓ Đã nghiệm thu & kích hoạt' : 'Chờ nghiệm thu'}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* 2. Thiết bị theo hợp đồng */}
                {detailTab === 'equipments' && (
                  <div className="space-y-3">
                    <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300">
                          <tr>
                            <th className="p-2.5">Thiết Bị &amp; SKU</th>
                            <th className="p-2.5">Serial</th>
                            <th className="p-2.5">Địa Điểm</th>
                            <th className="p-2.5">Trạng Thái</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                          {contractEquipments.map((eq) => (
                            <tr key={eq.id} className="hover:bg-slate-50">
                              <td className="p-2.5">
                                <div className="font-bold text-slate-900 dark:text-white">{eq.productName}</div>
                                <div className="font-mono text-[10px] text-slate-400">{eq.sku}</div>
                              </td>
                              <td className="p-2.5 font-mono">{eq.serialNumber || 'N/A'}</td>
                              <td className="p-2.5">{eq.siteName}</td>
                              <td className="p-2.5">
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                                  {eq.status}
                                </span>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* 3. Lịch bảo trì */}
                {detailTab === 'maintenance' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-3 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-xl text-sky-900 dark:text-sky-200 text-xs">
                      <span>Kế hoạch bảo trì định kỳ cho hợp đồng kỹ thuật {selectedContract.contractNumber}.</span>
                      <button
                        onClick={() => setIsMaintenanceModalOpen(true)}
                        className="px-3 py-1 rounded-lg bg-sky-600 text-white font-bold text-xs hover:bg-sky-700 transition-colors shadow-2xs whitespace-nowrap"
                      >
                        + Tạo lịch bảo trì
                      </button>
                    </div>
                    {(contractMaintenanceSchedules[selectedContract.id] || [
                      { period: 'Đợt 1 - Quý I/2026', date: '2026-03-15', status: 'Đã hoàn tất', tech: 'Trần Văn Nam' },
                      { period: 'Đợt 2 - Quý II/2026', date: '2026-06-15', status: 'Đã hoàn tất', tech: 'Nguyễn Văn Tuấn' },
                      { period: 'Đợt 3 - Quý III/2026', date: '2026-09-15', status: 'Đã hoàn tất', tech: 'Lê Hữu Đạt' },
                      { period: 'Đợt 4 - Quý IV/2026', date: '2026-12-15', status: 'Sắp tới hạn', tech: 'Trần Văn Nam' },
                    ]).map((m, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex items-center justify-between text-xs"
                      >
                        <div>
                          <h5 className="font-bold text-slate-900 dark:text-white">{m.period}</h5>
                          <span className="text-[11px] text-slate-400">Kỹ sư: {m.tech} &bull; Ngày: {m.date}</span>
                        </div>
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            m.status === 'Đã hoàn tất' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                          }`}
                        >
                          {m.status}
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                {/* 4. Biên bản nghiệm thu (BBNT) */}
                {detailTab === 'acceptance' && (
                  <div className="space-y-3">
                    {contractCertificates.length === 0 ? (
                      <p className="text-slate-400 italic">Chưa có biên bản nghiệm thu nào được lập.</p>
                    ) : (
                      contractCertificates.map((cert) => (
                        <div
                          key={cert.id}
                          className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono font-bold text-emerald-600">{cert.code}</span>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                              Kết luận: {cert.result}
                            </span>
                          </div>
                          <h4 className="font-bold text-slate-900 dark:text-white">{cert.scopeAccepted}</h4>
                          <div className="text-[11px] text-slate-500 grid grid-cols-2 gap-2 pt-1 border-t border-slate-200 dark:border-slate-700">
                            <span>Đại diện khách: <strong>{cert.customerRepresentative}</strong></span>
                            <span>Kỹ sư nghiệm thu: <strong>{cert.techRepresentative}</strong></span>
                          </div>
                          {cert.milestoneTitleToTrigger && (
                            <p className="text-emerald-700 dark:text-emerald-400 text-[11px] font-semibold">
                              ✓ Đã kích hoạt mốc thanh toán: {cert.milestoneTitleToTrigger}
                            </p>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* 5. Tài liệu */}
                {detailTab === 'docs' && (
                  <div className="space-y-2">
                    {selectedContract.attachments.map((att, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between hover:bg-slate-50"
                      >
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-sky-600" />
                          <span className="font-semibold text-slate-800 dark:text-slate-200">{att.name}</span>
                        </div>
                        <span className="text-[11px] text-slate-400">{att.size}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-400 p-8 text-center">
              <FileCheck2 className="w-12 h-12 text-slate-300 dark:text-slate-700 mb-3" />
              <p className="font-medium text-sm">
                Chọn một hợp đồng từ danh sách bên trái để xem phạm vi kỹ thuật, kế hoạch triển khai và nghiệm thu
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Modal: Tiếp nhận hợp đồng & Gán Trưởng dự án */}
      {isAcceptModalOpen && selectedContract && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2">
              Tiếp Nhận Hợp Đồng &amp; Lập Dự Án
            </h3>
            <p className="text-slate-500 mb-3">
              Chuyển Hợp đồng {selectedContract.contractNumber} sang phân hệ Kế hoạch tổng thể để phân công kỹ sư và điều phối vật tư.
            </p>
            <div className="space-y-3">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Trưởng dự án chịu trách nhiệm (Project Manager)
                </label>
                <select
                  value={assignedPM}
                  onChange={(e) => setAssignedPM(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                >
                  <option value="Trần Văn Nam (Kỹ sư Trưởng)">Trần Văn Nam (Kỹ sư Trưởng)</option>
                  <option value="Nguyễn Văn Tuấn (Kỹ sư Mạng)">Nguyễn Văn Tuấn (Kỹ sư Mạng)</option>
                  <option value="Lê Hữu Đạt (Kỹ sư Hệ thống)">Lê Hữu Đạt (Kỹ sư Hệ thống)</option>
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setIsAcceptModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700"
                >
                  Hủy
                </button>
                <button
                  onClick={handleAcceptSubmit}
                  className="px-3.5 py-1.5 rounded-lg bg-sky-600 text-white font-semibold shadow-xs"
                >
                  Xác nhận tiếp nhận
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Lập Biên Bản Nghiệm Thu (BBNT) */}
      {isBBNTModalOpen && selectedContract && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Lập Biên Bản Nghiệm Thu Kỹ Thuật (BBNT)
              </h3>
              <button onClick={() => setIsBBNTModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateBBNT} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                    Đại diện khách hàng ký nghiệm thu *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Họ tên người ký..."
                    value={bbntForm.customerRepresentative}
                    onChange={(e) => setBbntForm({ ...bbntForm, customerRepresentative: e.target.value })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Chức vụ đại diện</label>
                  <input
                    type="text"
                    value={bbntForm.customerRepRole}
                    onChange={(e) => setBbntForm({ ...bbntForm, customerRepRole: e.target.value })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Kỹ sư phụ trách nghiệm thu (Công ty)
                </label>
                <input
                  type="text"
                  value={bbntForm.techRepresentative}
                  onChange={(e) => setBbntForm({ ...bbntForm, techRepresentative: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Nội dung / Hạng mục nghiệm thu *
                </label>
                <textarea
                  rows={2}
                  required
                  value={bbntForm.scopeAccepted}
                  onChange={(e) => setBbntForm({ ...bbntForm, scopeAccepted: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Kết luận nghiệm thu *</label>
                  <select
                    value={bbntForm.result}
                    onChange={(e) => setBbntForm({ ...bbntForm, result: e.target.value as any })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-bold"
                  >
                    <option value="Đạt">ĐẠT (Nghiệm thu thành công)</option>
                    <option value="Không đạt">KHÔNG ĐẠT (Cần khắc phục)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                    Kích hoạt mốc thanh toán tương ứng
                  </label>
                  <select
                    value={bbntForm.milestoneTitle}
                    onChange={(e) => setBbntForm({ ...bbntForm, milestoneTitle: e.target.value })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-medium"
                  >
                    <option value="">-- Chọn mốc thanh toán --</option>
                    {selectedContract.paymentMilestones.map((m, idx) => (
                      <option key={idx} value={m.title}>
                        {m.title} ({m.percentage}%)
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/60 rounded-xl flex items-start gap-2.5">
                <input
                  type="checkbox"
                  id="confirmEquipmentRecording"
                  checked={confirmRecordEquipments}
                  onChange={(e) => setConfirmRecordEquipments(e.target.checked)}
                  className="mt-0.5 rounded border-amber-400 text-sky-600 focus:ring-sky-500"
                />
                <label htmlFor="confirmEquipmentRecording" className="text-xs text-amber-900 dark:text-amber-200 font-medium">
                  <strong>Ghi nhận thiết bị cho khách?</strong> Cập nhật hồ sơ thiết bị đã lắp đặt và kích hoạt bảo hành cho khách hàng sau khi nghiệm thu Đạt.
                </label>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg text-slate-700 dark:text-slate-300 text-[11px] leading-relaxed">
                ℹ️ Khi nghiệm thu <strong>ĐẠT</strong>:
                <ul className="list-disc pl-4 mt-1 space-y-0.5">
                  <li>Kích hoạt mốc thanh toán trong Hợp đồng để Sales &amp; Kế toán lập Hóa đơn.</li>
                </ul>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsBBNTModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold shadow-xs"
                >
                  Ký &amp; Phát hành BBNT
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Tạo Lịch Bảo Trì Thủ Công */}
      {isMaintenanceModalOpen && selectedContract && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2">
              Lập Kế Hoạch Lịch Bảo Trì Định Kỳ
            </h3>
            <p className="text-slate-500 mb-4">
              Người dùng chủ động chọn chu kỳ, số đợt và kỹ sư phụ trách cho Hợp đồng {selectedContract.contractNumber}.
            </p>
            <div className="space-y-3">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Chu kỳ bảo trì
                </label>
                <select
                  value={maintenanceForm.intervalMonths}
                  onChange={(e) => setMaintenanceForm({ ...maintenanceForm, intervalMonths: Number(e.target.value) })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value={1}>01 tháng / lần</option>
                  <option value={3}>03 tháng / lần (Mặc định)</option>
                  <option value={6}>06 tháng / lần</option>
                  <option value={12}>12 tháng / lần</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Số đợt bảo trì cần tạo
                </label>
                <input
                  type="number"
                  min={1}
                  max={12}
                  value={maintenanceForm.totalRounds}
                  onChange={(e) => setMaintenanceForm({ ...maintenanceForm, totalRounds: Number(e.target.value) })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Ngày bắt đầu đợt 1
                </label>
                <input
                  type="date"
                  value={maintenanceForm.startDate}
                  onChange={(e) => setMaintenanceForm({ ...maintenanceForm, startDate: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Kỹ sư phụ trách
                </label>
                <select
                  value={maintenanceForm.assignedTech}
                  onChange={(e) => setMaintenanceForm({ ...maintenanceForm, assignedTech: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                >
                  <option value="Trần Văn Nam">Trần Văn Nam</option>
                  <option value="Nguyễn Văn Tuấn">Nguyễn Văn Tuấn</option>
                  <option value="Lê Hữu Đạt">Lê Hữu Đạt</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsMaintenanceModalOpen(false)}
                  className="px-3.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700"
                >
                  Hủy
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const newSchedules = Array.from({ length: maintenanceForm.totalRounds }, (_, i) => {
                      const d = new Date(maintenanceForm.startDate);
                      d.setMonth(d.getMonth() + i * maintenanceForm.intervalMonths);
                      return {
                        period: `Đợt ${i + 1} (${d.toLocaleDateString('vi-VN', { month: '2-digit', year: 'numeric' })})`,
                        date: d.toISOString().split('T')[0],
                        status: i === 0 ? 'Sắp tới hạn' : 'Kế hoạch',
                        tech: maintenanceForm.assignedTech,
                      };
                    });
                    setContractMaintenanceSchedules((prev) => ({
                      ...prev,
                      [selectedContract.id]: newSchedules,
                    }));
                    setIsMaintenanceModalOpen(false);
                    showToast('Lập lịch bảo trì', `Đã tạo ${maintenanceForm.totalRounds} đợt bảo trì định kỳ cho hợp đồng.`);
                  }}
                  className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold shadow-xs"
                >
                  Lưu Lịch Bảo Trì
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
