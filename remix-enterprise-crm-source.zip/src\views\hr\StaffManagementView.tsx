import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useHR } from '../../context/HRContext';
import { useSales } from '../../context/SalesContext';
import {
  Employee,
  Department,
  TeamCategory,
  EmployeeContract,
  ChecklistItem,
} from '../../types/hr';
import { SAMPLE_CHECKLISTS } from '../../data/mockHRData';
import {
  Users,
  Search,
  Plus,
  Filter,
  Download,
  Upload,
  Calendar,
  Clock,
  Building,
  UserCheck,
  UserX,
  Cake,
  AlertTriangle,
  Eye,
  EyeOff,
  ChevronRight,
  ChevronDown,
  Layers,
  FileText,
  ShieldAlert,
  ArrowRight,
  Check,
  X,
  FolderTree,
  Sliders,
  Briefcase,
  Phone,
  Mail,
  MapPin,
  Lock,
  Unlock,
  CheckCircle2,
  FileCheck,
  RotateCcw,
  UserPlus,
  Award,
} from 'lucide-react';

export const StaffManagementView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const {
    employees,
    departments,
    teams,
    positions,
    contracts,
    workHistories,
    addEmployee,
    updateEmployee,
    renewOrSignContract,
    convertProbationToOfficial,
    handoverEmployeeData,
    updateChecklistItem,
    addDepartment,
    updateDepartment,
    addTeam,
    updateTeam,
    addPosition,
    updatePosition,
    maskSensitive,
    logSensitiveAccess,
  } = useHR();

  const { leads, customers, opportunities } = useSales();

  // Active Main Tab
  const [activeTab, setActiveTab] = useState<'list' | 'org' | 'dept'>('list');

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [deptFilter, setDeptFilter] = useState('all');
  const [teamFilter, setTeamFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [contractTypeFilter, setContractTypeFilter] = useState('all');

  // Selected Employee for Detail Drawer
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  const [detailTab, setDetailTab] = useState<'personal' | 'job' | 'contracts' | 'history' | 'documents' | 'insurance' | 'checklist'>('personal');

  // Sensitive data unmask state
  const [unmaskedFields, setUnmaskedFields] = useState<Record<string, boolean>>({});

  const toggleUnmask = (fieldKey: string, empName: string, label: string) => {
    const isCurrentlyUnmasked = !!unmaskedFields[fieldKey];
    if (!isCurrentlyUnmasked) {
      logSensitiveAccess('VIEW_UNMASKED', empName, [label], `Xem đầy đủ ${label}`);
    }
    setUnmaskedFields((prev) => ({ ...prev, [fieldKey]: !isCurrentlyUnmasked }));
  };

  // Stats Calculations
  const stats = useMemo(() => {
    const total = employees.length;
    const working = employees.filter((e) => e.status === 'Chính thức').length;
    const probation = employees.filter((e) => e.status === 'Thử việc').length;
    const onLeave = employees.filter((e) => e.status === 'Nghỉ dài hạn').length;
    const resigned = employees.filter((e) => e.status === 'Đã nghỉ việc').length;

    // Hợp đồng hoặc thử việc sắp hết hạn trong 30 ngày
    const now = new Date('2026-10-05').getTime();
    const expiringContracts = contracts.filter((c) => {
      if (!c.endDate || c.status === 'Đã thanh lý') return false;
      const diffDays = Math.ceil((new Date(c.endDate).getTime() - now) / (1000 * 60 * 60 * 24));
      return diffDays >= 0 && diffDays <= 30;
    });

    // Mới vào trong tháng 10/2026
    const newHiresThisMonth = employees.filter((e) => e.joinDate.startsWith('2026-10')).length;

    // Sinh nhật trong tuần (tháng 10 ngày 05 - 11)
    const birthdaysThisWeek = employees.filter((e) => {
      if (!e.dob) return false;
      const [, m, d] = e.dob.split('-').map(Number);
      return m === 10 && d >= 5 && d <= 12;
    });

    return {
      total,
      working,
      probation,
      onLeave,
      resigned,
      expiringCount: expiringContracts.length,
      expiringList: expiringContracts,
      newHiresThisMonth,
      birthdaysThisWeek,
    };
  }, [employees, contracts]);

  // Filtered Employees List
  const filteredEmployees = useMemo(() => {
    return employees.filter((e) => {
      if (deptFilter !== 'all' && e.departmentId !== deptFilter) return false;
      if (teamFilter !== 'all' && e.teamId !== teamFilter) return false;
      if (statusFilter !== 'all' && e.status !== statusFilter) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return (
          e.code.toLowerCase().includes(q) ||
          e.fullName.toLowerCase().includes(q) ||
          e.phone.toLowerCase().includes(q) ||
          e.email.toLowerCase().includes(q) ||
          e.positionName.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [employees, deptFilter, teamFilter, statusFilter, searchTerm]);

  // Modals
  const [isAddWizardOpen, setIsAddWizardOpen] = useState(false);
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3 | 4 | 5>(1);

  // Wizard Form State
  const [wizPersonal, setWizPersonal] = useState({
    fullName: '',
    gender: 'Nam' as 'Nam' | 'Nữ' | 'Khác',
    dob: '1995-01-15',
    phone: '',
    email: '',
    permanentAddress: '',
    currentAddress: '',
    idCardNumber: '',
    idCardDate: '2022-01-10',
    idCardPlace: 'Cục Cảnh sát QLHC về TTXH',
    personalTaxCode: '',
    bankName: 'Vietcombank',
    bankAccount: '',
    bankHolder: '',
    educationLevel: 'Đại học',
    emergencyName: '',
    emergencyRel: 'Bố/Mẹ',
    emergencyPhone: '',
  });

  const [wizJob, setWizJob] = useState({
    departmentId: 'dept-sales',
    teamId: 'team-sales-north',
    positionId: 'pos-sales-exec',
    jobLevel: 'Chuyên viên' as Employee['jobLevel'],
    directManagerId: 'emp-06',
    workLocation: 'Trụ sở Hà Nội',
    workRegion: 'Vùng I' as Employee['workRegion'],
    joinDate: new Date().toISOString().split('T')[0],
    status: 'Thử việc' as Employee['status'],
    systemRole: 'Sales Staff' as Employee['systemRole'],
  });

  const [wizContract, setWizContract] = useState({
    type: 'Thử việc' as EmployeeContract['type'],
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    baseSalary: 10000000,
    insuranceSalary: 9000000,
    allowances: [{ name: 'Phụ cấp ăn trưa & điện thoại', amount: 1000000 }],
  });

  const [wizInsurance, setWizInsurance] = useState({
    socialInsuranceNumber: '',
    healthInsuranceCardNumber: '',
    healthClinicName: 'Bệnh viện Đa khoa Nông Nghiệp',
  });

  const [wizChecklist, setWizChecklist] = useState<ChecklistItem[]>([
    { id: 'item-1', title: 'Nộp đầy đủ bản sao CCCD, bằng cấp và sơ yếu lý lịch', assignedTo: 'Đặng Thu Thảo (HR)', dueDate: '2026-10-15', completed: false },
    { id: 'item-2', title: 'Ký Hợp đồng thử việc 02 tháng', assignedTo: 'Đặng Thu Thảo (HR)', dueDate: '2026-10-10', completed: false },
    { id: 'item-3', title: 'Cấp email công ty và tài khoản đăng nhập CRM', assignedTo: 'Trần Văn Nam (IT)', dueDate: '2026-10-08', completed: false },
    { id: 'item-4', title: 'Bàn giao thiết bị làm việc, thẻ nhân viên và chỗ ngồi', assignedTo: 'Vũ Đình Khoa (Kho)', dueDate: '2026-10-08', completed: false },
    { id: 'item-5', title: 'Tham gia khóa đào tạo hội nhập văn hóa A+ Enterprise', assignedTo: 'Trưởng bộ phận', dueDate: '2026-10-20', completed: false },
  ]);

  const handleFinishWizard = () => {
    if (!wizPersonal.fullName || !wizPersonal.phone) {
      showToast('Thiếu thông tin', 'Vui lòng nhập Họ tên và Số điện thoại.', 'warning');
      return;
    }

    const dept = departments.find((d) => d.id === wizJob.departmentId);
    const tm = teams.find((t) => t.id === wizJob.teamId);
    const pos = positions.find((p) => p.id === wizJob.positionId);
    const mgr = employees.find((e) => e.id === wizJob.directManagerId);

    addEmployee(
      {
        fullName: wizPersonal.fullName,
        gender: wizPersonal.gender,
        dob: wizPersonal.dob,
        phone: wizPersonal.phone,
        email: wizPersonal.email || `${wizPersonal.fullName.toLowerCase().replace(/\s+/g, '')}@apluscorp.vn`,
        permanentAddress: wizPersonal.permanentAddress || 'TP. Hà Nội',
        currentAddress: wizPersonal.currentAddress || 'TP. Hà Nội',
        idCardNumber: wizPersonal.idCardNumber || '001095000000',
        idCardDate: wizPersonal.idCardDate,
        idCardPlace: wizPersonal.idCardPlace,
        personalTaxCode: wizPersonal.personalTaxCode || '8999999999',
        bankAccount: {
          bankName: wizPersonal.bankName,
          accountNumber: wizPersonal.bankAccount || '001100000000',
          accountHolder: wizPersonal.bankHolder || wizPersonal.fullName.toUpperCase(),
        },
        educationLevel: wizPersonal.educationLevel,
        emergencyContact: {
          name: wizPersonal.emergencyName || 'Người thân',
          relationship: wizPersonal.emergencyRel,
          phone: wizPersonal.emergencyPhone || wizPersonal.phone,
        },
        departmentId: wizJob.departmentId,
        departmentName: dept?.name || 'Khối Kinh Doanh B2B & Dự Án',
        teamId: wizJob.teamId,
        teamName: tm?.name,
        positionId: wizJob.positionId,
        positionName: pos?.name || 'Chuyên Viên',
        jobLevel: wizJob.jobLevel,
        directManagerId: wizJob.directManagerId,
        directManagerName: mgr?.fullName,
        workLocation: wizJob.workLocation,
        workRegion: wizJob.workRegion,
        joinDate: wizJob.joinDate,
        status: wizJob.status,
        systemRole: wizJob.systemRole,
        accountStatus: 'active',
        loginUsername: wizPersonal.email.split('@')[0] || wizPersonal.fullName.toLowerCase().replace(/\s+/g, ''),
        socialInsuranceNumber: wizInsurance.socialInsuranceNumber,
        healthInsuranceCardNumber: wizInsurance.healthInsuranceCardNumber,
        healthClinicName: wizInsurance.healthClinicName,
        insuranceStatus: wizContract.insuranceSalary > 0 ? 'Chờ báo tăng' : 'Chưa đăng ký',
        insuranceSalary: wizContract.insuranceSalary,
      },
      {
        type: wizContract.type,
        startDate: wizContract.startDate,
        endDate: wizContract.endDate,
        baseSalary: wizContract.baseSalary,
        allowances: wizContract.allowances,
        insuranceSalary: wizContract.insuranceSalary,
      },
      wizChecklist
    );

    setIsAddWizardOpen(false);
    setWizardStep(1);
  };

  // Handover Modal State
  const [isHandoverModalOpen, setIsHandoverModalOpen] = useState(false);
  const [handoverSourceEmp, setHandoverSourceEmp] = useState<Employee | null>(null);
  const [handoverTargetId, setHandoverTargetId] = useState<string>('');
  const [handoverNotes, setHandoverNotes] = useState('Thôi việc theo nguyện vọng cá nhân, bàn giao toàn bộ khách hàng và cơ hội');

  const startHandover = (emp: Employee) => {
    setHandoverSourceEmp(emp);
    const candidate = employees.find((e) => e.id !== emp.id && e.status === 'Chính thức');
    setHandoverTargetId(candidate?.id || '');
    setIsHandoverModalOpen(true);
  };

  const handleConfirmHandover = () => {
    if (!handoverSourceEmp || !handoverTargetId) {
      showToast('Lỗi', 'Vui lòng chọn nhân sự tiếp nhận bàn giao.', 'warning');
      return;
    }
    handoverEmployeeData(handoverSourceEmp.id, handoverTargetId, handoverNotes);
    setIsHandoverModalOpen(false);
    if (selectedEmployee?.id === handoverSourceEmp.id) {
      setSelectedEmployee((prev) => (prev ? { ...prev, status: 'Đã nghỉ việc', accountStatus: 'locked' } : null));
    }
  };

  // Excel Import / Export Modal
  const [isExcelImportModalOpen, setIsExcelImportModalOpen] = useState(false);
  const [importRows, setImportRows] = useState([
    { row: 1, name: 'Nguyễn Đình Trọng', phone: '0912 333 999', dept: 'Khối Kinh Doanh', role: 'Sales Staff', status: 'Hợp lệ' },
    { row: 2, name: 'Trần Thị Mỹ Duyên', phone: '0988 777 666', dept: 'Phòng Kỹ Thuật', role: 'Technical Staff', status: 'Hợp lệ' },
    { row: 3, name: 'Lê Văn Cảnh', phone: '', dept: 'Phòng Kho', role: 'Warehouse Staff', status: 'Lỗi: Thiếu số điện thoại' },
  ]);

  const handleExportExcel = () => {
    showToast('Xuất Excel thành công', `Đã xuất danh sách ${filteredEmployees.length} nhân viên ra file Excel.`, 'success');
  };

  // Org Chart Expand / Collapse State
  const [expandedDeptIds, setExpandedDeptIds] = useState<string[]>(departments.map((d) => d.id));
  const [orgViewMode, setOrgViewMode] = useState<'dept' | 'manager'>('dept');

  const toggleDeptExpand = (dId: string) => {
    setExpandedDeptIds((prev) =>
      prev.includes(dId) ? prev.filter((id) => id !== dId) : [...prev, dId]
    );
  };

  // Modal thêm/sửa Phòng ban & Chức vụ
  const [isAddDeptModalOpen, setIsAddDeptModalOpen] = useState(false);
  const [deptForm, setDeptForm] = useState({ code: '', name: '', managerId: '' });

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
              <Users className="w-5 h-5" />
            </span>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Hồ Sơ &amp; Quản Lý Nhân Viên
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 font-bold font-mono">
                  {employees.length} Nhân sự
                </span>
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Nguồn dữ liệu gốc toàn hệ thống: Danh sách nhân viên, sơ đồ tổ chức, hợp đồng lao động và luồng bàn giao dữ liệu CRM.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsExcelImportModalOpen(true)}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Nhập Excel</span>
          </button>
          <button
            onClick={handleExportExcel}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Xuất Excel</span>
          </button>
          <button
            onClick={() => {
              setWizardStep(1);
              setIsAddWizardOpen(true);
            }}
            className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm Nhân Viên Mới</span>
          </button>
        </div>
      </div>

      {/* Main Tabs Navigation */}
      <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 text-xs">
        <button
          onClick={() => setActiveTab('list')}
          className={`px-4 py-2.5 font-bold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'list'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/20'
              : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Danh Sách Nhân Viên</span>
        </button>

        <button
          onClick={() => setActiveTab('org')}
          className={`px-4 py-2.5 font-bold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'org'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/20'
              : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <FolderTree className="w-4 h-4" />
          <span>Sơ Đồ Tổ Chức</span>
        </button>

        <button
          onClick={() => setActiveTab('dept')}
          className={`px-4 py-2.5 font-bold border-b-2 transition-colors flex items-center gap-2 ${
            activeTab === 'dept'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400 bg-indigo-50/50 dark:bg-indigo-950/20'
              : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
          }`}
        >
          <Building className="w-4 h-4" />
          <span>Phòng Ban &amp; Chức Vụ</span>
        </button>
      </div>

      {/* ========================================================
          TAB 1: DANH SÁCH NHÂN VIÊN
      ======================================================== */}
      {activeTab === 'list' && (
        <div className="space-y-4">
          {/* Quick Metrics Bar */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
            <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-slate-400 block font-medium">Tổng nhân sự</span>
              <span className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-0.5 block">
                {stats.total}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 block font-medium">Đang làm việc</span>
              <span className="text-xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-0.5 block">
                {stats.working}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-amber-600 dark:text-amber-400 block font-medium">Đang thử việc</span>
              <span className="text-xl font-bold font-mono text-amber-600 dark:text-amber-400 mt-0.5 block">
                {stats.probation}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-rose-200 dark:border-rose-900/60 shadow-xs bg-rose-50/40 dark:bg-rose-950/20">
              <span className="text-[11px] text-rose-600 dark:text-rose-400 block font-bold flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" />
                HĐ/Thử việc hết hạn
              </span>
              <span className="text-xl font-bold font-mono text-rose-600 dark:text-rose-400 mt-0.5 block">
                {stats.expiringCount} <span className="text-xs font-normal">(&le;30 ngày)</span>
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-sky-600 dark:text-sky-400 block font-medium">Mới trong tháng</span>
              <span className="text-xl font-bold font-mono text-sky-600 dark:text-sky-400 mt-0.5 block">
                +{stats.newHiresThisMonth}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-slate-500 block font-medium">Đã nghỉ việc</span>
              <span className="text-xl font-bold font-mono text-slate-500 mt-0.5 block">
                {stats.resigned}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-amber-200 dark:border-amber-900/60 shadow-xs bg-amber-50/30 dark:bg-amber-950/20">
              <span className="text-[11px] text-amber-700 dark:text-amber-300 block font-medium flex items-center gap-1">
                <Cake className="w-3.5 h-3.5 text-amber-500" />
                Sinh nhật tuần này
              </span>
              <span className="text-xl font-bold font-mono text-amber-700 dark:text-amber-300 mt-0.5 block">
                {stats.birthdaysThisWeek.length}
              </span>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Tìm theo Mã NV, Họ tên, SĐT, Email..."
                className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              >
                <option value="all">Tất cả phòng ban</option>
                {departments.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>

              <select
                value={teamFilter}
                onChange={(e) => setTeamFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              >
                <option value="all">Tất cả nhóm</option>
                {teams.map((t) => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>

              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              >
                <option value="all">Tất cả trạng thái</option>
                <option value="Chính thức">Chính thức</option>
                <option value="Thử việc">Thử việc</option>
                <option value="Nghỉ dài hạn">Nghỉ dài hạn</option>
                <option value="Đã nghỉ việc">Đã nghỉ việc</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800 uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="p-3">Mã &amp; Nhân Viên</th>
                    <th className="p-3">Phòng Ban / Nhóm</th>
                    <th className="p-3">Chức Vụ</th>
                    <th className="p-3">Quản Lý Trực Tiếp</th>
                    <th className="p-3">Ngày Vào Làm</th>
                    <th className="p-3">Trạng Thái</th>
                    <th className="p-3">Tài Khoản CRM</th>
                    <th className="p-3 text-right">Thao Tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-slate-700 dark:text-slate-200">
                  {filteredEmployees.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-400">
                        Không tìm thấy nhân viên phù hợp với bộ lọc.
                      </td>
                    </tr>
                  ) : (
                    filteredEmployees.map((emp) => {
                      const isBirthday = stats.birthdaysThisWeek.some((b) => b.id === emp.id);
                      return (
                        <tr
                          key={emp.id}
                          onClick={() => {
                            setSelectedEmployee(emp);
                            setDetailTab('personal');
                          }}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                        >
                          <td className="p-3">
                            <div className="flex items-center gap-2.5">
                              <div className="relative">
                                {emp.avatar ? (
                                  <img
                                    src={emp.avatar}
                                    alt={emp.fullName}
                                    className="w-8 h-8 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0"
                                  />
                                ) : (
                                  <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold flex items-center justify-center text-xs">
                                    {emp.fullName.split(' ').slice(-1)[0][0]}
                                  </div>
                                )}
                                {isBirthday && (
                                  <span
                                    title="Sinh nhật trong tuần này!"
                                    className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-400 text-slate-900 rounded-full flex items-center justify-center text-[9px] font-bold shadow-xs animate-bounce"
                                  >
                                    🎂
                                  </span>
                                )}
                              </div>
                              <div>
                                <span className="font-bold text-slate-900 dark:text-white block hover:text-indigo-600">
                                  {emp.fullName}
                                </span>
                                <span className="font-mono text-[10px] text-slate-400">
                                  {emp.code} &bull; {emp.phone}
                                </span>
                              </div>
                            </div>
                          </td>

                          <td className="p-3">
                            <div className="font-medium">{emp.departmentName}</div>
                            {emp.teamName && (
                              <div className="text-[11px] text-indigo-600 dark:text-indigo-400 font-medium">
                                {emp.teamName}
                              </div>
                            )}
                          </td>

                          <td className="p-3 font-medium">
                            {emp.positionName}
                          </td>

                          <td className="p-3 text-slate-500">
                            {emp.directManagerName || '—'}
                          </td>

                          <td className="p-3 font-mono text-[11px]">
                            {emp.joinDate}
                          </td>

                          <td className="p-3">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                emp.status === 'Chính thức'
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                                  : emp.status === 'Thử việc'
                                  ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 ring-1 ring-amber-300'
                                  : emp.status === 'Nghỉ dài hạn'
                                  ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300'
                                  : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                              }`}
                            >
                              {emp.status}
                            </span>
                          </td>

                          <td className="p-3">
                            <div className="flex items-center gap-1.5">
                              {emp.accountStatus === 'active' ? (
                                <span className="flex items-center gap-1 text-[11px] text-emerald-600 font-medium">
                                  <Unlock className="w-3 h-3" />
                                  {emp.systemRole}
                                </span>
                              ) : (
                                <span className="flex items-center gap-1 text-[11px] text-rose-500 font-medium">
                                  <Lock className="w-3 h-3" />
                                  Đã khóa
                                </span>
                              )}
                            </div>
                          </td>

                          <td className="p-3 text-right" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-end gap-1">
                              <button
                                onClick={() => {
                                  setSelectedEmployee(emp);
                                  setDetailTab('personal');
                                }}
                                className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-semibold text-xs"
                              >
                                Xem hồ sơ
                              </button>
                              {emp.status !== 'Đã nghỉ việc' && (
                                <button
                                  onClick={() => startHandover(emp)}
                                  className="px-2 py-1 rounded text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-semibold"
                                  title="Thôi việc & Bàn giao dữ liệu CRM"
                                >
                                  Nghỉ việc
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 2: SƠ ĐỒ TỔ CHỨC (ORG CHART)
      ======================================================== */}
      {activeTab === 'org' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <FolderTree className="w-4 h-4 text-indigo-600" />
                Cây Sơ Đồ Cơ Cấu Tổ Chức Doanh Nghiệp
              </h2>
              <p className="text-xs text-slate-500">
                Hiển thị phân cấp Phòng ban &rarr; Nhóm phụ trách &rarr; Thành viên trực thuộc. Bấm vào nhân sự để xem nhanh hồ sơ.
              </p>
            </div>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400">Chế độ xem:</span>
              <button
                onClick={() => setOrgViewMode('dept')}
                className={`px-3 py-1 rounded-lg font-semibold ${
                  orgViewMode === 'dept'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                }`}
              >
                Theo Phòng Ban
              </button>
              <button
                onClick={() => setOrgViewMode('manager')}
                className={`px-3 py-1 rounded-lg font-semibold ${
                  orgViewMode === 'manager'
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600'
                }`}
              >
                Theo Quản Lý Trực Tiếp
              </button>
            </div>
          </div>

          {/* Org Tree Rendering */}
          <div className="space-y-4 pt-2">
            {departments.map((dept) => {
              const deptEmps = employees.filter((e) => e.departmentId === dept.id);
              const deptTeams = teams.filter((t) => t.departmentId === dept.id);
              const isExpanded = expandedDeptIds.includes(dept.id);

              return (
                <div
                  key={dept.id}
                  className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden bg-slate-50/40 dark:bg-slate-950/30"
                >
                  {/* Dept Header */}
                  <div
                    onClick={() => toggleDeptExpand(dept.id)}
                    className="p-3 bg-slate-100 dark:bg-slate-800/80 flex items-center justify-between cursor-pointer select-none hover:bg-slate-200/70"
                  >
                    <div className="flex items-center gap-2.5">
                      {isExpanded ? (
                        <ChevronDown className="w-4 h-4 text-slate-500" />
                      ) : (
                        <ChevronRight className="w-4 h-4 text-slate-500" />
                      )}
                      <Building className="w-4 h-4 text-indigo-600" />
                      <span className="font-bold text-slate-900 dark:text-white text-sm">
                        {dept.name} ({dept.code})
                      </span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-white dark:bg-slate-900 text-indigo-600 font-bold border border-slate-200 dark:border-slate-700">
                        {deptEmps.length} nhân sự
                      </span>
                    </div>

                    <div className="text-xs text-slate-500">
                      Trưởng phòng: <strong className="text-slate-800 dark:text-slate-200">{dept.managerName || 'Chưa gán'}</strong>
                    </div>
                  </div>

                  {/* Dept Contents */}
                  {isExpanded && (
                    <div className="p-4 space-y-4">
                      {/* Teams if any */}
                      {deptTeams.length > 0 ? (
                        <div className="space-y-3 pl-4 border-l-2 border-indigo-200 dark:border-indigo-900">
                          {deptTeams.map((team) => {
                            const teamEmps = deptEmps.filter((e) => e.teamId === team.id);
                            return (
                              <div key={team.id} className="space-y-2">
                                <div className="flex items-center gap-2 text-xs font-bold text-indigo-700 dark:text-indigo-300">
                                  <Users className="w-3.5 h-3.5" />
                                  <span>{team.name}</span>
                                  <span className="text-[10px] text-slate-400 font-normal">
                                    (Trưởng nhóm: {team.leaderName} &bull; {teamEmps.length} thành viên)
                                  </span>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pl-3">
                                  {teamEmps.map((emp) => (
                                    <div
                                      key={emp.id}
                                      onClick={() => {
                                        setSelectedEmployee(emp);
                                        setDetailTab('personal');
                                      }}
                                      className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-indigo-400 cursor-pointer flex items-center gap-2.5 transition-all shadow-2xs"
                                    >
                                      {emp.avatar ? (
                                        <img src={emp.avatar} alt={emp.fullName} className="w-8 h-8 rounded-full object-cover shrink-0" />
                                      ) : (
                                        <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-xs">
                                          {emp.fullName[0]}
                                        </div>
                                      )}
                                      <div className="min-w-0">
                                        <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                                          {emp.fullName}
                                        </p>
                                        <p className="text-[10px] text-slate-400 truncate">
                                          {emp.positionName}
                                        </p>
                                      </div>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 pl-4 border-l-2 border-slate-200 dark:border-slate-800">
                          {deptEmps.map((emp) => (
                            <div
                              key={emp.id}
                              onClick={() => {
                                setSelectedEmployee(emp);
                                setDetailTab('personal');
                              }}
                              className="p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-indigo-400 cursor-pointer flex items-center gap-2.5 transition-all shadow-2xs"
                            >
                              {emp.avatar ? (
                                <img src={emp.avatar} alt={emp.fullName} className="w-8 h-8 rounded-full object-cover shrink-0" />
                              ) : (
                                <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-700 font-bold flex items-center justify-center text-xs">
                                  {emp.fullName[0]}
                                </div>
                              )}
                              <div className="min-w-0">
                                <p className="font-bold text-xs text-slate-900 dark:text-white truncate">
                                  {emp.fullName}
                                </p>
                                <p className="text-[10px] text-slate-400 truncate">
                                  {emp.positionName}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 3: PHÒNG BAN & CHỨC VỤ (DÙNG CHUNG HỆ THỐNG)
      ======================================================== */}
      {activeTab === 'dept' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Cột 1: Danh sách Phòng Ban & Nhóm */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <Building className="w-4 h-4 text-indigo-600" />
                Danh Mục Phòng Ban &amp; Đội Nhóm
              </h3>
              <button
                onClick={() => setIsAddDeptModalOpen(true)}
                className="px-2.5 py-1 bg-indigo-600 text-white rounded-lg text-xs font-semibold hover:bg-indigo-700 flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Thêm Phòng Ban</span>
              </button>
            </div>

            <div className="space-y-3">
              {departments.map((d) => {
                const memberCount = employees.filter((e) => e.departmentId === d.id).length;
                return (
                  <div
                    key={d.id}
                    className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-white text-sm">
                          {d.name}
                        </span>
                        <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 font-bold">
                          {d.code}
                        </span>
                      </div>
                      <p className="text-slate-500 text-[11px] mt-0.5">
                        Trưởng bộ phận: <strong className="text-slate-700 dark:text-slate-300">{d.managerName || 'Chưa gán'}</strong>
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="px-2.5 py-1 rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold font-mono">
                        {memberCount} nhân sự
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800">
              <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200 mb-2">
                Các Đội Nhóm Kinh Doanh (B2B Sales Teams)
              </h4>
              <div className="space-y-2">
                {teams.map((t) => {
                  const tCount = employees.filter((e) => e.teamId === t.id).length;
                  return (
                    <div
                      key={t.id}
                      className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs"
                    >
                      <div>
                        <span className="font-bold text-indigo-600">{t.name}</span>
                        <span className="text-slate-400 text-[11px] ml-2">({t.region})</span>
                        <p className="text-[10px] text-slate-500">Trưởng nhóm: {t.leaderName}</p>
                      </div>
                      <span className="font-mono font-semibold text-slate-600">{tCount} thành viên</span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Cột 2: Danh Mục Chức Vụ & Cấp Bậc */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <Briefcase className="w-4 h-4 text-indigo-600" />
                Danh Mục Chức Vụ &amp; Cấp Bậc
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 font-semibold border-b border-slate-200 dark:border-slate-800 text-[11px]">
                  <tr>
                    <th className="p-2.5">Tên Chức Vụ</th>
                    <th className="p-2.5">Phòng Ban Phụ Trách</th>
                    <th className="p-2.5">Cấp Bậc</th>
                    <th className="p-2.5 text-right">Số Người</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {positions.map((pos) => {
                    const count = employees.filter((e) => e.positionId === pos.id).length;
                    return (
                      <tr key={pos.id} className="hover:bg-slate-50/50">
                        <td className="p-2.5 font-bold text-slate-900 dark:text-white">
                          {pos.name}
                        </td>
                        <td className="p-2.5 text-slate-500">
                          {pos.departmentName || 'Toàn công ty'}
                        </td>
                        <td className="p-2.5">
                          <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold">
                            {pos.level}
                          </span>
                        </td>
                        <td className="p-2.5 text-right font-mono font-bold text-slate-700 dark:text-slate-300">
                          {count}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 rounded-xl text-[11px] text-amber-800 dark:text-amber-300 space-y-1">
              <p className="font-bold flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                Nguyên tắc quản lý danh mục dùng chung:
              </p>
              <p>
                Không cho phép xóa Phòng ban hay Chức vụ đang có nhân viên gắn kết. Chỉ cho phép chuyển trạng thái &quot;Ngưng sử dụng&quot; để đảm bảo tính toàn vẹn dữ liệu kế thừa sang Báo cáo và Quản lý Sales.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          DRAWER CHI TIẾT HỒ SƠ NHÂN VIÊN
      ======================================================== */}
      {selectedEmployee && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex justify-end">
          <div className="bg-white dark:bg-slate-900 w-full max-w-3xl h-full shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-right duration-200">
            {/* Drawer Top Header */}
            <div className="p-4 bg-slate-100 dark:bg-slate-800/90 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                {selectedEmployee.avatar ? (
                  <img src={selectedEmployee.avatar} alt={selectedEmployee.fullName} className="w-12 h-12 rounded-full object-cover border-2 border-indigo-500 shrink-0" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-indigo-600 text-white font-bold flex items-center justify-center text-base">
                    {selectedEmployee.fullName[0]}
                  </div>
                )}
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                      {selectedEmployee.fullName}
                    </h2>
                    <span className="font-mono text-xs px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 font-bold">
                      {selectedEmployee.code}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500">
                    {selectedEmployee.positionName} &bull; {selectedEmployee.departmentName}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {selectedEmployee.status === 'Thử việc' && (
                  <button
                    onClick={() => convertProbationToOfficial(selectedEmployee.id)}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 shadow-xs"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Chuyển Chính Thức</span>
                  </button>
                )}
                {selectedEmployee.status !== 'Đã nghỉ việc' && (
                  <button
                    onClick={() => startHandover(selectedEmployee)}
                    className="px-2.5 py-1.5 rounded-lg border border-rose-300 text-rose-600 hover:bg-rose-50 text-xs font-semibold"
                  >
                    Thôi việc
                  </button>
                )}
                <button
                  onClick={() => setSelectedEmployee(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Profile Tabs */}
            <div className="flex items-center gap-1 px-4 border-b border-slate-200 dark:border-slate-800 text-xs bg-slate-50 dark:bg-slate-850 shrink-0 overflow-x-auto">
              <button
                onClick={() => setDetailTab('personal')}
                className={`py-2.5 px-3 font-bold border-b-2 whitespace-nowrap ${
                  detailTab === 'personal' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500'
                }`}
              >
                Thông Tin Cá Nhân
              </button>
              <button
                onClick={() => setDetailTab('job')}
                className={`py-2.5 px-3 font-bold border-b-2 whitespace-nowrap ${
                  detailTab === 'job' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500'
                }`}
              >
                Công Việc &amp; Tài Khoản
              </button>
              <button
                onClick={() => setDetailTab('contracts')}
                className={`py-2.5 px-3 font-bold border-b-2 whitespace-nowrap ${
                  detailTab === 'contracts' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500'
                }`}
              >
                Hợp Đồng Lao Động
              </button>
              <button
                onClick={() => setDetailTab('history')}
                className={`py-2.5 px-3 font-bold border-b-2 whitespace-nowrap ${
                  detailTab === 'history' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500'
                }`}
              >
                Quá Trình Công Tác
              </button>
              <button
                onClick={() => setDetailTab('insurance')}
                className={`py-2.5 px-3 font-bold border-b-2 whitespace-nowrap ${
                  detailTab === 'insurance' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500'
                }`}
              >
                Bảo Hiểm Xã Hội
              </button>
              <button
                onClick={() => setDetailTab('checklist')}
                className={`py-2.5 px-3 font-bold border-b-2 whitespace-nowrap ${
                  detailTab === 'checklist' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500'
                }`}
              >
                Checklist Tiếp Nhận / Nghỉ Việc
              </button>
            </div>

            {/* Profile Tab Content */}
            <div className="flex-1 overflow-y-auto p-5 text-xs space-y-4">
              {detailTab === 'personal' && (
                <div className="space-y-4">
                  <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                      <Briefcase className="w-4 h-4 text-indigo-600" />
                      Thông Tin Nhân Thân &amp; Liên Hệ
                    </h3>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-slate-400 block text-[11px]">Giới tính &amp; Ngày sinh:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {selectedEmployee.gender} &bull; {selectedEmployee.dob}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Trình độ học vấn:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {selectedEmployee.educationLevel}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Số điện thoại:</span>
                        <span className="font-semibold font-mono text-slate-800 dark:text-slate-200">
                          {selectedEmployee.phone}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Email công việc:</span>
                        <span className="font-semibold font-mono text-slate-800 dark:text-slate-200">
                          {selectedEmployee.email}
                        </span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-slate-400 block text-[11px]">Địa chỉ thường trú:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {selectedEmployee.permanentAddress}
                        </span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-slate-400 block text-[11px]">Địa chỉ tạm trú hiện nay:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {selectedEmployee.currentAddress}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Giấy tờ nhạy cảm có Masking */}
                  <div className="bg-amber-50/50 dark:bg-amber-950/20 p-4 rounded-xl border border-amber-200 dark:border-amber-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-sm text-amber-900 dark:text-amber-200 flex items-center gap-1.5">
                        <ShieldAlert className="w-4 h-4 text-amber-600" />
                        Giấy Tờ Cá Nhân &amp; Tài Khoản Ngân Hàng (Dữ liệu bảo mật)
                      </h3>
                      <button
                        onClick={() => toggleUnmask(`emp-${selectedEmployee.id}-idcard`, selectedEmployee.fullName, 'Số CCCD & Tài khoản')}
                        className="px-2.5 py-1 rounded bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200 font-bold text-[11px] flex items-center gap-1"
                      >
                        {unmaskedFields[`emp-${selectedEmployee.id}-idcard`] ? (
                          <>
                            <EyeOff className="w-3.5 h-3.5" />
                            <span>Che bớt</span>
                          </>
                        ) : (
                          <>
                            <Eye className="w-3.5 h-3.5" />
                            <span>Hiện đầy đủ</span>
                          </>
                        )}
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-slate-500 block text-[11px]">Số Căn cước công dân (CCCD):</span>
                        <span className="font-mono font-bold text-slate-900 dark:text-white">
                          {unmaskedFields[`emp-${selectedEmployee.id}-idcard`]
                            ? selectedEmployee.idCardNumber
                            : maskSensitive(selectedEmployee.idCardNumber, 4)}
                        </span>
                        <p className="text-[10px] text-slate-400">
                          Cấp ngày: {selectedEmployee.idCardDate} tại {selectedEmployee.idCardPlace}
                        </p>
                      </div>

                      <div>
                        <span className="text-slate-500 block text-[11px]">Mã số thuế cá nhân:</span>
                        <span className="font-mono font-bold text-slate-900 dark:text-white">
                          {unmaskedFields[`emp-${selectedEmployee.id}-idcard`]
                            ? selectedEmployee.personalTaxCode
                            : maskSensitive(selectedEmployee.personalTaxCode, 4)}
                        </span>
                      </div>

                      <div className="col-span-2">
                        <span className="text-slate-500 block text-[11px]">Tài khoản ngân hàng nhận lương:</span>
                        <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                          {unmaskedFields[`emp-${selectedEmployee.id}-idcard`]
                            ? selectedEmployee.bankAccount.accountNumber
                            : maskSensitive(selectedEmployee.bankAccount.accountNumber, 4)}
                        </span>
                        <span className="text-slate-500 ml-2 font-medium">
                          ({selectedEmployee.bankAccount.bankName} &bull; Chủ TK: {selectedEmployee.bankAccount.accountHolder})
                        </span>
                      </div>

                      <div className="col-span-2 pt-2 border-t border-amber-200/60 dark:border-amber-800">
                        <span className="text-slate-500 block text-[11px]">Người liên hệ khẩn cấp:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {selectedEmployee.emergencyContact.name} ({selectedEmployee.emergencyContact.relationship}) - SĐT: {selectedEmployee.emergencyContact.phone}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {detailTab === 'job' && (
                <div className="space-y-4">
                  <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                      <Briefcase className="w-4 h-4 text-indigo-600" />
                      Thông Tin Công Việc Hiện Tại
                    </h3>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-slate-400 block text-[11px]">Phòng ban:</span>
                        <span className="font-bold text-slate-900 dark:text-white">{selectedEmployee.departmentName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Đội / Nhóm:</span>
                        <span className="font-bold text-indigo-600">{selectedEmployee.teamName || 'Không trực thuộc nhóm'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Chức danh &amp; Cấp bậc:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{selectedEmployee.positionName} ({selectedEmployee.jobLevel})</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Quản lý trực tiếp:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{selectedEmployee.directManagerName || '—'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Địa điểm làm việc:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{selectedEmployee.workLocation} ({selectedEmployee.workRegion})</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Ngày vào làm &amp; Chính thức:</span>
                        <span className="font-semibold font-mono text-slate-800 dark:text-slate-200">
                          {selectedEmployee.joinDate} {selectedEmployee.officialDate ? `(Chính thức: ${selectedEmployee.officialDate})` : '(Đang thử việc)'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Tài khoản & Vai trò hệ thống */}
                  <div className="bg-indigo-50/50 dark:bg-indigo-950/20 p-4 rounded-xl border border-indigo-200 dark:border-indigo-800 space-y-3">
                    <h3 className="font-bold text-sm text-indigo-950 dark:text-indigo-200 flex items-center gap-1.5">
                      <Lock className="w-4 h-4 text-indigo-600" />
                      Tài Khoản CRM &amp; Quyền Hạn Hệ Thống
                    </h3>
                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-slate-500 block text-[11px]">Tên đăng nhập CRM:</span>
                        <span className="font-mono font-bold text-indigo-700 dark:text-indigo-300">
                          {selectedEmployee.loginUsername || selectedEmployee.code.toLowerCase()}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">Vai trò phân quyền:</span>
                        <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 font-bold text-[11px]">
                          {selectedEmployee.systemRole}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">Trạng thái tài khoản:</span>
                        <span className={`font-bold ${selectedEmployee.accountStatus === 'active' ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {selectedEmployee.accountStatus === 'active' ? 'Đang hoạt động' : 'Đã khóa tài khoản'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {detailTab === 'contracts' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                      Danh Sách Hợp Đồng Lao Động
                    </h3>
                    <button
                      onClick={() => {
                        const newCtrNumber = `HĐLĐ-2026-${selectedEmployee.code.replace('NV-', '')}-v2`;
                        renewOrSignContract(selectedEmployee.id, {
                          contractNumber: newCtrNumber,
                          type: 'Xác định thời hạn',
                          startDate: new Date().toISOString().split('T')[0],
                          endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                          baseSalary: selectedEmployee.insuranceSalary,
                          allowances: [],
                          insuranceSalary: selectedEmployee.insuranceSalary,
                          signedDate: new Date().toISOString().split('T')[0],
                        });
                      }}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white font-bold text-xs hover:bg-indigo-700 flex items-center gap-1"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Gia Hạn / Ký Mới HĐLĐ</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {contracts
                      .filter((c) => c.employeeId === selectedEmployee.id)
                      .map((c) => (
                        <div
                          key={c.id}
                          className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850 space-y-2"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-indigo-600 font-mono text-xs">
                              {c.contractNumber} ({c.type})
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                c.status === 'Còn hạn'
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : c.status === 'Sắp hết hạn'
                                  ? 'bg-amber-100 text-amber-800 ring-1 ring-amber-300'
                                  : 'bg-slate-100 text-slate-600'
                              }`}
                            >
                              {c.status}
                            </span>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                            <div>
                              <span className="text-slate-400 block text-[11px]">Thời hạn:</span>
                              <span className="font-mono">
                                {c.startDate} &rarr; {c.endDate || 'Không thời hạn'}
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[11px]">Lương cơ bản:</span>
                              <span className="font-mono font-bold text-slate-900 dark:text-white">
                                {c.baseSalary.toLocaleString()} đ
                              </span>
                            </div>
                            <div>
                              <span className="text-slate-400 block text-[11px]">Lương đóng BHXH:</span>
                              <span className="font-mono font-bold text-indigo-600">
                                {c.insuranceSalary.toLocaleString()} đ
                              </span>
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {detailTab === 'history' && (
                <div className="space-y-3">
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                    Quá Trình Công Tác &amp; Biến Động Nhân Sự (Tự động ghi nhận)
                  </h3>
                  <div className="border-l-2 border-indigo-300 dark:border-indigo-800 pl-4 space-y-4">
                    {workHistories
                      .filter((w) => w.employeeId === selectedEmployee.id)
                      .map((w) => (
                        <div key={w.id} className="relative text-xs">
                          <span className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full bg-indigo-600 ring-4 ring-white dark:ring-slate-900" />
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-indigo-600">{w.date}</span>
                            <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-bold">
                              {w.type}
                            </span>
                          </div>
                          <p className="font-semibold text-slate-800 dark:text-slate-200 mt-1">
                            {w.changeSummary}
                          </p>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            Thực hiện bởi: {w.performedBy} {w.notes ? `(${w.notes})` : ''}
                          </p>
                        </div>
                      ))}
                  </div>
                </div>
              )}

              {detailTab === 'insurance' && (
                <div className="space-y-4">
                  <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-1.5">
                        <FileCheck className="w-4 h-4 text-indigo-600" />
                        Tóm Tắt Bảo Hiểm Xã Hội &amp; BHYT
                      </h3>
                      <button
                        onClick={() => setActiveModule('hr-insurance')}
                        className="text-xs text-indigo-600 hover:underline font-bold flex items-center gap-1"
                      >
                        <span>Mở phân hệ BHXH &rarr;</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-slate-400 block text-[11px]">Mã số BHXH (10 số):</span>
                        <span className="font-mono font-bold text-slate-900 dark:text-white">
                          {selectedEmployee.socialInsuranceNumber || 'Chưa đăng ký'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Số thẻ BHYT &amp; Hạn dùng:</span>
                        <span className="font-mono font-bold text-slate-900 dark:text-white">
                          {selectedEmployee.healthInsuranceCardNumber || 'Chưa cấp'}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Mức lương đóng BHXH:</span>
                        <span className="font-mono font-bold text-emerald-600 text-sm">
                          {selectedEmployee.insuranceSalary.toLocaleString()} đ
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[11px]">Trạng thái đóng:</span>
                        <span className="font-bold text-indigo-600">{selectedEmployee.insuranceStatus}</span>
                      </div>
                      <div className="col-span-2">
                        <span className="text-slate-400 block text-[11px]">Cơ sở khám chữa bệnh ban đầu:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {selectedEmployee.healthClinicName || 'Bệnh viện Nông Nghiệp'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {detailTab === 'checklist' && (
                <div className="space-y-6">
                  {/* Onboarding Checklist */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-indigo-600" />
                          Checklist Tiếp Nhận (Onboarding)
                        </h3>
                        <p className="text-[11px] text-slate-400">Các hạng mục công việc khi tiếp nhận nhân sự mới vào công ty</p>
                      </div>
                      {(() => {
                        const total = SAMPLE_CHECKLISTS.onboarding.length;
                        const done = SAMPLE_CHECKLISTS.onboarding.filter((i: ChecklistItem) => i.completed).length;
                        const pct = Math.round((done / total) * 100);
                        return (
                          <div className="text-right">
                            <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 font-mono">
                              {done}/{total} ({pct}%)
                            </span>
                            <div className="w-24 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full mt-1 overflow-hidden">
                              <div className="h-full bg-indigo-600 rounded-full transition-all" style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                        );
                      })()}
                    </div>

                    <div className="space-y-2">
                      {SAMPLE_CHECKLISTS.onboarding.map((item: ChecklistItem) => (
                        <div
                          key={item.id}
                          className={`p-3 rounded-xl border flex items-center justify-between text-xs transition-colors ${
                            item.completed
                              ? 'bg-emerald-50/40 border-emerald-200 dark:bg-emerald-950/20 dark:border-emerald-800'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <input
                              type="checkbox"
                              checked={item.completed}
                              onChange={(e) => updateChecklistItem(selectedEmployee.id, 'onboarding', item.id, e.target.checked)}
                              className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                            />
                            <div>
                              <span className={`font-semibold ${item.completed ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                                {item.title}
                              </span>
                              <p className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                                <span>Phụ trách: <strong>{item.assignedTo}</strong></span>
                                <span>&bull;</span>
                                <span>Hạn: <strong>{item.dueDate}</strong></span>
                              </p>
                            </div>
                          </div>

                          {item.completed ? (
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-100 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full flex items-center gap-1">
                              <Check className="w-3 h-3" /> Đã hoàn thành
                            </span>
                          ) : (
                            <span className="text-[10px] font-medium text-amber-600 bg-amber-50 dark:bg-amber-950/50 px-2 py-0.5 rounded-full flex items-center gap-1">
                              <Clock className="w-3 h-3" /> Đang xử lý
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Offboarding Checklist (Bàn giao công việc & Nghỉ việc) */}
                  <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                          <UserX className="w-4 h-4 text-rose-500" />
                          Checklist Nghỉ Việc &amp; Bàn Giao (Offboarding)
                        </h3>
                        <p className="text-[11px] text-slate-400">Quy trình bàn giao công việc, thu hồi thiết bị/tài khoản và chốt BHXH</p>
                      </div>
                      {(() => {
                        const total = SAMPLE_CHECKLISTS.offboarding.length;
                        const done = SAMPLE_CHECKLISTS.offboarding.filter((i: ChecklistItem) => i.completed).length;
                        const pct = Math.round((done / total) * 100);
                        return (
                          <div className="text-right">
                            <span className="text-xs font-bold text-rose-600 dark:text-rose-400 font-mono">
                              {done}/{total} ({pct}%)
                            </span>
                            <div className="w-24 h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full mt-1 overflow-hidden">
                              <div className="h-full bg-rose-600 rounded-full transition-all" style={{ width: `${pct}%` }} />
                            </div>
                          </div>
                        );
                      })()}
                    </div>

                    <div className="space-y-2">
                      {SAMPLE_CHECKLISTS.offboarding.map((item: ChecklistItem) => (
                        <div
                          key={item.id}
                          className={`p-3 rounded-xl border flex items-center justify-between text-xs transition-colors ${
                            item.completed
                              ? 'bg-emerald-50/40 border-emerald-200 dark:bg-emerald-950/20 dark:border-emerald-800'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
                          }`}
                        >
                          <div className="flex items-center gap-2.5">
                            <input
                              type="checkbox"
                              checked={item.completed}
                              onChange={(e) => updateChecklistItem(selectedEmployee.id, 'offboarding', item.id, e.target.checked)}
                              className="w-4 h-4 rounded text-rose-600 focus:ring-rose-500 cursor-pointer"
                            />
                            <div>
                              <span className={`font-semibold ${item.completed ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'}`}>
                                {item.title}
                              </span>
                              <p className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                                <span>Phụ trách: <strong>{item.assignedTo}</strong></span>
                                <span>&bull;</span>
                                <span>Hạn: <strong>{item.dueDate}</strong></span>
                              </p>
                            </div>
                          </div>

                          {item.completed ? (
                            <span className="text-[10px] font-bold text-emerald-600 bg-emerald-100 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full flex items-center gap-1">
                              <Check className="w-3 h-3" /> Đã hoàn thành
                            </span>
                          ) : (
                            <span className="text-[10px] font-medium text-slate-500 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full flex items-center gap-1">
                              <Clock className="w-3 h-3" /> Chờ thực hiện
                            </span>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL WIZARD THÊM NHÂN VIÊN MỚI (5 BƯỚC)
      ======================================================== */}
      {isAddWizardOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            {/* Wizard Header */}
            <div className="p-4 bg-slate-100 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                  <UserPlus className="w-4 h-4 text-indigo-600" />
                  Quy Trình Tiếp Nhận Nhân Viên Mới (Onboarding Wizard)
                </h3>
                <p className="text-xs text-slate-500">
                  Bước {wizardStep} / 5: {
                    wizardStep === 1 ? 'Thông tin cá nhân' :
                    wizardStep === 2 ? 'Vị trí công việc & Tài khoản' :
                    wizardStep === 3 ? 'Hợp đồng lao động' :
                    wizardStep === 4 ? 'Bảo hiểm xã hội' : 'Checklist tiếp nhận'
                  }
                </p>
              </div>
              <button onClick={() => setIsAddWizardOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Stepper Indicator */}
            <div className="grid grid-cols-5 border-b border-slate-200 dark:border-slate-800 text-[11px] font-bold text-center">
              {[
                { step: 1, title: '1. Cá nhân' },
                { step: 2, title: '2. Công việc' },
                { step: 3, title: '3. Hợp đồng' },
                { step: 4, title: '4. BHXH' },
                { step: 5, title: '5. Checklist' },
              ].map((s) => (
                <div
                  key={s.step}
                  onClick={() => setWizardStep(s.step as any)}
                  className={`py-2 cursor-pointer transition-colors ${
                    wizardStep === s.step
                      ? 'bg-indigo-600 text-white'
                      : wizardStep > s.step
                      ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300'
                      : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {s.title}
                </div>
              ))}
            </div>

            {/* Wizard Body */}
            <div className="flex-1 overflow-y-auto p-5 text-xs space-y-4">
              {wizardStep === 1 && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div className="col-span-2 sm:col-span-1">
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Họ và tên *</label>
                      <input
                        type="text"
                        value={wizPersonal.fullName}
                        onChange={(e) => setWizPersonal({ ...wizPersonal, fullName: e.target.value })}
                        placeholder="Ví dụ: Nguyễn Văn Hùng"
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Giới tính</label>
                      <select
                        value={wizPersonal.gender}
                        onChange={(e) => setWizPersonal({ ...wizPersonal, gender: e.target.value as any })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="Nam">Nam</option>
                        <option value="Nữ">Nữ</option>
                        <option value="Khác">Khác</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Ngày sinh</label>
                      <input
                        type="date"
                        value={wizPersonal.dob}
                        onChange={(e) => setWizPersonal({ ...wizPersonal, dob: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Số điện thoại *</label>
                      <input
                        type="text"
                        value={wizPersonal.phone}
                        onChange={(e) => setWizPersonal({ ...wizPersonal, phone: e.target.value })}
                        placeholder="0912 xxx xxx"
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Số CCCD (12 số)</label>
                      <input
                        type="text"
                        value={wizPersonal.idCardNumber}
                        onChange={(e) => setWizPersonal({ ...wizPersonal, idCardNumber: e.target.value })}
                        placeholder="001095xxxxxx"
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Mã số thuế cá nhân</label>
                      <input
                        type="text"
                        value={wizPersonal.personalTaxCode}
                        onChange={(e) => setWizPersonal({ ...wizPersonal, personalTaxCode: e.target.value })}
                        placeholder="8xxxxxxxx"
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                  </div>
                </div>
              )}

              {wizardStep === 2 && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Phòng ban *</label>
                      <select
                        value={wizJob.departmentId}
                        onChange={(e) => setWizJob({ ...wizJob, departmentId: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        {departments.map((d) => (
                          <option key={d.id} value={d.id}>{d.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Chức vụ *</label>
                      <select
                        value={wizJob.positionId}
                        onChange={(e) => setWizJob({ ...wizJob, positionId: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        {positions.map((p) => (
                          <option key={p.id} value={p.id}>{p.name} ({p.level})</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Quản lý trực tiếp</label>
                      <select
                        value={wizJob.directManagerId}
                        onChange={(e) => setWizJob({ ...wizJob, directManagerId: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="">Không có</option>
                        {employees.map((e) => (
                          <option key={e.id} value={e.id}>{e.fullName} ({e.positionName})</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Vai trò hệ thống CRM</label>
                      <select
                        value={wizJob.systemRole}
                        onChange={(e) => setWizJob({ ...wizJob, systemRole: e.target.value as any })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="Admin">Admin (Quản trị viên toàn quyền)</option>
                        <option value="Director">Ban Giám Đốc (Director)</option>
                        <option value="Sales Manager">Trưởng Phòng Sale (Sale Manager)</option>
                        <option value="Sales Staff">Nhân Viên Sale (Sales Staff)</option>
                        <option value="Technical Manager">Trưởng Phòng Kỹ Thuật (Technical Manager)</option>
                        <option value="Accountant">Kế Toán (Accountant)</option>
                        <option value="HR Staff">Nhân Sự (HR Staff)</option>
                        <option value="Warehouse Staff">Nhân Viên Kho (Warehouse Staff)</option>
                      </select>
                    </div>
                  </div>
                </div>
              )}

              {wizardStep === 3 && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Loại hợp đồng</label>
                      <select
                        value={wizContract.type}
                        onChange={(e) => setWizContract({ ...wizContract, type: e.target.value as any })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      >
                        <option value="Thử việc">Thử việc (02 tháng)</option>
                        <option value="Xác định thời hạn">Xác định thời hạn (12 tháng)</option>
                        <option value="Không xác định thời hạn">Không xác định thời hạn</option>
                        <option value="Thời vụ/Dịch vụ">Thời vụ / Dịch vụ</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Ngày bắt đầu</label>
                      <input
                        type="date"
                        value={wizContract.startDate}
                        onChange={(e) => setWizContract({ ...wizContract, startDate: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Lương cơ bản (VNĐ)</label>
                      <input
                        type="number"
                        value={wizContract.baseSalary}
                        onChange={(e) => setWizContract({ ...wizContract, baseSalary: Number(e.target.value) })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Lương đóng BHXH (VNĐ)</label>
                      <input
                        type="number"
                        value={wizContract.insuranceSalary}
                        onChange={(e) => setWizContract({ ...wizContract, insuranceSalary: Number(e.target.value) })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                  </div>
                </div>
              )}

              {wizardStep === 4 && (
                <div className="space-y-3">
                  <div className="p-3 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-xl text-sky-900 dark:text-sky-200 text-xs">
                    Hệ thống sẽ <strong>tự động đề xuất Báo tăng BHXH</strong> sang phân hệ Bảo hiểm xã hội ngay sau khi hoàn tất thêm nhân viên này.
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Mã số BHXH (nếu đã có)</label>
                      <input
                        type="text"
                        value={wizInsurance.socialInsuranceNumber}
                        onChange={(e) => setWizInsurance({ ...wizInsurance, socialInsuranceNumber: e.target.value })}
                        placeholder="Để trống nếu chưa từng tham gia"
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-400 font-semibold mb-1">Nơi khám chữa bệnh ban đầu</label>
                      <input
                        type="text"
                        value={wizInsurance.healthClinicName}
                        onChange={(e) => setWizInsurance({ ...wizInsurance, healthClinicName: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                      />
                    </div>
                  </div>
                </div>
              )}

              {wizardStep === 5 && (
                <div className="space-y-3">
                  <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200">
                    Danh Sách Việc Cần Làm Khi Tiếp Nhận (Onboarding Checklist)
                  </h4>
                  <div className="space-y-2">
                    {wizChecklist.map((c, i) => (
                      <div key={c.id} className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                        <span>{i + 1}. {c.title}</span>
                        <span className="text-slate-400 text-[11px]">{c.assignedTo} &bull; {c.dueDate}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Wizard Footer */}
            <div className="p-4 bg-slate-50 dark:bg-slate-850 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <button
                  onClick={() => {
                    showToast('Lưu nháp', 'Đã lưu bản nháp thông tin nhân viên.', 'info');
                    setIsAddWizardOpen(false);
                  }}
                  className="px-3 py-1.5 text-xs text-slate-600 hover:underline"
                >
                  Lưu nháp &amp; Thoát
                </button>
              </div>

              <div className="flex items-center gap-2">
                {wizardStep > 1 && (
                  <button
                    onClick={() => setWizardStep((prev) => (prev - 1) as any)}
                    className="px-3.5 py-1.5 rounded-lg border border-slate-300 text-xs font-semibold"
                  >
                    Quay lại
                  </button>
                )}
                {wizardStep < 5 ? (
                  <button
                    onClick={() => setWizardStep((prev) => (prev + 1) as any)}
                    className="px-4 py-1.5 rounded-lg bg-indigo-600 text-white font-bold text-xs"
                  >
                    Tiếp theo &rarr;
                  </button>
                ) : (
                  <button
                    onClick={handleFinishWizard}
                    className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs shadow-sm hover:bg-emerald-700"
                  >
                    Hoàn tất &amp; Thêm nhân viên
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL BÀN GIAO DỮ LIỆU CRM KHI NGHỈ VIỆC
      ======================================================== */}
      {isHandoverModalOpen && handoverSourceEmp && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 text-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <UserX className="w-5 h-5 text-rose-600" />
                Bàn Giao Dữ Liệu CRM &amp; Thôi Việc
              </h3>
              <button onClick={() => setIsHandoverModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 rounded-xl text-rose-900 dark:text-rose-200 space-y-1">
              <p className="font-bold">Nhân sự nghỉ việc: {handoverSourceEmp.fullName} ({handoverSourceEmp.code})</p>
              <p className="text-[11px]">
                Hệ thống bắt buộc chọn nhân sự thay thế để tiếp nhận toàn bộ khách hàng, tiềm năng và cơ hội kinh doanh.
              </p>
            </div>

            {/* Counts */}
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border">
                <span className="text-[10px] text-slate-400 block">Khách hàng</span>
                <span className="font-bold text-base text-indigo-600">
                  {customers.filter((c) => c.assignedTo === handoverSourceEmp.fullName).length}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border">
                <span className="text-[10px] text-slate-400 block">Leads</span>
                <span className="font-bold text-base text-sky-600">
                  {leads.filter((l) => l.assignedTo === handoverSourceEmp.fullName).length}
                </span>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800 border">
                <span className="text-[10px] text-slate-400 block">Cơ hội (Deals)</span>
                <span className="font-bold text-base text-emerald-600">
                  {opportunities.filter((o) => o.assignedTo === handoverSourceEmp.fullName).length}
                </span>
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 dark:text-slate-300 mb-1">
                Chọn người tiếp nhận bàn giao *:
              </label>
              <select
                value={handoverTargetId}
                onChange={(e) => setHandoverTargetId(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
              >
                {employees
                  .filter((e) => e.id !== handoverSourceEmp.id && e.status === 'Chính thức')
                  .map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.fullName} ({e.departmentName} - {e.positionName})
                    </option>
                  ))}
              </select>
            </div>

            <div>
              <label className="block text-slate-600 font-medium mb-1">Ghi chú bàn giao:</label>
              <textarea
                value={handoverNotes}
                onChange={(e) => setHandoverNotes(e.target.value)}
                rows={2}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs"
              />
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
              <button
                onClick={() => setIsHandoverModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg border text-xs font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={handleConfirmHandover}
                className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold text-xs hover:bg-rose-700 shadow-sm"
              >
                Xác nhận bàn giao &amp; Khóa tài khoản
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL NHẬP EXCEL
      ======================================================== */}
      {isExcelImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl p-6 text-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <Upload className="w-5 h-5 text-indigo-600" />
                Nhập Danh Sách Nhân Viên Từ File Excel
              </h3>
              <button onClick={() => setIsExcelImportModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-indigo-50/60 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-800 rounded-xl flex items-center justify-between">
              <div>
                <span className="font-bold text-indigo-900 dark:text-indigo-200 block">File mẫu chuẩn doanh nghiệp</span>
                <span className="text-[11px] text-indigo-700 dark:text-indigo-400">Tải file mẫu Excel có định dạng kiểm tra lỗi từng dòng</span>
              </div>
              <button
                onClick={() => showToast('Tải file mẫu', 'Đã tải xuống file template: Mau_Nhan_Vien_CRM_2026.xlsx', 'info')}
                className="px-3 py-1.5 bg-white dark:bg-slate-800 border border-indigo-300 rounded-lg text-indigo-700 dark:text-indigo-300 font-bold text-xs"
              >
                Tải file mẫu (.xlsx)
              </button>
            </div>

            <div>
              <h4 className="font-bold text-xs mb-2">Xem trước dữ liệu import (3 dòng):</h4>
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] text-slate-500 font-bold border-b">
                    <tr>
                      <th className="p-2">Dòng</th>
                      <th className="p-2">Họ Tên</th>
                      <th className="p-2">Số Điện Thoại</th>
                      <th className="p-2">Phòng Ban</th>
                      <th className="p-2">Kiểm tra hợp lệ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {importRows.map((r) => (
                      <tr key={r.row} className={r.status.startsWith('Lỗi') ? 'bg-rose-50/60 text-rose-700' : ''}>
                        <td className="p-2 font-mono">{r.row}</td>
                        <td className="p-2 font-bold">{r.name}</td>
                        <td className="p-2 font-mono">{r.phone || '—'}</td>
                        <td className="p-2">{r.dept}</td>
                        <td className="p-2 font-semibold">{r.status}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end gap-2">
              <button
                onClick={() => setIsExcelImportModalOpen(false)}
                className="px-3 py-1.5 rounded-lg border text-xs font-semibold"
              >
                Đóng
              </button>
              <button
                onClick={() => {
                  showToast('Import thành công', 'Đã nhập thành công 2 nhân viên hợp lệ vào hệ thống.', 'success');
                  setIsExcelImportModalOpen(false);
                }}
                className="px-4 py-1.5 rounded-lg bg-indigo-600 text-white font-bold text-xs hover:bg-indigo-700"
              >
                Tiến hành Import
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL THÊM PHÒNG BAN */}
      {isAddDeptModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 text-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b">
              <h3 className="font-bold text-sm">Thêm Phòng Ban Mới</h3>
              <button onClick={() => setIsAddDeptModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>
            <div>
              <label className="block font-semibold mb-1">Mã phòng ban *</label>
              <input
                type="text"
                placeholder="VD: MKT"
                value={deptForm.code}
                onChange={(e) => setDeptForm({ ...deptForm, code: e.target.value.toUpperCase() })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">Tên phòng ban *</label>
              <input
                type="text"
                placeholder="VD: Phòng Marketing & Truyền Thông"
                value={deptForm.name}
                onChange={(e) => setDeptForm({ ...deptForm, name: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>
            <div className="pt-2 flex justify-end gap-2">
              <button onClick={() => setIsAddDeptModalOpen(false)} className="px-3 py-1.5 border rounded-lg">Hủy</button>
              <button
                onClick={() => {
                  if (!deptForm.name) return;
                  addDepartment({ code: deptForm.code || 'PB', name: deptForm.name, status: 'active' });
                  setIsAddDeptModalOpen(false);
                }}
                className="px-4 py-1.5 bg-indigo-600 text-white font-bold rounded-lg"
              >
                Lưu phòng ban
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
