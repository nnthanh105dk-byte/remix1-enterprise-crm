import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { SalesQuotation, SalesQuotationLineItem } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import { numberToVietnameseWords } from '../../utils/vietnameseNumberWords';
import { INITIAL_WAREHOUSE_PRODUCTS } from '../../data/mockWarehouseData';
import {
  FileSpreadsheet,
  Plus,
  Printer,
  Copy,
  Mail,
  Send,
  CheckCircle2,
  XCircle,
  Clock,
  Search,
  Building,
  User,
  Trash2,
  X,
  Layers,
  ArrowRight,
  ExternalLink,
  ShieldAlert,
  RotateCcw,
} from 'lucide-react';
import { APlusLogo } from '../../components/common/APlusLogo';
import { useColumnVisibility, ColumnDef } from '../../hooks/useColumnVisibility';
import { ColumnVisibilityPicker } from '../../components/common/ColumnVisibilityPicker';

const QUOTATION_COLUMNS: ColumnDef[] = [
  { id: 'code', label: 'Số Báo Giá', required: true },
  { id: 'customer', label: 'Khách Hàng & Cơ Hội' },
  { id: 'total', label: 'Tổng Tiền (VNĐ)' },
  { id: 'expiry', label: 'Hạn Hiệu Lực' },
  { id: 'status', label: 'Trạng Thái' },
  { id: 'creator', label: 'Người Lập' },
  { id: 'actions', label: 'Thao Tác' },
];

export const SalesQuotationsView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const {
    quotations,
    customers,
    opportunities,
    createQuotation,
    duplicateQuotationVersion,
    updateQuotationStatus,
    createOrderFromQuotation,
  } = useSales();

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const {
    columns: colDefs,
    visibleColumns,
    isVisible,
    toggleColumn,
    selectAll,
    resetToDefault,
  } = useColumnVisibility('sales_quotations', QUOTATION_COLUMNS);

  // Selected Quotation for Preview / Print
  const [previewQuote, setPreviewQuote] = useState<SalesQuotation | null>(null);

  // Modal: Soạn Báo Giá Mới
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  // Form State
  const [formTitle, setFormTitle] = useState('Báo giá Giải pháp & Thiết bị Công nghệ 2026');
  const [formCustomerId, setFormCustomerId] = useState(customers[0]?.id || '');
  const [formOpportunityId, setFormOpportunityId] = useState('');
  const [formTaxRate, setFormTaxRate] = useState<0 | 5 | 8 | 10>(10);
  const [formDiscountTotal, setFormDiscountTotal] = useState<number>(0);
  const [formValidUntil, setFormValidUntil] = useState<string>(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [formPaymentTerms, setFormPaymentTerms] = useState(
    'Đợt 1: Tạm ứng 40% khi ký HĐ, Đợt 2: Giao hàng 40%, Đợt 3: Nghiệm thu 20%'
  );
  const [formNotes, setFormNotes] = useState('Bảo hành chính hãng 36 tháng On-site. Miễn phí vận chuyển toàn quốc.');
  const [formItems, setFormItems] = useState<SalesQuotationLineItem[]>([
    {
      id: 'qi-1',
      productId: INITIAL_WAREHOUSE_PRODUCTS[0]?.id || 'prod-01',
      sku: INITIAL_WAREHOUSE_PRODUCTS[0]?.sku || 'HW-SRV-DL380',
      productName: INITIAL_WAREHOUSE_PRODUCTS[0]?.name || 'Máy chủ HPE ProLiant DL380 Gen10',
      unit: INITIAL_WAREHOUSE_PRODUCTS[0]?.unit || 'Chiếc',
      quantity: 5,
      unitPrice: INITIAL_WAREHOUSE_PRODUCTS[0]?.sellingPrice || 58000000,
      discountPercent: 0,
      total: 5 * (INITIAL_WAREHOUSE_PRODUCTS[0]?.sellingPrice || 58000000),
      availableStock: 11,
    },
  ]);

  // Handle Customer Selection in Form
  const handleCustomerChange = (custId: string) => {
    setFormCustomerId(custId);
    // Find customer's first open deal if any
    const custDeal = opportunities.find((o) => o.customerId === custId);
    if (custDeal) {
      setFormOpportunityId(custDeal.id);
    } else {
      setFormOpportunityId('');
    }
  };

  // Add Item to Quotation Form
  const handleAddItem = (productId: string) => {
    const whProd = INITIAL_WAREHOUSE_PRODUCTS.find((p) => p.id === productId);
    if (!whProd) return;
    const totalStock = Object.values(whProd.stocks).reduce((a, b) => a + b, 0);
    const available = Math.max(0, totalStock - whProd.reserved);

    const newItem: SalesQuotationLineItem = {
      id: `qi-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      productId: whProd.id,
      sku: whProd.sku,
      productName: whProd.name,
      unit: whProd.unit,
      quantity: 1,
      unitPrice: whProd.sellingPrice,
      discountPercent: 0,
      total: whProd.sellingPrice,
      availableStock: available,
    };
    setFormItems((prev) => [...prev, newItem]);
  };

  const handleUpdateItemQty = (id: string, qty: number) => {
    if (qty <= 0) return;
    setFormItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const discountAmt = (item.unitPrice * qty * item.discountPercent) / 100;
        return {
          ...item,
          quantity: qty,
          total: item.unitPrice * qty - discountAmt,
        };
      })
    );
  };

  const handleUpdateItemDiscount = (id: string, disc: number) => {
    setFormItems((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const discountAmt = (item.unitPrice * item.quantity * disc) / 100;
        return {
          ...item,
          discountPercent: disc,
          total: item.unitPrice * item.quantity - discountAmt,
        };
      })
    );
  };

  const handleRemoveItem = (id: string) => {
    setFormItems((prev) => prev.filter((i) => i.id !== id));
  };

  // Form calculations
  const formSubTotal = formItems.reduce((sum, item) => sum + item.total, 0);
  const formDiscountAmt = Math.round((formSubTotal * formDiscountTotal) / 100);
  const formAfterDiscount = formSubTotal - formDiscountAmt;
  const formTaxAmt = Math.round((formAfterDiscount * formTaxRate) / 100);
  const formGrandTotal = formAfterDiscount + formTaxAmt;

  const handleCreateQuotationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formItems.length === 0) {
      showToast('Lỗi', 'Báo giá phải có ít nhất 1 dòng sản phẩm.', 'warning');
      return;
    }

    const cust = customers.find((c) => c.id === formCustomerId);
    if (!cust) return;

    const opp = opportunities.find((o) => o.id === formOpportunityId);

    const newQuote = createQuotation({
      title: formTitle,
      customerId: cust.id,
      customerCode: cust.code,
      customerName: cust.name,
      customerCompany: cust.name,
      customerEmail: cust.email,
      customerPhone: cust.phone,
      customerAddress: cust.billingAddress,
      opportunityId: opp?.id,
      opportunityCode: opp?.code,
      items: formItems,
      discountPercentTotal: formDiscountTotal,
      taxRate: formTaxRate,
      status: 'Nháp',
      validUntil: formValidUntil,
      paymentTerms: formPaymentTerms,
      notes: formNotes,
      createdByName: 'Lê Hoàng Yến',
    });

    setIsCreateModalOpen(false);
    setPreviewQuote(newQuote);
  };

  const handlePrint = () => {
    window.print();
  };

  // Filtered List
  const filteredQuotes = quotations.filter((q) => {
    if (statusFilter !== 'all' && q.status !== statusFilter) return false;
    if (searchTerm) {
      const query = searchTerm.toLowerCase();
      return (
        q.code.toLowerCase().includes(query) ||
        q.title.toLowerCase().includes(query) ||
        q.customerName.toLowerCase().includes(query) ||
        (q.opportunityCode && q.opportunityCode.toLowerCase().includes(query))
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
                <FileSpreadsheet className="w-5 h-5" />
              </span>
              Báo Giá &amp; Đề Xuất (Quotations)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {quotations.length} Bản báo giá
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Soạn thảo báo giá chuẩn mẫu doanh nghiệp, kiểm tra tồn kho tức thì, quản lý đa phiên bản (v1, v2) và luồng duyệt chiết khấu.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-sky-600 text-white hover:bg-sky-700 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Soạn Báo Giá Mới</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo số báo giá (BG-...), tiêu đề, khách hàng..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">Trạng thái:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="Nháp">Nháp</option>
              <option value="Chờ duyệt">Chờ duyệt</option>
              <option value="Chờ Sales duyệt thương mại">Chờ Sales duyệt thương mại (từ Kỹ thuật)</option>
              <option value="Đã gửi">Đã gửi</option>
              <option value="Chấp nhận">Chấp nhận</option>
              <option value="Từ chối">Từ chối</option>
              <option value="Hết hạn">Hết hạn</option>
            </select>
          </div>

          <ColumnVisibilityPicker
            columns={colDefs}
            visibleColumns={visibleColumns}
            onToggleColumn={toggleColumn}
            onSelectAll={selectAll}
            onReset={resetToDefault}
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800 uppercase text-[11px]">
              <tr>
                {isVisible('code') && <th className="py-3 px-3">Số Báo Giá</th>}
                {isVisible('customer') && <th className="py-3 px-3">Khách Hàng &amp; Cơ Hội</th>}
                {isVisible('total') && <th className="py-3 px-3 text-right">Tổng Tiền (VNĐ)</th>}
                {isVisible('expiry') && <th className="py-3 px-3">Hạn Hiệu Lực</th>}
                {isVisible('status') && <th className="py-3 px-3">Trạng Thái</th>}
                {isVisible('creator') && <th className="py-3 px-3">Người Lập</th>}
                {isVisible('actions') && <th className="py-3 px-3 text-right">Thao Tác</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredQuotes.length === 0 ? (
                <tr>
                  <td
                    colSpan={colDefs.filter((c) => isVisible(c.id)).length || 1}
                    className="py-8 text-center text-slate-400"
                  >
                    Không tìm thấy báo giá nào phù hợp với bộ lọc.
                  </td>
                </tr>
              ) : (
                filteredQuotes.map((quote) => (
                  <tr
                    key={quote.id}
                    onClick={() => setPreviewQuote(quote)}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                  >
                    {isVisible('code') && (
                      <td className="py-3 px-3">
                        <span className="font-mono font-bold text-sky-600 dark:text-sky-400 block">
                          {quote.code}
                        </span>
                        <span className="text-[10px] text-slate-400">Phiên bản {quote.version}</span>
                      </td>
                    )}

                    {isVisible('customer') && (
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900 dark:text-white line-clamp-1">
                          {quote.title}
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1.5">
                          <Building className="w-3 h-3 text-slate-400" />
                          <span>{quote.customerName}</span>
                          {quote.opportunityCode && (
                            <span className="font-mono text-sky-600">• {quote.opportunityCode}</span>
                          )}
                        </div>
                      </td>
                    )}

                    {isVisible('total') && (
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                        {quote.grandTotal.toLocaleString()} ₫
                      </td>
                    )}

                    {isVisible('expiry') && (
                      <td className="py-3 px-3 font-mono text-[11px]">
                        {quote.validUntil}
                      </td>
                    )}

                    {isVisible('status') && (
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            quote.status === 'Chấp nhận'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                              : quote.status === 'Chờ Sales duyệt thương mại'
                              ? 'bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300 ring-1 ring-purple-300 dark:ring-purple-700'
                              : quote.status === 'Chờ duyệt'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300'
                              : quote.status === 'Đã gửi'
                              ? 'bg-sky-100 text-sky-800 dark:bg-sky-950/60 dark:text-sky-300'
                              : quote.status === 'Từ chối'
                              ? 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300'
                              : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                          }`}
                        >
                          {quote.status}
                        </span>
                      </td>
                    )}

                    {isVisible('creator') && (
                      <td className="py-3 px-3 font-medium">
                        {quote.createdByName}
                      </td>
                    )}

                    {isVisible('actions') && (
                      <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => setPreviewQuote(quote)}
                            className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-200 text-xs cursor-pointer"
                          >
                            Xem &amp; In
                          </button>
                          <button
                            onClick={() => duplicateQuotationVersion(quote.id)}
                            className="p-1 rounded text-slate-400 hover:text-sky-600 cursor-pointer"
                            title="Nhân bản phiên bản v2"
                          >
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal / Drawer: Xem Trước & In Báo Giá Chuẩn Doanh Nghiệp */}
      {previewQuote && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
          <div className="w-full max-w-4xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl h-[92vh] overflow-y-auto flex flex-col shadow-2xl p-6">
            {/* Top Toolbar */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 shrink-0">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs px-2.5 py-1 rounded bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-bold">
                  {previewQuote.code}
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-bold">
                  Trạng thái: {previewQuote.status}
                </span>
                {previewQuote.requiresApproval && (
                  <span className="text-xs px-2 py-0.5 rounded bg-amber-100 text-amber-800 font-bold flex items-center gap-1">
                    <ShieldAlert className="w-3 h-3" /> Cần {previewQuote.approvalRequiredBy} duyệt
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 font-semibold text-xs flex items-center gap-1.5 hover:bg-slate-100"
                >
                  <Printer className="w-3.5 h-3.5" /> In / PDF
                </button>

                <button
                  onClick={() => {
                    navigator.clipboard.writeText(window.location.href);
                    showToast('Đã sao chép link', 'Đã lưu đường dẫn xem báo giá trực tuyến vào clipboard.');
                  }}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 font-semibold text-xs flex items-center gap-1.5 hover:bg-slate-100"
                >
                  <Copy className="w-3.5 h-3.5" /> Sao chép liên kết
                </button>

                <button
                  onClick={() => setPreviewQuote(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Chain Bar */}
            <div className="mt-4">
              <DocumentChainBar currentType="quotation" chain={previewQuote.chain} />
            </div>

            {/* Preview Sheet (Printable A4 Content) */}
            <div className="mt-6 flex-1 p-6 border border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-950/40 text-xs text-slate-800 dark:text-slate-200 space-y-6">
              {/* Header Company & Logo */}
              <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-5">
                <div className="flex items-center gap-3">
                  <APlusLogo size={42} />
                  <div>
                    <h2 className="text-base font-bold text-slate-900 dark:text-white">
                      CÔNG TY CỔ PHẦN CÔNG NGHỆ &amp; THƯƠNG MẠI A+ ENTERPRISE
                    </h2>
                    <p className="text-[11px] text-slate-500">
                      Tòa nhà Innovation Hub, 180 Triệu Việt Vương, Hai Bà Trưng, Hà Nội
                    </p>
                    <p className="text-[11px] text-slate-500">
                      Hotline: 1900 6868 • Email: sales@aplus-enterprise.vn • MST: 0108998877
                    </p>
                  </div>
                </div>
                <div className="text-right font-mono">
                  <span className="text-lg font-bold text-sky-600 block">{previewQuote.code}</span>
                  <span className="text-[11px] text-slate-400">Ngày lập: {previewQuote.createdAt}</span>
                </div>
              </div>

              {/* Title */}
              <div className="text-center py-2">
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white uppercase tracking-tight">
                  BÁO GIÁ THIẾT BỊ &amp; GIẢI PHÁP
                </h3>
                <p className="text-slate-500 mt-0.5">{previewQuote.title}</p>
              </div>

              {/* Info Customer */}
              <div className="grid grid-cols-2 gap-4 bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-slate-400 block text-[11px] font-semibold">Kính gửi Quý khách hàng:</span>
                  <h4 className="font-bold text-slate-900 dark:text-white text-sm">{previewQuote.customerName}</h4>
                  <p className="text-slate-600 dark:text-slate-300">{previewQuote.customerCompany}</p>
                  <p className="text-slate-500 text-[11px] mt-1">Địa chỉ: {previewQuote.customerAddress}</p>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px] font-semibold">Thông tin liên hệ &amp; Người lập:</span>
                  <p className="font-medium">Người liên hệ: {previewQuote.customerPhone} ({previewQuote.customerEmail})</p>
                  <p className="text-slate-600 dark:text-slate-300 mt-1">
                    Đại diện kinh doanh: <strong>{previewQuote.createdByName}</strong>
                  </p>
                  <p className="text-slate-500 text-[11px] font-mono">Hiệu lực đến: {previewQuote.validUntil}</p>
                </div>
              </div>

              {/* Items Table */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden bg-white dark:bg-slate-900">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3 w-10 text-center">STT</th>
                      <th className="py-2.5 px-3">Mã SKU</th>
                      <th className="py-2.5 px-3">Tên Hàng Hóa / Dịch Vụ</th>
                      <th className="py-2.5 px-3 text-center">ĐVT</th>
                      <th className="py-2.5 px-3 text-right">Số Lượng</th>
                      <th className="py-2.5 px-3 text-right">Đơn Giá</th>
                      <th className="py-2.5 px-3 text-right">CK (%)</th>
                      <th className="py-2.5 px-3 text-right">Thành Tiền</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {previewQuote.items.map((item, idx) => (
                      <tr key={item.id}>
                        <td className="py-2.5 px-3 text-center text-slate-400 font-mono">{idx + 1}</td>
                        <td className="py-2.5 px-3 font-mono font-bold text-sky-600">{item.sku}</td>
                        <td className="py-2.5 px-3 font-medium text-slate-900 dark:text-white">{item.productName}</td>
                        <td className="py-2.5 px-3 text-center">{item.unit}</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold">{item.quantity}</td>
                        <td className="py-2.5 px-3 text-right font-mono">{item.unitPrice.toLocaleString()} ₫</td>
                        <td className="py-2.5 px-3 text-right font-mono">{item.discountPercent}%</td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                          {item.total.toLocaleString()} ₫
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Total Summary */}
              <div className="flex justify-end">
                <div className="w-72 space-y-1.5 text-xs font-mono">
                  <div className="flex justify-between text-slate-500">
                    <span>Tổng tiền hàng:</span>
                    <span>{previewQuote.subTotal.toLocaleString()} ₫</span>
                  </div>
                  {previewQuote.discountAmountTotal > 0 && (
                    <div className="flex justify-between text-amber-600">
                      <span>Chiết khấu ({previewQuote.discountPercentTotal}%):</span>
                      <span>-{previewQuote.discountAmountTotal.toLocaleString()} ₫</span>
                    </div>
                  )}
                  <div className="flex justify-between text-slate-500">
                    <span>Thuế GTGT ({previewQuote.taxRate}%):</span>
                    <span>{previewQuote.taxAmount.toLocaleString()} ₫</span>
                  </div>
                  <div className="flex justify-between text-base font-bold text-sky-600 pt-2 border-t border-slate-200">
                    <span>TỔNG CỘNG:</span>
                    <span>{previewQuote.grandTotal.toLocaleString()} ₫</span>
                  </div>
                </div>
              </div>

              {/* Amount in Vietnamese Words */}
              <div className="p-3 bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-lg text-sky-900 dark:text-sky-200 font-medium">
                <strong>Số tiền viết bằng chữ: </strong>
                <em>{previewQuote.amountInWords}</em>
              </div>

              {/* Terms */}
              <div className="space-y-1 text-slate-600 dark:text-slate-400 text-[11px]">
                <p><strong>Điều khoản thanh toán: </strong>{previewQuote.paymentTerms}</p>
                <p><strong>Ghi chú: </strong>{previewQuote.notes}</p>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800 mt-4 shrink-0">
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-medium">Cập nhật trạng thái:</span>
                <select
                  value={previewQuote.status}
                  onChange={(e) => updateQuotationStatus(previewQuote.id, e.target.value as any)}
                  className="text-xs font-semibold px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="Nháp">Nháp</option>
                  <option value="Chờ duyệt">Chờ duyệt</option>
                  <option value="Chờ Sales duyệt thương mại">Chờ Sales duyệt thương mại</option>
                  <option value="Đã gửi">Đã gửi</option>
                  <option value="Chấp nhận">Chấp nhận</option>
                  <option value="Từ chối">Từ chối</option>
                  <option value="Hết hạn">Hết hạn</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                {previewQuote.status === 'Chờ Sales duyệt thương mại' && (
                  <>
                    <button
                      onClick={() => {
                        updateQuotationStatus(previewQuote.id, 'Đã gửi');
                        showToast(
                          'Duyệt thương mại thành công',
                          `Báo giá ${previewQuote.code} đã được Sales phê duyệt thương mại và chuyển sang "Đã gửi" khách hàng.`,
                          'success'
                        );
                      }}
                      className="px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-sm"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Duyệt Thương Mại &amp; Gửi Khách</span>
                    </button>
                    <button
                      onClick={() => {
                        updateQuotationStatus(previewQuote.id, 'Chờ duyệt');
                        setActiveModule('technical-quotations');
                        showToast(
                          'Trả lại Kỹ thuật',
                          `Đã gửi trả báo giá ${previewQuote.code} về Kỹ thuật yêu cầu bóc tách lại.`,
                          'warning'
                        );
                      }}
                      className="px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-200 font-bold text-xs flex items-center gap-1.5"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Trả Lại Kỹ Thuật</span>
                    </button>
                  </>
                )}

                {previewQuote.status === 'Chấp nhận' && (
                  <button
                    onClick={() => {
                      createOrderFromQuotation(previewQuote.id);
                      setPreviewQuote(null);
                      setActiveModule('sales-orders');
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 hover:bg-emerald-700 shadow-sm"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Tạo Đơn Hàng Ngay →</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Soạn Báo Giá Mới */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-3xl w-full shadow-2xl max-h-[92vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-sky-600" />
                Soạn Thảo Báo Giá Mới
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateQuotationSubmit} className="space-y-4 mt-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Khách Hàng *</label>
                  <select
                    value={formCustomerId}
                    onChange={(e) => handleCustomerChange(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    {customers.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.code} - {c.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Cơ Hội Bán Hàng (Nếu có)</label>
                  <select
                    value={formOpportunityId}
                    onChange={(e) => setFormOpportunityId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="">-- Không gắn cơ hội cụ thể --</option>
                    {opportunities
                      .filter((o) => !formCustomerId || o.customerId === formCustomerId)
                      .map((opp) => (
                        <option key={opp.id} value={opp.id}>
                          {opp.code} - {opp.title}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Tiêu Đề Báo Giá *</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              {/* Dòng Sản Phẩm */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 space-y-3 bg-slate-50 dark:bg-slate-800/40">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    Danh mục mặt hàng &amp; Tồn kho khả dụng:
                  </span>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-400 text-[11px]">Thêm nhanh từ kho:</span>
                    <select
                      onChange={(e) => {
                        if (e.target.value) handleAddItem(e.target.value);
                      }}
                      defaultValue=""
                      className="px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-[11px]"
                    >
                      <option value="" disabled>-- Chọn sản phẩm thêm vào --</option>
                      {INITIAL_WAREHOUSE_PRODUCTS.map((prod) => (
                        <option key={prod.id} value={prod.id}>
                          {prod.sku} - {prod.name} ({prod.sellingPrice.toLocaleString()} ₫)
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  {formItems.map((item) => (
                    <div
                      key={item.id}
                      className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 flex items-center justify-between gap-3 text-xs"
                    >
                      <div className="flex-1 min-w-0">
                        <span className="font-mono font-bold text-sky-600 block">{item.sku}</span>
                        <span className="font-bold text-slate-900 dark:text-white truncate block">
                          {item.productName}
                        </span>
                        <span className="text-[10px] text-emerald-600 font-semibold">
                          Tồn khả dụng kho: {item.availableStock} {item.unit}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="w-16">
                          <span className="text-[10px] text-slate-400 block">SL:</span>
                          <input
                            type="number"
                            min={1}
                            value={item.quantity}
                            onChange={(e) => handleUpdateItemQty(item.id, Number(e.target.value))}
                            className="w-full px-2 py-1 rounded border font-mono text-right"
                          />
                        </div>

                        <div className="w-28 text-right font-mono">
                          <span className="text-[10px] text-slate-400 block">Đơn giá:</span>
                          <span>{item.unitPrice.toLocaleString()} ₫</span>
                        </div>

                        <div className="w-16">
                          <span className="text-[10px] text-slate-400 block">CK (%):</span>
                          <input
                            type="number"
                            min={0}
                            max={100}
                            value={item.discountPercent}
                            onChange={(e) => handleUpdateItemDiscount(item.id, Number(e.target.value))}
                            className="w-full px-1.5 py-1 rounded border font-mono text-right"
                          />
                        </div>

                        <div className="w-28 text-right font-mono font-bold text-slate-900 dark:text-white">
                          <span className="text-[10px] text-slate-400 block font-normal">Thành tiền:</span>
                          <span>{item.total.toLocaleString()} ₫</span>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleRemoveItem(item.id)}
                          className="p-1 rounded text-slate-400 hover:text-rose-600"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Thuế & Chiết khấu Tổng */}
              <div className="grid grid-cols-3 gap-3 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border border-slate-200">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Thuế VAT (%)</label>
                  <select
                    value={formTaxRate}
                    onChange={(e) => setFormTaxRate(Number(e.target.value) as any)}
                    className="w-full px-2.5 py-1.5 rounded-lg border bg-white dark:bg-slate-800"
                  >
                    <option value={10}>10% (Chuẩn)</option>
                    <option value={8}>8% (Ưu đãi)</option>
                    <option value={5}>5%</option>
                    <option value={0}>0%</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Chiết Khấu Toàn Đơn (%)</label>
                  <input
                    type="number"
                    min={0}
                    max={50}
                    value={formDiscountTotal}
                    onChange={(e) => setFormDiscountTotal(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 rounded-lg border bg-white dark:bg-slate-800 font-mono"
                  />
                  {formDiscountTotal > 5 && (
                    <span className="text-[10px] text-amber-600 block mt-0.5 font-bold">
                      &gt; 5% cần Trưởng nhóm duyệt
                    </span>
                  )}
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Hạn Hiệu Lực Báo Giá</label>
                  <input
                    type="date"
                    required
                    value={formValidUntil}
                    onChange={(e) => setFormValidUntil(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg border bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              {/* Tự tính tổng */}
              <div className="p-3 bg-slate-100 dark:bg-slate-800 rounded-xl space-y-1 font-mono text-xs">
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Tiền hàng:</span>
                  <span>{formSubTotal.toLocaleString()} ₫</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Tiền thuế VAT ({formTaxRate}%):</span>
                  <span>{formTaxAmt.toLocaleString()} ₫</span>
                </div>
                <div className="flex justify-between font-bold text-sm text-sky-600 pt-1 border-t border-slate-200">
                  <span>TỔNG THANH TOÁN:</span>
                  <span>{formGrandTotal.toLocaleString()} ₫</span>
                </div>
                <div className="text-[11px] text-slate-500 font-sans italic pt-1">
                  Bằng chữ: {numberToVietnameseWords(formGrandTotal)}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-sky-600 text-white font-bold"
                >
                  Tạo Bản Báo Giá
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
