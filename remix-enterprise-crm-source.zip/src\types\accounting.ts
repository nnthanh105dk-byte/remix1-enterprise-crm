import { DocumentChainInfo } from './sales';

// ==========================================
// 1. CÔNG NỢ & TUỔI NỢ (DEBT & AGING)
// ==========================================

export type DebtRiskStatus = 'Bình thường' | 'Cần nhắc' | 'Rủi ro cao';

export interface AgingBucket {
  current: number; // Chưa đến hạn
  days1_30: number; // Quá hạn 1 - 30 ngày
  days31_60: number; // Quá hạn 31 - 60 ngày
  days61_90: number; // Quá hạn 61 - 90 ngày
  over90: number; // Quá hạn > 90 ngày
}

export interface CustomerDebtSummary {
  customerId: string;
  customerCode: string;
  customerName: string;
  taxId: string;
  phone: string;
  email: string;
  assignedSalesStaff: string;
  salesDepartment: string;
  region: string;
  group: 'Thường' | 'VIP' | 'Tiềm năng';
  creditLimit: number; // Hạn mức công nợ tối đa (VND)
  creditTermDays: number; // Số ngày cho phép nợ (ví dụ 30 ngày)
  openingBalance: number; // Số dư nợ đầu kỳ
  periodIncurred: number; // Phát sinh nợ trong kỳ (doanh số xuất hóa đơn)
  periodPaid: number; // Đã thu trong kỳ
  closingDebt: number; // Nợ còn lại cuối kỳ = opening + incurred - paid
  overdueDebt: number; // Nợ quá hạn
  aging: AgingBucket;
  lastPaymentDate?: string;
  riskStatus: DebtRiskStatus;
  note?: string;
  blockNewOrdersOnOverdue: boolean; // Chặn tạo đơn mới nếu vượt hạn mức/quá hạn
}

export interface SupplierDebtSummary {
  supplierId: string;
  supplierCode: string;
  supplierName: string;
  taxId: string;
  phone: string;
  costCategory: 'Hàng hóa thiết bị' | 'Cước vận chuyển' | 'Dịch vụ kỹ thuật thầu phụ' | 'Vật tư tiêu hao' | 'Khác';
  creditTermDays: number;
  openingBalance: number;
  periodIncurred: number; // Mua hàng/chi phí phát sinh trong kỳ
  periodPaid: number; // Đã thanh toán
  closingDebt: number; // Còn phải trả
  overdueDebt: number; // Quá hạn phải trả
  nextDueDate?: string;
  bankAccount?: string;
  bankName?: string;
  status: 'Chờ thanh toán' | 'Đã duyệt chi' | 'Quá hạn';
}

export type DebtLedgerDocType = 
  | 'Hóa đơn bán hàng' 
  | 'Phiếu thu' 
  | 'Hóa đơn mua hàng' 
  | 'Đề nghị thanh toán' 
  | 'Phiếu chi' 
  | 'Chứng từ điều chỉnh tăng' 
  | 'Chứng từ điều chỉnh giảm';

export interface DebtLedgerEntry {
  id: string;
  date: string;
  docType: DebtLedgerDocType;
  docCode: string; // HDON-..., PT-..., HDM-..., DNTT-..., PC-..., DC-..
  description: string;
  increaseAmount: number; // Phát sinh nợ (Tăng)
  decreaseAmount: number; // Giảm nợ / Đã thu/chi (Giảm)
  runningBalance: number; // Dư nợ lũy kế
  dueDate?: string;
  status?: string;
  referenceDocId?: string;
  attachmentUrl?: string;
}

export interface DebtAdjustmentRecord {
  id: string;
  code: string; // DC-2026-xxxx
  date: string;
  partnerType: 'customer' | 'supplier';
  partnerId: string;
  partnerName: string;
  direction: 'increase' | 'decrease'; // Tăng hoặc giảm nợ
  amount: number;
  reason: string; // Chiết khấu thương mại bổ sung, Giảm trừ hàng lỗi, Phạt vi phạm hợp đồng, Xóa nợ khó đòi...
  approvedBy: string;
  attachmentFileName?: string;
  createdAt: string;
}

export interface DebtReminderLog {
  id: string;
  customerId: string;
  customerName: string;
  channel: 'Email' | 'SMS' | 'Zalo';
  recipientContact: string;
  sentAt: string;
  sentBy: string;
  debtAmount: number;
  overdueDays: number;
  contentPreview: string;
  hasAttachmentStatement: boolean;
  status: 'Đã gửi' | 'Đã xem' | 'Phản hồi';
}

// ==========================================
// 2. HÓA ĐƠN & BÁO GIÁ (INVOICES & QUOTES)
// ==========================================

export type EInvoiceStatus = 
  | 'Chưa phát hành' 
  | 'Đã phát hành' 
  | 'Đã hủy' 
  | 'Bị thay thế';

export interface EInvoiceDetails {
  eInvoiceNumber?: string; // Số hóa đơn điện tử (ví dụ: 0000452)
  eInvoiceSymbol?: string; // Ký hiệu (ví dụ: 1C26TBB)
  issueDate?: string;
  taxAuthorityCode?: string; // Mã của CQT cấp nếu có
  xmlUrl?: string;
  pdfUrl?: string;
  provider: 'MISA meInvoice' | 'VNPT Einvoice' | 'Viettel Sinvoice' | 'Bkav eHoadon' | 'Khác';
  digitalSignatureSubject?: string; // Tên đơn vị ký số
}

export interface AccountingQuotationReview {
  id: string;
  quotationId: string;
  quotationCode: string; // BG-2026-xxxx
  date: string;
  customerId: string;
  customerName: string;
  createdByStaff: string;
  department: string;
  totalValue: number;
  estimatedCost: number; // Giá vốn dự kiến
  estimatedGrossMargin: number; // Lợi nhuận gộp
  marginPercentage: number; // % Biên LN gộp
  discountPercentage: number; // % Chiết khấu
  paymentTerms: string; // Điều khoản thanh toán đề xuất
  debtTermDays: number; // Số ngày công nợ
  financialStatus: 'Đạt tiêu chuẩn' | 'Cần duyệt ngoại lệ' | 'Đã duyệt' | 'Từ chối';
  reviewNotes?: string;
  riskWarnings: string[];
  reviewedBy?: string;
  reviewedAt?: string;
}

// ==========================================
// 3. GIAO DỊCH & DÒNG TIỀN (CASH FLOW & PETTY CASH)
// ==========================================

export type CashTransactionType = 'Thu' | 'Chi';

export type CashCategoryType = 
  // Thu
  | 'Thu tiền hàng từ khách'
  | 'Thu tiền dịch vụ / bảo trì'
  | 'Thu hoàn ứng'
  | 'Thu lãi tiền gửi'
  | 'Thu khác'
  // Chi
  | 'Chi trả nhà cung cấp hàng hóa'
  | 'Chi cước vận chuyển logistics'
  | 'Chi phí thầu phụ kỹ thuật'
  | 'Chi lương & bảo hiểm nhân sự'
  | 'Chi tạm ứng công tác'
  | 'Chi thuê văn phòng & tiện ích'
  | 'Chi tiếp khách & công tác phí'
  | 'Chi nộp thuế & lệ phí'
  | 'Chi khác';

export type PaymentChannel = 
  | 'Tiền mặt tại quỹ' 
  | 'Vietcombank (0011004321999)' 
  | 'Techcombank (19033321456011)' 
  | 'MB Bank (0888666999)';

export interface CashTransaction {
  id: string;
  code: string; // PT-2026-xxxx hoặc PC-2026-xxxx
  type: CashTransactionType;
  date: string;
  category: CashCategoryType;
  partnerType: 'Khách hàng' | 'Nhà cung cấp' | 'Nhân viên' | 'Nội bộ / Khác';
  partnerId?: string;
  partnerName: string;
  amount: number;
  amountInWords: string;
  channel: PaymentChannel;
  bankRefNumber?: string; // Mã giao dịch ngân hàng
  reason: string;
  creatorName: string;
  approverName?: string;
  cashierName?: string;
  status: 'Đã thực hiện' | 'Chờ duyệt chi' | 'Đã hủy';
  referenceDocType?: 'Hóa đơn bán hàng' | 'Hóa đơn mua hàng' | 'Đề nghị thanh toán' | 'Bảng lương BHXH';
  referenceDocCode?: string;
  attachmentFileName?: string;
  createdAt: string;
}

export interface BankAccountBalance {
  id: string;
  accountNumber: string;
  bankName: string;
  branch: string;
  accountHolder: string;
  currentBalance: number;
  bookBalance: number; // Số dư trên sổ sách
  lastReconciledDate: string;
  unreconciledDifference: number; // Chênh lệch chưa đối soát
}

export interface CashForecastPeriod {
  periodLabel: string; // "Tuần 1", "Tuần 2", "Tháng 04/2026"
  startDate: string;
  endDate: string;
  openingCash: number;
  forecastInflow: number; // Dự kiến thu (phải thu đến hạn + đơn hàng sắp xuất)
  forecastOutflow: number; // Dự kiến chi (phải trả NCC + lương BHXH + chi thường xuyên)
  netCashFlow: number; // Thu - Chi
  closingCash: number; // Số dư dự kiến
  isDeficitWarning: boolean; // Cảnh báo thiếu hụt dòng tiền
  details: {
    receivableDue: number;
    expectedSalesCollection: number;
    supplierPayableDue: number;
    salaryAndInsuranceDue: number;
    overheadExpenseDue: number;
  };
}

// ==========================================
// 4. BÁO CÁO TÀI CHÍNH QUẢN TRỊ (MANAGEMENT P&L & ANALYSIS)
// ==========================================

export interface ProfitAndLossStatement {
  period: string; // "Tháng 03/2026" | "Quý 1/2026" | "Năm 2026"
  // 1. Doanh thu
  grossRevenue: number; // Tổng doanh thu bán hàng & dịch vụ
  revenueDeductions: number; // Giảm trừ doanh thu (chiết khấu, hàng trả)
  netRevenue: number; // Doanh thu thuần = gross - deductions
  
  // 2. Giá vốn
  cogs: number; // Giá vốn hàng bán (Cost of Goods Sold)
  grossProfit: number; // Lợi nhuận gộp = netRevenue - cogs
  grossMarginPercentage: number; // Tỷ suất lợi nhuận gộp (%)
  
  // 3. Chi phí hoạt động
  sellingExpenses: number; // Chi phí bán hàng (hoa hồng, logistics cước xe, tiếp thị)
  adminExpenses: number; // Chi phí quản lý (lương & BHXH nhân viên từ HR, thuê vp, điện nước, khấu hao)
  totalOperatingExpenses: number;
  
  // 4. Lợi nhuận kinh doanh
  operatingProfit: number; // EBIT = grossProfit - totalOperatingExpenses
  operatingMarginPercentage: number;
  
  // 5. Tài chính & Khác
  financialIncome: number; // Lãi tiền gửi
  financialExpenses: number; // Phí ngân hàng, lãi vay
  otherProfit: number; // Thu nhập khác ròng
  
  // 6. Lợi nhuận trước thuế quản trị
  netProfitBeforeTax: number;
  netMarginPercentage: number;
  
  // So sánh cùng kỳ
  previousPeriodComparison?: {
    netRevenueChangePct: number;
    grossProfitChangePct: number;
    operatingProfitChangePct: number;
    netProfitChangePct: number;
  };
}

export interface RevenueProfitByDimension {
  id: string;
  dimensionName: string; // Tên dòng sản phẩm / Nhân viên Sales / Khu vực
  revenue: number;
  cogs: number;
  grossProfit: number;
  grossMarginPct: number;
  ordersCount: number;
}
