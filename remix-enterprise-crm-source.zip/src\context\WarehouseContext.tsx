import React, { createContext, useContext, useState } from 'react';
import {
  Warehouse,
  WarehouseProduct,
  ProductLot,
  StockInReceipt,
  StockOutReceipt,
  StockMove,
  StockSnapshotDaily,
  INITIAL_WAREHOUSES,
  INITIAL_WAREHOUSE_PRODUCTS,
  INITIAL_PRODUCT_LOTS,
  INITIAL_STOCK_IN_RECEIPTS,
  INITIAL_STOCK_OUT_RECEIPTS,
  INITIAL_STOCK_MOVES,
} from '../data/mockWarehouseData';
import { useCRM } from './CRMContext';

interface WarehouseContextType {
  warehouses: Warehouse[];
  products: WarehouseProduct[];
  lots: ProductLot[];
  stockInReceipts: StockInReceipt[];
  stockOutReceipts: StockOutReceipt[];
  stockMoves: StockMove[];
  createStockInReceipt: (receipt: Omit<StockInReceipt, 'id' | 'receiptNumber' | 'status'>) => void;
  approveStockInReceipt: (receiptId: string) => void;
  cancelStockInReceipt: (receiptId: string) => void;
  createStockOutReceipt: (receipt: Omit<StockOutReceipt, 'id' | 'receiptNumber' | 'status'>) => void;
  approveStockOutReceipt: (receiptId: string) => void;
  cancelStockOutReceipt: (receiptId: string) => void;
  quickReassignLotAction: (lotId: string, actionType: 'sell' | 'discount' | 'return' | 'waste') => void;
}

const WarehouseContext = createContext<WarehouseContextType | undefined>(undefined);

export const WarehouseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { showToast } = useCRM();

  const [warehouses] = useState<Warehouse[]>(INITIAL_WAREHOUSES);
  const [products, setProducts] = useState<WarehouseProduct[]>(INITIAL_WAREHOUSE_PRODUCTS);
  const [lots, setLots] = useState<ProductLot[]>(INITIAL_PRODUCT_LOTS);
  const [stockInReceipts, setStockInReceipts] = useState<StockInReceipt[]>(INITIAL_STOCK_IN_RECEIPTS);
  const [stockOutReceipts, setStockOutReceipts] = useState<StockOutReceipt[]>(INITIAL_STOCK_OUT_RECEIPTS);
  const [stockMoves, setStockMoves] = useState<StockMove[]>(INITIAL_STOCK_MOVES);

  // Tạo phiếu nhập kho mới
  const createStockInReceipt = (data: Omit<StockInReceipt, 'id' | 'receiptNumber' | 'status'>) => {
    const id = `pnk-${Date.now()}`;
    const receiptNumber = `PNK-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newReceipt: StockInReceipt = {
      ...data,
      id,
      receiptNumber,
      status: 'Chờ duyệt',
    };
    setStockInReceipts((prev) => [newReceipt, ...prev]);
    showToast('Tạo phiếu nhập thành công', `Phiếu ${receiptNumber} đã được lập và chuyển trạng thái Chờ duyệt.`);
  };

  // Duyệt phiếu nhập kho -> TỰ ĐỘNG CỘNG TỒN & GHI SỔ BIẾN ĐỘNG KHO
  const approveStockInReceipt = (receiptId: string) => {
    const receipt = stockInReceipts.find((r) => r.id === receiptId);
    if (!receipt || receipt.status !== 'Chờ duyệt') return;

    const approvedAt = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const dateStr = receipt.date || new Date().toISOString().split('T')[0];

    // 1. Cập nhật tồn kho các sản phẩm
    setProducts((prevProducts) =>
      prevProducts.map((p) => {
        const item = receipt.items.find((it) => it.sku === p.sku);
        if (!item) return p;
        const currentWhStock = p.stocks[receipt.warehouseId] || 0;
        const newWhStock = currentWhStock + item.quantity;
        return {
          ...p,
          stocks: {
            ...p.stocks,
            [receipt.warehouseId]: newWhStock,
          },
        };
      })
    );

    // 2. Cập nhật hoặc thêm Lô hàng
    receipt.items.forEach((item) => {
      const lotNum = item.lotNumber;
      if (lotNum) {
        setLots((prevLots) => {
          const existingLot = prevLots.find((l) => l.lotNumber === lotNum && l.warehouseId === receipt.warehouseId);
          if (existingLot) {
            return prevLots.map((l) =>
              l.id === existingLot.id ? { ...l, quantity: l.quantity + item.quantity } : l
            );
          }
          const newLot: ProductLot = {
            id: `lot-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            lotNumber: lotNum,
            sku: item.sku,
            productName: item.productName,
            warehouseId: receipt.warehouseId,
            warehouseName: receipt.warehouseName,
            quantity: item.quantity,
            initialQuantity: item.quantity,
            manufactureDate: item.mfgDate || '2026-09-01',
            expiryDate: item.expDate || '2027-09-01',
            unitCost: item.unitPrice,
          };
          return [newLot, ...prevLots];
        });
      }
    });

    // 3. Ghi vào Sổ biến động kho (StockMove)
    const newMoves: StockMove[] = receipt.items.map((item, idx) => {
      const prod = products.find((p) => p.sku === item.sku);
      const currentWhStock = prod?.stocks[receipt.warehouseId] || 0;
      return {
        id: `mv-${Date.now()}-${idx}`,
        timestamp: approvedAt,
        date: dateStr,
        type: 'Nhập mua',
        refCode: receipt.receiptNumber,
        sku: item.sku,
        productName: item.productName,
        lotNumber: item.lotNumber,
        warehouseId: receipt.warehouseId,
        warehouseName: receipt.warehouseName,
        quantity: item.quantity,
        balanceAfter: currentWhStock + item.quantity,
        unitPrice: item.unitPrice,
        performedBy: receipt.createdBy,
        notes: `Nhập kho từ ${receipt.supplierName} theo ${receipt.receiptNumber}`,
      };
    });

    setStockMoves((prev) => [...newMoves, ...prev]);

    // 4. Cập nhật trạng thái phiếu nhập thành "Đã nhập kho"
    setStockInReceipts((prev) =>
      prev.map((r) =>
        r.id === receiptId
          ? {
              ...r,
              status: 'Đã nhập kho',
              approvedBy: 'Trần Văn Giám Đốc Kho',
              approvedAt,
            }
          : r
      )
    );

    showToast(
      'Nhập kho thành công',
      `Phiếu ${receipt.receiptNumber} đã được phê duyệt. Tồn kho và sổ biến động đã được cập nhật nhất quán.`,
      'success'
    );
  };

  const cancelStockInReceipt = (receiptId: string) => {
    setStockInReceipts((prev) =>
      prev.map((r) => (r.id === receiptId ? { ...r, status: 'Đã hủy' } : r))
    );
    showToast('Đã hủy phiếu', 'Phiếu nhập kho đã được chuyển sang trạng thái Đã hủy.', 'warning');
  };

  // Tạo phiếu xuất kho mới
  const createStockOutReceipt = (data: Omit<StockOutReceipt, 'id' | 'receiptNumber' | 'status'>) => {
    const id = `pxk-${Date.now()}`;
    const receiptNumber = `PXK-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newReceipt: StockOutReceipt = {
      ...data,
      id,
      receiptNumber,
      status: 'Chờ duyệt',
    };
    setStockOutReceipts((prev) => [newReceipt, ...prev]);
    showToast('Tạo phiếu xuất thành công', `Phiếu ${receiptNumber} đã được lập và chuyển trạng thái Chờ duyệt.`);
  };

  // Duyệt phiếu xuất kho -> TỰ ĐỘNG TRỪ TỒN & GHI SỔ BIẾN ĐỘNG KHO
  const approveStockOutReceipt = (receiptId: string) => {
    const receipt = stockOutReceipts.find((r) => r.id === receiptId);
    if (!receipt || (receipt.status !== 'Chờ duyệt' && receipt.status !== 'Đang soạn hàng')) return;

    const approvedAt = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const dateStr = receipt.date || new Date().toISOString().split('T')[0];

    // 1. Trừ tồn kho
    setProducts((prevProducts) =>
      prevProducts.map((p) => {
        const item = receipt.items.find((it) => it.sku === p.sku);
        if (!item) return p;
        const currentWhStock = p.stocks[receipt.warehouseId] || 0;
        const newWhStock = Math.max(0, currentWhStock - item.quantity);
        return {
          ...p,
          stocks: {
            ...p.stocks,
            [receipt.warehouseId]: newWhStock,
          },
        };
      })
    );

    // 2. Trừ tồn Lô hàng nếu có
    receipt.items.forEach((item) => {
      if (item.lotNumber) {
        setLots((prevLots) =>
          prevLots.map((l) =>
            l.lotNumber === item.lotNumber && l.warehouseId === receipt.warehouseId
              ? { ...l, quantity: Math.max(0, l.quantity - item.quantity) }
              : l
          )
        );
      }
    });

    // 3. Ghi vào Sổ biến động kho (StockMove)
    const newMoves: StockMove[] = receipt.items.map((item, idx) => {
      const prod = products.find((p) => p.sku === item.sku);
      const currentWhStock = prod?.stocks[receipt.warehouseId] || 0;
      return {
        id: `mv-out-${Date.now()}-${idx}`,
        timestamp: approvedAt,
        date: dateStr,
        type: receipt.exportReason === 'Xuất hủy' ? 'Xuất hủy' : 'Xuất bán',
        refCode: receipt.receiptNumber,
        sku: item.sku,
        productName: item.productName,
        lotNumber: item.lotNumber,
        warehouseId: receipt.warehouseId,
        warehouseName: receipt.warehouseName,
        quantity: -item.quantity,
        balanceAfter: Math.max(0, currentWhStock - item.quantity),
        unitPrice: item.unitPrice,
        performedBy: receipt.createdBy,
        notes: `Xuất kho: ${receipt.exportReason} theo phiếu ${receipt.receiptNumber}`,
        isAbnormal: receipt.exportReason === 'Xuất hủy',
        abnormalReason: receipt.exportReason === 'Xuất hủy' ? receipt.wasteApprovalReason || 'Xuất hủy hàng hỏng/hết hạn' : undefined,
      };
    });

    setStockMoves((prev) => [...newMoves, ...prev]);

    // 4. Đổi trạng thái phiếu xuất thành "Đã xuất kho"
    setStockOutReceipts((prev) =>
      prev.map((r) =>
        r.id === receiptId
          ? {
              ...r,
              status: 'Đã xuất kho',
              approvedBy: 'Trần Văn Giám Đốc Kho',
              approvedAt,
            }
          : r
      )
    );

    showToast(
      'Xuất kho hoàn tất',
      `Phiếu ${receipt.receiptNumber} đã được phê duyệt. Tồn kho và sổ biến động đã được cập nhật chính xác.`,
      'success'
    );
  };

  const cancelStockOutReceipt = (receiptId: string) => {
    setStockOutReceipts((prev) =>
      prev.map((r) => (r.id === receiptId ? { ...r, status: 'Đã hủy' } : r))
    );
    showToast('Đã hủy phiếu', 'Phiếu xuất kho đã được chuyển sang trạng thái Đã hủy.', 'warning');
  };

  // Hành động đề xuất nhanh cho hàng sắp hết hạn
  const quickReassignLotAction = (lotId: string, actionType: 'sell' | 'discount' | 'return' | 'waste') => {
    const lot = lots.find((l) => l.id === lotId);
    if (!lot) return;

    const actionNames = {
      sell: 'Ưu tiên xuất bán',
      discount: 'Tạo chương trình giảm giá',
      return: 'Trả nhà cung cấp',
      waste: 'Xuất hủy hàng quá hạn',
    };

    showToast(
      'Đã kích hoạt hành động',
      `Đã khởi tạo quy trình "${actionNames[actionType]}" cho lô ${lot.lotNumber} (${lot.productName}).`,
      'info'
    );
  };

  return (
    <WarehouseContext.Provider
      value={{
        warehouses,
        products,
        lots,
        stockInReceipts,
        stockOutReceipts,
        stockMoves,
        createStockInReceipt,
        approveStockInReceipt,
        cancelStockInReceipt,
        createStockOutReceipt,
        approveStockOutReceipt,
        cancelStockOutReceipt,
        quickReassignLotAction,
      }}
    >
      {children}
    </WarehouseContext.Provider>
  );
};

export const useWarehouse = (): WarehouseContextType => {
  const ctx = useContext(WarehouseContext);
  if (!ctx) {
    throw new Error('useWarehouse must be used within a WarehouseProvider');
  }
  return ctx;
};
