import React from 'react';

export interface SectionTitleProps {
  children: React.ReactNode;
  icon?: React.ComponentType<{ className?: string }>;
  className?: string;
  badge?: React.ReactNode;
  level?: 'h2' | 'h3' | 'h4';
}

/**
 * SectionTitle Component
 * Mang phong cách tiêu đề nổi bật Executive:
 * - Đường viền dọc màu xanh cyan tạo điểm nhấn mạnh mẽ bên trái.
 * - Nền màu xanh nhạt phớt gradient lan dần sang trong suốt.
 * - Font chữ to hơn (~17-18px), nét chữ in đậm rõ ràng, tương phản cao.
 */
export const SectionTitle: React.FC<SectionTitleProps> = ({
  children,
  icon: Icon,
  className = '',
  badge,
  level = 'h2',
}) => {
  const content = (
    <>
      {Icon && <Icon className="w-4.5 h-4.5 text-[#0284c7] dark:text-sky-400 shrink-0" />}
      <span className="text-[17.5px] sm:text-[18.5px] font-bold text-slate-900 dark:text-white tracking-tight leading-snug">
        {children}
      </span>
      {badge}
    </>
  );

  const containerClasses = `section-title ${className}`;

  if (level === 'h3') {
    return <h3 className={containerClasses}>{content}</h3>;
  }
  if (level === 'h4') {
    return <h4 className={containerClasses}>{content}</h4>;
  }
  return <h2 className={containerClasses}>{content}</h2>;
};
