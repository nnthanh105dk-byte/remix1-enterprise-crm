import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import { CodCollection } from '../../types/logistics';
import {
  Banknote,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Printer,
  Calendar,
  User,
  Building,
  CheckSquare,
  Square,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';

export const LogisticsCodCollectionsView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { codCollections, remitCodCollections, drivers } = useLogistics();

  // Tab: 'unremitted' (Tiền chưa nộp) | 'all' (Tất cả phiếu)
  const [activeTab, setActiveTab] = useState<'unremitted' | 'all'>('unremitted');
  const [searchTerm, setSearchTerm] = useState('');
  const [driverFilter, setDriverFilter] = useState('all');

  // Selected collection IDs for bulk remit
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [remitStaffName, setRemitStaffName] = useState('Nguyễn Thị Bích Ngọc (Kế toán quỹ)');

  // Helper check if unremitted > 2 days
  const isOverdueRemit = (dateStr: string): boolean => {
    const dTime = new Date(dateStr).getTime();
    if (isNaN(dTime)) return false;
    const diffDays = Math.round((Date.now() - dTime) / (1000 * 60 * 60 * 24));
    return diffDays >= 2;
  };

  const unremittedList = codCollections.filter(
    (c) => c.status === 'Đã thu - chờ nộp' || c.status === 'Có chênh lệch'
  );

  const filteredList = (activeTab === 'unremitted' ? unremittedList : codCollections).filter((c) => {
    if (driverFilter !== 'all' && c.driverName !== driverFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        c.code.toLowerCase().includes(q) ||
        c.customerName.toLowerCase().includes(q) ||
        c.deliveryNoteCode.toLowerCase().includes(q) ||
        c.driverName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const totalUnremittedAmount = unremittedList.reduce((sum, c) => sum + c.amountCollected, 0);

  const handleSelectAll = () => {
    if (selectedIds.length === filteredList.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredList.map((c) => c.id));
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleConfirmRemitSelected = () => {
    if (selectedIds.length === 0) {
      showToast('Lỗi', 'Vui lòng chọn ít nhất 1 phiếu thu hộ để xác nhận nộp về công ty.', 'warning');
      return;
    }
    remitCodCollections(selectedIds, remitStaffName);
    setSelectedIds([]);
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
              <Banknote className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Quản Lý Thu Hộ (COD Collections)
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Theo dõi tiền mặt / chuyển khoản tài xế thu hộ khi giao hàng. Xác nhận nộp quỹ để tự động sinh Phiếu thu khấu trừ công nợ.
          </p>
        </div>

        <button
          onClick={() => setActiveModule('sales-receipts')}
          className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors"
        >
          <span>Xem Phiếu thu Sales</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Tổng tiền COD tài xế đang giữ</span>
          <p className="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-1">
            {totalUnremittedAmount.toLocaleString()} đ
          </p>
          <p className="text-[11px] text-slate-400 mt-1">{unremittedList.length} phiếu chưa nộp về công ty</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Cảnh báo quá 2 ngày chưa nộp</span>
          <p className="text-2xl font-bold text-rose-600 dark:text-rose-400 mt-1">
            {unremittedList.filter((c) => isOverdueRemit(c.date)).length} phiếu
          </p>
          <p className="text-[11px] text-rose-500 mt-1">Cần giục tài xế nộp quỹ ngay</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Đã nộp về công ty</span>
          <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {codCollections.filter((c) => c.status === 'Đã nộp về công ty').length} phiếu
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Đã đồng bộ sang Quản lý Sales</p>
        </div>
      </div>

      {/* Tabs & Bulk Action */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b pb-3">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('unremitted')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeTab === 'unremitted'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Tiền Chưa Nộp ({unremittedList.length})
            </button>
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                activeTab === 'all'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Tất Cả Phiếu Thu Hộ ({codCollections.length})
            </button>
          </div>

          {activeTab === 'unremitted' && selectedIds.length > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">Đã chọn {selectedIds.length} phiếu</span>
              <button
                onClick={handleConfirmRemitSelected}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 shadow-xs"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Xác Nhận Đã Nộp Về Quỹ</span>
              </button>
            </div>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm theo số phiếu (TH-2026-xxxx), khách hàng, tài xế..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border bg-slate-50 dark:bg-slate-800"
            />
          </div>

          <select
            value={driverFilter}
            onChange={(e) => setDriverFilter(e.target.value)}
            className="text-xs px-3 py-1.5 rounded-lg border bg-white dark:bg-slate-800"
          >
            <option value="all">Tất cả tài xế</option>
            {drivers.map((d) => (
              <option key={d.id} value={d.fullName}>
                {d.fullName}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800 text-[11px] text-slate-500 uppercase font-semibold">
                {activeTab === 'unremitted' && (
                  <th className="py-3 px-4 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={selectedIds.length === filteredList.length && filteredList.length > 0}
                      onChange={handleSelectAll}
                    />
                  </th>
                )}
                <th className="py-3 px-4">Số phiếu &amp; Ngày thu</th>
                <th className="py-3 px-4">Khách hàng</th>
                <th className="py-3 px-4">Phiếu giao &amp; Đơn hàng</th>
                <th className="py-3 px-4">Tài xế thu tiền</th>
                <th className="py-3 px-4 text-right">Số tiền thu hộ</th>
                <th className="py-3 px-4 text-center">Hình thức</th>
                <th className="py-3 px-4 text-center">Trạng thái nộp</th>
                <th className="py-3 px-4 text-center">Phiếu thu Sales</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-10 text-center text-slate-400">
                    Không có phiếu thu hộ nào.
                  </td>
                </tr>
              ) : (
                filteredList.map((cod) => {
                  const isOverdue = isOverdueRemit(cod.date) && cod.status === 'Đã thu - chờ nộp';

                  return (
                    <tr
                      key={cod.id}
                      className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 ${
                        isOverdue ? 'bg-rose-50/40 dark:bg-rose-950/20' : ''
                      }`}
                    >
                      {activeTab === 'unremitted' && (
                        <td className="py-3 px-4 text-center">
                          <input
                            type="checkbox"
                            checked={selectedIds.includes(cod.id)}
                            onChange={() => handleToggleSelect(cod.id)}
                          />
                        </td>
                      )}
                      <td className="py-3 px-4 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {cod.code}
                        <div className="text-[10px] text-slate-400 font-sans font-normal">{cod.date}</div>
                      </td>
                      <td className="py-3 px-4 font-semibold text-slate-800 dark:text-slate-200">
                        {cod.customerName}
                      </td>
                      <td className="py-3 px-4 font-mono text-indigo-600">
                        {cod.deliveryNoteCode}
                        {cod.orderCode && (
                          <div className="text-[10px] text-slate-400">{cod.orderCode}</div>
                        )}
                      </td>
                      <td className="py-3 px-4 font-medium">{cod.driverName}</td>
                      <td className="py-3 px-4 text-right font-bold text-slate-900 dark:text-white">
                        {cod.amountCollected.toLocaleString()} đ
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 text-slate-700">
                          {cod.paymentMethod}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            cod.status === 'Đã nộp về công ty'
                              ? 'bg-emerald-100 text-emerald-800'
                              : isOverdue
                              ? 'bg-rose-100 text-rose-800 animate-pulse font-bold'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {cod.status}
                          {isOverdue && ' (Quá 2 ngày!)'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-sky-600">
                        {cod.salesReceiptNumber || <span className="text-slate-300 font-normal italic">Chờ nộp</span>}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
