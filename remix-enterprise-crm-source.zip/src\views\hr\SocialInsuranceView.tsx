import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useHR } from '../../context/HRContext';
import {
  InsuranceParticipant,
  InsuranceChangeRecord,
  InsuranceMonthlyPeriod,
  InsuranceClaimRecord,
} from '../../types/hr';
import { APlusLogo } from '../../components/common/APlusLogo';
import { numberToVietnameseWords } from '../../utils/vietnameseNumberWords';
import {
  ShieldCheck,
  Search,
  Filter,
  Download,
  Plus,
  AlertTriangle,
  Clock,
  Calendar,
  CheckCircle2,
  FileSpreadsheet,
  XCircle,
  Lock,
  Unlock,
  Printer,
  Eye,
  EyeOff,
  Sliders,
  DollarSign,
  HeartPulse,
  RefreshCw,
  Send,
  FileCheck,
  Info,
  Check,
  X,
  Building,
  User,
} from 'lucide-react';

export const SocialInsuranceView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    employees,
    insuranceParticipants,
    insuranceChanges,
    monthlyPeriods,
    insuranceClaims,
    insuranceConfigs,
    activeConfig,
    addInsuranceChange,
    confirmInsuranceChange,
    batchConfirmInsuranceChanges,
    submitInsuranceChangeToAgency,
    approveInsuranceChange,
    rejectInsuranceChange,
    generateMonthlyPeriod,
    lockMonthlyPeriod,
    unlockMonthlyPeriod,
    recordPeriodPayment,
    addInsuranceClaim,
    updateClaimStatus,
    addInsuranceConfig,
    maskSensitive,
    logSensitiveAccess,
  } = useHR();

  // Tabs: 6 tabs as requested
  const [activeTab, setActiveTab] = useState<'overview' | 'participants' | 'changes' | 'periods' | 'claims' | 'config'>('overview');

  // Unmask state
  const [unmaskedRows, setUnmaskedRows] = useState<Record<string, boolean>>({});

  const toggleUnmaskNumber = (id: string, empName: string) => {
    const isCurrentlyUnmasked = !!unmaskedRows[id];
    if (!isCurrentlyUnmasked) {
      logSensitiveAccess('VIEW_UNMASKED', empName, ['Mã số BHXH'], 'Xem đầy đủ mã số BHXH');
    }
    setUnmaskedRows((prev) => ({ ...prev, [id]: !isCurrentlyUnmasked }));
  };

  // Search & Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // Batch Selection for Changes Tab
  const [selectedChangeIds, setSelectedChangeIds] = useState<string[]>([]);

  // Selected Monthly Period for Detail Drawer / Print Modal
  const [selectedPeriod, setSelectedPeriod] = useState<InsuranceMonthlyPeriod | null>(monthlyPeriods[0] || null);
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Modal Submit to BHXH Agency
  const [submitModalTarget, setSubmitModalTarget] = useState<InsuranceChangeRecord | null>(null);
  const [submissionCodeInput, setSubmissionCodeInput] = useState('HS-BHXH-2026-');

  // Modal Record Payment
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentRefInput, setPaymentRefInput] = useState('UNC-VCB-');
  const [paymentAmountInput, setPaymentAmountInput] = useState(0);

  // Modal Unlock Period
  const [isUnlockModalOpen, setIsUnlockModalOpen] = useState(false);
  const [unlockReasonInput, setUnlockReasonInput] = useState('Bổ sung hồ sơ báo giảm nhân viên tháng trước bị sót');

  // Modal New Claim
  const [isNewClaimModalOpen, setIsNewClaimModalOpen] = useState(false);
  const [claimEmployeeId, setClaimEmployeeId] = useState(employees[0]?.id || '');
  const [claimType, setClaimType] = useState<InsuranceClaimRecord['type']>('Ốm đau');
  const [claimStartDate, setClaimStartDate] = useState(new Date().toISOString().split('T')[0]);
  const [claimEndDate, setClaimEndDate] = useState(new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  const [claimDays, setClaimDays] = useState(3);
  const [claimExpectedAmount, setClaimExpectedAmount] = useState(1500000);
  const [claimNotes, setClaimNotes] = useState('Điều trị nội trú tại bệnh viện đa khoa');

  // Modal Manual Insurance Change
  const [isManualChangeModalOpen, setIsManualChangeModalOpen] = useState(false);
  const [manualChangeForm, setManualChangeForm] = useState<{
    employeeId: string;
    type: 'Báo tăng' | 'Báo giảm' | 'Điều chỉnh' | 'Tạm dừng đóng';
    effectiveDate: string;
    reason: string;
    newSalary: number;
  }>({
    employeeId: employees[0]?.id || '',
    type: 'Báo tăng',
    effectiveDate: new Date().toISOString().split('T')[0],
    reason: 'Ký mới hợp đồng lao động',
    newSalary: 12000000,
  });

  // OVERVIEW TAB: Automated calculations & warnings
  const overviewMetrics = useMemo(() => {
    const participatingCount = insuranceParticipants.filter((p) => p.status === 'Đang tham gia').length;
    const needRegisterCount = employees.filter((e) => e.insuranceStatus === 'Chưa đăng ký' && e.status !== 'Đã nghỉ việc').length;
    const pendingIncreaseCount = insuranceChanges.filter((c) => c.type === 'Báo tăng' && c.status === 'Đề xuất').length;
    const pendingDecreaseCount = insuranceChanges.filter((c) => c.type === 'Báo giảm' && (c.status === 'Đề xuất' || c.status === 'Đã xác nhận')).length;
    const activeClaimsCount = insuranceClaims.filter((c) => c.status !== 'Đã chi trả' && c.status !== 'Bị trả lại').length;

    // Tính tổng tiền dự kiến đóng tháng này từ active participants
    const activeList = insuranceParticipants.filter((p) => p.status === 'Đang tham gia' || p.status === 'Chờ báo tăng');
    const totalEE = activeList.reduce((sum, p) => sum + p.employeeAmount, 0);
    const totalER = activeList.reduce((sum, p) => sum + p.employerAmount, 0);
    const totalUnion = Math.round(activeList.reduce((sum, p) => sum + p.insuranceSalary, 0) * 0.02);
    const totalAll = totalEE + totalER + totalUnion;

    // Cảnh báo tự động
    const warnings: { id: string; type: 'danger' | 'warning' | 'info'; message: string; actionText?: string }[] = [];

    // 1. Nhân viên có HĐ từ 1 tháng nhưng chưa tham gia
    const unregWithContract = employees.filter((e) => e.insuranceStatus === 'Chưa đăng ký' && e.status === 'Chính thức');
    if (unregWithContract.length > 0) {
      warnings.push({
        id: 'w-unreg',
        type: 'danger',
        message: `Có ${unregWithContract.length} nhân sự chính thức đã ký HĐLĐ trên 1 tháng nhưng chưa lập hồ sơ đăng ký BHXH.`,
        actionText: 'Lập báo tăng ngay',
      });
    }

    // 2. Nhân viên nghỉ việc chưa báo giảm
    const resignedNotDecreased = employees.filter((e) => e.status === 'Đã nghỉ việc' && e.insuranceStatus !== 'Đã dừng');
    if (resignedNotDecreased.length > 0) {
      warnings.push({
        id: 'w-resigned',
        type: 'danger',
        message: `Có ${resignedNotDecreased.length} nhân sự đã nghỉ việc nhưng chưa hoàn tất Báo giảm BHXH (nguy cơ truy thu phí).`,
        actionText: 'Xử lý báo giảm',
      });
    }

    // 3. Mức lương đóng thấp hơn sàn vùng hoặc cao hơn trần
    const minSalaryRegionI = activeConfig.regionMinimumWages.I;
    const ceilingSocial = activeConfig.ceilingSocialInsurance;
    const invalidSalaries = insuranceParticipants.filter(
      (p) => (p.insuranceSalary > 0 && p.insuranceSalary < minSalaryRegionI) || p.insuranceSalary > ceilingSocial
    );
    if (invalidSalaries.length > 0) {
      warnings.push({
        id: 'w-salary',
        type: 'warning',
        message: `Có ${invalidSalaries.length} người lao động có mức lương đóng lệch mức sàn Vùng I (${minSalaryRegionI.toLocaleString()} đ) hoặc vượt trần (${ceilingSocial.toLocaleString()} đ).`,
      });
    }

    // 4. Nhắc hạn nộp tiền tháng 10/2026 (Ngày 25 hàng tháng)
    warnings.push({
      id: 'w-due-date',
      type: 'info',
      message: `Hạn chót trích nộp tiền BHXH tháng 10/2026 là ngày 25/10/2026 (Cơ quan quản lý: ${activeConfig.managingAgency}).`,
    });

    return {
      participatingCount,
      needRegisterCount,
      pendingIncreaseCount,
      pendingDecreaseCount,
      activeClaimsCount,
      totalEE,
      totalER,
      totalUnion,
      totalAll,
      warnings,
    };
  }, [insuranceParticipants, employees, insuranceChanges, insuranceClaims, activeConfig]);

  // Filtered Participants
  const filteredParticipants = useMemo(() => {
    return insuranceParticipants.filter((p) => {
      if (statusFilter !== 'all' && p.status !== statusFilter) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return (
          p.employeeName.toLowerCase().includes(q) ||
          p.employeeCode.toLowerCase().includes(q) ||
          p.socialInsuranceNumber.includes(q) ||
          p.departmentName.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [insuranceParticipants, statusFilter, searchTerm]);

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 border border-teal-200 dark:border-teal-800">
              <ShieldCheck className="w-5 h-5" />
            </span>
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                Quản Lý Bảo Hiểm Xã Hội (BHXH - BHYT - BHTN)
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Theo dõi người tham gia, lập phiếu biến động tăng/giảm khi có sự kiện nhân sự, tính kỳ đóng hàng tháng và quản lý chế độ ốm đau - thai sản.
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => {
              logSensitiveAccess('EXPORT_DATA', 'Danh sách BHXH', ['Mã số BHXH', 'Mức lương đóng']);
              showToast('Xuất Excel thành công', 'Đã tải xuống bảng kê danh sách tham gia BHXH & tiền đóng.', 'success');
            }}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold flex items-center gap-1.5 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Xuất Báo Cáo Kê Khai</span>
          </button>
        </div>
      </div>

      {/* 6 Tabs Navigation */}
      <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 text-xs overflow-x-auto">
        {[
          { key: 'overview', label: 'Tổng Quan & Cảnh Báo' },
          { key: 'participants', label: 'Danh Sách Tham Gia' },
          { key: 'changes', label: 'Biến Động (Tăng / Giảm)' },
          { key: 'periods', label: 'Kỳ Đóng Hàng Tháng' },
          { key: 'claims', label: 'Chế Độ BHXH (Thai sản / Ốm đau)' },
          { key: 'config', label: 'Cấu Hình Theo Ngày Hiệu Lực' },
        ].map((t) => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key as any)}
            className={`px-4 py-2.5 font-bold border-b-2 whitespace-nowrap transition-colors flex items-center gap-1.5 ${
              activeTab === t.key
                ? 'border-teal-600 text-teal-600 dark:text-teal-400 bg-teal-50/50 dark:bg-teal-950/20'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <span>{t.label}</span>
          </button>
        ))}
      </div>

      {/* ========================================================
          TAB 1: TỔNG QUAN & CẢNH BÁO
      ======================================================== */}
      {activeTab === 'overview' && (
        <div className="space-y-4">
          {/* Key Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-slate-500 block font-medium">Lao động tham gia</span>
              <span className="text-xl font-bold font-mono text-teal-600 dark:text-teal-400 mt-0.5 block">
                {overviewMetrics.participatingCount} <span className="text-xs font-normal text-slate-400">người</span>
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-amber-600 block font-medium">Cần đăng ký mới</span>
              <span className="text-xl font-bold font-mono text-amber-600 mt-0.5 block">
                {overviewMetrics.needRegisterCount} <span className="text-xs font-normal text-slate-400">hồ sơ</span>
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-sky-600 block font-medium">Cần báo tăng</span>
              <span className="text-xl font-bold font-mono text-sky-600 mt-0.5 block">
                {overviewMetrics.pendingIncreaseCount}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-rose-600 block font-medium">Cần báo giảm</span>
              <span className="text-xl font-bold font-mono text-rose-600 mt-0.5 block">
                {overviewMetrics.pendingDecreaseCount}
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-[11px] text-purple-600 block font-medium">Hưởng chế độ</span>
              <span className="text-xl font-bold font-mono text-purple-600 mt-0.5 block">
                {overviewMetrics.activeClaimsCount} <span className="text-xs font-normal text-slate-400">ca</span>
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-teal-200 dark:border-teal-900 shadow-xs bg-teal-50/30 dark:bg-teal-950/20">
              <span className="text-[11px] text-teal-800 dark:text-teal-300 block font-bold">Tổng tiền tháng này</span>
              <span className="text-base font-bold font-mono text-teal-700 dark:text-teal-300 mt-0.5 block">
                {overviewMetrics.totalAll.toLocaleString()} đ
              </span>
            </div>
          </div>

          {/* Breakdown tiền đóng */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
            <div className="space-y-1">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Cơ Cấu Tiền Nộp BHXH &amp; Kinh Phí Công Đoàn Tháng Này
              </h3>
              <p className="text-slate-500 text-[11px]">
                Áp dụng biểu tỷ lệ hiện hành: Người lao động 10,5% &bull; Doanh nghiệp 21,5% &bull; Kinh phí công đoàn 2,0%
              </p>
            </div>

            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block font-sans">NLĐ đóng (10.5%):</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{overviewMetrics.totalEE.toLocaleString()} đ</span>
              </div>
              <span className="text-slate-300">+</span>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block font-sans">DN đóng (21.5%):</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{overviewMetrics.totalER.toLocaleString()} đ</span>
              </div>
              <span className="text-slate-300">+</span>
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block font-sans">Kinh phí CĐ (2%):</span>
                <span className="font-bold text-slate-800 dark:text-slate-200">{overviewMetrics.totalUnion.toLocaleString()} đ</span>
              </div>
              <span className="text-slate-300">=</span>
              <div className="text-right pl-2 border-l border-slate-200 dark:border-slate-700">
                <span className="text-[10px] text-teal-600 block font-sans font-bold">Tổng trích nộp:</span>
                <span className="font-bold text-teal-600 text-sm">{overviewMetrics.totalAll.toLocaleString()} đ</span>
              </div>
            </div>
          </div>

          {/* Cảnh báo tự động */}
          <div className="space-y-2.5">
            <h3 className="font-bold text-xs text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              Cảnh Báo Nghiệp Vụ Tự Động (Automated Health Alerts)
            </h3>
            <div className="space-y-2">
              {overviewMetrics.warnings.map((w) => (
                <div
                  key={w.id}
                  className={`p-3.5 rounded-xl border flex items-center justify-between text-xs gap-3 ${
                    w.type === 'danger'
                      ? 'bg-rose-50 border-rose-200 dark:bg-rose-950/40 dark:border-rose-800 text-rose-900 dark:text-rose-200'
                      : w.type === 'warning'
                      ? 'bg-amber-50 border-amber-200 dark:bg-amber-950/40 dark:border-amber-800 text-amber-900 dark:text-amber-200'
                      : 'bg-sky-50 border-sky-200 dark:bg-sky-950/40 dark:border-sky-800 text-sky-900 dark:text-sky-200'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <AlertTriangle className={`w-4 h-4 shrink-0 ${w.type === 'danger' ? 'text-rose-600' : w.type === 'warning' ? 'text-amber-600' : 'text-sky-600'}`} />
                    <span className="font-semibold">{w.message}</span>
                  </div>

                  {w.actionText && (
                    <button
                      onClick={() => setActiveTab('changes')}
                      className="shrink-0 px-3 py-1 rounded-lg bg-white dark:bg-slate-900 font-bold text-xs shadow-xs hover:bg-slate-50 border"
                    >
                      {w.actionText} &rarr;
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 2: DANH SÁCH THAM GIA
      ======================================================== */}
      {activeTab === 'participants' && (
        <div className="space-y-3">
          {/* Filter Bar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Tìm theo tên, mã NV, mã BHXH..."
                className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>

            <div className="flex items-center gap-2">
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value)}
                className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              >
                <option value="all">Tất cả trạng thái</option>
                <option value="Đang tham gia">Đang tham gia</option>
                <option value="Chờ báo tăng">Chờ báo tăng</option>
                <option value="Chờ báo giảm">Chờ báo giảm</option>
                <option value="Đã dừng">Đã dừng</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-bold border-b text-[11px] uppercase tracking-wider">
                  <tr>
                    <th className="p-3">Nhân Viên</th>
                    <th className="p-3">Mã Số BHXH</th>
                    <th className="p-3">Thẻ BHYT &amp; Nơi KCB</th>
                    <th className="p-3">Ngày Bắt Đầu</th>
                    <th className="p-3 text-right">Lương Đóng</th>
                    <th className="p-3 text-right">NLĐ Đóng (10.5%)</th>
                    <th className="p-3 text-right">DN Đóng (21.5%)</th>
                    <th className="p-3">Trạng Thái</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredParticipants.map((p) => {
                    const isUnmasked = !!unmaskedRows[p.id];
                    return (
                      <tr key={p.id} className="hover:bg-slate-50/50">
                        <td className="p-3">
                          <span className="font-bold text-slate-900 dark:text-white block">{p.employeeName}</span>
                          <span className="font-mono text-[10px] text-slate-400">{p.employeeCode} &bull; {p.departmentName}</span>
                        </td>

                        <td className="p-3">
                          <div className="flex items-center gap-1.5 font-mono font-bold text-teal-700 dark:text-teal-300">
                            <span>{isUnmasked ? p.socialInsuranceNumber : maskSensitive(p.socialInsuranceNumber, 3)}</span>
                            <button
                              onClick={() => toggleUnmaskNumber(p.id, p.employeeName)}
                              className="text-slate-400 hover:text-slate-700 p-0.5"
                              title={isUnmasked ? 'Che bớt' : 'Hiện đầy đủ'}
                            >
                              {isUnmasked ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                            </button>
                          </div>
                        </td>

                        <td className="p-3">
                          <span className="font-mono text-xs block">{p.healthInsuranceCardNumber}</span>
                          <span className="text-[10px] text-slate-400 truncate max-w-xs block">{p.healthClinicName}</span>
                        </td>

                        <td className="p-3 font-mono text-[11px]">{p.startDate}</td>

                        <td className="p-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                          {p.insuranceSalary.toLocaleString()} đ
                        </td>

                        <td className="p-3 text-right font-mono text-slate-600 dark:text-slate-300">
                          {p.employeeAmount.toLocaleString()} đ
                        </td>

                        <td className="p-3 text-right font-mono text-slate-600 dark:text-slate-300">
                          {p.employerAmount.toLocaleString()} đ
                        </td>

                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              p.status === 'Đang tham gia'
                                ? 'bg-emerald-100 text-emerald-800'
                                : p.status === 'Chờ báo tăng'
                                ? 'bg-sky-100 text-sky-800 ring-1 ring-sky-300'
                                : p.status === 'Chờ báo giảm'
                                ? 'bg-rose-100 text-rose-800 ring-1 ring-rose-300'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {p.status}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 3: BIẾN ĐỘNG (BÁO TĂNG / GIẢM / ĐIỀU CHỈNH)
      ======================================================== */}
      {activeTab === 'changes' && (
        <div className="space-y-3">
          {/* Action bar for batch confirm */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-800 dark:text-slate-200">
                {selectedChangeIds.length > 0 ? `Đã chọn ${selectedChangeIds.length} phiếu` : 'Danh sách phiếu biến động'}
              </span>
              {selectedChangeIds.length > 0 && (
                <button
                  onClick={() => {
                    batchConfirmInsuranceChanges(selectedChangeIds);
                    setSelectedChangeIds([]);
                  }}
                  className="px-3 py-1 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-lg flex items-center gap-1 shadow-xs"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Xác Nhận Hàng Loạt</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsManualChangeModalOpen(true)}
                className="px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white font-bold flex items-center gap-1.5 shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>+ Lập phiếu biến động</span>
              </button>

              <button
                onClick={() => {
                  showToast('Xuất danh sách biến động', 'Đã xuất file bảng kê biến động lao động D02-LT.', 'info');
                }}
                className="px-3 py-1.5 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300 font-semibold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Xuất Mẫu D02-LT (Excel)</span>
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800 text-slate-500 font-bold border-b text-[11px] uppercase">
                  <tr>
                    <th className="p-3 w-8">
                      <input
                        type="checkbox"
                        checked={selectedChangeIds.length === insuranceChanges.length && insuranceChanges.length > 0}
                        onChange={(e) => {
                          if (e.target.checked) setSelectedChangeIds(insuranceChanges.map((c) => c.id));
                          else setSelectedChangeIds([]);
                        }}
                      />
                    </th>
                    <th className="p-3">Mã Phiếu &amp; Loại</th>
                    <th className="p-3">Người Lao Động</th>
                    <th className="p-3">Ngày Hiệu Lực</th>
                    <th className="p-3">Lý Do Biến Động</th>
                    <th className="p-3">Mức Lương Đóng</th>
                    <th className="p-3">Trạng Thái</th>
                    <th className="p-3 text-right">Thao Tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {insuranceChanges.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-50/50">
                      <td className="p-3">
                        <input
                          type="checkbox"
                          checked={selectedChangeIds.includes(c.id)}
                          onChange={(e) => {
                            if (e.target.checked) setSelectedChangeIds((prev) => [...prev, c.id]);
                            else setSelectedChangeIds((prev) => prev.filter((id) => id !== c.id));
                          }}
                        />
                      </td>

                      <td className="p-3">
                        <span className="font-mono font-bold text-teal-600 block">{c.code}</span>
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            c.type === 'Báo tăng'
                              ? 'bg-sky-100 text-sky-800'
                              : c.type === 'Báo giảm'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {c.type}
                        </span>
                      </td>

                      <td className="p-3 font-semibold text-slate-900 dark:text-white">
                        {c.employeeName}
                        <span className="block text-[10px] text-slate-400 font-normal">{c.departmentName}</span>
                      </td>

                      <td className="p-3 font-mono text-[11px]">{c.effectiveDate}</td>

                      <td className="p-3 text-slate-600 dark:text-slate-300 max-w-xs">
                        {c.reason}
                        {c.notes && <p className="text-[10px] text-slate-400 italic mt-0.5">{c.notes}</p>}
                      </td>

                      <td className="p-3 font-mono text-xs">
                        {c.oldSalary && c.newSalary ? (
                          <span>
                            {c.oldSalary.toLocaleString()} &rarr; <strong className="text-teal-600">{c.newSalary.toLocaleString()} đ</strong>
                          </span>
                        ) : c.newSalary ? (
                          <strong className="text-teal-600">{c.newSalary.toLocaleString()} đ</strong>
                        ) : (
                          '—'
                        )}
                      </td>

                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            c.status === 'Đã duyệt'
                              ? 'bg-emerald-100 text-emerald-800'
                              : c.status === 'Đã nộp CQ BHXH'
                              ? 'bg-sky-100 text-sky-800'
                              : c.status === 'Đã xác nhận'
                              ? 'bg-teal-100 text-teal-800'
                              : c.status === 'Đề xuất'
                              ? 'bg-amber-100 text-amber-800 ring-1 ring-amber-300'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {c.status}
                        </span>
                      </td>

                      <td className="p-3 text-right">
                        <div className="flex items-center justify-end gap-1">
                          {c.status === 'Đề xuất' && (
                            <button
                              onClick={() => confirmInsuranceChange(c.id)}
                              className="px-2 py-1 rounded bg-teal-600 text-white font-bold hover:bg-teal-700 text-[10px]"
                            >
                              Xác nhận
                            </button>
                          )}
                          {c.status === 'Đã xác nhận' && (
                            <button
                              onClick={() => {
                                setSubmitModalTarget(c);
                                setSubmissionCodeInput(`HS-BHXH-2026-${Math.floor(100000 + Math.random() * 900000)}`);
                              }}
                              className="px-2 py-1 rounded bg-sky-600 text-white font-bold hover:bg-sky-700 text-[10px] flex items-center gap-1"
                            >
                              <Send className="w-3 h-3" />
                              <span>Nộp hồ sơ</span>
                            </button>
                          )}
                          {c.status === 'Đã nộp CQ BHXH' && (
                            <button
                              onClick={() => approveInsuranceChange(c.id)}
                              className="px-2 py-1 rounded bg-emerald-600 text-white font-bold hover:bg-emerald-700 text-[10px]"
                            >
                              CQ duyệt
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 4: KỲ ĐÓNG HÀNG THÁNG
      ======================================================== */}
      {activeTab === 'periods' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Bảng Tổng Hợp Kỳ Đóng BHXH Hàng Tháng
              </h3>
              <p className="text-xs text-slate-500">
                Tính toán theo danh sách tham gia, áp dụng mức trần/sàn quỹ lương và tỷ lệ phần NLĐ &amp; DN đóng.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => generateMonthlyPeriod('11/2026')}
                className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Tạo Kỳ Đóng Mới (11/2026)</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {monthlyPeriods.map((period) => (
              <div
                key={period.id}
                onClick={() => setSelectedPeriod(period)}
                className={`p-4 rounded-xl border cursor-pointer transition-all ${
                  selectedPeriod?.id === period.id
                    ? 'border-teal-500 ring-2 ring-teal-200 dark:ring-teal-900 bg-white dark:bg-slate-900 shadow-md'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-bold text-base text-slate-900 dark:text-white">
                    Kỳ Tháng {period.periodMonth}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      period.status === 'Đã nộp tiền'
                        ? 'bg-emerald-100 text-emerald-800'
                        : period.status === 'Đã chốt'
                        ? 'bg-sky-100 text-sky-800'
                        : 'bg-amber-100 text-amber-800 ring-1 ring-amber-300'
                    }`}
                  >
                    {period.status}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-500">
                    <span>Số lao động:</span>
                    <strong className="text-slate-800 dark:text-slate-200">{period.totalEmployees} người</strong>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Quỹ lương đóng:</span>
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{period.totalSalaryFund.toLocaleString()} đ</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Phần NLĐ đóng (10.5%):</span>
                    <span className="font-mono text-slate-800 dark:text-slate-200">{period.totalEmployeePaid.toLocaleString()} đ</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Phần DN đóng (21.5%):</span>
                    <span className="font-mono text-slate-800 dark:text-slate-200">{period.totalEmployerPaid.toLocaleString()} đ</span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Kinh phí công đoàn (2%):</span>
                    <span className="font-mono text-slate-800 dark:text-slate-200">{period.tradeUnionFee.toLocaleString()} đ</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-teal-600 font-bold">
                    <span>Tổng nộp kỳ:</span>
                    <span className="text-sm font-mono">{period.grandTotal.toLocaleString()} đ</span>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Xem bảng chi tiết &rarr;</span>
                  {period.paymentRefNumber && (
                    <span className="font-mono text-emerald-600 font-bold">{period.paymentRefNumber}</span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Chi tiết kỳ được chọn */}
          {selectedPeriod && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base">
                    Chi Tiết Kỳ Đóng Tháng {selectedPeriod.periodMonth} ({selectedPeriod.totalEmployees} lao động)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Số liệu dùng để hạch toán chi phí phần Doanh nghiệp và khấu trừ lương phần Người lao động.
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsPrintModalOpen(true)}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>In Bảng Tổng Hợp (PDF)</span>
                  </button>

                  {selectedPeriod.status === 'Nháp' && (
                    <button
                      onClick={() => lockMonthlyPeriod(selectedPeriod.id)}
                      className="px-3 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs flex items-center gap-1"
                    >
                      <Lock className="w-3.5 h-3.5" />
                      <span>Chốt Số Liệu Kỳ</span>
                    </button>
                  )}

                  {selectedPeriod.status === 'Đã chốt' && (
                    <>
                      <button
                        onClick={() => {
                          setPaymentAmountInput(selectedPeriod.grandTotal);
                          setIsPaymentModalOpen(true);
                        }}
                        className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1 shadow-xs"
                      >
                        <DollarSign className="w-3.5 h-3.5" />
                        <span>Xác Nhận Nộp Tiền</span>
                      </button>
                      <button
                        onClick={() => setIsUnlockModalOpen(true)}
                        className="px-2.5 py-1.5 rounded-lg border border-amber-300 text-amber-700 text-xs font-semibold"
                      >
                        Mở lại kỳ
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Bảng phân bổ các quỹ */}
              <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 text-xs">
                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-400 block">Hưu trí - tử tuất (22%)</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white mt-1 block">
                    {selectedPeriod.pensionFund.total.toLocaleString()} đ
                  </span>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-400 block">Ốm đau - thai sản (3%)</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white mt-1 block">
                    {selectedPeriod.maternityFund.total.toLocaleString()} đ
                  </span>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-400 block">TNLĐ - BNN (0.5%)</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white mt-1 block">
                    {selectedPeriod.accidentFund.total.toLocaleString()} đ
                  </span>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-400 block">BHYT Y tế (4.5%)</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white mt-1 block">
                    {selectedPeriod.healthFund.total.toLocaleString()} đ
                  </span>
                </div>
                <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
                  <span className="text-[10px] text-slate-400 block">BHTN Thất nghiệp (2%)</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white mt-1 block">
                    {selectedPeriod.unemploymentFund.total.toLocaleString()} đ
                  </span>
                </div>
                <div className="p-3 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 rounded-lg">
                  <span className="text-[10px] text-teal-700 block font-bold">Kinh phí Công đoàn (2%)</span>
                  <span className="font-mono font-bold text-teal-800 dark:text-teal-200 mt-1 block">
                    {selectedPeriod.tradeUnionFee.toLocaleString()} đ
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================
          TAB 5: CHẾ ĐỘ BHXH (THAI SẢN / ỐM ĐAU)
      ======================================================== */}
      {activeTab === 'claims' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Hồ Sơ Hưởng Chế Độ Bảo Hiểm Xã Hội (Sức khỏe &amp; Thai sản)
              </h3>
              <p className="text-xs text-slate-500">
                Dữ liệu sức khỏe nhạy cảm &bull; Phân quyền bảo mật cao cho vai trò Nhân sự và Giám đốc.
              </p>
            </div>

            <button
              onClick={() => setIsNewClaimModalOpen(true)}
              className="px-3.5 py-2 bg-teal-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs hover:bg-teal-700"
            >
              <Plus className="w-4 h-4" />
              <span>Lập Hồ Sơ Hưởng Chế Độ</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {insuranceClaims.map((claim) => (
              <div
                key={claim.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3"
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <HeartPulse className="w-4 h-4 text-purple-600" />
                    <span className="font-bold text-slate-900 dark:text-white text-sm">
                      {claim.employeeName}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-purple-100 text-purple-800 font-bold text-[10px]">
                      {claim.type}
                    </span>
                  </div>

                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      claim.status === 'Đã chi trả'
                        ? 'bg-emerald-100 text-emerald-800'
                        : claim.status === 'Đã duyệt'
                        ? 'bg-sky-100 text-sky-800'
                        : claim.status === 'Đã nộp'
                        ? 'bg-teal-100 text-teal-800'
                        : 'bg-amber-100 text-amber-800 ring-1 ring-amber-300'
                    }`}
                  >
                    {claim.status}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[11px]">Thời gian nghỉ:</span>
                    <span className="font-semibold">{claim.startDate} &rarr; {claim.endDate} ({claim.leaveDays} ngày)</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[11px]">Số tiền trợ cấp:</span>
                    <span className="font-mono font-bold text-purple-600 text-sm">
                      {(claim.actualAmount || claim.expectedAmount).toLocaleString()} đ
                    </span>
                  </div>
                  <div className="col-span-2">
                    <span className="text-slate-400 block text-[11px]">Chứng từ kèm theo:</span>
                    <span className="font-mono text-slate-600 dark:text-slate-300">
                      {claim.attachments?.map((a) => a.name).join(', ') || 'Giấy chứng sinh / Giấy ra viện'}
                    </span>
                  </div>
                  {claim.notes && (
                    <div className="col-span-2 text-slate-500 italic text-[11px]">
                      Ghi chú: {claim.notes}
                    </div>
                  )}
                </div>

                {claim.status !== 'Đã chi trả' && (
                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
                    {claim.status === 'Đang chuẩn bị hồ sơ' && (
                      <button
                        onClick={() => updateClaimStatus(claim.id, 'Đã nộp')}
                        className="px-2.5 py-1 bg-sky-600 text-white rounded-lg text-xs font-semibold"
                      >
                        Đã nộp cơ quan BHXH
                      </button>
                    )}
                    {claim.status === 'Đã nộp' && (
                      <button
                        onClick={() => updateClaimStatus(claim.id, 'Đã duyệt')}
                        className="px-2.5 py-1 bg-emerald-600 text-white rounded-lg text-xs font-semibold"
                      >
                        Cơ quan duyệt
                      </button>
                    )}
                    {claim.status === 'Đã duyệt' && (
                      <button
                        onClick={() => updateClaimStatus(claim.id, 'Đã chi trả', claim.expectedAmount)}
                        className="px-2.5 py-1 bg-purple-600 text-white rounded-lg text-xs font-semibold"
                      >
                        Xác nhận đã chi trả
                      </button>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================
          TAB 6: CẤU HÌNH THEO NGÀY HIỆU LỰC
      ======================================================== */}
      {activeTab === 'config' && (
        <div className="space-y-4">
          <div className="p-3.5 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-amber-900 dark:text-amber-200 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Info className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                <strong>Lưu ý nghiệp vụ: </strong>Mọi tham số BHXH được lưu theo <strong>NGÀY HIỆU LỰC</strong>. Khi nhà nước thay đổi mức lương cơ sở hoặc trần đóng, hệ thống lưu lịch sử để dữ liệu các tháng cũ vẫn tính toán chính xác.
              </span>
            </div>
          </div>

          <div className="space-y-4">
            {insuranceConfigs.map((cfg) => {
              const isCurrent = cfg.id === activeConfig.id;
              return (
                <div
                  key={cfg.id}
                  className={`bg-white dark:bg-slate-900 border rounded-xl p-5 shadow-xs space-y-4 ${
                    isCurrent ? 'border-teal-500 ring-2 ring-teal-200 dark:ring-teal-900' : 'border-slate-200 dark:border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-white text-base">
                          {cfg.title}
                        </span>
                        {isCurrent && (
                          <span className="px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 font-bold text-[10px]">
                            Đang áp dụng
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5 font-mono">
                        Ngày bắt đầu áp dụng: {cfg.effectiveDate} &bull; Mã đơn vị BHXH: {cfg.companyCode}
                      </p>
                    </div>

                    <span className="font-mono text-xs text-slate-400">
                      Cơ quan: {cfg.managingAgency}
                    </span>
                  </div>

                  {/* Chi tiết tỷ lệ */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
                    <div className="space-y-1">
                      <span className="text-slate-400 block text-[11px]">Tỷ lệ Người lao động đóng:</span>
                      <strong className="text-slate-900 dark:text-white text-sm font-mono">
                        {cfg.rates.employee.total}%
                      </strong>
                      <p className="text-[10px] text-slate-500">
                        Hưu trí 8% &bull; BHYT 1.5% &bull; BHTN 1%
                      </p>
                    </div>

                    <div className="space-y-1">
                      <span className="text-slate-400 block text-[11px]">Tỷ lệ Doanh nghiệp đóng:</span>
                      <strong className="text-slate-900 dark:text-white text-sm font-mono">
                        {cfg.rates.employer.total}%
                      </strong>
                      <p className="text-[10px] text-slate-500">
                        Hưu trí 14% &bull; Thai sản 3% &bull; TNLĐ 0.5% &bull; BHYT 3% &bull; BHTN 1%
                      </p>
                    </div>

                    <div className="space-y-1">
                      <span className="text-slate-400 block text-[11px]">Kinh phí Công đoàn (DN):</span>
                      <strong className="text-teal-600 text-sm font-mono">
                        {cfg.rates.tradeUnion}%
                      </strong>
                      <p className="text-[10px] text-slate-500">
                        2% quỹ tiền lương làm căn cứ đóng
                      </p>
                    </div>

                    <div className="space-y-1">
                      <span className="text-slate-400 block text-[11px]">Mức lương cơ sở:</span>
                      <strong className="text-purple-600 text-sm font-mono">
                        {cfg.baseSalary.toLocaleString()} đ
                      </strong>
                      <p className="text-[10px] text-slate-500">
                        Mức trần 20x = {cfg.ceilingSocialInsurance.toLocaleString()} đ
                      </p>
                    </div>
                  </div>

                  {/* Lương tối thiểu 4 vùng */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                    <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200 mb-2">
                      Mức Lương Tối Thiểu Vùng:
                    </h4>
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono">
                      <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded">
                        <span className="text-[10px] text-slate-400 block font-sans">Vùng I (Hà Nội, TP.HCM):</span>
                        <strong>{cfg.regionMinimumWages.I.toLocaleString()} đ</strong>
                      </div>
                      <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded">
                        <span className="text-[10px] text-slate-400 block font-sans">Vùng II (Đà Nẵng, Cần Thơ):</span>
                        <strong>{cfg.regionMinimumWages.II.toLocaleString()} đ</strong>
                      </div>
                      <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded">
                        <span className="text-[10px] text-slate-400 block font-sans">Vùng III (Hưng Yên, Bắc Ninh):</span>
                        <strong>{cfg.regionMinimumWages.III.toLocaleString()} đ</strong>
                      </div>
                      <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded">
                        <span className="text-[10px] text-slate-400 block font-sans">Vùng IV (Khu vực còn lại):</span>
                        <strong>{cfg.regionMinimumWages.IV.toLocaleString()} đ</strong>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================
          MODAL IN BẢNG TỔNG HỢP KỲ ĐÓNG (PDF)
      ======================================================== */}
      {isPrintModalOpen && selectedPeriod && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-xl max-w-3xl w-full p-8 shadow-2xl my-8 text-xs font-serif leading-relaxed">
            <div className="flex justify-between items-start pb-4 border-b border-slate-300 mb-4">
              <APlusLogo />
              <div className="text-right">
                <h4 className="font-bold text-sm">CÔNG TY CỔ PHẦN CÔNG NGHỆ A+</h4>
                <p className="text-[11px] text-slate-500">Mã đơn vị: {activeConfig.companyCode}</p>
                <p className="text-[11px] text-slate-500">Cơ quan: {activeConfig.managingAgency}</p>
              </div>
            </div>

            <div className="text-center my-6">
              <h2 className="text-base font-bold uppercase tracking-wider">
                BẢNG TỔNG HỢP TRÍCH NỘP BHXH - BHYT - BHTN
              </h2>
              <p className="text-xs italic">Kỳ tính tháng {selectedPeriod.periodMonth}</p>
            </div>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between border-b pb-1">
                <span>1. Tổng số người lao động tham gia:</span>
                <strong>{selectedPeriod.totalEmployees} người</strong>
              </div>
              <div className="flex justify-between border-b pb-1">
                <span>2. Tổng quỹ lương làm căn cứ đóng:</span>
                <strong className="font-mono">{selectedPeriod.totalSalaryFund.toLocaleString()} VNĐ</strong>
              </div>
              <div className="flex justify-between border-b pb-1">
                <span>3. Số tiền Người lao động đóng (10,5%):</span>
                <strong className="font-mono">{selectedPeriod.totalEmployeePaid.toLocaleString()} VNĐ</strong>
              </div>
              <div className="flex justify-between border-b pb-1">
                <span>4. Số tiền Doanh nghiệp đóng (21,5%):</span>
                <strong className="font-mono">{selectedPeriod.totalEmployerPaid.toLocaleString()} VNĐ</strong>
              </div>
              <div className="flex justify-between border-b pb-1">
                <span>5. Kinh phí công đoàn trích nộp (2,0%):</span>
                <strong className="font-mono">{selectedPeriod.tradeUnionFee.toLocaleString()} VNĐ</strong>
              </div>
              <div className="flex justify-between border-b pb-1 text-sm font-bold text-teal-800">
                <span>TỔNG CỘNG PHẢI NỘP CƠ QUAN BHXH &amp; CÔNG ĐOÀN:</span>
                <span className="font-mono">{selectedPeriod.grandTotal.toLocaleString()} VNĐ</span>
              </div>
              <p className="italic text-[11px]">
                Bằng chữ: <em>{numberToVietnameseWords(selectedPeriod.grandTotal)}</em>
              </p>
            </div>

            <div className="grid grid-cols-3 gap-4 text-center pt-8 border-t border-slate-300">
              <div>
                <p className="font-bold">Người lập biểu</p>
                <div className="h-16" />
                <p className="font-semibold">Đặng Thu Thảo</p>
              </div>
              <div>
                <p className="font-bold">Kế toán trưởng</p>
                <div className="h-16" />
                <p className="font-semibold">Đặng Thu Thảo</p>
              </div>
              <div>
                <p className="font-bold">Tổng Giám Đốc</p>
                <div className="h-16" />
                <p className="font-semibold">Trần Minh Đức</p>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-200 flex justify-end gap-2 no-print">
              <button
                onClick={() => setIsPrintModalOpen(false)}
                className="px-4 py-2 border rounded font-sans font-bold"
              >
                Đóng
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-teal-600 text-white rounded font-sans font-bold shadow-xs"
              >
                In văn bản (Print)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL NỘP HỒ SƠ CQ BHXH */}
      {submitModalTarget && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 text-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b">
              <h3 className="font-bold text-sm">Ghi Nhận Đã Nộp CQ BHXH</h3>
              <button onClick={() => setSubmitModalTarget(null)}><X className="w-4 h-4" /></button>
            </div>

            <p className="text-slate-600">
              Nhập mã số hồ sơ điện tử trả về từ phần mềm kê khai BHXH hoặc cổng dịch vụ công:
            </p>

            <div>
              <label className="block font-semibold mb-1">Mã số hồ sơ / Biên nhận *</label>
              <input
                type="text"
                value={submissionCodeInput}
                onChange={(e) => setSubmissionCodeInput(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border font-mono font-bold"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button onClick={() => setSubmitModalTarget(null)} className="px-3 py-1.5 border rounded-lg">Hủy</button>
              <button
                onClick={() => {
                  submitInsuranceChangeToAgency(submitModalTarget.id, submissionCodeInput);
                  setSubmitModalTarget(null);
                }}
                className="px-4 py-1.5 bg-sky-600 text-white font-bold rounded-lg"
              >
                Xác nhận đã nộp
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL NỘP TIỀN KỲ */}
      {isPaymentModalOpen && selectedPeriod && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 text-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b">
              <h3 className="font-bold text-sm">Xác Nhận Nộp Tiền BHXH Kỳ Tháng {selectedPeriod.periodMonth}</h3>
              <button onClick={() => setIsPaymentModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>

            <div>
              <label className="block font-semibold mb-1">Số chứng từ thanh toán (Ủy nhiệm chi) *</label>
              <input
                type="text"
                value={paymentRefInput}
                onChange={(e) => setPaymentRefInput(e.target.value)}
                className="w-full px-3 py-2 rounded-lg border font-mono font-bold"
              />
            </div>

            <div>
              <label className="block font-semibold mb-1">Số tiền thực nộp (VNĐ)</label>
              <input
                type="number"
                value={paymentAmountInput}
                onChange={(e) => setPaymentAmountInput(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg border font-mono font-bold text-teal-600"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button onClick={() => setIsPaymentModalOpen(false)} className="px-3 py-1.5 border rounded-lg">Hủy</button>
              <button
                onClick={() => {
                  recordPeriodPayment(selectedPeriod.id, paymentRefInput, paymentAmountInput);
                  setIsPaymentModalOpen(false);
                }}
                className="px-4 py-1.5 bg-emerald-600 text-white font-bold rounded-lg"
              >
                Lưu xác nhận nộp tiền
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL MỞ LẠI KỲ ĐÓNG */}
      {isUnlockModalOpen && selectedPeriod && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-md shadow-2xl p-6 text-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b">
              <h3 className="font-bold text-sm text-amber-600">Mở Lại Kỳ Đóng Đã Chốt</h3>
              <button onClick={() => setIsUnlockModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>

            <p className="text-slate-600">
              Kỳ đóng đã chốt chỉ được mở lại khi có lý do điều chỉnh hợp lệ theo quy định:
            </p>

            <div>
              <label className="block font-semibold mb-1">Lý do mở lại kỳ *</label>
              <textarea
                value={unlockReasonInput}
                onChange={(e) => setUnlockReasonInput(e.target.value)}
                rows={3}
                className="w-full px-3 py-2 rounded-lg border"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button onClick={() => setIsUnlockModalOpen(false)} className="px-3 py-1.5 border rounded-lg">Hủy</button>
              <button
                onClick={() => {
                  unlockMonthlyPeriod(selectedPeriod.id, unlockReasonInput);
                  setIsUnlockModalOpen(false);
                }}
                className="px-4 py-1.5 bg-amber-600 text-white font-bold rounded-lg"
              >
                Xác nhận mở lại
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL LẬP HỒ SƠ HƯỞNG CHẾ ĐỘ */}
      {isNewClaimModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl p-6 text-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b">
              <h3 className="font-bold text-sm">Lập Hồ Sơ Hưởng Chế Độ BHXH</h3>
              <button onClick={() => setIsNewClaimModalOpen(false)}><X className="w-4 h-4" /></button>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="block font-semibold mb-1">Người lao động *</label>
                <select
                  value={claimEmployeeId}
                  onChange={(e) => setClaimEmployeeId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border"
                >
                  {employees.map((e) => (
                    <option key={e.id} value={e.id}>{e.fullName} ({e.departmentName})</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Loại chế độ *</label>
                <select
                  value={claimType}
                  onChange={(e) => setClaimType(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg border"
                >
                  <option value="Ốm đau">Ốm đau</option>
                  <option value="Thai sản">Thai sản</option>
                  <option value="Dưỡng sức phục hồi sức khỏe">Dưỡng sức phục hồi sức khỏe</option>
                  <option value="Tai nạn lao động/Bệnh nghề nghiệp">Tai nạn lao động/Bệnh nghề nghiệp</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold mb-1">Số ngày nghỉ *</label>
                <input
                  type="number"
                  value={claimDays}
                  onChange={(e) => setClaimDays(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border font-mono font-bold"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Từ ngày</label>
                <input
                  type="date"
                  value={claimStartDate}
                  onChange={(e) => setClaimStartDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border"
                />
              </div>

              <div>
                <label className="block font-semibold mb-1">Đến ngày</label>
                <input
                  type="date"
                  value={claimEndDate}
                  onChange={(e) => setClaimEndDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border"
                />
              </div>

              <div className="col-span-2">
                <label className="block font-semibold mb-1">Số tiền trợ cấp dự kiến (VNĐ)</label>
                <input
                  type="number"
                  value={claimExpectedAmount}
                  onChange={(e) => setClaimExpectedAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border font-mono font-bold text-purple-600"
                />
              </div>

              <div className="col-span-2">
                <label className="block font-semibold mb-1">Ghi chú &amp; Tình trạng bệnh viện</label>
                <input
                  type="text"
                  value={claimNotes}
                  onChange={(e) => setClaimNotes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border"
                />
              </div>
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button onClick={() => setIsNewClaimModalOpen(false)} className="px-3 py-1.5 border rounded-lg">Hủy</button>
              <button
                onClick={() => {
                  const emp = employees.find((e) => e.id === claimEmployeeId);
                  addInsuranceClaim({
                    employeeId: claimEmployeeId,
                    employeeName: emp?.fullName || 'Người lao động',
                    departmentName: emp?.departmentName || 'Công ty',
                    type: claimType,
                    startDate: claimStartDate,
                    endDate: claimEndDate,
                    leaveDays: claimDays,
                    expectedAmount: claimExpectedAmount,
                    status: 'Đang chuẩn bị hồ sơ',
                    attachments: [{ name: 'Giay-Kham-Xac-Nhan.pdf', size: '1.2 MB' }],
                    notes: claimNotes,
                  });
                  setIsNewClaimModalOpen(false);
                }}
                className="px-4 py-1.5 bg-teal-600 text-white font-bold rounded-lg"
              >
                Lưu hồ sơ hưởng chế độ
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Modal: Lập Phiếu Biến Động Thủ Công */}
      {isManualChangeModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-teal-600" />
                <span>Lập Phiếu Biến Động BHXH (Thủ Công)</span>
              </h3>
              <button onClick={() => setIsManualChangeModalOpen(false)}>
                <XCircle className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div className="space-y-3.5">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Loại biến động *</label>
                <select
                  value={manualChangeForm.type}
                  onChange={(e) => setManualChangeForm({ ...manualChangeForm, type: e.target.value as any })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                >
                  <option value="Báo tăng">Báo tăng (Tuyển mới / Hết thử việc)</option>
                  <option value="Báo giảm">Báo giảm (Nghỉ việc / Tạm hoãn)</option>
                  <option value="Điều chỉnh">Điều chỉnh mức lương đóng BHXH</option>
                  <option value="Tạm dừng đóng">Tạm dừng đóng (Nghỉ không lương / Thai sản)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Nhân viên áp dụng *</label>
                <select
                  value={manualChangeForm.employeeId}
                  onChange={(e) => setManualChangeForm({ ...manualChangeForm, employeeId: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                >
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.fullName} ({emp.code} - {emp.departmentName})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Ngày hiệu lực *</label>
                <input
                  type="date"
                  value={manualChangeForm.effectiveDate}
                  onChange={(e) => setManualChangeForm({ ...manualChangeForm, effectiveDate: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Lý do biến động *</label>
                <input
                  type="text"
                  value={manualChangeForm.reason}
                  onChange={(e) => setManualChangeForm({ ...manualChangeForm, reason: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  placeholder="Ví dụ: Ký HĐLĐ chính thức đủ điều kiện tham gia"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Mức lương đóng BHXH mới (đ)</label>
                <input
                  type="number"
                  step={500000}
                  value={manualChangeForm.newSalary}
                  onChange={(e) => setManualChangeForm({ ...manualChangeForm, newSalary: Number(e.target.value) })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={() => setIsManualChangeModalOpen(false)}
                  className="px-3.5 py-1.5 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-700"
                >
                  Hủy
                </button>
                <button
                  onClick={() => {
                    const emp = employees.find((e) => e.id === manualChangeForm.employeeId) || employees[0];
                    addInsuranceChange({
                      employeeId: emp.id,
                      employeeName: emp.fullName,
                      departmentName: emp.departmentName,
                      type: manualChangeForm.type,
                      effectiveDate: manualChangeForm.effectiveDate,
                      reason: manualChangeForm.reason,
                      newSalary: manualChangeForm.newSalary,
                      status: 'Đề xuất',
                      notes: 'Tạo thủ công theo sự kiện nhân sự',
                      isAutoGenerated: false,
                    });
                    setIsManualChangeModalOpen(false);
                  }}
                  className="px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-lg shadow-xs"
                >
                  Tạo Phiếu Biến Động
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
