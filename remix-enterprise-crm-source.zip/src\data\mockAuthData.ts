/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * A+ CRM — MULTI-TENANT AUTHENTICATION & ORGANIZATION MANAGEMENT MOCK DATA
 * Chứa cấu trúc Control Database (CRM_CORE):
 * - Tenants & Database Registry (DB_APLUS, DB_ABC, DB_XYZ)
 * - Users, Memberships
 * - Departments, Positions, Levels
 * - Roles, Permissions & Scopes (OWN, TEAM, DEPARTMENT, COMPANY)
 */

import {
  Tenant,
  UserAccount,
  Department,
  Position,
  Level,
  Role,
  Membership,
  JoinRequest,
  CompanyInvitation,
  PlatformConfig,
  ModulePermission,
} from '../types/auth';

/**
 * 01. TENANTS REGISTRY (Control DB: CRM_CORE.tenants)
 * Mỗi Tenant có Database riêng: DB_APLUS, DB_ABC, DB_XYZ.
 */
export const INITIAL_TENANTS: Tenant[] = [
  {
    id: 'tenant_aplus',
    code: 'APLUS',
    slug: 'aplus',
    name: 'Công ty Cổ phần Tập đoàn Công nghệ số A+',
    database: 'DB_APLUS',
    databaseStatus: 'READY',
    schemaVersion: 'v3.4.2-enterprise',
    storageGb: 18.4,
    plan: 'Enterprise',
    status: 'active',
    userCount: 48,
    maxUsers: 100,
    departmentCount: 6,
    customerCount: 2481,
    dealCount: 328,
    taxCode: '0109988776',
    phone: '024 3888 9999',
    address: 'Tầng 12, Tòa nhà Keangnam Landmark 72, Mễ Trì, Nam Từ Liêm, Hà Nội',
    email: 'contact@apluscorp.vn',
    website: 'https://apluscorp.vn',
    logoUrl: 'https://images.unsplash.com/photo-1599305445671-ac291c95aaa9?w=100&h=100&fit=crop&crop=faces',
    createdAt: '2026-01-15',
    lastBackup: '2026-10-07 04:00 (Tự động hằng ngày)',
    lastActivity: 'Vừa xong',
  },
  {
    id: 'tenant_abc',
    code: 'ABC',
    slug: 'abc',
    name: 'ABC Technology Solutions',
    database: 'DB_ABC',
    databaseStatus: 'READY',
    schemaVersion: 'v3.4.2-enterprise',
    storageGb: 8.7,
    plan: 'Business',
    status: 'active',
    userCount: 21,
    maxUsers: 50,
    departmentCount: 3,
    customerCount: 940,
    dealCount: 142,
    taxCode: '0318822334',
    phone: '028 7300 5566',
    address: 'Tầng 8, Tòa nhà Bitexco Financial Tower, Số 2 Hải Triều, Bến Nghé, Q.1, TP. Hồ Chí Minh',
    email: 'info@abctech.vn',
    website: 'https://abctech.vn',
    logoUrl: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=100&h=100&fit=crop&crop=faces',
    createdAt: '2026-03-20',
    lastBackup: '2026-10-07 04:15 (Tự động hằng ngày)',
    lastActivity: '12 phút trước',
  },
  {
    id: 'tenant_xyz',
    code: 'XYZ',
    slug: 'xyz',
    name: 'XYZ Global Logistics & Trading',
    database: 'DB_XYZ',
    databaseStatus: 'READY',
    schemaVersion: 'v3.4.2-enterprise',
    storageGb: 3.1,
    plan: 'Starter',
    status: 'trial',
    userCount: 7,
    maxUsers: 15,
    departmentCount: 2,
    customerCount: 310,
    dealCount: 45,
    taxCode: '0107766554',
    phone: '024 3799 1122',
    address: 'Tầng 5, Tòa nhà Charmvit, 117 Trần Duy Hưng, Cầu Giấy, Hà Nội',
    email: 'contact@xyzcorp.vn',
    website: 'https://xyzcorp.vn',
    logoUrl: 'https://images.unsplash.com/photo-1572021335469-31706a17aaef?w=100&h=100&fit=crop&crop=faces',
    createdAt: '2026-08-01',
    lastBackup: '2026-10-07 04:30 (Tự động hằng ngày)',
    lastActivity: '45 phút trước',
  },
];

// Alias giữ tương thích ngược
export const INITIAL_COMPANIES = INITIAL_TENANTS;

/**
 * 02. DEPARTMENTS (Control DB: CRM_CORE.departments)
 */
export const INITIAL_DEPARTMENTS: Department[] = [
  // APLUS
  { id: 'dept_aplus_sale', tenantId: 'tenant_aplus', code: 'SALE', name: 'Phòng Kinh Doanh (Sales)', description: 'Chịu trách nhiệm mở rộng thị trường, quản trị Lead, Deal và Doanh thu', managerName: 'Hồ Hoàng Long', userCount: 18 },
  { id: 'dept_aplus_mkt', tenantId: 'tenant_aplus', code: 'MKT', name: 'Phòng Tiếp Thị & Thương Hiệu (Marketing)', description: 'Thu hút khách hàng tiềm năng, tổ chức chiến dịch quảng bá', managerName: 'Đặng Mai Phương', userCount: 8 },
  { id: 'dept_aplus_tech', tenantId: 'tenant_aplus', code: 'TECH', name: 'Phòng Kỹ Thuật & Triển Khai (Technology)', description: 'Khảo sát hiện trường, bóc tách BOM, thi công dự án và bảo hành', managerName: 'Nguyễn Nhật Thanh', userCount: 12 },
  { id: 'dept_aplus_hr', tenantId: 'tenant_aplus', code: 'HR', name: 'Phòng Nhân Sự & Đào Tạo (Human Resources)', description: 'Quản trị hồ sơ nhân sự, BHXH, chấm công và tuyển dụng', managerName: 'Phạm Thị Lan', userCount: 4 },
  { id: 'dept_aplus_acc', tenantId: 'tenant_aplus', code: 'ACCOUNTING', name: 'Phòng Tài Chính & Kế Toán (Accounting)', description: 'Quản trị dòng tiền, xuất hóa đơn VAT, đối soát công nợ', managerName: 'Vũ Thị Minh', userCount: 4 },
  { id: 'dept_aplus_ops', tenantId: 'tenant_aplus', code: 'OPERATIONS', name: 'Phòng Vận Hành & Logistics (Operations)', description: 'Quản lý kho bãi, điều phối vận tải, xuất nhập tồn hàng hóa', managerName: 'Hồ Minh Châu', userCount: 6 },

  // ABC
  { id: 'dept_abc_mkt', tenantId: 'tenant_abc', code: 'MKT', name: 'Phòng Marketing & Truyền Thông', description: 'Chiến dịch kỹ thuật số và quản trị quan hệ đối tác', managerName: 'Trần Văn B', userCount: 8 },
  { id: 'dept_abc_sale', tenantId: 'tenant_abc', code: 'SALE', name: 'Phòng Kinh Doanh Phần Mềm', description: 'Phân phối giải pháp SaaS doanh nghiệp', managerName: 'Võ Hoàng Quân', userCount: 9 },
  { id: 'dept_abc_tech', tenantId: 'tenant_abc', code: 'TECH', name: 'Phòng R&D & Hạ Tầng Cloud', description: 'Nghiên cứu sản phẩm và vận hành máy chủ', managerName: 'Ngô Quốc Bảo', userCount: 4 },

  // XYZ
  { id: 'dept_xyz_ops', tenantId: 'tenant_xyz', code: 'OPERATIONS', name: 'Phòng Vận Hành Giao Nhận', description: 'Điều phối logistics quốc tế và thủ tục thông quan', managerName: 'Lê Thị C', userCount: 5 },
  { id: 'dept_xyz_sale', tenantId: 'tenant_xyz', code: 'SALE', name: 'Phòng Phát Triển Khách Hàng', description: 'Tìm kiếm nguồn hàng và đối tác xuất nhập khẩu', managerName: 'Bùi Gia Khiêm', userCount: 2 },
];

/**
 * 03. LEVELS (Control DB: CRM_CORE.levels)
 */
export const INITIAL_LEVELS: Level[] = [
  { id: 'lvl_staff', tenantId: 'tenant_aplus', name: 'Staff (Chuyên viên)', code: 'STAFF', rank: 1 },
  { id: 'lvl_lead', tenantId: 'tenant_aplus', name: 'Leader (Trưởng nhóm)', code: 'LEADER', rank: 2 },
  { id: 'lvl_mgr', tenantId: 'tenant_aplus', name: 'Manager (Trưởng phòng)', code: 'MANAGER', rank: 3 },
  { id: 'lvl_dir', tenantId: 'tenant_aplus', name: 'Director (Ban Giám Đốc)', code: 'DIRECTOR', rank: 4 },
];

/**
 * 04. POSITIONS (Control DB: CRM_CORE.positions)
 */
export const INITIAL_POSITIONS: Position[] = [
  // APLUS
  { id: 'pos_aplus_sale_exec', tenantId: 'tenant_aplus', departmentId: 'dept_aplus_sale', code: 'SALE_EXEC', name: 'Sales Executive', levelId: 'lvl_staff' },
  { id: 'pos_aplus_sale_lead', tenantId: 'tenant_aplus', departmentId: 'dept_aplus_sale', code: 'SALE_LEAD', name: 'Sales Leader', levelId: 'lvl_lead' },
  { id: 'pos_aplus_sale_mgr', tenantId: 'tenant_aplus', departmentId: 'dept_aplus_sale', code: 'SALE_MGR', name: 'Sales Manager', levelId: 'lvl_mgr' },
  { id: 'pos_aplus_tech_mgr', tenantId: 'tenant_aplus', departmentId: 'dept_aplus_tech', code: 'TECH_MGR', name: 'Technical Manager', levelId: 'lvl_mgr' },
  { id: 'pos_aplus_dir', tenantId: 'tenant_aplus', departmentId: 'dept_aplus_ops', code: 'DIRECTOR', name: 'Managing Director', levelId: 'lvl_dir' },

  // ABC
  { id: 'pos_abc_mkt_mgr', tenantId: 'tenant_abc', departmentId: 'dept_abc_mkt', code: 'MKT_MGR', name: 'Marketing Manager', levelId: 'lvl_mgr' },

  // XYZ
  { id: 'pos_xyz_oper_lead', tenantId: 'tenant_xyz', departmentId: 'dept_xyz_ops', code: 'OPER_LEAD', name: 'Operations Leader', levelId: 'lvl_lead' },
];

/**
 * 05. ROLES & SCOPES (Control DB: CRM_CORE.roles)
 * Quy chuẩn Scopes: OWN (Cá nhân) | TEAM (Đội nhóm) | DEPARTMENT (Phòng ban) | COMPANY (Toàn công ty)
 */
const DEFAULT_PERMISSIONS_MATRIX = (scope: 'OWN' | 'TEAM' | 'DEPARTMENT' | 'COMPANY'): ModulePermission[] => [
  { module: 'Customer', moduleLabel: 'Khách hàng', actions: ['view', 'create', 'edit', 'delete'], scope },
  { module: 'Lead', moduleLabel: 'Khách hàng tiềm năng (Leads)', actions: ['view', 'create', 'edit', 'delete'], scope },
  { module: 'Deal', moduleLabel: 'Cơ hội bán hàng (Deals)', actions: ['view', 'create', 'edit', 'delete'], scope },
  { module: 'Product', moduleLabel: 'Sản phẩm & Giá', actions: ['view', 'create', 'edit'], scope },
  { module: 'Order', moduleLabel: 'Đơn hàng & Hợp đồng', actions: ['view', 'create', 'edit'], scope },
  { module: 'Inventory', moduleLabel: 'Kho & Vật tư', actions: ['view'], scope },
  { module: 'Technical', moduleLabel: 'Khảo sát & Nghiệm thu', actions: ['view'], scope },
  { module: 'Report', moduleLabel: 'Báo cáo & Phân tích', actions: ['view'], scope },
  { module: 'Settings', moduleLabel: 'Cài đặt hệ thống', actions: scope === 'COMPANY' ? ['view', 'edit'] : [], scope },
];

export const INITIAL_ROLES: Role[] = [
  {
    id: 'role_super_admin',
    tenantId: 'tenant_aplus',
    code: 'SUPER_ADMIN',
    name: 'Super Admin Role',
    description: 'Toàn quyền tối cao quản trị nền tảng và mọi chi nhánh doanh nghiệp',
    defaultScope: 'COMPANY',
    permissions: DEFAULT_PERMISSIONS_MATRIX('COMPANY'),
  },
  {
    id: 'role_company_admin',
    tenantId: 'tenant_aplus',
    code: 'COMPANY_ADMIN',
    name: 'Company Admin Role',
    description: 'Toàn quyền cấu hình, phân quyền, quản trị nhân sự và mọi module trong Tenant',
    defaultScope: 'COMPANY',
    permissions: DEFAULT_PERMISSIONS_MATRIX('COMPANY'),
  },
  {
    id: 'role_director',
    tenantId: 'tenant_aplus',
    code: 'DIRECTOR',
    name: 'Board Director Role (Ban Giám Đốc)',
    description: 'Quyền xem toàn bộ báo cáo doanh nghiệp (Sales, P&L, Kho bãi, Logistics, Kỹ thuật)',
    defaultScope: 'COMPANY',
    permissions: DEFAULT_PERMISSIONS_MATRIX('COMPANY'),
  },
  {
    id: 'role_sale_manager',
    tenantId: 'tenant_aplus',
    code: 'SALE_MANAGER',
    name: 'Sales Manager Role (Trưởng Phòng Sale)',
    description: 'Quản lý toàn bộ dữ liệu của cả phòng Kinh Doanh, duyệt đơn hàng và xem báo cáo sales',
    defaultScope: 'DEPARTMENT',
    permissions: DEFAULT_PERMISSIONS_MATRIX('DEPARTMENT'),
  },
  {
    id: 'role_sale_staff',
    tenantId: 'tenant_aplus',
    code: 'SALE_STAFF',
    name: 'Sales Staff Role (Nhân Viên Sale)',
    description: 'Chỉ xem và thao tác trên dữ liệu Khách hàng, Lead và Deal được phân bổ cho cá nhân',
    defaultScope: 'OWN',
    permissions: DEFAULT_PERMISSIONS_MATRIX('OWN'),
  },
  {
    id: 'role_tech_manager',
    tenantId: 'tenant_aplus',
    code: 'TECH_MANAGER',
    name: 'Technical Manager Role',
    description: 'Toàn quyền khối kỹ thuật, khảo sát, bóc tách BOM, phê duyệt vật tư và nghiệm thu',
    defaultScope: 'DEPARTMENT',
    permissions: DEFAULT_PERMISSIONS_MATRIX('DEPARTMENT'),
  },
  {
    id: 'role_sale_leader',
    tenantId: 'tenant_aplus',
    code: 'SALE_LEADER',
    name: 'Sales Leader Role',
    description: 'Quản lý toàn bộ dữ liệu của nhóm phụ trách (Scope: TEAM)',
    defaultScope: 'TEAM',
    permissions: DEFAULT_PERMISSIONS_MATRIX('TEAM'),
  },
  {
    id: 'role_consultant',
    tenantId: 'tenant_abc',
    code: 'CONSULTANT',
    name: 'External Consultant Role',
    description: 'Chuyên gia tư vấn ngoài, xem báo cáo theo phân hệ chỉ định',
    defaultScope: 'DEPARTMENT',
    permissions: DEFAULT_PERMISSIONS_MATRIX('DEPARTMENT'),
  },
  {
    id: 'role_viewer',
    tenantId: 'tenant_xyz',
    code: 'VIEWER',
    name: 'Read-only Viewer Role',
    description: 'Chỉ xem dữ liệu ở chế độ đọc, không được chỉnh sửa',
    defaultScope: 'OWN',
    permissions: DEFAULT_PERMISSIONS_MATRIX('OWN'),
  },
];

/**
 * 06. USERS (Control DB: CRM_CORE.users)
 * Định danh duy nhất toàn cầu (user_id = UUID).
 */
export const INITIAL_ACCOUNTS: UserAccount[] = [
  {
    id: 'usr_huy_72jd',
    email: 'huy.nk@apluscorp.vn',
    fullName: 'Nguyễn Khắc Huy',
    phone: '0988 270 999',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces',
    passwordHash: 'password123',
    isPlatformAdmin: true, // Super Admin toàn nền tảng
    status: 'active',
    failedAttempts: 0,
    createdAt: '2026-01-10',
  },
  {
    id: 'usr_chau_81ks',
    email: 'chau.hm@apluscorp.vn',
    fullName: 'Hồ Minh Châu',
    phone: '0909 888 777',
    avatar: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=100&h=100&fit=crop&crop=faces',
    passwordHash: 'password123',
    isPlatformAdmin: false,
    status: 'active',
    failedAttempts: 0,
    createdAt: '2026-01-15',
  },
  {
    id: 'usr_thanh_93la',
    email: 'thanh.nn@apluscorp.vn',
    fullName: 'Nguyễn Nhật Thanh',
    phone: '0918 333 444',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=faces',
    passwordHash: 'password123',
    isPlatformAdmin: false,
    status: 'active',
    failedAttempts: 0,
    createdAt: '2026-02-01',
  },
  {
    id: 'usr_long_41pb',
    email: 'long.hh@apluscorp.vn',
    fullName: 'Hồ Hoàng Long',
    phone: '0912 666 888',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=faces',
    passwordHash: 'password123',
    isPlatformAdmin: false,
    status: 'active',
    failedAttempts: 0,
    createdAt: '2026-02-14',
  },
  {
    id: 'usr_vana_62zc',
    email: 'vana.sales@apluscorp.vn',
    fullName: 'Nguyễn Văn A',
    phone: '0933 111 222',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop&crop=faces',
    passwordHash: 'password123',
    isPlatformAdmin: false,
    status: 'active',
    failedAttempts: 0,
    createdAt: '2026-03-01',
  },
  // User thuộc Tenant ABC
  {
    id: 'usr_tranb_55mk',
    email: 'tran.b@abctech.vn',
    fullName: 'Trần Văn B',
    phone: '0977 444 888',
    avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100&h=100&fit=crop&crop=faces',
    passwordHash: 'password123',
    isPlatformAdmin: false,
    status: 'active',
    failedAttempts: 0,
    createdAt: '2026-03-25',
  },
  // User thuộc Tenant XYZ
  {
    id: 'usr_lethic_78op',
    email: 'lethic@xyzcorp.vn',
    fullName: 'Lê Thị C',
    phone: '0944 555 666',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100&h=100&fit=crop&crop=faces',
    passwordHash: 'password123',
    isPlatformAdmin: false,
    status: 'active',
    failedAttempts: 0,
    createdAt: '2026-08-05',
  },
  // Multi-Tenant User: Nguyễn Văn B (Có membership ở cả 3 công ty: APLUS, ABC, XYZ)
  {
    id: 'usr_nguyenvanb_multi',
    email: 'b.nguyen@multicorp.vn',
    fullName: 'Nguyễn Văn B (Cố vấn đa công ty)',
    phone: '0912 345 678',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=faces',
    passwordHash: 'password123',
    isPlatformAdmin: false,
    status: 'active',
    failedAttempts: 0,
    createdAt: '2026-01-20',
  },
  {
    id: 'usr_nguyenvanb_alias',
    email: 'vanb.consult@global.vn',
    fullName: 'Nguyễn Văn B (Cố vấn đa công ty)',
    phone: '0912 345 678',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=faces',
    passwordHash: 'password123',
    isPlatformAdmin: false,
    status: 'active',
    failedAttempts: 0,
    createdAt: '2026-01-20',
  },
];

/**
 * 07. MEMBERSHIPS (Control DB: CRM_CORE.memberships)
 * Quan hệ giữa User và Tenant.
 * - UUID hệ thống: membership_id
 * - Human-readable: Employee Code (0001), Username (SALE-0001), Display ID (APLUS-SALE-0001)
 */
export const INITIAL_MEMBERSHIPS: Membership[] = [
  // --- TENANT APLUS ---
  {
    id: 'mem_huy_aplus',
    tenantId: 'tenant_aplus',
    userId: 'usr_huy_72jd',
    departmentId: 'dept_aplus_ops',
    positionId: 'pos_aplus_dir',
    levelId: 'lvl_dir',
    roleId: 'role_super_admin',
    employeeCode: '0001',
    username: 'SUPERADMIN-0001',
    displayId: 'APLUS-SUPERADMIN-0001',
    roleTitle: 'Super Admin',
    status: 'active',
    joinedAt: '2026-01-10',
    permissions: DEFAULT_PERMISSIONS_MATRIX('COMPANY'),
  },
  {
    id: 'mem_chau_aplus',
    tenantId: 'tenant_aplus',
    userId: 'usr_chau_81ks',
    departmentId: 'dept_aplus_ops',
    positionId: 'pos_aplus_dir',
    levelId: 'lvl_dir',
    roleId: 'role_director',
    employeeCode: '0002',
    username: 'DIR-0001',
    displayId: 'APLUS-DIR-0001',
    roleTitle: 'Ban Giám Đốc',
    status: 'active',
    joinedAt: '2026-01-15',
    permissions: DEFAULT_PERMISSIONS_MATRIX('COMPANY'),
  },
  {
    id: 'mem_thanh_aplus',
    tenantId: 'tenant_aplus',
    userId: 'usr_thanh_93la',
    departmentId: 'dept_aplus_tech',
    positionId: 'pos_aplus_tech_mgr',
    levelId: 'lvl_mgr',
    roleId: 'role_company_admin',
    employeeCode: '0003',
    username: 'ADMIN-0001',
    displayId: 'APLUS-ADMIN-0001',
    roleTitle: 'Admin',
    status: 'active',
    joinedAt: '2026-02-01',
    permissions: DEFAULT_PERMISSIONS_MATRIX('COMPANY'),
  },
  {
    id: 'mem_long_aplus',
    tenantId: 'tenant_aplus',
    userId: 'usr_long_41pb',
    departmentId: 'dept_aplus_sale',
    positionId: 'pos_aplus_sale_mgr',
    levelId: 'lvl_mgr',
    roleId: 'role_sale_manager',
    employeeCode: '0004',
    username: 'SALE-0002',
    displayId: 'APLUS-SALE-0002',
    roleTitle: 'Trưởng Phòng Sale',
    status: 'active',
    joinedAt: '2026-02-14',
    permissions: DEFAULT_PERMISSIONS_MATRIX('DEPARTMENT'),
  },
  {
    id: 'mem_vana_aplus',
    tenantId: 'tenant_aplus',
    userId: 'usr_vana_62zc',
    departmentId: 'dept_aplus_sale',
    positionId: 'pos_aplus_sale_exec',
    levelId: 'lvl_staff',
    roleId: 'role_sale_staff',
    employeeCode: '0005',
    username: 'SALE-0001',
    displayId: 'APLUS-SALE-0001',
    roleTitle: 'Nhân Viên Sale',
    status: 'active',
    joinedAt: '2026-03-01',
    permissions: DEFAULT_PERMISSIONS_MATRIX('OWN'),
  },
  // Multi-tenant: Nguyễn Văn B tại APLUS (Role Admin)
  {
    id: 'mem_vanb_aplus',
    tenantId: 'tenant_aplus',
    userId: 'usr_nguyenvanb_multi',
    departmentId: 'dept_aplus_ops',
    positionId: 'pos_aplus_dir',
    levelId: 'lvl_dir',
    roleId: 'role_company_admin',
    employeeCode: '0002',
    username: 'ADMIN-0002',
    displayId: 'APLUS-ADMIN-0002',
    roleTitle: 'Cố Vấn Ban Điều Hành APLUS',
    status: 'active',
    joinedAt: '2026-01-20',
    permissions: DEFAULT_PERMISSIONS_MATRIX('COMPANY'),
  },

  // --- TENANT ABC ---
  {
    id: 'mem_tranb_abc',
    tenantId: 'tenant_abc',
    userId: 'usr_tranb_55mk',
    departmentId: 'dept_abc_mkt',
    positionId: 'pos_abc_mkt_mgr',
    levelId: 'lvl_mgr',
    roleId: 'role_sale_manager',
    employeeCode: '0005',
    username: 'MKT-0005',
    displayId: 'ABC-MKT-0005',
    roleTitle: 'Marketing Manager ABC',
    status: 'active',
    joinedAt: '2026-03-25',
    permissions: DEFAULT_PERMISSIONS_MATRIX('DEPARTMENT'),
  },
  // Multi-tenant: Nguyễn Văn B tại ABC (Role Consultant)
  {
    id: 'mem_vanb_abc',
    tenantId: 'tenant_abc',
    userId: 'usr_nguyenvanb_multi',
    departmentId: 'dept_abc_sale',
    positionId: 'pos_abc_mkt_mgr',
    levelId: 'lvl_mgr',
    roleId: 'role_consultant',
    employeeCode: '0001',
    username: 'CONSULT-0001',
    displayId: 'ABC-CONSULT-0001',
    roleTitle: 'Chuyên Gia Tư Vấn ABC',
    status: 'active',
    joinedAt: '2026-04-01',
    permissions: DEFAULT_PERMISSIONS_MATRIX('DEPARTMENT'),
  },

  // --- TENANT XYZ ---
  {
    id: 'mem_lethic_xyz',
    tenantId: 'tenant_xyz',
    userId: 'usr_lethic_78op',
    departmentId: 'dept_xyz_ops',
    positionId: 'pos_xyz_oper_lead',
    levelId: 'lvl_lead',
    roleId: 'role_sale_leader',
    employeeCode: '0001',
    username: 'OPER-0001',
    displayId: 'XYZ-OPER-0001',
    roleTitle: 'Operations Leader XYZ',
    status: 'active',
    joinedAt: '2026-08-05',
    permissions: DEFAULT_PERMISSIONS_MATRIX('TEAM'),
  },
  // Multi-tenant: Nguyễn Văn B tại XYZ (Role Viewer)
  {
    id: 'mem_vanb_xyz',
    tenantId: 'tenant_xyz',
    userId: 'usr_nguyenvanb_multi',
    departmentId: 'dept_xyz_ops',
    positionId: 'pos_xyz_oper_lead',
    levelId: 'lvl_staff',
    roleId: 'role_viewer',
    employeeCode: '0001',
    username: 'VIEW-0001',
    displayId: 'XYZ-VIEW-0001',
    roleTitle: 'Thành Viên Đọc Dữ Liệu XYZ',
    status: 'active',
    joinedAt: '2026-08-10',
    permissions: DEFAULT_PERMISSIONS_MATRIX('OWN'),
  },
];

// Alias giữ tương thích ngược
export const INITIAL_COMPANY_MEMBERS = INITIAL_MEMBERSHIPS.map((m) => ({
  ...m,
  accountId: m.userId,
  companyId: m.tenantId,
  roleGroupId: m.roleId,
}));

export const INITIAL_JOIN_REQUESTS: JoinRequest[] = [
  {
    id: 'req-01',
    companyId: 'tenant_aplus',
    accountId: 'usr_tranb_55mk',
    fullName: 'Trần Văn B',
    email: 'tran.b@abctech.vn',
    phone: '0977 444 888',
    requestedAt: '2026-10-06 14:30',
    status: 'pending',
    roleGroupId: 'role_sale_staff',
  },
];

export const INITIAL_INVITATIONS: CompanyInvitation[] = [
  {
    id: 'inv-01',
    companyId: 'tenant_aplus',
    code: 'INV-APLUS-884K',
    roleGroupId: 'role_sale_staff',
    roleTitle: 'Chuyên Viên Kinh Doanh B2B',
    expiresAt: '2026-10-20',
    maxUses: 10,
    usedCount: 3,
    createdAt: '2026-10-01',
    createdBy: 'Nguyễn Khắc Huy',
    status: 'active',
    linkUrl: 'https://aplus.crm.aplus.vn/join?code=INV-APLUS-884K',
  },
];

export const INITIAL_PLATFORM_CONFIG: PlatformConfig = {
  allowNewCompanyRegistration: true,
  maxCompaniesAllowed: 500,
  platformNotice: 'Hạ tầng Database Isolation A+ CRM v3.4 đang hoạt động bình thường. Phân giải CSDL thời gian thực độc lập 100%.',
  activeControlDb: 'CRM_CORE',
  totalDatabasesOnline: 3,
};
