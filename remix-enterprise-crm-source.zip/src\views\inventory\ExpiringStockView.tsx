import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { ProductLot } from '../../data/mockWarehouseData';
import {
  CalendarClock,
  AlertTriangle,
  Clock,
  DollarSign,
  Search,
  Filter,
  FileSpreadsheet,
  ArrowRight,
  TrendingDown,
  RotateCcw,
  Percent,
  CheckCircle2,
  Trash2,
  Bell,
} from 'lucide-react';

export interface ExpiringStockViewProps {
  viewMode?: 'warehouse' | 'logistics';
}

export const ExpiringStockView: React.FC<ExpiringStockViewProps> = ({ viewMode = 'warehouse' }) => {
  const { themeDef, showToast, setActiveModule } = useCRM();
  const { lots, warehouses, quickReassignLotAction } = useWarehouse();

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('all');
  const [selectedUrgency, setSelectedUrgency] = useState<string>('all');

  // Configurable Alert Thresholds (ngày)
  const [threshold30, setThreshold30] = useState(30);
  const [threshold60, setThreshold60] = useState(60);
  const [threshold90, setThreshold90] = useState(90);
  const [configModalOpen, setConfigModalOpen] = useState(false);

  const nowTime = new Date('2026-10-04').getTime();

  // Helper to calculate days remaining
  const getDaysRemaining = (expDate: string): number => {
    const exp = new Date(expDate).getTime();
    return Math.ceil((exp - nowTime) / (1000 * 60 * 60 * 24));
  };

  // Helper to get urgency level
  const getUrgencyLevel = (days: number): 'expired' | 'urgent_30' | 'warning_60' | 'notice_90' | 'safe' => {
    if (days <= 0) return 'expired';
    if (days <= threshold30) return 'urgent_30';
    if (days <= threshold60) return 'warning_60';
    if (days <= threshold90) return 'notice_90';
    return 'safe';
  };

  // Enriched Lots with Days remaining & Urgency
  const enrichedLots = lots.map((l) => {
    const days = getDaysRemaining(l.expiryDate);
    const urgency = getUrgencyLevel(days);
    const totalValue = l.quantity * l.unitCost;
    return {
      ...l,
      daysRemaining: days,
      urgency,
      totalValue,
    };
  });

  // KPI Calculations
  const expiredCount = enrichedLots.filter((l) => l.urgency === 'expired').length;
  const in30DaysCount = enrichedLots.filter((l) => l.urgency === 'urgent_30').length;
  const in60DaysCount = enrichedLots.filter((l) => l.urgency === 'warning_60').length;
  const in90DaysCount = enrichedLots.filter((l) => l.urgency === 'notice_90').length;
  const atRiskTotalValue = enrichedLots
    .filter((l) => l.urgency !== 'safe')
    .reduce((sum, l) => sum + l.totalValue, 0);

  // Filtered Lots
  const filteredLots = enrichedLots.filter((l) => {
    if (selectedWarehouseId !== 'all' && l.warehouseId !== selectedWarehouseId) return false;
    if (selectedUrgency !== 'all' && l.urgency !== selectedUrgency) return false;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const match =
        l.productName.toLowerCase().includes(q) ||
        l.sku.toLowerCase().includes(q) ||
        l.lotNumber.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  const handleAction = (lotId: string, actionType: 'sell' | 'discount' | 'return' | 'waste') => {
    quickReassignLotAction(lotId, actionType);
    if (actionType === 'waste') {
      setActiveModule('inventory-stock-out');
    }
  };

  const handleExportExcel = () => {
    showToast('Xuất báo cáo lô hàng', 'Đang tải xuống tệp Excel cảnh báo hạn sử dụng lô hàng.', 'success');
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Alert Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-200 dark:border-amber-800">
              <CalendarClock className="w-5 h-5" />
            </span>
            {viewMode === 'logistics' ? 'Hàng Sắp Hết Hạn (Góc nhìn Vận chuyển)' : 'Quản lý Hàng sắp hết hạn (Approaching Expiry)'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {viewMode === 'logistics'
              ? 'Cảnh báo các lô hàng cận hạn sử dụng theo nguyên tắc FEFO để ưu tiên xuất giao sớm hoặc hoàn trả nhà cung cấp.'
              : 'Theo dõi chi tiết từng lô hàng, cảnh báo rủi ro cận hạn (FEFO) và tự động kích hoạt hành động xử lý'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setConfigModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 shadow-xs"
          >
            <Clock className="w-3.5 h-3.5 text-sky-600" />
            <span>Cấu hình ngưỡng ({threshold30}/{threshold60}/{threshold90} ngày)</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Xuất Excel</span>
          </button>
        </div>
      </div>

      {/* Bell Alert Notification for Warehouse Manager */}
      {(expiredCount > 0 || in30DaysCount > 0) && (
        <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 flex items-center justify-between text-xs text-amber-900 dark:text-amber-200 shadow-xs">
          <div className="flex items-center gap-2.5">
            <span className="p-1.5 rounded-lg bg-amber-500 text-white animate-bounce">
              <Bell className="w-4 h-4" />
            </span>
            <div>
              <p className="font-bold">
                Cảnh báo khẩn cấp: Có {expiredCount} lô đã hết hạn và {in30DaysCount} lô hết hạn trong vòng 30 ngày!
              </p>
              <p className="text-[11px] text-amber-700 dark:text-amber-300">
                Thủ kho cần ưu tiên duyệt phiếu xuất bán hoặc lập biên bản xuất hủy để tránh thất thoát vốn.
              </p>
            </div>
          </div>

          <button
            onClick={() => setSelectedUrgency('urgent_30')}
            className="px-3 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shrink-0 shadow-xs"
          >
            Xử lý ngay →
          </button>
        </div>
      )}

      {/* 5 KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
        {/* Đã hết hạn */}
        <div className="bg-rose-50 dark:bg-rose-950/50 border border-rose-300 dark:border-rose-900 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-rose-800 dark:text-rose-300">
            <span className="text-[11px] font-bold uppercase">Đã hết hạn</span>
            <AlertTriangle className="w-4 h-4 text-rose-600 animate-pulse" />
          </div>
          <h3 className="text-2xl font-bold text-rose-700 dark:text-rose-300 mt-1 font-mono">
            {expiredCount} Lô
          </h3>
          <p className="text-[10px] text-rose-600/90 mt-0.5">Bắt buộc lập phiếu hủy</p>
        </div>

        {/* Hết hạn <= 30 ngày */}
        <div className="bg-white dark:bg-slate-900 border border-rose-200 dark:border-rose-900/60 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-rose-600">
            <span className="text-[11px] font-semibold">Trong ≤ 30 ngày</span>
            <Clock className="w-4 h-4" />
          </div>
          <h3 className="text-2xl font-bold text-rose-600 mt-1 font-mono">
            {in30DaysCount} Lô
          </h3>
          <p className="text-[10px] text-slate-400 mt-0.5">Khẩn cấp xả hàng</p>
        </div>

        {/* Hết hạn <= 60 ngày */}
        <div className="bg-white dark:bg-slate-900 border border-amber-200 dark:border-amber-900/60 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-amber-600">
            <span className="text-[11px] font-semibold">Trong ≤ 60 ngày</span>
            <Clock className="w-4 h-4" />
          </div>
          <h3 className="text-2xl font-bold text-amber-600 mt-1 font-mono">
            {in60DaysCount} Lô
          </h3>
          <p className="text-[10px] text-slate-400 mt-0.5">Ưu tiên xuất bán FEFO</p>
        </div>

        {/* Hết hạn <= 90 ngày */}
        <div className="bg-white dark:bg-slate-900 border border-yellow-200 dark:border-yellow-900/60 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-yellow-600">
            <span className="text-[11px] font-semibold">Trong ≤ 90 ngày</span>
            <Clock className="w-4 h-4" />
          </div>
          <h3 className="text-2xl font-bold text-yellow-600 mt-1 font-mono">
            {in90DaysCount} Lô
          </h3>
          <p className="text-[10px] text-slate-400 mt-0.5">Theo dõi lịch cận hạn</p>
        </div>

        {/* Tổng giá trị có nguy cơ */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-[11px] font-semibold">Tổng giá trị nguy cơ</span>
            <DollarSign className="w-4 h-4 text-rose-500" />
          </div>
          <h3 className="text-2xl font-bold text-rose-600 dark:text-rose-400 mt-1 font-mono">
            {(atRiskTotalValue / 1000000).toLocaleString('vi-VN')} Tr
          </h3>
          <p className="text-[10px] text-slate-400 mt-0.5">Cần hành động giải phóng</p>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative max-w-sm w-full">
            <input
              type="text"
              placeholder="Tìm theo mã SKU, tên hàng, số lô..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedWarehouseId}
              onChange={(e) => setSelectedWarehouseId(e.target.value)}
              className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả kho lưu trữ</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>

            <select
              value={selectedUrgency}
              onChange={(e) => setSelectedUrgency(e.target.value)}
              className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả mức cảnh báo</option>
              <option value="expired">Đã hết hạn (Đỏ đậm)</option>
              <option value="urgent_30">≤ 30 ngày (Đỏ)</option>
              <option value="warning_60">≤ 60 ngày (Cam)</option>
              <option value="notice_90">≤ 90 ngày (Vàng)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Lots Table with Action Triggering */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-4 sm:p-5 shadow-xs space-y-4`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">Mã SKU &amp; Tên sản phẩm</th>
                <th className="py-3 px-3">Số Lô</th>
                <th className="py-3 px-3">Kho lưu trữ</th>
                <th className="py-3 px-3 text-right">Số lượng còn</th>
                <th className="py-3 px-3 text-center">Hạn sử dụng</th>
                <th className="py-3 px-3 text-center">Số ngày còn lại</th>
                <th className="py-3 px-3 text-right">Giá trị lô (VND)</th>
                <th className="py-3 px-3 text-center">Mức cảnh báo</th>
                <th className="py-3 px-3 text-center">Hành động đề xuất</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredLots.map((lot) => {
                const isExpired = lot.urgency === 'expired';
                const isUrgent30 = lot.urgency === 'urgent_30';
                const isWarning60 = lot.urgency === 'warning_60';
                const isNotice90 = lot.urgency === 'notice_90';

                return (
                  <tr
                    key={lot.id}
                    className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 ${
                      isExpired ? 'bg-rose-100/30 dark:bg-rose-950/30' : ''
                    }`}
                  >
                    <td className="py-3 px-3">
                      <p className="font-bold text-slate-900 dark:text-white">{lot.productName}</p>
                      <span className="font-mono text-[10px] text-sky-600">{lot.sku}</span>
                    </td>

                    <td className="py-3 px-3 font-mono font-bold text-slate-800 dark:text-slate-200">
                      {lot.lotNumber}
                    </td>

                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                      {lot.warehouseName.replace('Kho ', '')}
                    </td>

                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                      {lot.quantity}
                    </td>

                    <td className="py-3 px-3 text-center font-mono font-bold text-slate-800 dark:text-slate-200">
                      {lot.expiryDate}
                    </td>

                    <td className="py-3 px-3 text-center font-mono font-bold">
                      {lot.daysRemaining <= 0 ? (
                        <span className="text-rose-700 dark:text-rose-400 font-bold">Quá {Math.abs(lot.daysRemaining)} ngày</span>
                      ) : (
                        <span>{lot.daysRemaining} ngày</span>
                      )}
                    </td>

                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                      {(lot.totalValue / 1000000).toLocaleString('vi-VN')} Tr
                    </td>

                    <td className="py-3 px-3 text-center">
                      {isExpired ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-600 text-white animate-pulse">
                          Đã hết hạn
                        </span>
                      ) : isUrgent30 ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                          ≤ 30 ngày (Nguy hiểm)
                        </span>
                      ) : isWarning60 ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300">
                          ≤ 60 ngày (Cảnh báo)
                        </span>
                      ) : isNotice90 ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-yellow-100 text-yellow-800 dark:bg-yellow-950 dark:text-yellow-300">
                          ≤ 90 ngày (Lưu ý)
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                          An toàn
                        </span>
                      )}
                    </td>

                    {/* Hành động đề xuất nhanh */}
                    <td className="py-3 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {isExpired ? (
                          <button
                            onClick={() => handleAction(lot.id, 'waste')}
                            className="px-2.5 py-1 rounded bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-bold shadow-xs flex items-center gap-1"
                          >
                            <Trash2 className="w-3 h-3" /> Xuất hủy
                          </button>
                        ) : isUrgent30 ? (
                          <div className="flex items-center gap-1">
                            <button
                              onClick={() => handleAction(lot.id, 'discount')}
                              className="px-2 py-1 rounded bg-amber-600 hover:bg-amber-700 text-white text-[10px] font-bold"
                              title="Tạo giảm giá khuyến mại đẩy hàng"
                            >
                              Giảm giá
                            </button>
                            <button
                              onClick={() => handleAction(lot.id, 'return')}
                              className="px-2 py-1 rounded border border-slate-300 text-slate-700 dark:text-slate-300 text-[10px] font-semibold"
                              title="Trả lại nhà cung cấp theo hợp đồng"
                            >
                              Trả NCC
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => handleAction(lot.id, 'sell')}
                            className="px-2.5 py-1 rounded bg-sky-600 hover:bg-sky-700 text-white text-[10px] font-bold"
                          >
                            Ưu tiên FEFO
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Threshold Config Modal */}
      {configModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Clock className="w-5 h-5 text-sky-600" />
              Cấu hình ngưỡng cảnh báo hạn dùng
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Điều chỉnh số ngày chạm ngưỡng để hệ thống tự động gắn nhãn mức độ nguy hiểm:
            </p>

            <div className="space-y-3 mb-5 text-xs">
              <div>
                <label className="block font-semibold text-rose-600 mb-1">Mức nguy cấp (Đỏ - ngày)</label>
                <input
                  type="number"
                  value={threshold30}
                  onChange={(e) => setThreshold30(parseInt(e.target.value) || 30)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-amber-600 mb-1">Mức cảnh báo (Cam - ngày)</label>
                <input
                  type="number"
                  value={threshold60}
                  onChange={(e) => setThreshold60(parseInt(e.target.value) || 60)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-yellow-600 mb-1">Mức lưu ý (Vàng - ngày)</label>
                <input
                  type="number"
                  value={threshold90}
                  onChange={(e) => setThreshold90(parseInt(e.target.value) || 90)}
                  className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 font-mono"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setConfigModalOpen(false)}
                className="px-4 py-1.5 text-xs font-semibold rounded-lg bg-[#002659] text-white"
              >
                Lưu cấu hình
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
