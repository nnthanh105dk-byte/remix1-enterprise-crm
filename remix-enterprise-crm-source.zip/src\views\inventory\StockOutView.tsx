import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { useSales } from '../../context/SalesContext';
import { useLogistics } from '../../context/LogisticsContext';
import { StockOutReceipt, StockOutItem } from '../../data/mockWarehouseData';
import {
  ArrowUpFromLine,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Printer,
  Trash2,
  X,
  AlertTriangle,
  Building,
  User,
  AlertCircle,
  Truck,
  RotateCcw,
} from 'lucide-react';

export interface StockOutViewProps {
  viewMode?: 'warehouse' | 'logistics';
}

export const StockOutView: React.FC<StockOutViewProps> = ({ viewMode = 'warehouse' }) => {
  const { themeDef, showToast, setActiveModule } = useCRM();
  const {
    warehouses,
    products,
    lots,
    stockOutReceipts,
    createStockOutReceipt,
    approveStockOutReceipt,
    cancelStockOutReceipt,
  } = useWarehouse();
  const { orders, updateOrder } = useSales();
  const { createDeliveryNoteFromStockOut } = useLogistics();

  const handleApproveStockOut = (r: StockOutReceipt) => {
    approveStockOutReceipt(r.id);
    if (r.orderId) {
      updateOrder(r.orderId, { logisticsStatus: 'Đã xuất kho' });
    }
  };

  const handleCreateDeliveryNoteFromStockOut = (r: StockOutReceipt) => {
    const linkedOrder = orders.find((o) => o.id === r.orderId || o.code === r.dealCode || o.code === r.orderCode);
    const dnItems = r.items.map((it) => ({
      sku: it.sku,
      productName: it.productName,
      unit: 'Bộ',
      quantity: it.quantity,
    }));

    const newDN = createDeliveryNoteFromStockOut(
      linkedOrder?.id || r.orderId || 'ord-sample',
      r.id,
      r.receiptNumber,
      r.customerName || 'Khách hàng A+',
      '0908 999 555',
      'Địa chỉ công trình / giao hàng theo đơn',
      linkedOrder?.totalAmount || r.totalAmount,
      dnItems,
      `Giao hàng từ Phiếu xuất kho ${r.receiptNumber}`
    );

    showToast(
      'Tạo Phiếu giao hàng thành công',
      `Đã lập Phiếu giao hàng ${newDN.code} từ Phiếu xuất ${r.receiptNumber}. Chuyển sang Vận chuyển!`,
      'success'
    );
    setActiveModule('logistics-delivery-notes');
  };

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [printReceipt, setPrintReceipt] = useState<StockOutReceipt | null>(null);

  // Form State for Creating Receipt
  const [formDate, setFormDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [formExportReason, setFormExportReason] = useState<StockOutReceipt['exportReason']>('Bán hàng');
  const [formWarehouseId, setFormWarehouseId] = useState<string>(warehouses[0]?.id || 'wh-hn');
  const [formCustomerName, setFormCustomerName] = useState<string>('Tập đoàn Hoàng Anh Gia Lai');
  const [formDealCode, setFormDealCode] = useState<string>('DEAL-WON-2026-001');
  const [formNotes, setFormNotes] = useState<string>('');
  const [formWasteReason, setFormWasteReason] = useState<string>('');

  // Sample Deals to choose from when reason is "Bán hàng"
  const sampleDeals = [
    { code: 'DEAL-WON-2026-001', customer: 'Tập đoàn Hoàng Anh Gia Lai', title: 'Hệ thống A+ Enterprise CRM' },
    { code: 'DEAL-WON-2026-002', customer: 'Công ty CP May Sông Hồng', title: 'Triển khai ERP Cloud & Kho' },
    { code: 'DEAL-WON-2026-003', customer: 'Logistics Giao Hàng Xanh', title: 'Phân hệ WMS Đa Chi Nhánh' },
  ];

  // Helper: Find FEFO / FIFO suggested lot for SKU in Warehouse
  const getSuggestedLot = (sku: string, whId: string): string => {
    const matchingLots = lots
      .filter((l) => l.sku === sku && l.warehouseId === whId && l.quantity > 0)
      .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());
    return matchingLots[0]?.lotNumber || '';
  };

  const [formItems, setFormItems] = useState<StockOutItem[]>([
    {
      sku: products[0]?.sku || '',
      productName: products[0]?.name || '',
      quantity: 2,
      unitPrice: products[0]?.sellingPrice || 0,
      lotNumber: getSuggestedLot(products[0]?.sku || '', 'wh-hn'),
      total: (products[0]?.sellingPrice || 0) * 2,
    },
  ]);

  // Filtered receipts
  const filteredReceipts = stockOutReceipts.filter((r) => {
    if (selectedWarehouseId !== 'all' && r.warehouseId !== selectedWarehouseId) return false;
    if (selectedStatus !== 'all' && r.status !== selectedStatus) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const match =
        r.receiptNumber.toLowerCase().includes(q) ||
        (r.customerName && r.customerName.toLowerCase().includes(q)) ||
        (r.dealCode && r.dealCode.toLowerCase().includes(q)) ||
        r.createdBy.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Add Item Line
  const handleAddItemLine = () => {
    const firstProd = products[0];
    const lot = getSuggestedLot(firstProd.sku, formWarehouseId);
    setFormItems((prev) => [
      ...prev,
      {
        sku: firstProd.sku,
        productName: firstProd.name,
        quantity: 1,
        unitPrice: firstProd.sellingPrice,
        lotNumber: lot,
        total: firstProd.sellingPrice,
      },
    ]);
  };

  const handleRemoveItemLine = (index: number) => {
    if (formItems.length === 1) return;
    setFormItems((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleItemSkuChange = (index: number, newSku: string) => {
    const selectedProd = products.find((p) => p.sku === newSku);
    if (!selectedProd) return;
    const lot = getSuggestedLot(newSku, formWarehouseId);

    setFormItems((prev) =>
      prev.map((item, idx) =>
        idx === index
          ? {
              ...item,
              sku: selectedProd.sku,
              productName: selectedProd.name,
              unitPrice: selectedProd.sellingPrice,
              lotNumber: lot,
              total: selectedProd.sellingPrice * item.quantity,
            }
          : item
      )
    );
  };

  const handleItemQuantityChange = (index: number, qty: number) => {
    const safeQty = Math.max(1, qty);
    setFormItems((prev) =>
      prev.map((item, idx) =>
        idx === index
          ? {
              ...item,
              quantity: safeQty,
              total: safeQty * item.unitPrice,
            }
          : item
      )
    );
  };

  // Check if quantity exceeds available stock
  const isItemOverStock = (sku: string, qty: number): boolean => {
    const prod = products.find((p) => p.sku === sku);
    if (!prod) return false;
    const currentWhStock = prod.stocks[formWarehouseId] || 0;
    const available = Math.max(0, currentWhStock - prod.reserved);
    return qty > available;
  };

  const hasAnyOverstock = formItems.some((it) => isItemOverStock(it.sku, it.quantity));

  const totalFormQuantity = formItems.reduce((sum, item) => sum + item.quantity, 0);
  const totalFormAmount = formItems.reduce((sum, item) => sum + item.total, 0);

  const handleSubmitCreateReceipt = (e: React.FormEvent) => {
    e.preventDefault();
    if (hasAnyOverstock) {
      showToast('Cảnh báo xuất âm', 'Có sản phẩm vượt quá tồn kho khả dụng! Vui lòng điều chỉnh số lượng.', 'error');
      return;
    }
    if (formExportReason === 'Xuất hủy' && !formWasteReason.trim()) {
      showToast('Thiếu thông tin', 'Lý do xuất hủy là bắt buộc và phải có biên bản thẩm định.', 'error');
      return;
    }

    const wh = warehouses.find((w) => w.id === formWarehouseId);

    createStockOutReceipt({
      date: formDate,
      exportReason: formExportReason,
      warehouseId: formWarehouseId,
      warehouseName: wh ? wh.name : 'Kho Tổng',
      customerName: formExportReason === 'Bán hàng' ? formCustomerName : undefined,
      dealCode: formExportReason === 'Bán hàng' ? formDealCode : undefined,
      notes: formNotes,
      wasteApprovalReason: formExportReason === 'Xuất hủy' ? formWasteReason : undefined,
      items: formItems,
      totalQuantity: totalFormQuantity,
      totalAmount: totalFormAmount,
      createdBy: 'Lê Hoàng Phong (Thủ kho TP.HCM)',
    });

    setCreateModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50">
              <ArrowUpFromLine className="w-5 h-5" />
            </span>
            {viewMode === 'logistics' ? 'Xuất Kho Giao Hàng (Phân hệ Vận chuyển)' : 'Quản lý Xuất kho (Stock Out)'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {viewMode === 'logistics'
              ? 'Xử lý phiếu xuất từ đơn hàng Sales đã xác nhận, đối soát lô hàng FEFO và lập Phiếu giao hàng (PGH).'
              : 'Quy trình xuất kho liên kết chặt chẽ với đơn hàng Sales, tự động gợi ý lô FEFO và chặn xuất âm.'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {viewMode === 'logistics' && (
            <button
              onClick={() => setActiveModule('logistics-delivery-notes')}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-sky-50 dark:bg-sky-950/50 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 hover:bg-sky-100 transition-colors"
            >
              <Truck className="w-4 h-4 text-sky-600" />
              <span>Phiếu giao hàng (PGH)</span>
            </button>
          )}
          <button
            onClick={() => setCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001c42] shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Tạo phiếu xuất mới</span>
          </button>
        </div>
      </div>

      {viewMode === 'logistics' && (
        <div className="bg-sky-50/80 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 rounded-xl p-3.5 flex items-center justify-between text-xs text-sky-900 dark:text-sky-200">
          <div className="flex items-center gap-2.5">
            <Truck className="w-5 h-5 text-sky-600 shrink-0" />
            <div>
              <p className="font-bold">Góc nhìn Logistics &amp; Vận chuyển</p>
              <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                Bộ phận Vận chuyển tiếp nhận đơn hàng đã duyệt từ Sales để xuất kho, trừ tồn khả dụng và gom phiếu giao hàng cho tài xế/đơn vị vận chuyển.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveModule('logistics-order-approval')}
            className="px-3 py-1.5 bg-sky-600 hover:bg-sky-700 text-white rounded-lg font-bold shrink-0 text-xs shadow-xs"
          >
            &larr; Hàng đợi duyệt đơn
          </button>
        </div>
      )}

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative max-w-sm w-full">
            <input
              type="text"
              placeholder="Tìm theo số phiếu, khách hàng, mã deal..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedWarehouseId}
              onChange={(e) => setSelectedWarehouseId(e.target.value)}
              className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả kho xuất</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>

            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="Chờ duyệt">Chờ duyệt</option>
              <option value="Đang soạn hàng">Đang soạn hàng</option>
              <option value="Đã xuất kho">Đã xuất kho (Hoàn tất)</option>
              <option value="Đã hủy">Đã hủy</option>
            </select>
          </div>
        </div>
      </div>

      {/* Receipts Table */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-4 sm:p-5 shadow-xs space-y-4`}>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">Số phiếu</th>
                <th className="py-3 px-3">Ngày xuất</th>
                <th className="py-3 px-3">Lý do xuất</th>
                <th className="py-3 px-3">Kho xuất</th>
                <th className="py-3 px-3">Khách hàng / Đơn hàng</th>
                <th className="py-3 px-3 text-center">Số lượng</th>
                <th className="py-3 px-3 text-right">Tổng giá trị</th>
                <th className="py-3 px-3">Người lập</th>
                <th className="py-3 px-3 text-center">Trạng thái</th>
                <th className="py-3 px-3 text-center">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredReceipts.map((r) => (
                <tr key={r.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="py-3 px-3">
                    <span className="font-mono font-bold text-sky-600">{r.receiptNumber}</span>
                  </td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-400">{r.date}</td>
                  <td className="py-3 px-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      r.exportReason === 'Xuất hủy' ? 'bg-rose-100 text-rose-800' : 'bg-sky-100 text-sky-800'
                    }`}>
                      {r.exportReason}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">{r.warehouseName}</td>
                  <td className="py-3 px-3">
                    <p className="font-bold text-slate-900 dark:text-white">{r.customerName || 'Nội bộ'}</p>
                    {r.dealCode && <span className="font-mono text-[10px] text-sky-600">{r.dealCode}</span>}
                  </td>
                  <td className="py-3 px-3 text-center font-mono font-bold">{r.totalQuantity}</td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                    {(r.totalAmount / 1000000).toLocaleString('vi-VN')} Tr
                  </td>
                  <td className="py-3 px-3 text-slate-500">{r.createdBy.split('(')[0]}</td>
                  <td className="py-3 px-3 text-center">
                    {r.status === 'Đã xuất kho' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        Đã xuất kho
                      </span>
                    ) : r.status === 'Đang soạn hàng' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                        Đang soạn hàng
                      </span>
                    ) : r.status === 'Chờ duyệt' ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 animate-pulse">
                        Chờ duyệt
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                        Đã hủy
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      {(r.status === 'Chờ duyệt' || r.status === 'Đang soạn hàng') && (
                        <button
                          onClick={() => handleApproveStockOut(r)}
                          className="px-2.5 py-1 rounded bg-sky-600 hover:bg-sky-700 text-white text-[11px] font-bold shadow-xs"
                          title="Phê duyệt xuất kho & trừ tồn"
                        >
                          Duyệt xuất
                        </button>
                      )}

                      {r.status === 'Đã xuất kho' && (
                        <button
                          onClick={() => handleCreateDeliveryNoteFromStockOut(r)}
                          className="px-2 py-1 rounded text-sky-600 hover:text-sky-800 hover:bg-sky-50 dark:hover:bg-slate-700 flex items-center gap-1 text-[11px] font-semibold border border-sky-200 dark:border-sky-800"
                          title="Tạo Phiếu giao hàng chuyển sang Vận chuyển"
                        >
                          <Truck className="w-3.5 h-3.5" />
                          <span>Tạo Phiếu Giao</span>
                        </button>
                      )}

                      <button
                        onClick={() => setPrintReceipt(r)}
                        className="p-1 rounded text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100"
                        title="In phiếu xuất kho (PDF)"
                      >
                        <Printer className="w-4 h-4" />
                      </button>

                      {r.status === 'Chờ duyệt' && (
                        <button
                          onClick={() => cancelStockOutReceipt(r.id)}
                          className="p-1 rounded text-rose-500 hover:text-rose-700 hover:bg-rose-50"
                          title="Hủy phiếu"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal: Tạo phiếu xuất kho */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95 my-8">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <ArrowUpFromLine className="w-5 h-5 text-sky-600" />
                Lập Phiếu Xuất Kho Mới
              </h3>
              <button
                onClick={() => setCreateModalOpen(false)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmitCreateReceipt} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Ngày xuất *</label>
                  <input
                    type="date"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    required
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Lý do xuất *</label>
                  <select
                    value={formExportReason}
                    onChange={(e) => setFormExportReason(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-medium"
                  >
                    <option value="Bán hàng">Bán hàng (Xuất theo Deal/Đơn)</option>
                    <option value="Xuất nội bộ">Xuất nội bộ (Bảo hành/Demo)</option>
                    <option value="Xuất hủy">Xuất hủy (Hỏng / Quá hạn)</option>
                    <option value="Trả nhà cung cấp">Trả nhà cung cấp</option>
                    <option value="Chuyển sang kho khác">Chuyển sang kho khác</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Kho xuất hàng *</label>
                  <select
                    value={formWarehouseId}
                    onChange={(e) => setFormWarehouseId(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-medium"
                  >
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name}
                      </option>
                    ))}
                  </select>
                </div>

                {formExportReason === 'Bán hàng' && (
                  <>
                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Chọn Deal / Hợp đồng</label>
                      <select
                        value={formDealCode}
                        onChange={(e) => {
                          const deal = sampleDeals.find((d) => d.code === e.target.value);
                          if (deal) {
                            setFormDealCode(deal.code);
                            setFormCustomerName(deal.customer);
                          }
                        }}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-medium"
                      >
                        {sampleDeals.map((d) => (
                          <option key={d.code} value={d.code}>
                            {d.code} - {d.customer}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Khách hàng nhận</label>
                      <input
                        type="text"
                        value={formCustomerName}
                        onChange={(e) => setFormCustomerName(e.target.value)}
                        className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
                      />
                    </div>
                  </>
                )}

                {formExportReason === 'Xuất hủy' && (
                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-rose-600 mb-1">
                      Lý do xuất hủy &amp; Căn cứ biên bản *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="VD: Hàng hết hạn ngày 01/09/2026 theo Biên bản số BB-09"
                      value={formWasteReason}
                      onChange={(e) => setFormWasteReason(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-rose-300 bg-rose-50/50"
                    />
                  </div>
                )}
              </div>

              {/* Items Table */}
              <div className="space-y-2 pt-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-slate-900 dark:text-white">Dòng hàng xuất &amp; Gợi ý Lô FEFO</h4>
                  <button
                    type="button"
                    onClick={handleAddItemLine}
                    className="text-xs text-sky-600 font-semibold hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> Thêm sản phẩm
                  </button>
                </div>

                <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-x-auto">
                  <table className="w-full text-left text-xs min-w-[650px]">
                    <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-bold">
                      <tr>
                        <th className="py-2 px-2">Chọn sản phẩm (SKU)</th>
                        <th className="py-2 px-2 text-center w-20">Tồn khả dụng</th>
                        <th className="py-2 px-2 text-center w-20">SL Xuất</th>
                        <th className="py-2 px-2 w-32">Gợi ý Lô (FEFO)</th>
                        <th className="py-2 px-2 text-right w-28">Đơn giá bán</th>
                        <th className="py-2 px-2 text-right w-28">Thành tiền</th>
                        <th className="py-2 px-2 text-center w-10">Xóa</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {formItems.map((item, idx) => {
                        const prod = products.find((p) => p.sku === item.sku);
                        const whStock = prod?.stocks[formWarehouseId] || 0;
                        const available = Math.max(0, whStock - (prod?.reserved || 0));
                        const isOver = item.quantity > available;

                        return (
                          <tr key={idx} className={isOver ? 'bg-rose-50/40' : ''}>
                            <td className="py-2 px-2">
                              <select
                                value={item.sku}
                                onChange={(e) => handleItemSkuChange(idx, e.target.value)}
                                className="w-full text-xs px-2 py-1 rounded border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900"
                              >
                                {products.map((p) => (
                                  <option key={p.id} value={p.sku}>
                                    {p.sku} - {p.name}
                                  </option>
                                ))}
                              </select>
                            </td>

                            <td className="py-2 px-2 text-center font-mono font-bold text-sky-600">
                              {available}
                            </td>

                            <td className="py-2 px-2">
                              <input
                                type="number"
                                min="1"
                                value={item.quantity}
                                onChange={(e) => handleItemQuantityChange(idx, parseInt(e.target.value) || 1)}
                                className={`w-full text-center px-1 py-1 rounded border font-mono ${
                                  isOver ? 'border-rose-500 bg-rose-50 text-rose-700' : 'border-slate-300'
                                }`}
                              />
                            </td>

                            <td className="py-2 px-2">
                              <input
                                type="text"
                                placeholder="Lô FEFO gợi ý"
                                value={item.lotNumber || ''}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  setFormItems((prev) =>
                                    prev.map((it, i) => (i === idx ? { ...it, lotNumber: val } : it))
                                  );
                                }}
                                className="w-full px-1.5 py-1 rounded border border-slate-300 font-mono text-[11px]"
                              />
                            </td>

                            <td className="py-2 px-2 text-right font-mono">
                              {item.unitPrice.toLocaleString('vi-VN')} đ
                            </td>

                            <td className="py-2 px-2 text-right font-mono font-bold text-slate-900">
                              {item.total.toLocaleString('vi-VN')} đ
                            </td>

                            <td className="py-2 px-2 text-center">
                              <button
                                type="button"
                                onClick={() => handleRemoveItemLine(idx)}
                                className="text-slate-400 hover:text-rose-500 p-1"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                {hasAnyOverstock && (
                  <div className="p-2.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0" />
                    <span>Cảnh báo: Có sản phẩm xuất vượt quá số dư khả dụng trong kho! Không thể tạo phiếu xuất âm.</span>
                  </div>
                )}
              </div>

              {/* Form Actions */}
              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold rounded-lg text-slate-600 hover:bg-slate-100"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  disabled={hasAnyOverstock}
                  className="px-5 py-2 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001c42] shadow-xs disabled:opacity-50"
                >
                  Tạo &amp; Chuyển duyệt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: In Phiếu Xuất Kho (PDF Print Preview) */}
      {printReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-xl max-w-2xl w-full p-8 shadow-2xl border border-slate-200 print:p-0 animate-in fade-in zoom-in-95 my-8">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-6 print:hidden">
              <span className="text-xs font-bold text-slate-500 uppercase">Mẫu phiếu xuất kho tiêu chuẩn (Mẫu số 02 - VT)</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 bg-[#002659] text-white rounded text-xs font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <Printer className="w-3.5 h-3.5" /> In phiếu
                </button>
                <button
                  onClick={() => setPrintReceipt(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="text-center space-y-1 mb-6">
              <p className="text-xs uppercase font-bold tracking-wider text-slate-500">CÔNG TY CỔ PHẦN CÔNG NGHỆ A+ VIỆT NAM</p>
              <h2 className="text-xl font-bold uppercase tracking-tight">PHIẾU XUẤT KHO</h2>
              <p className="text-xs text-slate-500">
                Ngày {printReceipt.date.split('-')[2]} tháng {printReceipt.date.split('-')[1]} năm {printReceipt.date.split('-')[0]}
              </p>
              <p className="text-xs font-mono font-bold text-sky-700">Số: {printReceipt.receiptNumber}</p>
            </div>

            <div className="text-xs space-y-1.5 mb-5 leading-relaxed">
              <p>- Họ và tên người nhận hàng: <strong>{printReceipt.customerName || 'Nội bộ công ty'}</strong></p>
              <p>- Xuất tại kho: <strong>{printReceipt.warehouseName}</strong></p>
              <p>- Lý do xuất: <strong>{printReceipt.exportReason} {printReceipt.dealCode ? `(Deal: ${printReceipt.dealCode})` : ''}</strong></p>
              {printReceipt.wasteApprovalReason && (
                <p className="text-rose-700">- Căn cứ xuất hủy: <strong>{printReceipt.wasteApprovalReason}</strong></p>
              )}
            </div>

            <table className="w-full text-left text-xs border-collapse border border-slate-300 mb-6">
              <thead className="bg-slate-100 font-bold">
                <tr>
                  <th className="border border-slate-300 p-2 text-center w-8">STT</th>
                  <th className="border border-slate-300 p-2">Tên sản phẩm &amp; Mã SKU</th>
                  <th className="border border-slate-300 p-2 text-center w-24">Số Lô FEFO</th>
                  <th className="border border-slate-300 p-2 text-center w-16">SL</th>
                  <th className="border border-slate-300 p-2 text-right w-24">Đơn giá</th>
                  <th className="border border-slate-300 p-2 text-right w-28">Thành tiền</th>
                </tr>
              </thead>
              <tbody>
                {printReceipt.items.map((it, idx) => (
                  <tr key={idx}>
                    <td className="border border-slate-300 p-2 text-center">{idx + 1}</td>
                    <td className="border border-slate-300 p-2">
                      <p className="font-bold">{it.productName}</p>
                      <span className="font-mono text-[10px] text-slate-500">{it.sku}</span>
                    </td>
                    <td className="border border-slate-300 p-2 text-center font-mono">{it.lotNumber || '-'}</td>
                    <td className="border border-slate-300 p-2 text-center font-bold font-mono">{it.quantity}</td>
                    <td className="border border-slate-300 p-2 text-right font-mono">{it.unitPrice.toLocaleString('vi-VN')} đ</td>
                    <td className="border border-slate-300 p-2 text-right font-mono font-bold">{it.total.toLocaleString('vi-VN')} đ</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="grid grid-cols-4 gap-2 text-center text-xs pt-4 mb-8">
              <div>
                <p className="font-bold">Người lập phiếu</p>
                <div className="h-16" />
                <p className="font-semibold">{printReceipt.createdBy.split('(')[0]}</p>
              </div>
              <div>
                <p className="font-bold">Người nhận hàng</p>
                <div className="h-16" />
                <p className="font-semibold">Đại diện khách</p>
              </div>
              <div>
                <p className="font-bold">Thủ kho</p>
                <div className="h-16" />
                <p className="font-semibold">Lê Hoàng Phong</p>
              </div>
              <div>
                <p className="font-bold">Giám đốc duyệt</p>
                <div className="h-16" />
                <p className="font-semibold">Trần Văn Duyệt</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
