import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { useTechnical } from '../../context/TechnicalContext';
import { TechnicalProject, ProjectTask, TaskStatus } from '../../types/technical';
import {
  FolderKanban,
  Calendar,
  ListFilter,
  Kanban,
  Plus,
  Search,
  Clock,
  User,
  CheckCircle2,
  AlertTriangle,
  Package,
  Layers,
  Check,
  X,
  Building,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

export const TechnicalMasterPlanningView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { products } = useWarehouse();
  const {
    projects,
    updateProjectTaskStatus,
    addProjectMaterialRequest,
  } = useTechnical();

  // 4 View Modes: gantt | calendar | list | kanban
  const [viewMode, setViewMode] = useState<'gantt' | 'calendar' | 'list' | 'kanban'>('gantt');
  const [searchTerm, setSearchTerm] = useState('');
  const [techFilter, setTechFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');

  // Selected Project for Detail Drawer
  const [selectedProject, setSelectedProject] = useState<TechnicalProject | null>(projects[0] || null);

  // Material Request Modal
  const [isMatModalOpen, setIsMatModalOpen] = useState(false);
  const [matSku, setMatSku] = useState(products[0]?.sku || 'HPE-DL380-G10');
  const [matQty, setMatQty] = useState(2);

  const filteredProjects = projects.filter((p) => {
    if (statusFilter !== 'all' && p.status !== statusFilter) return false;
    if (techFilter !== 'all' && !p.teamMembers.includes(techFilter) && p.projectManager !== techFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        p.code.toLowerCase().includes(q) ||
        p.title.toLowerCase().includes(q) ||
        p.customerName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleTaskStatusChange = (projectId: string, taskId: string, newStatus: TaskStatus) => {
    const prog = newStatus === 'Hoàn thành' ? 100 : newStatus === 'Đang làm' ? 50 : 0;
    updateProjectTaskStatus(projectId, taskId, newStatus, prog);

    if (selectedProject?.id === projectId) {
      setSelectedProject((prev) => {
        if (!prev) return null;
        const updatedPhases = prev.phases.map((ph) => ({
          ...ph,
          tasks: ph.tasks.map((t) => (t.id === taskId ? { ...t, status: newStatus, progress: prog } : t)),
        }));
        return { ...prev, phases: updatedPhases };
      });
    }
  };

  const handleAddMaterialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProject) return;
    const prod = products.find((p) => p.sku === matSku);
    if (!prod) return;

    addProjectMaterialRequest(selectedProject.id, prod.sku, prod.name, prod.unit, matQty);
    setIsMatModalOpen(false);
  };

  // Gom tất cả tasks của dự án đã chọn
  const allTasks = selectedProject
    ? selectedProject.phases.flatMap((ph) => ph.tasks.map((t) => ({ ...t, phaseName: ph.name })))
    : [];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50">
              <FolderKanban className="w-5 h-5" />
            </span>
            Kế Hoạch Tổng Thể &amp; Dự Án Kỹ Thuật (Master Planning)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Điều phối toàn bộ dự án lắp đặt, lịch bảo trì định kỳ, phân bổ nhân sự kỹ thuật và kiểm soát yêu cầu vật tư công trình
          </p>
        </div>

        {/* 4 View Modes Switcher */}
        <div className="inline-flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 text-xs shrink-0 font-bold">
          <button
            onClick={() => setViewMode('gantt')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              viewMode === 'gantt'
                ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Tiến độ Gantt</span>
          </button>
          <button
            onClick={() => setViewMode('kanban')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              viewMode === 'kanban'
                ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Kanban className="w-3.5 h-3.5" />
            <span>Kanban Công Việc</span>
          </button>
          <button
            onClick={() => setViewMode('calendar')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              viewMode === 'calendar'
                ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Lịch Nguồn Lực</span>
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all ${
              viewMode === 'list'
                ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <ListFilter className="w-3.5 h-3.5" />
            <span>Danh Sách Dự Án</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="relative max-w-sm w-full">
          <input
            type="text"
            placeholder="Tìm theo mã DA, tên dự án, khách hàng..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-medium"
          >
            <option value="all">Tất cả trạng thái dự án</option>
            <option value="Chưa bắt đầu">Chưa bắt đầu</option>
            <option value="Đang triển khai">Đang triển khai</option>
            <option value="Chờ nghiệm thu">Chờ nghiệm thu</option>
            <option value="Hoàn thành">Hoàn thành</option>
          </select>

          <select
            value={techFilter}
            onChange={(e) => setTechFilter(e.target.value)}
            className="bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-medium"
          >
            <option value="all">Tất cả kỹ sư phụ trách</option>
            <option value="Trần Văn Nam">Trần Văn Nam</option>
            <option value="Nguyễn Văn Tuấn">Nguyễn Văn Tuấn</option>
            <option value="Lê Hữu Đạt">Lê Hữu Đạt</option>
            <option value="Vũ Quốc Bảo">Vũ Quốc Bảo</option>
          </select>
        </div>
      </div>

      {/* Main View Area */}
      {viewMode === 'gantt' && selectedProject && (
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-mono font-bold text-sky-600 bg-sky-50 dark:bg-sky-950 px-2 py-0.5 rounded text-xs">
                  {selectedProject.code}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-700">
                  {selectedProject.status}
                </span>
              </div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                {selectedProject.title}
              </h2>
              <span className="text-xs text-slate-500">Khách hàng: {selectedProject.customerName} &bull; Trưởng dự án: {selectedProject.projectManager}</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsMatModalOpen(true)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-100 text-xs font-semibold flex items-center gap-1.5"
              >
                <Package className="w-3.5 h-3.5 text-amber-600" />
                <span>+ Yêu cầu vật tư công trình</span>
              </button>
              <div className="text-right pl-4 border-l border-slate-200 dark:border-slate-700">
                <span className="text-slate-400 block text-[11px]">Tiến độ tổng thể</span>
                <span className="text-lg font-bold font-mono text-sky-600 dark:text-sky-400">
                  {selectedProject.progressPercent}%
                </span>
              </div>
            </div>
          </div>

          {/* Simple Gantt Bars */}
          <div className="space-y-4">
            {selectedProject.phases.map((phase) => (
              <div key={phase.id} className="space-y-2">
                <h4 className="font-bold text-xs text-slate-800 dark:text-slate-200 bg-slate-50 dark:bg-slate-800/60 p-2 rounded-lg">
                  {phase.name}
                </h4>
                <div className="space-y-2 pl-3">
                  {phase.tasks.map((task) => (
                    <div
                      key={task.id}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                    >
                      <div className="space-y-1 max-w-md">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-900 dark:text-white">{task.title}</span>
                          {task.dependencyTaskId && (
                            <span className="text-[10px] text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded">
                              Phụ thuộc task trước
                            </span>
                          )}
                        </div>
                        <span className="text-[11px] text-slate-400">
                          Phụ trách: {task.assignedTo} &bull; Thời gian: {task.startDate} &rarr; {task.endDate}
                        </span>
                      </div>

                      {/* Bar & Status switcher */}
                      <div className="flex items-center gap-4 shrink-0">
                        <div className="w-32 bg-slate-100 dark:bg-slate-800 h-2.5 rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all ${
                              task.progress === 100 ? 'bg-emerald-600' : 'bg-sky-600'
                            }`}
                            style={{ width: `${task.progress}%` }}
                          />
                        </div>
                        <span className="w-10 text-right font-mono font-bold text-[11px]">{task.progress}%</span>

                        <select
                          value={task.status}
                          onChange={(e) => handleTaskStatusChange(selectedProject.id, task.id, e.target.value as any)}
                          className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-1 text-[11px] font-bold"
                        >
                          <option value="Chưa làm">Chưa làm</option>
                          <option value="Đang làm">Đang làm</option>
                          <option value="Hoàn thành">Hoàn thành</option>
                        </select>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Danh sách yêu cầu vật tư */}
          {selectedProject.materialRequests.length > 0 && (
            <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
              <h4 className="font-bold text-slate-900 dark:text-white text-xs mb-3 flex items-center gap-2">
                <Package className="w-4 h-4 text-amber-600" />
                Vật tư &amp; Linh kiện dự án:
              </h4>
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden text-xs">
                <table className="w-full text-left">
                  <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300">
                    <tr>
                      <th className="p-2.5">Tên Vật Tư / SKU</th>
                      <th className="p-2.5 text-center">Nhu Cầu</th>
                      <th className="p-2.5 text-center">Tồn Khả Dụng</th>
                      <th className="p-2.5">Trạng Thái Điều Phối</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {selectedProject.materialRequests.map((mat) => (
                      <tr key={mat.id}>
                        <td className="p-2.5">
                          <div className="font-bold text-slate-900 dark:text-white">{mat.productName}</div>
                          <span className="font-mono text-[10px] text-slate-400">{mat.sku}</span>
                        </td>
                        <td className="p-2.5 text-center font-mono font-bold">
                          {mat.quantityRequired} {mat.unit}
                        </td>
                        <td className="p-2.5 text-center font-mono">
                          {mat.quantityAvailable} {mat.unit}
                        </td>
                        <td className="p-2.5">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              mat.status === 'Đủ hàng - Đã xuất'
                                ? 'bg-emerald-100 text-emerald-700'
                                : 'bg-rose-100 text-rose-700'
                            }`}
                          >
                            {mat.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Kanban Mode */}
      {viewMode === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {(['Chưa làm', 'Đang làm', 'Hoàn thành'] as TaskStatus[]).map((statusCol) => {
            const colTasks = allTasks.filter((t) => t.status === statusCol);

            return (
              <div
                key={statusCol}
                className="bg-slate-50 dark:bg-slate-900/60 rounded-xl border border-slate-200 dark:border-slate-800 p-4 flex flex-col h-[650px]"
              >
                <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-3">
                  <h3 className="font-bold text-slate-900 dark:text-white text-xs">{statusCol}</h3>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 font-mono">
                    {colTasks.length}
                  </span>
                </div>

                <div className="flex-1 overflow-y-auto space-y-2.5">
                  {colTasks.map((task) => (
                    <div
                      key={task.id}
                      className="bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-xs space-y-2 text-xs"
                    >
                      <span className="text-[10px] text-sky-600 font-bold block">{task.phaseName}</span>
                      <h4 className="font-bold text-slate-900 dark:text-white">{task.title}</h4>
                      <div className="flex justify-between text-[11px] text-slate-400">
                        <span>{task.assignedTo}</span>
                        <span className="font-mono">{task.endDate}</span>
                      </div>
                      <div className="pt-2 border-t border-slate-100 dark:border-slate-700 flex justify-end gap-1">
                        {statusCol !== 'Chưa làm' && (
                          <button
                            onClick={() => selectedProject && handleTaskStatusChange(selectedProject.id, task.id, 'Chưa làm')}
                            className="px-2 py-0.5 text-[10px] text-slate-500 hover:bg-slate-100 rounded"
                          >
                            &larr; Chưa làm
                          </button>
                        )}
                        {statusCol !== 'Đang làm' && (
                          <button
                            onClick={() => selectedProject && handleTaskStatusChange(selectedProject.id, task.id, 'Đang làm')}
                            className="px-2 py-0.5 text-[10px] text-sky-600 hover:bg-sky-50 rounded font-bold"
                          >
                            Đang làm
                          </button>
                        )}
                        {statusCol !== 'Hoàn thành' && (
                          <button
                            onClick={() => selectedProject && handleTaskStatusChange(selectedProject.id, task.id, 'Hoàn thành')}
                            className="px-2 py-0.5 text-[10px] text-emerald-600 hover:bg-emerald-50 rounded font-bold"
                          >
                            Hoàn thành &rarr;
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Calendar Mode (Lịch nguồn lực kỹ sư) */}
      {viewMode === 'calendar' && (
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4 text-xs">
          <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-xl text-amber-900 dark:text-amber-200 flex items-center justify-between">
            <span className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              Lịch điều phối: Phát hiện 0 kỹ sư bị trùng ca bảo trì trong tuần này.
            </span>
            <span className="text-[11px] font-bold">Tháng 10 / 2026</span>
          </div>

          <div className="grid grid-cols-7 gap-2 text-center font-bold pb-2 border-b border-slate-200 dark:border-slate-800">
            {['Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7', 'Chủ Nhật'].map((d) => (
              <div key={d} className="p-2 text-slate-500">{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-2 min-h-[300px]">
            {Array.from({ length: 14 }).map((_, idx) => {
              const day = idx + 1;
              const hasTask = day === 4 || day === 8 || day === 15;

              return (
                <div
                  key={idx}
                  className="p-2 rounded-lg border border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col justify-between h-24 text-left"
                >
                  <span className="font-mono font-bold text-slate-400">{day}/10</span>
                  {hasTask && (
                    <div className="p-1 rounded bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300 text-[10px] font-semibold truncate">
                      {day === 4 ? 'HAGL: Gá Rack Server' : 'Bảo trì HAGL Q3'}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* List Mode */}
      {viewMode === 'list' && (
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden text-xs">
          <table className="w-full text-left">
            <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300">
              <tr>
                <th className="p-3">Mã DA &amp; Tên Dự Án</th>
                <th className="p-3">Khách Hàng</th>
                <th className="p-3">Hợp Đồng</th>
                <th className="p-3">Trưởng Dự Án</th>
                <th className="p-3 text-center">Tiến Độ %</th>
                <th className="p-3">Trạng Thái</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredProjects.map((p) => (
                <tr
                  key={p.id}
                  onClick={() => {
                    setSelectedProject(p);
                    setViewMode('gantt');
                  }}
                  className="hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer"
                >
                  <td className="p-3">
                    <span className="font-mono font-bold text-sky-600 block">{p.code}</span>
                    <span className="font-semibold text-slate-900 dark:text-white">{p.title}</span>
                  </td>
                  <td className="p-3 text-slate-600 dark:text-slate-400">{p.customerName}</td>
                  <td className="p-3 font-mono text-slate-500">{p.contractCode}</td>
                  <td className="p-3 font-medium text-slate-700 dark:text-slate-300">{p.projectManager}</td>
                  <td className="p-3 text-center font-mono font-bold text-sky-600">
                    {p.progressPercent}%
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-700">
                      {p.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Modal: Thêm Yêu Cầu Vật Tư */}
      {isMatModalOpen && selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-sm w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-2">
              Yêu Cầu Vật Tư Cho Dự Án: {selectedProject.code}
            </h3>
            <form onSubmit={handleAddMaterialSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Mặt hàng / Thiết bị *</label>
                <select
                  value={matSku}
                  onChange={(e) => setMatSku(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {products.map((p) => (
                    <option key={p.sku} value={p.sku}>
                      {p.sku} - {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Số lượng yêu cầu *</label>
                <input
                  type="number"
                  min={1}
                  value={matQty}
                  onChange={(e) => setMatQty(Number(e.target.value))}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono font-bold"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsMatModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-3.5 py-1.5 rounded-lg bg-sky-600 text-white font-semibold shadow-xs"
                >
                  Gửi yêu cầu vật tư
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
