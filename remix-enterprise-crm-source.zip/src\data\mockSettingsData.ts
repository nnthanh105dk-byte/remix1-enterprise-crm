import {
  SystemUser,
  PermissionGroup,
  CompanyInfoConfig,
  PrintTemplateConfig,
  DocumentNumberingRule,
  SecurityPolicyConfig,
  WorkingTimeConfig,
  NotificationTemplateConfig,
  IntegrationConnectionConfig,
  AppParameterItem,
  DocumentApprovalRule,
  ApprovalDelegation,
  DictionaryCategory,
  SupplierDirectoryItem,
  WarehouseDirectoryItem,
  BankDirectoryItem,
  VatRateDirectoryItem,
  SyncRunRecord,
  DataImportExportLog,
  SystemAuditLogItem,
} from '../types/settings';

// ==========================================
// 1. NHÓM QUYỀN MẪU (12 NHÓM)
// ==========================================

export const INITIAL_PERMISSION_GROUPS: PermissionGroup[] = [
  {
    id: 'grp-admin',
    code: 'ADMIN',
    name: 'Quản trị hệ thống (System Admin)',
    description: 'Toàn quyền cấu hình, người dùng, phân quyền; mặc định không xem lương, CCCD, hồ sơ BHXH.',
    isSystem: true,
    userCount: 2,
    moduleRules: [
      { moduleId: 'settings', moduleLabel: 'Cài đặt hệ thống', parentGroup: 'Cài đặt hệ thống', actions: ['view', 'create', 'edit', 'delete', 'approve', 'export', 'print'], dataScope: 'all' },
      { moduleId: 'reports', moduleLabel: 'Báo cáo', parentGroup: 'Báo cáo', actions: ['view', 'export'], dataScope: 'all' },
      { moduleId: 'inventory', moduleLabel: 'Quản lý kho', parentGroup: 'Quản lý kho', actions: ['view', 'create', 'edit', 'export'], dataScope: 'all' },
      { moduleId: 'sales', moduleLabel: 'Quản lý Sales', parentGroup: 'Quản lý Sales', actions: ['view', 'create', 'edit', 'export'], dataScope: 'all' },
      { moduleId: 'logistics', moduleLabel: 'Vận chuyển', parentGroup: 'Vận chuyển', actions: ['view', 'create', 'edit', 'export'], dataScope: 'all' },
      { moduleId: 'accounting', moduleLabel: 'Kế toán', parentGroup: 'Kế toán', actions: ['view', 'export'], dataScope: 'all' },
      { moduleId: 'technical', moduleLabel: 'Kỹ thuật', parentGroup: 'Kỹ thuật', actions: ['view', 'create', 'edit', 'export'], dataScope: 'all' },
      { moduleId: 'hr', moduleLabel: 'Quản lý nhân sự', parentGroup: 'Quản lý nhân sự', actions: ['view', 'create', 'edit'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'full' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'hidden' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'masked' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'masked' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'full' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-director',
    code: 'DIRECTOR',
    name: 'Ban Giám Đốc (Board of Directors)',
    description: 'Xem toàn công ty, duyệt cấp cao, xem giá vốn và lợi nhuận, toàn quyền điều hành.',
    isSystem: true,
    userCount: 3,
    moduleRules: [
      { moduleId: 'settings', moduleLabel: 'Cài đặt hệ thống', parentGroup: 'Cài đặt hệ thống', actions: ['view', 'approve', 'export'], dataScope: 'all' },
      { moduleId: 'reports', moduleLabel: 'Báo cáo', parentGroup: 'Báo cáo', actions: ['view', 'export', 'print'], dataScope: 'all' },
      { moduleId: 'sales', moduleLabel: 'Quản lý Sales', parentGroup: 'Quản lý Sales', actions: ['view', 'approve', 'export', 'print'], dataScope: 'all' },
      { moduleId: 'inventory', moduleLabel: 'Quản lý kho', parentGroup: 'Quản lý kho', actions: ['view', 'approve', 'export'], dataScope: 'all' },
      { moduleId: 'logistics', moduleLabel: 'Vận chuyển', parentGroup: 'Vận chuyển', actions: ['view', 'approve', 'export'], dataScope: 'all' },
      { moduleId: 'accounting', moduleLabel: 'Kế toán', parentGroup: 'Kế toán', actions: ['view', 'approve', 'export'], dataScope: 'all' },
      { moduleId: 'technical', moduleLabel: 'Kỹ thuật', parentGroup: 'Kỹ thuật', actions: ['view', 'approve', 'export'], dataScope: 'all' },
      { moduleId: 'hr', moduleLabel: 'Quản lý nhân sự', parentGroup: 'Quản lý nhân sự', actions: ['view', 'approve', 'export'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'full' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'full' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'full' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'full' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'full' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-sales-mgr',
    code: 'SALES_MGR',
    name: 'Trưởng phòng / Trưởng nhóm Sales',
    description: 'Dữ liệu Sales và Báo cáo Sales của phòng/nhóm mình; duyệt chiết khấu cấp 1.',
    isSystem: true,
    userCount: 4,
    moduleRules: [
      { moduleId: 'sales', moduleLabel: 'Quản lý Sales', parentGroup: 'Quản lý Sales', actions: ['view', 'create', 'edit', 'delete', 'approve', 'export', 'print'], dataScope: 'department' },
      { moduleId: 'reports', moduleLabel: 'Báo cáo', parentGroup: 'Báo cáo', actions: ['view', 'export'], dataScope: 'department' },
      { moduleId: 'inventory', moduleLabel: 'Quản lý kho', parentGroup: 'Quản lý kho', actions: ['view'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'masked' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'hidden' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'hidden' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'hidden' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'hidden' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-sales-staff',
    code: 'SALES_STAFF',
    name: 'Nhân viên Sales (Sales Executive)',
    description: 'Dữ liệu cá nhân phụ trách; xem tồn khả dụng; không xem giá vốn.',
    isSystem: true,
    userCount: 18,
    moduleRules: [
      { moduleId: 'sales', moduleLabel: 'Quản lý Sales', parentGroup: 'Quản lý Sales', actions: ['view', 'create', 'edit', 'export', 'print'], dataScope: 'personal' },
      { moduleId: 'reports', moduleLabel: 'Báo cáo', parentGroup: 'Báo cáo', actions: ['view'], dataScope: 'personal' },
      { moduleId: 'inventory', moduleLabel: 'Quản lý kho', parentGroup: 'Quản lý kho', actions: ['view'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'hidden' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'hidden' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'hidden' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'hidden' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'hidden' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-logistics',
    code: 'LOGISTICS',
    name: 'Vận chuyển & Điều phối (Logistics)',
    description: 'Toàn bộ menu Vận chuyển; xem tồn kho; tạo đề nghị thanh toán cước.',
    isSystem: true,
    userCount: 5,
    moduleRules: [
      { moduleId: 'logistics', moduleLabel: 'Vận chuyển', parentGroup: 'Vận chuyển', actions: ['view', 'create', 'edit', 'approve', 'export', 'print'], dataScope: 'all' },
      { moduleId: 'inventory', moduleLabel: 'Quản lý kho', parentGroup: 'Quản lý kho', actions: ['view'], dataScope: 'all' },
      { moduleId: 'sales', moduleLabel: 'Quản lý Sales', parentGroup: 'Quản lý Sales', actions: ['view'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'hidden' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'hidden' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'hidden' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'hidden' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'full' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-warehouse',
    code: 'WAREHOUSE',
    name: 'Thủ kho (Warehouse Keeper)',
    description: 'Quản lý kho, nhập/xuất kho, bàn giao, kiểm kê kho.',
    isSystem: true,
    userCount: 4,
    moduleRules: [
      { moduleId: 'inventory', moduleLabel: 'Quản lý kho', parentGroup: 'Quản lý kho', actions: ['view', 'create', 'edit', 'approve', 'export', 'print'], dataScope: 'all' },
      { moduleId: 'logistics', moduleLabel: 'Vận chuyển', parentGroup: 'Vận chuyển', actions: ['view'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'hidden' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'hidden' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'hidden' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'hidden' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'hidden' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-procurement',
    code: 'PROCUREMENT',
    name: 'Nhân viên Mua hàng (Procurement)',
    description: 'Đơn mua hàng, Hóa đơn mua hàng, tạo phiếu nhập kho và đề nghị thanh toán.',
    isSystem: true,
    userCount: 3,
    moduleRules: [
      { moduleId: 'logistics', moduleLabel: 'Vận chuyển', parentGroup: 'Vận chuyển', actions: ['view', 'create', 'edit', 'export'], dataScope: 'all' },
      { moduleId: 'inventory', moduleLabel: 'Quản lý kho', parentGroup: 'Quản lý kho', actions: ['view', 'create'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'full' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'hidden' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'hidden' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'hidden' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'full' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-driver',
    code: 'DRIVER',
    name: 'Tài xế giao nhận (Driver)',
    description: 'Chỉ chuyến xe, phiếu giao hàng, tiền thu hộ COD của chính mình.',
    isSystem: true,
    userCount: 4,
    moduleRules: [
      { moduleId: 'logistics', moduleLabel: 'Vận chuyển', parentGroup: 'Vận chuyển', actions: ['view', 'edit'], dataScope: 'personal' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'hidden' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'hidden' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'hidden' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'hidden' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'hidden' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-accountant',
    code: 'ACCOUNTANT',
    name: 'Kế toán (Accountant)',
    description: 'Hóa đơn, Phiếu thu, Hóa đơn mua hàng, xác nhận chi đề nghị thanh toán, module Kế toán.',
    isSystem: true,
    userCount: 3,
    moduleRules: [
      { moduleId: 'accounting', moduleLabel: 'Kế toán', parentGroup: 'Kế toán', actions: ['view', 'create', 'edit', 'approve', 'export', 'print'], dataScope: 'all' },
      { moduleId: 'sales', moduleLabel: 'Quản lý Sales', parentGroup: 'Quản lý Sales', actions: ['view', 'export', 'print'], dataScope: 'all' },
      { moduleId: 'logistics', moduleLabel: 'Vận chuyển', parentGroup: 'Vận chuyển', actions: ['view', 'approve', 'export'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'full' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'full' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'full' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'full' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'full' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-technical',
    code: 'TECHNICAL',
    name: 'Kỹ thuật viên & Trưởng kỹ thuật (Technical)',
    description: 'Menu Kỹ thuật (Trưởng duyệt; Kỹ thuật viên chỉ thấy việc của mình).',
    isSystem: true,
    userCount: 11,
    moduleRules: [
      { moduleId: 'technical', moduleLabel: 'Kỹ thuật', parentGroup: 'Kỹ thuật', actions: ['view', 'create', 'edit', 'approve', 'export', 'print'], dataScope: 'team' },
      { moduleId: 'inventory', moduleLabel: 'Quản lý kho', parentGroup: 'Quản lý kho', actions: ['view'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'hidden' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'hidden' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'hidden' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'hidden' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'hidden' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-hr',
    code: 'HR',
    name: 'Quản lý Nhân sự (HR Manager)',
    description: 'Toàn bộ module Quản lý nhân sự, bảo hiểm xã hội, hợp đồng nhân sự.',
    isSystem: true,
    userCount: 2,
    moduleRules: [
      { moduleId: 'hr', moduleLabel: 'Quản lý nhân sự', parentGroup: 'Quản lý nhân sự', actions: ['view', 'create', 'edit', 'approve', 'export', 'print'], dataScope: 'all' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'hidden' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'full' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'full' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'full' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'hidden' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
  {
    id: 'grp-employee',
    code: 'EMPLOYEE',
    name: 'Nhân viên mặc định (Default Employee)',
    description: 'Quyền cơ bản: xem thông báo, xem hồ sơ cá nhân và cập nhật thông tin.',
    isSystem: true,
    userCount: 50,
    moduleRules: [
      { moduleId: 'hr', moduleLabel: 'Quản lý nhân sự', parentGroup: 'Quản lý nhân sự', actions: ['view'], dataScope: 'personal' },
    ],
    fieldRules: [
      { fieldKey: 'costAndMargin', fieldLabel: 'Giá vốn & Biên lợi nhuận', visibility: 'hidden' },
      { fieldKey: 'salaryAndAllowance', fieldLabel: 'Lương & Phụ cấp', visibility: 'masked' },
      { fieldKey: 'employeeIdCardTaxBank', fieldLabel: 'CCCD & Ngân hàng nhân viên', visibility: 'masked' },
      { fieldKey: 'socialInsurance', fieldLabel: 'Mã số & Hồ sơ BHXH', visibility: 'masked' },
      { fieldKey: 'supplierBankInfo', fieldLabel: 'Tài khoản ngân hàng NCC', visibility: 'hidden' },
    ],
    createdAt: '2026-01-01',
    updatedAt: '2026-01-01',
  },
];

// ==========================================
// 2. NGƯỜI DÙNG HỆ THỐNG BAN ĐẦU
// ==========================================

export const INITIAL_SYSTEM_USERS: SystemUser[] = [
  {
    id: 'usr-admin-1',
    employeeId: 'emp-01',
    fullName: 'Trần Minh Đức',
    username: 'admin@apluscorp.vn',
    email: 'admin@apluscorp.vn',
    phone: '0903 123 456',
    avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    departmentName: 'Ban Giám Đốc & Chiến Lược',
    positionName: 'Tổng Giám Đốc',
    roleIds: ['grp-admin', 'grp-director'],
    status: 'active',
    lastLogin: '2026-10-05 18:20:15',
    isSystemAdmin: true,
    activeSessions: [
      { id: 'sess-1', device: 'MacBook Pro (macOS 15.1)', browser: 'Chrome 130', ipAddress: '192.168.1.100', loginTime: '2026-10-05 08:30:00', isCurrent: true },
      { id: 'sess-2', device: 'iPhone 16 Pro (iOS 18)', browser: 'Mobile Safari', ipAddress: '113.190.23.45', loginTime: '2026-10-04 20:15:22', isCurrent: false },
    ],
    loginHistories: [
      { id: 'lh-1', timestamp: '2026-10-05 08:30:00', device: 'MacBook Pro', browser: 'Chrome', ipAddress: '192.168.1.100', status: 'SUCCESS' },
      { id: 'lh-2', timestamp: '2026-10-04 20:15:22', device: 'iPhone 16 Pro', browser: 'Safari', ipAddress: '113.190.23.45', status: 'SUCCESS' },
    ],
    createdAt: '2026-01-01',
  },
  {
    id: 'usr-sales-mgr',
    employeeId: 'emp-02',
    fullName: 'Lê Hoàng Yến',
    username: 'yen.le@apluscorp.vn',
    email: 'yen.le@apluscorp.vn',
    phone: '0912 345 678',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=120&auto=format&fit=crop&q=80',
    departmentName: 'Khối Kinh Doanh B2B & Dự Án',
    positionName: 'Trưởng Khối Kinh Doanh',
    roleIds: ['grp-sales-mgr'],
    status: 'active',
    lastLogin: '2026-10-05 16:45:10',
    activeSessions: [
      { id: 'sess-3', device: 'Dell XPS 15 (Windows 11)', browser: 'Chrome 130', ipAddress: '192.168.1.105', loginTime: '2026-10-05 09:00:00', isCurrent: false },
    ],
    loginHistories: [
      { id: 'lh-3', timestamp: '2026-10-05 09:00:00', device: 'Dell XPS 15', browser: 'Chrome', ipAddress: '192.168.1.105', status: 'SUCCESS' },
    ],
    createdAt: '2026-01-01',
  },
  {
    id: 'usr-tech-lead',
    employeeId: 'emp-03',
    fullName: 'Trần Văn Nam',
    username: 'nam.tran@apluscorp.vn',
    email: 'nam.tran@apluscorp.vn',
    phone: '0988 123 789',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&auto=format&fit=crop&q=80',
    departmentName: 'Phòng Kỹ Thuật & Giải Pháp',
    positionName: 'Trưởng Phòng Kỹ Thuật',
    roleIds: ['grp-technical'],
    status: 'active',
    lastLogin: '2026-10-05 14:10:00',
    activeSessions: [],
    loginHistories: [],
    createdAt: '2026-01-01',
  },
  {
    id: 'usr-wh-mgr',
    employeeId: 'emp-04',
    fullName: 'Vũ Đình Khoa',
    username: 'khoa.vu@apluscorp.vn',
    email: 'khoa.vu@apluscorp.vn',
    phone: '0977 456 123',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=120&auto=format&fit=crop&q=80',
    departmentName: 'Phòng Quản Lý Kho & Vận Chuyển',
    positionName: 'Trưởng Phòng Kho & Logistics',
    roleIds: ['grp-warehouse', 'grp-logistics'],
    status: 'active',
    lastLogin: '2026-10-05 11:30:20',
    activeSessions: [],
    loginHistories: [],
    createdAt: '2026-01-01',
  },
  {
    id: 'usr-hr-lead',
    employeeId: 'emp-05',
    fullName: 'Đặng Thu Thảo',
    username: 'thao.dang@apluscorp.vn',
    email: 'thao.dang@apluscorp.vn',
    phone: '0966 789 456',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&auto=format&fit=crop&q=80',
    departmentName: 'Phòng Tài Chính - Kế Toán & Nhân Sự',
    positionName: 'Trưởng Phòng Nhân Sự',
    roleIds: ['grp-hr'],
    status: 'active',
    lastLogin: '2026-10-05 17:05:40',
    activeSessions: [],
    loginHistories: [],
    createdAt: '2026-01-01',
  },
];

// ==========================================
// 3. CẤU HÌNH HỆ THỐNG (SYSTEM CONFIG)
// ==========================================

export const INITIAL_COMPANY_CONFIG: CompanyInfoConfig = {
  companyName: 'CÔNG TY CỔ PHẦN CÔNG NGHỆ & THƯƠNG MẠI A+ ENTERPRISE',
  shortName: 'A+ ENTERPRISE JSC',
  taxCode: '0108999888',
  legalRepresentative: 'Trần Minh Đức (Tổng Giám Đốc)',
  address: 'Tầng 18, Tòa nhà Keangnam Landmark 72, Đường Phạm Hùng, Q. Nam Từ Liêm, TP. Hà Nội',
  phone: '024 3888 9999 / Hotline: 1900 6868',
  email: 'contact@apluscorp.vn',
  website: 'https://apluscorp.vn',
  bankAccount: '0011009988776',
  bankName: 'Ngân hàng TMCP Ngoại thương Việt Nam (Vietcombank)',
  bankBranch: 'Chi nhánh Sở Giao Dịch - Hà Nội',
  logoUrl: '/logo-aplus-trasparent.png',
  systemIconUrl: '/logo-aplus-trasparent.png',
  primaryColor: '#002659',
  defaultTheme: 'ocean',
  stampSignatureUrl: 'https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=160&auto=format&fit=crop&q=80',
};

export const INITIAL_NUMBERING_RULES: DocumentNumberingRule[] = [
  { id: 'num-lead', docType: 'Lead', docName: 'Khách hàng tiềm năng', prefix: 'LEAD', numberLength: 4, resetYearly: true, currentNumber: 120, sampleFormat: 'LEAD-2026-0120' },
  { id: 'num-kh', docType: 'Customer', docName: 'Khách hàng chính thức', prefix: 'KH', numberLength: 4, resetYearly: false, currentNumber: 85, sampleFormat: 'KH-0085' },
  { id: 'num-ch', docType: 'Opportunity', docName: 'Cơ hội bán hàng', prefix: 'CH', numberLength: 4, resetYearly: true, currentNumber: 64, sampleFormat: 'CH-2026-0064' },
  { id: 'num-bg', docType: 'Quotation', docName: 'Báo giá bán hàng', prefix: 'BG', numberLength: 4, resetYearly: true, currentNumber: 152, sampleFormat: 'BG-2026-0152' },
  { id: 'num-dh', docType: 'SalesOrder', docName: 'Đơn hàng bán', prefix: 'DH', numberLength: 4, resetYearly: true, currentNumber: 88, sampleFormat: 'DH-2026-0088' },
  { id: 'num-hd', docType: 'Contract', docName: 'Hợp đồng kinh tế', prefix: 'HD', numberLength: 4, resetYearly: true, currentNumber: 42, sampleFormat: 'HD-2026-0042' },
  { id: 'num-hdon', docType: 'SalesInvoice', docName: 'Hóa đơn bán hàng', prefix: 'HDON', numberLength: 4, resetYearly: true, currentNumber: 76, sampleFormat: 'HDON-2026-0076' },
  { id: 'num-pt', docType: 'Receipt', docName: 'Phiếu thu tiền', prefix: 'PT', numberLength: 4, resetYearly: true, currentNumber: 110, sampleFormat: 'PT-2026-0110' },
  { id: 'num-dmh', docType: 'PurchaseOrder', docName: 'Đơn mua hàng', prefix: 'DMH', numberLength: 4, resetYearly: true, currentNumber: 35, sampleFormat: 'DMH-2026-0035' },
  { id: 'num-hdm', docType: 'PurchaseInvoice', docName: 'Hóa đơn mua hàng', prefix: 'HDM', numberLength: 4, resetYearly: true, currentNumber: 29, sampleFormat: 'HDM-2026-0029' },
  { id: 'num-pgh', docType: 'DeliveryNote', docName: 'Phiếu giao hàng', prefix: 'PGH', numberLength: 4, resetYearly: true, currentNumber: 94, sampleFormat: 'PGH-2026-0094' },
  { id: 'num-cx', docType: 'Shipment', docName: 'Chuyến xe giao hàng', prefix: 'CX', numberLength: 4, resetYearly: true, currentNumber: 48, sampleFormat: 'CX-2026-0048' },
  { id: 'num-bbg', docType: 'Handover', docName: 'Biên bản bàn giao', prefix: 'BBG', numberLength: 4, resetYearly: true, currentNumber: 52, sampleFormat: 'BBG-2026-0052' },
  { id: 'num-th', docType: 'COD', docName: 'Phiếu thu hộ COD', prefix: 'TH', numberLength: 4, resetYearly: true, currentNumber: 67, sampleFormat: 'TH-2026-0067' },
  { id: 'num-dntt', docType: 'PaymentRequest', docName: 'Đề nghị thanh toán', prefix: 'DNTT', numberLength: 4, resetYearly: true, currentNumber: 83, sampleFormat: 'DNTT-2026-0083' },
  { id: 'num-yckt', docType: 'TechRequest', docName: 'Yêu cầu kỹ thuật', prefix: 'YCKT', numberLength: 4, resetYearly: true, currentNumber: 39, sampleFormat: 'YCKT-2026-0039' },
  { id: 'num-da', docType: 'Project', docName: 'Dự án / Kế hoạch kỹ thuật', prefix: 'DA', numberLength: 4, resetYearly: true, currentNumber: 18, sampleFormat: 'DA-2026-0018' },
  { id: 'num-bbnt', docType: 'Acceptance', docName: 'Biên bản nghiệm thu', prefix: 'BBNT', numberLength: 4, resetYearly: true, currentNumber: 27, sampleFormat: 'BBNT-2026-0027' },
  { id: 'num-ycbh', docType: 'WarrantyRequest', docName: 'Yêu cầu bảo hành', prefix: 'YCBH', numberLength: 4, resetYearly: true, currentNumber: 15, sampleFormat: 'YCBH-2026-0015' },
  { id: 'num-xbh', docType: 'WarrantyStockOut', docName: 'Xuất kho bảo hành', prefix: 'XBH', numberLength: 4, resetYearly: true, currentNumber: 12, sampleFormat: 'XBH-2026-0012' },
  { id: 'num-pn', docType: 'StockIn', docName: 'Phiếu nhập kho', prefix: 'PN', numberLength: 4, resetYearly: true, currentNumber: 130, sampleFormat: 'PN-2026-0130' },
  { id: 'num-px', docType: 'StockOut', docName: 'Phiếu xuất kho', prefix: 'PX', numberLength: 4, resetYearly: true, currentNumber: 145, sampleFormat: 'PX-2026-0145' },
];

export const INITIAL_SECURITY_POLICY: SecurityPolicyConfig = {
  minPasswordLength: 8,
  requireUppercase: true,
  requireLowercase: true,
  requireNumber: true,
  requireSpecialChar: true,
  forceChangePasswordFirstLogin: true,
  passwordExpireDays: 90,
  maxFailedLogins: 5,
  lockoutDurationMinutes: 15,
  sessionTimeoutMinutes: 30,
  auditLogRetentionMonths: 12,
};

export const INITIAL_WORKING_TIME: WorkingTimeConfig = {
  workingHoursStart: '08:00',
  workingHoursEnd: '17:30',
  lunchBreakStart: '12:00',
  lunchBreakEnd: '13:30',
  workingDays: ['T2', 'T3', 'T4', 'T5', 'T6', 'T7'],
  timezone: 'Asia/Ho_Chi_Minh (GMT+7)',
  dateFormat: 'DD/MM/YYYY',
  timeFormat: '24h',
  currency: 'VND',
  decimalPrecision: 0,
  holidays: [
    { id: 'h-1', name: 'Tết Dương Lịch 2026', startDate: '2026-01-01', endDate: '2026-01-01', year: 2026 },
    { id: 'h-2', name: 'Tết Nguyên Đán Bính Ngọ 2026', startDate: '2026-02-15', endDate: '2026-02-23', year: 2026 },
    { id: 'h-3', name: 'Giỗ Tổ Hùng Vương', startDate: '2026-04-26', endDate: '2026-04-26', year: 2026 },
    { id: 'h-4', name: 'Ngày Giải Phóng Miền Nam & Quốc Tế Lao Động', startDate: '2026-04-30', endDate: '2026-05-03', year: 2026 },
    { id: 'h-5', name: 'Lễ Quốc Khánh 2/9', startDate: '2026-09-01', endDate: '2026-09-03', year: 2026 },
  ],
};

export const INITIAL_PRINT_TEMPLATES: PrintTemplateConfig[] = [
  {
    docType: 'quotation',
    docName: 'Báo giá bán hàng',
    pageSize: 'A4',
    orientation: 'portrait',
    headerText: 'BÁO GIÁ THIẾT BỊ VÀ GIẢI PHÁP CÔNG NGHỆ',
    footerText: 'Cảm ơn Quý Khách hàng đã tin tưởng lựa chọn dịch vụ của A+ Enterprise!',
    showCompanyLogo: true,
    showCompanyInfo: true,
    showStamp: true,
    signerSlots: [
      { id: 's1', title: 'Người lập biểu', note: '(Ký, họ tên)', required: true },
      { id: 's2', title: 'Trưởng bộ phận Sales', note: '(Ký, họ tên)', required: true },
      { id: 's3', title: 'Xác nhận của Khách hàng', note: '(Ký, đóng dấu)', required: true },
    ],
  },
  {
    docType: 'delivery_note',
    docName: 'Phiếu giao hàng kiêm xuất kho',
    pageSize: 'A5',
    orientation: 'landscape',
    headerText: 'PHIẾU GIAO HÀNG KIÊM VẬN CHUYỂN NỘI BỘ',
    footerText: 'Hàng hóa đã được kiểm tra kỹ trước khi xuất kho giao khách hàng.',
    showCompanyLogo: true,
    showCompanyInfo: true,
    showStamp: false,
    signerSlots: [
      { id: 's1', title: 'Người lập phiếu', note: '(Ký, họ tên)', required: true },
      { id: 's2', title: 'Thủ kho xuất', note: '(Ký, họ tên)', required: true },
      { id: 's3', title: 'Nhân viên giao nhận', note: '(Ký, họ tên)', required: true },
      { id: 's4', title: 'Người nhận hàng', note: '(Ký, họ tên)', required: true },
    ],
  },
];

export const INITIAL_INTEGRATION_CONFIG: IntegrationConnectionConfig = {
  smtp: {
    host: 'smtp.gmail.com',
    port: 587,
    username: 'noreply@apluscorp.vn',
    passwordMasked: '••••••••••••••••',
    fromEmail: 'noreply@apluscorp.vn',
    fromName: 'Hệ thống A+ Enterprise CRM',
    useSslTls: true,
    status: 'connected',
    lastTestedAt: '2026-10-05 14:00:00',
  },
  apiKeys: [
    {
      id: 'key-1',
      name: 'Mobile App ERP Connector',
      keyMasked: 'apl_live_••••••••••••••••789A',
      scopes: ['orders:read', 'inventory:read', 'customers:read'],
      createdAt: '2026-06-01',
      expiresAt: '2027-06-01',
      lastUsedAt: '2026-10-05 17:30:12',
      status: 'active',
    },
    {
      id: 'key-2',
      name: 'Website Lead Capture Hook',
      keyMasked: 'apl_live_••••••••••••••••452C',
      scopes: ['leads:write'],
      createdAt: '2026-08-15',
      expiresAt: '2027-08-15',
      lastUsedAt: '2026-10-05 18:12:00',
      status: 'active',
    },
  ],
  einvoiceDraft: {
    providerName: 'VNPT',
    serviceUrl: 'https://einvoice.vnpt.vn/api/v2',
    status: 'placeholder',
  },
  accountingSoftwareDraft: {
    providerName: 'MISA SME',
    status: 'placeholder',
  },
  zaloOADraft: {
    oaId: '2847192837491823',
    status: 'placeholder',
  },
};

// ==========================================
// 4. CẤU HÌNH NGHIỆP VỤ & QUY TẮC DUYỆT (APP CONFIG)
// ==========================================

export const INITIAL_APP_PARAMETERS: AppParameterItem[] = [
  // Sales
  { id: 'p-sales-1', key: 'lead_first_contact_sla_hours', tabGroup: 'sales', name: 'Thời hạn liên hệ lead lần đầu (SLA)', description: 'Thời gian tối đa nhân viên phải phản hồi hoặc gọi điện cho Lead mới', value: 4, valueType: 'number', unit: 'giờ làm việc', defaultValue: 4, usedInModules: ['Quản lý Sales'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  { id: 'p-sales-2', key: 'opp_inactive_warning_days', tabGroup: 'sales', name: 'Số ngày cơ hội đứng yên để cảnh báo', description: 'Cảnh báo nếu Cơ hội bán hàng không có tương tác hoặc không cập nhật trạng thái', value: 14, valueType: 'number', unit: 'ngày', defaultValue: 14, usedInModules: ['Quản lý Sales'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  { id: 'p-sales-3', key: 'quote_default_validity_days', tabGroup: 'sales', name: 'Số ngày hiệu lực mặc định của báo giá', description: 'Thời gian tính từ ngày lập báo giá đến ngày hết hiệu lực', value: 30, valueType: 'number', unit: 'ngày', defaultValue: 30, usedInModules: ['Quản lý Sales'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  { id: 'p-sales-4', key: 'contract_expiring_warning_days', tabGroup: 'sales', name: 'Cảnh báo hợp đồng sắp hết hạn', description: 'Các mốc thời gian hệ thống phát cảnh báo hợp đồng sắp hết hạn', value: '30, 60', valueType: 'string', unit: 'ngày trước', defaultValue: '30, 60', usedInModules: ['Quản lý Sales', 'Kỹ thuật'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  // Kho
  { id: 'p-wh-1', key: 'stock_expiring_threshold_days', tabGroup: 'inventory', name: 'Ngưỡng hàng sắp hết hạn (Date)', description: 'Các ngưỡng ngày để cảnh báo tồn kho sắp quá hạn sử dụng', value: '30, 60, 90', valueType: 'string', unit: 'ngày trước', defaultValue: '30, 60, 90', usedInModules: ['Quản lý kho'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  { id: 'p-wh-2', key: 'allow_negative_stock', tabGroup: 'inventory', name: 'Cho phép xuất âm kho', description: 'Cho phép xuất kho khi số lượng tồn sổ sách nhỏ hơn số lượng xuất', value: false, valueType: 'boolean', defaultValue: false, usedInModules: ['Quản lý kho'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  { id: 'p-wh-3', key: 'stock_out_rule', tabGroup: 'inventory', name: 'Nguyên tắc chọn lô xuất kho', description: 'FEFO: Hết hạn trước xuất trước; FIFO: Nhập trước xuất trước', value: 'FEFO', valueType: 'string', defaultValue: 'FEFO', usedInModules: ['Quản lý kho'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  { id: 'p-wh-4', key: 'cost_price_method', tabGroup: 'inventory', name: 'Phương pháp tính giá vốn', description: 'Phương pháp định giá hàng tồn kho trong hệ thống', value: 'Bình quân gia quyền', valueType: 'string', defaultValue: 'Bình quân gia quyền', usedInModules: ['Quản lý kho', 'Kế toán'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  { id: 'p-wh-5', key: 'slow_moving_stock_days', tabGroup: 'inventory', name: 'Số ngày coi là hàng tồn lâu không biến động', description: 'Sản phẩm không có phát sinh xuất kho trong khoảng thời gian này sẽ báo tồn đọng', value: 90, valueType: 'number', unit: 'ngày', defaultValue: 90, usedInModules: ['Quản lý kho', 'Báo cáo'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  { id: 'p-wh-6', key: 'daily_closing_time', tabGroup: 'inventory', name: 'Giờ chạy chốt tồn cuối ngày', description: 'Hệ thống tự động chụp ảnh tồn kho và lưu sổ chốt số dư', value: '23:59', valueType: 'string', defaultValue: '23:59', usedInModules: ['Quản lý kho'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  // Logistics
  { id: 'p-log-1', key: 'logistics_approval_sla_hours', tabGroup: 'logistics', name: 'Thời hạn Logistics xác nhận đơn', description: 'SLA xác nhận phê duyệt đơn từ lúc Sales gửi sang', value: 4, valueType: 'number', unit: 'giờ làm việc', defaultValue: 4, usedInModules: ['Vận chuyển'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  { id: 'p-log-2', key: 'cod_remittance_warning_days', tabGroup: 'logistics', name: 'Cảnh báo tiền thu hộ COD chưa nộp', description: 'Số ngày tài xế hoặc bưu tá giữ tiền thu hộ chưa bàn giao cho kế toán', value: 2, valueType: 'number', unit: 'ngày', defaultValue: 2, usedInModules: ['Vận chuyển', 'Kế toán'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  // Technical
  { id: 'p-tech-1', key: 'tech_quote_sla_days', tabGroup: 'technical', name: 'Hạn lập báo giá kỹ thuật', description: 'Thời gian tối đa để bộ phận Kỹ thuật phản hồi giải pháp & danh mục cho Sales', value: 2, valueType: 'number', unit: 'ngày làm việc', defaultValue: 2, usedInModules: ['Kỹ thuật', 'Quản lý Sales'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
  // HR
  { id: 'p-hr-1', key: 'labor_contract_expiring_days', tabGroup: 'hr', name: 'Cảnh báo HĐLĐ / thử việc sắp hết hạn', description: 'Cảnh báo trước ngày kết thúc hợp đồng lao động để làm thủ tục tái ký hoặc thanh lý', value: 30, valueType: 'number', unit: 'ngày trước', defaultValue: 30, usedInModules: ['Quản lý nhân sự'], updatedBy: 'Admin', updatedAt: '2026-01-01' },
];

export const INITIAL_APPROVAL_RULES: DocumentApprovalRule[] = [
  {
    id: 'appr-quote-1',
    docType: 'Quotation',
    docTypeName: 'Báo giá bán hàng',
    priorityOrder: 1,
    conditionDescription: 'Chiết khấu tổng đơn từ trên 5% đến 10%',
    conditionFormula: { field: 'discountRate', operator: '>', thresholdValue: 5 },
    tier1Approver: { tierLevel: 1, approverType: 'role', approverTarget: 'Trưởng phòng / Trưởng nhóm Sales' },
    isEnabled: true,
  },
  {
    id: 'appr-quote-2',
    docType: 'Quotation',
    docTypeName: 'Báo giá bán hàng',
    priorityOrder: 2,
    conditionDescription: 'Chiết khấu đặc biệt trên 10% hoặc giá trị đơn trên 500 triệu',
    conditionFormula: { field: 'discountRate', operator: '>', thresholdValue: 10 },
    tier1Approver: { tierLevel: 1, approverType: 'role', approverTarget: 'Trưởng phòng / Trưởng nhóm Sales' },
    tier2Approver: { tierLevel: 2, approverType: 'role', approverTarget: 'Ban Giám Đốc (Board of Directors)' },
    isEnabled: true,
  },
  {
    id: 'appr-po-1',
    docType: 'PurchaseOrder',
    docTypeName: 'Đơn mua hàng (PO)',
    priorityOrder: 1,
    conditionDescription: 'Đơn mua hàng có giá trị trên 50.000.000 đ',
    conditionFormula: { field: 'totalAmount', operator: '>', thresholdValue: 50000000 },
    tier1Approver: { tierLevel: 1, approverType: 'role', approverTarget: 'Trưởng phòng Kho & Logistics' },
    tier2Approver: { tierLevel: 2, approverType: 'role', approverTarget: 'Ban Giám Đốc (Board of Directors)' },
    isEnabled: true,
  },
  {
    id: 'appr-payment-1',
    docType: 'PaymentRequest',
    docTypeName: 'Đề nghị thanh toán',
    priorityOrder: 1,
    conditionDescription: 'Đề nghị thanh toán chi phí hoặc vượt dự toán dự án',
    conditionFormula: { field: 'amount', operator: '>', thresholdValue: 20000000 },
    tier1Approver: { tierLevel: 1, approverType: 'direct_manager', approverTarget: 'Quản lý trực tiếp của người tạo' },
    tier2Approver: { tierLevel: 2, approverType: 'role', approverTarget: 'Kế toán (Accountant)' },
    tier3Approver: { tierLevel: 3, approverType: 'role', approverTarget: 'Ban Giám Đốc (Board of Directors)' },
    isEnabled: true,
  },
  {
    id: 'appr-scrap-1',
    docType: 'StockOutScrap',
    docTypeName: 'Xuất kho hủy / Thanh lý',
    priorityOrder: 1,
    conditionDescription: 'Mọi phiếu xuất hủy hàng lỗi hoặc quá hạn sử dụng',
    conditionFormula: { field: 'amount', operator: '>=', thresholdValue: 0 },
    tier1Approver: { tierLevel: 1, approverType: 'role', approverTarget: 'Trưởng phòng Kho & Logistics' },
    tier2Approver: { tierLevel: 2, approverType: 'role', approverTarget: 'Ban Giám Đốc (Board of Directors)' },
    isEnabled: true,
  },
];

export const INITIAL_APPROVAL_DELEGATIONS: ApprovalDelegation[] = [
  {
    id: 'del-1',
    delegatorName: 'Trần Minh Đức (Tổng Giám Đốc)',
    delegateeName: 'Lê Hoàng Yến (Trưởng Khối Kinh Doanh)',
    fromDate: '2026-10-10',
    toDate: '2026-10-20',
    docTypes: ['Quotation', 'SalesOrder'],
    reason: 'Công tác nước ngoài tham dự hội nghị Tech Expo 2026',
    status: 'active',
  },
];

// ==========================================
// 5. TỪ ĐIỂN GIÁ TRỊ (DICTIONARY CATEGORIES)
// ==========================================

export const INITIAL_DICTIONARY_CATEGORIES: DictionaryCategory[] = [
  // Sales
  {
    id: 'dict-lead-source',
    code: 'LEAD_SOURCE',
    name: 'Nguồn khách hàng tiềm năng (Lead Source)',
    moduleGroup: 'sales',
    description: 'Các kênh thu hút lead đổ về CRM',
    values: [
      { id: 'v-ls-1', code: 'WEBSITE', label: 'Website doanh nghiệp', colorBadge: 'bg-blue-100 text-blue-700', sortOrder: 1, isDefault: true, status: 'active', isSystem: true, usedCount: 45 },
      { id: 'v-ls-2', code: 'FACEBOOK', label: 'Facebook Ads & Fanpage', colorBadge: 'bg-indigo-100 text-indigo-700', sortOrder: 2, isDefault: false, status: 'active', isSystem: true, usedCount: 32 },
      { id: 'v-ls-3', code: 'ZALO', label: 'Zalo OA / Tin nhắn Zalo', colorBadge: 'bg-sky-100 text-sky-700', sortOrder: 3, isDefault: false, status: 'active', isSystem: true, usedCount: 28 },
      { id: 'v-ls-4', code: 'REFERRAL', label: 'Khách hàng cũ giới thiệu', colorBadge: 'bg-emerald-100 text-emerald-700', sortOrder: 4, isDefault: false, status: 'active', isSystem: false, usedCount: 19 },
      { id: 'v-ls-5', code: 'HOTLINE', label: 'Tổng đài Hotline / Trực tiếp', colorBadge: 'bg-amber-100 text-amber-700', sortOrder: 5, isDefault: false, status: 'active', isSystem: false, usedCount: 15 },
      { id: 'v-ls-6', code: 'OTHER', label: 'Kênh khác', colorBadge: 'bg-slate-100 text-slate-700', sortOrder: 6, isDefault: false, status: 'active', isSystem: false, usedCount: 8 },
    ],
  },
  {
    id: 'dict-loss-reason',
    code: 'LOSS_REASON',
    name: 'Lý do cơ hội thất bại (Loss Reason)',
    moduleGroup: 'sales',
    description: 'Nguyên nhân đóng cơ hội với trạng thái Thất bại (Lost)',
    values: [
      { id: 'v-lr-1', code: 'PRICE_HIGH', label: 'Giá cao hơn ngân sách dự kiến', colorBadge: 'bg-rose-100 text-rose-700', sortOrder: 1, isDefault: true, status: 'active', isSystem: true, usedCount: 22 },
      { id: 'v-lr-2', code: 'COMPETITOR', label: 'Đối thủ cạnh tranh thắng thầu', colorBadge: 'bg-purple-100 text-purple-700', sortOrder: 2, isDefault: false, status: 'active', isSystem: true, usedCount: 18 },
      { id: 'v-lr-3', code: 'NO_BUDGET', label: 'Khách hoãn / hủy kế hoạch đầu tư', colorBadge: 'bg-slate-100 text-slate-700', sortOrder: 3, isDefault: false, status: 'active', isSystem: false, usedCount: 14 },
      { id: 'v-lr-4', code: 'FEATURE_MISMATCH', label: 'Tính năng chưa đáp ứng đặc thù', colorBadge: 'bg-amber-100 text-amber-700', sortOrder: 4, isDefault: false, status: 'active', isSystem: false, usedCount: 9 },
      { id: 'v-lr-5', code: 'NO_RESPONSE', label: 'Không phản hồi / Mất liên lạc', colorBadge: 'bg-gray-100 text-gray-700', sortOrder: 5, isDefault: false, status: 'active', isSystem: false, usedCount: 11 },
    ],
  },
  {
    id: 'dict-customer-group',
    code: 'CUSTOMER_GROUP',
    name: 'Nhóm khách hàng (Customer Group)',
    moduleGroup: 'sales',
    description: 'Phân loại tệp khách hàng theo quy mô và chính sách ưu đãi',
    values: [
      { id: 'v-cg-1', code: 'ENTERPRISE', label: 'Khách hàng Doanh nghiệp lớn (VIP)', colorBadge: 'bg-amber-100 text-amber-700', sortOrder: 1, isDefault: false, status: 'active', isSystem: true, usedCount: 24 },
      { id: 'v-cg-2', code: 'SME', label: 'Doanh nghiệp vừa và nhỏ (SME)', colorBadge: 'bg-blue-100 text-blue-700', sortOrder: 2, isDefault: true, status: 'active', isSystem: true, usedCount: 52 },
      { id: 'v-cg-3', code: 'POTENTIAL', label: 'Khách hàng tiềm năng mới', colorBadge: 'bg-emerald-100 text-emerald-700', sortOrder: 3, isDefault: false, status: 'active', isSystem: false, usedCount: 30 },
      { id: 'v-cg-4', code: 'GOVERNMENT', label: 'Cơ quan nhà nước & Giáo dục', colorBadge: 'bg-indigo-100 text-indigo-700', sortOrder: 4, isDefault: false, status: 'active', isSystem: false, usedCount: 8 },
    ],
  },
  {
    id: 'dict-payment-method',
    code: 'PAYMENT_METHOD',
    name: 'Hình thức thanh toán (Payment Method)',
    moduleGroup: 'sales',
    description: 'Phương thức thanh toán chấp nhận trong hợp đồng và phiếu thu',
    values: [
      { id: 'v-pm-1', code: 'BANK_TRANSFER', label: 'Chuyển khoản ngân hàng', colorBadge: 'bg-blue-100 text-blue-700', sortOrder: 1, isDefault: true, status: 'active', isSystem: true, usedCount: 120 },
      { id: 'v-pm-2', code: 'CASH', label: 'Tiền mặt tại quầy', colorBadge: 'bg-emerald-100 text-emerald-700', sortOrder: 2, isDefault: false, status: 'active', isSystem: true, usedCount: 35 },
      { id: 'v-pm-3', code: 'LETTER_OF_CREDIT', label: 'Thư tín dụng (L/C)', colorBadge: 'bg-purple-100 text-purple-700', sortOrder: 3, isDefault: false, status: 'active', isSystem: false, usedCount: 4 },
    ],
  },
  // Kho
  {
    id: 'dict-stock-out-reason',
    code: 'STOCK_OUT_REASON',
    name: 'Lý do xuất kho (Stock Out Reason)',
    moduleGroup: 'inventory',
    description: 'Phân loại mục đích xuất kho hàng hóa và vật tư',
    values: [
      { id: 'v-sor-1', code: 'SALE_ORDER', label: 'Xuất bán hàng theo đơn (Sales Order)', colorBadge: 'bg-blue-100 text-blue-700', sortOrder: 1, isDefault: true, status: 'active', isSystem: true, usedCount: 88 },
      { id: 'v-sor-2', code: 'WARRANTY_REPLACE', label: 'Xuất kho bảo hành & đổi trả linh kiện', colorBadge: 'bg-amber-100 text-amber-700', sortOrder: 2, isDefault: false, status: 'active', isSystem: true, usedCount: 14 },
      { id: 'v-sor-3', code: 'INTERNAL_USE', label: 'Xuất sử dụng nội bộ / Văn phòng', colorBadge: 'bg-slate-100 text-slate-700', sortOrder: 3, isDefault: false, status: 'active', isSystem: false, usedCount: 19 },
      { id: 'v-sor-4', code: 'TRANSFER', label: 'Xuất chuyển kho nội bộ', colorBadge: 'bg-indigo-100 text-indigo-700', sortOrder: 4, isDefault: false, status: 'active', isSystem: true, usedCount: 25 },
      { id: 'v-sor-5', code: 'SCRAP_DISPOSAL', label: 'Xuất hủy hàng hỏng / quá hạn', colorBadge: 'bg-rose-100 text-rose-700', sortOrder: 5, isDefault: false, status: 'active', isSystem: false, usedCount: 6 },
    ],
  },
  // Logistics
  {
    id: 'dict-delivery-fail-reason',
    code: 'DELIVERY_FAIL_REASON',
    name: 'Lý do giao hàng thất bại (Delivery Failure)',
    moduleGroup: 'logistics',
    description: 'Nguyên nhân không giao được hàng cho khách',
    values: [
      { id: 'v-dfr-1', code: 'CUSTOMER_ABSENT', label: 'Khách hàng vắng mặt / Không liên lạc được', colorBadge: 'bg-amber-100 text-amber-700', sortOrder: 1, isDefault: true, status: 'active', isSystem: true, usedCount: 16 },
      { id: 'v-dfr-2', code: 'WRONG_ADDRESS', label: 'Sai thông tin địa chỉ / Địa chỉ khó tìm', colorBadge: 'bg-orange-100 text-orange-700', sortOrder: 2, isDefault: false, status: 'active', isSystem: true, usedCount: 8 },
      { id: 'v-dfr-3', code: 'CUSTOMER_REJECT', label: 'Khách từ chối nhận hàng (đổi ý)', colorBadge: 'bg-rose-100 text-rose-700', sortOrder: 3, isDefault: false, status: 'active', isSystem: true, usedCount: 5 },
      { id: 'v-dfr-4', code: 'RESCHEDULE', label: 'Khách hẹn giao lại vào thời gian khác', colorBadge: 'bg-sky-100 text-sky-700', sortOrder: 4, isDefault: false, status: 'active', isSystem: false, usedCount: 21 },
    ],
  },
  {
    id: 'dict-payment-request-type',
    code: 'PAYMENT_REQ_TYPE',
    name: 'Loại đề nghị thanh toán (Payment Request Type)',
    moduleGroup: 'logistics',
    description: 'Phân loại chi phí yêu cầu thanh toán trên toàn hệ thống',
    values: [
      { id: 'v-prt-1', code: 'SUPPLIER_PAYMENT', label: 'Thanh toán tiền hàng cho Nhà cung cấp', colorBadge: 'bg-blue-100 text-blue-700', sortOrder: 1, isDefault: true, status: 'active', isSystem: true, usedCount: 42 },
      { id: 'v-prt-2', code: 'FREIGHT_SHIPPING', label: 'Cước vận chuyển & Thuê ngoài Logistics', colorBadge: 'bg-cyan-100 text-cyan-700', sortOrder: 2, isDefault: false, status: 'active', isSystem: true, usedCount: 31 },
      { id: 'v-prt-3', code: 'SUB_CONTRACTOR', label: 'Chi phí nhà thầu phụ / Thi công lắp đặt', colorBadge: 'bg-purple-100 text-purple-700', sortOrder: 3, isDefault: false, status: 'active', isSystem: false, usedCount: 18 },
      { id: 'v-prt-4', code: 'EXTERNAL_MATERIAL', label: 'Vật tư mua ngoài phục vụ dự án', colorBadge: 'bg-emerald-100 text-emerald-700', sortOrder: 4, isDefault: false, status: 'active', isSystem: false, usedCount: 20 },
      { id: 'v-prt-5', code: 'TRAVEL_ADVANCE', label: 'Tạm ứng công tác / Đi lại phụ cấp', colorBadge: 'bg-amber-100 text-amber-700', sortOrder: 5, isDefault: false, status: 'active', isSystem: false, usedCount: 12 },
    ],
  },
];

// ==========================================
// 6. DANH MỤC DỮ LIỆU (DIRECTORIES)
// ==========================================

export const INITIAL_SUPPLIERS: SupplierDirectoryItem[] = [
  { id: 'sup-1', code: 'NCC-CISCO', name: 'Công ty TNHH Cisco Systems Việt Nam', taxCode: '0101567890', address: 'Tòa nhà Landmark 81, TP.HCM', contactPerson: 'Nguyễn Tuấn Anh', phone: '0903 888 777', email: 'sales@cisco.vn', defaultPaymentTerm: 'Công nợ 30 ngày', bankAccount: '0071009876543', bankName: 'Vietcombank TP.HCM', groupName: 'Thiết bị mạng cao cấp', totalPayableDebt: 185000000, status: 'active' },
  { id: 'sup-2', code: 'NCC-DELL', name: 'Công ty TNHH Dell Global B.V Việt Nam', taxCode: '0304567891', address: 'Tòa nhà Bitexco, Q.1, TP.HCM', contactPerson: 'Trần Minh Quân', phone: '0918 333 444', email: 'b2b@dell.com.vn', defaultPaymentTerm: 'Công nợ 45 ngày', bankAccount: '118000998877', bankName: 'VietinBank', groupName: 'Máy chủ & Máy tính', totalPayableDebt: 320000000, status: 'active' },
  { id: 'sup-3', code: 'NCC-FORTINET', name: 'Nhà phân phối Fortinet Network Security', taxCode: '0106789123', address: 'Tháp Hà Nội, 49 Hai Bà Trưng, Hà Nội', contactPerson: 'Hoàng Quốc Việt', phone: '0982 555 666', email: 'contact@fortinetvn.com', defaultPaymentTerm: 'Công nợ 15 ngày', bankAccount: '19034567890123', bankName: 'Techcombank', groupName: 'Bảo mật an ninh mạng', totalPayableDebt: 95000000, status: 'active' },
  { id: 'sup-4', code: 'NCC-HIKVISION', name: 'Công ty CP Công Nghệ Hikvision Việt Nam', taxCode: '0107891234', address: 'Khu Công Nghệ Cao Hòa Lạc, Hà Nội', contactPerson: 'Phạm Thu Trang', phone: '0977 123 999', email: 'sales@hikvision.vn', defaultPaymentTerm: 'Thanh toán ngay', bankAccount: '0451000888999', bankName: 'Vietcombank Thăng Long', groupName: 'Camera & Giám sát', totalPayableDebt: 45000000, status: 'active' },
  { id: 'sup-5', code: 'NCC-MICROSOFT', name: 'Microsoft Enterprise Partner VN', taxCode: '0102345678', address: 'Tòa nhà Pacific Place, Hà Nội', contactPerson: 'Lê Thanh Thảo', phone: '0904 222 111', email: 'partner@msenterprise.vn', defaultPaymentTerm: 'Công nợ 30 ngày', bankAccount: '020011998877', bankName: 'Sacombank', groupName: 'Phần mềm bản quyền', totalPayableDebt: 150000000, status: 'active' },
  { id: 'sup-6', code: 'NCC-SCHNEIDER', name: 'Schneider Electric IT Việt Nam (APC)', taxCode: '0301122334', address: 'Khu Chế Xuất Tân Thuận, Q.7, TP.HCM', contactPerson: 'Đặng Hữu Phúc', phone: '0933 666 888', email: 'orders@apc-schneider.vn', defaultPaymentTerm: 'Công nợ 30 ngày', bankAccount: '0011005544332', bankName: 'Vietcombank', groupName: 'UPS & Hạ tầng nguồn điện', totalPayableDebt: 78000000, status: 'active' },
  { id: 'sup-7', code: 'NCC-HP', name: 'HP Enterprise Solutions Việt Nam', taxCode: '0309988776', address: 'Tòa nhà Mplaza Saigon, Q.1, TP.HCM', contactPerson: 'Vũ Đức Thành', phone: '0944 888 222', email: 'enterprise@hpe.vn', defaultPaymentTerm: 'Công nợ 45 ngày', bankAccount: '123456789098', bankName: 'BIDV', groupName: 'Máy chủ & Lưu trữ', totalPayableDebt: 210000000, status: 'active' },
  { id: 'sup-8', code: 'NCC-SAMSUNG', name: 'Samsung Display & B2B Solutions', taxCode: '0103344556', address: 'Tòa nhà Lotte Center, Ba Đình, Hà Nội', contactPerson: 'Kim Hyun Jin / Mai Anh', phone: '0912 999 888', email: 'b2b.display@samsung.vn', defaultPaymentTerm: 'Công nợ 30 ngày', bankAccount: '002100998811', bankName: 'Vietcombank', groupName: 'Màn hình ghép & Trình chiếu', totalPayableDebt: 135000000, status: 'active' },
  { id: 'sup-9', code: 'NCC-DRAYTEK', name: 'Nhà nhập khẩu thiết bị mạng DrayTek An Phát', taxCode: '0305566778', address: 'Đường Cộng Hòa, Q. Tân Bình, TP.HCM', contactPerson: 'Bùi Thế Hiển', phone: '0908 444 333', email: 'sales@anphat.vn', defaultPaymentTerm: 'Công nợ 15 ngày', bankAccount: '060088997766', bankName: 'Sacombank', groupName: 'Router & Cân bằng tải', totalPayableDebt: 38000000, status: 'active' },
  { id: 'sup-10', code: 'NCC-FASTVANCHUYEN', name: 'Công ty Cổ phần Tiếp Vận Nhanh Toàn Quốc', taxCode: '0104455667', address: 'Khu CN Quang Minh, Mê Linh, Hà Nội', contactPerson: 'Trịnh Đình Dũng', phone: '0966 888 111', email: 'tiepvan@fastlogistics.vn', defaultPaymentTerm: 'Gối đầu theo tuần', bankAccount: '19022233344455', bankName: 'Techcombank', groupName: 'Dịch vụ vận chuyển thuê ngoài', totalPayableDebt: 26000000, status: 'active' },
];

export const INITIAL_WAREHOUSES: WarehouseDirectoryItem[] = [
  { id: 'wh-1', code: 'KHO-HN', name: 'Kho Tổng Hà Nội (Trụ sở chính)', address: 'Kho C12, Cụm Công nghiệp Nam Từ Liêm, Hà Nội', managerName: 'Vũ Đình Khoa', type: 'regular', includeInAvailableStock: true, status: 'active' },
  { id: 'wh-2', code: 'KHO-HCM', name: 'Kho Chi Nhánh TP.HCM', address: 'Kho B5, Khu Công Nghiệp Tân Bình, TP.HCM', managerName: 'Nguyễn Văn Cường', type: 'regular', includeInAvailableStock: true, status: 'active' },
  { id: 'wh-3', code: 'KHO-BH', name: 'Kho Hàng Lỗi & Bảo Hành Kỹ Thuật', address: 'Phòng Kỹ thuật tầng hầm Keangnam, Hà Nội', managerName: 'Trần Văn Nam', type: 'defective_warranty', includeInAvailableStock: false, status: 'active' },
];

export const INITIAL_BANKS: BankDirectoryItem[] = [
  { id: 'b-1', code: 'VCB', shortName: 'Vietcombank', fullName: 'Ngân hàng TMCP Ngoại Thương Việt Nam' },
  { id: 'b-2', code: 'TCB', shortName: 'Techcombank', fullName: 'Ngân hàng TMCP Kỹ Thương Việt Nam' },
  { id: 'b-3', code: 'MB', shortName: 'MB Bank', fullName: 'Ngân hàng TMCP Quân Đội' },
  { id: 'b-4', code: 'ACB', shortName: 'ACB', fullName: 'Ngân hàng TMCP Á Châu' },
  { id: 'b-5', code: 'BIDV', shortName: 'BIDV', fullName: 'Ngân hàng TMCP Đầu Tư & Phát Triển Việt Nam' },
  { id: 'b-6', code: 'CTG', shortName: 'VietinBank', fullName: 'Ngân hàng TMCP Công Thương Việt Nam' },
  { id: 'b-7', code: 'VPB', shortName: 'VPBank', fullName: 'Ngân hàng TMCP Việt Nam Thịnh Vượng' },
  { id: 'b-8', code: 'TPB', shortName: 'TPBank', fullName: 'Ngân hàng TMCP Tiên Phong' },
];

export const INITIAL_VAT_RATES: VatRateDirectoryItem[] = [
  { id: 'vat-0', code: 'VAT_0', ratePercent: 0, label: '0% (Hàng xuất khẩu / Không chịu thuế)', isDefault: false, status: 'active' },
  { id: 'vat-5', code: 'VAT_5', ratePercent: 5, label: '5% (Thiết bị y tế, khoa học giáo dục)', isDefault: false, status: 'active' },
  { id: 'vat-8', code: 'VAT_8', ratePercent: 8, label: '8% (Chính sách ưu đãi giảm thuế GTGT)', isDefault: false, status: 'active' },
  { id: 'vat-10', code: 'VAT_10', ratePercent: 10, label: '10% (Thuế suất chuẩn phổ thông)', isDefault: true, status: 'active' },
  { id: 'vat-none', code: 'VAT_EXEMPT', ratePercent: 0, label: 'Không chịu thuế GTGT (Phần mềm bản quyền)', isDefault: false, status: 'active' },
];

// ==========================================
// 7. NHẬT KÝ ĐỒNG BỘ & AUDIT LOGS
// ==========================================

export const INITIAL_SYNC_RUNS: SyncRunRecord[] = [
  { id: 'sync-1', startTime: '2026-10-05 18:30:00', sourceDestination: 'Đồng bộ Dữ liệu Bán hàng sang Kế toán', direction: 'INBOUND', totalRecords: 12, successRecords: 12, failedRecords: 0, skippedRecords: 0, status: 'SUCCESS', durationMs: 420, triggeredBy: 'Trần Minh Đức (Kế toán)' },
  { id: 'sync-2', startTime: '2026-10-05 17:00:00', sourceDestination: 'Đồng bộ Phiếu giao hàng sang Kho', direction: 'OUTBOUND', totalRecords: 8, successRecords: 7, failedRecords: 1, skippedRecords: 0, status: 'PARTIAL', durationMs: 1250, triggeredBy: 'Lê Hoàng Yến (Sales)', errorDetails: [{ line: 5, entityId: 'PGH-2026-0091', message: 'Mã bưu cục đích không tồn tại hoặc sai số điện thoại người nhận' }] },
  { id: 'sync-3', startTime: '2026-10-05 12:00:00', sourceDestination: 'Đồng bộ Kho - Nghiệm thu Kỹ thuật', direction: 'INBOUND', totalRecords: 5, successRecords: 5, failedRecords: 0, skippedRecords: 0, status: 'SUCCESS', durationMs: 310, triggeredBy: 'Trần Văn Nam (Kỹ thuật)' },
  { id: 'sync-4', startTime: '2026-10-04 09:15:00', sourceDestination: 'Đồng bộ Danh mục Nhà cung cấp', direction: 'INBOUND', totalRecords: 3, successRecords: 0, failedRecords: 3, skippedRecords: 0, status: 'FAILED', durationMs: 5200, triggeredBy: 'Vũ Đình Khoa (Kho)', errorDetails: [{ line: 1, message: 'Máy chủ phản hồi timeout' }, { line: 2, message: 'Lỗi xác thực chứng chỉ kết nối' }] },
];

export const INITIAL_IMPORT_EXPORT_LOGS: DataImportExportLog[] = [
  { id: 'iel-1', timestamp: '2026-10-05 15:20:00', type: 'IMPORT', moduleName: 'Quản lý nhân sự', entityType: 'Danh sách nhân sự mới', fileName: 'Danh_sach_nhan_su_thang_10.xlsx', totalRows: 5, successRows: 5, errorRows: 0, performedBy: 'Đặng Thu Thảo', status: 'SUCCESS', canRollback: true, isRolledBack: false },
  { id: 'iel-2', timestamp: '2026-10-05 11:10:00', type: 'EXPORT', moduleName: 'Quản lý kho', entityType: 'Báo cáo tồn kho tổng hợp', fileName: 'Bao_cao_ton_kho_HN_102026.xlsx', totalRows: 40, successRows: 40, errorRows: 0, performedBy: 'Vũ Đình Khoa', status: 'SUCCESS', canRollback: false },
  { id: 'iel-3', timestamp: '2026-10-04 14:05:00', type: 'IMPORT', moduleName: 'Quản lý Sales', entityType: 'Danh sách Khách hàng tiềm năng', fileName: 'Leads_Hoi_Thao_Tech2026.xlsx', totalRows: 50, successRows: 48, errorRows: 2, performedBy: 'Lê Hoàng Yến', status: 'PARTIAL', canRollback: true, isRolledBack: false, errorLines: [{ row: 12, error: 'Số điện thoại không đúng 10 chữ số' }, { row: 35, error: 'Trùng email với khách hàng KH-0042 đã có trên hệ thống' }] },
];

export const INITIAL_SYSTEM_AUDIT_LOGS: SystemAuditLogItem[] = [
  { id: 'aud-1', timestamp: '2026-10-05 18:25:00', userName: 'Trần Minh Đức', userRole: 'Tổng Giám Đốc', module: 'Cài đặt hệ thống', action: 'CẬP NHẬT', objectCode: 'CFG-WORKING-TIME', objectName: 'Cấu hình thời gian làm việc', isSensitiveAccess: false, changesSummary: 'Cập nhật giờ bắt đầu làm việc từ 08:30 thành 08:00', ipAddress: '192.168.1.100' },
  { id: 'aud-2', timestamp: '2026-10-05 17:35:10', userName: 'Đặng Thu Thảo', userRole: 'Trưởng Phòng Nhân Sự', module: 'Quản lý nhân sự', action: 'XEM DỮ LIỆU NHẠY CẢM', objectCode: 'NV-0008', objectName: 'Hồ sơ nhân viên Hoàng Kim Liên', isSensitiveAccess: true, changesSummary: 'Mở xem chi tiết số CCCD và thông tin tài khoản ngân hàng', ipAddress: '192.168.1.112' },
  { id: 'aud-3', timestamp: '2026-10-05 16:40:00', userName: 'Lê Hoàng Yến', userRole: 'Trưởng Khối Kinh Doanh', module: 'Quản lý Sales', action: 'DUYỆT', objectCode: 'BG-2026-0150', objectName: 'Báo giá Thiết bị Viễn Thông Tân Á', isSensitiveAccess: false, changesSummary: 'Phê duyệt chiết khấu 7.5% theo chính sách khách hàng thân thiết', ipAddress: '192.168.1.105' },
  { id: 'aud-4', timestamp: '2026-10-05 14:15:00', userName: 'Trần Minh Đức', userRole: 'Tổng Giám Đốc', module: 'Cài đặt hệ thống', action: 'CẬP NHẬT', objectCode: 'RBAC-SALES-STAFF', objectName: 'Nhóm quyền Nhân viên Sales', isSensitiveAccess: true, changesSummary: 'Thay đổi quyền xem giá vốn thành ẨN', ipAddress: '192.168.1.100' },
  { id: 'aud-5', timestamp: '2026-10-05 10:00:00', userName: 'Vũ Đình Khoa', userRole: 'Trưởng Phòng Kho & Logistics', module: 'Quản lý kho', action: 'TẠO MỚI', objectCode: 'PN-2026-0130', objectName: 'Phiếu nhập kho lô Router Cisco', isSensitiveAccess: false, changesSummary: 'Nhập kho 20 bộ Switch Cisco Catalyst 9200', ipAddress: '192.168.1.108' },
];
