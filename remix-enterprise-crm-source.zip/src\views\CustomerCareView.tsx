import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { Ticket } from '../types/crm';
import {
  Headphones,
  Plus,
  Clock,
  Star,
  CheckCircle2,
  AlertCircle,
  FileCode,
  PhoneCall,
  Mail,
  MessageSquare,
  Globe,
  Trash2,
  X,
  Filter,
} from 'lucide-react';

export const CustomerCareView: React.FC = () => {
  const {
    tickets,
    addTicket,
    resolveTicket,
    deleteTicket,
    hasPermission,
    language,
    themeDef,
    openScreenSpec,
    t,
  } = useCRM();

  const isVi = language === 'vi';
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [channelFilter, setChannelFilter] = useState<string>('all');

  // Modal Resolve with CSAT
  const [resolvingTicketId, setResolvingTicketId] = useState<string | null>(null);
  const [csatRating, setCsatRating] = useState<number>(5);

  // Modal Create
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [formData, setFormData] = useState({
    customerName: 'Bùi Thanh Mai (CleanFarm)',
    customerPhone: '0937 221 668',
    channel: 'Zalo OA' as Ticket['channel'],
    subject: 'Hỗ trợ cấu hình tích hợp tổng đài ảo VoIP với CRM',
    description: 'Khách hàng yêu cầu kết nối luồng cuộc gọi tự động ghi âm từ đầu số hotline 1900.',
    priority: 'P2 - Cao' as Ticket['priority'],
    status: 'Mới tạo' as Ticket['status'],
    assignedTo: 'Phạm Hải Đăng',
    slaMinutesRemaining: 180,
  });

  const canCreate = hasPermission('customer-care', 'create');

  const filteredTickets = tickets.filter((ticket) => {
    const matchesPriority = priorityFilter === 'all' || ticket.priority.startsWith(priorityFilter);
    const matchesChannel = channelFilter === 'all' || ticket.channel === channelFilter;
    return matchesPriority && matchesChannel;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subject.trim()) return;
    addTicket(formData);
    setIsCreateOpen(false);
  };

  const handleConfirmResolve = () => {
    if (resolvingTicketId) {
      resolveTicket(resolvingTicketId, csatRating);
      setResolvingTicketId(null);
    }
  };

  const getPriorityBadge = (priority: Ticket['priority']) => {
    if (priority.startsWith('P1')) {
      return 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border-rose-300 font-bold animate-pulse';
    }
    if (priority.startsWith('P2')) {
      return 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border-amber-300 font-semibold';
    }
    if (priority.startsWith('P3')) {
      return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300 border-blue-200';
    }
    return 'bg-slate-100 text-slate-700 dark:bg-slate-800 border-slate-300';
  };

  const getChannelIcon = (channel: Ticket['channel']) => {
    switch (channel) {
      case 'Hotline':
        return <PhoneCall className="w-3.5 h-3.5 text-blue-500" />;
      case 'Email':
        return <Mail className="w-3.5 h-3.5 text-purple-500" />;
      case 'Zalo OA':
        return <MessageSquare className="w-3.5 h-3.5 text-sky-500" />;
      default:
        return <Globe className="w-3.5 h-3.5 text-emerald-500" />;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
              {t.customerCare}
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 font-mono font-bold">
              {tickets.filter((t) => t.status !== 'Đã giải quyết').length} pending
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isVi
              ? 'Tiếp nhận sự cố đa kênh Omnichannel, đồng hồ đếm ngược vi phạm cam kết SLA và đo lường CSAT.'
              : 'Omnichannel helpdesk, real-time SLA countdown triage, and CSAT customer satisfaction.'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 flex-wrap">
          <button
            onClick={() => openScreenSpec('SCR-CUSTOMER-CARE')}
            className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] sm:text-xs font-medium border border-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            <FileCode className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="hidden md:inline">{isVi ? 'Đặc tả Màn hình G' : 'Spec Screen G'}</span>
            <span className="md:hidden">Spec G</span>
          </button>

          {canCreate && (
            <button
              onClick={() => setIsCreateOpen(true)}
              className="flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white text-[11px] sm:text-xs font-medium transition-colors shadow-xs whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">{isVi ? 'Tạo Ticket CSKH' : 'New Ticket'}</span>
              <span className="sm:hidden">{isVi ? 'Ticket' : 'New'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-3 rounded-xl bg-white border border-[#E5E7EB] flex flex-wrap items-center justify-between gap-3 shadow-xs">
        <div className="flex flex-wrap items-center gap-1.5">
          <span className="text-[11px] sm:text-xs font-semibold text-slate-500">Độ ưu tiên SLA:</span>
          {['all', 'P1', 'P2', 'P3', 'P4'].map((p) => (
            <button
              key={p}
              onClick={() => setPriorityFilter(p)}
              className={`px-2.5 sm:px-3 py-1 rounded-lg text-[11px] sm:text-xs font-medium border transition-colors ${
                priorityFilter === p
                  ? 'bg-[#002659] text-white border-[#002659] shadow-xs'
                  : 'border-[#E5E7EB] text-slate-600 hover:bg-slate-50'
              }`}
            >
              {p === 'all' ? 'Tất cả' : p}
            </button>
          ))}
        </div>

        <select
          value={channelFilter}
          onChange={(e) => setChannelFilter(e.target.value)}
          className="px-3 py-1.5 rounded-xl text-xs border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 font-medium"
        >
          <option value="all">Tất cả kênh tiếp nhận</option>
          <option value="Hotline">Hotline</option>
          <option value="Email">Email</option>
          <option value="Zalo OA">Zalo OA</option>
          <option value="Cổng Khách Hàng">Cổng Khách Hàng</option>
        </select>
      </div>

      {/* Tickets List */}
      <div className="space-y-3">
        {filteredTickets.map((ticket) => (
          <div
            key={ticket.id}
            className={`p-5 rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow} flex flex-col md:flex-row md:items-center justify-between gap-4`}
          >
            <div className="flex items-start gap-3.5">
              <div className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 shrink-0">
                {getChannelIcon(ticket.channel)}
              </div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400">
                    {ticket.ticketNumber}
                  </span>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${getPriorityBadge(ticket.priority)}`}>
                    {ticket.priority}
                  </span>
                  <span className="text-[11px] text-slate-400 font-medium">
                    Kênh: {ticket.channel}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 mt-1">
                  {ticket.subject}
                </h3>
                <p className="text-xs text-slate-500 mt-1 line-clamp-2">{ticket.description}</p>

                <div className="mt-2.5 flex items-center gap-4 text-xs text-slate-400">
                  <span>Khách: <strong className="text-slate-700 dark:text-slate-300">{ticket.customerName}</strong> ({ticket.customerPhone})</span>
                  <span>•</span>
                  <span>Phụ trách: {ticket.assignedTo}</span>
                  <span>•</span>
                  <span>Tạo lúc: {ticket.createdAt}</span>
                </div>
              </div>
            </div>

            {/* SLA Timer & Actions */}
            <div className="flex md:flex-col items-center md:items-end justify-between gap-2 shrink-0 border-t md:border-t-0 pt-3 md:pt-0 border-slate-100 dark:border-slate-800">
              {ticket.status === 'Đã giải quyết' ? (
                <div className="text-right">
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Đã hoàn tất
                  </span>
                  {ticket.csatScore && (
                    <div className="flex items-center justify-end gap-1 mt-1 text-amber-500">
                      {Array.from({ length: ticket.csatScore }).map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-amber-400 text-amber-400" />
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="text-right">
                  <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-rose-600">
                    <Clock className="w-3.5 h-3.5" />
                    <span>SLA còn: {ticket.slaMinutesRemaining} phút</span>
                  </div>
                  <button
                    onClick={() => {
                      setResolvingTicketId(ticket.id);
                      setCsatRating(5);
                    }}
                    className="mt-2 px-2.5 sm:px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs flex items-center gap-1 shadow-xs whitespace-nowrap shrink-0"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                    <span className="hidden sm:inline">Đóng & Chấm CSAT</span>
                    <span className="sm:hidden">Đóng Ticket</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Modal Resolve Ticket & Rate CSAT */}
      {resolvingTicketId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-950/60 dark:text-emerald-400 flex items-center justify-center mx-auto mb-3">
              <CheckCircle2 className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Hoàn tất & Đóng Ticket Hỗ trợ
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Ghi nhận phản hồi xử lý thành công sự cố và đánh giá mức độ hài lòng của khách hàng (CSAT).
            </p>

            <div className="my-5">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Điểm đánh giá CSAT (1 đến 5 Sao):
              </label>
              <div className="flex items-center justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setCsatRating(star)}
                    className="p-1 hover:scale-110 transition-transform"
                  >
                    <Star
                      className={`w-7 h-7 ${
                        star <= csatRating
                          ? 'fill-amber-400 text-amber-400'
                          : 'text-slate-300 dark:text-slate-700'
                      }`}
                    />
                  </button>
                ))}
              </div>
              <div className="text-xs text-amber-600 font-bold mt-1">
                {csatRating === 5
                  ? 'Tuyệt vời (5/5 Rất hài lòng)'
                  : csatRating === 4
                  ? 'Hài lòng (4/5)'
                  : 'Cần cải thiện'}
              </div>
            </div>

            <div className="flex justify-center gap-3">
              <button
                onClick={() => setResolvingTicketId(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium"
              >
                Hủy bỏ
              </button>
              <button
                onClick={handleConfirmResolve}
                className="px-5 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-sm hover:bg-emerald-700"
              >
                Lưu & Đóng Ticket
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Add Ticket */}
      {isCreateOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Tiếp nhận Ticket Yêu cầu Hỗ trợ Mới
              </h3>
              <button onClick={() => setIsCreateOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCreateSubmit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Tiêu đề sự cố / Yêu cầu *</label>
                <input
                  type="text"
                  required
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Tên khách hàng</label>
                  <input
                    type="text"
                    value={formData.customerName}
                    onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Số điện thoại</label>
                  <input
                    type="text"
                    value={formData.customerPhone}
                    onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Kênh tiếp nhận</label>
                  <select
                    value={formData.channel}
                    onChange={(e) => setFormData({ ...formData, channel: e.target.value as Ticket['channel'] })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="Hotline">Hotline</option>
                    <option value="Email">Email</option>
                    <option value="Zalo OA">Zalo OA</option>
                    <option value="Cổng Khách Hàng">Cổng Khách Hàng</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Độ ưu tiên SLA</label>
                  <select
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: e.target.value as Ticket['priority'] })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-semibold"
                  >
                    <option value="P1 - Khẩn cấp">P1 - Khẩn cấp (SLA 2h)</option>
                    <option value="P2 - Cao">P2 - Cao (SLA 4h)</option>
                    <option value="P3 - Trung bình">P3 - Trung bình (SLA 8h)</option>
                    <option value="P4 - Thấp">P4 - Thấp (SLA 24h)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Mô tả chi tiết sự cố</label>
                <textarea
                  rows={3}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-white font-bold ${themeDef.classes.primaryButton}`}
                >
                  Lưu & Phân công
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
