# A+ Enterprise CRM — Nền Tảng Quản Trị Doanh Nghiệp Multi-Tenant

Nền tảng Quản trị Quan hệ Khách hàng (CRM) và Vận hành Doanh nghiệp B2B theo kiến trúc **Multi-Tenant Cô Lập Cơ Sở Dữ Liệu (Database-per-Tenant Isolation)**. Hệ thống phân định rõ ràng giữa **Quản trị nền tảng (Super Admin / Platform Portal)** và **Quản trị viên công ty (Company Admin)**, đồng thời hỗ trợ chu trình đăng ký doanh nghiệp, phê duyệt hạ tầng và quản trị nhân sự phân quyền linh hoạt.

---

## 📑 Mục Lục

1. [Quy Trình Vận Hành Doanh Nghiệp (Multi-Tenant Lifecycle)](#1-quy-trình-vận-hành-doanh-nghiệp-multi-tenant-lifecycle)
2. [Phân Định Giữa Super Admin Và Company Admin](#2-phân-định-giữa-super-admin-và-company-admin)
3. [Dọn Sạch Dữ Liệu Mô Phỏng (Clean Slate Data)](#3-dọn-sạch-dữ-liệu-mô-phỏng-clean-slate-data)
4. [Cơ Chế Phân Quyền & Vai Trò (RBAC)](#4-cơ-chế-phân-quyền--vai-trò-rbac)
5. [Luồng Nghiệp Vụ Khép Kín (End-to-End Workflow)](#5-luồng-nghiệp-vụ-khép-kín-end-to-end-workflow)
6. [Hướng Dẫn Chạy Thử Cho Công Ty Aplus](#6-hướng-dẫn-chạy-thử-cho-công-ty-aplus)
7. [Hướng Dẫn Cài Đặt & Vận Hành Trên Local](#7-hướng-dẫn-cài-đặt--vận-hành-trên-local)

---

## 1. Quy Trình Vận Hành Doanh Nghiệp (Multi-Tenant Lifecycle)

```mermaid
sequenceDiagram
    autonumber
    actor Owner as Chủ Doanh Nghiệp
    participant Web as Cổng Đăng Ký CRM
    actor SuperAdmin as Super Admin (Platform)
    participant CoreDB as CRM_CORE Registry
    participant TenantDB as CSDL Doanh Nghiệp (DB_APLUS)
    actor Staff as Nhân Viên Được Mời

    Owner->>Web: Điền tên công ty (aplus) -> Tự động sinh mã (APLUS)
    Owner->>Web: Nhập thông tin Admin & gửi yêu cầu
    Web->>SuperAdmin: Yêu cầu đăng ký mới với trạng thái PENDING
    SuperAdmin->>CoreDB: Duyệt yêu cầu tại Platform Portal (/platform)
    SuperAdmin->>TenantDB: Khởi tạo Database độc lập DB_APLUS & Schema
    CoreDB-->>Owner: Cấp quyền Admin công ty & kích hoạt tài khoản
    Owner->>TenantDB: Đăng nhập với quyền Admin (Dữ liệu sạch 100%)
    Owner->>TenantDB: Tạo danh sách nhân sự & cấp quyền (Sale Manager, Sales Staff, Kế toán...)
    Staff->>TenantDB: Đăng nhập theo quyền hạn được phân
```

---

## 2. Phân Định Giữa Super Admin Và Company Admin

- **Super Admin (Quản trị nền tảng - Platform Portal `/platform`):**
  - Quản trị hạ tầng toàn hệ thống, danh sách tổ chức thuê bao (Tenants).
  - Tiếp nhận và phê duyệt các yêu cầu đăng ký công ty mới để cấp phát CSDL riêng biệt.
  - Theo dõi trạng thái kết nối CSDL, dung lượng lưu trữ, khóa/mở tổ chức, cấp lại link mật khẩu khẩn cấp.
  - **Nguyên tắc bảo mật Zero-Knowledge:** Super Admin **không** can thiệp và không xem dữ liệu kinh doanh nội bộ (khách hàng, cơ hội bán hàng, sổ quỹ, tiền lương) của từng công ty.

- **Admin Công Ty (Company Admin):**
  - Là tài khoản của người đăng ký tạo doanh nghiệp (ví dụ: công ty `aplus`).
  - Có toàn quyền truy cập tất cả các phân hệ CRM của công ty mình (Dashboard, Báo cáo 3 cấp, Bán hàng, Kho vận, Kỹ thuật, Kế toán, Nhân sự HR, Cài đặt).
  - Quản lý cơ cấu phòng ban, tạo danh sách nhân viên và gán nhóm quyền tương ứng cho từng nhân viên.

---

## 3. Dọn Sạch Dữ Liệu Mô Phỏng (Clean Slate Data)

- Toàn bộ dữ liệu mô phỏng trước đây (leads giả lập, deals mô phỏng, khách hàng mẫu của Vingroup) đã được dọn sạch đối với công ty mới đăng ký hoặc công ty `aplus`.
- Khi tài khoản Admin của `aplus` đăng nhập:
  - Bảng Lead, Khách hàng, Cơ hội bán hàng, Báo giá, Hợp đồng, Sản phẩm, Kho vận đều khởi tạo ở trạng thái **trống (`[]`)**.
  - Danh sách nhân sự chỉ chứa tài khoản Quản trị viên khởi tạo, sẵn sàng để Admin thêm nhân sự thật của doanh nghiệp mình.

---

## 4. Cơ Chế Phân Quyền & Vai Trò (RBAC)

Tài khoản Admin công ty có thể tạo và phân công các vai trò chuyên biệt:

| Vai trò (Role) | Nhãn hiển thị | Quyền hạn & Phạm vi truy cập |
| :--- | :--- | :--- |
| **Admin** | `Admin` | Toàn quyền điều hành công ty: Xem và thao tác tất cả module, quản lý nhân viên, cấu hình cài đặt. |
| **Director** | `Ban Giám Đốc` | Xem Dashboard chiến lược, toàn bộ báo cáo doanh thu, phễu bán hàng, dòng tiền và OKR. |
| **Sales Manager** | `Sale Manager` | Giám sát toàn bộ phòng Sales, duyệt báo giá & hợp đồng, phân bổ Lead, 8 báo cáo chuyên sâu Sales. |
| **Sales Staff** | `Sales Staff` | Quản lý Lead và Deal được phân bổ cho cá nhân, tạo báo giá, theo dõi tiến độ cá nhân. |
| **Technical Manager** | `TP. Kỹ Thuật` | Quản lý khảo sát công trình, bóc tách BOM vật tư, nghiệm thu và dịch vụ bảo hành kỹ thuật. |
| **Accountant** | `Kế Toán` | Quản lý hóa đơn VAT, đối soát công nợ phải thu/phải trả, theo dõi giao dịch thu chi. |
| **HR Staff** | `Nhân Sự` | Quản lý danh sách hồ sơ nhân sự, hợp đồng lao động và bảo hiểm xã hội. |
| **Warehouse Staff** | `Nhân Viên Kho`| Quản lý xuất nhập kho hàng hóa, kiểm kê tồn kho theo lô/date. |

---

## 5. Hướng Dẫn Chạy Thử Cho Công Ty Aplus

### Bước 1: Đăng ký doanh nghiệp
1. Truy cập `http://localhost:3000/`.
2. Bấm vào liên kết **"Đăng ký doanh nghiệp mới"**.
3. Điền thông tin:
   - **Tên doanh nghiệp:** `aplus` (Hệ thống tự động sinh mã công ty: `APLUS`).
   - **Mã số thuế:** (tùy chọn, ví dụ `0109988776`).
   - **Họ và tên Quản trị viên:** `Nguyễn Văn Aplus`.
   - **Email:** `admin@aplus.vn`.
   - **Mật khẩu:** Nhập mật khẩu (ví dụ `password123`).
   - Tích chọn đồng ý điều khoản và bấm **"Đăng Ký Doanh Nghiệp"**.
4. Màn hình xác nhận hiển thị thông tin đăng ký thành công với trạng thái `PENDING (Chờ Super Admin phê duyệt)`. Bấm nút **"Đến Cổng Super Admin để duyệt ngay"**.

### Bước 2: Super Admin phê duyệt & cấp phát CSDL
1. Tại Cổng Quản trị Nền tảng (`/platform`), nhìn vào mục **"Yêu Cầu Đăng Ký Doanh Nghiệp Chờ Duyệt"**.
2. Thấy yêu cầu đăng ký của công ty `aplus` (Mã `APLUS`, CSDL dự kiến `DB_APLUS`).
3. Bấm nút **"Duyệt & Tạo CSDL DB_APLUS"**.
4. Quá trình cấp phát hoàn tất, hộp thoại thông báo thành công xuất hiện. Bấm **"Vào CRM với tư cách Admin công ty aplus"**.

### Bước 3: Admin quản trị và thêm nhân viên
1. Giao diện CRM của công ty `aplus` mở ra:
   - Header hiển thị tên doanh nghiệp **aplus** và nhãn vai trò **Admin**.
   - Dữ liệu kinh doanh bắt đầu từ 0 (danh sách sạch, không có dữ liệu mô phỏng cũ).
2. Vào phân hệ **Quản lý nhân sự -> Nhân viên** (hoặc **Cài đặt hệ thống -> Nhân sự & Thành viên**).
3. Bấm **"Tiếp Nhận Nhân Viên Mới (Onboarding Wizard)"** để thêm nhân viên và lựa chọn phân quyền mong muốn (`Sale Manager`, `Sales Staff`, `Technical Manager`, `Accountant`...).

> **Lưu ý:** Chỉ số hiển thị trên Dashboard và các danh sách dữ liệu được tự động khóa theo đúng quyền hạn của tài khoản đăng nhập, đảm bảo không xảy ra hiện tượng chồng chéo hoặc rò rỉ dữ liệu giữa các bộ phận.

---

## 4. Luồng Nghiệp Vụ Khép Kín (End-to-End Workflow)

```mermaid
graph TD
    A[1. Tiếp nhận Lead] --> B[2. Thẩm định & Phân bổ Lead]
    B --> C[3. Chuyển đổi thành Cơ hội / Deal]
    C --> D[4. Khảo sát Kỹ thuật & Bóc tách BOM]
    D --> E[5. Tạo Báo giá & Phê duyệt]
    E --> F[6. Đàm phán & Ký Hợp đồng]
    F --> G[7. Lệnh Xuất kho & Giao hàng Logistics]
    G --> H[8. Triển khai Kỹ thuật & Ký Nghiệm thu]
    H --> I[9. Kế toán Đối soát & Thu hồi Công nợ]
    I --> J[10. Chăm sóc Sau bán & Bảo hành SLA]
```

### Chi tiết các bước thực hiện:

1. **Tiếp nhận & Nuôi dưỡng Lead:**
   - Thu thập thông tin từ Website, Hotline, Sự kiện hoặc đối tác giới thiệu.
   - Trưởng phòng kinh doanh hoặc hệ thống tự động điều phối Lead cho từng Chuyên viên Sales.
2. **Phát triển Cơ hội (Sales Opportunity / Deal):**
   - Theo dõi từng cơ hội qua 5 giai đoạn: *Tiếp cận* ➔ *Khảo sát* ➔ *Gửi báo giá* ➔ *Đàm phán* ➔ *Chốt thành công (Won)*.
   - Đánh giá xác suất thắng (Win Probability) và giá trị dự kiến.
3. **Phối hợp Kỹ thuật & Lập Báo giá (Quotation & BOM):**
   - Đội Kỹ thuật tiến hành khảo sát thực địa, xây dựng cấu hình thiết bị (Bill of Materials - BOM).
   - Sales lập báo giá chính thức, áp dụng chính sách chiết khấu và gửi trình ký cấp quản lý.
4. **Hợp đồng & Đơn hàng:**
   - Ký kết hợp đồng kinh tế với các mốc thanh toán, điều khoản bảo hành và lịch giao hàng cụ thể.
5. **Kho vận & Logistics:**
   - Lập phiếu xuất kho, đóng gói, bàn giao đơn vị vận chuyển kèm biên bản giao nhận có ký nhận.
6. **Nghiệm thu, Kế toán & Dịch vụ hậu mãi:**
   - Bàn giao thiết bị hoàn tất, ký biên bản nghiệm thu (Acceptance Certificate).
   - Kế toán xuất hóa đơn điện tử, theo dõi lịch thu hồi công nợ.
   - Đội kỹ thuật kích hoạt thời hạn bảo hành và giám sát cảnh báo SLA định kỳ.

---

## 5. Hệ Thống Báo Cáo Phân Tích 3 Cấp

Cấu trúc menu báo cáo được tổ chức theo mô hình cây 3 cấp chuẩn Enterprise:
- **Cấp 1 (-):** Menu Báo cáo
- **Cấp 2 (>):** Nhóm lĩnh vực (Sales, Kho vận, Kỹ thuật, Kế toán, Nhân sự)
- **Cấp 3 (>>):** Báo cáo chuyên sâu chi tiết

### Danh mục Báo cáo Sales chuyên sâu:
1. **Tổng quan Sales (`/reports/sales/overview`):** Bức tranh tài chính tổng hợp, tốc độ tăng trưởng so với cùng kỳ.
2. **Doanh thu (`/reports/sales/revenue`):** Cơ cấu doanh thu theo dòng sản phẩm, thị trường và nhân viên.
3. **Dự báo doanh số (`/reports/sales/forecast`):** Dự báo dòng tiền dựa trên tỷ lệ chuyển đổi của các Deal trong pipeline.
4. **Phễu bán hàng (`/reports/sales/funnel`):** Đo lường tỷ lệ rớt khách qua từng nấc thang bán hàng.
5. **Deal thắng (`/reports/sales/won`):** Thống kê các hợp đồng đã chốt thành công, chu kỳ bán hàng trung bình.
6. **Deal thua (`/reports/sales/lost`):** Phân tích nguyên nhân thất bại (giá, tính năng, đối thủ...) để cải thiện chiến lược.
7. **Năng suất Sales (`/reports/sales/productivity`):** Đánh giá khối lượng công việc, số cuộc gọi, cuộc hẹn và tỷ lệ hoàn thành KPI.
8. **Báo cáo Lead (`/reports/sales/leads`):** Hiệu quả chuyển đổi Lead từ các kênh tiếp thị.

---

## 6. Cấu Trúc Thư Mục Dự Án

```
remix-3-enterprise-crm-a+/
├── src/
│   ├── components/            # Các UI component tái sử dụng
│   │   ├── common/            # Nút bấm, Logo, Modal, Bộ chọn cột, Toast...
│   │   ├── layout/            # Sidebar, Header, Breadcrumb, Search, MobileNav...
│   │   └── modals/            # Modal xem chi tiết, đặc tả kỹ thuật...
│   ├── context/               # Quản lý State phân tầng (CRM, Sales, Logistics...)
│   ├── data/                  # Dữ liệu Mock khởi tạo cho toàn bộ hệ thống
│   ├── hooks/                 # Custom React Hooks (ẩn/hiện cột bảng, responsive...)
│   ├── i18n/                  # Bộ từ điển chuyển đổi ngôn ngữ Việt - Anh
│   ├── services/              # Lớp dịch vụ xử lý dữ liệu và logic nghiệp vụ
│   ├── types/                 # Khai báo TypeScript Interfaces & Types
│   ├── views/                 # Các màn hình chính theo từng phân hệ
│   │   ├── dashboards/        # Dashboard chuyên biệt theo 5 vị trí
│   │   ├── sales/             # Màn hình quản lý Lead, Deal, Khách hàng, Báo giá...
│   │   ├── inventory/         # Quản lý kho, tồn kho, xuất nhập
│   │   ├── logistics/         # Quản lý điều vận, đơn giao, COD
│   │   ├── technical/         # Dự án kỹ thuật, BOM, bảo hành
│   │   ├── hr/                # Quản lý nhân sự, hồ sơ cá nhân, BHXH
│   │   ├── reports/           # 8 Báo cáo Sales & Báo cáo các phòng ban
│   │   └── settings/          # Cài đặt người dùng, phân quyền, hệ thống
│   ├── App.tsx                # Điều hướng ứng dụng và layout chính
│   ├── main.tsx               # Entry point ứng dụng
│   └── index.css              # Thiết lập Style Tokens & TailwindCSS
├── package.json               # Cấu hình gói thư viện & npm scripts
├── vite.config.ts             # Cấu hình Vite bundler & path aliases
└── README.md                  # Tài liệu hướng dẫn sử dụng & vận hành
```

---

## 7. Hướng Dẫn Cài Đặt & Vận Hành Trên Local

### Yêu Cầu Môi Trường
- **Node.js:** Phiên bản 18.x trở lên (khuyến nghị Node 20 LTS)
- **Trình quản lý gói:** `npm` (đi kèm Node.js) hoặc `pnpm` / `yarn`

### Các Bước Thực Hiện

1. **Cài đặt thư viện phụ thuộc:**
   ```bash
   npm install
   ```

2. **Khởi chạy ứng dụng trên môi trường phát triển (Local Development):**
   ```bash
   npm run dev
   ```
   Ứng dụng sẽ khởi chạy tại địa chỉ:
   - **Local:** [http://localhost:3000/](http://localhost:3000/)
   - **Network:** Xem IP hiển thị trên terminal (dùng để truy cập thử nghiệm qua thiết bị di động trong cùng mạng LAN).

3. **Kiểm tra mã nguồn (TypeScript Linting):**
   ```bash
   npm run lint
   ```

4. **Đóng gói sản phẩm (Production Build):**
   ```bash
   npm run build
   ```
   Bản build hoàn chỉnh sẽ được xuất ra thư mục `dist/`.

5. **Xem thử bản build (Preview):**
   ```bash
   npm run preview
   ```

---

## 8. Tiện Ích & Trải Nghiệm Người Dùng

- **Tìm kiếm toàn cục siêu tốc:** Nhấn phím tắt `/` hoặc tổ hợp phím `Ctrl + K` (hoặc `Cmd + K` trên macOS) để mở hộp tìm kiếm thông minh; hỗ trợ tìm nhanh mã khách hàng, số báo giá, tên hợp đồng hoặc danh bạ nội bộ.
- **Tùy biến bảng màu Pastel:** Bấm vào Avatar cá nhân góc trên bên phải để chọn nhanh một trong 10 bảng màu sắc nét (Corporate Blue, Soft Amber, Pastel Emerald, Cyan, Purple...).
- **Chế độ Sáng / Tối thông minh:** Hỗ trợ giao diện nền tối bảo vệ mắt, tự động đồng bộ theo tùy chọn hệ điều hành.
- **Thanh bên (Sidebar) thông minh:** Khi thu gọn để mở rộng không gian làm việc, người dùng chỉ cần rê chuột (hover) vào thanh bên để mở rộng tạm thời xem chi tiết menu mà không làm dịch chuyển bố cục trang.
- **Tùy biến cột dữ liệu:** Bấm vào biểu tượng bánh răng trên các bảng dữ liệu để bật/tắt hoặc sắp xếp lại các cột hiển thị theo nhu cầu tác nghiệp cá nhân.

---

*Hệ thống được phát triển & vận hành trên nền tảng **A+ Enterprise CRM Multi-Tenant Architecture**.*
