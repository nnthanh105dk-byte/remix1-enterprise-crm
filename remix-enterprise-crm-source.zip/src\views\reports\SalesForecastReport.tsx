import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { ReportFilterState } from '../../types/crm';
import { ReportFilterBar } from '../../components/reports/ReportFilterBar';
import { ExecutiveStatCard } from '../../components/reports/ReportCharts';
import {
  MOCK_PIPELINE_DEALS,
  MOCK_SALES_REPS,
  MockSalesRep,
} from '../../data/mockReportsData';
import {
  Target,
  Edit3,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight,
  TrendingUp,
  Info,
  History,
} from 'lucide-react';

interface SalesForecastReportProps {
  filter: ReportFilterState;
  onChangeFilter: (updated: Partial<ReportFilterState>) => void;
}

export const SalesForecastReport: React.FC<SalesForecastReportProps> = ({
  filter,
  onChangeFilter,
}) => {
  const { showToast, themeDef } = useCRM();

  // Sales reps with local override state
  const [repsData, setRepsData] = useState<MockSalesRep[]>(MOCK_SALES_REPS);
  const [editingRepId, setEditingRepId] = useState<string | null>(null);
  const [overrideValueInput, setOverrideValueInput] = useState<string>('');
  const [overrideModalOpen, setOverrideModalOpen] = useState(false);

  // Filtered deals
  const filteredDeals = MOCK_PIPELINE_DEALS.filter((d) => {
    if (filter.teamId !== 'all' && d.teamId !== filter.teamId) return false;
    if (filter.salesRepId !== 'all' && d.repId !== filter.salesRepId) return false;
    if (filter.region !== 'all' && d.region !== filter.region) return false;
    return true;
  });

  // 3 Category Totals
  const commitDeals = filteredDeals.filter((d) => d.forecastCategory === 'commit');
  const bestCaseDeals = filteredDeals.filter((d) => d.forecastCategory === 'best_case');
  const pipelineCategoryDeals = filteredDeals.filter((d) => d.forecastCategory === 'pipeline');

  const commitValue = commitDeals.reduce((sum, d) => sum + d.amount, 0);
  const bestCaseValue = bestCaseDeals.reduce((sum, d) => sum + d.amount, 0);
  const pipelineValue = pipelineCategoryDeals.reduce((sum, d) => sum + d.amount, 0);

  // Weighted Pipeline Value: Amount * Probability
  const weightedPipelineTotal = filteredDeals.reduce((sum, d) => sum + Math.round((d.amount * d.probability) / 100), 0);

  // Target Quota
  const totalTargetQuota = 8500000000; // 8.5 Tỷ
  const forecastGap = totalTargetQuota - (commitValue + Math.round(bestCaseValue * 0.7));

  // Handle Manual Override
  const handleOpenOverride = (rep: MockSalesRep) => {
    setEditingRepId(rep.id);
    setOverrideValueInput((rep.manualForecastOverride || rep.actualRevenue).toString());
    setOverrideModalOpen(true);
  };

  const handleSaveOverride = () => {
    if (!editingRepId) return;
    const num = parseFloat(overrideValueInput) || 0;
    const author = 'Trần Văn Giám Đốc (Sales Director)';
    const time = new Date().toLocaleString('vi-VN');

    setRepsData((prev) =>
      prev.map((r) =>
        r.id === editingRepId
          ? {
              ...r,
              manualForecastOverride: num,
              overrideAuthor: author,
              overrideTime: time,
            }
          : r
      )
    );

    setOverrideModalOpen(false);
    showToast('Đã ghi nhận điều chỉnh', `Cập nhật dự báo thủ công cho nhân viên thành công vào ${time}.`);
  };

  // Sorted deals by Expected Close Date
  const sortedDeals = [...filteredDeals].sort(
    (a, b) => new Date(a.expectedCloseDate).getTime() - new Date(b.expectedCloseDate).getTime()
  );

  return (
    <div className="space-y-6">
      {/* Shared Filter Bar */}
      <ReportFilterBar
        filter={filter}
        onChangeFilter={onChangeFilter}
        reportTitle="Dự báo doanh số (Sales Forecast)"
      />

      {/* 3 Forecasting Categories + Weighted Pipeline + Gap Card (Executive Style: Chỉ hiển thị Tiêu đề và Con số, bấm ! xem giải thích) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <ExecutiveStatCard
          title="1. Chắc chắn (Commit)"
          value={`${(commitValue / 1000000000).toFixed(2)} Tỷ`}
          badge="Xác suất ≥ 80%"
          icon={CheckCircle2}
          iconColor="bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
          explanation={`${commitDeals.length} hợp đồng trong giai đoạn đàm phán cuối, dự kiến hoàn tất ký kết trong kỳ.`}
        />

        <ExecutiveStatCard
          title="2. Khả thi (Best Case)"
          value={`${(bestCaseValue / 1000000000).toFixed(2)} Tỷ`}
          badge="Xác suất 50 - 79%"
          icon={Target}
          iconColor="bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-800"
          explanation={`${bestCaseDeals.length} hợp đồng đang thẩm định ngân sách và bảo vệ phương án kỹ thuật.`}
        />

        <ExecutiveStatCard
          title="3. Tiềm năng (Pipeline)"
          value={`${(pipelineValue / 1000000000).toFixed(2)} Tỷ`}
          badge="Xác suất 20 - 49%"
          icon={Layers}
          iconColor="bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800"
          explanation={`${pipelineCategoryDeals.length} hợp đồng giai đoạn đầu tiếp cận và khám phá nhu cầu.`}
        />

        <ExecutiveStatCard
          title="Dự báo có trọng số"
          value={`${(weightedPipelineTotal / 1000000000).toFixed(2)} Tỷ`}
          valueColor="text-[#002659] dark:text-sky-300"
          icon={TrendingUp}
          iconColor="bg-indigo-50 dark:bg-indigo-950/50 text-[#002659] dark:text-sky-300 border-indigo-200 dark:border-indigo-800"
          explanation={`Khoảng thiếu hụt (Gap): ${(Math.max(0, forecastGap) / 1000000000).toFixed(2)} Tỷ so với Quota mục tiêu ${(totalTargetQuota / 1000000000).toFixed(1)} Tỷ.`}
        />
      </div>

      {/* Manual Forecast Override Table (Trưởng phòng chỉnh tay có ghi log) */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-4`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="section-title">
              <Edit3 className="w-4.5 h-4.5 text-sky-500 mr-2 shrink-0" />
              Điều chỉnh dự báo thủ công theo nhân viên (Manager Override)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Trưởng bộ phận có quyền ghi đè giá trị dự báo thực tế dựa trên đánh giá thị trường và ghi nhận lịch sử
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Nhân viên sales</th>
                <th className="py-2.5 px-3">Đội Sales</th>
                <th className="py-2.5 px-3 text-right">Chỉ tiêu (Quota)</th>
                <th className="py-2.5 px-3 text-right">Dự báo hệ thống tính</th>
                <th className="py-2.5 px-3 text-right">Dự báo ghi đè (Override)</th>
                <th className="py-2.5 px-3">Lịch sử sửa đổi</th>
                <th className="py-2.5 px-3 text-center">Thao tác</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {repsData.slice(0, 8).map((rep) => {
                const systemForecast = rep.actualRevenue + Math.round(rep.monthlyQuota * 0.25);
                const hasOverride = rep.manualForecastOverride !== undefined;

                return (
                  <tr key={rep.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <img src={rep.avatar} alt="" className="w-6 h-6 rounded-full object-cover shrink-0" />
                        <span className="font-bold text-slate-900 dark:text-white">{rep.name}</span>
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">{rep.teamName}</td>
                    <td className="py-3 px-3 text-right font-mono">
                      {(rep.monthlyQuota / 1000000).toLocaleString('vi-VN')} Tr
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-semibold text-slate-700 dark:text-slate-300">
                      {(systemForecast / 1000000).toLocaleString('vi-VN')} Tr
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold">
                      {hasOverride ? (
                        <span className="text-amber-600 dark:text-amber-400">
                          {((rep.manualForecastOverride || 0) / 1000000).toLocaleString('vi-VN')} Tr
                        </span>
                      ) : (
                        <span className="text-slate-400 font-normal italic">Chưa can thiệp</span>
                      )}
                    </td>
                    <td className="py-3 px-3">
                      {hasOverride ? (
                        <div className="text-[11px] text-slate-500">
                          <p className="font-semibold text-slate-700 dark:text-slate-300">{rep.overrideAuthor}</p>
                          <p className="flex items-center gap-1 text-[10px] text-slate-400">
                            <History className="w-3 h-3" /> {rep.overrideTime}
                          </p>
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-400">Tự động</span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => handleOpenOverride(rep)}
                        className="px-2.5 py-1 rounded-md text-xs font-semibold bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 hover:bg-sky-100 transition-colors border border-sky-200 dark:border-sky-800"
                      >
                        Chỉnh sửa
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Deals in Forecast Pipeline Table (Sorted by Expected Close Date) */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-4`}>
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="section-title">
              <Calendar className="w-4.5 h-4.5 text-emerald-500 mr-2 shrink-0" />
              Danh sách Deal cấu thành Dự báo (Sắp xếp theo ngày dự kiến chốt)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Tổng hợp {sortedDeals.length} thương vụ đang mở phân loại theo nhóm cam kết và xác suất thành công
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">Mã & Tên thương vụ</th>
                <th className="py-3 px-3">Khách hàng</th>
                <th className="py-3 px-3 text-right">Giá trị Deal</th>
                <th className="py-3 px-3 text-center">Xác suất</th>
                <th className="py-3 px-3 text-right">Giá trị trọng số</th>
                <th className="py-3 px-3 text-center">Nhóm dự báo</th>
                <th className="py-3 px-3">Ngày dự kiến chốt</th>
                <th className="py-3 px-3">Phụ trách</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {sortedDeals.map((deal) => {
                const weighted = Math.round((deal.amount * deal.probability) / 100);

                return (
                  <tr key={deal.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-3">
                      <p className="font-bold text-slate-900 dark:text-white">{deal.title}</p>
                      <span className="font-mono text-[10px] text-slate-500">{deal.code}</span>
                    </td>
                    <td className="py-3 px-3">
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{deal.customerCompany}</p>
                      <p className="text-[11px] text-slate-500">{deal.customerName}</p>
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                      {(deal.amount / 1000000).toLocaleString('vi-VN')} Tr
                    </td>
                    <td className="py-3 px-3 text-center font-bold text-sky-600">
                      {deal.probability}%
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {(weighted / 1000000).toLocaleString('vi-VN')} Tr
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span
                        className={`inline-block px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          deal.forecastCategory === 'commit'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : deal.forecastCategory === 'best_case'
                            ? 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                            : 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300'
                        }`}
                      >
                        {deal.forecastCategory === 'commit' ? 'Commit' : deal.forecastCategory === 'best_case' ? 'Best Case' : 'Pipeline'}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-semibold text-slate-800 dark:text-slate-200">
                      {deal.expectedCloseDate}
                    </td>
                    <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                      {deal.repName}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Override Modal */}
      {overrideModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Edit3 className="w-5 h-5 text-sky-500" />
              Ghi đè dự báo (Forecast Override)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Nhập con số dự báo mới cho nhân viên. Thao tác này sẽ lưu tên bạn và mốc thời gian vào sổ kiểm toán.
            </p>

            <div className="mb-4">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Giá trị dự báo mới (VND)
              </label>
              <input
                type="number"
                value={overrideValueInput}
                onChange={(e) => setOverrideValueInput(e.target.value)}
                className="w-full text-sm font-mono px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                onClick={() => setOverrideModalOpen(false)}
                className="px-3 py-1.5 text-xs font-medium rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                Hủy
              </button>
              <button
                onClick={handleSaveOverride}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001f4a] shadow-xs transition-colors"
              >
                Lưu ghi đè
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
