import { UserRole, ActiveModule } from './crm';

// ==========================================
// 1. NGƯỜI DÙNG & TÀI KHOẢN (USER)
// ==========================================

export type UserAccountStatus = 'active' | 'pending' | 'locked';

export interface UserSession {
  id: string;
  device: string;
  browser: string;
  ipAddress: string;
  loginTime: string;
  isCurrent: boolean;
}

export interface UserLoginHistory {
  id: string;
  timestamp: string;
  device: string;
  browser: string;
  ipAddress: string;
  status: 'SUCCESS' | 'FAILED' | 'LOCKED';
  failureReason?: string;
}

export interface SystemUser {
  id: string;
  employeeId?: string; // Liên kết 1-1 với Quản lý nhân sự
  fullName: string;
  username: string; // Tên đăng nhập hoặc email
  email: string;
  phone: string;
  avatar: string;
  departmentId?: string;
  departmentName: string;
  teamName?: string;
  positionName: string;
  roleIds: string[]; // Một người dùng có thể thuộc nhiều nhóm quyền
  status: UserAccountStatus;
  lastLogin?: string;
  invitedAt?: string;
  isSystemAdmin?: boolean; // Cờ nhận biết tài khoản quản trị viên
  activeSessions: UserSession[];
  loginHistories: UserLoginHistory[];
  createdAt: string;
}

// ==========================================
// 2. NHÓM QUYỀN & MA TRẬN PHÂN QUYỀN (RBAC)
// ==========================================

export type PermissionActionType = 
  | 'view' 
  | 'create' 
  | 'edit' 
  | 'delete' 
  | 'approve' 
  | 'export' 
  | 'print';

export type DataScope = 'personal' | 'team' | 'department' | 'all';

export type FieldVisibility = 'full' | 'masked' | 'hidden';

export interface ModulePermissionRule {
  moduleId: string;
  moduleLabel: string;
  parentGroup: string; // 'Báo cáo' | 'Quản lý kho' | 'Quản lý Sales' | 'Vận chuyển' | 'Kế toán' | 'Kỹ thuật' | 'Quản lý nhân sự' | 'Cài đặt hệ thống'
  actions: PermissionActionType[];
  dataScope: DataScope;
}

export interface SensitiveFieldPermissionRule {
  fieldKey: 'costAndMargin' | 'salaryAndAllowance' | 'employeeIdCardTaxBank' | 'socialInsurance' | 'supplierBankInfo';
  fieldLabel: string;
  visibility: FieldVisibility;
}

export interface PermissionGroup {
  id: string;
  code: string;
  name: string;
  description: string;
  isSystem: boolean; // Hệ thống: không thể xóa
  userCount: number;
  moduleRules: ModulePermissionRule[];
  fieldRules: SensitiveFieldPermissionRule[];
  createdAt: string;
  updatedAt: string;
}

export interface PermissionChangeLog {
  id: string;
  groupId: string;
  groupName: string;
  performedBy: string;
  timestamp: string;
  action: 'CREATE' | 'UPDATE' | 'DELETE' | 'CLONE';
  description: string;
  oldValue?: string;
  newValue?: string;
}

// ==========================================
// 3. CẤU HÌNH HỆ THỐNG (SYSTEM CONFIG)
// ==========================================

export interface CompanyInfoConfig {
  companyName: string;
  shortName: string;
  taxCode: string;
  legalRepresentative: string;
  address: string;
  phone: string;
  email: string;
  website: string;
  bankAccount: string;
  bankName: string;
  bankBranch: string;
  logoUrl: string;
  stampSignatureUrl?: string;
  systemIconUrl?: string;
  primaryColor?: string;
  defaultTheme?: string;
}

export interface PrintSignerSlot {
  id: string;
  title: string; // ví dụ: "Người lập biểu", "Thủ kho", "Kế toán trưởng", "Giám đốc", "Khách hàng"
  note?: string; // "(Ký, ghi rõ họ tên)"
  required: boolean;
}

export interface PrintTemplateConfig {
  docType: string; // 'quotation' | 'delivery_note' | 'receipt' | 'payment_request' | 'handover' | 'acceptance'
  docName: string;
  pageSize: 'A4' | 'A5';
  orientation: 'portrait' | 'landscape';
  headerText: string;
  footerText: string;
  showCompanyLogo: boolean;
  showCompanyInfo: boolean;
  showStamp: boolean;
  signerSlots: PrintSignerSlot[];
}

export interface DocumentNumberingRule {
  id: string;
  docType: string;
  docName: string;
  prefix: string; // LEAD, KH, CH, BG, DH, HD, HDON, PT, DMH, HDM, PGH, CX, BBG, TH, DNTT, YCKT, DA, BBNT, YCBH, XBH, PN, PX
  numberLength: number; // 4 -> 0001
  resetYearly: boolean;
  currentNumber: number;
  sampleFormat: string; // ví dụ: BG-2026-0001
}

export interface SecurityPolicyConfig {
  minPasswordLength: number; // >= 8
  requireUppercase: boolean;
  requireLowercase: boolean;
  requireNumber: boolean;
  requireSpecialChar: boolean;
  forceChangePasswordFirstLogin: boolean;
  passwordExpireDays: number; // 0 = Không hết hạn, hoặc 90 ngày
  maxFailedLogins: number; // 5 lần
  lockoutDurationMinutes: number; // 15 phút
  sessionTimeoutMinutes: number; // 30 phút
  auditLogRetentionMonths: number; // 12 tháng
}

export interface HolidaySchedule {
  id: string;
  name: string;
  startDate: string;
  endDate: string;
  year: number;
}

export interface WorkingTimeConfig {
  workingHoursStart: string; // 08:00
  workingHoursEnd: string; // 17:30
  lunchBreakStart: string; // 12:00
  lunchBreakEnd: string; // 13:30
  workingDays: ('T2' | 'T3' | 'T4' | 'T5' | 'T6' | 'T7' | 'CN')[];
  timezone: string; // GMT+7
  dateFormat: string; // DD/MM/YYYY
  timeFormat: string; // 24h
  currency: string; // VND
  decimalPrecision: number; // 0
  holidays: HolidaySchedule[];
}

export interface NotificationTemplateConfig {
  id: string;
  eventCode: string;
  eventName: string;
  inAppEnabled: boolean;
  emailEnabled: boolean;
  titleTemplate: string;
  bodyTemplate: string;
  recipientRoles: string[];
}

export interface ApiKeyItem {
  id: string;
  name: string;
  keyMasked: string;
  scopes: string[];
  createdAt: string;
  expiresAt: string;
  lastUsedAt?: string;
  status: 'active' | 'revoked';
}

export interface IntegrationConnectionConfig {
  smtp: {
    host: string;
    port: number;
    username: string;
    passwordMasked: string;
    fromEmail: string;
    fromName: string;
    useSslTls: boolean;
    status: 'connected' | 'error' | 'untested';
    lastTestedAt?: string;
  };
  apiKeys: ApiKeyItem[];
  einvoiceDraft: {
    providerName: 'VNPT' | 'Viettel' | 'MISA' | 'Bkav';
    serviceUrl: string;
    status: 'placeholder';
  };
  accountingSoftwareDraft: {
    providerName: 'MISA SME' | 'Fast' | 'SAP B1';
    status: 'placeholder';
  };
  zaloOADraft: {
    oaId: string;
    status: 'placeholder';
  };
}

// ==========================================
// 4. CẤU HÌNH NGHIỆP VỤ & QUY TẮC DUYỆT (APP CONFIG)
// ==========================================

export interface AppParameterItem {
  id: string;
  key: string;
  tabGroup: 'general' | 'sales' | 'inventory' | 'logistics' | 'technical' | 'hr';
  name: string;
  description: string;
  value: any;
  valueType: 'number' | 'string' | 'boolean' | 'json';
  unit?: string;
  defaultValue: any;
  effectiveDate?: string;
  usedInModules: string[];
  updatedBy: string;
  updatedAt: string;
}

export interface ApprovalRuleTier {
  tierLevel: 1 | 2 | 3;
  approverType: 'role' | 'direct_manager' | 'specific_user';
  approverTarget: string; // role name hoặc 'Quản lý trực tiếp' hoặc user name
}

export interface DocumentApprovalRule {
  id: string;
  docType: 'Quotation' | 'SalesOrder' | 'PurchaseOrder' | 'PaymentRequest' | 'StockOutScrap' | 'StockAdjustment' | 'WarrantyStockOut' | 'Contract';
  docTypeName: string;
  priorityOrder: number;
  conditionDescription: string;
  conditionFormula: {
    field: string;
    operator: '>' | '>=' | '<' | '<=' | '==' | 'budget_exceeded';
    thresholdValue: number;
  };
  tier1Approver?: ApprovalRuleTier;
  tier2Approver?: ApprovalRuleTier;
  tier3Approver?: ApprovalRuleTier;
  isEnabled: boolean;
}

export interface ApprovalDelegation {
  id: string;
  delegatorName: string;
  delegateeName: string;
  fromDate: string;
  toDate: string;
  docTypes: string[];
  reason: string;
  status: 'active' | 'expired' | 'revoked';
}

// ==========================================
// 5. TỪ ĐIỂN GIÁ TRỊ (DICTIONARY)
// ==========================================

export interface DictionaryValueItem {
  id: string;
  code: string; // Mã bất biến sau khi tạo
  label: string;
  colorBadge?: string;
  sortOrder: number;
  isDefault: boolean;
  status: 'active' | 'disabled'; // Ngưng sử dụng
  isSystem: boolean; // Hệ thống: không thể xóa/ngưng
  usedCount: number; // Số nơi đang dùng
}

export interface DictionaryCategory {
  id: string;
  code: string;
  name: string;
  moduleGroup: 'sales' | 'inventory' | 'logistics' | 'technical' | 'hr';
  description: string;
  values: DictionaryValueItem[];
}

// ==========================================
// 6. DANH MỤC DỮ LIỆU (DIRECTORIES)
// ==========================================

export interface SupplierDirectoryItem {
  id: string;
  code: string;
  name: string;
  taxCode: string;
  address: string;
  contactPerson: string;
  phone: string;
  email: string;
  defaultPaymentTerm: string;
  bankAccount: string;
  bankName: string;
  groupName: string;
  totalPayableDebt: number; // Chỉ đọc: tổng nợ phải trả
  status: 'active' | 'disabled';
}

export interface ProductCategoryTree {
  id: string;
  code: string;
  name: string;
  parentId?: string;
  children?: ProductCategoryTree[];
}

export interface UnitOfMeasure {
  id: string;
  code: string;
  name: string;
  baseUnit?: string;
  conversionRate?: number; // 1 Thùng = 24 Hộp
}

export interface WarehouseDirectoryItem {
  id: string;
  code: string;
  name: string;
  address: string;
  managerName: string;
  type: 'regular' | 'defective_warranty' | 'transit';
  includeInAvailableStock: boolean; // Kho lỗi / bảo hành = false
  status: 'active' | 'disabled';
}

export interface RegionDirectoryItem {
  id: string;
  code: string;
  name: string;
  level: 'region' | 'province' | 'district';
  parentId?: string;
}

export interface BankDirectoryItem {
  id: string;
  code: string; // VCB, TCB...
  shortName: string;
  fullName: string;
}

export interface VatRateDirectoryItem {
  id: string;
  code: string;
  ratePercent: number; // 0, 5, 8, 10
  label: string;
  isDefault: boolean;
  status: 'active' | 'disabled';
}

// ==========================================
// 7. NHẬT KÝ ĐỒNG BỘ & HOẠT ĐỘNG (SYNC LOG)
// ==========================================

export interface SyncRunRecord {
  id: string;
  startTime: string;
  sourceDestination: string; // 'Webhook Lead Website', 'Email Nhận Đơn', 'API Đối tác GHTK', 'Đồng bộ Kho - Kỹ thuật'
  direction: 'INBOUND' | 'OUTBOUND';
  totalRecords: number;
  successRecords: number;
  failedRecords: number;
  skippedRecords: number;
  status: 'SUCCESS' | 'PARTIAL' | 'FAILED' | 'RUNNING';
  durationMs: number;
  triggeredBy: string; // 'Hệ thống tự động' hoặc tên người dùng
  errorDetails?: { line: number; entityId?: string; message: string }[];
}

export interface DataImportExportLog {
  id: string;
  timestamp: string;
  type: 'IMPORT' | 'EXPORT';
  moduleName: string;
  entityType: string;
  fileName: string;
  totalRows: number;
  successRows: number;
  errorRows: number;
  performedBy: string;
  status: 'SUCCESS' | 'ERROR' | 'PARTIAL';
  canRollback: boolean;
  isRolledBack?: boolean;
  errorLines?: { row: number; error: string }[];
}

export interface SystemAuditLogItem {
  id: string;
  timestamp: string;
  userName: string;
  userRole: string;
  module: string;
  action: 'TẠO MỚI' | 'CẬP NHẬT' | 'XÓA' | 'DUYỆT' | 'ĐĂNG NHẬP' | 'XUẤT DỮ LIỆU' | 'XEM DỮ LIỆU NHẠY CẢM';
  objectCode: string;
  objectName: string;
  isSensitiveAccess: boolean;
  changesSummary: string;
  oldValue?: string;
  newValue?: string;
  ipAddress: string;
}
