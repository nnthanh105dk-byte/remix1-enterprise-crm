import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { ReportFilterState } from '../../types/crm';
import { ReportFilterBar } from '../../components/reports/ReportFilterBar';
import { MonthlyComparisonBarChart, ExecutiveStatCard } from '../../components/reports/ReportCharts';
import { getReportText, formatCurrencyShort, translateEntityName } from '../../i18n/translations';
import {
  MOCK_SALES_REPS,
  MOCK_SALES_TEAMS,
  MOCK_WON_DEALS,
  MOCK_HISTORICAL_MONTHS,
} from '../../data/mockReportsData';
import {
  TrendingUp,
  DollarSign,
  PieChart,
  Users,
  Building,
  Package,
  MapPin,
  Share2,
  CheckCircle2,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

interface SalesRevenueReportProps {
  filter: ReportFilterState;
  onChangeFilter: (updated: Partial<ReportFilterState>) => void;
}

type GroupByOption = 'rep' | 'team' | 'product' | 'region' | 'source' | 'customer';

export const SalesRevenueReport: React.FC<SalesRevenueReportProps> = ({
  filter,
  onChangeFilter,
}) => {
  const { themeDef, language } = useCRM();
  const [groupBy, setGroupBy] = useState<GroupByOption>('team');

  // Filtered reps and deals
  const filteredReps = MOCK_SALES_REPS.filter((r) => {
    if (filter.teamId !== 'all' && r.teamId !== filter.teamId) return false;
    if (filter.salesRepId !== 'all' && r.id !== filter.salesRepId) return false;
    if (filter.region !== 'all' && r.region !== filter.region) return false;
    return true;
  });

  const totalRecognized = filteredReps.reduce((sum, r) => sum + r.actualRevenue, 0);
  const totalCollected = filteredReps.reduce((sum, r) => sum + r.collectedRevenue, 0);
  const totalQuota = filteredReps.reduce((sum, r) => sum + r.monthlyQuota, 0);
  const totalVariance = totalRecognized - totalQuota;
  const overallAttainment = totalQuota > 0 ? Math.round((totalRecognized / totalQuota) * 100) : 0;

  // Aggregate based on GroupBy
  interface TableRowData {
    id: string;
    label: string;
    subLabel?: string;
    quota: number;
    recognized: number;
    collected: number;
    attainment: number;
    variance: number;
  }

  const tableData: TableRowData[] = (() => {
    if (groupBy === 'team') {
      return MOCK_SALES_TEAMS.map((t) => {
        const teamReps = MOCK_SALES_REPS.filter((r) => r.teamId === t.id);
        const rec = teamReps.reduce((sum, r) => sum + r.actualRevenue, 0);
        const col = teamReps.reduce((sum, r) => sum + r.collectedRevenue, 0);
        const quota = t.monthlyQuota;
        return {
          id: t.id,
          label: translateEntityName(t.name, language),
          subLabel: `${getReportText('teamLeader', language)} ${t.leader}`,
          quota,
          recognized: rec,
          collected: col,
          attainment: quota > 0 ? Math.round((rec / quota) * 100) : 0,
          variance: rec - quota,
        };
      });
    }

    if (groupBy === 'rep') {
      return filteredReps.map((r) => ({
        id: r.id,
        label: r.name,
        subLabel: translateEntityName(r.teamName, language),
        quota: r.monthlyQuota,
        recognized: r.actualRevenue,
        collected: r.collectedRevenue,
        attainment: r.monthlyQuota > 0 ? Math.round((r.actualRevenue / r.monthlyQuota) * 100) : 0,
        variance: r.actualRevenue - r.monthlyQuota,
      }));
    }

    if (groupBy === 'product') {
      const products = [
        'Gói Enterprise CRM',
        'Giải pháp ERP Cloud',
        'Module Kho Vận WMS',
        'Dịch vụ Tích hợp API',
        'Cổng Portal B2B',
        'Gói Chăm sóc Khách hàng',
      ];
      return products.map((prod, idx) => {
        const matchingDeals = MOCK_WON_DEALS.filter((d) => d.productName === prod);
        const rec = matchingDeals.reduce((sum, d) => sum + d.value, 0) || (idx + 1) * 350000000;
        const col = Math.round(rec * 0.9);
        const quota = rec * 1.05;
        return {
          id: `prod-${idx}`,
          label: translateEntityName(prod, language),
          subLabel: `${matchingDeals.length || 3} ${getReportText('contractsCount', language)}`,
          quota,
          recognized: rec,
          collected: col,
          attainment: Math.round((rec / quota) * 100),
          variance: rec - quota,
        };
      });
    }

    if (groupBy === 'region') {
      const regions: ('Miền Bắc' | 'Miền Trung' | 'Miền Nam')[] = ['Miền Bắc', 'Miền Trung', 'Miền Nam'];
      return regions.map((reg) => {
        const regReps = MOCK_SALES_REPS.filter((r) => r.region === reg);
        const rec = regReps.reduce((sum, r) => sum + r.actualRevenue, 0);
        const col = regReps.reduce((sum, r) => sum + r.collectedRevenue, 0);
        const quota = regReps.reduce((sum, r) => sum + r.monthlyQuota, 0);
        return {
          id: reg,
          label: translateEntityName(`Khu vực ${reg}`, language),
          subLabel: `${regReps.length} ${getReportText('membersCount', language)}`,
          quota,
          recognized: rec,
          collected: col,
          attainment: quota > 0 ? Math.round((rec / quota) * 100) : 0,
          variance: rec - quota,
        };
      });
    }

    if (groupBy === 'source') {
      const sources: ('Facebook' | 'Zalo' | 'Website' | 'Giới thiệu' | 'Hotline' | 'Triển lãm')[] = [
        'Facebook',
        'Zalo',
        'Website',
        'Giới thiệu',
        'Hotline',
        'Triển lãm',
      ];
      return sources.map((src, idx) => {
        const deals = MOCK_WON_DEALS.filter((d) => d.source === src);
        const rec = deals.reduce((sum, d) => sum + d.value, 0) || (idx + 1) * 280000000;
        const col = Math.round(rec * 0.92);
        const quota = rec * 0.95;
        return {
          id: src,
          label: translateEntityName(`Nguồn ${src}`, language),
          subLabel: `${deals.length || 2} ${getReportText('wonDealsCount', language)}`,
          quota,
          recognized: rec,
          collected: col,
          attainment: Math.round((rec / quota) * 100),
          variance: rec - quota,
        };
      });
    }

    // Customer
    return MOCK_WON_DEALS.map((d) => ({
      id: d.id,
      label: d.customerCompany,
      subLabel: `${d.customerName} (${d.code})`,
      quota: d.value,
      recognized: d.value,
      collected: d.isCollected ? d.value : Math.round(d.value * 0.5),
      attainment: 100,
      variance: 0,
    }));
  })();

  return (
    <div className="space-y-6">
      {/* Shared Filter Bar */}
      <ReportFilterBar
        filter={filter}
        onChangeFilter={onChangeFilter}
        reportTitle={getReportText('salesRevenueReportTitle', language)}
      />

      {/* Overview Stat Cards (Executive Style: Chỉ hiển thị Tiêu đề và Con số, bấm ! xem giải thích) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <ExecutiveStatCard
          title={getReportText('recognizedRevenue', language)}
          value={formatCurrencyShort(totalRecognized, language)}
          icon={DollarSign}
          iconColor="bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-800"
          explanation={getReportText('wonContractsExplain', language)}
        />

        <ExecutiveStatCard
          title={getReportText('cashCollected', language)}
          value={formatCurrencyShort(totalCollected, language)}
          valueColor="text-emerald-600 dark:text-emerald-400"
          icon={CheckCircle2}
          iconColor="bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
          explanation={`${getReportText('collectedExplainPrefix', language)} ${totalRecognized > 0 ? Math.round((totalCollected / totalRecognized) * 100) : 0}% ${getReportText('collectedExplainSuffix', language)}`}
        />

        <ExecutiveStatCard
          title={getReportText('currentQuota', language)}
          value={formatCurrencyShort(totalQuota, language)}
          icon={PieChart}
          iconColor="bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800"
          explanation={`${getReportText('quotaExplainPrefix', language)} ${overallAttainment}% ${getReportText('quotaExplainSuffix', language)}`}
        />

        <ExecutiveStatCard
          title={getReportText('variance', language)}
          value={`${totalVariance >= 0 ? '+' : ''}${formatCurrencyShort(totalVariance, language)}`}
          valueColor={totalVariance >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}
          icon={totalVariance >= 0 ? ArrowUpRight : ArrowDownRight}
          iconColor={
            totalVariance >= 0
              ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800'
              : 'bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 border-rose-200 dark:border-rose-800'
          }
          explanation={totalVariance >= 0 ? getReportText('varianceSurplus', language) : getReportText('varianceDeficit', language)}
        />
      </div>

      {/* Historical Revenue Chart */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs`}>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="section-title">
              <TrendingUp className="w-4.5 h-4.5 text-[#0284c7] dark:text-sky-400 mr-2 shrink-0" />
              {getReportText('revenueTrendTitle', language)}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {getReportText('revenueTrendSubtitle', language)}
            </p>
          </div>
        </div>

        <MonthlyComparisonBarChart data={MOCK_HISTORICAL_MONTHS} />
      </div>

      {/* Detailed Revenue Table with Group-By Switcher */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-4`}>
        {/* Group By Toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="section-title">
              {getReportText('multidimTableTitle', language)}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              {getReportText('multidimTableSubtitle', language)}
            </p>
          </div>

          <div className="flex items-center gap-1 overflow-x-auto pb-1 sm:pb-0">
            <span className="text-xs text-slate-500 font-semibold mr-1 shrink-0">{getReportText('groupBy', language)}</span>
            <button
              onClick={() => setGroupBy('team')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 flex items-center gap-1 ${
                groupBy === 'team'
                  ? 'bg-[#002659] text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              <Building className="w-3.5 h-3.5" />
              <span>{getReportText('team', language)}</span>
            </button>

            <button
              onClick={() => setGroupBy('rep')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 flex items-center gap-1 ${
                groupBy === 'rep'
                  ? 'bg-[#002659] text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{getReportText('rep', language)}</span>
            </button>

            <button
              onClick={() => setGroupBy('product')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 flex items-center gap-1 ${
                groupBy === 'product'
                  ? 'bg-[#002659] text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              <Package className="w-3.5 h-3.5" />
              <span>{getReportText('product', language)}</span>
            </button>

            <button
              onClick={() => setGroupBy('region')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 flex items-center gap-1 ${
                groupBy === 'region'
                  ? 'bg-[#002659] text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              <MapPin className="w-3.5 h-3.5" />
              <span>{getReportText('region', language)}</span>
            </button>

            <button
              onClick={() => setGroupBy('source')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 flex items-center gap-1 ${
                groupBy === 'source'
                  ? 'bg-[#002659] text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{getReportText('source', language)}</span>
            </button>

            <button
              onClick={() => setGroupBy('customer')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors shrink-0 flex items-center gap-1 ${
                groupBy === 'customer'
                  ? 'bg-[#002659] text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{getReportText('customer', language)}</span>
            </button>
          </div>
        </div>

        {/* Responsive Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th className="py-3 px-3">{getReportText('thEntity', language)}</th>
                <th className="py-3 px-3 text-right">{getReportText('thQuota', language)}</th>
                <th className="py-3 px-3 text-right">{getReportText('thRecognized', language)}</th>
                <th className="py-3 px-3 text-right">{getReportText('thCollected', language)}</th>
                <th className="py-3 px-3 text-center">{getReportText('thAttainment', language)}</th>
                <th className="py-3 px-3 text-right">{getReportText('thVariance', language)}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {tableData.map((row) => (
                <tr key={row.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-3">
                    <p className="font-bold text-slate-900 dark:text-white">{row.label}</p>
                    {row.subLabel && <p className="text-[11px] text-slate-500">{row.subLabel}</p>}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-slate-700 dark:text-slate-300">
                    {formatCurrencyShort(row.quota, language)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-sky-600 dark:text-sky-400">
                    {formatCurrencyShort(row.recognized, language)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {formatCurrencyShort(row.collected, language)}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span
                      className={`inline-block px-2 py-0.5 rounded-full text-[11px] font-bold ${
                        row.attainment >= 100
                          ? 'bg-emerald-100 dark:bg-emerald-900/40 text-emerald-700 dark:text-emerald-300'
                          : row.attainment >= 70
                          ? 'bg-sky-100 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300'
                          : 'bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300'
                      }`}
                    >
                      {row.attainment}%
                    </span>
                  </td>
                  <td
                    className={`py-3 px-3 text-right font-mono font-bold ${
                      row.variance >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {row.variance >= 0 ? '+' : ''}
                    {formatCurrencyShort(row.variance, language)}
                  </td>
                </tr>
              ))}

              {/* Total Summary Row */}
              <tr className="bg-slate-100/80 dark:bg-slate-800/80 font-bold text-slate-900 dark:text-white border-t-2 border-slate-300 dark:border-slate-700">
                <td className="py-3 px-3">{getReportText('totalSystem', language)}</td>
                <td className="py-3 px-3 text-right font-mono">
                  {formatCurrencyShort(totalQuota, language)}
                </td>
                <td className="py-3 px-3 text-right font-mono text-sky-600 dark:text-sky-400">
                  {formatCurrencyShort(totalRecognized, language)}
                </td>
                <td className="py-3 px-3 text-right font-mono text-emerald-600 dark:text-emerald-400">
                  {formatCurrencyShort(totalCollected, language)}
                </td>
                <td className="py-3 px-3 text-center">
                  <span className="px-2.5 py-0.5 rounded-full bg-[#002659] text-white text-[11px]">
                    {overallAttainment}%
                  </span>
                </td>
                <td
                  className={`py-3 px-3 text-right font-mono ${
                    totalVariance >= 0 ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'
                  }`}
                >
                  {totalVariance >= 0 ? '+' : ''}
                  {formatCurrencyShort(totalVariance, language)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
