import React from 'react';
import { useCRM } from '../context/CRMContext';
import { ArrowLeft, Clock, CheckCircle2, ShieldCheck } from 'lucide-react';

interface PlaceholderModuleViewProps {
  moduleTitle: string;
  icon: React.ComponentType<{ className?: string }>;
  description?: string;
}

export const PlaceholderModuleView: React.FC<PlaceholderModuleViewProps> = ({
  moduleTitle,
  icon: Icon,
  description,
}) => {
  const { setActiveModule, themeDef } = useCRM();

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner / Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50">
              <Icon className="w-5 h-5" />
            </span>
            {moduleTitle}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Phân hệ mở rộng trong hệ sinh thái A+ Enterprise CRM
          </p>
        </div>

        <button
          onClick={() => setActiveModule('dashboard')}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-750 transition-colors shadow-xs w-fit"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Về Dashboard</span>
        </button>
      </div>

      {/* Main Under Development Container */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-8 sm:p-12 shadow-xs text-center max-w-2xl mx-auto my-8`}>
        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto mb-5 shadow-xs">
          <Icon className="w-8 h-8 sm:w-10 sm:h-10" />
        </div>

        {/* Required Title & Status */}
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-100 dark:bg-amber-900/50 text-amber-800 dark:text-amber-300 mb-3">
          <Clock className="w-3.5 h-3.5 animate-pulse" />
          <span>Chức năng đang được phát triển</span>
        </div>

        <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white mb-2">
          {moduleTitle}
        </h2>

        <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-6">
          {description ||
            `Phân hệ ${moduleTitle} đang được đội ngũ kỹ thuật hoàn thiện theo lộ trình kiến trúc hệ thống A+ Enterprise CRM. Dữ liệu và các mẫu biểu chức năng sẽ sẵn sàng ở bản cập nhật tiếp theo.`}
        </p>

        {/* Feature Specs in Progress */}
        <div className="bg-slate-50 dark:bg-slate-900/50 rounded-lg p-4 border border-slate-200 dark:border-slate-800/80 text-left space-y-2.5 mb-6 text-xs text-slate-600 dark:text-slate-300">
          <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-sky-500" />
            <span>Tiêu chuẩn kiến trúc phân hệ:</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span>Sẵn sàng kết nối cơ sở dữ liệu RBAC</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span>Đồng bộ đa chi nhánh & đa Tenant</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
              <span>Audit Log chuẩn an ninh doanh nghiệp</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-500 shrink-0" />
              <span>Bảo mật dữ liệu cấp độ Enterprise</span>
            </div>
          </div>
        </div>

        <button
          onClick={() => setActiveModule('dashboard')}
          className="px-5 py-2.5 rounded-lg bg-[#002659] hover:bg-[#001c42] text-white text-xs font-semibold shadow-xs transition-colors"
        >
          Quay lại Bảng điều khiển chính
        </button>
      </div>
    </div>
  );
};
