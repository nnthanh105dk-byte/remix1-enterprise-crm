import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useHR } from '../../context/HRContext';
import {
  Users,
  ShieldCheck,
  Briefcase,
  FileText,
  DollarSign,
  Download,
  Printer,
  Search,
  Building,
  CheckCircle2,
  Clock,
  Layers,
} from 'lucide-react';

export const HRReportView: React.FC = () => {
  const { showToast } = useCRM();
  const { employees, departments, contracts, insuranceParticipants } = useHR();

  const [activeTab, setActiveTab] = useState<'structure' | 'insurance' | 'contracts'>('structure');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDept, setSelectedDept] = useState('all');

  // 1. KPI Metrics
  const kpis = useMemo(() => {
    const totalStaff = employees.length;
    const activeStaff = employees.filter((e) => e.status === 'Đang làm việc').length;
    const probationStaff = employees.filter((e) => e.status === 'Thử việc').length;
    const activeRate = totalStaff > 0 ? Math.round((activeStaff / totalStaff) * 100) : 100;

    const totalInsured = insuranceParticipants.length;
    const insuranceRate = activeStaff > 0 ? Math.round((totalInsured / activeStaff) * 100) : 0;

    const totalInsuranceFund = contracts.reduce((sum, c) => sum + (c.insuranceSalary || 6000000), 0);

    return {
      totalStaff,
      activeStaff,
      probationStaff,
      activeRate,
      insuranceRate,
      totalInsuranceFund,
      totalInsured,
    };
  }, [employees, contracts, insuranceParticipants]);

  // 2. Department Breakdown
  const deptBreakdown = useMemo(() => {
    return departments.map((d) => {
      const staffInDept = employees.filter((e) => e.departmentId === d.id);
      const activeCount = staffInDept.filter((e) => e.status === 'Đang làm việc').length;
      const probationCount = staffInDept.filter((e) => e.status === 'Thử việc').length;
      return {
        ...d,
        staffCount: staffInDept.length,
        activeCount,
        probationCount,
      };
    });
  }, [departments, employees]);

  // 3. Filtered Employees
  const filteredEmployees = useMemo(() => {
    return employees.filter((e) => {
      const matchDept = selectedDept === 'all' || e.departmentId === selectedDept;
      const matchSearch =
        e.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.phone.includes(searchTerm);
      return matchDept && matchSearch;
    });
  }, [employees, selectedDept, searchTerm]);

  return (
    <div className="space-y-6">
      {/* 1. Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
              Báo cáo Khối Nhân sự &amp; Tổ chức (HR Analytics)
            </span>
            <span className="text-xs text-slate-400">Nhân sự &amp; Quỹ BHXH</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-1">
            Báo cáo Cơ cấu Nhân sự, Hợp đồng Lao động &amp; Quỹ BHXH
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Tổng quan biến động nhân sự theo phòng ban, tỷ lệ nhân viên chính thức, trích nộp quỹ bảo hiểm xã hội và quản lý hạn hợp đồng.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-sm"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            In Báo cáo
          </button>
          <button
            onClick={() => showToast('Xuất báo cáo', 'Đã tải xuống file Excel báo cáo nhân sự & BHXH.')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors shadow-sm"
          >
            <Download className="w-4 h-4" />
            Xuất Excel
          </button>
        </div>
      </div>

      {/* 2. Top KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Tổng quy mô nhân sự</span>
          <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
            {kpis.totalStaff} nhân sự
          </div>
          <span className="text-[11px] text-slate-400">Toàn công ty</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Nhân viên chính thức</span>
          <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {kpis.activeStaff} người
          </div>
          <span className="text-[11px] text-emerald-500">Tỷ lệ: {kpis.activeRate}%</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Nhân sự thử việc</span>
          <div className="text-xl font-bold text-amber-600 dark:text-amber-400 mt-1">
            {kpis.probationStaff} người
          </div>
          <span className="text-[11px] text-amber-500">Đang đánh giá</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Tỷ lệ tham gia BHXH</span>
          <div className="text-xl font-bold text-blue-600 dark:text-blue-400 mt-1">
            {kpis.insuranceRate}%
          </div>
          <span className="text-[11px] text-slate-400">{kpis.totalInsured} người đóng</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Quỹ lương đóng BHXH/tháng</span>
          <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
            {kpis.totalInsuranceFund.toLocaleString('vi-VN')} đ
          </div>
          <span className="text-[11px] text-slate-400">Cơ quan BHXH</span>
        </div>
      </div>

      {/* 3. Search & Filters */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="flex-1 w-full md:w-auto relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo mã NV, họ tên, số điện thoại..."
            className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <select
            value={selectedDept}
            onChange={(e) => setSelectedDept(e.target.value)}
            className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
          >
            <option value="all">Tất cả phòng ban</option>
            {departments.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* 4. Tab Navigation */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 rounded-t-xl">
        <button
          onClick={() => setActiveTab('structure')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'structure'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Building className="w-4 h-4" />
          Cơ Cấu Phòng Ban ({departments.length})
        </button>

        <button
          onClick={() => setActiveTab('insurance')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'insurance'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          Báo Cáo Tham Gia BHXH ({insuranceParticipants.length})
        </button>

        <button
          onClick={() => setActiveTab('contracts')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'contracts'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <FileText className="w-4 h-4" />
          Danh Sách Nhân Sự ({filteredEmployees.length})
        </button>
      </div>

      {/* 5. TAB 1: PHÒNG BAN */}
      {activeTab === 'structure' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã Phòng Ban</th>
                  <th className="px-4 py-3.5">Tên Phòng Ban</th>
                  <th className="px-4 py-3.5">Trưởng Bộ Phận</th>
                  <th className="px-3 py-3.5 text-center font-bold">Tổng Định Biên</th>
                  <th className="px-3 py-3.5 text-center">Chính Thức</th>
                  <th className="px-3 py-3.5 text-center">Thử Việc</th>
                  <th className="px-3 py-3.5 text-center">Tỷ Lệ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {deptBreakdown.map((d) => (
                  <tr key={d.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{d.code}</td>
                    <td className="px-4 py-3.5 font-medium text-slate-900 dark:text-white">{d.name}</td>
                    <td className="px-4 py-3.5 text-xs text-slate-700 dark:text-slate-300">{d.managerName || 'Chưa bổ nhiệm'}</td>
                    <td className="px-3 py-3.5 text-center font-bold text-slate-900 dark:text-white">
                      {d.staffCount} người
                    </td>
                    <td className="px-3 py-3.5 text-center text-emerald-600 font-semibold">{d.activeCount}</td>
                    <td className="px-3 py-3.5 text-center text-amber-600 font-semibold">{d.probationCount}</td>
                    <td className="px-3 py-3.5 text-center">
                      <span className="px-2 py-0.5 rounded text-xs font-bold bg-slate-100 dark:bg-slate-700">
                        {d.staffCount > 0 ? Math.round((d.activeCount / d.staffCount) * 100) : 0}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. TAB 2: BHXH */}
      {activeTab === 'insurance' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã NV</th>
                  <th className="px-4 py-3.5">Họ &amp; Tên Nhân Viên</th>
                  <th className="px-4 py-3.5">Mã Số BHXH</th>
                  <th className="px-4 py-3.5">Phòng Ban</th>
                  <th className="px-3 py-3.5 text-right font-bold">Mức Lương Đóng</th>
                  <th className="px-3 py-3.5 text-center">Trạng Thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {insuranceParticipants.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{p.employeeCode}</td>
                    <td className="px-4 py-3.5 font-medium text-slate-900 dark:text-white">{p.employeeName}</td>
                    <td className="px-4 py-3.5 font-mono text-xs text-blue-600">{p.insuranceBookNumber}</td>
                    <td className="px-4 py-3.5 text-xs text-slate-600 dark:text-slate-300">{p.departmentName}</td>
                    <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                      {p.monthlySalaryBasis.toLocaleString('vi-VN')} đ
                    </td>
                    <td className="px-3 py-3.5 text-center">
                      <span className="px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                        {p.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. TAB 3: DANH SÁCH NHÂN SỰ */}
      {activeTab === 'contracts' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã NV</th>
                  <th className="px-4 py-3.5">Họ Tên Nhân Viên</th>
                  <th className="px-4 py-3.5">Phòng Ban &amp; Chức Danh</th>
                  <th className="px-3 py-3.5 text-center">Số Điện Thoại</th>
                  <th className="px-3 py-3.5 text-center">Ngày Vào Làm</th>
                  <th className="px-3 py-3.5 text-center">Trạng Thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {filteredEmployees.map((e) => (
                  <tr key={e.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{e.code}</td>
                    <td className="px-4 py-3.5 font-medium text-slate-900 dark:text-white">{e.fullName}</td>
                    <td className="px-4 py-3.5">
                      <div className="font-medium text-slate-800 dark:text-slate-200">{e.departmentName}</div>
                      <div className="text-xs text-slate-400">{e.positionName}</div>
                    </td>
                    <td className="px-3 py-3.5 text-center text-xs font-mono">{e.phone}</td>
                    <td className="px-3 py-3.5 text-center text-xs font-mono">{e.joinDate}</td>
                    <td className="px-3 py-3.5 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          e.status === 'Đang làm việc'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300'
                        }`}
                      >
                        {e.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
