import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  Clock,
  Plus,
  Users2,
  Video,
  MapPin,
  CheckCircle2,
} from 'lucide-react';

interface CalendarEvent {
  id: string;
  title: string;
  client: string;
  company: string;
  time: string;
  duration: string;
  type: 'meeting' | 'call' | 'demo' | 'signing';
  location: string;
  day: number; // 1-31
}

export const CalendarView: React.FC = () => {
  const { language } = useCRM();
  const isVi = language === 'vi';

  const [currentMonth, setCurrentMonth] = useState('Tháng 10, 2026');
  const [selectedDay, setSelectedDay] = useState<number>(15);

  const events: CalendarEvent[] = [
    {
      id: 'e-1',
      title: 'Họp demo giải pháp CRM & phân quyền',
      client: 'Nguyễn Văn An',
      company: 'Dược Liệu Á Châu',
      time: '09:30 - 10:30',
      duration: '60 phút',
      type: 'demo',
      location: 'Google Meet',
      day: 15,
    },
    {
      id: 'e-2',
      title: 'Ký kết hợp đồng cung cấp phần mềm',
      client: 'Lê Hoàng Nam',
      company: 'Tập đoàn Masan',
      time: '14:00 - 15:00',
      duration: '60 phút',
      type: 'signing',
      location: 'Văn phòng Masan, Q.1, TP.HCM',
      day: 15,
    },
    {
      id: 'e-3',
      title: 'Cuộc gọi chốt điều khoản thanh toán',
      client: 'Trần Minh Tuấn',
      company: 'VNPAY Solutions',
      time: '16:30 - 17:00',
      duration: '30 phút',
      type: 'call',
      location: 'Hotline A+ CRM',
      day: 16,
    },
    {
      id: 'e-4',
      title: 'Review tiến độ triển khai kỹ thuật sprint 3',
      client: 'Ban Giám Đốc',
      company: 'Nội bộ A+ Apluz',
      time: '10:00 - 11:30',
      duration: '90 phút',
      type: 'meeting',
      location: 'Phòng họp Tầng 8',
      day: 18,
    },
  ];

  const daysOfWeek = isVi
    ? ['T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'CN']
    : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  const selectedDayEvents = events.filter((e) => e.day === selectedDay);

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* 01. Context Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-[#0F172A] tracking-tight">
              {isVi ? 'Lịch làm việc & Hội họp' : 'Schedule & Meetings'}
            </h1>
            <span className="text-xs font-mono font-medium text-[#64748B] bg-slate-100 px-2 py-0.5 rounded">
              {currentMonth}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            {isVi
              ? 'Theo dõi lịch gặp đối tác, ký hợp đồng và demo tính năng trực tiếp.'
              : 'Calendar management for customer meetings, contract signings, and product demos.'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button className="flex items-center gap-1 px-2.5 sm:px-3.5 py-1 sm:py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white text-[11px] sm:text-xs font-medium transition-colors shadow-xs whitespace-nowrap shrink-0">
            <Plus className="w-3.5 h-3.5 shrink-0" />
            <span className="hidden sm:inline">{isVi ? 'Đặt lịch hẹn' : 'Schedule Meeting'}</span>
            <span className="sm:hidden">{isVi ? 'Đặt lịch' : 'Schedule'}</span>
          </button>
        </div>
      </div>

      {/* 02. Calendar Grid & Details Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Left 2 Cols: Monthly Grid */}
        <div className="md:col-span-7 lg:col-span-8 bg-white rounded-xl border border-[#E5E7EB] p-4 sm:p-5 shadow-xs">
          {/* Month Navigator */}
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-bold text-[#0F172A]">{currentMonth}</h2>
            <div className="flex items-center gap-1">
              <button className="p-1 rounded-md border border-[#E5E7EB] hover:bg-slate-50 text-slate-600">
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button className="p-1 rounded-md border border-[#E5E7EB] hover:bg-slate-50 text-slate-600">
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Days of Week */}
          <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-[#64748B] pb-2 border-b border-[#E5E7EB]">
            {daysOfWeek.map((d) => (
              <div key={d} className="py-1">
                {d}
              </div>
            ))}
          </div>

          {/* Days Grid (1-31) */}
          <div className="grid grid-cols-7 gap-1 pt-2">
            {Array.from({ length: 31 }, (_, i) => i + 1).map((d) => {
              const isSelected = d === selectedDay;
              const hasEvents = events.some((e) => e.day === d);

              return (
                <button
                  key={d}
                  onClick={() => setSelectedDay(d)}
                  className={`h-16 p-1.5 rounded-lg border text-left flex flex-col justify-between transition-colors ${
                    isSelected
                      ? 'border-[#002659] bg-[#F0F7FD] shadow-xs'
                      : 'border-transparent hover:bg-slate-50'
                  }`}
                >
                  <span
                    className={`text-xs font-mono font-medium ${
                      isSelected ? 'text-[#002659] font-bold' : 'text-slate-700'
                    }`}
                  >
                    {d}
                  </span>

                  {hasEvents && (
                    <div className="flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#3661C9]" />
                      <span className="text-[9px] font-mono text-[#3661C9] truncate hidden sm:inline">
                        {events.filter((e) => e.day === d).length} lịch
                      </span>
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Col: Events for Selected Day */}
        <div className="md:col-span-5 lg:col-span-4 bg-white rounded-xl border border-[#E5E7EB] p-4 sm:p-5 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-3 border-b border-[#E5E7EB]">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#64748B]">
                {isVi ? `Lịch ngày ${selectedDay} tháng 10` : `Events on Oct ${selectedDay}`}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                {selectedDayEvents.length} {isVi ? 'cuộc hẹn đã ghi nhận' : 'events scheduled'}
              </p>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto py-3 space-y-3">
            {selectedDayEvents.length === 0 ? (
              <div className="py-12 text-center text-xs text-slate-400">
                {isVi ? 'Không có lịch hẹn trong ngày này.' : 'No events scheduled for this date.'}
              </div>
            ) : (
              selectedDayEvents.map((evt) => (
                <div
                  key={evt.id}
                  className="p-3 rounded-lg border border-[#E5E7EB] hover:border-slate-300 transition-colors bg-[#F8FAFC]"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-white border border-[#E5E7EB] text-[#002659]">
                      {evt.time}
                    </span>
                    <span className="text-[10px] font-mono text-slate-400">{evt.duration}</span>
                  </div>

                  <h4 className="text-xs font-bold text-[#0F172A] mt-2">{evt.title}</h4>

                  <div className="text-[11px] text-[#64748B] mt-1 space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <Users2 className="w-3 h-3 text-slate-400" />
                      <span>{evt.client} • {evt.company}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3 h-3 text-slate-400" />
                      <span className="truncate">{evt.location}</span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
