import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSettings } from '../../context/SettingsContext';
import { DictionaryCategory, DictionaryValueItem } from '../../types/settings';
import {
  BookOpen,
  Plus,
  Download,
  Upload,
  Edit2,
  Trash2,
  Check,
  X,
  Lock,
  Tag,
  Search,
  Filter,
} from 'lucide-react';

export const SettingsDictionaryView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    dictionaryCategories,
    addDictionaryValue,
    updateDictionaryValue,
    toggleDisableDictionaryValue,
    canAccessSettings,
  } = useSettings();

  const [selectedCatId, setSelectedCatId] = useState<string>((dictionaryCategories || [])[0]?.id || '');
  const [searchTerm, setSearchTerm] = useState('');
  const [moduleGroupFilter, setModuleGroupFilter] = useState('all');

  // Modal Add Value
  const [isAddValueModalOpen, setIsAddValueModalOpen] = useState(false);
  const [newValueCode, setNewValueCode] = useState('');
  const [newValueLabel, setNewValueLabel] = useState('');
  const [newValueColor, setNewValueColor] = useState('bg-blue-100 text-blue-700');

  // Edit Value inline state
  const [editingValId, setEditingValId] = useState<string | null>(null);
  const [editLabel, setEditLabel] = useState('');
  const [editColor, setEditColor] = useState('');

  const filteredCategories = (dictionaryCategories || []).filter((c) => {
    if (moduleGroupFilter !== 'all' && c.moduleGroup !== moduleGroupFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q);
    }
    return true;
  });

  const activeCategory = (dictionaryCategories || []).find((c) => c.id === selectedCatId) || (dictionaryCategories || [])[0];

  const handleAddValueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeCategory || !newValueCode || !newValueLabel) return;
    addDictionaryValue(activeCategory.id, {
      code: newValueCode.toUpperCase().replace(/\s+/g, '_'),
      label: newValueLabel,
      colorBadge: newValueColor,
      sortOrder: activeCategory.values.length + 1,
      isDefault: false,
      status: 'active',
      isSystem: false,
    });
    setIsAddValueModalOpen(false);
    setNewValueCode('');
    setNewValueLabel('');
  };

  const handleSaveInlineEdit = (valId: string) => {
    if (!activeCategory) return;
    updateDictionaryValue(activeCategory.id, valId, {
      label: editLabel,
      colorBadge: editColor,
    });
    setEditingValId(null);
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 border border-teal-200 dark:border-teal-800">
            <BookOpen className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              Từ Điển Giá Trị Hệ Thống (Dictionaries)
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-teal-100 text-teal-700 dark:bg-teal-950 dark:text-teal-300 font-bold font-mono">
                {dictionaryCategories.length} Nhóm từ điển
              </span>
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Quản lý danh sách lựa chọn dùng chung: Nguồn lead, lý do thua, hình thức thanh toán, lý do xuất nhập kho, kết luận bảo hành.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => showToast('Xuất Excel', 'Đã tải xuống bảng giá trị từ điển dạng Excel.', 'success')}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 text-xs font-semibold flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Xuất Excel</span>
          </button>
        </div>
      </div>

      {/* 2 Cột: Bên trái Danh mục Từ điển, Bên phải Bảng giá trị */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Cột trái */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-3 shadow-xs space-y-3 lg:col-span-1">
          <div className="space-y-2">
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm nhóm từ điển..."
              className="w-full px-2.5 py-1.5 rounded-lg border bg-white dark:bg-slate-800 text-xs"
            />
            <select
              value={moduleGroupFilter}
              onChange={(e) => setModuleGroupFilter(e.target.value)}
              className="w-full px-2.5 py-1.5 rounded-lg border bg-white dark:bg-slate-800 text-xs"
            >
              <option value="all">Tất cả module</option>
              <option value="sales">Quản lý Sales</option>
              <option value="inventory">Quản lý kho</option>
              <option value="logistics">Vận chuyển</option>
              <option value="technical">Kỹ thuật</option>
              <option value="hr">Quản lý nhân sự</option>
            </select>
          </div>

          <div className="space-y-1 max-h-[580px] overflow-y-auto">
            {filteredCategories.map((cat) => {
              const isSelected = cat.id === activeCategory?.id;
              return (
                <div
                  key={cat.id}
                  onClick={() => setSelectedCatId(cat.id)}
                  className={`p-2.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-teal-50/80 border-teal-300 dark:bg-teal-950/30 dark:border-teal-800'
                      : 'border-transparent hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  <span className={`font-bold text-xs block ${isSelected ? 'text-teal-700 dark:text-teal-300' : 'text-slate-800 dark:text-slate-200'}`}>
                    {cat.name}
                  </span>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                    <span className="font-mono">{cat.code}</span>
                    <span className="font-semibold">{cat.values.length} mục</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Cột phải: Bảng giá trị */}
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs lg:col-span-3 space-y-4 text-xs">
          {activeCategory && (
            <>
              <div className="flex items-center justify-between pb-3 border-b">
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-base text-slate-900 dark:text-white">{activeCategory.name}</h3>
                    <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-[10px] text-slate-500">
                      {activeCategory.code}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">{activeCategory.description}</p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsAddValueModalOpen(true)}
                  className="px-3.5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white font-bold flex items-center gap-1.5 shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>Thêm giá trị</span>
                </button>
              </div>

              <div className="border rounded-xl overflow-x-auto">
                <table className="w-full text-left">
                  <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 font-semibold border-b">
                    <tr>
                      <th className="px-3 py-2.5">Thứ tự</th>
                      <th className="px-3 py-2.5">Mã (Code cố định)</th>
                      <th className="px-3 py-2.5">Nhãn hiển thị</th>
                      <th className="px-3 py-2.5">Màu Badge</th>
                      <th className="px-3 py-2.5">Đang dùng ở</th>
                      <th className="px-3 py-2.5">Trạng thái</th>
                      <th className="px-3 py-2.5 text-right">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {activeCategory.values.map((val) => {
                      const isEditing = editingValId === val.id;

                      return (
                        <tr key={val.id} className="hover:bg-slate-50/50">
                          <td className="px-3 py-2.5 font-mono text-slate-400">{val.sortOrder}</td>
                          <td className="px-3 py-2.5 font-mono font-bold text-slate-800 dark:text-slate-200">
                            {val.code}
                            {val.isSystem && (
                              <span className="ml-1.5 text-[9px] px-1 rounded bg-slate-200 text-slate-600 font-normal">
                                Hệ thống
                              </span>
                            )}
                          </td>

                          <td className="px-3 py-2.5">
                            {isEditing ? (
                              <input
                                type="text"
                                value={editLabel}
                                onChange={(e) => setEditLabel(e.target.value)}
                                className="px-2 py-1 rounded border bg-white dark:bg-slate-800 font-semibold text-xs w-full"
                              />
                            ) : (
                              <span className="font-semibold text-slate-900 dark:text-white">{val.label}</span>
                            )}
                          </td>

                          <td className="px-3 py-2.5">
                            {isEditing ? (
                              <input
                                type="text"
                                value={editColor}
                                onChange={(e) => setEditColor(e.target.value)}
                                className="px-2 py-1 rounded border bg-white dark:bg-slate-800 font-mono text-[10px] w-full"
                              />
                            ) : (
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${val.colorBadge || 'bg-slate-100 text-slate-700'}`}>
                                Mẫu màu
                              </span>
                            )}
                          </td>

                          <td className="px-3 py-2.5 font-semibold text-slate-600">
                            {val.usedCount} chứng từ
                          </td>

                          <td className="px-3 py-2.5">
                            {val.status === 'active' ? (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                                Đang dùng
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-200 text-slate-600">
                                Ngưng sử dụng
                              </span>
                            )}
                          </td>

                          <td className="px-3 py-2.5 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {isEditing ? (
                                <>
                                  <button
                                    onClick={() => handleSaveInlineEdit(val.id)}
                                    className="p-1 rounded bg-emerald-600 text-white"
                                    title="Lưu thay đổi"
                                  >
                                    <Check className="w-3.5 h-3.5" />
                                  </button>
                                  <button
                                    onClick={() => setEditingValId(null)}
                                    className="p-1 rounded bg-slate-200 text-slate-600"
                                    title="Hủy"
                                  >
                                    <X className="w-3.5 h-3.5" />
                                  </button>
                                </>
                              ) : (
                                <>
                                  <button
                                    onClick={() => {
                                      setEditingValId(val.id);
                                      setEditLabel(val.label);
                                      setEditColor(val.colorBadge || 'bg-blue-100 text-blue-700');
                                    }}
                                    className="p-1 rounded hover:bg-slate-100 text-slate-600"
                                    title="Chỉnh sửa nhãn và màu"
                                  >
                                    <Edit2 className="w-3.5 h-3.5" />
                                  </button>

                                  {!val.isSystem && (
                                    <button
                                      onClick={() => toggleDisableDictionaryValue(activeCategory.id, val.id)}
                                      className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-rose-600"
                                      title={val.status === 'active' ? 'Ngưng sử dụng (ẩn khỏi lựa chọn mới)' : 'Kích hoạt lại'}
                                    >
                                      {val.status === 'active' ? <X className="w-3.5 h-3.5" /> : <Check className="w-3.5 h-3.5" />}
                                    </button>
                                  )}
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      </div>

      {/* Modal Thêm Giá Trị Mới */}
      {isAddValueModalOpen && activeCategory && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-5 border shadow-xl space-y-4 text-xs">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Thêm Giá Trị: {activeCategory.name}</h3>
            <form onSubmit={handleAddValueSubmit} className="space-y-3">
              <div>
                <label className="font-semibold block mb-1">Mã giá trị (Code bất biến) *</label>
                <input
                  type="text"
                  value={newValueCode}
                  onChange={(e) => setNewValueCode(e.target.value)}
                  placeholder="Ví dụ: TIKTOK_ADS"
                  className="w-full px-3 py-2 rounded-xl border font-mono font-bold uppercase"
                  required
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">Nhãn hiển thị *</label>
                <input
                  type="text"
                  value={newValueLabel}
                  onChange={(e) => setNewValueLabel(e.target.value)}
                  placeholder="Ví dụ: TikTok Ads & Livestream"
                  className="w-full px-3 py-2 rounded-xl border"
                  required
                />
              </div>
              <div>
                <label className="font-semibold block mb-1">Màu sắc Badge</label>
                <select
                  value={newValueColor}
                  onChange={(e) => setNewValueColor(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border"
                >
                  <option value="bg-blue-100 text-blue-700">Xanh dương (Blue)</option>
                  <option value="bg-indigo-100 text-indigo-700">Chàm (Indigo)</option>
                  <option value="bg-sky-100 text-sky-700">Xanh da trời (Sky)</option>
                  <option value="bg-emerald-100 text-emerald-700">Xanh lá (Emerald)</option>
                  <option value="bg-amber-100 text-amber-700">Vàng (Amber)</option>
                  <option value="bg-rose-100 text-rose-700">Đỏ hồng (Rose)</option>
                  <option value="bg-purple-100 text-purple-700">Tím (Purple)</option>
                </select>
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsAddValueModalOpen(false)} className="px-3 py-1.5 border rounded-xl">Hủy</button>
                <button type="submit" className="px-4 py-2 bg-teal-600 text-white font-bold rounded-xl">Thêm giá trị</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
