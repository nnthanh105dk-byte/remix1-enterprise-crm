import React, { createContext, useContext, useState } from 'react';
import { useCRM } from './CRMContext';
import { useSales } from './SalesContext';
import { useWarehouse } from './WarehouseContext';
import { useLogistics } from './LogisticsContext';
import {
  CustomerSite,
  CustomerEquipment,
  TechnicalCatalogItem,
  TechnicalQuotationRequest,
  TechnicalQuotationLineItem,
  TechnicalProject,
  ProjectTask,
  ProjectMaterialRequest,
  AcceptanceCertificate,
  WarrantyTicket,
  WarrantyStockOut,
} from '../types/technical';
import {
  INITIAL_CUSTOMER_SITES,
  INITIAL_CUSTOMER_EQUIPMENTS,
  INITIAL_TECHNICAL_CATALOG,
  INITIAL_TECHNICAL_QUOTATION_REQUESTS,
  INITIAL_TECHNICAL_PROJECTS,
  INITIAL_ACCEPTANCE_CERTIFICATES,
  INITIAL_WARRANTY_TICKETS,
  INITIAL_WARRANTY_STOCK_OUTS,
} from '../data/mockTechnicalData';

interface TechnicalContextType {
  // 1. Hồ sơ khách hàng & Địa điểm & Thiết bị
  customerSites: CustomerSite[];
  customerEquipments: CustomerEquipment[];
  addCustomerSite: (site: Omit<CustomerSite, 'id'>) => CustomerSite;
  addCustomerEquipment: (eq: Omit<CustomerEquipment, 'id'>) => CustomerEquipment;
  updateCustomerEquipmentStatus: (id: string, status: CustomerEquipment['status'], notes?: string) => void;

  // 2. Danh mục kỹ thuật
  technicalCatalog: TechnicalCatalogItem[];
  addCatalogItem: (item: Omit<TechnicalCatalogItem, 'id'>) => TechnicalCatalogItem;
  updateCatalogItem: (id: string, updates: Partial<TechnicalCatalogItem>) => void;

  // 3. Báo giá kỹ thuật (YCKT)
  quotationRequests: TechnicalQuotationRequest[];
  createTechnicalQuotationRequest: (
    data: Omit<TechnicalQuotationRequest, 'id' | 'code' | 'status' | 'createdAt' | 'version' | 'chain' | 'items' | 'subTotal'>
  ) => TechnicalQuotationRequest;
  acceptQuotationRequest: (id: string, assignedStaff: string) => void;
  returnQuotationRequest: (id: string, reason: string) => void;
  saveQuotationLines: (
    id: string,
    items: TechnicalQuotationLineItem[],
    surveyNotes?: string,
    notes?: string
  ) => void;
  completeTechnicalQuotation: (id: string) => void;

  // 4. Hợp đồng & Triển khai
  acceptContractForDeployment: (contractId: string, projectManager: string) => void;

  // 5. Kế hoạch tổng thể & Dự án
  projects: TechnicalProject[];
  createProjectFromContract: (
    contractId: string,
    title: string,
    projectManager: string,
    startDate: string,
    endDate: string,
    budget: number
  ) => TechnicalProject;
  updateProjectTaskStatus: (projectId: string, taskId: string, status: ProjectTask['status'], progress: number) => void;
  addProjectMaterialRequest: (
    projectId: string,
    sku: string,
    productName: string,
    unit: string,
    quantityRequired: number
  ) => void;

  // 6. Nghiệm thu
  acceptanceCertificates: AcceptanceCertificate[];
  createAcceptanceCertificate: (
    data: Omit<AcceptanceCertificate, 'id' | 'code' | 'createdAt' | 'chain'>
  ) => AcceptanceCertificate;

  // 7. Bảo hành & Sự cố
  warrantyTickets: WarrantyTicket[];
  createWarrantyTicket: (
    data: Omit<WarrantyTicket, 'id' | 'code' | 'status' | 'createdAt' | 'chain'>
  ) => WarrantyTicket;
  resolveWarrantyTicket: (id: string, resolution: string) => void;

  // 8. Xuất kho bảo hành
  warrantyStockOuts: WarrantyStockOut[];
  createWarrantyStockOut: (
    ticketId: string,
    warehouseId: string,
    technicianName: string,
    replacementItems: WarrantyStockOut['replacementItems'],
    defectiveItemsCollected: WarrantyStockOut['defectiveItemsCollected'],
    notes?: string
  ) => WarrantyStockOut;

  // 9. Điểm nối: Tạo cơ hội gia hạn đẩy về Sales
  createRenewalOpportunityFromContract: (contractId: string, notes?: string) => void;
}

const TechnicalContext = createContext<TechnicalContextType | undefined>(undefined);

export const TechnicalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { showToast, setActiveModule, addNotification } = useCRM();
  const { customers, contracts, updateContract, addOpportunity, createQuotation } = useSales();
  const { products, createStockOutReceipt } = useWarehouse();
  const { paymentRequests } = useLogistics();

  // State
  const [customerSites, setCustomerSites] = useState<CustomerSite[]>(INITIAL_CUSTOMER_SITES);
  const [customerEquipments, setCustomerEquipments] = useState<CustomerEquipment[]>(INITIAL_CUSTOMER_EQUIPMENTS);
  const [technicalCatalog, setTechnicalCatalog] = useState<TechnicalCatalogItem[]>(INITIAL_TECHNICAL_CATALOG);
  const [quotationRequests, setQuotationRequests] = useState<TechnicalQuotationRequest[]>(
    INITIAL_TECHNICAL_QUOTATION_REQUESTS
  );
  const [projects, setProjects] = useState<TechnicalProject[]>(INITIAL_TECHNICAL_PROJECTS);
  const [acceptanceCertificates, setAcceptanceCertificates] = useState<AcceptanceCertificate[]>(
    INITIAL_ACCEPTANCE_CERTIFICATES
  );
  const [warrantyTickets, setWarrantyTickets] = useState<WarrantyTicket[]>(INITIAL_WARRANTY_TICKETS);
  const [warrantyStockOuts, setWarrantyStockOuts] = useState<WarrantyStockOut[]>(INITIAL_WARRANTY_STOCK_OUTS);

  // Helper generators
  const getNextCode = (prefix: string, listLength: number) => {
    const year = new Date().getFullYear();
    const num = String(listLength + 1).padStart(4, '0');
    return `${prefix}-${year}-${num}`;
  };

  // 1. Sites & Equipments
  const addCustomerSite = (site: Omit<CustomerSite, 'id'>): CustomerSite => {
    const newSite: CustomerSite = { ...site, id: `site-${Date.now()}` };
    setCustomerSites((prev) => [newSite, ...prev]);
    showToast('Thêm địa điểm công trình', `Đã lưu địa điểm: ${newSite.name}`, 'success');
    return newSite;
  };

  const addCustomerEquipment = (eq: Omit<CustomerEquipment, 'id'>): CustomerEquipment => {
    const newEq: CustomerEquipment = { ...eq, id: `eq-${Date.now()}` };
    setCustomerEquipments((prev) => [newEq, ...prev]);
    showToast('Thêm thiết bị khách hàng', `Đã gán thiết bị ${newEq.productName} (${newEq.serialNumber || 'Không serial'}) vào hồ sơ khách hàng.`, 'success');
    return newEq;
  };

  const updateCustomerEquipmentStatus = (id: string, status: CustomerEquipment['status'], notes?: string) => {
    setCustomerEquipments((prev) =>
      prev.map((eq) => (eq.id === id ? { ...eq, status, notes: notes || eq.notes } : eq))
    );
    showToast('Cập nhật thiết bị', `Trạng thái thiết bị đã chuyển sang: ${status}`, 'info');
  };

  // 2. Catalog
  const addCatalogItem = (item: Omit<TechnicalCatalogItem, 'id'>): TechnicalCatalogItem => {
    const newItem: TechnicalCatalogItem = { ...item, id: `tc-${Date.now()}` };
    setTechnicalCatalog((prev) => [newItem, ...prev]);
    showToast('Thêm danh mục kỹ thuật', `Đã bổ sung ${newItem.name} vào danh mục kỹ thuật.`, 'success');
    return newItem;
  };

  const updateCatalogItem = (id: string, updates: Partial<TechnicalCatalogItem>) => {
    setTechnicalCatalog((prev) =>
      prev.map((item) => (item.id === id ? { ...item, ...updates } : item))
    );
    showToast('Cập nhật danh mục', 'Đã lưu các thông số kỹ thuật cập nhật.', 'success');
  };

  // 3. Technical Quotations
  const createTechnicalQuotationRequest = (
    data: Omit<TechnicalQuotationRequest, 'id' | 'code' | 'status' | 'createdAt' | 'version' | 'chain' | 'items' | 'subTotal'>
  ): TechnicalQuotationRequest => {
    const code = getNextCode('YCKT', quotationRequests.length);
    const newReq: TechnicalQuotationRequest = {
      ...data,
      id: `yckt-${Date.now()}`,
      code,
      status: 'Chờ tiếp nhận',
      items: [],
      subTotal: 0,
      version: 1,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      chain: {
        opportunityId: data.opportunityId,
        opportunityCode: data.opportunityCode,
        customerId: data.customerId,
        customerName: data.customerName,
      },
    };
    setQuotationRequests((prev) => [newReq, ...prev]);
    showToast('Tạo Yêu cầu kỹ thuật', `Đã tạo yêu cầu khảo sát & bóc tách kỹ thuật ${code} từ cơ hội ${data.opportunityCode}.`, 'success');
    return newReq;
  };

  const acceptQuotationRequest = (id: string, assignedStaff: string) => {
    setQuotationRequests((prev) =>
      prev.map((req) =>
        req.id === id
          ? { ...req, status: 'Đang khảo sát', assignedTechStaff: assignedStaff }
          : req
      )
    );
    showToast('Tiếp nhận yêu cầu kỹ thuật', `Đã phân công kỹ sư phụ trách: ${assignedStaff}.`, 'success');
  };

  const returnQuotationRequest = (id: string, reason: string) => {
    setQuotationRequests((prev) =>
      prev.map((req) =>
        req.id === id ? { ...req, status: 'Cần chỉnh sửa', returnReason: reason } : req
      )
    );
    showToast('Trả lại yêu cầu', `Đã trả lại yêu cầu kỹ thuật với lý do: ${reason}`, 'warning');
  };

  const saveQuotationLines = (
    id: string,
    items: TechnicalQuotationLineItem[],
    surveyNotes?: string,
    notes?: string
  ) => {
    const subTotal = items.reduce((sum, it) => sum + it.total, 0);
    setQuotationRequests((prev) =>
      prev.map((req) =>
        req.id === id
          ? {
              ...req,
              items,
              subTotal,
              status: req.status === 'Chờ tiếp nhận' ? 'Đang lập báo giá' : req.status,
              surveyNotes: surveyNotes !== undefined ? surveyNotes : req.surveyNotes,
              notes: notes !== undefined ? notes : req.notes,
            }
          : req
      )
    );
    showToast('Đã lưu bóc tách kỹ thuật', `Tổng giá trị phần kỹ thuật: ${subTotal.toLocaleString()} đ`, 'success');
  };

  const completeTechnicalQuotation = (id: string) => {
    const req = quotationRequests.find((r) => r.id === id);
    if (!req) return;

    setQuotationRequests((prev) =>
      prev.map((r) =>
        r.id === id
          ? {
              ...r,
              status: 'Hoàn tất phần kỹ thuật',
              completedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            }
          : r
      )
    );

    // Kế thừa dữ liệu: Tự động chuyển Báo giá sang Sales chờ duyệt thương mại
    let createdQuoteCode = '';
    if (req.items && req.items.length > 0) {
      const quoteItems = req.items.map((it) => ({
        sku: it.sku || 'DV-KT',
        productName: it.name,
        unit: it.unit || 'Bộ',
        quantity: it.quantity,
        unitPrice: it.unitPrice,
        discountPercent: 0,
        total: it.total,
      }));

      const newQuote = createQuotation({
        title: `Báo giá giải pháp kỹ thuật - ${req.customerName}`,
        customerId: req.customerId || 'cust-1',
        customerCode: req.chain?.customerCode || 'KH-2026-001',
        customerName: req.customerName,
        opportunityId: req.opportunityId,
        opportunityCode: req.opportunityCode,
        items: quoteItems,
        validUntil: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        paymentTerms: 'Tạm ứng 40%, Nghiệm thu 50%, Bảo hành 10%',
        warrantyTerms: 'Bảo hành chính hãng 12 tháng, bảo trì định kỳ 3 tháng/lần',
        discountPercentTotal: 0,
        taxRate: 10,
        status: 'Chờ duyệt',
        createdByName: req.assignedTechStaff || 'Bộ phận Kỹ thuật',
      });
      createdQuoteCode = newQuote.code;

      setQuotationRequests((prev) =>
        prev.map((r) =>
          r.id === id
            ? {
                ...r,
                chain: {
                  ...r.chain,
                  quotationId: newQuote.id,
                  quotationCode: newQuote.code,
                  technicalRequestCode: req.code,
                },
              }
            : r
        )
      );
    }

    showToast(
      'Hoàn tất phần kỹ thuật',
      `Yêu cầu ${req.code} đã hoàn tất bóc tách BOM và sinh Báo giá ${createdQuoteCode || ''} chuyển sang Quản lý Sales duyệt thương mại.`,
      'success'
    );
  };

  // 4. Contract Deployment
  const acceptContractForDeployment = (contractId: string, projectManager: string) => {
    const contract = contracts.find((c) => c.id === contractId);
    if (!contract) return;

    const projCode = getNextCode('DA', projects.length);
    const newProj: TechnicalProject = {
      id: `proj-${Date.now()}`,
      code: projCode,
      title: `Triển khai dự án ${contract.contractNumber} - ${contract.customerName}`,
      customerId: contract.customerId,
      customerName: contract.customerName,
      contractId: contract.id,
      contractCode: contract.contractNumber,
      siteName: 'Trụ sở khách hàng',
      siteAddress: 'Địa chỉ theo hợp đồng',
      projectManager,
      teamMembers: [projectManager],
      startDate: contract.startDate || new Date().toISOString().split('T')[0],
      endDate: contract.endDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      budget: Math.round(contract.totalValue * 0.4),
      spentCost: 0,
      progressPercent: 10,
      status: 'Đang triển khai',
      phases: [
        {
          id: `phase-${Date.now()}-1`,
          name: '1. Khảo sát & Chuẩn bị vật tư',
          order: 1,
          tasks: [
            {
              id: `task-${Date.now()}-1`,
              phaseId: `phase-${Date.now()}-1`,
              title: 'Khảo sát hiện trường và bàn giao mặt bằng',
              assignedTo: projectManager,
              startDate: new Date().toISOString().split('T')[0],
              endDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              status: 'Đang làm',
              progress: 50,
            },
          ],
        },
        {
          id: `phase-${Date.now()}-2`,
          name: '2. Lắp đặt & Cấu hình thiết bị',
          order: 2,
          tasks: [
            {
              id: `task-${Date.now()}-2`,
              phaseId: `phase-${Date.now()}-2`,
              title: 'Lắp ráp tủ rack, đấu nối thiết bị và kiểm tra nguồn',
              assignedTo: projectManager,
              startDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              endDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              status: 'Chưa làm',
              progress: 0,
            },
          ],
        },
        {
          id: `phase-${Date.now()}-3`,
          name: '3. Nghiệm thu & Bàn giao',
          order: 3,
          tasks: [
            {
              id: `task-${Date.now()}-3`,
              phaseId: `phase-${Date.now()}-3`,
              title: 'Chạy thử tải 72 giờ và ký biên bản nghiệm thu BBNT',
              assignedTo: projectManager,
              startDate: new Date(Date.now() + 11 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              endDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
              status: 'Chưa làm',
              progress: 0,
            },
          ],
        },
      ],
      materialRequests: [],
      notes: `Tiếp nhận triển khai từ Hợp đồng ${contract.contractNumber}`,
      createdAt: new Date().toISOString().split('T')[0],
      chain: {
        contractId: contract.id,
        contractCode: contract.contractNumber,
        customerId: contract.customerId,
        customerCode: contract.customerCode,
        customerName: contract.customerName,
      },
    };

    setProjects((prev) => [newProj, ...prev]);
    showToast(
      'Kỹ thuật tiếp nhận hợp đồng',
      `Đã khởi tạo Dự án triển khai ${projCode} do ${projectManager} làm Trưởng dự án.`,
      'success'
    );
  };

  // 5. Projects
  const createProjectFromContract = (
    contractId: string,
    title: string,
    projectManager: string,
    startDate: string,
    endDate: string,
    budget: number
  ): TechnicalProject => {
    const contract = contracts.find((c) => c.id === contractId);
    const code = getNextCode('DA', projects.length);
    const newProj: TechnicalProject = {
      id: `proj-${Date.now()}`,
      code,
      title,
      customerId: contract?.customerId || 'cust-1',
      customerName: contract?.customerName || 'Khách hàng',
      contractId,
      contractCode: contract?.contractNumber || 'HD-2026-0001',
      siteName: 'Công trình khách hàng',
      siteAddress: 'Địa chỉ công trình',
      projectManager,
      teamMembers: [projectManager],
      startDate,
      endDate,
      budget,
      spentCost: 0,
      progressPercent: 0,
      status: 'Chưa bắt đầu',
      phases: [],
      materialRequests: [],
      createdAt: new Date().toISOString().split('T')[0],
      chain: {
        contractId,
        contractCode: contract?.contractNumber,
        customerId: contract?.customerId,
        customerCode: contract?.customerCode,
        customerName: contract?.customerName,
      },
    };

    setProjects((prev) => [newProj, ...prev]);
    showToast('Tạo dự án mới', `Đã lập kế hoạch dự án ${code}: ${title}`, 'success');
    return newProj;
  };

  const updateProjectTaskStatus = (
    projectId: string,
    taskId: string,
    status: ProjectTask['status'],
    progress: number
  ) => {
    setProjects((prev) =>
      prev.map((proj) => {
        if (proj.id !== projectId) return proj;

        let totalTasks = 0;
        let totalCompleted = 0;

        const updatedPhases = proj.phases.map((phase) => ({
          ...phase,
          tasks: phase.tasks.map((task) => {
            if (task.id === taskId) {
              const updated = { ...task, status, progress };
              totalTasks++;
              if (updated.status === 'Hoàn thành') totalCompleted++;
              return updated;
            }
            totalTasks++;
            if (task.status === 'Hoàn thành') totalCompleted++;
            return task;
          }),
        }));

        const newProgress = totalTasks > 0 ? Math.round((totalCompleted / totalTasks) * 100) : proj.progressPercent;
        const newProjStatus: TechnicalProject['status'] =
          newProgress === 100 ? 'Hoàn thành' : newProgress > 0 ? 'Đang triển khai' : 'Chưa bắt đầu';

        return {
          ...proj,
          phases: updatedPhases,
          progressPercent: newProgress,
          status: newProjStatus,
        };
      })
    );
    showToast('Cập nhật tiến độ', `Công việc đã cập nhật trạng thái: ${status} (${progress}%)`, 'info');
  };

  const addProjectMaterialRequest = (
    projectId: string,
    sku: string,
    productName: string,
    unit: string,
    quantityRequired: number
  ) => {
    const prod = products.find((p) => p.sku === sku);
    const totalAvail = prod ? Object.values(prod.stocks).reduce((a, b) => a + b, 0) - (prod.reserved || 0) : 0;
    const isEnough = totalAvail >= quantityRequired;

    const newReq: ProjectMaterialRequest = {
      id: `mat-${Date.now()}`,
      sku,
      productName,
      unit,
      quantityRequired,
      quantityAvailable: Math.max(0, totalAvail),
      status: isEnough ? 'Đủ hàng - Đã xuất' : 'Thiếu - Cần đặt hàng (PO)',
    };

    setProjects((prev) =>
      prev.map((proj) =>
        proj.id === projectId
          ? { ...proj, materialRequests: [newReq, ...proj.materialRequests] }
          : proj
      )
    );

    if (isEnough) {
      showToast('Yêu cầu vật tư', `Tồn kho khả dụng (${totalAvail}) đủ cho ${quantityRequired} ${unit} ${productName}. Đã tạo lệnh xuất kho nội bộ.`);
    } else {
      showToast('Cảnh báo thiếu vật tư', `Kho chỉ còn ${totalAvail} / ${quantityRequired} ${unit}. Hệ thống gợi ý tạo Đơn mua hàng (PO) sang bộ phận Vận chuyển.`, 'warning');
    }
  };

  // 6. Acceptance Certificate (BBNT)
  const createAcceptanceCertificate = (
    data: Omit<AcceptanceCertificate, 'id' | 'code' | 'createdAt' | 'chain'>
  ): AcceptanceCertificate => {
    const code = getNextCode('BBNT', acceptanceCertificates.length);
    const newCert: AcceptanceCertificate = {
      ...data,
      id: `bbnt-${Date.now()}`,
      code,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      chain: {
        contractId: data.contractId,
        contractCode: data.contractCode,
        customerId: data.customerId,
        customerName: data.customerName,
      },
    };

    setAcceptanceCertificates((prev) => [newCert, ...prev]);

    // Nếu kết quả Nghiệm thu là 'Đạt':
    if (data.result === 'Đạt') {
      // 1. Kích hoạt mốc thanh toán trong hợp đồng
      if (data.contractId) {
        const contract = contracts.find((c) => c.id === data.contractId);
        if (contract) {
          const updatedMilestones = contract.paymentMilestones.map((m) =>
            m.title.includes('nghiệm thu') || m.title === data.milestoneTitleToTrigger
              ? { ...m, isPaid: true }
              : m
          );
          updateContract(contract.id, {
            paymentMilestones: updatedMilestones,
          });
        }
      }

      // 2. Kích hoạt ngày bắt đầu bảo hành cho các thiết bị liên quan
      setCustomerEquipments((prev) =>
        prev.map((eq) => {
          if (eq.customerId === data.customerId && eq.status === 'Đang hoạt động') {
            const today = new Date().toISOString().split('T')[0];
            const endYear = new Date().getFullYear() + Math.floor(eq.warrantyDurationMonths / 12);
            return {
              ...eq,
              warrantyStartDate: today,
              warrantyEndDate: `${endYear}-${today.substring(5)}`,
            };
          }
          return eq;
        })
      );

      addNotification({
        title: 'Kỹ thuật: Nghiệm thu hoàn tất -> Báo Sale bàn giao & Vận hành',
        message: `Kỹ thuật đã hoàn tất nghiệm thu nội bộ Biên bản ${code} cho Hợp đồng ${data.contractCode} (Khách hàng: ${data.customerName}). Đã đưa vào List theo dõi vận hành & SLA. Sale tiến hành bàn giao khách hàng!`,
        type: 'sla',
        linkModule: 'technical-acceptance',
        entityId: newCert.id,
        senderName: data.techRepresentative || 'Kỹ sư Trưởng A+',
      });

      showToast(
        'Nghiệm thu thành công',
        `Biên bản ${code} kết luận ĐẠT. Đã tự động kích hoạt mốc thanh toán trong Hợp đồng ${data.contractCode} và kích hoạt hạn bảo hành thiết bị.`,
        'success'
      );
    } else {
      showToast('Nghiệm thu không đạt', `Biên bản ${code} ghi nhận không đạt. Yêu cầu kỹ thuật khắc phục các điểm tồn đọng.`, 'warning');
    }

    return newCert;
  };

  // 7. Warranty Tickets
  const createWarrantyTicket = (
    data: Omit<WarrantyTicket, 'id' | 'code' | 'status' | 'createdAt' | 'chain'>
  ): WarrantyTicket => {
    const code = getNextCode('YCBH', warrantyTickets.length);
    const newTicket: WarrantyTicket = {
      ...data,
      id: `w-${Date.now()}`,
      code,
      status: 'Mới tiếp nhận',
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      chain: {
        customerId: data.customerId,
        customerName: data.customerName,
      },
    };

    setWarrantyTickets((prev) => [newTicket, ...prev]);

    // Cập nhật trạng thái thiết bị sang 'Đang sửa/bảo hành'
    if (data.equipmentId) {
      updateCustomerEquipmentStatus(data.equipmentId, 'Đang sửa/bảo hành', `Tiếp nhận sự cố: ${data.symptoms}`);
    }

    showToast('Tạo Yêu cầu bảo hành', `Đã tiếp nhận yêu cầu bảo hành ${code} cho thiết bị ${data.equipmentName}.`, 'success');
    return newTicket;
  };

  const resolveWarrantyTicket = (id: string, resolution: string) => {
    setWarrantyTickets((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          if (t.equipmentId) {
            updateCustomerEquipmentStatus(t.equipmentId, 'Đang hoạt động', `Đã khắc phục xong: ${resolution}`);
          }
          return { ...t, status: 'Đã hoàn tất', resolution };
        }
        return t;
      })
    );
    showToast('Xử lý xong sự cố', `Đã hoàn tất yêu cầu bảo hành và bàn giao lại thiết bị hoạt động bình thường.`, 'success');
  };

  // 8. Warranty Stock Out (XBH)
  const createWarrantyStockOut = (
    ticketId: string,
    warehouseId: string,
    technicianName: string,
    replacementItems: WarrantyStockOut['replacementItems'],
    defectiveItemsCollected: WarrantyStockOut['defectiveItemsCollected'],
    notes?: string
  ): WarrantyStockOut => {
    const ticket = warrantyTickets.find((t) => t.id === ticketId);
    const code = getNextCode('XBH', warrantyStockOuts.length);

    const newXbh: WarrantyStockOut = {
      id: `xbh-${Date.now()}`,
      code,
      ticketId,
      ticketCode: ticket?.code || 'YCBH-2026-0001',
      customerId: ticket?.customerId || 'cust-1',
      customerName: ticket?.customerName || 'Khách hàng',
      warehouseId,
      warehouseName: warehouseId === 'wh-hn' ? 'Kho Tổng Hà Nội' : 'Kho TP.HCM',
      date: new Date().toISOString().split('T')[0],
      technicianName,
      replacementItems,
      defectiveItemsCollected,
      status: 'Đã xuất thay thế & thu hồi',
      notes,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      chain: {
        customerId: ticket?.customerId,
        customerName: ticket?.customerName,
      },
    };

    setWarrantyStockOuts((prev) => [newXbh, ...prev]);

    // Cập nhật ticket
    if (ticket) {
      setWarrantyTickets((prev) =>
        prev.map((t) =>
          t.id === ticketId ? { ...t, status: 'Cần thay thế linh kiện', warrantyStockOutCode: code } : t
        )
      );
    }

    showToast(
      'Xuất kho bảo hành',
      `Đã lập phiếu ${code}: Xuất linh kiện thay thế và lập biên bản thu hồi ${defectiveItemsCollected.length} thiết bị lỗi về kho.`,
      'success'
    );
    return newXbh;
  };

  // 9. Renewal Opportunity for Expiring Contracts
  const createRenewalOpportunityFromContract = (contractId: string, notes?: string) => {
    const contract = contracts.find((c) => c.id === contractId);
    if (!contract) return;

    addOpportunity({
      title: `[Tái Ký & Gia Hạn] Hợp đồng ${contract.contractNumber} - ${contract.customerName}`,
      customerId: contract.customerId,
      customerCode: contract.customerCode,
      customerName: contract.customerName,
      contactName: contract.templateVariables?.dai_dien || 'Đại diện kỹ thuật',
      amount: Math.round(contract.totalValue * 1.05), // Dự kiến tăng nhẹ theo chu kỳ mới
      stage: 'Khám phá nhu cầu',
      probability: 70, // Khách hàng cũ tỷ lệ tái ký cao
      expectedCloseDate: contract.endDate || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      leadSource: 'Chăm sóc & Gia hạn Kỹ thuật',
      interestedProducts: [],
      assignedTo: contract.manager || 'Nguyễn Văn Minh (Sales)',
      nextStep: 'Liên hệ khách hàng trao đổi gói gia hạn bảo trì năm tiếp theo',
      nextStepDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      lastActivityDate: new Date().toISOString().split('T')[0],
    });

    showToast(
      'Đẩy Cơ hội về Sales',
      `Đã tạo Cơ hội bán hàng gia hạn cho Hợp đồng ${contract.contractNumber} trong Quản lý Sales.`,
      'success'
    );
  };

  return (
    <TechnicalContext.Provider
      value={{
        customerSites,
        customerEquipments,
        addCustomerSite,
        addCustomerEquipment,
        updateCustomerEquipmentStatus,
        technicalCatalog,
        addCatalogItem,
        updateCatalogItem,
        quotationRequests,
        createTechnicalQuotationRequest,
        acceptQuotationRequest,
        returnQuotationRequest,
        saveQuotationLines,
        completeTechnicalQuotation,
        acceptContractForDeployment,
        projects,
        createProjectFromContract,
        updateProjectTaskStatus,
        addProjectMaterialRequest,
        acceptanceCertificates,
        createAcceptanceCertificate,
        warrantyTickets,
        createWarrantyTicket,
        resolveWarrantyTicket,
        warrantyStockOuts,
        createWarrantyStockOut,
        createRenewalOpportunityFromContract,
      }}
    >
      {children}
    </TechnicalContext.Provider>
  );
};

export const useTechnical = () => {
  const context = useContext(TechnicalContext);
  if (!context) {
    throw new Error('useTechnical must be used within a TechnicalProvider');
  }
  return context;
};
