import { DocumentChainInfo } from './sales';

// 1. Địa điểm / Công trình của khách hàng
export interface CustomerSite {
  id: string;
  customerId: string;
  name: string; // ví dụ: Tòa nhà Discovery Complex, Nhà máy Hưng Yên
  address: string;
  contactName: string;
  contactPhone: string;
  notes?: string;
}

// 2. Thiết bị của khách hàng đang quản lý
export type EquipmentStatus =
  | 'Đang hoạt động'
  | 'Đang sửa/bảo hành'
  | 'Đã thay thế'
  | 'Ngưng sử dụng';

export interface CustomerEquipment {
  id: string;
  customerId: string;
  customerName: string;
  sku: string;
  productName: string;
  serialNumber?: string;
  siteId?: string;
  siteName: string;
  installedDate: string;
  warrantyStartDate: string;
  warrantyDurationMonths: number;
  warrantyEndDate: string;
  contractId?: string;
  contractCode?: string;
  status: EquipmentStatus;
  notes?: string;
}

// 3. Danh mục kỹ thuật (Thư viện thiết bị, vật tư, dịch vụ)
export interface TechnicalCatalogItem {
  id: string;
  sku: string;
  name: string;
  category: string;
  unit: string;
  isService: boolean; // Dịch vụ kỹ thuật (không có tồn kho)
  techGroup: 'Hạ tầng mạng & Server' | 'Hệ thống Camera & An ninh' | 'IoT & Cảm biến' | 'Cáp & Vật tư phụ trợ' | 'Dịch vụ Kỹ thuật & Bảo trì';
  specs: { name: string; value: string }[];
  defaultWarrantyMonths: number;
  trackSerial: boolean;
  recommendedMaintenanceMonths: number; // Chu kỳ bảo trì khuyến nghị (tháng)
  bundledAccessories: { sku: string; name: string; quantity: number }[];
  serviceHourlyRate?: number; // Đơn giá theo giờ công
  standardHours?: number; // Định mức giờ công
  packagePrice?: number; // Đơn giá gói dịch vụ
  documents?: { name: string; type: string; size: string }[];
}

// 4. Báo giá kỹ thuật (YCKT-2026-xxxx)
export type TechRequestStatus =
  | 'Chờ tiếp nhận'
  | 'Đang khảo sát'
  | 'Đang lập báo giá'
  | 'Hoàn tất phần kỹ thuật'
  | 'Cần chỉnh sửa';

export type TechLineItemType =
  | 'Thiết bị'
  | 'Vật tư'
  | 'Nhân công'
  | 'Dịch vụ'
  | 'Chi phí khác';

export interface TechnicalQuotationLineItem {
  id: string;
  lineType: TechLineItemType;
  sku?: string;
  name: string;
  unit: string;
  quantity: number;
  unitPrice: number;
  total: number;
  hours?: number;
  hourlyRate?: number;
  costPrice?: number;
  availableStock?: number;
  notes?: string;
}

export interface TechnicalQuotationRequest {
  id: string;
  code: string; // YCKT-2026-xxxx
  opportunityId: string;
  opportunityCode: string;
  customerId: string;
  customerName: string;
  siteAddress: string;
  requirementDetails: string;
  expectedBudget?: number;
  deadlineDate: string; // Hạn cần kết quả
  assignedTechStaff?: string;
  status: TechRequestStatus;
  returnReason?: string;
  surveyNotes?: string;
  surveyPhotos?: string[];
  items: TechnicalQuotationLineItem[];
  subTotal: number;
  notes?: string;
  createdAt: string;
  completedAt?: string;
  version: number;
  chain: DocumentChainInfo;
}

// 5. Dự án & Kế hoạch tổng thể (DA-2026-xxxx)
export type ProjectStatus =
  | 'Chưa bắt đầu'
  | 'Đang triển khai'
  | 'Chờ nghiệm thu'
  | 'Hoàn thành'
  | 'Tạm dừng';

export type TaskStatus = 'Chưa làm' | 'Đang làm' | 'Hoàn thành';

export interface ProjectTask {
  id: string;
  phaseId: string;
  title: string;
  assignedTo: string;
  startDate: string;
  endDate: string;
  status: TaskStatus;
  progress: number; // 0 - 100%
  dependencyTaskId?: string;
  notes?: string;
}

export interface ProjectPhase {
  id: string;
  name: string; // Khảo sát, Chuẩn bị vật tư, Lắp đặt, Chạy thử, Nghiệm thu, Bàn giao
  order: number;
  tasks: ProjectTask[];
}

export interface ProjectMaterialRequest {
  id: string;
  sku: string;
  productName: string;
  unit: string;
  quantityRequired: number;
  quantityAvailable: number;
  status: 'Đủ hàng - Đã xuất' | 'Thiếu - Cần đặt hàng (PO)' | 'Chờ xuất kho';
  stockOutReceiptId?: string;
}

export interface TechnicalProject {
  id: string;
  code: string; // DA-2026-xxxx
  title: string;
  customerId: string;
  customerName: string;
  contractId: string;
  contractCode: string;
  siteName: string;
  siteAddress: string;
  projectManager: string;
  teamMembers: string[];
  startDate: string;
  endDate: string;
  budget: number;
  spentCost: number;
  progressPercent: number;
  status: ProjectStatus;
  phases: ProjectPhase[];
  materialRequests: ProjectMaterialRequest[];
  notes?: string;
  createdAt: string;
  chain: DocumentChainInfo;
}

// 6. Biên bản nghiệm thu (BBNT-2026-xxxx)
export interface AcceptanceCertificate {
  id: string;
  code: string; // BBNT-2026-xxxx
  projectId: string;
  projectCode: string;
  contractId: string;
  contractCode: string;
  customerId: string;
  customerName: string;
  acceptanceDate: string;
  customerRepresentative: string;
  customerRepRole: string;
  techRepresentative: string;
  scopeAccepted: string;
  result: 'Đạt' | 'Không đạt';
  milestoneTitleToTrigger?: string;
  activatedEquipmentsCount: number;
  notes?: string;
  createdAt: string;
  chain: DocumentChainInfo;
}

// 7. Yêu cầu bảo hành / Sự cố (YCBH-2026-xxxx)
export interface WarrantyTicket {
  id: string;
  code: string; // YCBH-2026-xxxx
  customerId: string;
  customerName: string;
  equipmentId: string;
  equipmentName: string;
  serialNumber?: string;
  siteName: string;
  issueDate: string;
  symptoms: string;
  priority: 'Khẩn cấp' | 'Cao' | 'Bình thường' | 'Thấp';
  assignedStaff: string;
  status: 'Mới tiếp nhận' | 'Đang xử lý' | 'Cần thay thế linh kiện' | 'Đã hoàn tất' | 'Đóng';
  resolution?: string;
  warrantyStockOutCode?: string;
  createdAt: string;
  chain: DocumentChainInfo;
}

// 8. Xuất kho bảo hành (XBH-2026-xxxx)
export interface WarrantyStockOutItem {
  sku: string;
  productName: string;
  quantity: number;
  serialNumber?: string;
  unitPrice: number;
  total: number;
}

export interface DefectiveItemCollected {
  sku: string;
  productName: string;
  quantity: number;
  serialNumber?: string;
  defectReason: string;
}

export interface WarrantyStockOut {
  id: string;
  code: string; // XBH-2026-xxxx
  ticketId: string;
  ticketCode: string;
  customerId: string;
  customerName: string;
  warehouseId: string;
  warehouseName: string;
  date: string;
  technicianName: string;
  replacementItems: WarrantyStockOutItem[];
  defectiveItemsCollected: DefectiveItemCollected[];
  status: 'Đã xuất thay thế & thu hồi' | 'Chờ duyệt' | 'Hủy';
  notes?: string;
  createdAt: string;
  chain: DocumentChainInfo;
}
