import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { CustomerAccount, CustomerType, CustomerGroup } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import {
  Search,
  Plus,
  Phone,
  Mail,
  Building,
  User,
  MapPin,
  Calendar,
  DollarSign,
  TrendingUp,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  X,
  CreditCard,
  Layers,
  ArrowRight,
  ExternalLink,
  Users,
  SlidersHorizontal,
  Columns,
  MessageSquare,
  Check,
  Eye,
  EyeOff,
  MoreHorizontal,
} from 'lucide-react';

type SavedViewType = 'all' | 'new' | 'vip' | 'call_today' | 'my_customers';

export const SalesCustomersView: React.FC = () => {
  const { showToast, setActiveModule, currentUser } = useCRM();
  const {
    customers,
    opportunities,
    quotations,
    contracts,
    invoices,
    activities,
    addCustomer,
    updateCustomer,
  } = useSales();

  // Saved Views State
  const [activeView, setActiveView] = useState<SavedViewType>('all');
  const [customViews, setCustomViews] = useState<string[]>([]);
  const [isNewViewModalOpen, setIsNewViewModalOpen] = useState(false);
  const [newViewName, setNewViewName] = useState('');

  // Column Visibility State
  const [visibleColumns, setVisibleColumns] = useState({
    code: true,
    name: true,
    assignedTo: true,
    group: true,
    totalRevenue: true,
    currentDebt: true,
    actions: true,
  });
  const [isColumnPickerOpen, setIsColumnPickerOpen] = useState(false);

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [groupFilter, setGroupFilter] = useState<string>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Selected Customer for Details
  const [selectedCust, setSelectedCust] = useState<CustomerAccount | null>(null);
  const [detailTab, setDetailTab] = useState<
    'overview' | 'activities' | 'deals' | 'contracts' | 'invoices' | 'contacts' | 'notes'
  >('overview');

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [transferTargetRep, setTransferTargetRep] = useState('Trần Minh Đức');

  // New Customer Form State (Clean Categorized)
  const [formName, setFormName] = useState('');
  const [formType, setFormType] = useState<CustomerType>('Doanh nghiệp');
  const [formTaxId, setFormTaxId] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formIndustry, setFormIndustry] = useState('Công nghệ & Viễn thông');
  const [formGroup, setFormGroup] = useState<CustomerGroup>('Thường');
  const [formBillingAddress, setFormBillingAddress] = useState('');
  const [formShippingAddress, setFormShippingAddress] = useState('');
  const [formContactName, setFormContactName] = useState('');
  const [formContactRole, setFormContactRole] = useState('Giám đốc điều hành');

  // Filter Customers by Saved View and Filters
  const filteredCustomers = customers.filter((c) => {
    // Saved view condition
    if (activeView === 'vip' && c.group !== 'VIP') return false;
    if (activeView === 'new' && c.group !== 'Tiềm năng') return false;
    if (activeView === 'call_today' && !c.phone) return false;
    if (activeView === 'my_customers' && c.assignedTo !== currentUser.fullName) return false;

    // Filter controls
    if (groupFilter !== 'all' && c.group !== groupFilter) return false;
    if (typeFilter !== 'all' && c.type !== typeFilter) return false;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        c.name.toLowerCase().includes(q) ||
        c.code.toLowerCase().includes(q) ||
        c.taxId.includes(q) ||
        c.phone.includes(q) ||
        c.email.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formPhone.trim()) {
      showToast('Lỗi nhập liệu', 'Vui lòng nhập tên khách hàng và số điện thoại.', 'warning');
      return;
    }

    const newCust = {
      name: formName.trim(),
      type: formType,
      taxId: formTaxId.trim(),
      phone: formPhone.trim(),
      email: formEmail.trim(),
      industry: formIndustry,
      group: formGroup,
      billingAddress: formBillingAddress.trim(),
      shippingAddresses: formShippingAddress.trim() ? [formShippingAddress.trim()] : [formBillingAddress.trim()],
      contacts: formContactName.trim()
        ? [
            {
              id: `cp-${Date.now()}`,
              fullName: formContactName.trim(),
              role: formContactRole,
              phone: formPhone.trim(),
              email: formEmail.trim(),
              isPrimary: true,
              isDecisionMaker: true,
            },
          ]
        : [],
      assignedTo: currentUser.fullName,
      notes: '',
    };

    const created = addCustomer(newCust);
    setIsCreateModalOpen(false);
    showToast('Tạo khách hàng thành công', `Đã lưu hồ sơ ${created.name} (${created.code}).`);
    setSelectedCust(created);

    // Reset
    setFormName('');
    setFormTaxId('');
    setFormPhone('');
    setFormEmail('');
    setFormBillingAddress('');
    setFormShippingAddress('');
    setFormContactName('');
  };

  const handleTransferCustomer = () => {
    if (!selectedCust) return;
    updateCustomer(selectedCust.id, {
      assignedTo: transferTargetRep,
    });
    setSelectedCust((prev) => (prev ? { ...prev, assignedTo: transferTargetRep } : null));
    setIsTransferModalOpen(false);
    showToast('Chuyển giao thành công', `Đã chuyển khách hàng sang cho ${transferTargetRep}.`);
  };

  const handleAddCustomView = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newViewName.trim()) return;
    setCustomViews([...customViews, newViewName.trim()]);
    setNewViewName('');
    setIsNewViewModalOpen(false);
    showToast('Tạo view thành công', `Đã lưu chế độ xem "${newViewName}".`);
  };

  // Associated customer deals & activities
  const custDeals = selectedCust
    ? opportunities.filter((o) => o.customerId === selectedCust.id || o.customerName === selectedCust.name)
    : [];
  const custQuotes = selectedCust
    ? quotations.filter((q) => q.customerId === selectedCust.id || q.customerName === selectedCust.name)
    : [];
  const custContracts = selectedCust
    ? contracts.filter((c) => c.customerId === selectedCust.id || c.customerName === selectedCust.name)
    : [];
  const custInvoices = selectedCust
    ? invoices.filter((i) => i.customerId === selectedCust.id || i.customerName === selectedCust.name)
    : [];
  const custActivities = selectedCust
    ? activities.filter((a) => a.targetId === selectedCust.id || a.targetName === selectedCust.name)
    : [];

  return (
    <div className="space-y-5 max-w-[1400px] mx-auto pb-12">
      {/* 01. PAGE HEADER */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E5EAF1] pb-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-[26px] font-bold text-[#172033] tracking-tight">
              Khách hàng
            </h1>
            <span className="inline-flex items-center px-2 py-0.5 rounded-[6px] text-[13px] font-semibold bg-[#F0F7FD] text-[#002659] border border-[#9CD7F8]">
              {customers.length} khách hàng
            </span>
          </div>
          <p className="text-[14px] text-[#667085] mt-1">
            Quản lý hồ sơ 360 độ, đầu mối liên hệ, lịch sử cơ hội, báo giá, hợp đồng và công nợ.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap shrink-0">
          <button
            onClick={() => showToast('Xuất danh sách', 'Đã xuất dữ liệu khách hàng ra định dạng Excel.')}
            className="h-9 px-3.5 rounded-[6px] border border-[#E5EAF1] bg-white hover:bg-slate-50 text-[14px] font-medium text-[#172033] transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Xuất Excel</span>
          </button>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="h-9 px-4 rounded-[6px] bg-[#002659] hover:bg-[#001a3d] text-white text-[14px] font-medium transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm Khách Hàng</span>
          </button>
        </div>
      </div>

      {/* 02. SAVED VIEWS BAR */}
      <div className="flex items-center justify-between gap-3 border-b border-[#E5EAF1] pb-1 overflow-x-auto">
        <div className="flex items-center gap-1.5 min-w-max">
          {[
            { id: 'all', label: 'Tất cả khách hàng' },
            { id: 'new', label: 'Khách hàng mới' },
            { id: 'vip', label: 'Khách hàng VIP' },
            { id: 'call_today', label: 'Cần gọi hôm nay' },
            { id: 'my_customers', label: 'Khách hàng của tôi' },
          ].map((v) => (
            <button
              key={v.id}
              onClick={() => setActiveView(v.id as SavedViewType)}
              className={`px-3 py-2 rounded-[6px] text-[14px] font-medium transition-colors cursor-pointer ${
                activeView === v.id
                  ? 'bg-[#002659] text-white font-semibold shadow-xs'
                  : 'text-[#667085] hover:text-[#002659] hover:bg-[#F0F7FD]'
              }`}
            >
              {v.label}
            </button>
          ))}

          {customViews.map((name) => (
            <button
              key={name}
              onClick={() => showToast('Chế độ xem', `Đang xem theo chế độ: ${name}`)}
              className="px-3 py-2 rounded-[6px] text-[14px] font-medium text-[#667085] hover:text-[#002659] hover:bg-[#F0F7FD] cursor-pointer"
            >
              {name}
            </button>
          ))}

          <button
            onClick={() => setIsNewViewModalOpen(true)}
            className="px-2.5 py-1.5 text-[13px] font-medium text-[#3661C9] hover:underline flex items-center gap-1 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tạo view</span>
          </button>
        </div>

        {/* Column Visibility Trigger */}
        <div className="relative">
          <button
            onClick={() => setIsColumnPickerOpen(!isColumnPickerOpen)}
            className="h-8 px-2.5 rounded-[6px] border border-[#E5EAF1] bg-white hover:bg-slate-50 text-[13px] font-medium text-[#667085] hover:text-[#172033] flex items-center gap-1.5 cursor-pointer shadow-xs"
          >
            <Columns className="w-3.5 h-3.5" />
            <span>Tùy chỉnh cột</span>
          </button>

          {isColumnPickerOpen && (
            <div className="absolute right-0 mt-2 w-56 rounded-[6px] bg-white border border-[#E5EAF1] shadow-xl p-3 z-30 space-y-2">
              <div className="text-[13px] font-bold text-[#172033] border-b border-[#E5EAF1] pb-1.5 flex items-center justify-between">
                <span>Cột hiển thị</span>
                <button
                  onClick={() => setIsColumnPickerOpen(false)}
                  className="text-[#98A2B3] hover:text-[#172033]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-1.5 text-[13px]">
                {[
                  { key: 'code', label: 'Mã khách hàng' },
                  { key: 'name', label: 'Tên KH / MST' },
                  { key: 'assignedTo', label: 'Người phụ trách' },
                  { key: 'group', label: 'Nhóm / Ngành' },
                  { key: 'totalRevenue', label: 'Doanh thu lũy kế' },
                  { key: 'currentDebt', label: 'Công nợ hiện tại' },
                  { key: 'actions', label: 'Thao tác' },
                ].map((col) => (
                  <label
                    key={col.key}
                    className="flex items-center gap-2 text-[#172033] cursor-pointer hover:bg-[#F8FAFC] p-1 rounded-[6px]"
                  >
                    <input
                      type="checkbox"
                      checked={(visibleColumns as any)[col.key]}
                      onChange={(e) =>
                        setVisibleColumns({
                          ...visibleColumns,
                          [col.key]: e.target.checked,
                        })
                      }
                      className="rounded-[4px] text-[#002659]"
                    />
                    <span>{col.label}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 03. FILTER & SEARCH BAR */}
      <div className="bg-white border border-[#E5EAF1] rounded-[6px] p-3 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#98A2B3] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo mã, tên công ty, số điện thoại, MST..."
            className="w-full pl-9 pr-3 h-9 text-[14px] rounded-[6px] border border-[#E5EAF1] bg-[#F8FAFC] text-[#172033] focus:outline-hidden focus:border-[#002659] focus:bg-white transition-colors"
          />
        </div>

        <div className="flex items-center gap-3 text-[14px] flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="text-[#667085] font-medium text-[13px]">Nhóm:</span>
            <select
              value={groupFilter}
              onChange={(e) => setGroupFilter(e.target.value)}
              className="h-9 px-2.5 rounded-[6px] border border-[#E5EAF1] bg-white text-[#172033] text-[13px] font-medium cursor-pointer"
            >
              <option value="all">Tất cả nhóm</option>
              <option value="VIP">Khách hàng VIP</option>
              <option value="Tiềm năng">Khách hàng Tiềm năng</option>
              <option value="Thường">Khách hàng Thường</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-[#667085] font-medium text-[13px]">Loại hình:</span>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="h-9 px-2.5 rounded-[6px] border border-[#E5EAF1] bg-white text-[#172033] text-[13px] font-medium cursor-pointer"
            >
              <option value="all">Tất cả loại hình</option>
              <option value="Doanh nghiệp">Doanh nghiệp</option>
              <option value="Cá nhân">Cá nhân</option>
            </select>
          </div>
        </div>
      </div>

      {/* 04. DATA TABLE (Row height 54px, 6px radius) */}
      <div className="bg-white border border-[#E5EAF1] rounded-[6px] overflow-hidden shadow-xs">
        <div className="px-5 py-3 border-b border-[#E5EAF1] flex items-center justify-between">
          <h2 className="section-title">
            Danh sách Khách hàng
          </h2>
          <span className="text-[13px] text-[#667085]">
            Hiển thị <strong className="text-[#172033]">{filteredCustomers.length}</strong> khách hàng
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr>
                {visibleColumns.code && <th className="w-28">Mã KH</th>}
                {visibleColumns.name && <th>Khách hàng / Công ty</th>}
                {visibleColumns.assignedTo && <th>Người phụ trách</th>}
                {visibleColumns.group && <th>Phân nhóm / Ngành</th>}
                {visibleColumns.totalRevenue && <th className="text-right">Doanh thu lũy kế</th>}
                {visibleColumns.currentDebt && <th className="text-right">Công nợ hiện tại</th>}
                {visibleColumns.actions && <th className="text-right w-28">Thao tác</th>}
              </tr>
            </thead>
            <tbody>
              {filteredCustomers.map((cust) => (
                <tr
                  key={cust.id}
                  onClick={() => setSelectedCust(cust)}
                  className="hover:bg-[#F8FAFC] cursor-pointer transition-colors"
                >
                  {visibleColumns.code && (
                    <td className="font-mono font-bold text-[#002659]">
                      {cust.code}
                    </td>
                  )}

                  {visibleColumns.name && (
                    <td>
                      <div className="font-semibold text-[#172033]">
                        {cust.name}
                      </div>
                      <div className="text-[13px] text-[#667085] font-mono flex items-center gap-2 mt-0.5">
                        <span>MST: {cust.taxId || 'N/A'}</span>
                        <span>•</span>
                        <span>{cust.phone}</span>
                      </div>
                    </td>
                  )}

                  {visibleColumns.assignedTo && (
                    <td className="text-[#172033] font-medium">
                      {cust.assignedTo}
                    </td>
                  )}

                  {visibleColumns.group && (
                    <td>
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`px-2 py-0.5 rounded-[6px] text-[13px] font-semibold ${
                            cust.group === 'VIP'
                              ? 'bg-[#FDF2E9] text-[#E96F22]'
                              : cust.group === 'Tiềm năng'
                              ? 'bg-[#F0F7FD] text-[#002659]'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {cust.group}
                        </span>
                        <span className="text-[13px] text-[#667085] truncate max-w-[150px]">
                          {cust.industry}
                        </span>
                      </div>
                    </td>
                  )}

                  {visibleColumns.totalRevenue && (
                    <td className="text-right font-mono font-bold text-emerald-600">
                      {(cust.totalRevenue / 1000000).toFixed(1)}M ₫
                    </td>
                  )}

                  {visibleColumns.currentDebt && (
                    <td className="text-right font-mono font-bold text-[#E96F22]">
                      {cust.currentDebt > 0 ? `${(cust.currentDebt / 1000000).toFixed(1)}M ₫` : '0 ₫'}
                    </td>
                  )}

                  {visibleColumns.actions && (
                    <td className="text-right" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => setSelectedCust(cust)}
                        className="px-2.5 py-1 rounded-[6px] border border-[#E5EAF1] bg-white hover:bg-[#F0F7FD] text-[#002659] text-[13px] font-semibold cursor-pointer transition-colors shadow-2xs"
                      >
                        Hồ sơ 360°
                      </button>
                    </td>
                  )}
                </tr>
              ))}
              {filteredCustomers.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-[#667085]">
                    Không tìm thấy khách hàng nào phù hợp với bộ lọc.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 05. CUSTOMER DETAIL DRAWER (Clean Header + Categorized Tabs) */}
      {selectedCust && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-[#172033]/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
          <div className="w-full max-w-2xl bg-white border-l border-[#E5EAF1] h-full overflow-y-auto flex flex-col p-6 shadow-2xl">
            {/* Header: Name, Company, Status, Quick Actions */}
            <div className="border-b border-[#E5EAF1] pb-4">
              <div className="flex items-start justify-between">
                <div>
                  <h2 className="text-[20px] font-bold text-[#172033] leading-snug">
                    {selectedCust.name}
                  </h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-[13px] font-mono text-[#667085]">
                      {selectedCust.code}
                    </span>
                    <span className="text-[#98A2B3]">•</span>
                    <span className="inline-flex items-center gap-1 text-[13px] font-semibold text-[#002659]">
                      <span className="w-2 h-2 rounded-full bg-[#002659]" />
                      Khách hàng {selectedCust.group}
                    </span>
                    <span className="text-[#98A2B3]">•</span>
                    <span className="text-[13px] text-[#667085]">
                      Phụ trách: <strong>{selectedCust.assignedTo}</strong>
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => setSelectedCust(null)}
                  className="p-1.5 rounded-[6px] text-[#667085] hover:text-[#172033] hover:bg-slate-100 cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Quick Action Buttons */}
              <div className="flex items-center gap-2 mt-4 flex-wrap">
                <button
                  onClick={() => showToast('Gọi điện', `Đang kết nối tới số ${selectedCust.phone}`)}
                  className="h-8 px-3 rounded-[6px] bg-[#002659] text-white text-[13px] font-semibold flex items-center gap-1.5 hover:bg-[#001a3d] cursor-pointer shadow-xs"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Gọi điện</span>
                </button>

                <button
                  onClick={() => showToast('Gửi email', `Đang mở trình soạn thảo gửi tới ${selectedCust.email}`)}
                  className="h-8 px-3 rounded-[6px] border border-[#E5EAF1] bg-white text-[#172033] text-[13px] font-medium flex items-center gap-1.5 hover:bg-slate-50 cursor-pointer shadow-xs"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Gửi thư</span>
                </button>

                <button
                  onClick={() => setActiveModule('tasks')}
                  className="h-8 px-3 rounded-[6px] border border-[#E5EAF1] bg-white text-[#172033] text-[13px] font-medium flex items-center gap-1.5 hover:bg-slate-50 cursor-pointer shadow-xs"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Tạo việc</span>
                </button>

                <button
                  onClick={() => setIsTransferModalOpen(true)}
                  className="h-8 px-3 rounded-[6px] border border-[#E5EAF1] bg-white text-[#667085] text-[13px] font-medium hover:text-[#172033] cursor-pointer shadow-xs"
                >
                  Chuyển giao
                </button>
              </div>
            </div>

            {/* Document Chain Bar */}
            <div className="mt-4">
              <DocumentChainBar
                currentType="customer"
                chain={{
                  customerId: selectedCust.id,
                  customerCode: selectedCust.code,
                  customerName: selectedCust.name,
                }}
              />
            </div>

            {/* 4 Financial KPI Stat Cards */}
            <div className="grid grid-cols-4 gap-2.5 mt-4">
              <div className="p-3 rounded-[6px] bg-[#F8FAFC] border border-[#E5EAF1]">
                <span className="text-[13px] text-[#667085] block font-medium">Doanh thu lũy kế</span>
                <span className="text-[16px] font-bold font-mono text-emerald-600">
                  {(selectedCust.totalRevenue / 1000000).toFixed(0)}M ₫
                </span>
              </div>
              <div className="p-3 rounded-[6px] bg-[#F8FAFC] border border-[#E5EAF1]">
                <span className="text-[13px] text-[#667085] block font-medium">Công nợ hiện tại</span>
                <span className="text-[16px] font-bold font-mono text-[#E96F22]">
                  {(selectedCust.currentDebt / 1000000).toFixed(0)}M ₫
                </span>
              </div>
              <div className="p-3 rounded-[6px] bg-[#F8FAFC] border border-[#E5EAF1]">
                <span className="text-[13px] text-[#667085] block font-medium">Cơ hội mở</span>
                <span className="text-[16px] font-bold font-mono text-[#002659]">
                  {custDeals.length} Deal
                </span>
              </div>
              <div className="p-3 rounded-[6px] bg-[#F8FAFC] border border-[#E5EAF1]">
                <span className="text-[13px] text-[#667085] block font-medium">Lần mua cuối</span>
                <span className="text-[13px] font-bold text-[#172033] truncate block">
                  {selectedCust.lastPurchaseDate || 'Chưa mua'}
                </span>
              </div>
            </div>

            {/* Structured Tabs */}
            <div className="flex items-center gap-1 border-b border-[#E5EAF1] mt-5 overflow-x-auto text-[14px] pb-1">
              {[
                { id: 'overview', label: 'Thông tin tổng quan' },
                { id: 'activities', label: `Hoạt động (${custActivities.length})` },
                { id: 'deals', label: `Cơ hội (${custDeals.length})` },
                { id: 'contracts', label: `Hợp đồng (${custContracts.length})` },
                { id: 'invoices', label: `Hóa đơn (${custInvoices.length})` },
                { id: 'contacts', label: `Người liên hệ (${selectedCust.contacts.length})` },
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setDetailTab(tab.id as any)}
                  className={`px-3 py-2 rounded-[6px] font-medium shrink-0 transition-colors cursor-pointer ${
                    detailTab === tab.id
                      ? 'bg-[#002659] text-white font-semibold'
                      : 'text-[#667085] hover:text-[#002659] hover:bg-[#F0F7FD]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Tab Contents */}
            <div className="mt-4 flex-1 space-y-4">
              {detailTab === 'overview' && (
                <div className="space-y-4 text-[14px]">
                  <div className="bg-[#F8FAFC] p-4 rounded-[6px] border border-[#E5EAF1] space-y-2">
                    <h4 className="font-bold text-[#172033] text-[13px] uppercase tracking-wider mb-2">
                      Thông Tin Pháp Lý & Giao Dịch
                    </h4>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-[#667085] block text-[13px]">Mã số thuế:</span>
                        <span className="font-bold font-mono text-[#172033]">
                          {selectedCust.taxId || 'Chưa cập nhật'}
                        </span>
                      </div>
                      <div>
                        <span className="text-[#667085] block text-[13px]">Ngành nghề:</span>
                        <span className="font-semibold text-[#172033]">
                          {selectedCust.industry}
                        </span>
                      </div>
                      <div>
                        <span className="text-[#667085] block text-[13px]">Số điện thoại:</span>
                        <span className="font-bold font-mono text-[#172033]">
                          {selectedCust.phone}
                        </span>
                      </div>
                      <div>
                        <span className="text-[#667085] block text-[13px]">Email:</span>
                        <span className="font-medium text-[#172033]">
                          {selectedCust.email}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-[#F8FAFC] p-4 rounded-[6px] border border-[#E5EAF1] space-y-2">
                    <h4 className="font-bold text-[#172033] text-[13px] uppercase tracking-wider mb-1 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-[#3661C9]" />
                      Địa Chỉ Giao Nhận & Hóa Đơn
                    </h4>
                    <div>
                      <span className="text-[#667085] block text-[13px]">Địa chỉ xuất hóa đơn:</span>
                      <p className="font-medium text-[#172033]">{selectedCust.billingAddress || 'Chưa có thông tin'}</p>
                    </div>
                  </div>
                </div>
              )}

              {detailTab === 'activities' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-[#172033] text-[14px]">
                      Dòng thời gian hoạt động
                    </span>
                    <button
                      onClick={() => showToast('Hoạt động', 'Chức năng thêm nhanh nhật ký tương tác.')}
                      className="px-2.5 py-1.5 rounded-[6px] bg-[#002659] text-white text-[13px] font-semibold cursor-pointer"
                    >
                      + Ghi nhận tương tác
                    </button>
                  </div>
                  <div className="space-y-2.5">
                    <div className="p-3 rounded-[6px] border border-[#E5EAF1] bg-[#F8FAFC] space-y-1">
                      <div className="flex items-center justify-between text-[13px]">
                        <span className="font-bold text-[#002659]">Cuộc gọi thoại</span>
                        <span className="text-[#98A2B3] font-mono">10:32 hôm nay</span>
                      </div>
                      <p className="text-[14px] text-[#172033]">
                        {selectedCust.assignedTo} đã liên hệ trao đổi về tiến độ ký kết hợp đồng giải pháp.
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {detailTab === 'deals' && (
                <div className="space-y-2">
                  {custDeals.map((d) => (
                    <div
                      key={d.id}
                      className="p-3 rounded-[6px] border border-[#E5EAF1] bg-[#F8FAFC] flex items-center justify-between"
                    >
                      <div>
                        <div className="font-bold text-[#172033] text-[14px]">{d.title}</div>
                        <div className="text-[#667085] font-mono text-[13px] mt-0.5">
                          {d.code} • Ngày chốt: {d.expectedCloseDate}
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-[#002659] text-[15px] block">
                          {(d.amount / 1000000).toFixed(1)}M ₫
                        </span>
                        <span className="text-[13px] font-semibold px-2 py-0.5 rounded-[6px] bg-[#F0F7FD] text-[#002659]">
                          {d.stage}
                        </span>
                      </div>
                    </div>
                  ))}
                  {custDeals.length === 0 && (
                    <p className="text-[#667085] py-4 text-center text-[14px]">
                      Chưa có cơ hội bán hàng nào cho khách hàng này.
                    </p>
                  )}
                </div>
              )}

              {detailTab === 'contacts' && (
                <div className="space-y-3">
                  {selectedCust.contacts.map((cp) => (
                    <div
                      key={cp.id}
                      className="p-3.5 rounded-[6px] border border-[#E5EAF1] bg-[#F8FAFC] flex items-center justify-between"
                    >
                      <div>
                        <div className="font-bold text-[#172033] text-[14px] flex items-center gap-2">
                          {cp.fullName}
                          {cp.isPrimary && (
                            <span className="px-1.5 py-0.2 rounded-[6px] text-[13px] bg-[#F0F7FD] text-[#002659] font-semibold">
                              Liên hệ chính
                            </span>
                          )}
                        </div>
                        <div className="text-[#667085] text-[13px] mt-0.5">{cp.role}</div>
                        <div className="flex items-center gap-3 text-[#172033] font-mono text-[13px] mt-1">
                          <span>{cp.phone}</span>
                          <span>•</span>
                          <span>{cp.email}</span>
                        </div>
                      </div>
                      <button
                        onClick={() => showToast('Gọi điện', `Đang kết nối tới ${cp.fullName}`)}
                        className="p-2 rounded-[6px] bg-emerald-50 text-emerald-700 hover:bg-emerald-100 cursor-pointer"
                      >
                        <Phone className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 06. MODAL: TẠO KHÁCH HÀNG MỚI (Categorized Form) */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#172033]/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5EAF1] rounded-[6px] p-6 max-w-xl w-full shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#E5EAF1]">
              <h3 className="font-bold text-[#172033] text-[18px]">
                Thêm Hồ Sơ Khách Hàng Mới
              </h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-[#667085] hover:text-[#172033] p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-4 mt-4 text-[14px]">
              {/* Group 1: Basic Info */}
              <div className="space-y-3">
                <div className="text-[13px] font-bold text-[#002659] uppercase tracking-wider">
                  1. Thông tin cơ bản
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[#172033] font-medium mb-1">
                      Tên Doanh nghiệp / Tổ chức *
                    </label>
                    <input
                      type="text"
                      required
                      value={formName}
                      onChange={(e) => setFormName(e.target.value)}
                      placeholder="Công ty CP Giải pháp ABC"
                      className="w-full px-3 py-2 rounded-[6px] border border-[#E5EAF1] text-[14px] focus:outline-hidden focus:border-[#002659]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#172033] font-medium mb-1">
                      Mã Số Thuế (MST)
                    </label>
                    <input
                      type="text"
                      value={formTaxId}
                      onChange={(e) => setFormTaxId(e.target.value)}
                      placeholder="0101234567"
                      className="w-full px-3 py-2 rounded-[6px] border border-[#E5EAF1] text-[14px] font-mono focus:outline-hidden focus:border-[#002659]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[#172033] font-medium mb-1">Số Điện Thoại *</label>
                    <input
                      type="tel"
                      required
                      value={formPhone}
                      onChange={(e) => setFormPhone(e.target.value)}
                      placeholder="0912345678"
                      className="w-full px-3 py-2 rounded-[6px] border border-[#E5EAF1] text-[14px] focus:outline-hidden focus:border-[#002659]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#172033] font-medium mb-1">Email</label>
                    <input
                      type="email"
                      value={formEmail}
                      onChange={(e) => setFormEmail(e.target.value)}
                      placeholder="contact@company.vn"
                      className="w-full px-3 py-2 rounded-[6px] border border-[#E5EAF1] text-[14px] focus:outline-hidden focus:border-[#002659]"
                    />
                  </div>
                  <div>
                    <label className="block text-[#172033] font-medium mb-1">Phân Nhóm</label>
                    <select
                      value={formGroup}
                      onChange={(e) => setFormGroup(e.target.value as CustomerGroup)}
                      className="w-full px-3 py-2 rounded-[6px] border border-[#E5EAF1] text-[14px] bg-white cursor-pointer"
                    >
                      <option value="Thường">Thường</option>
                      <option value="Tiềm năng">Tiềm năng</option>
                      <option value="VIP">VIP</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Group 2: Business & Address */}
              <div className="space-y-3 pt-2 border-t border-[#E5EAF1]">
                <div className="text-[13px] font-bold text-[#002659] uppercase tracking-wider">
                  2. Địa chỉ xuất hóa đơn
                </div>
                <input
                  type="text"
                  value={formBillingAddress}
                  onChange={(e) => setFormBillingAddress(e.target.value)}
                  placeholder="Số nhà, đường, phường/xã, quận/huyện, tỉnh/thành phố..."
                  className="w-full px-3 py-2 rounded-[6px] border border-[#E5EAF1] text-[14px] focus:outline-hidden focus:border-[#002659]"
                />
              </div>

              {/* Group 3: Primary Contact Person */}
              <div className="space-y-3 pt-2 border-t border-[#E5EAF1]">
                <div className="text-[13px] font-bold text-[#002659] uppercase tracking-wider">
                  3. Người liên hệ chính ban đầu
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <input
                    type="text"
                    placeholder="Họ tên người liên hệ"
                    value={formContactName}
                    onChange={(e) => setFormContactName(e.target.value)}
                    className="px-3 py-2 rounded-[6px] border border-[#E5EAF1] text-[14px] focus:outline-hidden focus:border-[#002659]"
                  />
                  <input
                    type="text"
                    placeholder="Chức vụ (VD: Trưởng phòng Mua hàng)"
                    value={formContactRole}
                    onChange={(e) => setFormContactRole(e.target.value)}
                    className="px-3 py-2 rounded-[6px] border border-[#E5EAF1] text-[14px] focus:outline-hidden focus:border-[#002659]"
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2.5 pt-4 border-t border-[#E5EAF1]">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-[6px] border border-[#E5EAF1] text-[#667085] hover:text-[#172033] font-medium cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-[6px] bg-[#002659] hover:bg-[#001a3d] text-white font-medium shadow-xs cursor-pointer"
                >
                  Lưu Khách Hàng
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 07. MODAL: TẠO VIEW MỚI */}
      {isNewViewModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#172033]/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5EAF1] rounded-[6px] p-5 max-w-sm w-full shadow-2xl">
            <h3 className="font-bold text-[#172033] text-[16px] mb-2">
              Tạo chế độ xem mới
            </h3>
            <p className="text-[13px] text-[#667085] mb-3">
              Lưu cấu hình bộ lọc hiện tại thành một tab xem riêng để truy cập nhanh.
            </p>
            <form onSubmit={handleAddCustomView} className="space-y-3">
              <input
                type="text"
                required
                value={newViewName}
                onChange={(e) => setNewViewName(e.target.value)}
                placeholder="Ví dụ: Khách dự án miền Bắc..."
                className="w-full px-3 py-2 rounded-[6px] border border-[#E5EAF1] text-[14px] focus:outline-hidden focus:border-[#002659]"
                autoFocus
              />
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsNewViewModalOpen(false)}
                  className="px-3 py-1.5 rounded-[6px] text-[13px] text-[#667085] hover:text-[#172033] cursor-pointer"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-[6px] bg-[#002659] text-white text-[13px] font-semibold cursor-pointer"
                >
                  Lưu view
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* 08. MODAL: CHUYỂN GIAO KHÁCH HÀNG */}
      {isTransferModalOpen && selectedCust && (
        <div className="fixed inset-0 z-50 bg-[#172033]/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#E5EAF1] rounded-[6px] p-5 max-w-sm w-full shadow-2xl text-[14px]">
            <h3 className="font-bold text-[#172033] text-[16px] mb-2">
              Chuyển giao khách hàng: {selectedCust.name}
            </h3>
            <p className="text-[13px] text-[#667085] mb-4">
              Nhân sự mới sẽ tiếp nhận quản lý toàn bộ cơ hội, báo giá và lịch sử công nợ của khách hàng này.
            </p>
            <div className="space-y-3">
              <div>
                <label className="block text-[#172033] font-medium text-[13px] mb-1">
                  Chọn nhân viên tiếp nhận:
                </label>
                <select
                  value={transferTargetRep}
                  onChange={(e) => setTransferTargetRep(e.target.value)}
                  className="w-full px-3 py-2 rounded-[6px] border border-[#E5EAF1] bg-white text-[14px] cursor-pointer"
                >
                  <option value="Trần Minh Đức">Trần Minh Đức (Giám đốc Sales)</option>
                  <option value="Lê Hoàng Yến">Lê Hoàng Yến (Phòng Dự án)</option>
                  <option value="Phạm Hải Đăng">Phạm Hải Đăng (Chăm sóc KH)</option>
                </select>
              </div>
            </div>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                onClick={() => setIsTransferModalOpen(false)}
                className="px-3 py-1.5 rounded-[6px] border border-[#E5EAF1] text-[#667085] cursor-pointer"
              >
                Hủy
              </button>
              <button
                onClick={handleTransferCustomer}
                className="px-4 py-1.5 rounded-[6px] bg-[#002659] text-white font-medium cursor-pointer"
              >
                Xác Nhận Chuyển Giao
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
