/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { MultiTenantProvider, useMultiTenant } from './context/MultiTenantContext';
import { CRMProvider, useCRM } from './context/CRMContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { ToastContainer } from './components/common/ToastContainer';
import { ScreenSpecModal } from './components/modals/ScreenSpecModal';
import { ErrorBoundary } from './components/common/ErrorBoundary';

// Auth & Platform Views
import { LoginView } from './views/auth/LoginView';
import { RegisterView } from './views/auth/RegisterView';
import { JoinCompanyView } from './views/auth/JoinCompanyView';
import { AcceptInviteView } from './views/auth/AcceptInviteView';
import { ForgotPasswordView } from './views/auth/ForgotPasswordView';
import { WorkspaceSelectModal } from './views/auth/WorkspaceSelectModal';
import { PlatformAdminView } from './views/platform/PlatformAdminView';
import { SystemArchitectureView } from './views/platform/SystemArchitectureView';

// Views
import { DashboardView } from './views/DashboardView';
import { LeadsView } from './views/LeadsView';
import { ContactsView } from './views/ContactsView';
import { OpportunitiesView } from './views/OpportunitiesView';
import { QuotationsView } from './views/QuotationsView';
import { ContractsView } from './views/ContractsView';
import { CustomerCareView } from './views/CustomerCareView';
import { InventoryView } from './views/InventoryView';
import { ReportsView } from './views/ReportsView';
import { SettingsView } from './views/SettingsView';
import { SpecSuiteView } from './views/SpecSuiteView';
import { TasksView } from './views/TasksView';
import { CalendarView } from './views/CalendarView';
import { SalesHubView } from './views/SalesHubView';
import { PlaceholderModuleView } from './views/PlaceholderModuleView';
import { Truck, Calculator, Wrench, Users, Warehouse } from 'lucide-react';
import { ReportFilterState } from './types/crm';
import { SalesOverviewReport } from './views/reports/SalesOverviewReport';
import { SalesRevenueReport } from './views/reports/SalesRevenueReport';
import { SalesForecastReport } from './views/reports/SalesForecastReport';
import { SalesFunnelReport } from './views/reports/SalesFunnelReport';
import { SalesWonReport } from './views/reports/SalesWonReport';
import { SalesLostReport } from './views/reports/SalesLostReport';
import { SalesProductivityReport } from './views/reports/SalesProductivityReport';
import { SalesLeadsReport } from './views/reports/SalesLeadsReport';
import { InventoryReportView } from './views/reports/InventoryReportView';
import { LogisticsReportView } from './views/reports/LogisticsReportView';
import { TechnicalReportView } from './views/reports/TechnicalReportView';
import { HRReportView } from './views/reports/HRReportView';

// Warehouse & Inventory Views
import { WarehouseProvider } from './context/WarehouseContext';
import { InventoryOverviewView } from './views/inventory/InventoryOverviewView';
import { StockInView } from './views/inventory/StockInView';
import { StockOutView } from './views/inventory/StockOutView';
import { StockHistoryView } from './views/inventory/StockHistoryView';
import { ExpiringStockView } from './views/inventory/ExpiringStockView';

// Sales Management Views
import { SalesProvider } from './context/SalesContext';
import { SalesLeadsView } from './views/sales/SalesLeadsView';
import { SalesCustomersView } from './views/sales/SalesCustomersView';
import { SalesOpportunitiesView } from './views/sales/SalesOpportunitiesView';
import { SalesQuotationsView } from './views/sales/SalesQuotationsView';
import { SalesOrdersView } from './views/sales/SalesOrdersView';
import { SalesContractsView } from './views/sales/SalesContractsView';
import { SalesInvoicesView } from './views/sales/SalesInvoicesView';
import { SalesReceiptsView } from './views/sales/SalesReceiptsView';
import { SalesActivitiesView } from './views/sales/SalesActivitiesView';

// Logistics Views & Context
import { LogisticsProvider } from './context/LogisticsContext';
import { LogisticsOrderApprovalView } from './views/logistics/LogisticsOrderApprovalView';
import { LogisticsDeliveryNotesView } from './views/logistics/LogisticsDeliveryNotesView';
import { LogisticsShipmentsView } from './views/logistics/LogisticsShipmentsView';
import { LogisticsHandoverView } from './views/logistics/LogisticsHandoverView';
import { LogisticsCodCollectionsView } from './views/logistics/LogisticsCodCollectionsView';
import { LogisticsPurchaseOrdersView } from './views/logistics/LogisticsPurchaseOrdersView';
import { LogisticsPurchaseInvoicesView } from './views/logistics/LogisticsPurchaseInvoicesView';
import { LogisticsPaymentRequestsView } from './views/logistics/LogisticsPaymentRequestsView';
import { LogisticsDocumentExpiryView } from './views/logistics/LogisticsDocumentExpiryView';

// Technical Views & Context
import { TechnicalProvider } from './context/TechnicalContext';
import { TechnicalCustomersView } from './views/technical/TechnicalCustomersView';
import { TechnicalDirectoryView } from './views/technical/TechnicalDirectoryView';
import { TechnicalQuotationsView } from './views/technical/TechnicalQuotationsView';
import { TechnicalContractsView } from './views/technical/TechnicalContractsView';
import { TechnicalMasterPlanningView } from './views/technical/TechnicalMasterPlanningView';
import { TechnicalPaymentRequestsView } from './views/technical/TechnicalPaymentRequestsView';
import { TechnicalWarrantyStockOutView } from './views/technical/TechnicalWarrantyStockOutView';
import { TechnicalExpiringContractsView } from './views/technical/TechnicalExpiringContractsView';

// HR Views & Context
import { HRProvider } from './context/HRContext';
import { StaffManagementView } from './views/hr/StaffManagementView';
import { SocialInsuranceView } from './views/hr/SocialInsuranceView';
import { MyProfileView } from './views/hr/MyProfileView';
import { NotificationsCenterView } from './views/NotificationsCenterView';

// Accounting Views & Context
import { AccountingProvider } from './context/AccountingContext';
import { AccountingDebtView } from './views/accounting/AccountingDebtView';
import { AccountingInvoicesView } from './views/accounting/AccountingInvoicesView';
import { AccountingCashFlowView } from './views/accounting/AccountingCashFlowView';
import { AccountingReportsView } from './views/accounting/AccountingReportsView';

// System Settings Views & Context
import { SettingsProvider } from './context/SettingsContext';
import { SettingsUsersView } from './views/settings/SettingsUsersView';
import { OrganizationManagementView } from './views/settings/OrganizationManagementView';
import { SettingsPermissionsView } from './views/settings/SettingsPermissionsView';
import { SettingsSystemConfigView } from './views/settings/SettingsSystemConfigView';
import { SettingsAppConfigView } from './views/settings/SettingsAppConfigView';
import { SettingsDictionaryView } from './views/settings/SettingsDictionaryView';
import { SettingsDirectoriesView } from './views/settings/SettingsDirectoriesView';
import { SettingsSyncLogsView } from './views/settings/SettingsSyncLogsView';

// Modals & Tools
import { CommandPalette } from './components/modals/CommandPalette';

const MainAppContent: React.FC = () => {
  const { activeModule, setActiveModule, themeDef, customTheme, theme } = useCRM();
  const { isPlatformMode } = useMultiTenant();
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Shared filter state across all Sales Reports
  const [reportFilter, setReportFilter] = useState<ReportFilterState>({
    dateRangePreset: 'month',
    salesRepId: 'all',
    teamId: 'all',
    productId: 'all',
    region: 'all',
    source: 'all',
    viewRole: 'director',
  });

  const handleUpdateReportFilter = (updated: Partial<ReportFilterState>) => {
    setReportFilter((prev) => ({ ...prev, ...updated }));
  };

  const customStyles: React.CSSProperties = {
    fontFamily: "'Roboto', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
  };

  const renderActiveModuleView = () => {
    if (isPlatformMode || activeModule === 'platform-admin') {
      return <PlatformAdminView />;
    }

    switch (activeModule) {
      case 'platform-admin':
        return <PlatformAdminView />;
      case 'dashboard':
        return <DashboardView />;
      case 'reports':
      case 'sales-overview':
        return <SalesOverviewReport filter={reportFilter} onChangeFilter={handleUpdateReportFilter} />;
      case 'sales-revenue':
        return <SalesRevenueReport filter={reportFilter} onChangeFilter={handleUpdateReportFilter} />;
      case 'sales-forecast':
        return <SalesForecastReport filter={reportFilter} onChangeFilter={handleUpdateReportFilter} />;
      case 'sales-funnel':
        return <SalesFunnelReport filter={reportFilter} onChangeFilter={handleUpdateReportFilter} />;
      case 'sales-won':
        return <SalesWonReport filter={reportFilter} onChangeFilter={handleUpdateReportFilter} />;
      case 'sales-lost':
        return <SalesLostReport filter={reportFilter} onChangeFilter={handleUpdateReportFilter} />;
      case 'sales-productivity':
        return <SalesProductivityReport filter={reportFilter} onChangeFilter={handleUpdateReportFilter} />;
      case 'sales-leads':
        return <SalesLeadsReport filter={reportFilter} onChangeFilter={handleUpdateReportFilter} />;
      case 'reports-inventory':
        return <InventoryReportView />;
      case 'reports-logistics':
        return <LogisticsReportView />;
      case 'reports-accounting':
        return <AccountingReportsView />;
      case 'reports-technical':
        return <TechnicalReportView />;
      case 'reports-hr':
        return <HRReportView />;
      case 'inventory':
      case 'inventory-overview':
        return <InventoryOverviewView />;
      case 'inventory-stock-in':
        return <StockInView />;
      case 'inventory-stock-out':
        return <StockOutView />;
      case 'inventory-history':
        return <StockHistoryView />;
      case 'inventory-expiry':
        return <ExpiringStockView />;
      case 'sales':
      case 'leads':
        return <SalesLeadsView />;
      case 'customers':
      case 'contacts':
        return <SalesCustomersView />;
      case 'opportunities':
        return <SalesOpportunitiesView />;
      case 'quotations':
        return <SalesQuotationsView />;
      case 'sales-orders':
        return <SalesOrdersView />;
      case 'contracts':
        return <SalesContractsView />;
      case 'sales-invoices':
        return <SalesInvoicesView />;
      case 'sales-receipts':
        return <SalesReceiptsView />;
      case 'sales-activities':
        return <SalesActivitiesView />;
      case 'logistics':
      case 'logistics-order-approval':
        return <LogisticsOrderApprovalView />;
      case 'logistics-stock-out':
        return <StockOutView viewMode="logistics" />;
      case 'logistics-delivery-notes':
        return <LogisticsDeliveryNotesView />;
      case 'logistics-shipments':
        return <LogisticsShipmentsView />;
      case 'logistics-handover':
        return <LogisticsHandoverView />;
      case 'logistics-cod-collections':
        return <LogisticsCodCollectionsView />;
      case 'logistics-purchase-orders':
        return <LogisticsPurchaseOrdersView />;
      case 'logistics-purchase-invoices':
        return <LogisticsPurchaseInvoicesView />;
      case 'logistics-stock-in':
        return <StockInView viewMode="logistics" />;
      case 'logistics-payment-requests':
        return <LogisticsPaymentRequestsView />;
      case 'logistics-stock-history':
        return <StockHistoryView viewMode="logistics" />;
      case 'logistics-approaching-expiry':
        return <ExpiringStockView viewMode="logistics" />;
      case 'logistics-document-expiry':
        return <LogisticsDocumentExpiryView />;
      case 'accounting':
      case 'accounting-debt':
        return <AccountingDebtView />;
      case 'accounting-invoices':
        return <AccountingInvoicesView />;
      case 'accounting-transactions':
        return <AccountingCashFlowView />;
      case 'accounting-reports':
        return <AccountingReportsView />;
      case 'technical':
      case 'technical-customers':
        return <TechnicalCustomersView />;
      case 'technical-directory':
        return <TechnicalDirectoryView />;
      case 'technical-quotations':
        return <TechnicalQuotationsView />;
      case 'technical-contracts':
        return <TechnicalContractsView />;
      case 'technical-master-planning':
        return <TechnicalMasterPlanningView />;
      case 'technical-payment-requests':
        return <TechnicalPaymentRequestsView />;
      case 'technical-warranty-stock-out':
        return <TechnicalWarrantyStockOutView />;
      case 'technical-expiring-contracts':
        return <TechnicalExpiringContractsView />;
      case 'hr':
      case 'hr-staff':
        return <StaffManagementView />;
      case 'hr-insurance':
        return <SocialInsuranceView />;
      case 'my-profile':
        return <MyProfileView />;
      case 'notifications-center':
        return <NotificationsCenterView />;
      case 'settings':
      case 'settings-users':
        return <OrganizationManagementView />;
      case 'settings-permissions':
        return <SettingsPermissionsView />;
      case 'system-architecture':
        return <SystemArchitectureView />;
      case 'settings-system':
        return <SettingsSystemConfigView />;
      case 'settings-app':
        return <SettingsAppConfigView />;
      case 'settings-dictionary':
        return <SettingsDictionaryView />;
      case 'settings-directories':
        return <SettingsDirectoriesView />;
      case 'settings-sync-logs':
        return <SettingsSyncLogsView />;
      case 'tasks':
      case 'calendar':
        return <SalesActivitiesView />;
      case 'customer-care':
        return <CustomerCareView />;
      case 'specifications':
        return <SpecSuiteView />;
      default:
        return <DashboardView />;
    }
  };

  return (
    <div
      data-theme={theme}
      style={customStyles}
      className={`min-h-screen flex ${themeDef.classes.appBackground} ${theme === 'modern-dark' ? 'dark' : ''} transition-colors duration-200`}
    >
      {/* Sidebar Navigation */}
      <Sidebar
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header onToggleSidebarMobile={() => setMobileSidebarOpen(!mobileSidebarOpen)} />

        {/* Viewport View Container */}
        <main className="flex-1 overflow-y-auto p-3 sm:p-5 lg:p-8 pb-20 md:pb-8">
          <div className="max-w-7xl mx-auto">
            <ErrorBoundary key={activeModule} onReset={() => setActiveModule('dashboard')}>
              {renderActiveModuleView()}
            </ErrorBoundary>
          </div>
        </main>

        {/* Mobile Bottom Navigation Bar (Natural Thumb Reach) */}
        <MobileBottomNav onOpenMobileMenu={() => setMobileSidebarOpen(true)} />
      </div>

      {/* Slide-over / Modal for Inspecting Screen Spec */}
      <ScreenSpecModal />

      {/* Global Command Palette (Cmd + K) */}
      <CommandPalette />

      {/* Toast Alert Notifications */}
      <ToastContainer />
    </div>
  );
};

const AppRouter: React.FC = () => {
  const { isAuthenticated, authScreenMode, isPlatformMode } = useMultiTenant();

  if (!isAuthenticated && !isPlatformMode) {
    switch (authScreenMode) {
      case 'REGISTER':
        return (
          <>
            <RegisterView />
            <ToastContainer />
          </>
        );
      case 'JOIN_COMPANY':
        return (
          <>
            <JoinCompanyView />
            <ToastContainer />
          </>
        );
      case 'ACCEPT_INVITE':
        return (
          <>
            <AcceptInviteView />
            <ToastContainer />
          </>
        );
      case 'FORGOT_PASSWORD':
        return (
          <>
            <ForgotPasswordView />
            <ToastContainer />
          </>
        );
      case 'SELECT_WORKSPACE':
        return (
          <>
            <WorkspaceSelectModal />
            <ToastContainer />
          </>
        );
      case 'LOGIN':
      default:
        return (
          <>
            <LoginView />
            <ToastContainer />
          </>
        );
    }
  }

  return <MainAppContent />;
};

export default function App() {
  return (
    <MultiTenantProvider>
      <CRMProvider>
        <WarehouseProvider>
          <SalesProvider>
            <LogisticsProvider>
              <TechnicalProvider>
                <HRProvider>
                  <SettingsProvider>
                    <AccountingProvider>
                      <AppRouter />
                    </AccountingProvider>
                  </SettingsProvider>
                </HRProvider>
              </TechnicalProvider>
            </LogisticsProvider>
          </SalesProvider>
        </WarehouseProvider>
      </CRMProvider>
    </MultiTenantProvider>
  );
}
