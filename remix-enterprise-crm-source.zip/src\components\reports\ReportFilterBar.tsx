import React, { useState } from 'react';
import { ReportFilterState, ReportDateRangePreset, SavedReportFilter } from '../../types/crm';
import { MOCK_SALES_TEAMS, MOCK_SALES_REPS } from '../../data/mockReportsData';
import { useCRM } from '../../context/CRMContext';
import { getReportText, translateEntityName } from '../../i18n/translations';
import {
  Calendar,
  Filter,
  FileSpreadsheet,
  FileText,
  BookmarkPlus,
  UserCheck,
  RotateCcw,
  ChevronDown,
  ChevronUp,
  X,
  Users,
  User,
  Package,
  MapPin,
  Tag,
  Eye,
  EyeOff,
} from 'lucide-react';

interface ReportFilterBarProps {
  filter: ReportFilterState;
  onChangeFilter: (updated: Partial<ReportFilterState>) => void;
  reportTitle: string;
  initialCollapsed?: boolean;
  initialShowRole?: boolean;
}

export const ReportFilterBar: React.FC<ReportFilterBarProps> = ({
  filter,
  onChangeFilter,
  reportTitle,
  initialCollapsed = false,
  initialShowRole = false,
}) => {
  const { showToast, language } = useCRM();

  // State: Collapsible filter section
  const [isCollapsed, setIsCollapsed] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('crm_report_filter_collapsed');
      return saved !== null ? saved === 'true' : initialCollapsed;
    } catch {
      return initialCollapsed;
    }
  });

  // State: Show / Hide Role view permission section
  const [showRoleView, setShowRoleView] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('crm_report_filter_show_role');
      return saved !== null ? saved === 'true' : initialShowRole;
    } catch {
      return initialShowRole;
    }
  });

  const [saveModalOpen, setSaveModalOpen] = useState(false);
  const [savedFilterName, setSavedFilterName] = useState('');
  const [savedFiltersList, setSavedFiltersList] = useState<SavedReportFilter[]>([
    {
      id: 'saved-01',
      name: 'Tháng này - Miền Bắc',
      createdAt: '2026-10-01',
      filters: {
        dateRangePreset: 'month',
        salesRepId: 'all',
        teamId: 'team-north',
        productId: 'all',
        region: 'Miền Bắc',
        source: 'all',
        viewRole: 'director',
      },
    },
    {
      id: 'saved-02',
      name: 'Quý này - Enterprise B2B',
      createdAt: '2026-10-02',
      filters: {
        dateRangePreset: 'quarter',
        salesRepId: 'all',
        teamId: 'team-b2b',
        productId: 'all',
        region: 'all',
        source: 'all',
        viewRole: 'manager',
      },
    },
  ]);

  const toggleCollapsed = () => {
    setIsCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('crm_report_filter_collapsed', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const toggleRoleView = (overrideVal?: boolean) => {
    setShowRoleView((prev) => {
      const next = overrideVal !== undefined ? overrideVal : !prev;
      try {
        localStorage.setItem('crm_report_filter_show_role', String(next));
      } catch {
        // ignore
      }
      return next;
    });
  };

  const handleExportExcel = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,' +
      encodeURIComponent(
        `Báo cáo: ${reportTitle}\nThời gian: ${filter.dateRangePreset}\nNhóm: ${filter.teamId}\nKhu vực: ${filter.region}\nNgày xuất: ${new Date().toLocaleString('vi-VN')}\n`
      );
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', csvContent);
    downloadAnchor.setAttribute('download', `${reportTitle.replace(/\s+/g, '_')}_${Date.now()}.csv`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    showToast('Xuất Excel thành công', `Đã tạo tệp dữ liệu bảng tính cho "${reportTitle}".`, 'success');
  };

  const handleExportPDF = () => {
    showToast('Chuẩn bị in ấn PDF', 'Đang kết xuất tài liệu PDF tiêu chuẩn A+ Report.', 'info');
    setTimeout(() => {
      window.print();
    }, 400);
  };

  const handleSaveFilter = () => {
    if (!savedFilterName.trim()) {
      showToast('Lỗi', 'Vui lòng nhập tên bộ lọc', 'error');
      return;
    }
    const newSaved: SavedReportFilter = {
      id: `filter-${Date.now()}`,
      name: savedFilterName.trim(),
      filters: { ...filter },
      createdAt: new Date().toISOString().split('T')[0],
    };
    setSavedFiltersList((prev) => [newSaved, ...prev]);
    setSavedFilterName('');
    setSaveModalOpen(false);
    showToast('Đã lưu bộ lọc', `Bộ lọc "${newSaved.name}" đã được lưu vào danh sách của bạn.`);
  };

  const handleResetFilter = () => {
    onChangeFilter({
      dateRangePreset: 'month',
      customStartDate: undefined,
      customEndDate: undefined,
      salesRepId: 'all',
      teamId: 'all',
      productId: 'all',
      region: 'all',
      source: 'all',
      viewRole: 'director',
    });
    showToast('Đặt lại bộ lọc', 'Đã khôi phục các tiêu chí lọc về mặc định.');
  };

  // Count active non-default filters
  const activeFiltersCount = [
    filter.dateRangePreset !== 'month',
    filter.teamId !== 'all',
    filter.salesRepId !== 'all',
    filter.productId !== 'all',
    filter.region !== 'all',
    filter.source !== 'all',
    filter.viewRole !== 'director',
  ].filter(Boolean).length;

  // Labels for compact summary tags
  const getPresetLabel = (preset: ReportDateRangePreset) => {
    switch (preset) {
      case 'today':
        return getReportText('presetToday', language);
      case 'week':
        return getReportText('presetWeek', language);
      case 'month':
        return getReportText('presetMonth', language);
      case 'quarter':
        return getReportText('presetQuarter', language);
      case 'year':
        return getReportText('presetYear', language);
      case 'custom':
        return getReportText('presetCustom', language);
      default:
        return preset;
    }
  };

  const selectedTeamName =
    filter.teamId === 'all'
      ? null
      : MOCK_SALES_TEAMS.find((t) => t.id === filter.teamId)?.name || filter.teamId;

  const selectedRepName =
    filter.salesRepId === 'all'
      ? null
      : MOCK_SALES_REPS.find((r) => r.id === filter.salesRepId)?.name || filter.salesRepId;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-xl shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] transition-all duration-200 print:hidden overflow-hidden">
      {/* 1. Header Toolbar */}
      <div className="px-3.5 py-2.5 sm:px-4 sm:py-3 flex flex-wrap items-center justify-between gap-2.5 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/60 dark:bg-slate-900/60">
        {/* Left: Filter title, active badge & role permission toggle */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={toggleCollapsed}
            className="flex items-center gap-2 group text-left focus:outline-hidden"
            title={
              isCollapsed
                ? (language === 'vi' ? 'Mở rộng khu vực lọc' : language === 'ja' ? 'フィルター領域を展開' : 'Expand filter area')
                : (language === 'vi' ? 'Thu nhỏ khu vực lọc' : language === 'ja' ? 'フィルター領域を折りたたむ' : 'Collapse filter area')
            }
          >
            <div className="w-7 h-7 rounded-lg bg-sky-50 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800 flex items-center justify-center text-sky-600 dark:text-sky-400 group-hover:bg-sky-100 transition-colors">
              <Filter className="w-3.5 h-3.5" />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors">
                {getReportText('filterTitle', language)}
              </span>
              {activeFiltersCount > 0 ? (
                <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold bg-sky-100 text-sky-700 dark:bg-sky-900/60 dark:text-sky-300">
                  {activeFiltersCount} {getReportText('filterCountSuffix', language)}
                </span>
              ) : (
                <span className="text-[11px] text-slate-400 dark:text-slate-500 font-normal hidden sm:inline">
                  {getReportText('filterDefault', language)}
                </span>
              )}
            </div>
          </button>

          {/* Role view toggle button (Allows user to hide/show role perspective) */}
          <div className="h-4 w-px bg-slate-200 dark:bg-slate-800 mx-1 hidden sm:block" />
          <button
            type="button"
            onClick={() => toggleRoleView()}
            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
              showRoleView
                ? 'bg-sky-100 dark:bg-sky-900/50 text-sky-800 dark:text-sky-300 border border-sky-300 dark:border-sky-700 shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
            title={
              showRoleView
                ? (language === 'vi' ? 'Ẩn phần quyền xem dữ liệu' : language === 'ja' ? '閲覧権限の選択を非表示' : 'Hide role view options')
                : (language === 'vi' ? 'Hiển thị tùy chọn quyền xem dữ liệu' : language === 'ja' ? '閲覧権限の選択を表示' : 'Show role view options')
            }
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>
              {showRoleView ? getReportText('roleViewActive', language) : getReportText('roleViewBtn', language)}
            </span>
            {showRoleView ? (
              <Eye className="w-3 h-3 text-sky-600 dark:text-sky-400 ml-0.5" />
            ) : (
              <EyeOff className="w-3 h-3 text-slate-400 ml-0.5" />
            )}
          </button>
        </div>

        {/* Right: Actions, Saved filters, Exports, Collapse button */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
          {savedFiltersList.length > 0 && (
            <select
              aria-label={getReportText('selectSavedFilter', language)}
              onChange={(e) => {
                const found = savedFiltersList.find((f) => f.id === e.target.value);
                if (found) {
                  onChangeFilter(found.filters);
                  showToast(
                    language === 'vi' ? 'Đã áp dụng' : language === 'ja' ? '適用完了' : 'Applied',
                    `${language === 'vi' ? 'Đã áp dụng bộ lọc: ' : language === 'ja' ? 'フィルターを適用しました: ' : 'Applied filter: '}${found.name}`
                  );
                }
              }}
              defaultValue=""
              className="text-xs bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-hidden hover:border-slate-300 dark:hover:border-slate-600 cursor-pointer shadow-2xs"
            >
              <option value="" disabled>
                {getReportText('savedFilters', language)} ({savedFiltersList.length})
              </option>
              {savedFiltersList.map((sf) => (
                <option key={sf.id} value={sf.id}>
                  {sf.name}
                </option>
              ))}
            </select>
          )}

          <button
            type="button"
            onClick={() => setSaveModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-750 text-xs font-medium shadow-2xs transition-colors"
            title={language === 'vi' ? 'Lưu các tiêu chí đang lọc' : language === 'ja' ? '現在のフィルター条件を保存' : 'Save current filters'}
          >
            <BookmarkPlus className="w-3.5 h-3.5 text-amber-500" />
            <span className="hidden sm:inline">{getReportText('saveFilter', language)}</span>
          </button>

          <button
            type="button"
            onClick={handleResetFilter}
            className="inline-flex items-center gap-1 px-2 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-750 text-xs font-medium transition-colors shadow-2xs"
            title={language === 'vi' ? 'Đặt lại các bộ lọc về mặc định' : language === 'ja' ? 'フィルターをリセット' : 'Reset filters to default'}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span className="hidden md:inline">{getReportText('resetFilter', language)}</span>
          </button>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-800 mx-0.5" />

          {/* Export buttons */}
          <button
            type="button"
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 text-xs font-semibold shadow-2xs transition-colors"
            title={language === 'vi' ? 'Xuất file bảng tính Excel' : language === 'ja' ? 'Excelスプレッドシートを出力' : 'Export Excel spreadsheet'}
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Excel</span>
          </button>

          <button
            type="button"
            onClick={handleExportPDF}
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-rose-200 dark:border-rose-800 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/60 text-xs font-semibold shadow-2xs transition-colors"
            title={language === 'vi' ? 'Xuất bản in / PDF' : language === 'ja' ? '印刷・PDF出力' : 'Print / Export PDF'}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>PDF</span>
          </button>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-800 mx-0.5" />

          {/* Collapse/Expand Toggle Button */}
          <button
            type="button"
            onClick={toggleCollapsed}
            className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              isCollapsed
                ? 'bg-[#002659] text-white hover:bg-[#001f4a] shadow-xs'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
            }`}
            title={
              isCollapsed
                ? (language === 'vi' ? 'Mở rộng bộ lọc' : language === 'ja' ? 'フィルターを展開' : 'Expand filters')
                : (language === 'vi' ? 'Thu nhỏ bộ lọc' : language === 'ja' ? 'フィルターを折りたたむ' : 'Collapse filters')
            }
          >
            {isCollapsed ? (
              <>
                <ChevronDown className="w-3.5 h-3.5" />
                <span>{language === 'vi' ? 'Mở rộng' : language === 'ja' ? '展開' : 'Expand'}</span>
              </>
            ) : (
              <>
                <ChevronUp className="w-3.5 h-3.5" />
                <span>{language === 'vi' ? 'Thu nhỏ' : language === 'ja' ? '折りたたむ' : 'Collapse'}</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 2. Compact View when Collapsed: Active Filters Quick Chips */}
      {isCollapsed && (
        <div className="px-3.5 py-2 sm:px-4 bg-white dark:bg-slate-900 flex items-center justify-between gap-2 flex-wrap text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-[11px] font-semibold text-slate-400 dark:text-slate-500 mr-1">
              {language === 'vi' ? 'Tiêu chí đang lọc:' : language === 'ja' ? '現在の絞り込み条件:' : 'Active filters:'}
            </span>

            {/* Date preset chip */}
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-[11px]">
              <Calendar className="w-3 h-3 text-sky-500" />
              {getPresetLabel(filter.dateRangePreset)}
            </span>

            {/* Team chip */}
            {selectedTeamName && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-[11px]">
                <Users className="w-3 h-3 text-indigo-500" />
                {translateEntityName(selectedTeamName, language)}
                <button
                  type="button"
                  onClick={() => onChangeFilter({ teamId: 'all' })}
                  className="hover:text-rose-500 ml-0.5 cursor-pointer"
                  title={language === 'vi' ? 'Bỏ lọc nhóm này' : language === 'ja' ? 'このチームの解除' : 'Remove team filter'}
                >
                  <X className="w-2.5 h-2.5" />
                </button>
              </span>
            )}

            {/* Rep chip */}
            {selectedRepName && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-[11px]">
                <User className="w-3 h-3 text-emerald-500" />
                {selectedRepName}
                <button
                  type="button"
                  onClick={() => onChangeFilter({ salesRepId: 'all' })}
                  className="hover:text-rose-500 ml-0.5 cursor-pointer"
                  title={language === 'vi' ? 'Bỏ lọc nhân viên này' : language === 'ja' ? 'この担当者の解除' : 'Remove rep filter'}
                >
                  <X className="w-2.5 h-2.5" />
                </button>
              </span>
            )}

            {/* Product chip */}
            {filter.productId !== 'all' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-[11px]">
                <Package className="w-3 h-3 text-amber-500" />
                {translateEntityName(filter.productId, language)}
                <button
                  type="button"
                  onClick={() => onChangeFilter({ productId: 'all' })}
                  className="hover:text-rose-500 ml-0.5 cursor-pointer"
                  title={language === 'vi' ? 'Bỏ lọc sản phẩm này' : language === 'ja' ? 'この製品の解除' : 'Remove product filter'}
                >
                  <X className="w-2.5 h-2.5" />
                </button>
              </span>
            )}

            {/* Region chip */}
            {filter.region !== 'all' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-[11px]">
                <MapPin className="w-3 h-3 text-rose-500" />
                {translateEntityName(filter.region, language)}
                <button
                  type="button"
                  onClick={() => onChangeFilter({ region: 'all' })}
                  className="hover:text-rose-500 ml-0.5 cursor-pointer"
                  title={language === 'vi' ? 'Bỏ lọc khu vực này' : language === 'ja' ? 'この地域の解除' : 'Remove region filter'}
                >
                  <X className="w-2.5 h-2.5" />
                </button>
              </span>
            )}

            {/* Source chip */}
            {filter.source !== 'all' && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium text-[11px]">
                <Tag className="w-3 h-3 text-purple-500" />
                {translateEntityName(filter.source, language)}
                <button
                  type="button"
                  onClick={() => onChangeFilter({ source: 'all' })}
                  className="hover:text-rose-500 ml-0.5 cursor-pointer"
                  title={language === 'vi' ? 'Bỏ lọc nguồn này' : language === 'ja' ? 'この獲得元の解除' : 'Remove source filter'}
                >
                  <X className="w-2.5 h-2.5" />
                </button>
              </span>
            )}
          </div>

          <button
            type="button"
            onClick={toggleCollapsed}
            className="text-xs text-sky-600 dark:text-sky-400 hover:underline font-semibold ml-auto cursor-pointer"
          >
            {language === 'vi' ? 'Chỉnh sửa bộ lọc →' : language === 'ja' ? 'フィルターを編集 →' : 'Edit filters →'}
          </button>
        </div>
      )}

      {/* 3. Expanded View: Full Filter Controls */}
      {!isCollapsed && (
        <div className="p-3.5 sm:p-4 space-y-3">
          {/* Optional: Role Perspective Selection (Removable / Dismissible) */}
          {showRoleView && (
            <div className="p-2.5 rounded-lg bg-sky-50/70 dark:bg-sky-950/30 border border-sky-100 dark:border-sky-900/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 transition-all animate-in fade-in">
              <div className="flex items-center gap-2 flex-wrap">
                <div className="flex items-center gap-1.5 text-xs text-sky-800 dark:text-sky-300 font-semibold">
                  <UserCheck className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                  <span>{language === 'vi' ? 'Quyền xem dữ liệu:' : language === 'ja' ? '閲覧権限:' : 'View Scope:'}</span>
                </div>
                <div className="inline-flex rounded-lg bg-white dark:bg-slate-800 p-0.5 text-xs shadow-2xs border border-sky-200/60 dark:border-sky-900/60">
                  <button
                    type="button"
                    onClick={() => onChangeFilter({ viewRole: 'director', teamId: 'all', salesRepId: 'all' })}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                      filter.viewRole === 'director'
                        ? 'bg-[#002659] text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {language === 'vi' ? 'Giám đốc (Toàn công ty)' : language === 'ja' ? '役員 (全社)' : 'Director (All)'}
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeFilter({ viewRole: 'manager', teamId: 'team-north', salesRepId: 'all' })}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                      filter.viewRole === 'manager'
                        ? 'bg-[#002659] text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {language === 'vi' ? 'Trưởng phòng (Theo nhóm)' : language === 'ja' ? 'マネージャー (チーム別)' : 'Manager (Team)'}
                  </button>
                  <button
                    type="button"
                    onClick={() => onChangeFilter({ viewRole: 'rep', salesRepId: 'rep-01', teamId: 'team-north' })}
                    className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                      filter.viewRole === 'rep'
                        ? 'bg-[#002659] text-white shadow-xs'
                        : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {language === 'vi' ? 'Nhân viên (Cá nhân)' : language === 'ja' ? '担当者 (個人)' : 'Staff (Personal)'}
                  </button>
                </div>
              </div>

              {/* Close/Remove Role View option */}
              <button
                type="button"
                onClick={() => toggleRoleView(false)}
                className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-500 dark:text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 self-end sm:self-auto transition-colors cursor-pointer"
                title={language === 'vi' ? 'Bỏ phần quyền xem dữ liệu này' : language === 'ja' ? '閲覧権限の表示を閉じる' : 'Hide role view option'}
              >
                <X className="w-3.5 h-3.5" />
                <span>{language === 'vi' ? 'Ẩn quyền xem' : language === 'ja' ? '非表示' : 'Hide'}</span>
              </button>
            </div>
          )}

          {/* Multi-dimension Filter Dropdowns Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2.5 sm:gap-3">
            {/* 1. Time Range Presets */}
            <div className="space-y-1">
              <label className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                <Calendar className="w-3 h-3 text-sky-500" />
                <span>{language === 'vi' ? 'Khoảng thời gian' : language === 'ja' ? '期間' : 'Time Range'}</span>
              </label>
              <select
                value={filter.dateRangePreset}
                onChange={(e) => onChangeFilter({ dateRangePreset: e.target.value as ReportDateRangePreset })}
                className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1.5 font-medium focus:ring-1 focus:ring-sky-500 focus:outline-hidden hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
              >
                <option value="today">{getReportText('presetToday', language)}</option>
                <option value="week">{getReportText('presetWeek', language)}</option>
                <option value="month">{getReportText('presetMonth', language)}</option>
                <option value="quarter">{getReportText('presetQuarter', language)}</option>
                <option value="year">{getReportText('presetYear', language)}</option>
                <option value="custom">{getReportText('presetCustom', language)}...</option>
              </select>
            </div>

            {/* 2. Nhóm Sales */}
            <div className="space-y-1">
              <label className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                <Users className="w-3 h-3 text-indigo-500" />
                <span>{getReportText('team', language)}</span>
              </label>
              <select
                value={filter.teamId}
                disabled={filter.viewRole === 'rep'}
                onChange={(e) => onChangeFilter({ teamId: e.target.value, salesRepId: 'all' })}
                className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1.5 font-medium focus:ring-1 focus:ring-sky-500 focus:outline-hidden disabled:opacity-50 hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
              >
                <option value="all">{language === 'vi' ? 'Tất cả nhóm' : language === 'ja' ? 'すべてのチーム' : 'All Teams'}</option>
                {MOCK_SALES_TEAMS.map((t) => (
                  <option key={t.id} value={t.id}>
                    {translateEntityName(t.name, language)}
                  </option>
                ))}
              </select>
            </div>

            {/* 3. Nhân viên phụ trách */}
            <div className="space-y-1">
              <label className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                <User className="w-3 h-3 text-emerald-500" />
                <span>{getReportText('rep', language)}</span>
              </label>
              <select
                value={filter.salesRepId}
                disabled={filter.viewRole === 'rep'}
                onChange={(e) => onChangeFilter({ salesRepId: e.target.value })}
                className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1.5 font-medium focus:ring-1 focus:ring-sky-500 focus:outline-hidden disabled:opacity-50 hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
              >
                <option value="all">{language === 'vi' ? 'Tất cả nhân viên' : language === 'ja' ? 'すべての担当者' : 'All Reps'}</option>
                {MOCK_SALES_REPS.filter((r) => filter.teamId === 'all' || r.teamId === filter.teamId).map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.name} ({translateEntityName(r.teamName, language).replace('Đội ', '')})
                  </option>
                ))}
              </select>
            </div>

            {/* 4. Sản phẩm / Dịch vụ */}
            <div className="space-y-1">
              <label className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                <Package className="w-3 h-3 text-amber-500" />
                <span>{getReportText('product', language)}</span>
              </label>
              <select
                value={filter.productId}
                onChange={(e) => onChangeFilter({ productId: e.target.value })}
                className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1.5 font-medium focus:ring-1 focus:ring-sky-500 focus:outline-hidden hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
              >
                <option value="all">{language === 'vi' ? 'Tất cả sản phẩm' : language === 'ja' ? 'すべての製品' : 'All Products'}</option>
                <option value="Gói Enterprise CRM">{translateEntityName('Gói Enterprise CRM', language)}</option>
                <option value="Giải pháp ERP Cloud">{translateEntityName('Giải pháp ERP Cloud', language)}</option>
                <option value="Module Kho Vận WMS">{translateEntityName('Module Kho Vận WMS', language)}</option>
                <option value="Dịch vụ Tích hợp API">{translateEntityName('Dịch vụ Tích hợp API', language)}</option>
                <option value="Cổng Portal B2B">{translateEntityName('Cổng Portal B2B', language)}</option>
                <option value="Gói Chăm sóc Khách hàng">{translateEntityName('Gói Chăm sóc Khách hàng', language)}</option>
              </select>
            </div>

            {/* 5. Khu vực địa lý */}
            <div className="space-y-1">
              <label className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                <MapPin className="w-3 h-3 text-rose-500" />
                <span>{getReportText('region', language)}</span>
              </label>
              <select
                value={filter.region}
                onChange={(e) => onChangeFilter({ region: e.target.value })}
                className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1.5 font-medium focus:ring-1 focus:ring-sky-500 focus:outline-hidden hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
              >
                <option value="all">{language === 'vi' ? 'Tất cả khu vực' : language === 'ja' ? 'すべての地域' : 'All Regions'}</option>
                <option value="Miền Bắc">{translateEntityName('Miền Bắc', language)}</option>
                <option value="Miền Trung">{translateEntityName('Miền Trung', language)}</option>
                <option value="Miền Nam">{translateEntityName('Miền Nam', language)}</option>
              </select>
            </div>

            {/* 6. Nguồn khách hàng / Lead Source */}
            <div className="space-y-1">
              <label className="flex items-center gap-1.5 text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                <Tag className="w-3 h-3 text-purple-500" />
                <span>{getReportText('source', language)}</span>
              </label>
              <select
                value={filter.source}
                onChange={(e) => onChangeFilter({ source: e.target.value })}
                className="w-full text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1.5 font-medium focus:ring-1 focus:ring-sky-500 focus:outline-hidden hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
              >
                <option value="all">{language === 'vi' ? 'Tất cả nguồn' : language === 'ja' ? 'すべての獲得元' : 'All Sources'}</option>
                <option value="Facebook">Facebook Ads</option>
                <option value="Zalo">Zalo OA</option>
                <option value="Website">Website Form</option>
                <option value="Giới thiệu">{language === 'vi' ? 'Khách giới thiệu' : language === 'ja' ? '顧客紹介' : 'Customer Referral'}</option>
                <option value="Hotline">{language === 'vi' ? 'Hotline / Tổng đài' : language === 'ja' ? '電話窓口' : 'Hotline'}</option>
                <option value="Triển lãm">{language === 'vi' ? 'Hội thảo & Triển lãm' : language === 'ja' ? '展示会・セミナー' : 'Exhibition & Seminar'}</option>
              </select>
            </div>
          </div>

          {/* Custom Date Range Picker when 'custom' is selected */}
          {filter.dateRangePreset === 'custom' && (
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center gap-3 flex-wrap text-xs">
              <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
                {language === 'vi' ? 'Khoảng ngày tùy chọn:' : language === 'ja' ? '日付範囲指定:' : 'Custom Date Range:'}
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={filter.customStartDate || ''}
                  onChange={(e) => onChangeFilter({ customStartDate: e.target.value })}
                  className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1 text-xs focus:ring-1 focus:ring-sky-500 focus:outline-hidden"
                />
                <span className="text-slate-400">{language === 'vi' ? 'đến' : language === 'ja' ? '〜' : 'to'}</span>
                <input
                  type="date"
                  value={filter.customEndDate || ''}
                  onChange={(e) => onChangeFilter({ customEndDate: e.target.value })}
                  className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 rounded-lg px-2.5 py-1 text-xs focus:ring-1 focus:ring-sky-500 focus:outline-hidden"
                />
              </div>
            </div>
          )}
        </div>
      )}

      {/* Save Filter Modal */}
      {saveModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-sm w-full p-5 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <BookmarkPlus className="w-5 h-5 text-amber-500" />
              {language === 'vi' ? 'Lưu mẫu bộ lọc' : language === 'ja' ? 'フィルター保存' : 'Save Filter Preset'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              {language === 'vi'
                ? 'Đặt tên cho cấu hình lọc hiện tại để tái sử dụng nhanh chóng trong tất cả các báo cáo Sales.'
                : language === 'ja'
                ? '現在のフィルター条件に名前を付けて保存し、各営業レポートで再利用できます。'
                : 'Name the current filter settings to quickly reuse across all sales reports.'}
            </p>
            <input
              type="text"
              placeholder={
                language === 'vi'
                  ? 'VD: Quý 4 - Khối Doanh nghiệp'
                  : language === 'ja'
                  ? '例: 第4四半期 - エンタープライズ'
                  : 'e.g., Q4 - Enterprise Corporate'
              }
              value={savedFilterName}
              onChange={(e) => setSavedFilterName(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white mb-4 focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
              autoFocus
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setSaveModalOpen(false)}
                className="px-3 py-1.5 text-xs font-medium rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                {language === 'vi' ? 'Hủy' : language === 'ja' ? 'キャンセル' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleSaveFilter}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001f4a] shadow-xs transition-colors cursor-pointer"
              >
                {getReportText('saveFilter', language)}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
