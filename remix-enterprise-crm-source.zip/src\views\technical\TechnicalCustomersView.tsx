import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useTechnical } from '../../context/TechnicalContext';
import { CustomerAccount } from '../../types/sales';
import { CustomerEquipment, CustomerSite } from '../../types/technical';
import {
  Users,
  Search,
  Building,
  Cpu,
  MapPin,
  Calendar,
  AlertTriangle,
  Plus,
  ShieldCheck,
  Wrench,
  FileText,
  Clock,
  ExternalLink,
  X,
  Phone,
  CheckCircle2,
  FolderOpen,
} from 'lucide-react';

export const TechnicalCustomersView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const { customers, contracts } = useSales();
  const {
    customerSites,
    customerEquipments,
    addCustomerSite,
    addCustomerEquipment,
    updateCustomerEquipmentStatus,
    warrantyTickets,
    projects,
  } = useTechnical();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [detailTab, setDetailTab] = useState<
    'overview' | 'sites' | 'equipments' | 'contracts' | 'maintenance' | 'tickets' | 'projects' | 'documents'
  >('overview');

  // Modals
  const [isAddSiteModalOpen, setIsAddSiteModalOpen] = useState(false);
  const [siteForm, setSiteForm] = useState({
    name: '',
    address: '',
    contactName: '',
    contactPhone: '',
    notes: '',
  });

  const [isAddEqModalOpen, setIsAddEqModalOpen] = useState(false);
  const [eqForm, setEqForm] = useState({
    sku: 'HPE-DL380-G10',
    productName: 'Máy chủ Server HPE ProLiant DL380 Gen10',
    serialNumber: '',
    siteName: 'Trụ sở chính',
    installedDate: new Date().toISOString().split('T')[0],
    warrantyStartDate: new Date().toISOString().split('T')[0],
    warrantyDurationMonths: 36,
    notes: '',
  });

  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId) || null;

  // Lọc danh sách khách hàng
  const filteredCustomers = customers.filter((c) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        c.code.toLowerCase().includes(q) ||
        c.name.toLowerCase().includes(q) ||
        c.taxId.toLowerCase().includes(q) ||
        c.phone.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Thiết bị của khách được chọn
  const customerEqList = customerEquipments.filter(
    (eq) => eq.customerId === selectedCustomerId
  );
  // Địa điểm của khách được chọn
  const customerSiteList = customerSites.filter(
    (s) => s.customerId === selectedCustomerId
  );
  // Hợp đồng của khách được chọn
  const customerContractList = contracts.filter(
    (ctr) => ctr.customerId === selectedCustomerId
  );
  // Sự cố của khách được chọn
  const customerTicketList = warrantyTickets.filter(
    (t) => t.customerId === selectedCustomerId
  );
  // Dự án của khách được chọn
  const customerProjList = projects.filter(
    (p) => p.customerId === selectedCustomerId
  );

  const handleCreateSite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomerId) return;
    addCustomerSite({
      customerId: selectedCustomerId,
      name: siteForm.name,
      address: siteForm.address,
      contactName: siteForm.contactName,
      contactPhone: siteForm.contactPhone,
      notes: siteForm.notes,
    });
    setIsAddSiteModalOpen(false);
    setSiteForm({ name: '', address: '', contactName: '', contactPhone: '', notes: '' });
  };

  const handleCreateEquipment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCustomer) return;
    const dur = Number(eqForm.warrantyDurationMonths) || 12;
    const sDate = eqForm.warrantyStartDate;
    const endYear = new Date(sDate).getFullYear() + Math.floor(dur / 12);
    const endDate = `${endYear}-${sDate.substring(5)}`;

    addCustomerEquipment({
      customerId: selectedCustomer.id,
      customerName: selectedCustomer.name,
      sku: eqForm.sku,
      productName: eqForm.productName,
      serialNumber: eqForm.serialNumber,
      siteName: eqForm.siteName,
      installedDate: eqForm.installedDate,
      warrantyStartDate: sDate,
      warrantyDurationMonths: dur,
      warrantyEndDate: endDate,
      status: 'Đang hoạt động',
      notes: eqForm.notes,
    });
    setIsAddEqModalOpen(false);
    setEqForm({
      sku: 'HPE-DL380-G10',
      productName: 'Máy chủ Server HPE ProLiant DL380 Gen10',
      serialNumber: '',
      siteName: 'Trụ sở chính',
      installedDate: new Date().toISOString().split('T')[0],
      warrantyStartDate: new Date().toISOString().split('T')[0],
      warrantyDurationMonths: 36,
      notes: '',
    });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50">
              <Users className="w-5 h-5" />
            </span>
            Hồ Sơ Khách Hàng (Góc nhìn Kỹ thuật)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Quản lý địa điểm công trình, cơ sở thiết bị đã lắp đặt, lịch bảo trì định kỳ và nhật ký sự cố theo từng khách hàng
          </p>
        </div>
      </div>

      {/* Main Grid: Danh sách khách hàng & Chi tiết kỹ thuật */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cột trái: Danh sách khách hàng */}
        <div className="lg:col-span-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col h-[750px] overflow-hidden">
          <div className="p-3.5 border-b border-slate-200 dark:border-slate-800">
            <div className="relative">
              <input
                type="text"
                placeholder="Tìm mã KH, tên công ty, SĐT..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
              />
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
            {filteredCustomers.map((cust) => {
              const eqCount = customerEquipments.filter((eq) => eq.customerId === cust.id).length;
              const openTickets = warrantyTickets.filter(
                (t) => t.customerId === cust.id && t.status !== 'Đã hoàn tất' && t.status !== 'Đóng'
              ).length;
              const isSelected = selectedCustomerId === cust.id;

              return (
                <div
                  key={cust.id}
                  onClick={() => setSelectedCustomerId(cust.id)}
                  className={`p-3.5 cursor-pointer transition-colors text-xs ${
                    isSelected
                      ? 'bg-sky-50/80 dark:bg-sky-950/40 border-l-4 border-sky-600'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-[10px] font-bold text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60 px-1.5 py-0.5 rounded">
                      {cust.code}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      {cust.type === 'Doanh nghiệp' ? 'B2B' : 'B2C'}
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-900 dark:text-white line-clamp-1 mb-1.5">
                    {cust.name}
                  </h3>

                  <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                    <span className="flex items-center gap-1">
                      <Cpu className="w-3.5 h-3.5 text-slate-400" />
                      {eqCount} thiết bị
                    </span>
                    {openTickets > 0 ? (
                      <span className="flex items-center gap-1 text-rose-600 dark:text-rose-400 font-bold">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        {openTickets} sự cố
                      </span>
                    ) : (
                      <span className="text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Ổn định
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Cột phải: Chi tiết 360 độ Kỹ thuật của Khách hàng */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col h-[750px] overflow-hidden">
          {selectedCustomer ? (
            <>
              {/* Header chi tiết khách */}
              <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-xs font-mono font-bold bg-sky-100 dark:bg-sky-900 text-sky-700 dark:text-sky-300 px-2 py-0.5 rounded">
                      {selectedCustomer.code}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">MST: {selectedCustomer.taxId}</span>
                  </div>
                  <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                    {selectedCustomer.name}
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 flex items-center gap-2">
                    <span>{selectedCustomer.billingAddress || selectedCustomer.shippingAddresses?.[0] || 'Địa chỉ doanh nghiệp'}</span>
                    <span>&bull;</span>
                    <span>SĐT: {selectedCustomer.phone}</span>
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => setIsAddSiteModalOpen(true)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <MapPin className="w-3.5 h-3.5 text-sky-600" />
                    <span>+ Thêm địa điểm</span>
                  </button>
                  <button
                    onClick={() => setIsAddEqModalOpen(true)}
                    className="px-2.5 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold flex items-center gap-1.5 shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Gán thiết bị</span>
                  </button>
                </div>
              </div>

              {/* Tabs Switcher */}
              <div className="flex items-center gap-1 overflow-x-auto px-4 border-b border-slate-200 dark:border-slate-800 bg-slate-100/50 dark:bg-slate-950/40 text-xs scrollbar-none">
                {[
                  { id: 'overview', label: 'Tổng quan' },
                  { id: 'sites', label: `Địa điểm (${customerSiteList.length})` },
                  { id: 'equipments', label: `Thiết bị (${customerEqList.length})` },
                  { id: 'contracts', label: `Hợp đồng (${customerContractList.length})` },
                  { id: 'tickets', label: `Sự cố & BH (${customerTicketList.length})` },
                  { id: 'projects', label: `Dự án (${customerProjList.length})` },
                  { id: 'documents', label: 'Tài liệu / Bản vẽ' },
                ].map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setDetailTab(t.id as any)}
                    className={`py-2.5 px-3 font-semibold whitespace-nowrap border-b-2 transition-colors ${
                      detailTab === t.id
                        ? 'border-sky-600 text-sky-600 dark:text-sky-400 bg-white dark:bg-slate-900'
                        : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-white'
                    }`}
                  >
                    {t.label}
                  </button>
                ))}
              </div>

              {/* Tab Contents */}
              <div className="flex-1 overflow-y-auto p-4 sm:p-5 text-xs">
                {/* 1. Tổng quan */}
                {detailTab === 'overview' && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 block text-[11px]">Thiết bị quản lý</span>
                        <span className="text-lg font-bold text-slate-900 dark:text-white font-mono">
                          {customerEqList.length}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 block text-[11px]">Địa điểm / Công trình</span>
                        <span className="text-lg font-bold text-slate-900 dark:text-white font-mono">
                          {customerSiteList.length}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 block text-[11px]">Hợp đồng hiệu lực</span>
                        <span className="text-lg font-bold text-sky-600 dark:text-sky-400 font-mono">
                          {customerContractList.length}
                        </span>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                        <span className="text-slate-400 block text-[11px]">Sự cố mở</span>
                        <span className="text-lg font-bold text-rose-600 dark:text-rose-400 font-mono">
                          {customerTicketList.filter((t) => t.status !== 'Đã hoàn tất').length}
                        </span>
                      </div>
                    </div>

                    <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-2">
                      <h4 className="font-bold text-slate-800 dark:text-slate-200">Ghi chú kỹ thuật đặc thù:</h4>
                      <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
                        Khách hàng yêu cầu toàn bộ kỹ sư vào công trình phải mang đầy đủ bảo hộ lao động (mũ, áo phản quang, giày mũi thép). Thiết bị máy chủ và mạng hoạt động 24/7, mọi thao tác bảo trì cần thực hiện ngoài giờ hành chính (sau 19:00 thứ Bảy).
                      </p>
                    </div>
                  </div>
                )}

                {/* 2. Địa điểm / Công trình */}
                {detailTab === 'sites' && (
                  <div className="space-y-3">
                    {customerSiteList.length === 0 ? (
                      <p className="text-slate-400 italic">Chưa có thông tin địa điểm/công trình.</p>
                    ) : (
                      customerSiteList.map((site) => (
                        <div
                          key={site.id}
                          className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-1.5"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                              <MapPin className="w-3.5 h-3.5 text-sky-600" />
                              {site.name}
                            </h4>
                            <span className="text-[11px] text-slate-500 flex items-center gap-1">
                              <Phone className="w-3 h-3 text-slate-400" />
                              {site.contactPhone} ({site.contactName})
                            </span>
                          </div>
                          <p className="text-slate-600 dark:text-slate-400 text-[11px]">{site.address}</p>
                          {site.notes && (
                            <p className="text-slate-500 italic text-[11px]">Lưu ý: {site.notes}</p>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* 3. Thiết bị của khách */}
                {detailTab === 'equipments' && (
                  <div className="space-y-3">
                    {customerEqList.length === 0 ? (
                      <p className="text-slate-400 italic">Chưa có thiết bị nào được gán cho khách hàng này.</p>
                    ) : (
                      <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300">
                            <tr>
                              <th className="p-2.5">Sản Phẩm &amp; Serial</th>
                              <th className="p-2.5">Địa Điểm</th>
                              <th className="p-2.5">Hạn Bảo Hành</th>
                              <th className="p-2.5">Trạng Thái</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                            {customerEqList.map((eq) => (
                              <tr key={eq.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                                <td className="p-2.5">
                                  <div className="font-bold text-slate-900 dark:text-white">{eq.productName}</div>
                                  <div className="font-mono text-[10px] text-slate-400">
                                    SKU: {eq.sku} | SN: {eq.serialNumber || 'N/A'}
                                  </div>
                                </td>
                                <td className="p-2.5 text-slate-600 dark:text-slate-400">{eq.siteName}</td>
                                <td className="p-2.5 font-mono">
                                  <div>{eq.warrantyEndDate}</div>
                                  <span className="text-[10px] text-slate-400">({eq.warrantyDurationMonths} tháng)</span>
                                </td>
                                <td className="p-2.5">
                                  <span
                                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                      eq.status === 'Đang hoạt động'
                                        ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                                        : eq.status === 'Đang sửa/bảo hành'
                                        ? 'bg-amber-100 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300'
                                        : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                                    }`}
                                  >
                                    {eq.status}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                )}

                {/* 4. Hợp đồng */}
                {detailTab === 'contracts' && (
                  <div className="space-y-3">
                    {customerContractList.map((ctr) => (
                      <div
                        key={ctr.id}
                        className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-sky-600">{ctr.contractNumber}</span>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                              {ctr.status}
                            </span>
                          </div>
                          <h4 className="font-bold text-slate-800 dark:text-slate-200 mt-1">{ctr.title}</h4>
                          <span className="text-slate-400 text-[11px]">
                            Hiệu lực: {ctr.startDate} &rarr; {ctr.endDate}
                          </span>
                        </div>
                        <button
                          onClick={() => setActiveModule('technical-contracts')}
                          className="px-2.5 py-1 text-[11px] font-semibold text-sky-600 hover:bg-sky-50 rounded-lg flex items-center gap-1"
                        >
                          <span>Xem chi tiết</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* 5. Sự cố & Bảo hành */}
                {detailTab === 'tickets' && (
                  <div className="space-y-3">
                    {customerTicketList.length === 0 ? (
                      <p className="text-slate-400 italic">Không có sự cố nào đang mở.</p>
                    ) : (
                      customerTicketList.map((ticket) => (
                        <div
                          key={ticket.id}
                          className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-1.5"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-mono font-bold text-rose-600">{ticket.code}</span>
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">
                              {ticket.status}
                            </span>
                          </div>
                          <h4 className="font-bold text-slate-800 dark:text-slate-200">{ticket.equipmentName}</h4>
                          <p className="text-slate-600 dark:text-slate-400 text-[11px]">{ticket.symptoms}</p>
                          <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-200 dark:border-slate-700 flex justify-between">
                            <span>Phụ trách: {ticket.assignedStaff}</span>
                            <span>Ngày báo: {ticket.issueDate}</span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                )}

                {/* 6. Dự án */}
                {detailTab === 'projects' && (
                  <div className="space-y-3">
                    {customerProjList.map((p) => (
                      <div
                        key={p.id}
                        className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-mono font-bold text-sky-600">{p.code}</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-700">
                            {p.status}
                          </span>
                        </div>
                        <h4 className="font-bold text-slate-800 dark:text-slate-200">{p.title}</h4>
                        <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                          <div
                            className="bg-sky-600 h-full rounded-full transition-all"
                            style={{ width: `${p.progressPercent}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-[11px] text-slate-400">
                          <span>Tiến độ: {p.progressPercent}%</span>
                          <span>Trưởng dự án: {p.projectManager}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* 7. Tài liệu */}
                {detailTab === 'documents' && (
                  <div className="space-y-2">
                    {[
                      { name: 'So_do_ha_tang_mang_LAN_2026.pdf', size: '2.4 MB', date: '2026-01-15' },
                      { name: 'Ban_ve_mat_bang_phong_may_chu.dwg', size: '5.1 MB', date: '2026-02-10' },
                      { name: 'Bien_ban_kiem_dinh_dien_ap_UPS.pdf', size: '1.2 MB', date: '2026-03-01' },
                    ].map((doc, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between hover:bg-slate-50"
                      >
                        <div className="flex items-center gap-2">
                          <FileText className="w-4 h-4 text-sky-600" />
                          <span className="font-semibold text-slate-800 dark:text-slate-200">{doc.name}</span>
                        </div>
                        <span className="text-[11px] text-slate-400">{doc.size}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-400 p-8 text-center">
              <Building className="w-12 h-12 text-slate-300 dark:text-slate-700 mb-3" />
              <p className="font-medium text-sm">Chọn một khách hàng từ danh sách bên trái để xem hồ sơ kỹ thuật 360 độ</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal: Thêm Địa điểm / Công trình */}
      {isAddSiteModalOpen && selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Thêm Địa Điểm / Công Trình Mới
              </h3>
              <button onClick={() => setIsAddSiteModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleCreateSite} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Tên địa điểm / Công trình *</label>
                <input
                  type="text"
                  required
                  placeholder="Ví dụ: Tòa nhà Keangnam Tầng 12"
                  value={siteForm.name}
                  onChange={(e) => setSiteForm({ ...siteForm, name: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Địa chỉ chi tiết *</label>
                <input
                  type="text"
                  required
                  placeholder="Số nhà, đường, quận/huyện, tỉnh/thành"
                  value={siteForm.address}
                  onChange={(e) => setSiteForm({ ...siteForm, address: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Người liên hệ</label>
                  <input
                    type="text"
                    placeholder="Họ tên người phụ trách tại điểm"
                    value={siteForm.contactName}
                    onChange={(e) => setSiteForm({ ...siteForm, contactName: e.target.value })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Số điện thoại</label>
                  <input
                    type="text"
                    placeholder="09xx..."
                    value={siteForm.contactPhone}
                    onChange={(e) => setSiteForm({ ...siteForm, contactPhone: e.target.value })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Ghi chú lưu ý tiếp cận</label>
                <textarea
                  rows={2}
                  placeholder="Thang máy chở hàng, bảo vệ, thủ tục ra vào..."
                  value={siteForm.notes}
                  onChange={(e) => setSiteForm({ ...siteForm, notes: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddSiteModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-sky-600 text-white font-semibold shadow-xs"
                >
                  Lưu địa điểm
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Gán Thiết bị Khách hàng */}
      {isAddEqModalOpen && selectedCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-md w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Gán Thiết Bị Mới Vào Hồ Sơ Khách Hàng
              </h3>
              <button onClick={() => setIsAddEqModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>
            <form onSubmit={handleCreateEquipment} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Tên thiết bị &amp; Model *</label>
                <input
                  type="text"
                  required
                  value={eqForm.productName}
                  onChange={(e) => setEqForm({ ...eqForm, productName: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Mã SKU</label>
                  <input
                    type="text"
                    value={eqForm.sku}
                    onChange={(e) => setEqForm({ ...eqForm, sku: e.target.value })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Số Serial (S/N)</label>
                  <input
                    type="text"
                    placeholder="SGH2148X..."
                    value={eqForm.serialNumber}
                    onChange={(e) => setEqForm({ ...eqForm, serialNumber: e.target.value })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Vị trí / Địa điểm lắp đặt</label>
                <input
                  type="text"
                  value={eqForm.siteName}
                  onChange={(e) => setEqForm({ ...eqForm, siteName: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Ngày bắt đầu BH</label>
                  <input
                    type="date"
                    value={eqForm.warrantyStartDate}
                    onChange={(e) => setEqForm({ ...eqForm, warrantyStartDate: e.target.value })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Thời hạn BH (Tháng)</label>
                  <input
                    type="number"
                    value={eqForm.warrantyDurationMonths}
                    onChange={(e) => setEqForm({ ...eqForm, warrantyDurationMonths: Number(e.target.value) })}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Ghi chú cấu hình</label>
                <textarea
                  rows={2}
                  placeholder="IP tĩnh, mật khẩu truy cập, cổng kết nối..."
                  value={eqForm.notes}
                  onChange={(e) => setEqForm({ ...eqForm, notes: e.target.value })}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddEqModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-sky-600 text-white font-semibold shadow-xs"
                >
                  Lưu thiết bị
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
