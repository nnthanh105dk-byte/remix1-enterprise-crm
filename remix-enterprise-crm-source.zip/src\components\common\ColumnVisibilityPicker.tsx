import React, { useState, useRef, useEffect } from 'react';
import { SlidersHorizontal, Check, RotateCcw, CheckSquare, ChevronDown } from 'lucide-react';
import { ColumnDef } from '../../hooks/useColumnVisibility';

export interface ColumnVisibilityPickerProps {
  columns: ColumnDef[];
  visibleColumns: Record<string, boolean>;
  onToggleColumn?: (columnId: string) => void;
  onToggle?: (columnId: string) => void;
  onSelectAll?: () => void;
  onReset?: () => void;
  buttonLabel?: string;
  className?: string;
}

export const ColumnVisibilityPicker: React.FC<ColumnVisibilityPickerProps> = ({
  columns,
  visibleColumns,
  onToggleColumn,
  onToggle,
  onSelectAll,
  onReset,
  buttonLabel = 'Tùy chọn cột',
  className = '',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const toggleFn = onToggle || onToggleColumn || (() => {});

  // Close when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const visibleCount = columns.filter((col) => visibleColumns[col.id] !== false).length;
  const totalCount = columns.length;

  return (
    <div className={`relative inline-block text-xs ${className}`} ref={containerRef}>
      {/* Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen((prev) => !prev)}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700/60 font-medium transition-colors shadow-2xs"
        title="Tùy chọn hiển thị các cột dữ liệu"
      >
        <SlidersHorizontal className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
        <span>{buttonLabel}</span>
        <span className="px-1.5 py-0.2 rounded-full bg-slate-100 dark:bg-slate-700 text-[10px] font-bold text-sky-600 dark:text-sky-400">
          {visibleCount}/{totalCount}
        </span>
        <ChevronDown className="w-3 h-3 text-slate-400 ml-0.5" />
      </button>

      {/* Dropdown Popover */}
      {isOpen && (
        <div className="absolute right-0 mt-1.5 w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl z-50 overflow-hidden animate-in fade-in duration-150">
          {/* Header */}
          <div className="px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <span className="font-semibold text-slate-800 dark:text-white text-xs">
              Hiển thị cột ({visibleCount}/{totalCount})
            </span>
            <div className="flex items-center gap-2">
              {onSelectAll && (
                <button
                  type="button"
                  onClick={onSelectAll}
                  className="text-[11px] text-sky-600 dark:text-sky-400 hover:underline flex items-center gap-0.5"
                  title="Hiện tất cả các cột"
                >
                  <CheckSquare className="w-3 h-3" />
                  <span>Tất cả</span>
                </button>
              )}
              {onReset && (
                <button
                  type="button"
                  onClick={onReset}
                  className="text-[11px] text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-0.5"
                  title="Đặt lại về mặc định"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Mặc định</span>
                </button>
              )}
            </div>
          </div>

          {/* Column Checkboxes List */}
          <div className="p-2 max-h-72 overflow-y-auto space-y-1">
            {columns.map((col) => {
              const isChecked = visibleColumns[col.id] !== false;
              const isRequired = !!col.required;

              return (
                <label
                  key={col.id}
                  className={`flex items-center gap-2 px-2 py-1.5 rounded-lg text-xs transition-colors select-none ${
                    isRequired
                      ? 'text-slate-400 dark:text-slate-500 cursor-not-allowed bg-slate-50/50 dark:bg-slate-800/30'
                      : 'hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer text-slate-700 dark:text-slate-200'
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={isChecked}
                    disabled={isRequired}
                    onChange={() => toggleFn(col.id)}
                    className="w-3.5 h-3.5 rounded border-slate-300 dark:border-slate-600 text-sky-600 focus:ring-sky-500 focus:ring-1"
                  />
                  <span className="flex-1 font-medium truncate">{col.label}</span>
                  {isRequired && (
                    <span className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded font-mono">
                      Cố định
                    </span>
                  )}
                </label>
              );
            })}
          </div>

          {/* Footer note */}
          <div className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 text-center">
            Cấu hình được lưu tự động trên trình duyệt
          </div>
        </div>
      )}
    </div>
  );
};
