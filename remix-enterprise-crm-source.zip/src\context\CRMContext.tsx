import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  Tenant,
  User,
  UserRole,
  LanguageCode,
  ThemePreset,
  ActiveModule,
  PermissionAction,
  RolePermissionConfig,
  Lead,
  Contact,
  Opportunity,
  OpportunityStage,
  Quotation,
  Contract,
  Ticket,
  Product,
  InventoryTransaction,
  AuditLog,
  ActivityLog,
  NotificationItem,
  CustomThemeSettings,
  OKRObjective,
  KeyResult,
  OKRTargetConfig,
  ThemeMode,
  AccentColor,
  FontSizePreference,
  TableDensityPreference,
  ProfileTab,
  UserPreferences,
} from '../types/crm';
import { useMultiTenant } from './MultiTenantContext';
import {
  INITIAL_TENANTS,
  INITIAL_ROLE_PERMISSIONS,
  INITIAL_USERS,
  INITIAL_LEADS,
  INITIAL_CONTACTS,
  INITIAL_OPPORTUNITIES,
  INITIAL_QUOTATIONS,
  INITIAL_CONTRACTS,
  INITIAL_TICKETS,
  INITIAL_PRODUCTS,
  INITIAL_STOCK_TRANSACTIONS,
  INITIAL_AUDIT_LOGS,
  INITIAL_ACTIVITY_LOGS,
  INITIAL_NOTIFICATIONS,
  INITIAL_OKR_TARGETS,
  INITIAL_OKR_OBJECTIVES,
} from '../data/mockData';
import { translations, Dictionary } from '../i18n/translations';
import { THEME_PRESETS, DEFAULT_CUSTOM_SETTINGS, ThemeDefinition } from '../theme/themeEngine';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message: string;
}

interface CRMContextType {
  // Tenant
  tenants: Tenant[];
  currentTenant: Tenant;
  setCurrentTenantId: (id: string) => void;
  updateCurrentTenant: (updated: Partial<Tenant>) => void;

  // Role & Current User
  currentRole: UserRole;
  setCurrentRole: (role: UserRole) => void;
  currentUser: User;
  switchDemoUser: (userIdOrRole: string) => void;
  hasPermission: (module: ActiveModule, action: PermissionAction) => boolean;
  rolePermissions: RolePermissionConfig[];
  updateRolePermission: (role: UserRole, module: ActiveModule, action: PermissionAction, enable: boolean) => void;

  // Navigation
  activeModule: ActiveModule;
  setActiveModule: (mod: ActiveModule) => void;
  sidebarCollapsed: boolean;
  setSidebarCollapsed: React.Dispatch<React.SetStateAction<boolean>>;
  toggleSidebarCollapsed: () => void;

  // i18n
  language: LanguageCode;
  setLanguage: (lang: LanguageCode) => void;
  t: Dictionary;

  // Theme & Appearance
  theme: ThemePreset;
  setTheme: (theme: ThemePreset) => void;
  isDarkMode: boolean;
  setIsDarkMode: (dark: boolean) => void;
  themeMode: ThemeMode;
  setThemeMode: (mode: ThemeMode) => void;
  themeDef: ThemeDefinition;
  customTheme: CustomThemeSettings;
  setCustomTheme: React.Dispatch<React.SetStateAction<CustomThemeSettings>>;

  // User Profile & Preferences
  currentDocCode: string | null;
  setCurrentDocCode: (code: string | null) => void;
  profileActiveTab: ProfileTab;
  setProfileActiveTab: (tab: ProfileTab) => void;
  userPreferences: UserPreferences;
  updateUserPreferences: (prefs: Partial<UserPreferences>) => void;
  updateCurrentUser: (updates: Partial<User>) => void;

  // Search
  recentSearches: string[];
  addRecentSearch: (query: string) => void;
  clearRecentSearches: () => void;

  // Data Collections
  leads: Lead[];
  addLead: (lead: Omit<Lead, 'id' | 'createdAt' | 'updatedAt' | 'code' | 'tenantId'>) => void;
  updateLead: (id: string, updated: Partial<Lead>) => void;
  deleteLead: (id: string) => void;
  convertLeadToOpportunity: (leadId: string) => void;

  contacts: Contact[];
  addContact: (contact: Omit<Contact, 'id' | 'createdAt' | 'code' | 'tenantId'>) => void;
  updateContact: (id: string, updated: Partial<Contact>) => void;
  deleteContact: (id: string) => void;

  opportunities: Opportunity[];
  addOpportunity: (opp: Omit<Opportunity, 'id' | 'createdAt' | 'code' | 'tenantId'>) => void;
  updateOpportunityStage: (id: string, stage: OpportunityStage) => void;
  updateOpportunity: (id: string, updated: Partial<Opportunity>) => void;
  deleteOpportunity: (id: string) => void;

  quotations: Quotation[];
  addQuotation: (quote: Omit<Quotation, 'id' | 'createdAt' | 'code' | 'tenantId'>) => void;
  updateQuotationStatus: (id: string, status: Quotation['status']) => void;
  deleteQuotation: (id: string) => void;

  contracts: Contract[];
  addContract: (cnt: Omit<Contract, 'id' | 'createdAt' | 'tenantId'>) => void;
  toggleMilestonePaid: (contractId: string, milestoneIndex: number) => void;
  deleteContract: (id: string) => void;

  tickets: Ticket[];
  addTicket: (t: Omit<Ticket, 'id' | 'createdAt' | 'updatedAt' | 'ticketNumber' | 'tenantId'>) => void;
  resolveTicket: (id: string, csatScore?: number) => void;
  deleteTicket: (id: string) => void;

  products: Product[];
  addProduct: (prod: Omit<Product, 'id' | 'tenantId'>) => void;
  deleteProduct: (id: string) => void;

  stockTransactions: InventoryTransaction[];
  addStockMovement: (
    type: InventoryTransaction['type'],
    warehouse: InventoryTransaction['warehouse'],
    productId: string,
    quantity: number,
    reason: string
  ) => void;

  users: User[];
  addUser: (user: Omit<User, 'id' | 'createdAt' | 'lastLogin' | 'tenantId'>) => void;
  updateUserStatus: (id: string, status: User['status']) => void;
  deleteUser: (id: string) => void;

  notifications: NotificationItem[];
  unreadNotificationCount: number;
  addNotification: (item: Omit<NotificationItem, 'id' | 'createdAt' | 'read' | 'timestamp'> & { timestamp?: string }) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;

  auditLogs: AuditLog[];
  activityLogs: ActivityLog[];

  // Global Modals
  commandPaletteOpen: boolean;
  setCommandPaletteOpen: (open: boolean) => void;

  // Screen Specification Inspector
  inspectingScreenCode: string | null;
  openScreenSpec: (screenCode: string) => void;
  closeScreenSpec: () => void;

  // Toast
  toasts: ToastMessage[];
  showToast: (title: string, message: string, type?: ToastMessage['type']) => void;
  dismissToast: (id: string) => void;

  // OKR & Period Targets
  okrObjectives: OKRObjective[];
  periodTargets: OKRTargetConfig[];
  selectedOKRPeriod: string;
  setSelectedOKRPeriod: (period: string) => void;
  updatePeriodTarget: (config: OKRTargetConfig) => void;
  addOKRObjective: (obj: Omit<OKRObjective, 'id' | 'code'>) => void;
  updateOKRObjective: (id: string, updated: Partial<OKRObjective>) => void;
  deleteOKRObjective: (id: string) => void;
  addKeyResult: (objectiveId: string, kr: Omit<KeyResult, 'id'>) => void;
  updateKeyResult: (objectiveId: string, krId: string, updated: Partial<KeyResult>) => void;
  deleteKeyResult: (objectiveId: string, krId: string) => void;
  getActualMetric: (syncKey: 'revenue' | 'pipeline' | 'leads' | 'conversion' | 'won_deals' | 'open_deals') => number;
}

const CRMContext = createContext<CRMContextType | undefined>(undefined);

export const CRMProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Tenant
  const [tenants, setTenants] = useState<Tenant[]>(INITIAL_TENANTS);
  const [currentTenantId, setCurrentTenantId] = useState<string>('tenant-vingroup');

  // Multi-Tenant User Sync
  const { currentAccount, currentCompany, currentMember } = useMultiTenant();

  // Role & Current User State
  const [currentUserId, setCurrentUserId] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('crm_current_user_id');
      if (saved) return saved;
    } catch (e) {}
    return 'usr-1';
  });

  const [currentRole, setCurrentRole] = useState<UserRole>(() => {
    try {
      const saved = localStorage.getItem('crm_current_role') as UserRole;
      if (saved) return saved;
    } catch (e) {}
    return 'Super Admin';
  });

  const [rolePermissions, setRolePermissions] = useState<RolePermissionConfig[]>(INITIAL_ROLE_PERMISSIONS);

  // Navigation
  const [activeModule, setActiveModule] = useState<ActiveModule>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(false);

  const toggleSidebarCollapsed = () => {
    setSidebarCollapsed((prev) => !prev);
  };

  // User Profile & Preferences State
  const DEFAULT_USER_PREFERENCES: UserPreferences = {
    themeMode: 'light',
    accentColor: 'amber',
    fontSize: 'medium',
    tableDensity: 'normal',
    defaultSidebarOpen: true,
    startupPage: 'dashboard',
    rowsPerPage: 25,
    dateFormat: 'DD/MM/YYYY',
    numberFormat: 'vi-VN',
    timezone: 'Asia/Ho_Chi_Minh (GMT+7)',
    language: 'vi',
    notificationChannels: {
      ordersAndApprovals: true,
      shippingAndLogistics: true,
      warehouseAndInventory: true,
      technicalAndWarranty: true,
      debtsAndPayments: true,
      hrAndStaff: true,
      systemAlerts: true,
      showBadgeOnBell: true,
      playSound: false,
    },
  };

  const [userPreferences, setUserPreferences] = useState<UserPreferences>(() => {
    try {
      const saved = localStorage.getItem('crm_user_preferences');
      if (saved) return { ...DEFAULT_USER_PREFERENCES, ...JSON.parse(saved) };
    } catch (e) {
      // ignore
    }
    return DEFAULT_USER_PREFERENCES;
  });

  const [themeMode, setThemeModeState] = useState<ThemeMode>(userPreferences.themeMode || 'light');
  const [currentDocCode, setCurrentDocCode] = useState<string | null>(null);
  const [profileActiveTab, setProfileActiveTab] = useState<ProfileTab>('personal');

  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('crm_recent_searches');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    return ['KH-0042', 'BG-2026-0090', 'Tập đoàn Vingroup', 'Cảm biến LoRaWAN'];
  });

  const addRecentSearch = (query: string) => {
    const trimmed = query.trim();
    if (!trimmed) return;
    setRecentSearches((prev) => {
      const filtered = prev.filter((item) => item.toLowerCase() !== trimmed.toLowerCase());
      const updated = [trimmed, ...filtered].slice(0, 10);
      try {
        localStorage.setItem('crm_recent_searches', JSON.stringify(updated));
      } catch (e) {
        // ignore
      }
      return updated;
    });
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    try {
      localStorage.removeItem('crm_recent_searches');
    } catch (e) {
      // ignore
    }
  };

  // i18n
  const [language, setLanguageState] = useState<LanguageCode>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('crm_language') as LanguageCode;
        if (saved && (saved === 'vi' || saved === 'en' || saved === 'ja')) return saved;
        const savedPrefs = localStorage.getItem('crm_user_preferences');
        if (savedPrefs) {
          const parsed = JSON.parse(savedPrefs);
          if (parsed.language && (parsed.language === 'vi' || parsed.language === 'en' || parsed.language === 'ja')) {
            return parsed.language;
          }
        }
      } catch (e) {}
    }
    return 'vi';
  });

  const setLanguage = (newLang: LanguageCode) => {
    setLanguageState(newLang);
    try {
      localStorage.setItem('crm_language', newLang);
    } catch (e) {}
    updateUserPreferences({ language: newLang });
  };

  const updateUserPreferences = (prefs: Partial<UserPreferences>) => {
    setUserPreferences((prev) => {
      const updated = { ...prev, ...prefs };
      if (prefs.themeMode && prefs.themeMode !== prev.themeMode) {
        setThemeModeState(prefs.themeMode);
      }
      if (prefs.language && prefs.language !== language) {
        setLanguageState(prefs.language);
        try {
          localStorage.setItem('crm_language', prefs.language);
        } catch (e) {}
      }
      try {
        localStorage.setItem('crm_user_preferences', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  const setThemeMode = (mode: ThemeMode) => {
    setThemeModeState(mode);
    updateUserPreferences({ themeMode: mode });
  };

  // Theme
  const [theme, setThemeState] = useState<ThemePreset>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('crm_theme_preset') as ThemePreset;
        if (saved && THEME_PRESETS[saved]) return saved;
      } catch (e) {}
    }
    return 'corporate-blue';
  });

  const setTheme = (newTheme: ThemePreset) => {
    setThemeState(newTheme);
    try {
      localStorage.setItem('crm_theme_preset', newTheme);
    } catch (e) {}
    if (newTheme === 'modern-dark') {
      setIsDarkMode(true);
    } else {
      setIsDarkMode(false);
    }
  };

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      try {
        const saved = localStorage.getItem('crm_theme_preset');
        return saved === 'modern-dark';
      } catch (e) {}
    }
    return false;
  });
  const [customTheme, setCustomTheme] = useState<CustomThemeSettings>(DEFAULT_CUSTOM_SETTINGS);

  // Theme mode reactive effect
  useEffect(() => {
    const applyMode = (mode: ThemeMode) => {
      let isDark = false;
      if (mode === 'dark') {
        isDark = true;
      } else if (mode === 'light') {
        isDark = false;
      } else {
        isDark = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
      }

      setIsDarkMode(isDark);
      if (isDark) {
        setThemeState('modern-dark');
      } else {
        const saved = (typeof window !== 'undefined' && localStorage.getItem('crm_theme_preset')) as ThemePreset;
        if (saved && saved !== 'modern-dark' && THEME_PRESETS[saved]) {
          setThemeState(saved);
        } else {
          setThemeState('corporate-blue');
        }
      }
    };

    applyMode(themeMode);

    if (themeMode === 'system' && typeof window !== 'undefined' && window.matchMedia) {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const handler = () => applyMode('system');
      mediaQuery.addEventListener('change', handler);
      return () => mediaQuery.removeEventListener('change', handler);
    }
  }, [themeMode]);

  // Apply accent color, font size, table density to root
  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.setAttribute('data-accent', userPreferences.accentColor);
      document.documentElement.setAttribute('data-font-size', userPreferences.fontSize);
      document.documentElement.setAttribute('data-density', userPreferences.tableDensity);
    }
  }, [userPreferences.accentColor, userPreferences.fontSize, userPreferences.tableDensity]);

  // Collections
  const [leads, setLeads] = useState<Lead[]>(INITIAL_LEADS);
  const [contacts, setContacts] = useState<Contact[]>(INITIAL_CONTACTS);
  const [opportunities, setOpportunities] = useState<Opportunity[]>(INITIAL_OPPORTUNITIES);
  const [quotations, setQuotations] = useState<Quotation[]>(INITIAL_QUOTATIONS);
  const [contracts, setContracts] = useState<Contract[]>(INITIAL_CONTRACTS);
  const [tickets, setTickets] = useState<Ticket[]>(INITIAL_TICKETS);
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [stockTransactions, setStockTransactions] = useState<InventoryTransaction[]>(INITIAL_STOCK_TRANSACTIONS);
  const [users, setUsers] = useState<User[]>(INITIAL_USERS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(INITIAL_ACTIVITY_LOGS);

  // Update current user record (shared with Employee)
  const updateCurrentUser = (updates: Partial<User>) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === currentUser.id || u.role === currentRole) {
          return { ...u, ...updates };
        }
        return u;
      })
    );
  };

  // Global Modals
  const [commandPaletteOpen, setCommandPaletteOpen] = useState<boolean>(false);

  // Screen Spec Inspector modal state
  const [inspectingScreenCode, setInspectingScreenCode] = useState<string | null>(null);

  // Toasts
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Apply dark mode class and data-theme to root HTML
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    const isDark = theme === 'modern-dark' || isDarkMode;
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme, isDarkMode]);

  const currentTenant = useMemo(() => {
    if (currentCompany) {
      return {
        id: currentCompany.id,
        code: currentCompany.code,
        name: currentCompany.name,
        domain: `${currentCompany.code.toLowerCase()}.aplus.vn`,
        taxId: currentCompany.taxCode || '0109988776',
        currency: 'VND',
        timezone: 'GMT+7',
        plan: 'Enterprise Plus' as const,
        maxUsers: currentCompany.maxUsers || 100,
        activeUsers: currentCompany.userCount || 1,
        status: 'active' as const,
      };
    }
    return tenants.find((t) => t.id === currentTenantId) || tenants[0];
  }, [currentCompany, tenants, currentTenantId]);

  const currentUser = users.find((u) => u.id === currentUserId) || users.find((u) => u.role === currentRole) || users[0];
  const t = translations[language];
  const themeDef = THEME_PRESETS[theme];

  // Auto-sync when user logs in via MultiTenantContext & clear simulated data for clean tenant (aplus)
  useEffect(() => {
    if (currentCompany) {
      const isCleanTenant =
        currentCompany.code?.toUpperCase() === 'APLUS' ||
        currentCompany.slug?.toLowerCase() === 'aplus' ||
        currentCompany.id?.startsWith('tenant_');

      if (isCleanTenant) {
        // Wipe simulated legacy mock data, but preserve real A+ notifications
        setLeads([]);
        setContacts([]);
        setOpportunities([]);
        setQuotations([]);
        setContracts([]);
        setTickets([]);
        setProducts([]);
        setStockTransactions([]);
        setNotifications((prev) => (prev && prev.length > 0 ? prev : INITIAL_NOTIFICATIONS));
      }

      if (currentAccount) {
        let resolvedRole: UserRole = 'Admin';
        const accEmail = (currentAccount.email || '').toLowerCase();
        const accName = (currentAccount.fullName || '').toLowerCase();
        const memRoleTitle = (currentMember?.roleTitle || '').toLowerCase();
        const memRoleId = currentMember?.roleId || '';

        if (
          currentAccount.isPlatformAdmin ||
          accEmail.includes('huy.nk') ||
          memRoleTitle.includes('super admin') ||
          memRoleId === 'role_super_admin'
        ) {
          resolvedRole = 'Super Admin';
        } else if (
          memRoleId === 'role_director' ||
          memRoleTitle.includes('giám đốc') ||
          accName.includes('hồ minh châu') ||
          accEmail.includes('chau.hm')
        ) {
          resolvedRole = 'Director';
        } else if (
          memRoleId === 'role_sale_manager' ||
          memRoleTitle.includes('trưởng phòng sale') ||
          accName.includes('hồ hoàng long') ||
          accEmail.includes('long.hh')
        ) {
          resolvedRole = 'Sales Manager';
        } else if (
          memRoleId === 'role_sale_staff' ||
          memRoleTitle.includes('nhân viên sale') ||
          accName.includes('nguyễn văn a') ||
          accEmail.includes('vana.sales')
        ) {
          resolvedRole = 'Sales Staff';
        } else if (
          memRoleId === 'role_company_admin' ||
          memRoleTitle.includes('admin') ||
          accName.includes('nguyễn nhật thanh') ||
          accEmail.includes('thanh.nn')
        ) {
          resolvedRole = 'Admin';
        }

        const activeTenantUser: User = {
          id: currentAccount.id,
          tenantId: currentCompany.id,
          fullName: currentAccount.fullName,
          email: currentAccount.email,
          phone: currentAccount.phone || '0901234567',
          role: resolvedRole,
          department: currentMember?.roleTitle || (resolvedRole === 'Super Admin' ? 'Ban Điều Hành & Chiến Lược' : resolvedRole === 'Director' ? 'Ban Giám Đốc' : resolvedRole === 'Sales Manager' ? 'Khối Kinh Doanh (Sales)' : resolvedRole === 'Sales Staff' ? 'Phòng Kinh Doanh (Sales)' : 'Ban Quản Trị Hệ Thống'),
          avatar: currentAccount.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=120&auto=format&fit=crop&q=80',
          status: 'active',
          lastLogin: 'Vừa xong',
          createdAt: currentCompany.createdAt || '2026-10-08',
        };

        setUsers((prev) => {
          const filtered = prev.filter((u) => u.tenantId === currentCompany.id);
          const exists = filtered.find((u) => u.id === currentAccount.id || u.email.toLowerCase() === currentAccount.email.toLowerCase());
          if (exists) {
            return filtered.map((u) => (u.id === exists.id ? { ...u, role: resolvedRole, avatar: currentAccount.avatar || u.avatar, fullName: currentAccount.fullName || u.fullName } : u));
          }
          return [activeTenantUser, ...filtered];
        });

        setCurrentUserId(currentAccount.id);
        setCurrentRole(resolvedRole);
        try {
          localStorage.setItem('crm_current_user_id', currentAccount.id);
          localStorage.setItem('crm_current_role', resolvedRole);
        } catch (e) {}
      }
    } else if (currentAccount) {
      const matched = users.find(
        (u) =>
          u.email.toLowerCase() === currentAccount.email.toLowerCase() ||
          u.fullName.toLowerCase() === currentAccount.fullName.toLowerCase()
      );
      if (matched) {
        setCurrentUserId(matched.id);
        setCurrentRole(matched.role);
        try {
          localStorage.setItem('crm_current_user_id', matched.id);
          localStorage.setItem('crm_current_role', matched.role);
        } catch (e) {}
      }
    }
  }, [currentCompany?.id, currentAccount?.id]);

  // Fast demo user switcher
  const switchDemoUser = (userIdOrRole: string) => {
    const query = userIdOrRole.toLowerCase();
    const targetUser =
      users.find((u) => u.id === userIdOrRole) ||
      users.find((u) => u.role.toLowerCase() === query) ||
      users.find((u) => u.fullName.toLowerCase().includes(query)) ||
      INITIAL_USERS.find((u) => u.role.toLowerCase() === query) ||
      INITIAL_USERS.find((u) => u.fullName.toLowerCase().includes(query));

    if (targetUser) {
      if (!users.some((u) => u.id === targetUser.id || u.email === targetUser.email)) {
        setUsers((prev) => [...prev, targetUser]);
      }
      setCurrentUserId(targetUser.id);
      setCurrentRole(targetUser.role);
      try {
        localStorage.setItem('crm_current_user_id', targetUser.id);
        localStorage.setItem('crm_current_role', targetUser.role);
      } catch (e) {}
      showToast(
        'Chuyển đổi vai trò',
        `Đang xem hệ sinh thái dưới quyền: ${targetUser.fullName} (${targetUser.role})`,
        'info'
      );
    }
  };

  const showToast = (title: string, message: string, type: ToastMessage['type'] = 'success') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((item) => item.id !== id));
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((item) => item.id !== id));
  };

  const hasPermission = (module: ActiveModule, action: PermissionAction): boolean => {
    // 1. Super Admin & Admin: Toàn quyền không giới hạn
    if (currentRole === 'Super Admin' || currentRole === 'Admin') return true;

    // 2. Ban Giám Đốc (Director): Quyền xem báo cáo, dashboard chiến lược, P&L, OKR
    if (currentRole === 'Director') {
      if (
        module === 'dashboard' ||
        module === 'reports' ||
        module.startsWith('reports-') ||
        module.startsWith('sales-') ||
        module === 'okr' ||
        module === 'my-profile'
      ) return true;
      if (action === 'view') return true;
      return false;
    }

    // 3. Trưởng phòng Kỹ thuật (Technical Manager): Quyền toàn bộ module kỹ thuật & báo cáo kỹ thuật
    if (currentRole === 'Technical Manager') {
      if (
        module === 'dashboard' ||
        module === 'technical' ||
        module.startsWith('technical-') ||
        module === 'reports-technical' ||
        module === 'my-profile'
      ) return true;
      return false;
    }

    // 4. Trưởng phòng Sale (Sales Manager): Quyền toàn bộ module sales & 8 báo cáo sales
    if (currentRole === 'Sales Manager') {
      if (
        module === 'dashboard' ||
        module === 'sales' ||
        module === 'leads' ||
        module === 'customers' ||
        module === 'contacts' ||
        module === 'opportunities' ||
        module === 'quotations' ||
        module === 'sales-orders' ||
        module === 'contracts' ||
        module === 'sales-invoices' ||
        module === 'sales-receipts' ||
        module === 'sales-activities' ||
        module === 'tasks' ||
        module === 'calendar' ||
        module.startsWith('sales-') ||
        module === 'reports' ||
        module === 'my-profile'
      ) return true;
      return false;
    }

    // 5. Nhân viên phòng Sale (Sales Staff): Xem & tác nghiệp lead/deal cá nhân
    if (currentRole === 'Sales Staff') {
      if (
        module === 'dashboard' ||
        module === 'sales' ||
        module === 'leads' ||
        module === 'customers' ||
        module === 'contacts' ||
        module === 'opportunities' ||
        module === 'quotations' ||
        module === 'sales-activities' ||
        module === 'tasks' ||
        module === 'calendar' ||
        module === 'my-profile'
      ) return true;
      return false;
    }

    // Common fallback for other roles
    if (module === 'dashboard' || module === 'my-profile') return true;
    const config = rolePermissions.find((r) => r.role === currentRole);
    if (!config) return false;
    const modulePerms = config.permissions[module];
    if (!modulePerms) return false;
    return modulePerms.includes(action);
  };

  const updateRolePermission = (
    role: UserRole,
    module: ActiveModule,
    action: PermissionAction,
    enable: boolean
  ) => {
    setRolePermissions((prev) =>
      prev.map((rConfig) => {
        if (rConfig.role !== role) return rConfig;
        const currentModulePerms = rConfig.permissions[module] || [];
        let updatedActions: PermissionAction[];
        if (enable) {
          updatedActions = Array.from(new Set([...currentModulePerms, action]));
        } else {
          updatedActions = currentModulePerms.filter((a) => a !== action);
        }
        return {
          ...rConfig,
          permissions: {
            ...rConfig.permissions,
            [module]: updatedActions,
          },
        };
      })
    );

    // Audit log entry
    addAuditLog('PERMISSION_CHANGE', 'ROLE_RBAC', role, `Cập nhật quyền ${action} cho module ${module}: ${enable ? 'Bật' : 'Tắt'}`);
    showToast('Cập nhật ma trận phân quyền', `Đã cập nhật quyền ${action} của vai trò ${role}`);
  };

  const addAuditLog = (
    action: AuditLog['action'],
    entity: string,
    entityId: string,
    details: string,
    status: AuditLog['status'] = 'SUCCESS'
  ) => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19);
    const newLog: AuditLog = {
      id: `aud-${Date.now()}`,
      tenantId: currentTenant.id,
      timestamp: now,
      userName: currentUser.fullName,
      userRole: currentRole,
      action,
      entity,
      entityId,
      ipAddress: '113.190.234.12',
      details,
      status,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const addActivityLog = (actionSummary: string, module: ActiveModule) => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const newAct: ActivityLog = {
      id: `act-${Date.now()}`,
      timestamp: now,
      userName: currentUser.fullName,
      userAvatar: currentUser.avatar,
      actionSummary,
      module,
      timeAgo: 'Vừa xong',
    };
    setActivityLogs((prev) => [newAct, ...prev]);
  };

  // CRUD Leads
  const addLead = (leadData: Omit<Lead, 'id' | 'createdAt' | 'updatedAt' | 'code' | 'tenantId'>) => {
    const newCode = `LEAD-2026-${String(leads.length + 94).padStart(3, '0')}`;
    const today = new Date().toISOString().split('T')[0];
    const newLead: Lead = {
      ...leadData,
      id: `lead-${Date.now()}`,
      code: newCode,
      tenantId: currentTenant.id,
      createdAt: today,
      updatedAt: today,
    };
    setLeads((prev) => [newLead, ...prev]);
    addActivityLog(`Đã tạo khách hàng tiềm năng mới ${newLead.fullName} (${newCode})`, 'leads');
    addAuditLog('CREATE', 'LEAD', newCode, `Tạo mới Lead: ${newLead.fullName}, cty: ${newLead.company}`);
    showToast(t.success, `Đã thêm thành công khách hàng tiềm năng ${newLead.fullName}`);
  };

  const updateLead = (id: string, updated: Partial<Lead>) => {
    const today = new Date().toISOString().split('T')[0];
    setLeads((prev) =>
      prev.map((lead) => {
        if (lead.id === id) {
          const merged = { ...lead, ...updated, updatedAt: today };
          addActivityLog(`Đã cập nhật thông tin Lead ${merged.fullName} (${merged.code})`, 'leads');
          addAuditLog('UPDATE', 'LEAD', merged.code, `Cập nhật trạng thái sang ${merged.status}`);
          return merged;
        }
        return lead;
      })
    );
    showToast(t.success, 'Đã cập nhật thông tin Lead thành công');
  };

  const deleteLead = (id: string) => {
    const target = leads.find((l) => l.id === id);
    if (!target) return;
    setLeads((prev) => prev.filter((l) => l.id !== id));
    addActivityLog(`Đã xóa Lead ${target.fullName} (${target.code})`, 'leads');
    addAuditLog('DELETE', 'LEAD', target.code, `Xóa Lead ${target.fullName}`);
    showToast(t.success, `Đã xóa Lead ${target.code}`);
  };

  const convertLeadToOpportunity = (leadId: string) => {
    const lead = leads.find((l) => l.id === leadId);
    if (!lead) return;

    // 1. Update lead status
    updateLead(leadId, { status: 'Đã chuyển đổi' });

    // 2. Create contact if not exists
    const contactCode = `CTC-${String(contacts.length + 1).padStart(3, '0')}`;
    const newContact: Contact = {
      id: `con-${Date.now()}`,
      tenantId: currentTenant.id,
      code: contactCode,
      fullName: lead.fullName,
      company: lead.company,
      title: lead.title,
      email: lead.email,
      phone: lead.phone,
      type: 'Khách hàng mới',
      address: 'Văn phòng trụ sở doanh nghiệp',
      city: 'Việt Nam',
      dealsCount: 1,
      totalSpent: 0,
      assignedTo: lead.assignedTo,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setContacts((prev) => [newContact, ...prev]);

    // 3. Create opportunity
    const oppCode = `OPP-2026-${String(opportunities.length + 46).padStart(3, '0')}`;
    const newOpp: Opportunity = {
      id: `opp-${Date.now()}`,
      tenantId: currentTenant.id,
      code: oppCode,
      title: `Triển khai Giải pháp CRM & Cloud cho ${lead.company}`,
      contactName: lead.fullName,
      company: lead.company,
      stage: 'Khám phá nhu cầu',
      amount: lead.estimatedValue || 500000000,
      probability: 40,
      expectedCloseDate: '2026-11-30',
      assignedTo: lead.assignedTo,
      leadSource: lead.source,
      priority: 'Cao',
      createdAt: new Date().toISOString().split('T')[0],
    };
    setOpportunities((prev) => [newOpp, ...prev]);

    addActivityLog(`Đã chuyển đổi Lead ${lead.fullName} thành Cơ hội ${oppCode}`, 'opportunities');
    addAuditLog('CREATE', 'OPPORTUNITY', oppCode, `Chuyển đổi thành công từ Lead ${lead.code}`);
    showToast(t.success, `Chuyển đổi thành công sang Cơ hội bán hàng ${oppCode}!`);
  };

  // Contacts
  const addContact = (data: Omit<Contact, 'id' | 'createdAt' | 'code' | 'tenantId'>) => {
    const code = `CTC-${String(contacts.length + 1).padStart(3, '0')}`;
    const newC: Contact = {
      ...data,
      id: `con-${Date.now()}`,
      code,
      tenantId: currentTenant.id,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setContacts((prev) => [newC, ...prev]);
    addActivityLog(`Đã thêm liên hệ mới ${newC.fullName}`, 'contacts');
    addAuditLog('CREATE', 'CONTACT', code, `Thêm liên hệ: ${newC.fullName}`);
    showToast(t.success, `Đã thêm liên hệ ${newC.fullName}`);
  };

  const updateContact = (id: string, updated: Partial<Contact>) => {
    setContacts((prev) =>
      prev.map((c) => (c.id === id ? { ...c, ...updated } : c))
    );
    showToast(t.success, 'Đã cập nhật danh bạ thành công');
  };

  const deleteContact = (id: string) => {
    const target = contacts.find((c) => c.id === id);
    if (!target) return;
    setContacts((prev) => prev.filter((c) => c.id !== id));
    addAuditLog('DELETE', 'CONTACT', target.code, `Xóa danh bạ ${target.fullName}`);
    showToast(t.success, `Đã xóa liên hệ ${target.fullName}`);
  };

  // Opportunities
  const addOpportunity = (data: Omit<Opportunity, 'id' | 'createdAt' | 'code' | 'tenantId'>) => {
    const code = `OPP-2026-${String(opportunities.length + 46).padStart(3, '0')}`;
    const newOpp: Opportunity = {
      ...data,
      id: `opp-${Date.now()}`,
      code,
      tenantId: currentTenant.id,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setOpportunities((prev) => [newOpp, ...prev]);
    addActivityLog(`Đã tạo cơ hội thương mại ${newOpp.title} (${code})`, 'opportunities');
    addAuditLog('CREATE', 'OPPORTUNITY', code, `Tạo cơ hội: ${newOpp.title}, giá trị ${newOpp.amount}`);
    showToast(t.success, `Đã tạo cơ hội bán hàng ${code}`);
  };

  const updateOpportunityStage = (id: string, stage: OpportunityStage) => {
    setOpportunities((prev) =>
      prev.map((opp) => {
        if (opp.id === id) {
          let prob = opp.probability;
          if (stage === 'Khám phá nhu cầu') prob = 30;
          if (stage === 'Báo giá & Đề xuất') prob = 60;
          if (stage === 'Đàm phán') prob = 80;
          if (stage === 'Thành công (Won)') prob = 100;
          if (stage === 'Thất bại (Lost)') prob = 0;

          addActivityLog(`Đã chuyển giai đoạn Cơ hội ${opp.code} sang ${stage}`, 'opportunities');
          addAuditLog('UPDATE', 'OPPORTUNITY', opp.code, `Cập nhật giai đoạn sang ${stage}`);
          return { ...opp, stage, probability: prob };
        }
        return opp;
      })
    );
    showToast(t.success, `Đã cập nhật giai đoạn thành công`);
  };

  const updateOpportunity = (id: string, updated: Partial<Opportunity>) => {
    setOpportunities((prev) =>
      prev.map((o) => (o.id === id ? { ...o, ...updated } : o))
    );
    showToast(t.success, 'Đã cập nhật cơ hội bán hàng');
  };

  const deleteOpportunity = (id: string) => {
    const target = opportunities.find((o) => o.id === id);
    if (!target) return;
    setOpportunities((prev) => prev.filter((o) => o.id !== id));
    addAuditLog('DELETE', 'OPPORTUNITY', target.code, `Xóa cơ hội ${target.title}`);
    showToast(t.success, `Đã xóa cơ hội ${target.code}`);
  };

  // Quotations
  const addQuotation = (data: Omit<Quotation, 'id' | 'createdAt' | 'code' | 'tenantId'>) => {
    const code = `BG-2026-${String(quotations.length + 91).padStart(4, '0')}`;
    const newQ: Quotation = {
      ...data,
      id: `quo-${Date.now()}`,
      code,
      tenantId: currentTenant.id,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setQuotations((prev) => [newQ, ...prev]);
    addActivityLog(`Đã lập báo giá mới ${code} cho ${newQ.customerName}`, 'quotations');
    addAuditLog('CREATE', 'QUOTATION', code, `Tạo báo giá ${code}, tổng tiền ${newQ.grandTotal}`);
    showToast(t.success, `Đã tạo báo giá thành công: ${code}`);
  };

  const updateQuotationStatus = (id: string, status: Quotation['status']) => {
    setQuotations((prev) =>
      prev.map((q) => {
        if (q.id === id) {
          addActivityLog(`Đã đổi trạng thái Báo giá ${q.code} sang ${status}`, 'quotations');
          addAuditLog('UPDATE', 'QUOTATION', q.code, `Đổi trạng thái báo giá sang ${status}`);
          return { ...q, status };
        }
        return q;
      })
    );
    showToast(t.success, `Báo giá đã cập nhật sang trạng thái: ${status}`);
  };

  const deleteQuotation = (id: string) => {
    const target = quotations.find((q) => q.id === id);
    if (!target) return;
    setQuotations((prev) => prev.filter((q) => q.id !== id));
    addAuditLog('DELETE', 'QUOTATION', target.code, `Xóa báo giá ${target.code}`);
    showToast(t.success, `Đã xóa báo giá ${target.code}`);
  };

  // Contracts
  const addContract = (data: Omit<Contract, 'id' | 'createdAt' | 'tenantId'>) => {
    const newCnt: Contract = {
      ...data,
      id: `cnt-${Date.now()}`,
      tenantId: currentTenant.id,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setContracts((prev) => [newCnt, ...prev]);
    addActivityLog(`Đã khởi tạo hợp đồng kinh tế ${newCnt.contractNumber}`, 'contracts');
    addAuditLog('CREATE', 'CONTRACT', newCnt.contractNumber, `Tạo hợp đồng giá trị ${newCnt.totalValue}`);
    showToast(t.success, `Đã thêm hợp đồng ${newCnt.contractNumber}`);
  };

  const toggleMilestonePaid = (contractId: string, milestoneIndex: number) => {
    setContracts((prev) =>
      prev.map((cnt) => {
        if (cnt.id === contractId) {
          const updatedMilestones = [...cnt.paymentMilestones];
          updatedMilestones[milestoneIndex].isPaid = !updatedMilestones[milestoneIndex].isPaid;
          addAuditLog('UPDATE', 'CONTRACT_MILESTONE', cnt.contractNumber, `Cập nhật đợt ${milestoneIndex + 1} sang ${updatedMilestones[milestoneIndex].isPaid ? 'Đã thu tiền' : 'Chưa thanh toán'}`);
          return { ...cnt, paymentMilestones: updatedMilestones };
        }
        return cnt;
      })
    );
    showToast(t.success, 'Đã cập nhật tiến độ thanh toán đợt');
  };

  const deleteContract = (id: string) => {
    const target = contracts.find((c) => c.id === id);
    if (!target) return;
    setContracts((prev) => prev.filter((c) => c.id !== id));
    addAuditLog('DELETE', 'CONTRACT', target.contractNumber, `Xóa hợp đồng ${target.contractNumber}`);
    showToast(t.success, `Đã xóa hợp đồng`);
  };

  // Tickets
  const addTicket = (data: Omit<Ticket, 'id' | 'createdAt' | 'updatedAt' | 'ticketNumber' | 'tenantId'>) => {
    const num = `TICK-2026-${String(tickets.length + 1046)}`;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const newT: Ticket = {
      ...data,
      id: `tic-${Date.now()}`,
      ticketNumber: num,
      tenantId: currentTenant.id,
      createdAt: now,
      updatedAt: now,
    };
    setTickets((prev) => [newT, ...prev]);
    addActivityLog(`Đã tiếp nhận Ticket CSKH ${num} (${newT.priority})`, 'customer-care');
    addAuditLog('CREATE', 'TICKET', num, `Tạo ticket: ${newT.subject} [${newT.priority}]`);
    showToast(t.success, `Đã tạo ticket CSKH ${num}`);
  };

  const resolveTicket = (id: string, csatScore: number = 5) => {
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setTickets((prev) =>
      prev.map((tItem) => {
        if (tItem.id === id) {
          addActivityLog(`Đã xử lý và đóng Ticket ${tItem.ticketNumber} (CSAT: ${csatScore}★)`, 'customer-care');
          addAuditLog('UPDATE', 'TICKET', tItem.ticketNumber, `Giải quyết sự cố và hoàn tất ticket với CSAT ${csatScore}`);
          return {
            ...tItem,
            status: 'Đã giải quyết',
            slaMinutesRemaining: 0,
            csatScore,
            updatedAt: now,
          };
        }
        return tItem;
      })
    );
    showToast(t.success, `Đã đóng Ticket và ghi nhận đánh giá CSAT ${csatScore} sao!`);
  };

  const deleteTicket = (id: string) => {
    setTickets((prev) => prev.filter((tItem) => tItem.id !== id));
    showToast(t.success, 'Đã xóa Ticket');
  };

  // Products & Inventory
  const addProduct = (data: Omit<Product, 'id' | 'tenantId'>) => {
    const newP: Product = {
      ...data,
      id: `prod-${Date.now()}`,
      tenantId: currentTenant.id,
    };
    setProducts((prev) => [newP, ...prev]);
    addAuditLog('CREATE', 'PRODUCT', newP.sku, `Thêm sản phẩm mới ${newP.name}`);
    showToast(t.success, `Đã thêm sản phẩm ${newP.sku}`);
  };

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id));
    showToast(t.success, 'Đã xóa sản phẩm');
  };

  const addStockMovement = (
    type: InventoryTransaction['type'],
    warehouse: InventoryTransaction['warehouse'],
    productId: string,
    quantity: number,
    reason: string
  ) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;

    // Check stock if out
    if (type === 'Xuất kho') {
      let currentStockInDepot = 0;
      if (warehouse === 'Kho Hà Nội') currentStockInDepot = product.stockHanoi;
      if (warehouse === 'Kho Đà Nẵng') currentStockInDepot = product.stockDanang;
      if (warehouse === 'Kho TP.HCM') currentStockInDepot = product.stockHCM;

      if (currentStockInDepot < quantity) {
        showToast('Lỗi xuất kho', `Số lượng tồn tại ${warehouse} (${currentStockInDepot}) không đủ để xuất ${quantity}!`, 'error');
        return;
      }
    }

    // Update product stock
    setProducts((prev) =>
      prev.map((p) => {
        if (p.id === productId) {
          const delta = type === 'Nhập kho' ? quantity : -quantity;
          let newHn = p.stockHanoi;
          let newDn = p.stockDanang;
          let newHcm = p.stockHCM;
          if (warehouse === 'Kho Hà Nội') newHn = Math.max(0, newHn + delta);
          if (warehouse === 'Kho Đà Nẵng') newDn = Math.max(0, newDn + delta);
          if (warehouse === 'Kho TP.HCM') newHcm = Math.max(0, newHcm + delta);

          const total = newHn + newDn + newHcm;
          const status = total <= p.minSafeStock ? 'Sắp hết hàng' : 'Đang kinh doanh';
          return {
            ...p,
            stockHanoi: newHn,
            stockDanang: newDn,
            stockHCM: newHcm,
            status,
          };
        }
        return p;
      })
    );

    // Create tx
    const txPrefix = type === 'Nhập kho' ? 'PNK' : 'PXK';
    const txCode = `${txPrefix}-2026-${String(stockTransactions.length + 92).padStart(4, '0')}`;
    const newTx: InventoryTransaction = {
      id: `tx-${Date.now()}`,
      tenantId: currentTenant.id,
      txCode,
      type,
      warehouse,
      productName: product.name,
      sku: product.sku,
      quantity,
      unit: product.unit,
      performedBy: currentUser.fullName,
      reason,
      createdAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };
    setStockTransactions((prev) => [newTx, ...prev]);
    addActivityLog(`Đã lập ${type} ${txCode} cho mã ${product.sku} (${quantity} ${product.unit})`, 'inventory');
    addAuditLog(type === 'Nhập kho' ? 'CREATE' : 'UPDATE', 'INVENTORY_TX', txCode, `${type} ${product.sku} sl: ${quantity}`);
    showToast(t.success, `Đã lập ${type} thành công: ${txCode}`);
  };

  // Users
  const addUser = (userData: Omit<User, 'id' | 'createdAt' | 'lastLogin' | 'tenantId'>) => {
    const newUser: User = {
      ...userData,
      id: `usr-${Date.now()}`,
      tenantId: currentTenant.id,
      lastLogin: 'Chưa đăng nhập',
      createdAt: new Date().toISOString().split('T')[0],
    };
    setUsers((prev) => [newUser, ...prev]);
    addAuditLog('CREATE', 'USER', newUser.email, `Khởi tạo người dùng ${newUser.fullName} (${newUser.role})`);
    showToast(t.success, `Đã cấp tài khoản thành công cho ${newUser.fullName}`);
  };

  const updateUserStatus = (id: string, status: User['status']) => {
    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === id) {
          addAuditLog('UPDATE', 'USER', u.email, `Đổi trạng thái tài khoản sang ${status}`);
          return { ...u, status };
        }
        return u;
      })
    );
    showToast(t.success, 'Đã cập nhật trạng thái tài khoản');
  };

  const deleteUser = (id: string) => {
    const target = users.find((u) => u.id === id);
    if (!target) return;
    setUsers((prev) => prev.filter((u) => u.id !== id));
    addAuditLog('DELETE', 'USER', target.email, `Xóa tài khoản ${target.fullName}`);
    showToast(t.success, 'Đã xóa người dùng khỏi hệ thống');
  };

  // Notifications with 90-day retention and tenant scope
  const activeNotifications = useMemo(() => {
    const ninetyDaysAgo = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000).toISOString();
    return notifications.filter((item) => {
      if (item.createdAt && item.createdAt < ninetyDaysAgo) return false;
      return true;
    });
  }, [notifications]);

  const unreadNotificationCount = useMemo(() => {
    if (userPreferences?.notificationChannels?.showBadgeOnBell === false) return 0;
    return activeNotifications.filter((n: NotificationItem) => !n.read).length;
  }, [activeNotifications, userPreferences?.notificationChannels?.showBadgeOnBell]);

  const addNotification = (
    item: Omit<NotificationItem, 'id' | 'createdAt' | 'read' | 'timestamp'> & { timestamp?: string }
  ) => {
    const newNotif: NotificationItem = {
      ...item,
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      read: false,
      timestamp: item.timestamp || 'Vừa xong',
      createdAt: new Date().toISOString(),
      tenantId: item.tenantId || currentTenantId,
    };
    setNotifications((prev) => [newNotif, ...prev]);
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
    showToast(t.success, t.markAllRead);
  };

  // Tenant update
  const updateCurrentTenant = (updated: Partial<Tenant>) => {
    setTenants((prev) =>
      prev.map((t) => (t.id === currentTenantId ? { ...t, ...updated } : t))
    );
    addAuditLog('UPDATE', 'TENANT', currentTenant.code, 'Cập nhật cấu hình doanh nghiệp');
    showToast(t.success, 'Đã lưu cấu hình doanh nghiệp Tenant');
  };

  // Screen Spec Inspector
  const openScreenSpec = (screenCode: string) => {
    setInspectingScreenCode(screenCode);
  };

  const closeScreenSpec = () => {
    setInspectingScreenCode(null);
  };

  // OKR State & Methods
  const [periodTargets, setPeriodTargets] = useState<OKRTargetConfig[]>(INITIAL_OKR_TARGETS);
  const [okrObjectives, setOkrObjectives] = useState<OKRObjective[]>(INITIAL_OKR_OBJECTIVES);
  const [selectedOKRPeriod, setSelectedOKRPeriod] = useState<string>('Q4-2026');

  const getActualMetric = (syncKey: 'revenue' | 'pipeline' | 'leads' | 'conversion' | 'won_deals' | 'open_deals'): number => {
    switch (syncKey) {
      case 'revenue':
        return contracts
          .filter((c) => c.status === 'Đang hiệu lực' || c.status === 'Đã hoàn tất')
          .reduce((sum, c) => sum + c.totalValue, 0);
      case 'pipeline':
        return opportunities
          .filter((o) => o.stage !== 'Thành công (Won)' && o.stage !== 'Thất bại (Lost)')
          .reduce((sum, o) => sum + o.amount, 0);
      case 'leads':
        return leads.length;
      case 'conversion': {
        const total = leads.length;
        if (total === 0) return 0;
        const converted = leads.filter((l) => l.status === 'Đã chuyển đổi').length;
        return Math.round((converted / total) * 100);
      }
      case 'won_deals':
        return opportunities.filter((o) => o.stage === 'Thành công (Won)').length;
      case 'open_deals':
        return opportunities.filter((o) => o.stage !== 'Thành công (Won)' && o.stage !== 'Thất bại (Lost)').length;
      default:
        return 0;
    }
  };

  const updatePeriodTarget = (updated: OKRTargetConfig) => {
    setPeriodTargets((prev) => {
      const exists = prev.some((p) => p.periodId === updated.periodId);
      if (exists) {
        return prev.map((p) => (p.periodId === updated.periodId ? updated : p));
      }
      return [updated, ...prev];
    });
    showToast('Đã lưu mục tiêu', `Cập nhật chỉ tiêu OKR cho chu kỳ ${updated.periodId} thành công.`);
  };

  const addOKRObjective = (obj: Omit<OKRObjective, 'id' | 'code'>) => {
    const id = `okr-obj-${Date.now()}`;
    const code = `OBJ-${new Date().getFullYear()}-${obj.quarter}-${Math.floor(10 + Math.random() * 90)}`;
    const newObj: OKRObjective = { ...obj, id, code };
    setOkrObjectives((prev) => [newObj, ...prev]);
    showToast('Đã tạo Mục tiêu mới', `Mục tiêu ${code} đã được khởi tạo.`);
  };

  const updateOKRObjective = (id: string, updated: Partial<OKRObjective>) => {
    setOkrObjectives((prev) =>
      prev.map((o) => (o.id === id ? { ...o, ...updated } : o))
    );
    showToast('Cập nhật thành công', 'Thông tin Mục tiêu OKR đã được cập nhật.');
  };

  const deleteOKRObjective = (id: string) => {
    setOkrObjectives((prev) => prev.filter((o) => o.id !== id));
    showToast('Đã xóa Mục tiêu', 'Mục tiêu đã được gỡ bỏ khỏi chu kỳ.', 'warning');
  };

  const addKeyResult = (objectiveId: string, kr: Omit<KeyResult, 'id'>) => {
    const id = `kr-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newKr: KeyResult = { ...kr, id };
    setOkrObjectives((prev) =>
      prev.map((o) => {
        if (o.id !== objectiveId) return o;
        return {
          ...o,
          keyResults: [...o.keyResults, newKr],
        };
      })
    );
    showToast('Đã thêm Key Result', `Kết quả then chốt "${kr.title}" đã được thêm.`);
  };

  const updateKeyResult = (objectiveId: string, krId: string, updated: Partial<KeyResult>) => {
    setOkrObjectives((prev) =>
      prev.map((o) => {
        if (o.id !== objectiveId) return o;
        return {
          ...o,
          keyResults: o.keyResults.map((k) => (k.id === krId ? { ...k, ...updated } : k)),
        };
      })
    );
    showToast('Cập nhật thành công', 'Kết quả then chốt đã được cập nhật.');
  };

  const deleteKeyResult = (objectiveId: string, krId: string) => {
    setOkrObjectives((prev) =>
      prev.map((o) => {
        if (o.id !== objectiveId) return o;
        return {
          ...o,
          keyResults: o.keyResults.filter((k) => k.id !== krId),
        };
      })
    );
    showToast('Đã xóa', 'Kết quả then chốt đã được gỡ bỏ.', 'warning');
  };

  return (
    <CRMContext.Provider
      value={{
        tenants,
        currentTenant,
        setCurrentTenantId,
        updateCurrentTenant,

        currentRole,
        setCurrentRole,
        currentUser,
        switchDemoUser,
        hasPermission,
        rolePermissions,
        updateRolePermission,

        activeModule,
        setActiveModule,
        sidebarCollapsed,
        setSidebarCollapsed,
        toggleSidebarCollapsed,

        language,
        setLanguage,
        t,

        theme,
        setTheme,
        isDarkMode,
        setIsDarkMode,
        themeMode,
        setThemeMode,
        themeDef,
        customTheme,
        setCustomTheme,

        // User Profile & Preferences
        currentDocCode,
        setCurrentDocCode,
        profileActiveTab,
        setProfileActiveTab,
        userPreferences,
        updateUserPreferences,
        updateCurrentUser,

        // Search
        recentSearches,
        addRecentSearch,
        clearRecentSearches,

        leads,
        addLead,
        updateLead,
        deleteLead,
        convertLeadToOpportunity,

        contacts,
        addContact,
        updateContact,
        deleteContact,

        opportunities,
        addOpportunity,
        updateOpportunityStage,
        updateOpportunity,
        deleteOpportunity,

        quotations,
        addQuotation,
        updateQuotationStatus,
        deleteQuotation,

        contracts,
        addContract,
        toggleMilestonePaid,
        deleteContract,

        tickets,
        addTicket,
        resolveTicket,
        deleteTicket,

        products,
        addProduct,
        deleteProduct,

        stockTransactions,
        addStockMovement,

        users,
        addUser,
        updateUserStatus,
        deleteUser,

        notifications: activeNotifications,
        unreadNotificationCount,
        addNotification,
        markNotificationRead,
        markAllNotificationsRead,

        auditLogs,
        activityLogs,

        commandPaletteOpen,
        setCommandPaletteOpen,

        inspectingScreenCode,
        openScreenSpec,
        closeScreenSpec,

        toasts,
        showToast,
        dismissToast,

        okrObjectives,
        periodTargets,
        selectedOKRPeriod,
        setSelectedOKRPeriod,
        updatePeriodTarget,
        addOKRObjective,
        updateOKRObjective,
        deleteOKRObjective,
        addKeyResult,
        updateKeyResult,
        deleteKeyResult,
        getActualMetric,
      }}
    >
      {children}
    </CRMContext.Provider>
  );
};

export const useCRM = (): CRMContextType => {
  const context = useContext(CRMContext);
  if (!context) {
    throw new Error('useCRM must be used within a CRMProvider');
  }
  return context;
};
