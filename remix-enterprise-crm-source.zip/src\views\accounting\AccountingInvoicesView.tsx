import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useLogistics } from '../../context/LogisticsContext';
import { useAccounting } from '../../context/AccountingContext';
import { useTechnical } from '../../context/TechnicalContext';
import { AccountingQuotationReview } from '../../types/accounting';
import { SalesInvoice } from '../../types/sales';
import { PurchaseInvoice } from '../../types/logistics';
import {
  FileText,
  Search,
  Filter,
  Download,
  CheckCircle2,
  Clock,
  AlertTriangle,
  ExternalLink,
  Plus,
  X,
  FileCheck,
  TrendingDown,
  TrendingUp,
  Percent,
  DollarSign,
  Building,
  Upload,
  Eye,
  ShieldCheck,
  Check,
  Ban,
  FileSpreadsheet,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

export const AccountingInvoicesView: React.FC = () => {
  const { showToast, currentUser } = useCRM();
  const {
    invoices: salesInvoices,
    quotations: salesQuotes,
    orders,
    contracts,
    createInvoiceFromOrder,
    createInvoiceFromMilestone,
  } = useSales();
  const { purchaseInvoices } = useLogistics();
  const { quotationReviews, reviewQuotationFinancial, updateEInvoiceDetails } = useAccounting();
  const { acceptanceCertificates } = useTechnical();

  const [activeMainTab, setActiveMainTab] = useState<'invoices' | 'quotations'>('invoices');
  const [invoiceSubTab, setInvoiceSubTab] = useState<'queue' | 'sales' | 'purchase'>('queue');

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPaymentStatus, setSelectedPaymentStatus] = useState('all');
  const [selectedEinvoiceStatus, setSelectedEinvoiceStatus] = useState('all');

  // Modals
  const [editingEinvoice, setEditingEinvoice] = useState<SalesInvoice | null>(null);
  const [einvoiceNum, setEinvoiceNum] = useState('');
  const [einvoiceSymbol, setEinvoiceSymbol] = useState('1C26TBB');
  const [einvoiceDate, setEinvoiceDate] = useState(new Date().toISOString().split('T')[0]);
  const [einvoiceProvider, setEinvoiceProvider] = useState('MISA meInvoice');

  const [reviewingQuote, setReviewingQuote] = useState<AccountingQuotationReview | null>(null);
  const [reviewDecision, setReviewDecision] = useState<'Đạt tiêu chuẩn' | 'Cần duyệt ngoại lệ' | 'Đã duyệt' | 'Từ chối'>('Đã duyệt');
  const [reviewNoteText, setReviewNoteText] = useState('');

  const [isExportVatModalOpen, setIsExportVatModalOpen] = useState(false);
  const [vatQuarter, setVatQuarter] = useState('Quý 1/2026');

  // Filter Sales Invoices
  const filteredSalesInvoices = useMemo(() => {
    return salesInvoices.filter((inv) => {
      const matchSearch =
        inv.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inv.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (inv.customerTaxId && inv.customerTaxId.includes(searchTerm)) ||
        (inv.einvoiceNumber && inv.einvoiceNumber.includes(searchTerm));
      const matchPayment =
        selectedPaymentStatus === 'all' || inv.status === selectedPaymentStatus;
      const matchEinvoice =
        selectedEinvoiceStatus === 'all' ||
        (selectedEinvoiceStatus === 'issued' && inv.einvoiceNumber) ||
        (selectedEinvoiceStatus === 'unissued' && !inv.einvoiceNumber);
      return matchSearch && matchPayment && matchEinvoice;
    });
  }, [salesInvoices, searchTerm, selectedPaymentStatus, selectedEinvoiceStatus]);

  // Filter Purchase Invoices
  const filteredPurchaseInvoices = useMemo(() => {
    return purchaseInvoices.filter((inv) => {
      const matchSearch =
        inv.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inv.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        inv.supplierInvoiceNumber.includes(searchTerm);
      const matchPayment =
        selectedPaymentStatus === 'all' || inv.status === selectedPaymentStatus;
      return matchSearch && matchPayment;
    });
  }, [purchaseInvoices, searchTerm, selectedPaymentStatus]);

  // Filter Quotation Reviews
  const filteredQuotationReviews = useMemo(() => {
    return quotationReviews.filter((q) => {
      const matchSearch =
        q.quotationCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        q.createdByStaff.toLowerCase().includes(searchTerm.toLowerCase());
      return matchSearch;
    });
  }, [quotationReviews, searchTerm]);

  // Hàng đợi Cần lập hóa đơn (Billing Queue tính toán trực tiếp từ chuỗi dữ liệu)
  const billingQueueItems = useMemo(() => {
    const list: Array<{
      id: string;
      sourceType: 'order' | 'milestone' | 'acceptance';
      sourceLabel: string;
      sourceCode: string;
      customerName: string;
      customerCode: string;
      description: string;
      amount: number;
      date: string;
      orderId?: string;
      contractId?: string;
      milestoneId?: string;
    }> = [];

    // 1. Đơn hàng đã giao / đã xuất kho nhưng chưa lập hóa đơn
    orders.forEach((o) => {
      const isDeliveredOrShipped = o.logisticsStatus === 'Đã giao' || o.logisticsStatus === 'Đã xuất kho' || o.status === 'Đã duyệt';
      const hasInvoice = salesInvoices.some((inv) => inv.orderId === o.id || inv.orderCode === o.code);
      if (isDeliveredOrShipped && !hasInvoice) {
        list.push({
          id: `queue-order-${o.id}`,
          sourceType: 'order',
          sourceLabel: 'Đơn hàng (Kho / Logistics)',
          sourceCode: o.code,
          customerName: o.customerName,
          customerCode: o.customerCode,
          description: `Giao hàng hoàn tất (${o.items.length} mặt hàng) - Trạng thái: ${o.logisticsStatus || o.status}`,
          amount: o.totalAmount,
          date: o.orderDate,
          orderId: o.id,
        });
      }
    });

    // 2. Mốc hợp đồng đến hạn chưa lập hóa đơn
    contracts.forEach((c) => {
      c.paymentMilestones.forEach((m) => {
        if (!m.invoiceCode && !salesInvoices.some((inv) => inv.contractId === c.id && inv.milestoneTitle === m.title)) {
          list.push({
            id: `queue-ms-${c.id}-${m.id}`,
            sourceType: 'milestone',
            sourceLabel: 'Hợp đồng (Kỳ thanh toán)',
            sourceCode: `${c.contractNumber} (${m.title})`,
            customerName: c.customerName,
            customerCode: c.customerCode,
            description: `Kỳ thanh toán ${m.percentage}% - Hợp đồng: ${c.title}`,
            amount: m.amount,
            date: m.dueDate,
            contractId: c.id,
            milestoneId: m.id,
          });
        }
      });
    });

    // 3. Biên bản nghiệm thu kỹ thuật đã ký
    acceptanceCertificates.forEach((acc) => {
      const hasInvoice = salesInvoices.some((inv) => inv.chain?.acceptanceCode === acc.code || inv.milestoneTitle?.includes(acc.code));
      if (acc.status === 'Đã ký nghiệm thu' && !hasInvoice) {
        list.push({
          id: `queue-acc-${acc.id}`,
          sourceType: 'acceptance',
          sourceLabel: 'Nghiệm thu (Kỹ thuật)',
          sourceCode: acc.code,
          customerName: acc.customerName,
          customerCode: 'KH-KT',
          description: `Biên bản nghiệm thu dự án ${acc.projectCode || ''}: ${acc.title}`,
          amount: acc.totalValue,
          date: acc.signedDate || acc.acceptanceDate,
        });
      }
    });

    return list;
  }, [orders, contracts, acceptanceCertificates, salesInvoices]);

  const filteredBillingQueue = useMemo(() => {
    return billingQueueItems.filter((item) => {
      return (
        item.sourceCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  }, [billingQueueItems, searchTerm]);

  // Statistics for sales invoices
  const salesStats = useMemo(() => {
    const totalAmount = salesInvoices.reduce((sum, inv) => sum + inv.totalAmount, 0);
    const paidAmount = salesInvoices.reduce((sum, inv) => sum + inv.paidAmount, 0);
    const remainingAmount = salesInvoices.reduce((sum, inv) => sum + inv.remainingAmount, 0);
    const issuedEinvoiceCount = salesInvoices.filter((inv) => inv.einvoiceNumber).length;
    return {
      totalAmount,
      paidAmount,
      remainingAmount,
      issuedEinvoiceCount,
      unissuedCount: salesInvoices.length - issuedEinvoiceCount,
    };
  }, [salesInvoices]);

  // Handle save E-Invoice Details
  const handleSaveEinvoice = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEinvoice) return;
    updateEInvoiceDetails(editingEinvoice.id, {
      einvoiceNumber: einvoiceNum,
      einvoiceSymbol,
      einvoiceIssuedDate: einvoiceDate,
      einvoiceFileUrl: 'https://demo.einvoice.vn/download/sample.pdf',
    });
    setEditingEinvoice(null);
  };

  // Handle submit review quote
  const handleSubmitReviewQuote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewingQuote) return;
    reviewQuotationFinancial(reviewingQuote.id, reviewDecision, reviewNoteText);
    setReviewingQuote(null);
  };

  return (
    <div className="space-y-6">
      {/* 1. Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
              Kế toán Doanh thu & Chi phí
            </span>
            <span className="text-xs text-slate-400">Góc nhìn Kế toán & Quản trị HĐĐT</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-1">
            Hóa đơn & Báo giá (Invoices & Quotations)
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Theo dõi hóa đơn bán ra (Sales), hóa đơn mua vào (Logistics), đồng bộ số hóa đơn điện tử và thẩm duyệt điều khoản tài chính báo giá.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsExportVatModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-sm"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            Bảng kê thuế GTGT (01-1/GTGT)
          </button>
          <button
            onClick={() =>
              showToast('Xuất danh sách', 'Đã xuất dữ liệu hóa đơn ra định dạng bảng tính Excel')
            }
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors shadow-sm"
          >
            <Download className="w-4 h-4" />
            Xuất Excel
          </button>
        </div>
      </div>

      {/* 2. Main Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 rounded-t-xl">
        <button
          onClick={() => setActiveMainTab('invoices')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeMainTab === 'invoices'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <FileText className="w-4 h-4" />
          Quản lý Hóa đơn (Bán ra & Mua vào)
          <span className="ml-1.5 px-2 py-0.5 text-xs rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
            {salesInvoices.length + purchaseInvoices.length}
          </span>
        </button>

        <button
          onClick={() => setActiveMainTab('quotations')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeMainTab === 'quotations'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Percent className="w-4 h-4" />
          Thẩm định Báo giá & Biên lợi nhuận
          <span className="ml-1.5 px-2 py-0.5 text-xs rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
            {quotationReviews.length}
          </span>
        </button>
      </div>

      {/* ======================================================== */}
      {/* TAB 1: QUẢN LÝ HÓA ĐƠN */}
      {/* ======================================================== */}
      {activeMainTab === 'invoices' && (
        <div className="space-y-6">
          {/* Subtabs: Hàng đợi Cần lập HĐ vs HĐ Bán ra vs HĐ Mua vào */}
          <div className="flex items-center gap-2 bg-slate-100 dark:bg-slate-900/60 p-1 rounded-lg w-fit">
            <button
              onClick={() => setInvoiceSubTab('queue')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-all flex items-center gap-1.5 ${
                invoiceSubTab === 'queue'
                  ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              Cần lập hóa đơn ({billingQueueItems.length})
            </button>
            <button
              onClick={() => setInvoiceSubTab('sales')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-all ${
                invoiceSubTab === 'sales'
                  ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Hóa đơn Bán ra (Sales Invoices) ({salesInvoices.length})
            </button>
            <button
              onClick={() => setInvoiceSubTab('purchase')}
              className={`px-4 py-1.5 text-xs font-semibold rounded-md transition-all ${
                invoiceSubTab === 'purchase'
                  ? 'bg-white dark:bg-slate-800 text-emerald-600 dark:text-emerald-400 shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Hóa đơn Mua vào (Purchase Invoices) ({purchaseInvoices.length})
            </button>
          </div>

          {/* ==================== SUBTAB: BILLING QUEUE ==================== */}
          {invoiceSubTab === 'queue' ? (
            <div className="space-y-4">
              <div className="bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/40 p-4 rounded-xl flex items-start gap-3">
                <Clock className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-amber-900 dark:text-amber-200 space-y-1">
                  <p className="font-bold">Hàng đợi Cần lập hóa đơn (Zero re-entry / Không nhập lại dữ liệu):</p>
                  <p>
                    Hệ thống tự động quét từ Đơn hàng đã giao thành công (Logistics/Kho), Kỳ thanh toán hợp đồng đến hạn (Sales) và Biên bản nghiệm thu dự án (Kỹ thuật). Nhấn <strong>"Lập Hóa Đơn (1-Click)"</strong> để phát hành hóa đơn kế thừa toàn bộ chứng từ gốc sang hóa đơn bán và HĐĐT.
                  </p>
                </div>
              </div>

              {/* Stats Cards for Queue */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
                <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <span className="text-xs font-medium text-slate-500">Chờ lập hóa đơn</span>
                  <div className="text-lg font-bold text-amber-600 dark:text-amber-400 mt-1">
                    {billingQueueItems.length} chứng từ
                  </div>
                  <span className="text-[11px] text-slate-400">Đã đủ điều kiện xuất</span>
                </div>
                <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <span className="text-xs font-medium text-slate-500">Tổng giá trị dự kiến</span>
                  <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                    {billingQueueItems.reduce((s, i) => s + i.amount, 0).toLocaleString('vi-VN')} đ
                  </div>
                  <span className="text-[11px] text-slate-400">Sẽ ghi nhận doanh số</span>
                </div>
                <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <span className="text-xs font-medium text-slate-500">Từ Đơn hàng đã giao</span>
                  <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                    {billingQueueItems.filter((i) => i.sourceType === 'order').length} đơn
                  </div>
                  <span className="text-[11px] text-emerald-500">Logistics & Kho xác nhận</span>
                </div>
                <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                  <span className="text-xs font-medium text-slate-500">Từ Hợp đồng / Nghiệm thu</span>
                  <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
                    {billingQueueItems.filter((i) => i.sourceType !== 'order').length} mốc/biên bản
                  </div>
                  <span className="text-[11px] text-blue-500">Đến kỳ đối soát thanh toán</span>
                </div>
              </div>

              {/* Search Bar for Queue */}
              <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between">
                <div className="flex-1 relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Tìm theo mã chứng từ, tên khách hàng, diễn giải..."
                    className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Table: Queue */}
              <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
                    <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                      <tr>
                        <th className="px-4 py-3.5">Nguồn dữ liệu</th>
                        <th className="px-4 py-3.5">Mã chứng từ gốc</th>
                        <th className="px-4 py-3.5">Khách hàng</th>
                        <th className="px-4 py-3.5">Nội dung / Nghiệp vụ</th>
                        <th className="px-3 py-3.5 text-right">Giá trị hóa đơn</th>
                        <th className="px-3 py-3.5 text-center">Ngày hoàn tất</th>
                        <th className="px-4 py-3.5 text-center">Thao tác</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                      {filteredBillingQueue.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="px-4 py-8 text-center text-slate-400">
                            Không có chứng từ nào chờ lập hóa đơn. Mọi giao dịch đã được phát hành đầy đủ!
                          </td>
                        </tr>
                      ) : (
                        filteredBillingQueue.map((item) => (
                          <tr key={item.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                            <td className="px-4 py-3.5">
                              <span
                                className={`px-2 py-0.5 rounded text-xs font-semibold ${
                                  item.sourceType === 'order'
                                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300'
                                    : item.sourceType === 'milestone'
                                    ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300'
                                    : 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300'
                                }`}
                              >
                                {item.sourceLabel}
                              </span>
                            </td>
                            <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">
                              {item.sourceCode}
                            </td>
                            <td className="px-4 py-3.5 font-medium text-slate-900 dark:text-white">
                              {item.customerName}
                            </td>
                            <td className="px-4 py-3.5 text-xs text-slate-600 dark:text-slate-300 max-w-xs truncate">
                              {item.description}
                            </td>
                            <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                              {item.amount.toLocaleString('vi-VN')} đ
                            </td>
                            <td className="px-3 py-3.5 text-center text-xs font-mono text-slate-500">
                              {item.date}
                            </td>
                            <td className="px-4 py-3.5 text-center">
                              <div className="flex items-center justify-center gap-2">
                                <button
                                  onClick={() => {
                                    if (item.sourceType === 'order' && item.orderId) {
                                      createInvoiceFromOrder(item.orderId);
                                      setInvoiceSubTab('sales');
                                    } else if (item.sourceType === 'milestone' && item.contractId && item.milestoneId) {
                                      createInvoiceFromMilestone(item.contractId, item.milestoneId);
                                      setInvoiceSubTab('sales');
                                    } else {
                                      showToast('Lập hóa đơn thành công', `Đã lập hóa đơn từ biên bản ${item.sourceCode}.`);
                                      setInvoiceSubTab('sales');
                                    }
                                  }}
                                  className="px-3 py-1.5 text-xs font-semibold rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition-colors flex items-center gap-1"
                                >
                                  <Sparkles className="w-3.5 h-3.5" />
                                  Lập Hóa Đơn (1-Click)
                                </button>
                                <button
                                  onClick={() => {
                                    const reason = window.prompt(
                                      `Nhập lý do hoãn / bỏ qua không lập hóa đơn cho ${item.sourceCode}:`,
                                      'Điều chỉnh kỳ thanh toán / Đợi nghiệm thu bổ sung'
                                    );
                                    if (reason) {
                                      showToast(
                                        'Đã bỏ qua chứng từ',
                                        `Chứng từ ${item.sourceCode} đã lưu lý do kiểm toán: "${reason}".`,
                                        'warning'
                                      );
                                    }
                                  }}
                                  className="px-2 py-1.5 text-xs font-medium rounded-lg text-slate-500 hover:text-red-600 dark:hover:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                                  title="Bỏ qua kèm lý do kiểm toán"
                                >
                                  Bỏ qua
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ) : (
            // ==================== SUBTABS: SALES & PURCHASE ====================
            <>
              {/* Stats Cards (For Sales Invoices) */}
              {invoiceSubTab === 'sales' ? (
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-medium text-slate-500">Tổng doanh số HĐ</span>
                    <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                      {salesStats.totalAmount.toLocaleString('vi-VN')} đ
                    </div>
                    <span className="text-[11px] text-slate-400">{salesInvoices.length} hóa đơn bán</span>
                  </div>

                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-medium text-slate-500">Đã thu thực tế</span>
                    <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                      {salesStats.paidAmount.toLocaleString('vi-VN')} đ
                    </div>
                    <span className="text-[11px] text-slate-400">Tiền đã về tài khoản</span>
                  </div>

                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-medium text-slate-500">Còn phải thu</span>
                    <div className="text-lg font-bold text-red-600 dark:text-red-400 mt-1">
                      {salesStats.remainingAmount.toLocaleString('vi-VN')} đ
                    </div>
                    <span className="text-[11px] text-red-500">Chưa đối trừ / thanh toán</span>
                  </div>

                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-medium text-slate-500">Đã phát hành HĐĐT</span>
                    <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
                      {salesStats.issuedEinvoiceCount} HĐ
                    </div>
                    <span className="text-[11px] text-blue-500">Đã có số & ký số</span>
                  </div>

                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-medium text-slate-500">Chưa cấp số HĐĐT</span>
                    <div className="text-lg font-bold text-amber-600 dark:text-amber-400 mt-1">
                      {salesStats.unissuedCount} HĐ
                    </div>
                    <span className="text-[11px] text-amber-500">Cần phát hành từ phần mềm</span>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-medium text-slate-500">Tổng hóa đơn mua</span>
                    <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                      {purchaseInvoices
                        .reduce((sum, inv) => sum + inv.totalAmount, 0)
                        .toLocaleString('vi-VN')}{' '}
                      đ
                    </div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-medium text-slate-500">Đã thanh toán</span>
                    <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                      {purchaseInvoices
                        .reduce((sum, inv) => sum + inv.paidAmount, 0)
                        .toLocaleString('vi-VN')}{' '}
                      đ
                    </div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-medium text-slate-500">Còn nợ NCC</span>
                    <div className="text-lg font-bold text-red-600 dark:text-red-400 mt-1">
                      {purchaseInvoices
                        .reduce((sum, inv) => sum + inv.remainingAmount, 0)
                        .toLocaleString('vi-VN')}{' '}
                      đ
                    </div>
                  </div>
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
                    <span className="text-xs font-medium text-slate-500">Đối chiếu 3 bên</span>
                    <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
                      {purchaseInvoices.filter((i) => i.threeWayMatchStatus === 'Khớp').length} /{' '}
                      {purchaseInvoices.length} khớp
                    </div>
                  </div>
                </div>
              )}

              {/* Filter Bar */}
              <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
                <div className="flex-1 w-full md:w-auto relative">
                  <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Tìm theo số HĐ, đối tác, MST, số HĐĐT..."
                    className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div className="flex items-center gap-2.5 w-full md:w-auto">
                  <select
                    value={selectedPaymentStatus}
                    onChange={(e) => setSelectedPaymentStatus(e.target.value)}
                    className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
                  >
                    <option value="all">Tất cả thanh toán</option>
                    <option value="Chưa thanh toán">Chưa thanh toán</option>
                    <option value="Thanh toán một phần">Thanh toán một phần</option>
                    <option value="Đã thanh toán">Đã thanh toán đủ</option>
                  </select>

                  {invoiceSubTab === 'sales' && (
                    <select
                      value={selectedEinvoiceStatus}
                      onChange={(e) => setSelectedEinvoiceStatus(e.target.value)}
                      className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
                    >
                      <option value="all">Tất cả HĐĐT</option>
                      <option value="issued">Đã phát hành HĐĐT</option>
                      <option value="unissued">Chưa phát hành HĐĐT</option>
                    </select>
                  )}
                </div>
              </div>

              {/* Table: Sales Invoices */}
              {invoiceSubTab === 'sales' ? (
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
                  <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th className="px-4 py-3.5">Số HĐ nội bộ</th>
                      <th className="px-3 py-3.5">Ngày xuất</th>
                      <th className="px-4 py-3.5">Khách hàng</th>
                      <th className="px-3 py-3.5 text-right">Trước thuế</th>
                      <th className="px-3 py-3.5 text-right">Thuế VAT (8-10%)</th>
                      <th className="px-3 py-3.5 text-right">Tổng thanh toán</th>
                      <th className="px-3 py-3.5 text-right">Còn nợ</th>
                      <th className="px-3 py-3.5 text-center">Trạng thái TT</th>
                      <th className="px-3 py-3.5 text-center">Hóa đơn điện tử</th>
                      <th className="px-4 py-3.5 text-center">Hành động</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                    {filteredSalesInvoices.map((inv) => (
                      <tr
                        key={inv.id}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors"
                      >
                        <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">
                          {inv.invoiceNumber}
                        </td>
                        <td className="px-3 py-3.5 text-xs text-slate-500 font-mono">
                          {inv.issueDate}
                        </td>
                        <td className="px-4 py-3.5">
                          <div className="font-medium text-slate-900 dark:text-white">
                            {inv.customerName}
                          </div>
                          <div className="text-xs text-slate-400">MST: {inv.customerTaxId || 'Chưa cập nhật'}</div>
                        </td>
                        <td className="px-3 py-3.5 text-right text-xs">
                          {inv.subTotal.toLocaleString('vi-VN')} đ
                        </td>
                        <td className="px-3 py-3.5 text-right text-xs text-slate-500">
                          {inv.taxAmount.toLocaleString('vi-VN')} đ
                        </td>
                        <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                          {inv.totalAmount.toLocaleString('vi-VN')} đ
                        </td>
                        <td className="px-3 py-3.5 text-right font-bold text-red-600 dark:text-red-400">
                          {inv.remainingAmount > 0
                            ? `${inv.remainingAmount.toLocaleString('vi-VN')} đ`
                            : '-'}
                        </td>
                        <td className="px-3 py-3.5 text-center">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                              inv.status === 'Đã thanh toán'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300'
                                : inv.status === 'Thanh toán một phần'
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
                                : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                            }`}
                          >
                            {inv.status}
                          </span>
                        </td>
                        <td className="px-3 py-3.5 text-center">
                          {inv.einvoiceNumber ? (
                            <div className="inline-flex flex-col items-center">
                              <span className="px-2 py-0.5 rounded text-[11px] font-mono font-bold bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300">
                                {inv.einvoiceNumber}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono mt-0.5">
                                Ký hiệu: {inv.einvoiceSymbol || '1C26TBB'}
                              </span>
                            </div>
                          ) : (
                            <span className="px-2 py-0.5 rounded text-xs text-slate-400 bg-slate-100 dark:bg-slate-700">
                              Chưa cấp số
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3.5 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => {
                                setEditingEinvoice(inv);
                                setEinvoiceNum(inv.einvoiceNumber || `0000${Math.floor(100 + Math.random() * 900)}`);
                                setEinvoiceSymbol(inv.einvoiceSymbol || '1C26TBB');
                                setEinvoiceDate(inv.issueDate || new Date().toISOString().split('T')[0]);
                              }}
                              className="px-2.5 py-1 text-xs font-medium rounded-lg border border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 transition-colors flex items-center gap-1"
                            >
                              <Upload className="w-3 h-3 text-emerald-600" />
                              HĐĐT
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            // Table: Purchase Invoices
            <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
                  <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                    <tr>
                      <th className="px-4 py-3.5">Mã HĐ mua</th>
                      <th className="px-3 py-3.5">Số HĐ NCC</th>
                      <th className="px-3 py-3.5">Ngày HĐ</th>
                      <th className="px-4 py-3.5">Nhà cung cấp</th>
                      <th className="px-3 py-3.5 text-right">Tổng tiền</th>
                      <th className="px-3 py-3.5 text-right">Đã thanh toán</th>
                      <th className="px-3 py-3.5 text-right">Còn nợ NCC</th>
                      <th className="px-3 py-3.5 text-center">Khớp 3 bên</th>
                      <th className="px-3 py-3.5 text-center">Trạng thái</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                    {filteredPurchaseInvoices.map((inv) => (
                      <tr
                        key={inv.id}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors"
                      >
                        <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">
                          {inv.code}
                        </td>
                        <td className="px-3 py-3.5 font-mono text-xs text-blue-600">
                          {inv.supplierInvoiceNumber}
                        </td>
                        <td className="px-3 py-3.5 text-xs text-slate-500 font-mono">
                          {inv.invoiceDate}
                        </td>
                        <td className="px-4 py-3.5">
                          <div className="font-medium text-slate-900 dark:text-white">
                            {inv.supplierName}
                          </div>
                          <div className="text-xs text-slate-400">PO: {inv.purchaseOrderCode}</div>
                        </td>
                        <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                          {inv.totalAmount.toLocaleString('vi-VN')} đ
                        </td>
                        <td className="px-3 py-3.5 text-right font-medium text-emerald-600">
                          {inv.paidAmount.toLocaleString('vi-VN')} đ
                        </td>
                        <td className="px-3 py-3.5 text-right font-bold text-red-600">
                          {inv.remainingAmount > 0
                            ? `${inv.remainingAmount.toLocaleString('vi-VN')} đ`
                            : '-'}
                        </td>
                        <td className="px-3 py-3.5 text-center">
                          <span
                            className={`px-2 py-0.5 rounded text-xs font-semibold ${
                              inv.threeWayMatchStatus === 'Khớp'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300'
                                : 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
                            }`}
                          >
                            {inv.threeWayMatchStatus}
                          </span>
                        </td>
                        <td className="px-3 py-3.5 text-center">
                          <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                            {inv.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
            </>
          )}
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: THẨM ĐỊNH BÁO GIÁ DƯỚI GÓC NHÌN KẾ TOÁN */}
      {/* ======================================================== */}
      {activeMainTab === 'quotations' && (
        <div className="space-y-6">
          <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 p-4 rounded-xl text-xs text-amber-900 dark:text-amber-300 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Quy chế Thẩm định Tài chính Báo giá:</span>
              <p className="mt-0.5">
                Các báo giá có biên lợi nhuận gộp dưới 20% hoặc có điều khoản công nợ vượt 30 ngày cần
                Kế toán trưởng / Giám đốc Tài chính phê duyệt trước khi nhân viên kinh doanh phát hành chính thức cho khách hàng.
              </p>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
                <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="px-4 py-3.5">Mã Báo giá</th>
                    <th className="px-3 py-3.5">Ngày lập</th>
                    <th className="px-4 py-3.5">Khách hàng & Người lập</th>
                    <th className="px-3 py-3.5 text-right">Tổng giá trị</th>
                    <th className="px-3 py-3.5 text-right">Giá vốn ước tính</th>
                    <th className="px-3 py-3.5 text-right">Lợi nhuận gộp</th>
                    <th className="px-3 py-3.5 text-center">Biên LNG (%)</th>
                    <th className="px-4 py-3.5">Điều khoản công nợ</th>
                    <th className="px-3 py-3.5 text-center">Duyệt tài chính</th>
                    <th className="px-4 py-3.5 text-center">Hành động</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {filteredQuotationReviews.map((q) => (
                    <tr
                      key={q.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors"
                    >
                      <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">
                        {q.quotationCode}
                      </td>
                      <td className="px-3 py-3.5 text-xs font-mono text-slate-500">{q.date}</td>
                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-900 dark:text-white">
                          {q.customerName}
                        </div>
                        <div className="text-xs text-slate-400">
                          {q.createdByStaff} ({q.department})
                        </div>
                      </td>
                      <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                        {q.totalValue.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-3 py-3.5 text-right text-xs text-slate-500">
                        {q.estimatedCost.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-3 py-3.5 text-right font-medium text-emerald-600">
                        {q.estimatedGrossMargin.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-3 py-3.5 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-xs font-bold font-mono ${
                            q.marginPercentage >= 25
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                              : q.marginPercentage >= 20
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300'
                              : 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300'
                          }`}
                        >
                          {q.marginPercentage.toFixed(1)}%
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-xs text-slate-600 dark:text-slate-400 max-w-xs truncate">
                        {q.paymentTerms}
                      </td>
                      <td className="px-3 py-3.5 text-center">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                            q.financialStatus === 'Đã duyệt' || q.financialStatus === 'Đạt tiêu chuẩn'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300'
                              : q.financialStatus === 'Cần duyệt ngoại lệ'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
                              : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                          }`}
                        >
                          {q.financialStatus}
                        </span>
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        <button
                          onClick={() => {
                            setReviewingQuote(q);
                            setReviewDecision(q.financialStatus);
                            setReviewNoteText(q.reviewNotes || '');
                          }}
                          className="px-2.5 py-1 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors"
                        >
                          Thẩm định
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 1: CẬP NHẬT HÓA ĐƠN ĐIỆN TỬ NGOÀI */}
      {/* ======================================================== */}
      {editingEinvoice && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <form
            onSubmit={handleSaveEinvoice}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Upload className="w-5 h-5 text-emerald-600" />
                  Cập Nhật Hóa Đơn Điện Tử
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Hóa đơn nội bộ: {editingEinvoice.invoiceNumber} - Khách hàng:{' '}
                  {editingEinvoice.customerName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setEditingEinvoice(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Số hóa đơn điện tử *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="ví dụ: 0000123"
                    value={einvoiceNum}
                    onChange={(e) => setEinvoiceNum(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono font-bold text-sm outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Ký hiệu mẫu số *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="ví dụ: 1C26TBB"
                    value={einvoiceSymbol}
                    onChange={(e) => setEinvoiceSymbol(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Ngày ký số / phát hành
                  </label>
                  <input
                    type="date"
                    value={einvoiceDate}
                    onChange={(e) => setEinvoiceDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Nhà cung cấp HĐĐT
                  </label>
                  <select
                    value={einvoiceProvider}
                    onChange={(e) => setEinvoiceProvider(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  >
                    <option value="MISA meInvoice">MISA meInvoice</option>
                    <option value="VNPT Einvoice">VNPT Einvoice</option>
                    <option value="Viettel Sinvoice">Viettel Sinvoice</option>
                    <option value="Bkav eHoadon">Bkav eHoadon</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Đính kèm tệp PDF / XML hóa đơn điện tử
                </label>
                <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-lg p-3 text-center cursor-pointer hover:border-emerald-500">
                  <Upload className="w-5 h-5 mx-auto text-slate-400 mb-1" />
                  <span className="text-xs text-slate-500">
                    Bấm để tải lên file .pdf hoặc .xml từ phần mềm xuất HĐĐT
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setEditingEinvoice(null)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Lưu thông tin HĐĐT
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 2: THẨM ĐỊNH TÀI CHÍNH BÁO GIÁ */}
      {/* ======================================================== */}
      {reviewingQuote && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <form
            onSubmit={handleSubmitReviewQuote}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  Thẩm Định Tài Chính Báo Giá
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Báo giá: {reviewingQuote.quotationCode} - {reviewingQuote.customerName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setReviewingQuote(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/60 p-3 rounded-xl grid grid-cols-3 gap-2 text-center text-xs">
              <div>
                <span className="text-slate-400 block">Tổng giá trị:</span>
                <span className="font-bold text-slate-900 dark:text-white text-sm">
                  {reviewingQuote.totalValue.toLocaleString('vi-VN')} đ
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Lợi nhuận gộp:</span>
                <span className="font-bold text-emerald-600 text-sm">
                  {reviewingQuote.estimatedGrossMargin.toLocaleString('vi-VN')} đ
                </span>
              </div>
              <div>
                <span className="text-slate-400 block">Biên LNG:</span>
                <span className="font-bold font-mono text-sm text-blue-600">
                  {reviewingQuote.marginPercentage.toFixed(1)}%
                </span>
              </div>
            </div>

            {reviewingQuote.riskWarnings.length > 0 && (
              <div className="p-3 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800/40 rounded-xl space-y-1 text-xs text-red-700 dark:text-red-300">
                <span className="font-bold flex items-center gap-1">
                  <AlertTriangle className="w-3.5 h-3.5 text-red-600" /> Cảnh báo rủi ro tài chính:
                </span>
                <ul className="list-disc pl-4 space-y-0.5">
                  {reviewingQuote.riskWarnings.map((w, idx) => (
                    <li key={idx}>{w}</li>
                  ))}
                </ul>
              </div>
            )}

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Kết luận phê duyệt của Kế toán/Tài chính *
                </label>
                <select
                  value={reviewDecision}
                  onChange={(e) =>
                    setReviewDecision(
                      e.target.value as 'Đạt tiêu chuẩn' | 'Cần duyệt ngoại lệ' | 'Đã duyệt' | 'Từ chối'
                    )
                  }
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-medium outline-none"
                >
                  <option value="Đã duyệt">Đã duyệt (Chấp thuận ban hành báo giá)</option>
                  <option value="Đạt tiêu chuẩn">Đạt tiêu chuẩn tài chính</option>
                  <option value="Cần duyệt ngoại lệ">
                    Cần duyệt ngoại lệ (Chuyển Giám đốc phê chuẩn)
                  </option>
                  <option value="Từ chối">Từ chối (Yêu cầu điều chỉnh lại giá / điều khoản)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Ý kiến thẩm duyệt & Đề xuất điều chỉnh
                </label>
                <textarea
                  rows={3}
                  value={reviewNoteText}
                  onChange={(e) => setReviewNoteText(e.target.value)}
                  placeholder="Ghi rõ lý do duyệt, yêu cầu rút ngắn ngày công nợ hoặc tăng tỷ lệ tạm ứng..."
                  className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setReviewingQuote(null)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Xác nhận thẩm duyệt
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 3: XUẤT BẢNG KÊ THUẾ GTGT 01-1 VÀ 01-2 */}
      {/* ======================================================== */}
      {isExportVatModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-emerald-600" />
                  Bảng Kê Hóa Đơn Thuế GTGT
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Xuất dữ liệu nộp tờ khai thuế hoặc nhập vào ứng dụng HTKK
                </p>
              </div>
              <button
                onClick={() => setIsExportVatModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Chọn kỳ tính thuế
                </label>
                <select
                  value={vatQuarter}
                  onChange={(e) => setVatQuarter(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                >
                  <option value="Quý 1/2026">Quý 1/2026 (01/01 - 31/03/2026)</option>
                  <option value="Quý 2/2026">Quý 2/2026 (01/04 - 30/06/2026)</option>
                  <option value="Tháng 03/2026">Tháng 03/2026</option>
                </select>
              </div>

              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={() => {
                    showToast('Xuất thành công', `Đã xuất Bảng kê bán ra Mẫu 01-1/GTGT cho ${vatQuarter}`);
                    setIsExportVatModalOpen(false);
                  }}
                  className="w-full py-2.5 px-4 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800 font-semibold text-xs flex items-center justify-between"
                >
                  <span>1. Bảng kê bán ra (Mẫu 01-1/GTGT)</span>
                  <Download className="w-4 h-4" />
                </button>

                <button
                  type="button"
                  onClick={() => {
                    showToast('Xuất thành công', `Đã xuất Bảng kê mua vào Mẫu 01-2/GTGT cho ${vatQuarter}`);
                    setIsExportVatModalOpen(false);
                  }}
                  className="w-full py-2.5 px-4 rounded-lg bg-blue-50 dark:bg-blue-950/40 text-blue-800 dark:text-blue-300 border border-blue-300 dark:border-blue-800 font-semibold text-xs flex items-center justify-between"
                >
                  <span>2. Bảng kê mua vào (Mẫu 01-2/GTGT)</span>
                  <Download className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsExportVatModalOpen(false)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
