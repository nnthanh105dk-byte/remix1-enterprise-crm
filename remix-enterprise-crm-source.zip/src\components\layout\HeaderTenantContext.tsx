/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * A+ CRM — HEADER TENANT CONTEXT & SWITCHER
 * Trực quan hóa 5 câu hỏi cốt lõi:
 * 1. Tôi đang ở công ty nào?
 * 2. Tôi đang thuộc phòng ban nào?
 * 3. Tôi đang có vai trò gì?
 * 4. Tôi được phép làm gì?
 * 5. Dữ liệu tôi đang xem thuộc Database nào?
 * 
 * Hỗ trợ chuyển đổi Tenant (Tenant Switching) tức thì cho User đa tổ chức.
 */

import React, { useState, useRef, useEffect } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import { useCRM } from '../../context/CRMContext';
import {
  Building2,
  Database,
  ChevronDown,
  CheckCircle2,
  Layers,
  ShieldCheck,
  Briefcase,
  Users,
  Server,
  ArrowRightLeft,
  ExternalLink,
  Lock,
} from 'lucide-react';

export const HeaderTenantContext: React.FC = () => {
  const {
    sessionContext,
    currentCompany,
    currentMember,
    currentAccount,
    userMemberships,
    allCompanies,
    allMemberships,
    switchTenant,
  } = useMultiTenant();

  const { setActiveModule, showToast } = useCRM();

  const [isOpen, setIsOpen] = useState(false);
  const popoverRef = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const tenantName = sessionContext?.tenantName || currentCompany?.name || 'A+ Technology';
  const tenantCode = sessionContext?.tenantCode || currentCompany?.code || 'APLUS';
  const dbName = sessionContext?.database || currentCompany?.database || 'DB_APLUS';
  const deptName = sessionContext?.departmentName || 'Phòng Kinh Doanh (Sales)';
  const roleTitle = sessionContext?.roleTitle || 'Sales Executive';
  const primaryScope = sessionContext?.primaryScope || 'OWN';
  const displayId = sessionContext?.displayId || `${tenantCode}-SALE-0001`;

  // Danh sách các Tenant mà User hiện tại có Membership
  const availableMemberships = allMemberships.filter(
    (m) => m.userId === currentAccount?.id && m.status === 'active'
  );

  const handleSwitch = (targetTenantId: string, companyName: string, targetDb: string) => {
    if (targetTenantId === currentCompany?.id) return;
    const ok = switchTenant(targetTenantId);
    setIsOpen(false);
    if (ok) {
      showToast(
        'Đã đổi không gian làm việc',
        `Chuyển thành công sang ${companyName} • Kết nối CSDL: ${targetDb}`,
        'info'
      );
    }
  };

  const handleOpenArchitecture = () => {
    setIsOpen(false);
    setActiveModule('system-architecture');
  };

  return (
    <div className="relative shrink-0 hidden md:block" ref={popoverRef}>
      {/* Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50/80 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-750 text-slate-800 dark:text-slate-100 transition-colors cursor-pointer text-xs"
        title="Xem ngữ cảnh tổ chức & Chuyển Tenant"
      >
        <Building2 className="w-3.5 h-3.5 text-[#002659] dark:text-sky-400 shrink-0" />
        
        <div className="flex items-center gap-1.5 font-semibold tracking-tight text-left">
          <span className="max-w-[140px] truncate">{tenantName}</span>
          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold border border-emerald-200 dark:border-emerald-800">
            {dbName}
          </span>
        </div>

        <ChevronDown className="w-3 h-3 text-slate-400 shrink-0" />
      </button>

      {/* Popover Card answering 5 core questions */}
      {isOpen && (
        <div className="absolute right-0 mt-2 w-96 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl z-50 animate-in fade-in zoom-in-95 duration-150 overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
          {/* Header & Isolation Badge */}
          <div className="p-3.5 bg-gradient-to-r from-slate-900 to-[#002659] text-white">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-sky-300 flex items-center gap-1">
                <Server className="w-3 h-3" />
                Ngữ cảnh Đa Doanh Nghiệp (Multi-Tenant Context)
              </span>
              <span className="text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.2 rounded">
                Database Isolation: 100%
              </span>
            </div>
            <h4 className="font-bold text-sm text-white mt-1.5 truncate">
              {tenantName}
            </h4>
            <div className="text-[11px] text-slate-300 flex items-center gap-2 mt-0.5">
              <span>Mã: <strong className="text-white font-mono">{tenantCode}</strong></span>
              <span>•</span>
              <span>Định danh: <strong className="text-sky-300 font-mono">{displayId}</strong></span>
            </div>
          </div>

          {/* 5 Core Questions Visual Checklist */}
          <div className="p-3 space-y-2 bg-slate-50/50 dark:bg-slate-900/40 text-xs">
            <div className="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1">
              Phân giải 5 yếu tố vận hành:
            </div>

            {/* Q1 & Q5: Tenant & Database */}
            <div className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
              <Database className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-slate-500 text-[11px] block">1 & 5. Doanh nghiệp & CSDL độc lập:</span>
                <span className="font-semibold text-slate-900 dark:text-white">
                  {tenantName} ➔ <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold">{dbName}</span>
                </span>
              </div>
            </div>

            {/* Q2: Department */}
            <div className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
              <Briefcase className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-slate-500 text-[11px] block">2. Phòng ban trực thuộc:</span>
                <span className="font-semibold text-slate-900 dark:text-white">{deptName}</span>
              </div>
            </div>

            {/* Q3 & Q4: Role & Scope */}
            <div className="flex items-start gap-2 text-slate-700 dark:text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0 mt-0.5" />
              <div>
                <span className="text-slate-500 text-[11px] block">3 & 4. Vai trò & Phạm vi truy cập (Scope):</span>
                <div className="flex items-center gap-1.5 mt-0.5">
                  <span className="font-semibold text-slate-900 dark:text-white">{roleTitle}</span>
                  <span className="text-[10px] font-bold font-mono px-1.5 py-0.2 rounded bg-indigo-100 text-indigo-800 dark:bg-indigo-950 dark:text-indigo-300">
                    Scope: {primaryScope}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Tenant Switching Options */}
          <div className="p-3">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
                <ArrowRightLeft className="w-3 h-3 text-[#002659]" />
                Chuyển Đổi Không Gian Làm Việc ({availableMemberships.length > 0 ? availableMemberships.length : allCompanies.length})
              </span>
              <span className="text-[10px] text-slate-400">Section 16</span>
            </div>

            <div className="space-y-1.5 max-h-48 overflow-y-auto">
              {allCompanies.map((comp) => {
                const isCurrent = comp.id === currentCompany?.id;
                const hasMem = allMemberships.some(
                  (m) => m.userId === currentAccount?.id && m.tenantId === comp.id && m.status === 'active'
                );

                return (
                  <button
                    key={comp.id}
                    type="button"
                    onClick={() => handleSwitch(comp.id, comp.name, comp.database)}
                    className={`w-full text-left p-2 rounded-xl border flex items-center justify-between text-xs transition-colors cursor-pointer ${
                      isCurrent
                        ? 'bg-blue-50/80 dark:bg-sky-950/40 border-blue-200 dark:border-sky-800 text-[#002659] dark:text-sky-300'
                        : 'bg-white dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-200'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 font-bold truncate">
                        <span>{comp.name}</span>
                        <span className="text-[10px] font-mono text-slate-400">({comp.code})</span>
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">{comp.database}</span>
                        <span>•</span>
                        <span>{comp.plan}</span>
                      </div>
                    </div>

                    <div className="shrink-0 ml-2">
                      {isCurrent ? (
                        <span className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 flex items-center gap-0.5">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          Hiện tại
                        </span>
                      ) : (
                        <span className="text-[11px] font-semibold text-[#002659] dark:text-sky-400 hover:underline">
                          Chuyển sang →
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Footer CTA: Link to Section 22 Visual Architecture */}
          <div className="p-2.5 bg-slate-50 dark:bg-slate-850 flex items-center justify-between text-xs">
            <button
              type="button"
              onClick={handleOpenArchitecture}
              className="text-[#002659] dark:text-sky-300 font-bold hover:underline flex items-center gap-1.5 cursor-pointer text-[11px]"
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Xem Sơ Đồ Kiến Trúc Hệ Thống (Section 22)</span>
            </button>
            <span className="text-[10px] text-slate-400 font-mono">v3.4-core</span>
          </div>
        </div>
      )}
    </div>
  );
};
