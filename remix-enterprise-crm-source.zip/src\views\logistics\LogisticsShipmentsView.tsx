import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import { Shipment, ShipmentStop, Vehicle, Driver, Carrier } from '../../types/logistics';
import {
  Truck,
  Plus,
  Search,
  Filter,
  Kanban,
  Table as TableIcon,
  CheckCircle2,
  Clock,
  AlertTriangle,
  MapPin,
  Calendar,
  DollarSign,
  User,
  Users,
  ShieldAlert,
  ArrowRight,
  ExternalLink,
  ChevronRight,
  X,
  FileText,
  Navigation,
} from 'lucide-react';

export const LogisticsShipmentsView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    shipments,
    createShipment,
    updateShipmentStatus,
    updateShipmentStopStatus,
    deliveryNotes,
    vehicles,
    drivers,
    carriers,
    documentExpiries,
    addVehicle,
    addDriver,
    addCarrier,
  } = useLogistics();

  // Active Main Tab
  const [activeMainTab, setActiveMainTab] = useState<'shipments' | 'vehicles' | 'drivers' | 'carriers'>('shipments');

  // Shipment View Mode: Kanban vs Table
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedShipment, setSelectedShipment] = useState<Shipment | null>(null);

  // Modal Create Shipment
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formType, setFormType] = useState<'Giao hàng cho khách' | 'Nhận hàng từ nhà cung cấp'>('Giao hàng cho khách');
  const [formDate, setFormDate] = useState(new Date().toISOString().split('T')[0]);
  const [selectedVehicleId, setSelectedVehicleId] = useState(vehicles[0]?.id || '');
  const [selectedDriverId, setSelectedDriverId] = useState(drivers[0]?.id || '');
  const [selectedCarrierId, setSelectedCarrierId] = useState('');
  const [formTrackingCode, setFormTrackingCode] = useState('');
  const [selectedDeliveryNoteIds, setSelectedDeliveryNoteIds] = useState<string[]>([]);

  // Costs
  const [feeFuel, setFeeFuel] = useState<number>(400000);
  const [feeTolls, setFeeTolls] = useState<number>(70000);
  const [feeLabor, setFeeLabor] = useState<number>(200000);
  const [feeIncidental, setFeeIncidental] = useState<number>(0);
  const [feeRental, setFeeRental] = useState<number>(0);

  // Check warnings for vehicle/driver expiry
  const getVehicleWarning = (vehId: string) => {
    const veh = vehicles.find((v) => v.id === vehId);
    if (!veh) return null;
    return documentExpiries.find(
      (d) => d.targetId === vehId && (d.status === 'Đã hết hạn' || d.status === 'Cận hạn (≤30 ngày)')
    );
  };

  const getDriverWarning = (drvId: string) => {
    const drv = drivers.find((d) => d.id === drvId);
    if (!drv) return null;
    return documentExpiries.find(
      (d) => d.targetId === drvId && (d.status === 'Đã hết hạn' || d.status === 'Cận hạn (≤30 ngày)')
    );
  };

  // Available delivery notes for dispatch (status 'Chờ giao')
  const availableDeliveryNotes = deliveryNotes.filter(
    (dn) => dn.status === 'Chờ giao' || !dn.shipmentId
  );

  const handleCreateShipmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formType === 'Giao hàng cho khách' && selectedDeliveryNoteIds.length === 0) {
      showToast('Lỗi', 'Vui lòng chọn ít nhất 1 phiếu giao hàng vào chuyến.', 'warning');
      return;
    }

    const veh = vehicles.find((v) => v.id === selectedVehicleId);
    const drv = drivers.find((d) => d.id === selectedDriverId);
    const car = carriers.find((c) => c.id === selectedCarrierId);

    // Build stops from selected delivery notes
    const selectedDNs = deliveryNotes.filter((dn) => selectedDeliveryNoteIds.includes(dn.id));
    const stops: ShipmentStop[] = selectedDNs.map((dn, idx) => ({
      stopNumber: idx + 1,
      deliveryNoteId: dn.id,
      deliveryNoteCode: dn.code,
      customerName: dn.customerName,
      address: dn.deliveryAddress,
      phone: dn.recipientPhone,
      codAmount: dn.codAmount,
      status: 'Chờ giao',
    }));

    const totalCost = feeRental + feeFuel + feeTolls + feeLabor + feeIncidental;
    const costPerStop = stops.length > 0 ? Math.round(totalCost / stops.length) : totalCost;

    createShipment({
      type: formType,
      departureDate: formDate,
      vehicleId: veh?.id,
      vehiclePlate: veh?.plateNumber,
      vehicleType: veh?.vehicleType,
      driverId: drv?.id,
      driverName: drv?.fullName,
      driverPhone: drv?.phone,
      carrierId: car?.id,
      carrierName: car?.name,
      trackingCode: formTrackingCode,
      deliveryNoteIds: selectedDeliveryNoteIds,
      stops,
      costs: {
        feeRental,
        feeFuel,
        feeTolls,
        feeLabor,
        feeIncidental,
        totalCost,
        costPerStop,
      },
    });

    setIsCreateModalOpen(false);
    setSelectedDeliveryNoteIds([]);
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
              <Navigation className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Điều Phối Chuyến Hàng &amp; Đội Xe
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Gom đơn hàng thành chuyến, tối ưu hóa điểm dừng, tính chi phí chuyến xe và quản lý tài xế, phương tiện.
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>Lập Chuyến Hàng Mới</span>
        </button>
      </div>

      {/* Main Tabs: Chuyến hàng | Xe | Tài xế | ĐVVC */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveMainTab('shipments')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-2 ${
            activeMainTab === 'shipments'
              ? 'border-sky-500 text-sky-600 dark:text-sky-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Truck className="w-4 h-4" />
          <span>Chuyến Hàng ({shipments.length})</span>
        </button>

        <button
          onClick={() => setActiveMainTab('vehicles')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-2 ${
            activeMainTab === 'vehicles'
              ? 'border-sky-500 text-sky-600 dark:text-sky-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <span>Đội Xe ({vehicles.length})</span>
        </button>

        <button
          onClick={() => setActiveMainTab('drivers')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-2 ${
            activeMainTab === 'drivers'
              ? 'border-sky-500 text-sky-600 dark:text-sky-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Tài Xế ({drivers.length})</span>
        </button>

        <button
          onClick={() => setActiveMainTab('carriers')}
          className={`px-4 py-2.5 text-xs sm:text-sm font-bold border-b-2 transition-colors flex items-center gap-2 ${
            activeMainTab === 'carriers'
              ? 'border-sky-500 text-sky-600 dark:text-sky-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <span>Đơn Vị Vận Chuyển ({carriers.length})</span>
        </button>
      </div>

      {/* TAB 1: CHUYẾN HÀNG */}
      {activeMainTab === 'shipments' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div className="relative w-72">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Tìm mã chuyến (CX-2026-xxxx), tài xế, xe..."
                className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
              />
            </div>

            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg">
              <button
                onClick={() => setViewMode('kanban')}
                className={`p-1.5 rounded-md text-xs font-semibold flex items-center gap-1 ${
                  viewMode === 'kanban'
                    ? 'bg-white dark:bg-slate-900 text-sky-600 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Kanban className="w-3.5 h-3.5" />
                <span>Kanban</span>
              </button>
              <button
                onClick={() => setViewMode('table')}
                className={`p-1.5 rounded-md text-xs font-semibold flex items-center gap-1 ${
                  viewMode === 'table'
                    ? 'bg-white dark:bg-slate-900 text-sky-600 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <TableIcon className="w-3.5 h-3.5" />
                <span>Danh sách</span>
              </button>
            </div>
          </div>

          {viewMode === 'kanban' ? (
            /* Kanban 4 Cột: Chờ xuất phát -> Đã bàn giao -> Đang giao -> Hoàn thành */
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {(['Chờ xuất phát', 'Đã bàn giao', 'Đang giao', 'Hoàn thành'] as Shipment['status'][]).map(
                (colStatus) => {
                  const colShipments = shipments.filter((s) => s.status === colStatus);

                  return (
                    <div
                      key={colStatus}
                      className="bg-slate-50/70 dark:bg-slate-900/40 p-3.5 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-3 flex flex-col"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                          {colStatus}
                        </span>
                        <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                          {colShipments.length}
                        </span>
                      </div>

                      <div className="space-y-3 flex-1 overflow-y-auto">
                        {colShipments.map((sh) => (
                          <div
                            key={sh.id}
                            onClick={() => setSelectedShipment(sh)}
                            className="p-3 bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-xs hover:border-sky-400 transition-all cursor-pointer space-y-2 text-xs"
                          >
                            <div className="flex items-center justify-between">
                              <span className="font-mono font-bold text-sky-600 dark:text-sky-400">
                                {sh.code}
                              </span>
                              <span className="text-[10px] text-slate-400 font-sans">{sh.departureDate}</span>
                            </div>

                            <div>
                              <div className="font-semibold text-slate-800 dark:text-slate-200">
                                {sh.driverName || sh.carrierName || 'Chưa gán xe'}
                              </div>
                              <div className="text-[10px] text-slate-500 font-mono">
                                {sh.vehiclePlate || sh.trackingCode || 'N/A'}
                              </div>
                            </div>

                            <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-100 dark:border-slate-700 text-slate-500">
                              <span>{sh.stops.length} điểm giao</span>
                              <span className="font-bold text-slate-800 dark:text-slate-200">
                                {sh.costs.totalCost.toLocaleString()} đ
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                }
              )}
            </div>
          ) : (
            /* Table View */
            <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] text-slate-500 uppercase font-semibold">
                  <tr>
                    <th className="p-3">Mã chuyến &amp; Ngày</th>
                    <th className="p-3">Loại chuyến</th>
                    <th className="p-3">Phương tiện / Tài xế</th>
                    <th className="p-3 text-center">Số điểm dừng</th>
                    <th className="p-3 text-right">Tổng chi phí</th>
                    <th className="p-3 text-center">Trạng thái</th>
                    <th className="p-3 text-center">Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {shipments.map((sh) => (
                    <tr key={sh.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="p-3 font-mono font-bold text-sky-600">
                        {sh.code}
                        <div className="text-[10px] text-slate-400 font-normal">{sh.departureDate}</div>
                      </td>
                      <td className="p-3 font-medium">{sh.type}</td>
                      <td className="p-3">
                        <div className="font-semibold">{sh.driverName || sh.carrierName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{sh.vehiclePlate || sh.trackingCode}</div>
                      </td>
                      <td className="p-3 text-center font-bold">{sh.stops.length} điểm</td>
                      <td className="p-3 text-right font-bold text-slate-900 dark:text-white">
                        {sh.costs.totalCost.toLocaleString()} đ
                      </td>
                      <td className="p-3 text-center">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300">
                          {sh.status}
                        </span>
                      </td>
                      <td className="p-3 text-center">
                        <button
                          onClick={() => setSelectedShipment(sh)}
                          className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 font-semibold text-slate-700 dark:text-slate-300"
                        >
                          Chi tiết
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: ĐỘI XE */}
      {activeMainTab === 'vehicles' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {vehicles.map((veh) => {
            const warningDoc = getVehicleWarning(veh.id);

            return (
              <div
                key={veh.id}
                className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-base font-bold text-sky-600">{veh.plateNumber}</span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      veh.status === 'Sẵn sàng'
                        ? 'bg-emerald-100 text-emerald-800'
                        : veh.status === 'Đang chạy'
                        ? 'bg-sky-100 text-sky-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {veh.status}
                  </span>
                </div>

                <div>
                  <p className="font-semibold text-slate-800 dark:text-slate-200">{veh.vehicleType}</p>
                  <p className="text-slate-400">Tải trọng thiết kế: {veh.capacityWeight} Tấn</p>
                  <p className="text-slate-500 mt-1">
                    Tài xế mặc định: <strong>{veh.mainDriverName || 'Chưa gán'}</strong>
                  </p>
                </div>

                {warningDoc && (
                  <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-lg text-rose-700 dark:text-rose-300 text-[11px] flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 shrink-0" />
                    <span>
                      Cảnh báo: {warningDoc.documentType} ({warningDoc.documentNumber}) {warningDoc.status}!
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 3: TÀI XẾ */}
      {activeMainTab === 'drivers' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {drivers.map((drv) => {
            const warningDoc = getDriverWarning(drv.id);

            return (
              <div
                key={drv.id}
                className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold text-sm text-slate-800 dark:text-slate-100">{drv.fullName}</div>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      drv.status === 'Sẵn sàng'
                        ? 'bg-emerald-100 text-emerald-800'
                        : drv.status === 'Đang chạy'
                        ? 'bg-sky-100 text-sky-800'
                        : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {drv.status}
                  </span>
                </div>

                <div className="space-y-1 text-slate-500">
                  <p>SĐT: <strong>{drv.phone}</strong></p>
                  <p>Số GPLX: <span className="font-mono">{drv.licenseNumber}</span></p>
                  <p>Hạng bằng lái: <span className="font-bold text-sky-600">Hạng {drv.licenseClass}</span></p>
                </div>

                {warningDoc && (
                  <div className="p-2.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-lg text-rose-700 dark:text-rose-300 text-[11px] flex items-center gap-1.5">
                    <ShieldAlert className="w-4 h-4 shrink-0" />
                    <span>Bằng lái {warningDoc.status}! Không xếp chuyến vượt quyền.</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* TAB 4: ĐƠN VỊ VẬN CHUYỂN */}
      {activeMainTab === 'carriers' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {carriers.map((car) => (
            <div
              key={car.id}
              className="bg-white dark:bg-slate-900 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-2.5 text-xs"
            >
              <h3 className="font-bold text-sm text-indigo-600">{car.name}</h3>
              <p className="text-slate-600 dark:text-slate-300">{car.serviceType}</p>
              <p className="text-slate-500">Hotline: {car.phone}</p>
              <p className="text-slate-500">Đầu mối: {car.contactPerson}</p>
              <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-400">
                Tracking: <span className="font-mono text-sky-600">{car.trackingUrlTemplate}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Drawer Chi Tiết Chuyến Hàng */}
      {selectedShipment && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end animate-fade-in">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col border-l border-slate-200 dark:border-slate-800">
            <div className="p-4 sm:p-5 border-b flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
              <div>
                <span className="font-mono text-base font-bold text-sky-600">{selectedShipment.code}</span>
                <span className="ml-2 px-2 py-0.5 rounded text-[10px] font-bold bg-sky-100 text-sky-800">
                  {selectedShipment.status}
                </span>
                <p className="text-xs text-slate-500 mt-0.5">Khởi hành: {selectedShipment.departureDate}</p>
              </div>
              <button onClick={() => setSelectedShipment(null)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-5 text-xs">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-400">Phương tiện:</span>
                  <span className="font-bold">{selectedShipment.vehiclePlate || selectedShipment.carrierName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Tài xế:</span>
                  <span className="font-bold">{selectedShipment.driverName} ({selectedShipment.driverPhone})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Tổng chi phí chuyến:</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {selectedShipment.costs.totalCost.toLocaleString()} đ (Bình quân{' '}
                    {selectedShipment.costs.costPerStop.toLocaleString()} đ/điểm)
                  </span>
                </div>
              </div>

              {/* Danh sách các điểm dừng giao hàng */}
              <div>
                <h4 className="text-xs font-bold text-slate-700 dark:text-slate-300 uppercase mb-2">
                  Lộ trình các điểm dừng ({selectedShipment.stops.length})
                </h4>
                <div className="space-y-2.5">
                  {selectedShipment.stops.map((stop) => (
                    <div
                      key={stop.stopNumber}
                      className="p-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 space-y-2"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                          <span className="w-5 h-5 rounded-full bg-sky-100 text-sky-700 flex items-center justify-center text-[10px]">
                            {stop.stopNumber}
                          </span>
                          {stop.customerName}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            stop.status === 'Đã giao'
                              ? 'bg-emerald-100 text-emerald-800'
                              : stop.status === 'Thất bại'
                              ? 'bg-rose-100 text-rose-800'
                              : 'bg-amber-100 text-amber-800'
                          }`}
                        >
                          {stop.status}
                        </span>
                      </div>

                      <p className="text-slate-500 text-[11px] flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-400 shrink-0" />
                        <span>{stop.address}</span>
                      </p>

                      <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-[11px]">
                        <span className="text-slate-500">Thu hộ COD: <strong>{stop.codAmount.toLocaleString()} đ</strong></span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() =>
                              updateShipmentStopStatus(selectedShipment.id, stop.stopNumber, 'Đã giao', new Date().toISOString().substring(11, 16))
                            }
                            className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 font-semibold"
                          >
                            Đã giao
                          </button>
                          <button
                            onClick={() =>
                              updateShipmentStopStatus(selectedShipment.id, stop.stopNumber, 'Thất bại')
                            }
                            className="px-2 py-0.5 rounded bg-rose-50 text-rose-700 font-semibold"
                          >
                            Thất bại
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-4 border-t flex justify-end gap-2 bg-slate-50 dark:bg-slate-800/80">
              {selectedShipment.status !== 'Hoàn thành' && (
                <button
                  onClick={() => {
                    updateShipmentStatus(selectedShipment.id, 'Hoàn thành');
                    setSelectedShipment((prev) => (prev ? { ...prev, status: 'Hoàn thành' } : null));
                  }}
                  className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-bold text-xs"
                >
                  Kết Thúc Chuyến Hàng
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal Lập Chuyến Hàng Mới */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-2xl w-full p-6 shadow-2xl border space-y-4 my-8">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <Truck className="w-5 h-5 text-sky-500" />
                <span>Lập Chuyến Vận Tải Mới</span>
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateShipmentSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Loại chuyến</label>
                  <select
                    value={formType}
                    onChange={(e: any) => setFormType(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-800"
                  >
                    <option value="Giao hàng cho khách">Giao hàng cho khách</option>
                    <option value="Nhận hàng từ nhà cung cấp">Nhận hàng từ nhà cung cấp</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Ngày khởi hành</label>
                  <input
                    type="date"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Phương tiện (Xe công ty)</label>
                  <select
                    value={selectedVehicleId}
                    onChange={(e) => setSelectedVehicleId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-800"
                  >
                    {vehicles.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.plateNumber} ({v.vehicleType})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Tài xế phân công</label>
                  <select
                    value={selectedDriverId}
                    onChange={(e) => setSelectedDriverId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-800"
                  >
                    {drivers.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.fullName} (Hạng {d.licenseClass})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Warning if vehicle or driver has expired docs */}
              {selectedVehicleId && getVehicleWarning(selectedVehicleId) && (
                <div className="p-2.5 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <span>Xe {vehicles.find((v) => v.id === selectedVehicleId)?.plateNumber} có đăng kiểm/bảo hiểm cận hạn hoặc đã hết hạn! Vui lòng lưu ý.</span>
                </div>
              )}

              {/* Select Delivery Notes */}
              <div>
                <label className="block text-slate-600 font-semibold mb-1">
                  Chọn các phiếu giao hàng vào chuyến này ({availableDeliveryNotes.length} phiếu chờ giao):
                </label>
                <div className="border rounded-xl max-h-40 overflow-y-auto divide-y">
                  {availableDeliveryNotes.length === 0 ? (
                    <p className="p-3 text-slate-400 text-center">Không có phiếu giao hàng nào đang chờ giao.</p>
                  ) : (
                    availableDeliveryNotes.map((dn) => (
                      <label
                        key={dn.id}
                        className="flex items-center justify-between p-2.5 hover:bg-slate-50 cursor-pointer"
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={selectedDeliveryNoteIds.includes(dn.id)}
                            onChange={(e) => {
                              if (e.target.value) {
                                setSelectedDeliveryNoteIds((prev) =>
                                  prev.includes(dn.id) ? prev.filter((id) => id !== dn.id) : [...prev, dn.id]
                                );
                              }
                            }}
                          />
                          <div>
                            <span className="font-mono font-bold text-sky-600">{dn.code}</span> - {dn.customerName}
                            <div className="text-[10px] text-slate-400">{dn.deliveryAddress}</div>
                          </div>
                        </div>
                        <span className="font-semibold text-slate-700">
                          {dn.codAmount > 0 ? `${dn.codAmount.toLocaleString()} đ` : 'Không COD'}
                        </span>
                      </label>
                    ))
                  )}
                </div>
              </div>

              {/* Estimated Costs */}
              <div className="grid grid-cols-4 gap-2 pt-2 border-t">
                <div>
                  <label className="block text-[11px] text-slate-500">Xăng dầu (đ)</label>
                  <input
                    type="number"
                    value={feeFuel}
                    onChange={(e) => setFeeFuel(Number(e.target.value))}
                    className="w-full px-2 py-1 rounded border"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500">Cầu đường (đ)</label>
                  <input
                    type="number"
                    value={feeTolls}
                    onChange={(e) => setFeeTolls(Number(e.target.value))}
                    className="w-full px-2 py-1 rounded border"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500">Bốc xếp (đ)</label>
                  <input
                    type="number"
                    value={feeLabor}
                    onChange={(e) => setFeeLabor(Number(e.target.value))}
                    className="w-full px-2 py-1 rounded border"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-slate-500">Thuê ngoài (đ)</label>
                  <input
                    type="number"
                    value={feeRental}
                    onChange={(e) => setFeeRental(Number(e.target.value))}
                    className="w-full px-2 py-1 rounded border"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg border text-slate-600 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-sky-600 text-white font-bold"
                >
                  Tạo Chuyến Hàng
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
