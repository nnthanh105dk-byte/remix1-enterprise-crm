import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { useTechnical } from '../../context/TechnicalContext';
import { SalesOpportunity, OpportunityStageName } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import { useColumnVisibility, ColumnDef } from '../../hooks/useColumnVisibility';
import { ColumnVisibilityPicker } from '../../components/common/ColumnVisibilityPicker';

const OPPORTUNITY_COLUMNS: ColumnDef[] = [
  { id: 'code', label: 'Mã Deal', required: true },
  { id: 'title', label: 'Tên Cơ Hội / Khách Hàng' },
  { id: 'amount', label: 'Giá Trị' },
  { id: 'stage', label: 'Giai Đoạn' },
  { id: 'expectedCloseDate', label: 'Ngày Dự Kiến Chốt' },
  { id: 'nextStep', label: 'Bước Tiếp Theo' },
  { id: 'assignedTo', label: 'Phụ Trách' },
  { id: 'actions', label: 'Thao Tác' },
];

import {
  Briefcase,
  Plus,
  Kanban,
  Table as TableIcon,
  Search,
  Filter,
  DollarSign,
  Calendar,
  Clock,
  ArrowRight,
  CheckCircle2,
  X,
  FileSpreadsheet,
  AlertTriangle,
  Building,
  User,
  ExternalLink,
  ChevronRight,
  Wrench,
} from 'lucide-react';

const STAGES: { name: OpportunityStageName; prob: number; color: string }[] = [
  { name: 'Khám phá nhu cầu', prob: 20, color: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300' },
  { name: 'Báo giá & Đề xuất', prob: 40, color: 'bg-sky-100 text-sky-800 dark:bg-sky-950/60 dark:text-sky-300' },
  { name: 'Đàm phán', prob: 70, color: 'bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300' },
  { name: 'Thành công (Won)', prob: 100, color: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300' },
  { name: 'Thất bại (Lost)', prob: 0, color: 'bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300' },
];

export const SalesOpportunitiesView: React.FC = () => {
  const { currentUser, currentRole, showToast, setActiveModule } = useCRM();
  const isSalesStaff = currentRole === 'Sales Staff' || currentUser.fullName === 'Nguyễn Văn A';
  const {
    opportunities,
    customers,
    quotations,
    addOpportunity,
    updateOpportunity,
    updateOpportunityStage,
    deleteOpportunity,
  } = useSales();
  const { createTechnicalQuotationRequest } = useTechnical();


  const {
    columns: colDefs,
    visibleColumns,
    isVisible,
    toggleColumn,
    selectAll,
    resetToDefault,
  } = useColumnVisibility('sales_opportunities', OPPORTUNITY_COLUMNS);
  const [viewMode, setViewMode] = useState<'kanban' | 'table'>('kanban');
  const [searchTerm, setSearchTerm] = useState('');
  const [repFilter, setRepFilter] = useState<string>(() =>
    currentRole === 'Sales Staff' || currentUser.fullName === 'Nguyễn Văn A' ? currentUser.fullName : 'all'
  );
  const [stageFilter, setStageFilter] = useState<string>('all');
  const [stagnantDaysThreshold, setStagnantDaysThreshold] = useState<number>(14);

  // Selected Deal for Drawer
  const [selectedDeal, setSelectedDeal] = useState<SalesOpportunity | null>(null);

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isLostModalOpen, setIsLostModalOpen] = useState(false);
  const [lostTargetDealId, setLostTargetDealId] = useState<string | null>(null);
  const [lostReason, setLostReason] = useState<'Giá cao' | 'Đối thủ' | 'Chưa có ngân sách' | 'Không phản hồi' | 'Khác'>('Giá cao');
  const [competitorName, setCompetitorName] = useState('');

  // Form State for Creating Deal
  const [formTitle, setFormTitle] = useState('');
  const [formCustomerId, setFormCustomerId] = useState(customers[0]?.id || '');
  const [formAmount, setFormAmount] = useState<number>(450000000);
  const [formExpectedDate, setFormExpectedDate] = useState<string>(
    new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [formNextStep, setFormNextStep] = useState('Liên hệ gửi bảng chào giá sơ bộ');
  const [formNextStepDate, setFormNextStepDate] = useState<string>(
    new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [formAssignedTo, setFormAssignedTo] = useState('Lê Hoàng Yến');

  // Helper check if deal is stagnant (> X days without activity)
  const isDealStagnant = (deal: SalesOpportunity) => {
    if (deal.stage === 'Thành công (Won)' || deal.stage === 'Thất bại (Lost)') return false;
    const lastTime = new Date(deal.lastActivityDate || deal.createdAt).getTime();
    if (isNaN(lastTime)) return false;
    const diffDays = (Date.now() - lastTime) / (1000 * 60 * 60 * 24);
    return diffDays >= stagnantDaysThreshold;
  };

  // Filtered Opportunities
  const filteredDeals = opportunities.filter((d) => {
    if (repFilter !== 'all' && d.assignedTo !== repFilter) return false;
    if (stageFilter !== 'all' && d.stage !== stageFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        d.title.toLowerCase().includes(q) ||
        d.code.toLowerCase().includes(q) ||
        d.customerName.toLowerCase().includes(q) ||
        d.contactName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCreateDealSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cust = customers.find((c) => c.id === formCustomerId);
    if (!cust) return;

    addOpportunity({
      title: formTitle,
      customerId: cust.id,
      customerCode: cust.code,
      customerName: cust.name,
      contactName: cust.contacts[0]?.fullName || cust.name,
      amount: formAmount,
      stage: 'Khám phá nhu cầu',
      probability: 20,
      expectedCloseDate: formExpectedDate,
      leadSource: 'Website',
      interestedProducts: ['HW-SRV-DL380', 'HW-SW-CISCO-9300'],
      assignedTo: formAssignedTo,
      nextStep: formNextStep,
      nextStepDate: formNextStepDate,
      lastActivityDate: new Date().toISOString().split('T')[0],
    });

    setIsCreateModalOpen(false);
    setFormTitle('');
  };

  const handleStageChange = (dealId: string, targetStage: OpportunityStageName) => {
    if (targetStage === 'Thất bại (Lost)') {
      setLostTargetDealId(dealId);
      setIsLostModalOpen(true);
      return;
    }
    updateOpportunityStage(dealId, targetStage);
    if (selectedDeal?.id === dealId) {
      setSelectedDeal((prev) => (prev ? { ...prev, stage: targetStage } : null));
    }
  };

  const handleConfirmLost = () => {
    if (!lostTargetDealId) return;
    updateOpportunityStage(lostTargetDealId, 'Thất bại (Lost)', lostReason, competitorName);
    setIsLostModalOpen(false);
    setLostTargetDealId(null);
    setCompetitorName('');
  };

  // Total Open Pipeline
  const openDeals = filteredDeals.filter((d) => d.stage !== 'Thành công (Won)' && d.stage !== 'Thất bại (Lost)');
  const totalPipeline = openDeals.reduce((sum, d) => sum + d.amount, 0);
  const stagnantCount = filteredDeals.filter(isDealStagnant).length;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
                <Briefcase className="w-5 h-5" />
              </span>
              Cơ Hội Bán Hàng (Sales Pipeline)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {filteredDeals.length} Deals
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Theo dõi phễu bán hàng, bắt buộc xác định ngày dự kiến chốt và bước tiếp theo để đảm bảo tiến độ kinh doanh.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center rounded-lg border border-slate-200 dark:border-slate-800 p-0.5 bg-slate-100 dark:bg-slate-800 text-xs">
            <button
              onClick={() => setViewMode('kanban')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md font-semibold transition-all ${
                viewMode === 'kanban'
                  ? 'bg-white dark:bg-slate-900 text-sky-600 dark:text-sky-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              <Kanban className="w-3.5 h-3.5" />
              <span>Kanban</span>
            </button>
            <button
              onClick={() => setViewMode('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-[6px] font-medium text-[13px] transition-all cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-white text-[#002659] shadow-xs font-semibold'
                  : 'text-[#667085] hover:text-[#172033]'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5" />
              <span>Bảng danh sách</span>
            </button>
          </div>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-[14px] font-medium rounded-[6px] bg-[#002659] text-white hover:bg-[#001a3d] shadow-xs cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm Cơ Hội</span>
          </button>
        </div>
      </div>

      {/* Pipeline Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200">
          <span className="text-[14.5px] font-bold text-slate-800 dark:text-slate-100 tracking-tight">Tổng giá trị Pipeline đang mở</span>
          <h3 className="text-2xl sm:text-[28px] font-black font-mono text-[#002659] dark:text-sky-400 mt-1.5 leading-none tabular-nums">
            {(totalPipeline / 1000000000).toFixed(2)} Tỷ ₫
          </h3>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200">
          <span className="text-[14.5px] font-bold text-slate-800 dark:text-slate-100 tracking-tight">Deals đã thắng (Won)</span>
          <h3 className="text-2xl sm:text-[28px] font-black font-mono text-emerald-600 dark:text-emerald-400 mt-1.5 leading-none tabular-nums">
            {filteredDeals.filter((d) => d.stage === 'Thành công (Won)').length} Deals
          </h3>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200">
          <span className="text-[14.5px] font-bold text-[#E96F22] dark:text-amber-400 tracking-tight">Cơ hội "đứng" (&gt;{stagnantDaysThreshold} ngày)</span>
          <h3 className="text-2xl sm:text-[28px] font-black font-mono text-[#E96F22] dark:text-amber-400 mt-1.5 leading-none tabular-nums">
            {stagnantCount} Deals
          </h3>
        </div>
      </div>

      {/* Sales Staff Role Scoping Banner */}
      {isSalesStaff && (
        <div className="bg-sky-50 dark:bg-sky-950/40 border border-sky-300 dark:border-sky-800 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-lg bg-sky-100 dark:bg-sky-900/60 text-sky-600 dark:text-sky-300 shrink-0">
              <User className="w-5 h-5" />
            </span>
            <div>
              <h4 className="text-sm font-bold text-sky-950 dark:text-sky-100 flex items-center gap-2">
                Góc nhìn Chuyên viên Sales: {currentUser.fullName}
                <span className="px-2 py-0.5 rounded text-[11px] bg-sky-200 dark:bg-sky-900 text-sky-800 dark:text-sky-200 font-semibold">
                  {opportunities.filter((d) => d.assignedTo === currentUser.fullName).length} Cơ hội được phân bổ
                </span>
              </h4>
              <p className="text-xs text-sky-700 dark:text-sky-300 mt-0.5">
                Bạn có thể cập nhật giai đoạn cơ hội bằng cách kéo thả thẻ Kanban hoặc chỉnh ngay trên danh sách.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setRepFilter(currentUser.fullName)}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                repFilter === currentUser.fullName
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700'
              }`}
            >
              Chỉ Deal của tôi ({opportunities.filter((d) => d.assignedTo === currentUser.fullName).length})
            </button>
            <button
              onClick={() => setRepFilter('all')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                repFilter === 'all'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700'
              }`}
            >
              Toàn bộ ({opportunities.length})
            </button>
          </div>
        </div>
      )}

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo tên deal, khách hàng, mã..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Người phụ trách:</span>
            <select
              value={repFilter}
              onChange={(e) => setRepFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <option value="all">Tất cả nhân viên</option>
              {Array.from(new Set(opportunities.map((d) => d.assignedTo))).map((assignee) => (
                <option key={assignee} value={assignee}>
                  {assignee} ({opportunities.filter((d) => d.assignedTo === assignee).length})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Giai đoạn:</span>
            <select
              value={stageFilter}
              onChange={(e) => setStageFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
            >
              <option value="all">Tất cả giai đoạn</option>
              {STAGES.map((s) => (
                <option key={s.name} value={s.name}>
                  {s.name} ({s.prob}%)
                </option>
              ))}
            </select>
          </div>

          <ColumnVisibilityPicker
            columns={colDefs}
            visibleColumns={visibleColumns}
            onToggle={toggleColumn}
            onSelectAll={selectAll}
            onReset={resetToDefault}
          />
        </div>
      </div>

      {/* KANBAN VIEW */}
      {viewMode === 'kanban' && (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3.5 overflow-x-auto pb-4">
          {STAGES.map((stage) => {
            const stageDeals = filteredDeals.filter((d) => d.stage === stage.name);
            const stageTotal = stageDeals.reduce((sum, d) => sum + d.amount, 0);

            return (
              <div
                key={stage.name}
                className="bg-[#F8FAFC] border border-[#E5EAF1] rounded-[6px] p-3 flex flex-col min-w-[250px]"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between pb-2.5 border-b border-[#E5EAF1] mb-3">
                  <div>
                    <span className="text-[14px] font-bold text-[#172033] block">
                      {stage.name}
                    </span>
                    <span className="text-[13px] font-mono font-bold text-[#002659]">
                      {(stageTotal / 1000000).toFixed(0)} Tr ₫
                    </span>
                  </div>
                  <span className="text-[13px] px-2 py-0.5 rounded-[6px] bg-white border border-[#E5EAF1] font-bold text-[#172033] font-mono shadow-2xs">
                    {stageDeals.length}
                  </span>
                </div>

                {/* Cards Container */}
                <div className="space-y-2.5 flex-1 overflow-y-auto max-h-[650px] pr-1">
                  {stageDeals.map((deal) => {
                    const isStagnant = isDealStagnant(deal);

                    return (
                      <div
                        key={deal.id}
                        onClick={() => setSelectedDeal(deal)}
                        className={`p-3 rounded-lg border bg-white dark:bg-slate-900 shadow-2xs hover:shadow-xs transition-all cursor-pointer text-xs space-y-2 group ${
                          isStagnant
                            ? 'border-amber-300 dark:border-amber-700/80 bg-amber-50/25 dark:bg-amber-950/15'
                            : 'border-slate-200/90 dark:border-slate-800 hover:border-sky-400 dark:hover:border-sky-600'
                        }`}
                      >
                        {/* 1. Header: Tên đơn vị + Nút ! ở góc phải trên */}
                        <div className="flex items-start justify-between gap-1.5">
                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-1.5">
                              <Building className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400 shrink-0" />
                              <h4
                                className="font-bold text-slate-900 dark:text-white text-[13.5px] truncate leading-tight group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors"
                                title={deal.customerName}
                              >
                                {deal.customerName}
                              </h4>
                            </div>
                            <p
                              className="text-[12px] text-slate-500 dark:text-slate-400 truncate mt-0.5"
                              title={deal.title}
                            >
                              {deal.title}
                            </p>
                          </div>

                          {/* Nút ! ở góc phải trên */}
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedDeal(deal);
                            }}
                            className="w-5 h-5 rounded-full bg-slate-100 hover:bg-[#002659] hover:text-white dark:bg-slate-800 dark:hover:bg-sky-500 text-slate-600 dark:text-slate-300 flex items-center justify-center text-[11px] font-bold transition-all shadow-2xs shrink-0 cursor-pointer ml-1"
                            title="Bấm để xem đầy đủ thông tin chi tiết cơ hội"
                          >
                            !
                          </button>
                        </div>

                        {/* 2. Giá trị hợp đồng */}
                        <div className="flex items-baseline justify-between pt-1 border-t border-slate-100 dark:border-slate-800/80">
                          <span className="text-[11.5px] font-medium text-slate-400 dark:text-slate-500">
                            Giá trị hợp đồng:
                          </span>
                          <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 text-[13.5px]">
                            {(deal.amount / 1000000).toLocaleString()}M ₫
                          </span>
                        </div>

                        {/* 3. Giai đoạn & Trạng thái */}
                        <div className="flex items-center justify-between gap-2 pt-1">
                          {/* Trạng thái */}
                          {isStagnant ? (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 text-[10.5px] font-semibold shrink-0">
                              <AlertTriangle className="w-3 h-3 shrink-0" />
                              <span>Đứng &gt;{stagnantDaysThreshold}d</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-sky-50 dark:bg-sky-950/50 text-sky-700 dark:text-sky-300 border border-sky-200/60 dark:border-sky-800 text-[10.5px] font-medium shrink-0">
                              <span className="w-1.5 h-1.5 rounded-full bg-sky-500" />
                              <span>Tiến độ tốt</span>
                            </span>
                          )}

                          {/* Giai đoạn (Dropdown chuyển giai đoạn nhanh) */}
                          <div className="min-w-0" onClick={(e) => e.stopPropagation()}>
                            <select
                              value={deal.stage}
                              onChange={(e) => handleStageChange(deal.id, e.target.value as OpportunityStageName)}
                              className="w-full text-[11px] font-semibold rounded-md border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 py-0.5 pl-1.5 pr-4 text-slate-700 dark:text-slate-300 cursor-pointer hover:border-sky-400 focus:outline-hidden truncate"
                              title="Thay đổi giai đoạn cơ hội"
                            >
                              {STAGES.map((s) => (
                                <option key={s.name} value={s.name}>
                                  {s.name}
                                </option>
                              ))}
                            </select>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* TABLE VIEW */}
      {viewMode === 'table' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800 uppercase text-[11px]">
                <tr>
                  {isVisible('code') && <th className="py-3 px-3">Mã Deal</th>}
                  {isVisible('title') && <th className="py-3 px-3">Tên Cơ Hội / Khách Hàng</th>}
                  {isVisible('amount') && <th className="py-3 px-3 text-right">Giá Trị</th>}
                  {isVisible('stage') && <th className="py-3 px-3">Giai Đoạn</th>}
                  {isVisible('expectedCloseDate') && <th className="py-3 px-3">Ngày Dự Kiến Chốt</th>}
                  {isVisible('nextStep') && <th className="py-3 px-3">Bước Tiếp Theo</th>}
                  {isVisible('assignedTo') && <th className="py-3 px-3">Phụ Trách</th>}
                  {isVisible('actions') && <th className="py-3 px-3 text-right">Thao Tác</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredDeals.length === 0 ? (
                  <tr>
                    <td colSpan={colDefs.filter(c => isVisible(c.id)).length || 1} className="py-8 text-center text-slate-400">
                      Không tìm thấy cơ hội nào phù hợp.
                    </td>
                  </tr>
                ) : (
                  filteredDeals.map((deal) => {
                    const isStagnant = isDealStagnant(deal);
                    return (
                      <tr
                        key={deal.id}
                        onClick={() => setSelectedDeal(deal)}
                        className={`hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition-colors ${
                          isStagnant ? 'bg-amber-50/40 dark:bg-amber-950/20' : ''
                        }`}
                      >
                        {isVisible('code') && (
                          <td className="py-3 px-3 font-mono font-bold text-sky-600 dark:text-sky-400">
                            {deal.code}
                          </td>
                        )}

                        {isVisible('title') && (
                          <td className="py-3 px-3">
                            <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                              {deal.title}
                              {isStagnant && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-500 text-white font-bold">
                                  Đứng
                                </span>
                              )}
                            </div>
                            <div className="text-[11px] text-slate-400 mt-0.5">
                              {deal.customerName} ({deal.contactName})
                            </div>
                          </td>
                        )}

                        {isVisible('amount') && (
                          <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                            {deal.amount.toLocaleString()} ₫
                          </td>
                        )}

                        {isVisible('stage') && (
                          <td className="py-3 px-3" onClick={(e) => e.stopPropagation()}>
                            <select
                              value={deal.stage}
                              onChange={(e) => handleStageChange(deal.id, e.target.value as OpportunityStageName)}
                              className={`text-[11px] font-bold rounded-lg border px-2 py-1 cursor-pointer transition-colors ${
                                deal.stage === 'Thành công (Won)'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-300 dark:border-emerald-700'
                                  : deal.stage === 'Thất bại (Lost)'
                                  ? 'bg-rose-50 text-rose-800 border-rose-300 dark:bg-rose-950/70 dark:text-rose-300 dark:border-rose-700'
                                  : 'bg-sky-50 text-sky-800 border-sky-300 dark:bg-sky-950/70 dark:text-sky-300 dark:border-sky-700'
                              }`}
                            >
                              {STAGES.map((s) => (
                                <option key={s.name} value={s.name}>
                                  {s.name} ({s.prob}%)
                                </option>
                              ))}
                            </select>
                          </td>
                        )}

                        {isVisible('expectedCloseDate') && (
                          <td className="py-3 px-3 font-mono font-medium">
                            {deal.expectedCloseDate}
                          </td>
                        )}

                        {isVisible('nextStep') && (
                          <td className="py-3 px-3 text-[11px] max-w-[200px]">
                            <span className="text-slate-800 dark:text-slate-200 block truncate font-medium">
                              {deal.nextStep}
                            </span>
                            <span className="text-slate-400 font-mono text-[10px]">Hạn: {deal.nextStepDate}</span>
                          </td>
                        )}

                        {isVisible('assignedTo') && (
                          <td className="py-3 px-3 font-medium">
                            {deal.assignedTo}
                          </td>
                        )}

                        {isVisible('actions') && (
                          <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => setSelectedDeal(deal)}
                              className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-200 text-xs"
                            >
                              Chi tiết →
                            </button>
                          </td>
                        )}
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Right Drawer: Chi Tiết Cơ Hội & Nút Tạo Báo Giá */}
      {selectedDeal && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 h-full overflow-y-auto flex flex-col p-6 shadow-2xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs px-2.5 py-1 rounded bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-bold">
                  {selectedDeal.code}
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-semibold">
                  {selectedDeal.stage}
                </span>
              </div>
              <button onClick={() => setSelectedDeal(null)} className="p-1 rounded-lg text-slate-400 hover:text-slate-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Chain Bar */}
            <div className="mt-4">
              <DocumentChainBar
                currentType="opportunity"
                chain={selectedDeal.chain}
              />
            </div>

            {/* Thông tin chính */}
            <div className="mt-5 space-y-4 text-xs">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">{selectedDeal.title}</h2>
                <p className="text-slate-500 font-medium">{selectedDeal.customerName}</p>
              </div>

              <div className="grid grid-cols-2 gap-3 bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-slate-400 block text-[11px]">Giá trị cơ hội:</span>
                  <span className="text-base font-bold font-mono text-emerald-600 dark:text-emerald-400">
                    {selectedDeal.amount.toLocaleString()} ₫
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Xác suất thắng:</span>
                  <span className="text-base font-bold font-mono text-sky-600 dark:text-sky-400">
                    {selectedDeal.probability}%
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Ngày dự kiến chốt:</span>
                  <span className="font-bold text-slate-900 dark:text-white font-mono">
                    {selectedDeal.expectedCloseDate}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Người phụ trách:</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {selectedDeal.assignedTo}
                  </span>
                </div>
              </div>

              {/* Bước tiếp theo */}
              <div className="bg-sky-50 dark:bg-sky-950/40 p-3.5 rounded-xl border border-sky-200 dark:border-sky-800">
                <span className="text-[11px] font-bold text-sky-800 dark:text-sky-300 block mb-1">
                  Bước tiếp theo (Bắt buộc theo chuẩn CRM):
                </span>
                <p className="font-semibold text-slate-900 dark:text-white">{selectedDeal.nextStep}</p>
                <span className="text-[11px] text-sky-600 dark:text-sky-400 mt-1 block font-mono">
                  Hạn hoàn thành: {selectedDeal.nextStepDate}
                </span>
              </div>

              {/* Lý do thua nếu có */}
              {selectedDeal.stage === 'Thất bại (Lost)' && (
                <div className="bg-rose-50 dark:bg-rose-950/40 p-3.5 rounded-xl border border-rose-200 dark:border-rose-800 text-rose-800 dark:text-rose-300">
                  <span className="font-bold block text-[11px]">Lý do thua deal:</span>
                  <p className="font-medium mt-0.5">{selectedDeal.lostReason}</p>
                  {selectedDeal.competitorName && (
                    <p className="text-[11px] text-rose-600 mt-1">Đối thủ: {selectedDeal.competitorName}</p>
                  )}
                </div>
              )}

              {/* Cập nhật nhanh giai đoạn Cơ hội trong Drawer */}
              <div className="bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
                <span className="text-[11px] font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
                  Cập nhật giai đoạn cơ hội:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {STAGES.map((s) => {
                    const isCur = selectedDeal.stage === s.name;
                    return (
                      <button
                        key={s.name}
                        onClick={() => handleStageChange(selectedDeal.id, s.name)}
                        className={`px-2.5 py-1 rounded-md text-xs font-semibold transition-all cursor-pointer ${
                          isCur
                            ? 'bg-sky-600 text-white shadow-xs'
                            : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-sky-400'
                        }`}
                      >
                        {s.name} ({s.prob}%)
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Nút Hành Động Xuyên Suốt: Báo giá & Kỹ thuật */}
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-2">
                <button
                  onClick={() => {
                    setActiveModule('quotations');
                  }}
                  className="w-full py-2.5 rounded-xl bg-sky-600 text-white font-bold flex items-center justify-center gap-2 hover:bg-sky-700 transition-colors shadow-md text-xs"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>Tạo Báo Giá Cho Cơ Hội Này →</span>
                </button>

                <button
                  onClick={() => {
                    createTechnicalQuotationRequest({
                      opportunityId: selectedDeal.id,
                      opportunityCode: selectedDeal.code,
                      customerId: selectedDeal.customerId,
                      customerName: selectedDeal.customerName,
                      siteAddress: `${selectedDeal.customerName} - Trụ sở / Nhà xưởng`,
                      requirementDetails: `Khảo sát hiện trường và lập giải pháp kỹ thuật chi tiết cho Cơ hội: ${selectedDeal.title}. Ngân sách dự kiến: ${selectedDeal.amount.toLocaleString()} đ.`,
                      expectedBudget: selectedDeal.amount,
                      deadlineDate: selectedDeal.nextStepDate || new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                      assignedTechStaff: 'Trần Văn Nam (Kỹ sư Trưởng)',
                    });
                    setActiveModule('technical-quotations');
                  }}
                  className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-white font-bold flex items-center justify-center gap-2 transition-colors shadow-md text-xs"
                >
                  <Wrench className="w-4 h-4" />
                  <span>Yêu Cầu Kỹ Thuật (Khảo sát &amp; Bóc tách) →</span>
                </button>

                {selectedDeal.stage === 'Thành công (Won)' && (
                  <button
                    onClick={() => setActiveModule('sales-orders')}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 text-white font-bold flex items-center justify-center gap-2 hover:bg-emerald-700 transition-colors shadow-md text-xs"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Tạo Đơn Hàng Ngay →</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Thêm Cơ Hội Mới */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-lg w-full shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <Briefcase className="w-5 h-5 text-sky-600" />
                Thêm Cơ Hội Bán Hàng Mới
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateDealSubmit} className="space-y-3.5 mt-4 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Tên cơ hội / Dự án *</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="Dự án Cung cấp & Lắp đặt Hệ thống..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Khách hàng liên kết *</label>
                <select
                  value={formCustomerId}
                  onChange={(e) => setFormCustomerId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.code} - {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Giá trị dự kiến (VNĐ) *</label>
                  <input
                    type="number"
                    step={10000000}
                    required
                    value={formAmount}
                    onChange={(e) => setFormAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Ngày dự kiến chốt *</label>
                  <input
                    type="date"
                    required
                    value={formExpectedDate}
                    onChange={(e) => setFormExpectedDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Bước tiếp theo *</label>
                  <input
                    type="text"
                    required
                    value={formNextStep}
                    onChange={(e) => setFormNextStep(e.target.value)}
                    placeholder="Gặp gỡ, demo sản phẩm..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Hạn bước tiếp theo *</label>
                  <input
                    type="date"
                    required
                    value={formNextStepDate}
                    onChange={(e) => setFormNextStepDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-sky-600 text-white font-bold"
                >
                  Tạo Cơ Hội
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Xác Nhận Thua Deal (Lost) */}
      {isLostModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl text-xs">
            <h3 className="font-bold text-rose-600 text-base mb-2 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Đánh dấu Thất bại (Lost)
            </h3>
            <p className="text-slate-500 mb-3">
              Vui lòng chọn lý do chính xác để lưu vào hệ thống phân tích đối thủ &amp; nguyên nhân mất khách.
            </p>

            <div className="space-y-3">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Lý do thất bại *</label>
                <select
                  value={lostReason}
                  onChange={(e) => setLostReason(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                >
                  <option value="Giá cao">Giá cao so với ngân sách</option>
                  <option value="Đối thủ">Đối thủ cạnh tranh thắng thầu</option>
                  <option value="Chưa có ngân sách">Chưa có ngân sách / Tạm hoãn dự án</option>
                  <option value="Không phản hồi">Không phản hồi / Mất liên lạc</option>
                  <option value="Khác">Lý do khác</option>
                </select>
              </div>

              {lostReason === 'Đối thủ' && (
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Tên đối thủ cạnh tranh</label>
                  <input
                    type="text"
                    value={competitorName}
                    onChange={(e) => setCompetitorName(e.target.value)}
                    placeholder="Tên công ty đối thủ..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  />
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                onClick={() => setIsLostModalOpen(false)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600"
              >
                Hủy
              </button>
              <button
                onClick={handleConfirmLost}
                className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
              >
                Lưu Thất Bại
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
