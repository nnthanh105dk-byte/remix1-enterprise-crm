import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useWarehouse } from '../../context/WarehouseContext';
import {
  Warehouse,
  Package,
  AlertTriangle,
  Clock,
  TrendingDown,
  TrendingUp,
  Download,
  Printer,
  Calendar,
  Layers,
  Search,
  Filter,
  CheckCircle2,
  FileSpreadsheet,
  ArrowUpRight,
  ArrowDownRight,
  ShieldCheck,
  RefreshCw,
} from 'lucide-react';

export const InventoryReportView: React.FC = () => {
  const { showToast } = useCRM();
  const { warehouses, products, lots, stockInReceipts, stockOutReceipts } = useWarehouse();

  const [activeTab, setActiveTab] = useState<'movement' | 'safety' | 'expiry'>('movement');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  // 1. Calculate Warehouse KPIs
  const kpiData = useMemo(() => {
    let totalInventoryValue = 0;
    let totalPhysicalQuantity = 0;
    let totalReserved = 0;
    let underSafeStockCount = 0;

    products.forEach((p) => {
      const stockQty =
        selectedWarehouseId === 'all'
          ? Object.values(p.stocks).reduce((sum, q) => sum + q, 0)
          : p.stocks[selectedWarehouseId] || 0;

      totalPhysicalQuantity += stockQty;
      totalInventoryValue += stockQty * p.costPrice;
      totalReserved += p.reserved;

      if (stockQty < p.minSafeStock) {
        underSafeStockCount += 1;
      }
    });

    const now = new Date();
    const nearExpiryLotsCount = lots.filter((lot) => {
      if (selectedWarehouseId !== 'all' && lot.warehouseId !== selectedWarehouseId) return false;
      const expDate = new Date(lot.expiryDate);
      const diffDays = Math.ceil((expDate.getTime() - now.getTime()) / (1000 * 3600 * 24));
      return diffDays <= 60 && lot.quantity > 0;
    }).length;

    const availableQty = Math.max(0, totalPhysicalQuantity - totalReserved);

    return {
      totalInventoryValue,
      totalPhysicalQuantity,
      availableQty,
      totalReserved,
      underSafeStockCount,
      nearExpiryLotsCount,
    };
  }, [products, lots, selectedWarehouseId]);

  // 2. Filtered Movement Products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchSearch =
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.category.toLowerCase().includes(searchTerm.toLowerCase());
      return matchSearch;
    });
  }, [products, searchTerm]);

  // 3. Low stock items
  const lowStockProducts = useMemo(() => {
    return products
      .map((p) => {
        const currentStock =
          selectedWarehouseId === 'all'
            ? Object.values(p.stocks).reduce((sum, q) => sum + q, 0)
            : p.stocks[selectedWarehouseId] || 0;
        const deficit = Math.max(0, p.minSafeStock - currentStock);
        const orderRecommend = Math.max(0, p.optimalStock - currentStock);
        const estimatedCost = orderRecommend * p.costPrice;
        return {
          ...p,
          currentStock,
          deficit,
          orderRecommend,
          estimatedCost,
        };
      })
      .filter((p) => p.currentStock < p.minSafeStock);
  }, [products, selectedWarehouseId]);

  // 4. Near expiry lots
  const expiryLots = useMemo(() => {
    const now = new Date();
    return lots
      .filter((lot) => {
        if (selectedWarehouseId !== 'all' && lot.warehouseId !== selectedWarehouseId) return false;
        return lot.quantity > 0;
      })
      .map((lot) => {
        const expDate = new Date(lot.expiryDate);
        const diffDays = Math.ceil((expDate.getTime() - now.getTime()) / (1000 * 3600 * 24));
        const lotValue = lot.quantity * lot.unitCost;
        return {
          ...lot,
          diffDays,
          lotValue,
        };
      })
      .sort((a, b) => a.diffDays - b.diffDays);
  }, [lots, selectedWarehouseId]);

  return (
    <div className="space-y-6">
      {/* 1. Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-indigo-100 text-indigo-800 dark:bg-indigo-900/40 dark:text-indigo-300">
              Báo cáo Quản lý Kho (WMS Analytics)
            </span>
            <span className="text-xs text-slate-400">Nguồn sự thật về tồn kho</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-1">
            Báo cáo Tồn kho &amp; Biến động Xuất - Nhập - Tồn
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Theo dõi tổng giá trị tài sản kho, tốc độ luân chuyển theo SKU, cảnh báo dưới tồn an toàn và theo dõi hạn dùng lô hàng (FEFO).
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-sm"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            In Báo cáo
          </button>
          <button
            onClick={() => showToast('Xuất báo cáo', 'Đã xuất dữ liệu báo cáo tồn kho ra file Excel.')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition-colors shadow-sm"
          >
            <Download className="w-4 h-4" />
            Xuất Excel
          </button>
        </div>
      </div>

      {/* 2. Top Filter Bar */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <Warehouse className="w-4 h-4 text-slate-400" />
          <select
            value={selectedWarehouseId}
            onChange={(e) => setSelectedWarehouseId(e.target.value)}
            className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
          >
            <option value="all">Tất cả các kho toàn quốc</option>
            {warehouses.map((wh) => (
              <option key={wh.id} value={wh.id}>
                {wh.name} ({wh.code})
              </option>
            ))}
          </select>
        </div>

        <div className="flex-1 w-full md:w-auto relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo tên sản phẩm, mã SKU, danh mục hàng..."
            className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* 3. Executive KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Tổng giá trị tồn kho</span>
          <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
            {kpiData.totalInventoryValue.toLocaleString('vi-VN')} đ
          </div>
          <span className="text-[11px] text-indigo-500">{products.length} mã sản phẩm</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Tồn thực tế trong kho</span>
          <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {kpiData.totalPhysicalQuantity.toLocaleString('vi-VN')} đv
          </div>
          <span className="text-[11px] text-slate-400">Kiểm kê sổ cái</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Tồn khả dụng bán</span>
          <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
            {kpiData.availableQty.toLocaleString('vi-VN')} đv
          </div>
          <span className="text-[11px] text-slate-400">Sales xem trực tiếp</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Dưới tồn an toàn</span>
          <div className="text-lg font-bold text-red-600 dark:text-red-400 mt-1">
            {kpiData.underSafeStockCount} SKU
          </div>
          <span className="text-[11px] text-red-500">Cần tạo Đơn mua hàng</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Lô cận date (&lt;60 ngày)</span>
          <div className="text-lg font-bold text-amber-600 dark:text-amber-400 mt-1">
            {kpiData.nearExpiryLotsCount} lô
          </div>
          <span className="text-[11px] text-amber-500">Cần đẩy bán ưu đãi</span>
        </div>
      </div>

      {/* 4. Tab Navigation */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 rounded-t-xl">
        <button
          onClick={() => setActiveTab('movement')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'movement'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Layers className="w-4 h-4" />
          Sổ Tổng Hợp Nhập - Xuất - Tồn ({filteredProducts.length})
        </button>

        <button
          onClick={() => setActiveTab('safety')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'safety'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <AlertTriangle className="w-4 h-4 text-red-500" />
          Cảnh Báo Dưới Tồn An Toàn ({lowStockProducts.length})
        </button>

        <button
          onClick={() => setActiveTab('expiry')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'expiry'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Clock className="w-4 h-4 text-amber-500" />
          Theo Dõi Lô &amp; Hạn Dùng FEFO ({expiryLots.length})
        </button>
      </div>

      {/* 5. TAB 1: SỔ TỔNG HỢP NHẬP - XUẤT - TỒN */}
      {activeTab === 'movement' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã SKU</th>
                  <th className="px-4 py-3.5">Tên Sản Phẩm &amp; Danh Mục</th>
                  <th className="px-3 py-3.5 text-center">ĐVT</th>
                  <th className="px-3 py-3.5 text-right">Đơn Giá Vốn</th>
                  <th className="px-3 py-3.5 text-right">Tồn Thực Tế</th>
                  <th className="px-3 py-3.5 text-right">Tồn Giữ Chỗ</th>
                  <th className="px-3 py-3.5 text-right font-bold text-blue-600">Tồn Khả Dụng</th>
                  <th className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">Giá Trị Tồn Kho</th>
                  <th className="px-3 py-3.5 text-center">Trạng Thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {filteredProducts.map((p) => {
                  const physicalQty =
                    selectedWarehouseId === 'all'
                      ? Object.values(p.stocks).reduce((sum, q) => sum + q, 0)
                      : p.stocks[selectedWarehouseId] || 0;
                  const availQty = Math.max(0, physicalQty - p.reserved);
                  const totalValue = physicalQty * p.costPrice;
                  const isLow = physicalQty < p.minSafeStock;

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                      <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">
                        {p.sku}
                      </td>
                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-900 dark:text-white">{p.name}</div>
                        <div className="text-xs text-slate-400">{p.category}</div>
                      </td>
                      <td className="px-3 py-3.5 text-center text-xs">{p.unit}</td>
                      <td className="px-3 py-3.5 text-right text-xs">
                        {p.costPrice.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-3 py-3.5 text-right font-semibold text-slate-800 dark:text-slate-200">
                        {physicalQty.toLocaleString('vi-VN')}
                      </td>
                      <td className="px-3 py-3.5 text-right text-amber-600 font-semibold">
                        {p.reserved > 0 ? p.reserved.toLocaleString('vi-VN') : '-'}
                      </td>
                      <td className="px-3 py-3.5 text-right font-bold text-blue-600 dark:text-blue-400">
                        {availQty.toLocaleString('vi-VN')}
                      </td>
                      <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                        {totalValue.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-3 py-3.5 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-xs font-semibold ${
                            isLow
                              ? 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300'
                              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                          }`}
                        >
                          {isLow ? 'Thiếu hàng' : 'Đủ hàng'}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. TAB 2: CẢNH BÁO TỒN AN TOÀN */}
      {activeTab === 'safety' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="p-4 bg-red-50 dark:bg-red-950/20 border-b border-red-200 dark:border-red-900/40 text-xs text-red-800 dark:text-red-300 flex items-center justify-between">
            <span>
              Có <strong>{lowStockProducts.length} mặt hàng</strong> đang dưới ngưỡng tồn tối thiểu an toàn. Đề xuất phát sinh Đơn mua hàng (PO) sang module Vận chuyển / Mua hàng.
            </span>
            <button
              onClick={() => showToast('Đề xuất đặt hàng', 'Đã chuyển danh sách mặt hàng thiếu tồn sang Đơn mua hàng.')}
              className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded text-xs font-semibold"
            >
              Tạo Đơn mua từ hàng sắp hết →
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã SKU</th>
                  <th className="px-4 py-3.5">Tên Sản Phẩm</th>
                  <th className="px-3 py-3.5 text-right">Tồn Hiện Tại</th>
                  <th className="px-3 py-3.5 text-right">Mức An Toàn (Min)</th>
                  <th className="px-3 py-3.5 text-right">Mức Tối Ưu (Max)</th>
                  <th className="px-3 py-3.5 text-right font-bold text-red-600">Số Lượng Thiếu</th>
                  <th className="px-3 py-3.5 text-right font-bold text-indigo-600">Đề Xuất Đặt Mua</th>
                  <th className="px-3 py-3.5 text-right">Ước Tính Chi Phí</th>
                  <th className="px-4 py-3.5">Nhà Cung Cấp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {lowStockProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{p.sku}</td>
                    <td className="px-4 py-3.5 font-medium text-slate-900 dark:text-white">{p.name}</td>
                    <td className="px-3 py-3.5 text-right font-bold text-red-600">{p.currentStock} {p.unit}</td>
                    <td className="px-3 py-3.5 text-right text-xs">{p.minSafeStock} {p.unit}</td>
                    <td className="px-3 py-3.5 text-right text-xs">{p.optimalStock} {p.unit}</td>
                    <td className="px-3 py-3.5 text-right font-bold text-red-600">-{p.deficit} {p.unit}</td>
                    <td className="px-3 py-3.5 text-right font-bold text-indigo-600">+{p.orderRecommend} {p.unit}</td>
                    <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                      {p.estimatedCost.toLocaleString('vi-VN')} đ
                    </td>
                    <td className="px-4 py-3.5 text-xs text-slate-500">{p.supplierName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. TAB 3: HẠN DÙNG LÔ HÀNG (FEFO) */}
      {activeTab === 'expiry' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Số Lô Hàng</th>
                  <th className="px-4 py-3.5">Mã SKU &amp; Tên Hàng</th>
                  <th className="px-4 py-3.5">Kho Lưu Trữ</th>
                  <th className="px-3 py-3.5 text-right">Số Lượng Lô</th>
                  <th className="px-3 py-3.5 text-center">Ngày Sản Xuất</th>
                  <th className="px-3 py-3.5 text-center">Hạn Sử Dụng</th>
                  <th className="px-3 py-3.5 text-center">Còn Lại</th>
                  <th className="px-3 py-3.5 text-right font-bold">Giá Trị Lô</th>
                  <th className="px-4 py-3.5 text-center">Hành Động Đề Xuất</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {expiryLots.map((lot) => {
                  const isCritical = lot.diffDays <= 30;
                  const isWarning = lot.diffDays > 30 && lot.diffDays <= 60;
                  return (
                    <tr key={lot.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                      <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{lot.lotNumber}</td>
                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-900 dark:text-white">{lot.productName}</div>
                        <div className="text-xs text-slate-400 font-mono">{lot.sku}</div>
                      </td>
                      <td className="px-4 py-3.5 text-xs text-slate-600 dark:text-slate-300">{lot.warehouseName}</td>
                      <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">{lot.quantity}</td>
                      <td className="px-3 py-3.5 text-center text-xs font-mono">{lot.manufactureDate}</td>
                      <td className="px-3 py-3.5 text-center text-xs font-mono font-bold text-slate-900 dark:text-white">{lot.expiryDate}</td>
                      <td className="px-3 py-3.5 text-center">
                        <span
                          className={`px-2 py-0.5 rounded text-xs font-bold ${
                            isCritical
                              ? 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300'
                              : isWarning
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300'
                              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                          }`}
                        >
                          {lot.diffDays} ngày
                        </span>
                      </td>
                      <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                        {lot.lotValue.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-4 py-3.5 text-center">
                        <button
                          onClick={() => showToast('Cảnh báo cho Sales', `Đã gửi thông báo đẩy bán lô hàng ${lot.lotNumber} sang Sales.`)}
                          className="px-2.5 py-1 text-xs font-semibold rounded bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200"
                        >
                          Báo Sales đẩy bán →
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
