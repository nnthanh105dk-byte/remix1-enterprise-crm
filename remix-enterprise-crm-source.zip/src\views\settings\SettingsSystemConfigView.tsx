import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSettings } from '../../context/SettingsContext';
import {
  Building2,
  Printer,
  Hash,
  ShieldAlert,
  Clock,
  Bell,
  Network,
  Save,
  CheckCircle2,
  AlertTriangle,
  Send,
  Plus,
  Trash2,
  KeyRound,
  ExternalLink,
  Eye,
  EyeOff,
  Calendar,
} from 'lucide-react';

export const SettingsSystemConfigView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    companyConfig,
    updateCompanyConfig,
    numberingRules,
    updateNumberingRule,
    securityPolicy,
    updateSecurityPolicy,
    workingTime,
    updateWorkingTime,
    printTemplates,
    updatePrintTemplate,
    integrationConfig,
    updateIntegrationConfig,
    testSmtpConnection,
    generateNewApiKey,
    revokeApiKey,
    canAccessSettings,
  } = useSettings();

  const [activeTab, setActiveTab] = useState<
    'company' | 'print' | 'numbering' | 'security' | 'working_time' | 'notifications' | 'integrations'
  >('company');

  // Local state for company form
  const [compForm, setCompForm] = useState(companyConfig || {});
  // Local state for security policy
  const [secForm, setSecForm] = useState(securityPolicy || {});
  // Local state for working time
  const [workForm, setWorkForm] = useState(workingTime || { holidays: [] });

  React.useEffect(() => {
    if (companyConfig) setCompForm(companyConfig);
  }, [companyConfig]);

  React.useEffect(() => {
    if (securityPolicy) setSecForm(securityPolicy);
  }, [securityPolicy]);

  React.useEffect(() => {
    if (workingTime) setWorkForm(workingTime);
  }, [workingTime]);

  // Print Preview Modal
  const [previewTemplate, setPreviewTemplate] = useState<any>(null);

  // New API Key Modal
  const [isApiKeyModalOpen, setIsApiKeyModalOpen] = useState(false);
  const [apiKeyName, setApiKeyName] = useState('');
  const [selectedScopes, setSelectedScopes] = useState<string[]>(['orders:read', 'inventory:read']);

  // New Holiday Modal
  const [isHolidayModalOpen, setIsHolidayModalOpen] = useState(false);
  const [holidayName, setHolidayName] = useState('');
  const [holidayStart, setHolidayStart] = useState('2026-10-10');
  const [holidayEnd, setHolidayEnd] = useState('2026-10-10');

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    updateCompanyConfig(compForm);
  };

  const handleSaveSecurity = (e: React.FormEvent) => {
    e.preventDefault();
    updateSecurityPolicy(secForm);
  };

  const handleSaveWorkingTime = (e: React.FormEvent) => {
    e.preventDefault();
    updateWorkingTime(workForm);
  };

  const handleAddHoliday = (e: React.FormEvent) => {
    e.preventDefault();
    if (!holidayName) return;
    const newH = {
      id: `h-${Date.now()}`,
      name: holidayName,
      startDate: holidayStart,
      endDate: holidayEnd,
      year: 2026,
    };
    const updatedHolidays = [...(workForm?.holidays || []), newH];
    setWorkForm({ ...workForm, holidays: updatedHolidays });
    updateWorkingTime({ holidays: updatedHolidays });
    setIsHolidayModalOpen(false);
    setHolidayName('');
    showToast('Đã thêm ngày nghỉ lễ', `Đã thêm "${newH.name}".`, 'success');
  };

  const handleDeleteHoliday = (hId: string) => {
    const updatedHolidays = (workForm?.holidays || []).filter((h) => h.id !== hId);
    setWorkForm({ ...workForm, holidays: updatedHolidays });
    updateWorkingTime({ holidays: updatedHolidays });
  };

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800">
            <Building2 className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              Cấu Hình Hệ Thống Tổng Thể
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Thông tin công ty, mẫu in tài liệu PDF, quy tắc đánh số chứng từ tự động, bảo mật, thời gian làm việc và tích hợp cổng ngoài.
            </p>
          </div>
        </div>
      </div>

      {!canAccessSettings && (
        <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-xl text-xs text-amber-800 dark:text-amber-200 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 text-amber-600" />
          <span>
            Bạn đang xem cấu hình ở chế độ chỉ đọc. Chỉ <strong>Quản trị viên (Admin)</strong> mới có quyền lưu và cập nhật các thiết lập này.
          </span>
        </div>
      )}

      {/* 7 Tabs Navigation */}
      <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 text-xs overflow-x-auto pb-0.5">
        <button
          onClick={() => setActiveTab('company')}
          className={`px-3.5 py-2 font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'company'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Thông tin công ty</span>
        </button>

        <button
          onClick={() => setActiveTab('print')}
          className={`px-3.5 py-2 font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'print'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Printer className="w-3.5 h-3.5" />
          <span>Mẫu in &amp; Chứng từ</span>
        </button>

        <button
          onClick={() => setActiveTab('numbering')}
          className={`px-3.5 py-2 font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'numbering'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Hash className="w-3.5 h-3.5" />
          <span>Đánh số chứng từ</span>
        </button>

        <button
          onClick={() => setActiveTab('security')}
          className={`px-3.5 py-2 font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'security'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Bảo mật</span>
        </button>

        <button
          onClick={() => setActiveTab('working_time')}
          className={`px-3.5 py-2 font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'working_time'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Thời gian làm việc</span>
        </button>

        <button
          onClick={() => setActiveTab('notifications')}
          className={`px-3.5 py-2 font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'notifications'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Bell className="w-3.5 h-3.5" />
          <span>Thông báo</span>
        </button>

        <button
          onClick={() => setActiveTab('integrations')}
          className={`px-3.5 py-2 font-bold border-b-2 whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'integrations'
              ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/50 dark:bg-blue-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <Network className="w-3.5 h-3.5" />
          <span>Kết nối &amp; Tích hợp</span>
        </button>
      </div>

      {/* 1. TAB THÔNG TIN CÔNG TY */}
      {activeTab === 'company' && (
        <form onSubmit={handleSaveCompany} className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex items-center justify-between pb-3 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Thông Tin Doanh Nghiệp Phát Hành Chứng Từ</h3>
              <p className="text-[11px] text-slate-400">Thông tin này xuất hiện trên tiêu đề báo giá, hợp đồng, biên bản và phiếu xuất kho.</p>
            </div>
            <button type="submit" className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-1.5">
              <Save className="w-4 h-4" />
              <span>Lưu thông tin</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Tên công ty đầy đủ *</label>
              <input
                type="text"
                value={compForm.companyName}
                onChange={(e) => setCompForm({ ...compForm, companyName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                required
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Tên giao dịch viết tắt *</label>
              <input
                type="text"
                value={compForm.shortName}
                onChange={(e) => setCompForm({ ...compForm, shortName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                required
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Mã số thuế (MST) *</label>
              <input
                type="text"
                value={compForm.taxCode}
                onChange={(e) => setCompForm({ ...compForm, taxCode: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono font-bold"
                required
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Người đại diện pháp luật</label>
              <input
                type="text"
                value={compForm.legalRepresentative}
                onChange={(e) => setCompForm({ ...compForm, legalRepresentative: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>

            {/* Nhận diện thương hiệu & Giao diện toàn hệ thống (Dành riêng cho Admin) */}
            <div className="md:col-span-2 p-4 bg-slate-50/80 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/80 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-700">
                <div>
                  <h4 className="font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-blue-600"></span>
                    Nhận Diện Thương Hiệu &amp; Màu Sắc Hệ Thống (Toàn Doanh Nghiệp)
                  </h4>
                  <p className="text-[11px] text-slate-500">Cấu hình Logo, Icon hệ thống và màu sắc thương hiệu áp dụng toàn công ty.</p>
                </div>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                  Chỉ Quản Trị Viên (Admin)
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Logo doanh nghiệp (URL)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={compForm.logoUrl || ''}
                      onChange={(e) => setCompForm({ ...compForm, logoUrl: e.target.value })}
                      placeholder="/logo-aplus-trasparent.png"
                      className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs"
                    />
                    {compForm.logoUrl && (
                      <div className="w-9 h-9 rounded-lg border bg-white p-1 flex items-center justify-center shrink-0 shadow-2xs">
                        <img src={compForm.logoUrl} alt="Logo preview" className="max-h-full max-w-full object-contain" />
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Icon hệ thống / Favicon (URL)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={compForm.systemIconUrl || ''}
                      onChange={(e) => setCompForm({ ...compForm, systemIconUrl: e.target.value })}
                      placeholder="/logo-aplus-trasparent.png"
                      className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs"
                    />
                    {compForm.systemIconUrl && (
                      <div className="w-9 h-9 rounded-lg border bg-white p-1 flex items-center justify-center shrink-0 shadow-2xs">
                        <img src={compForm.systemIconUrl} alt="Icon preview" className="max-h-full max-w-full object-contain" />
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Màu sắc chủ đạo hệ thống (Brand Primary Color)</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={compForm.primaryColor || '#002659'}
                      onChange={(e) => setCompForm({ ...compForm, primaryColor: e.target.value })}
                      className="w-9 h-9 rounded-lg border border-slate-200 dark:border-slate-700 cursor-pointer p-0.5 bg-white"
                    />
                    <input
                      type="text"
                      value={compForm.primaryColor || '#002659'}
                      onChange={(e) => setCompForm({ ...compForm, primaryColor: e.target.value })}
                      className="flex-1 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Theme mặc định doanh nghiệp</label>
                  <select
                    value={compForm.defaultTheme || 'ocean'}
                    onChange={(e) => setCompForm({ ...compForm, defaultTheme: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 text-xs font-medium"
                  >
                    <option value="ocean">Xanh đại dương (Ocean Blue - Chuẩn A+)</option>
                    <option value="emerald">Xanh ngọc bích (Emerald Green)</option>
                    <option value="slate">Xám doanh nghiệp (Slate Corporate)</option>
                    <option value="indigo">Tím than công nghệ (Indigo Tech)</option>
                    <option value="crimson">Đỏ rượu cao cấp (Crimson Luxury)</option>
                    <option value="amber">Vàng hổ phách (Warm Amber)</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="md:col-span-2">
              <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Địa chỉ trụ sở đăng ký kinh doanh *</label>
              <input
                type="text"
                value={compForm.address}
                onChange={(e) => setCompForm({ ...compForm, address: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
                required
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Số điện thoại / Hotline</label>
              <input
                type="text"
                value={compForm.phone}
                onChange={(e) => setCompForm({ ...compForm, phone: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Email liên hệ / Website</label>
              <input
                type="text"
                value={compForm.email}
                onChange={(e) => setCompForm({ ...compForm, email: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Số tài khoản ngân hàng thụ hưởng</label>
              <input
                type="text"
                value={compForm.bankAccount}
                onChange={(e) => setCompForm({ ...compForm, bankAccount: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 font-mono"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-200 block mb-1">Ngân hàng &amp; Chi nhánh</label>
              <input
                type="text"
                value={compForm.bankName}
                onChange={(e) => setCompForm({ ...compForm, bankName: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>
        </form>
      )}

      {/* 2. TAB MẪU IN & CHỨNG TỪ */}
      {activeTab === 'print' && (
        <div className="space-y-4 text-xs">
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Cấu Hình Mẫu In &amp; Xuất PDF</h3>
              <p className="text-[11px] text-slate-400">Tùy biến tiêu đề, ghi chú chân trang, khổ giấy A4/A5 và các vị trí ký duyệt.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {printTemplates.map((t) => (
              <div key={t.docType} className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b">
                  <span className="font-bold text-sm text-slate-900 dark:text-white">{t.docName}</span>
                  <span className="px-2 py-0.5 rounded bg-slate-100 font-mono text-[10px]">{t.pageSize} - {t.orientation}</span>
                </div>
                <div>
                  <label className="text-slate-400 block text-[10px]">Tiêu đề đầu trang (Header):</label>
                  <input
                    type="text"
                    defaultValue={t.headerText}
                    onBlur={(e) => updatePrintTemplate(t.docType, { headerText: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg border bg-white dark:bg-slate-800 font-semibold"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block text-[10px]">Lời cảm ơn / Chân trang (Footer):</label>
                  <input
                    type="text"
                    defaultValue={t.footerText}
                    onBlur={(e) => updatePrintTemplate(t.docType, { footerText: e.target.value })}
                    className="w-full px-2.5 py-1.5 rounded-lg border bg-white dark:bg-slate-800"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block text-[10px] mb-1">Các vị trí ký xác nhận:</label>
                  <div className="flex flex-wrap gap-1">
                    {t.signerSlots.map((s: any) => (
                      <span key={s.id} className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-[10px] font-semibold">
                        {s.title}
                      </span>
                    ))}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setPreviewTemplate(t)}
                  className="w-full py-1.5 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 font-semibold text-center"
                >
                  Xem thử bản in mẫu
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. TAB ĐÁNH SỐ CHỨNG TỪ */}
      {activeTab === 'numbering' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
          <div className="flex items-center justify-between pb-3 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Quy Tắc Đánh Số Chứng Từ Tự Động ({numberingRules.length} Loại)</h3>
              <p className="text-[11px] text-slate-400">
                Thay đổi tiền tố và độ dài số chỉ áp dụng cho chứng từ tạo <strong>MỚI</strong>, chứng từ lịch sử được bảo toàn nguyên vẹn.
              </p>
            </div>
          </div>

          <div className="border rounded-xl overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 font-semibold border-b">
                <tr>
                  <th className="px-3 py-2.5">Loại chứng từ</th>
                  <th className="px-3 py-2.5">Tiền tố (Prefix)</th>
                  <th className="px-3 py-2.5">Độ dài số</th>
                  <th className="px-3 py-2.5">Đặt lại theo năm</th>
                  <th className="px-3 py-2.5">Ví dụ hiển thị</th>
                  <th className="px-3 py-2.5 text-right">Lưu thay đổi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {numberingRules.map((rule) => (
                  <tr key={rule.id} className="hover:bg-slate-50/50">
                    <td className="px-3 py-2.5 font-bold text-slate-900 dark:text-white">
                      {rule.docName}
                      <span className="block text-[10px] text-slate-400 font-mono">{rule.docType}</span>
                    </td>
                    <td className="px-3 py-2.5">
                      <input
                        type="text"
                        defaultValue={rule.prefix}
                        id={`prefix-${rule.id}`}
                        className="px-2 py-1 rounded border bg-white dark:bg-slate-800 font-mono font-bold w-24 uppercase"
                      />
                    </td>
                    <td className="px-3 py-2.5">
                      <select
                        defaultValue={rule.numberLength}
                        id={`len-${rule.id}`}
                        className="px-2 py-1 rounded border bg-white dark:bg-slate-800 font-mono w-20"
                      >
                        <option value={3}>3 (001)</option>
                        <option value={4}>4 (0001)</option>
                        <option value={5}>5 (00001)</option>
                        <option value={6}>6 (000001)</option>
                      </select>
                    </td>
                    <td className="px-3 py-2.5">
                      <input
                        type="checkbox"
                        defaultChecked={rule.resetYearly}
                        id={`yearly-${rule.id}`}
                        className="rounded text-blue-600"
                      />
                      <span className="ml-1.5 text-[11px]">Có (-2026-)</span>
                    </td>
                    <td className="px-3 py-2.5 font-mono text-blue-600 font-bold">
                      {rule.sampleFormat}
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      <button
                        onClick={() => {
                          const pEl = document.getElementById(`prefix-${rule.id}`) as HTMLInputElement;
                          const lEl = document.getElementById(`len-${rule.id}`) as HTMLSelectElement;
                          const yEl = document.getElementById(`yearly-${rule.id}`) as HTMLInputElement;
                          const newPrefix = pEl?.value.toUpperCase() || rule.prefix;
                          const newLen = Number(lEl?.value) || rule.numberLength;
                          const newYearly = yEl?.checked ?? rule.resetYearly;
                          const year = new Date().getFullYear();
                          const sample = newYearly
                            ? `${newPrefix}-${year}-${'1'.padStart(newLen, '0')}`
                            : `${newPrefix}-${'1'.padStart(newLen, '0')}`;
                          updateNumberingRule(rule.id, {
                            prefix: newPrefix,
                            numberLength: newLen,
                            resetYearly: newYearly,
                            sampleFormat: sample,
                          });
                        }}
                        className="px-2.5 py-1 rounded-lg border border-slate-300 hover:bg-slate-100 font-semibold"
                      >
                        Lưu
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. TAB BẢO MẬT */}
      {activeTab === 'security' && (
        <form onSubmit={handleSaveSecurity} className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex items-center justify-between pb-3 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Chính Sách Bảo Mật &amp; Phiên Đăng Nhập</h3>
              <p className="text-[11px] text-slate-400">Thiết lập độ phức tạp mật khẩu, giới hạn đăng nhập sai và thời gian tự động khóa phiên.</p>
            </div>
            <button type="submit" className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-1.5">
              <Save className="w-4 h-4" />
              <span>Áp dụng chính sách</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Độ dài mật khẩu tối thiểu</label>
              <input
                type="number"
                min={8}
                max={32}
                value={secForm.minPasswordLength}
                onChange={(e) => setSecForm({ ...secForm, minPasswordLength: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Thời gian hết phiên khi không hoạt động (Timeout)</label>
              <select
                value={secForm.sessionTimeoutMinutes}
                onChange={(e) => setSecForm({ ...secForm, sessionTimeoutMinutes: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
              >
                <option value={15}>15 phút</option>
                <option value={30}>30 phút (Mặc định)</option>
                <option value={60}>60 phút (1 giờ)</option>
                <option value={120}>120 phút (2 giờ)</option>
              </select>
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Khóa tài khoản tạm thời sau số lần đăng nhập sai</label>
              <input
                type="number"
                min={3}
                max={10}
                value={secForm.maxFailedLogins}
                onChange={(e) => setSecForm({ ...secForm, maxFailedLogins: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Thời gian lưu trữ nhật ký hoạt động (Audit Logs)</label>
              <select
                value={secForm.auditLogRetentionMonths}
                onChange={(e) => setSecForm({ ...secForm, auditLogRetentionMonths: Number(e.target.value) })}
                className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
              >
                <option value={6}>6 tháng</option>
                <option value={12}>12 tháng (1 năm - Mặc định)</option>
                <option value={24}>24 tháng (2 năm)</option>
                <option value={36}>36 tháng (3 năm)</option>
              </select>
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={secForm.forceChangePasswordFirstLogin}
                onChange={(e) => setSecForm({ ...secForm, forceChangePasswordFirstLogin: e.target.checked })}
                className="rounded text-blue-600"
              />
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                Bắt buộc đổi mật khẩu trong lần đăng nhập đầu tiên
              </span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={secForm.requireSpecialChar}
                onChange={(e) => setSecForm({ ...secForm, requireSpecialChar: e.target.checked })}
                className="rounded text-blue-600"
              />
              <span className="font-semibold text-slate-800 dark:text-slate-200">
                Yêu cầu mật khẩu phải chứa ký tự đặc biệt (!@#$%^&amp;*) và chữ hoa
              </span>
            </label>
          </div>
        </form>
      )}

      {/* 5. TAB THỜI GIAN LÀM VIỆC */}
      {activeTab === 'working_time' && (
        <form onSubmit={handleSaveWorkingTime} className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex items-center justify-between pb-3 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Lịch Làm Việc Chuẩn &amp; Danh Sách Ngày Nghỉ Lễ</h3>
              <p className="text-[11px] text-slate-400">Các cam kết SLA phản hồi Lead (4h), duyệt đơn Logistics, kỹ thuật sẽ tự động trừ ngoài giờ làm việc và ngày nghỉ lễ.</p>
            </div>
            <button type="submit" className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold flex items-center gap-1.5">
              <Save className="w-4 h-4" />
              <span>Lưu thời gian</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Giờ bắt đầu làm việc</label>
              <input
                type="time"
                value={workForm.workingHoursStart}
                onChange={(e) => setWorkForm({ ...workForm, workingHoursStart: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800 font-mono font-bold"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Giờ kết thúc làm việc</label>
              <input
                type="time"
                value={workForm.workingHoursEnd}
                onChange={(e) => setWorkForm({ ...workForm, workingHoursEnd: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800 font-mono font-bold"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Nghỉ trưa từ</label>
              <input
                type="time"
                value={workForm.lunchBreakStart}
                onChange={(e) => setWorkForm({ ...workForm, lunchBreakStart: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800 font-mono"
              />
            </div>
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Đến</label>
              <input
                type="time"
                value={workForm.lunchBreakEnd}
                onChange={(e) => setWorkForm({ ...workForm, lunchBreakEnd: e.target.value })}
                className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800 font-mono"
              />
            </div>
          </div>

          {/* Danh sách ngày nghỉ lễ */}
          <div className="space-y-2 pt-3 border-t">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 dark:text-slate-200">Danh Sách Ngày Nghỉ Lễ Năm 2026</span>
              <button
                type="button"
                onClick={() => setIsHolidayModalOpen(true)}
                className="px-2.5 py-1 rounded-lg border border-blue-200 text-blue-600 hover:bg-blue-50 font-semibold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Thêm ngày nghỉ</span>
              </button>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800 border rounded-xl">
              {workForm.holidays.map((h) => (
                <div key={h.id} className="p-2.5 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-blue-600" />
                    <div>
                      <span className="font-bold text-slate-900 dark:text-white block">{h.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        Từ ngày {h.startDate} đến ngày {h.endDate}
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleDeleteHoliday(h.id)}
                    className="p-1 text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </form>
      )}

      {/* 6. TAB THÔNG BÁO */}
      {activeTab === 'notifications' && (
        <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex items-center justify-between pb-3 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Kênh &amp; Mẫu Nội Dung Thông Báo Sự Kiện</h3>
              <p className="text-[11px] text-slate-400">Bật/tắt chuông thông báo trong ứng dụng hoặc gửi email tức thời khi phát sinh sự kiện.</p>
            </div>
          </div>

          <div className="space-y-3">
            {[
              { code: 'NEW_LOGISTICS_ORDER', name: 'Đơn hàng mới gửi sang Vận chuyển', desc: 'Thông báo cho bộ phận Logistics khi Sales chốt đơn cần điều phối xe' },
              { code: 'RETURN_ORDER', name: 'Đơn hàng bị trả về / Giao thất bại', desc: 'Báo động tức thời cho Sales để liên hệ lại khách hàng xác minh địa chỉ' },
              { code: 'EXPIRING_WARNING', name: 'Hàng hóa / Hợp đồng / Giấy tờ sắp hết hạn', desc: 'Tự động kích hoạt khi chạm ngưỡng 30 hoặc 60 ngày' },
              { code: 'PENDING_APPROVAL', name: 'Chứng từ chờ phê duyệt chiết khấu hoặc chi tiền', desc: 'Gửi nhắc nhở cho cấp quản lý trực tiếp và Giám đốc' },
            ].map((evt) => (
              <div key={evt.code} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white block">{evt.name}</span>
                  <span className="text-[11px] text-slate-400">{evt.desc}</span>
                </div>
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded text-blue-600" />
                    <span>Chuông trong App</span>
                  </label>
                  <label className="flex items-center gap-1.5 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded text-blue-600" />
                    <span>Email tức thời</span>
                  </label>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 7. TAB KẾT NỐI & TÍCH HỢP */}
      {activeTab === 'integrations' && (
        <div className="space-y-4 text-xs">
          {/* SMTP */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b">
              <div>
                <span className="font-bold text-sm text-slate-900 dark:text-white block">1. Máy chủ Gửi Email (SMTP)</span>
                <span className="text-[11px] text-slate-400">Dùng để gửi thông báo hệ thống và liên kết kích hoạt người dùng.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                  Đã kết nối
                </span>
                <button
                  type="button"
                  onClick={testSmtpConnection}
                  className="px-3 py-1.5 rounded-xl border border-blue-300 text-blue-600 hover:bg-blue-50 font-semibold flex items-center gap-1"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Gửi thử nghiệm</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <span className="text-slate-400 block text-[10px]">Máy chủ SMTP:</span>
                <input type="text" defaultValue={integrationConfig?.smtp?.host || 'smtp.sendgrid.net'} className="w-full px-2.5 py-1.5 rounded border bg-white dark:bg-slate-800 font-mono" />
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Cổng (Port):</span>
                <input type="number" defaultValue={integrationConfig?.smtp?.port || 587} className="w-full px-2.5 py-1.5 rounded border bg-white dark:bg-slate-800 font-mono" />
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Tài khoản gửi:</span>
                <input type="text" defaultValue={integrationConfig?.smtp?.username || 'no-reply@aplus-crm.com'} className="w-full px-2.5 py-1.5 rounded border bg-white dark:bg-slate-800 font-mono" />
              </div>
            </div>
          </div>

          {/* API Keys */}
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b">
              <div>
                <span className="font-bold text-sm text-slate-900 dark:text-white block">2. Khóa API Hệ Thống (API Keys)</span>
                <span className="text-[11px] text-slate-400">Cấp quyền truy cập an toàn cho Mobile App, ERP và hệ sinh thái đối tác.</span>
              </div>
              <button
                type="button"
                onClick={() => setIsApiKeyModalOpen(true)}
                className="px-3 py-1.5 rounded-xl bg-blue-600 text-white font-bold flex items-center gap-1"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Tạo khóa API</span>
              </button>
            </div>

            <div className="space-y-2">
              {(integrationConfig?.apiKeys || []).map((k) => (
                <div key={k.id} className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white block">{k.name}</span>
                    <span className="font-mono text-[11px] text-slate-500">{k.keyMasked}</span>
                    <div className="flex gap-1 mt-1">
                      {(k.scopes || []).map((s) => (
                        <span key={s} className="px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 font-mono text-[9px]">{s}</span>
                      ))}
                    </div>
                  </div>
                  <div>
                    {k.status === 'active' ? (
                      <button
                        type="button"
                        onClick={() => revokeApiKey(k.id)}
                        className="px-2.5 py-1 rounded text-rose-600 border border-rose-200 hover:bg-rose-50 text-[10px] font-bold"
                      >
                        Thu hồi
                      </button>
                    ) : (
                      <span className="text-slate-400 font-bold text-[10px]">Đã thu hồi</span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modal Thêm Ngày Nghỉ Lễ */}
      {isHolidayModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-5 border shadow-xl space-y-4">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Thêm Ngày Nghỉ Lễ</h3>
            <form onSubmit={handleAddHoliday} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Tên kỳ nghỉ lễ *</label>
                <input
                  type="text"
                  value={holidayName}
                  onChange={(e) => setHolidayName(e.target.value)}
                  placeholder="Ví dụ: Nghỉ Tết Trung Thu"
                  className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
                  required
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Từ ngày</label>
                <input
                  type="date"
                  value={holidayStart}
                  onChange={(e) => setHolidayStart(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
                  required
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Đến ngày</label>
                <input
                  type="date"
                  value={holidayEnd}
                  onChange={(e) => setHolidayEnd(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
                  required
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsHolidayModalOpen(false)} className="px-3 py-1.5 border rounded-xl">Hủy</button>
                <button type="submit" className="px-4 py-2 bg-blue-600 text-white font-bold rounded-xl">Thêm ngày nghỉ</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Tạo API Key */}
      {isApiKeyModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-sm w-full p-5 border shadow-xl space-y-4">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">Tạo Khóa API Mới</h3>
            <div className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Tên ứng dụng kết nối *</label>
                <input
                  type="text"
                  value={apiKeyName}
                  onChange={(e) => setApiKeyName(e.target.value)}
                  placeholder="Ví dụ: App Giao Hàng Đối Tác"
                  className="w-full px-3 py-2 rounded-xl border bg-white dark:bg-slate-800"
                />
              </div>
              <div className="flex justify-end gap-2 pt-2">
                <button type="button" onClick={() => setIsApiKeyModalOpen(false)} className="px-3 py-1.5 border rounded-xl">Hủy</button>
                <button
                  type="button"
                  onClick={() => {
                    if (!apiKeyName) return;
                    generateNewApiKey(apiKeyName, selectedScopes);
                    setIsApiKeyModalOpen(false);
                    setApiKeyName('');
                  }}
                  className="px-4 py-2 bg-blue-600 text-white font-bold rounded-xl"
                >
                  Khởi tạo khóa
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Xem Thử Mẫu In */}
      {previewTemplate && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 text-slate-900 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b pb-3">
              <span className="font-bold text-base">Xem Trước Mẫu In: {previewTemplate.docName}</span>
              <button onClick={() => setPreviewTemplate(null)} className="text-slate-400 hover:text-slate-700">
                ✕
              </button>
            </div>
            {/* Paper container */}
            <div className="p-6 border border-slate-300 rounded-lg shadow-inner bg-slate-50 space-y-4 text-xs font-serif">
              <div className="flex items-start justify-between border-b pb-3">
                <div>
                  <h4 className="font-bold text-sm">{companyConfig.companyName}</h4>
                  <p className="text-[10px] text-slate-600">{companyConfig.address}</p>
                  <p className="text-[10px] text-slate-600 font-mono">MST: {companyConfig.taxCode} &bull; Hotline: {companyConfig.phone}</p>
                </div>
                <div className="w-12 h-12 bg-blue-600 text-white font-bold rounded flex items-center justify-center">
                  LOGO
                </div>
              </div>

              <div className="text-center py-2">
                <h3 className="text-base font-bold tracking-wide">{previewTemplate.headerText}</h3>
                <p className="text-[10px] text-slate-500 font-mono">Số: BG-2026-0152 &bull; Ngày: 05/10/2026</p>
              </div>

              <div className="p-3 bg-white border rounded">
                <p className="italic text-slate-400 text-center">[Phần thân bảng biểu hàng hóa, dịch vụ và đơn giá của chứng từ sẽ hiển thị ở đây]</p>
              </div>

              <div className="grid grid-cols-3 gap-2 pt-6 text-center font-sans">
                {previewTemplate.signerSlots.map((slot: any) => (
                  <div key={slot.id} className="space-y-8">
                    <span className="font-bold block text-[11px]">{slot.title}</span>
                    <span className="text-[9px] text-slate-400 block">{slot.note}</span>
                  </div>
                ))}
              </div>

              <div className="pt-3 border-t text-center text-[10px] text-slate-500 italic">
                {previewTemplate.footerText}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
