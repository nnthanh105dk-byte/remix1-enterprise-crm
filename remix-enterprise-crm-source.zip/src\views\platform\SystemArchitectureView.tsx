/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * SƠ ĐỒ TRỰC QUAN KIẾN TRÚC HỆ THỐNG A+ CRM (SYSTEM ARCHITECTURE VISUALIZER)
 * Mô phỏng trực quan:
 * A+ CRM Platform -> Gateway -> Control DB (CRM_CORE) -> Resolve Tenant -> DB_APLUS, DB_ABC, DB_XYZ
 * Phân giải chuỗi User -> Membership -> Department -> Position -> Role -> Scope -> Isolated Database.
 */

import React, { useState } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import {
  Server,
  Database,
  Building2,
  Users,
  ShieldCheck,
  Layers,
  ArrowRight,
  ArrowDown,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  User,
  KeyRound,
  FileCheck2,
  Activity,
  HardDrive,
  RefreshCw,
  Eye,
} from 'lucide-react';

export const SystemArchitectureView: React.FC = () => {
  const {
    tenants,
    allDepartments,
    allMemberships,
    allAccounts,
    allRoles,
    switchTenant,
    currentCompany,
    sessionContext,
    runDataIsolationAudit,
  } = useMultiTenant();

  const [selectedTenantCode, setSelectedTenantCode] = useState<string>('APLUS');
  const [selectedMemberId, setSelectedMemberId] = useState<string>('mem_vana_aplus');
  const [auditReport, setAuditReport] = useState<any | null>(null);
  const [isRunningAudit, setIsRunningAudit] = useState(false);

  const selectedTenant = tenants.find((t) => t.code === selectedTenantCode) || tenants[0];
  const selectedMember = allMemberships.find((m) => m.id === selectedMemberId) || allMemberships[0];
  const selectedUser = allAccounts.find((u) => u.id === selectedMember?.userId);
  const selectedDept = allDepartments.find((d) => d.id === selectedMember?.departmentId);
  const selectedRole = allRoles.find((r) => r.id === selectedMember?.roleId);

  const handleRunAudit = () => {
    setIsRunningAudit(true);
    setTimeout(() => {
      const res = runDataIsolationAudit();
      setAuditReport(res);
      setIsRunningAudit(false);
    }, 450);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* 01. HEADER BANNER */}
      <div className="bg-gradient-to-r from-slate-900 via-[#002659] to-slate-900 rounded-2xl p-6 text-white shadow-xl border border-blue-900/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-300 shrink-0 shadow-lg">
              <Server className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl font-bold tracking-tight">
                  Sơ Đồ Kiến Trúc Hệ Thống (System Architecture Topology)
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-500/20 text-sky-200 border border-sky-400/30">
                  Control DB + Dedicated Tenant Databases
                </span>
              </div>
              <p className="text-slate-300 text-sm mt-1 max-w-3xl">
                Mô phỏng phân giải dữ liệu đa doanh nghiệp thời gian thực. Người dùng không bao giờ truy cập CRM chung mà được phân giải tới Database riêng biệt thông qua Membership hợp lệ.
              </p>
            </div>
          </div>

          <button
            onClick={handleRunAudit}
            disabled={isRunningAudit}
            className="px-4 py-2.5 rounded-xl bg-sky-500 hover:bg-sky-600 text-white font-bold text-xs shadow-md transition-colors flex items-center gap-2 shrink-0 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isRunningAudit ? 'animate-spin' : ''}`} />
            <span>{isRunningAudit ? 'Đang Kiểm Thử...' : 'Chạy Kiểm Thử Cách Ly CSDL'}</span>
          </button>
        </div>
      </div>

      {/* 02. INTERACTIVE ARCHITECTURE TOPOLOGY MAP */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800 mb-6">
          <div className="flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#002659] dark:text-sky-400" />
            <h2 className="font-bold text-slate-900 dark:text-white text-base">
              Bản Đồ Phân Giải Đa Tầng (Multi-Tier Resolution Flow)
            </h2>
          </div>
          <span className="text-xs text-slate-500">
            Click vào từng Tenant hoặc User bên dưới để kiểm tra chuỗi phân giải
          </span>
        </div>

        {/* TIER 1: PLATFORM GATEWAY */}
        <div className="flex flex-col items-center">
          <div className="w-full max-w-md p-4 rounded-xl bg-slate-900 text-white border-2 border-slate-700 shadow-md text-center">
            <div className="text-[10px] uppercase font-bold tracking-wider text-sky-400">Tầng 1: Cổng Truy Cập Nền Tảng (Gateway)</div>
            <div className="text-base font-bold mt-0.5">A+ CRM PLATFORM (aplus.crm.aplus.vn)</div>
            <div className="text-[11px] text-slate-400 mt-1">Xác thực Subdomain, Token, SSL &amp; Định tuyến Yêu cầu</div>
          </div>

          <ArrowDown className="w-6 h-6 text-slate-400 my-2 animate-bounce" />

          {/* TIER 2: CONTROL DB (CRM_CORE) */}
          <div className="w-full max-w-xl p-4 rounded-xl bg-blue-950 text-white border-2 border-blue-600 shadow-lg text-center relative">
            <div className="absolute top-2 right-3 flex items-center gap-1 text-[10px] bg-blue-500/30 text-blue-200 px-2 py-0.5 rounded font-mono">
              <Database className="w-3 h-3" /> Control DB
            </div>
            <div className="text-[10px] uppercase font-bold tracking-wider text-cyan-300">Tầng 2: Cơ Sở Dữ Liệu Điều Phối (Control Database)</div>
            <div className="text-lg font-bold mt-0.5 text-white">CRM_CORE</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2 text-[10px] text-slate-300 bg-blue-900/40 p-2 rounded-lg border border-blue-800">
              <div>• Tenants Registry</div>
              <div>• Users &amp; Auth</div>
              <div>• Memberships</div>
              <div>• Roles &amp; Scopes</div>
            </div>
          </div>

          <div className="flex items-center gap-2 my-2 text-xs font-bold text-slate-500">
            <span>Resolve Tenant ID &amp; Target Database Registry</span>
            <ArrowDown className="w-4 h-4 text-slate-400" />
          </div>

          {/* TIER 3: DEDICATED TENANT DATABASES */}
          <div className="w-full grid grid-cols-1 md:grid-cols-3 gap-4 mt-1">
            {tenants.map((t) => {
              const isSelected = selectedTenantCode === t.code;
              return (
                <div
                  key={t.id}
                  onClick={() => setSelectedTenantCode(t.code)}
                  className={`p-4 rounded-xl border-2 transition-all cursor-pointer relative ${
                    isSelected
                      ? 'border-[#002659] dark:border-sky-500 bg-sky-50/50 dark:bg-sky-950/30 shadow-md ring-2 ring-sky-500/20'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-white dark:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-mono text-xs font-black px-2 py-0.5 rounded bg-slate-900 text-white">
                      {t.code}
                    </span>
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" /> {t.databaseStatus}
                    </span>
                  </div>

                  <h3 className="font-bold text-slate-900 dark:text-white text-sm line-clamp-1">
                    {t.name}
                  </h3>
                  <div className="mt-2 p-2 rounded-lg bg-slate-100 dark:bg-slate-800 font-mono text-xs flex items-center justify-between text-slate-700 dark:text-slate-300">
                    <div className="flex items-center gap-1.5">
                      <Database className="w-3.5 h-3.5 text-blue-600 dark:text-sky-400" />
                      <span className="font-bold text-blue-900 dark:text-sky-300">{t.database}</span>
                    </div>
                    <span className="text-[10px] text-slate-500">{t.storageGb} GB</span>
                  </div>

                  <div className="mt-3 grid grid-cols-3 gap-1 text-[11px] text-center text-slate-600 dark:text-slate-400">
                    <div className="bg-slate-50 dark:bg-slate-800/60 p-1 rounded">
                      <span className="block font-bold text-slate-900 dark:text-white">{t.userCount}</span>
                      <span className="text-[9px]">Users</span>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800/60 p-1 rounded">
                      <span className="block font-bold text-slate-900 dark:text-white">{t.customerCount}</span>
                      <span className="text-[9px]">Customers</span>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800/60 p-1 rounded">
                      <span className="block font-bold text-slate-900 dark:text-white">{t.dealCount}</span>
                      <span className="text-[9px]">Deals</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px]">
                    <span className="text-slate-500">Plan: <strong className="text-slate-700 dark:text-slate-300">{t.plan}</strong></span>
                    {currentCompany?.id === t.id ? (
                      <span className="text-emerald-600 font-bold">● Đang kết nối</span>
                    ) : (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          switchTenant(t.id);
                        }}
                        className="text-blue-600 hover:underline font-semibold"
                      >
                        Chuyển CSDL →
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* 03. RESOLUTION CHAIN INSPECTOR FOR SELECTED TENANT & USER */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Department & Member Tree in Selected Tenant */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-3">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <Building2 className="w-4 h-4 text-sky-600" />
                Cơ Cấu Phòng Ban &amp; Nhân Sự: {selectedTenant.code}
              </h3>
              <p className="text-[11px] text-slate-500">Bấm chọn nhân sự để xem chuỗi phân giải quyền hạn</p>
            </div>
          </div>

          <div className="space-y-3">
            {allDepartments
              .filter((d) => d.tenantId === selectedTenant.id)
              .map((dept) => {
                const deptMembers = allMemberships.filter(
                  (m) => m.tenantId === selectedTenant.id && m.departmentId === dept.id
                );
                return (
                  <div key={dept.id} className="border border-slate-200 dark:border-slate-800 rounded-xl p-3 bg-slate-50/50 dark:bg-slate-800/30">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-[10px] font-bold px-1.5 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300">
                          {dept.code}
                        </span>
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">
                          {dept.name}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400">{deptMembers.length} nhân sự</span>
                    </div>

                    <div className="space-y-1.5 pl-2 border-l-2 border-blue-200 dark:border-blue-900">
                      {deptMembers.map((mem) => {
                        const acc = allAccounts.find((a) => a.id === mem.userId);
                        const isSelected = selectedMemberId === mem.id;
                        return (
                          <button
                            key={mem.id}
                            onClick={() => setSelectedMemberId(mem.id)}
                            className={`w-full text-left p-2 rounded-lg text-xs transition-colors flex items-center justify-between cursor-pointer ${
                              isSelected
                                ? 'bg-white dark:bg-slate-900 border border-blue-500 font-bold shadow-xs text-blue-900 dark:text-sky-300'
                                : 'hover:bg-white dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300'
                            }`}
                          >
                            <div className="min-w-0">
                              <div className="font-bold truncate">{acc?.fullName || mem.username}</div>
                              <div className="text-[10px] font-mono text-slate-500">{mem.displayId}</div>
                            </div>
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-700 font-semibold shrink-0">
                              {mem.roleTitle}
                            </span>
                          </button>
                        );
                      })}
                      {deptMembers.length === 0 && (
                        <div className="text-[11px] text-slate-400 italic py-1">Chưa có nhân sự trực thuộc</div>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        {/* Right: The Complete Resolution Chain Visualizer (Section 22) */}
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
                <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                  Chuỗi Phân Giải Thẩm Quyền Truy Cập (User Resolution Chain)
                </h3>
              </div>
              <span className="font-mono text-xs font-bold text-sky-600 bg-sky-50 dark:bg-sky-950 px-2 py-0.5 rounded border border-sky-200 dark:border-sky-800">
                {selectedMember.displayId}
              </span>
            </div>

            {/* Visual Step-by-Step Chain */}
            <div className="space-y-2.5">
              {/* Step 1: User */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-xs shrink-0">
                    1
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500">1. Toàn cầu: User Identity (UUID)</span>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">{selectedUser?.fullName}</h4>
                    <span className="font-mono text-[10px] text-slate-400">ID: {selectedUser?.id} • {selectedUser?.email}</span>
                  </div>
                </div>
                <span className="text-xs px-2 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 font-semibold">
                  Global User
                </span>
              </div>

              {/* Step 2: Membership */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs shrink-0">
                    2
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500">2. Quan hệ: Tenant Membership</span>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      Username: <span className="font-mono text-blue-600">{selectedMember.username}</span> • Display ID: <span className="font-mono">{selectedMember.displayId}</span>
                    </h4>
                    <span className="font-mono text-[10px] text-slate-400">Membership UUID: {selectedMember.id}</span>
                  </div>
                </div>
                <span className="text-xs px-2 py-0.5 rounded bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 font-semibold">
                  Tenant: {selectedTenant.code}
                </span>
              </div>

              {/* Step 3: Organization & Role Layer */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center font-bold text-xs shrink-0">
                    3
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500">3. Cơ cấu: Department ➔ Position ➔ Role</span>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm">
                      {selectedDept?.name} ➔ {selectedMember.roleTitle}
                    </h4>
                    <span className="text-[11px] text-slate-500">Mã Vai trò: <strong className="font-mono">{selectedRole?.code}</strong></span>
                  </div>
                </div>
                <span className="text-xs px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 font-bold font-mono">
                  Scope: {selectedRole?.defaultScope}
                </span>
              </div>

              {/* Step 4: Isolated Database Target */}
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs shrink-0">
                    4
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-emerald-700 dark:text-emerald-300">4. Đích CSDL Cách Ly (Isolated Database)</span>
                    <h4 className="font-bold text-emerald-950 dark:text-emerald-100 text-sm font-mono flex items-center gap-1.5">
                      <Database className="w-4 h-4 text-emerald-600" />
                      {selectedTenant.database}
                    </h4>
                    <span className="text-[11px] text-emerald-700 dark:text-emerald-300">
                      Chỉ truy vấn dữ liệu thuộc CSDL này. Không tồn tại quyền truy cập chéo sang CSDL khác.
                    </span>
                  </div>
                </div>
                <span className="text-xs px-2.5 py-1 rounded bg-emerald-600 text-white font-bold">
                  ● READY
                </span>
              </div>
            </div>

            {/* Permission Matrix with Scopes */}
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 block mb-2">
                Ma Trận Phân Quyền Phân Giải Theo Phạm Vi Dữ Liệu:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {(selectedMember.permissions || selectedRole?.permissions || []).slice(0, 6).map((p) => (
                  <div key={p.module} className="p-2 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs flex items-center justify-between">
                    <span className="font-semibold text-slate-700 dark:text-slate-300">{p.moduleLabel}</span>
                    <span className="font-mono text-[10px] font-bold px-1.5 py-0.2 rounded bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300">
                      {p.scope}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Special Multi-Tenant Case Study Banner (Nguyễn Văn B) */}
          <div className="mt-4 p-3.5 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 dark:border-purple-800 flex items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-purple-600 animate-pulse" />
              <div>
                <strong className="text-purple-950 dark:text-purple-200">Trường hợp Multi-Tenant (Nguyễn Văn B):</strong>
                <p className="text-[11px] text-purple-700 dark:text-purple-300 mt-0.5">
                  1 User sở hữu 3 Memberships khác nhau tại APLUS (Admin), ABC (Consultant) và XYZ (Viewer).
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                setSelectedTenantCode('APLUS');
                setSelectedMemberId('mem_vanb_aplus');
              }}
              className="px-2.5 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-700 text-white font-bold text-[11px] shrink-0 cursor-pointer"
            >
              Xem Nguyễn Văn B →
            </button>
          </div>
        </div>
      </div>

      {/* 04. DATA ISOLATION AUDIT REPORT MODAL / SECTION */}
      {auditReport && (
        <div className="bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-800 rounded-2xl p-6 shadow-md animate-in fade-in">
          <div className="flex items-center justify-between pb-3 border-b border-emerald-100 dark:border-emerald-900 mb-4">
            <div className="flex items-center gap-2 text-emerald-700 dark:text-emerald-400 font-bold">
              <ShieldCheck className="w-6 h-6" />
              <h3 className="text-base">Kết Quả Kiểm Thử Cách Ly CSDL (Isolation Audit Report)</h3>
            </div>
            <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200">
              {auditReport.passedTests}/{auditReport.totalTests} BÀI THỬ THÀNH CÔNG (100% PASSED)
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            {auditReport.results.map((r: any) => (
              <div key={r.testId} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-mono text-[10px] text-slate-500">{r.testId}</span>
                  <span className="text-[10px] font-bold text-emerald-600">PASSED ({r.latencyMs.toFixed(1)}ms)</span>
                </div>
                <div className="font-bold text-slate-900 dark:text-white">{r.testName}</div>
                <p className="text-[11px] text-slate-500 mt-1">{r.details}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
