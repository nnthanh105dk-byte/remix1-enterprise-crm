import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { SalesLead, LeadSource, LeadStatus } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import {
  UserPlus,
  Search,
  Filter,
  Phone,
  Mail,
  Building,
  Calendar,
  Clock,
  ArrowRight,
  Flame,
  CheckCircle2,
  X,
  FileSpreadsheet,
  Users,
  AlertTriangle,
  RotateCcw,
  MessageSquare,
  UserCheck,
  ExternalLink,
} from 'lucide-react';
import { useColumnVisibility, ColumnDef } from '../../hooks/useColumnVisibility';
import { ColumnVisibilityPicker } from '../../components/common/ColumnVisibilityPicker';

const LEAD_COLUMNS: ColumnDef[] = [
  { id: 'code', label: 'Mã Lead', required: true },
  { id: 'name', label: 'Họ Tên / Công Ty' },
  { id: 'contact', label: 'Liên Hệ' },
  { id: 'source', label: 'Nguồn' },
  { id: 'status', label: 'Trạng Thái' },
  { id: 'assigned', label: 'Người Phụ Trách' },
  { id: 'dates', label: 'Ngày Tạo / Liên Hệ' },
  { id: 'actions', label: 'Thao Tác' },
];

export const SalesLeadsView: React.FC = () => {
  const { currentUser, currentRole, showToast, setActiveModule } = useCRM();
  const isSalesStaff = currentRole === 'Sales Staff' || currentUser.fullName === 'Nguyễn Văn A';
  const [scopeFilter, setScopeFilter] = useState<'all' | 'assigned_to_me'>(() =>
    currentRole === 'Sales Staff' || currentUser.fullName === 'Nguyễn Văn A' ? 'assigned_to_me' : 'all'
  );
  const {
    leads,
    customers,
    addLead,
    updateLead,
    distributeLeads,
    convertLead,
    addActivity,
  } = useSales();

  // Search & Filter State
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [selectedLeadIds, setSelectedLeadIds] = useState<string[]>([]);
  const [uncontactedHoursThreshold, setUncontactedHoursThreshold] = useState<number>(4);

  const {
    columns: colDefs,
    visibleColumns,
    isVisible,
    toggleColumn,
    selectAll,
    resetToDefault,
  } = useColumnVisibility('sales_leads', LEAD_COLUMNS);

  // Selected Lead for Detail Drawer
  const [detailLead, setDetailLead] = useState<SalesLead | null>(null);

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [isConvertModalOpen, setIsConvertModalOpen] = useState(false);
  const [isDistributeModalOpen, setIsDistributeModalOpen] = useState(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);
  const [isActivityModalOpen, setIsActivityModalOpen] = useState(false);

  // Create Lead Form State
  const [formName, setFormName] = useState('');
  const [formCompany, setFormCompany] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formSource, setFormSource] = useState<LeadSource>('Website');
  const [formEstValue, setFormEstValue] = useState<number>(300000000);
  const [formNotes, setFormNotes] = useState('');
  const [formAssignedTo, setFormAssignedTo] = useState('Nguyễn Văn A');

  // Convert Lead Modal State
  const [convertCompanyName, setConvertCompanyName] = useState('');
  const [convertTaxId, setConvertTaxId] = useState('');
  const [convertContactName, setConvertContactName] = useState('');
  const [convertDealTitle, setConvertDealTitle] = useState('');
  const [convertDealAmount, setConvertDealAmount] = useState<number>(350000000);
  const [convertExpectedDate, setConvertExpectedDate] = useState('');
  const [convertExistingCustId, setConvertExistingCustId] = useState<string>('');

  // Quick Activity Form
  const [actType, setActType] = useState<'Cuộc gọi' | 'Cuộc hẹn/Họp' | 'Ghi chú'>('Cuộc gọi');
  const [actTitle, setActTitle] = useState('');
  const [actDesc, setActDesc] = useState('');

  // Helper check uncontacted > X hours
  const isUncontactedOverThreshold = (lead: SalesLead) => {
    if (lead.status !== 'Mới') return false;
    if (lead.lastContactedAt) return false;
    const createdTime = new Date(lead.createdAt).getTime();
    if (isNaN(createdTime)) return false;
    const diffHours = (Date.now() - createdTime) / (1000 * 60 * 60);
    return diffHours >= uncontactedHoursThreshold;
  };

  const myLeadsCount = leads.filter((l) => l.assignedTo === currentUser.fullName).length;

  // Filtered Leads (Sorted to put uncontacted urgent leads at the top)
  const filteredLeads = leads
    .filter((l) => {
      if (scopeFilter === 'assigned_to_me' && l.assignedTo !== currentUser.fullName) return false;
      if (statusFilter !== 'all' && l.status !== statusFilter) return false;
      if (sourceFilter !== 'all' && l.source !== sourceFilter) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return (
          l.fullName.toLowerCase().includes(q) ||
          l.company.toLowerCase().includes(q) ||
          l.phone.includes(q) ||
          l.email.toLowerCase().includes(q) ||
          l.code.toLowerCase().includes(q)
        );
      }
      return true;
    })
    .sort((a, b) => {
      const aUrgent = isUncontactedOverThreshold(a);
      const bUrgent = isUncontactedOverThreshold(b);
      if (aUrgent && !bUrgent) return -1;
      if (!aUrgent && bUrgent) return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });

  // Handle Create Lead Submit
  const handleCreateLead = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formPhone.trim()) {
      showToast('Lỗi nhập liệu', 'Vui lòng nhập họ tên và số điện thoại.', 'warning');
      return;
    }
    addLead({
      fullName: formName,
      company: formCompany,
      phone: formPhone,
      email: formEmail,
      source: formSource,
      status: 'Mới',
      assignedTo: formAssignedTo,
      estimatedValue: formEstValue,
      notes: formNotes,
    });
    setIsCreateModalOpen(false);
    // Reset
    setFormName('');
    setFormCompany('');
    setFormPhone('');
    setFormEmail('');
    setFormNotes('');
  };

  // Handle Open Convert Modal
  const openConvertModal = (lead: SalesLead) => {
    setDetailLead(lead);
    setConvertCompanyName(lead.company || lead.fullName);
    setConvertContactName(lead.fullName);
    setConvertTaxId(`010${Math.floor(1000000 + Math.random() * 9000000)}`);
    setConvertDealTitle(`Dự án Cung cấp & Triển khai - ${lead.company || lead.fullName}`);
    setConvertDealAmount(lead.estimatedValue || 350000000);
    setConvertExpectedDate(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
    setConvertExistingCustId('');
    setIsConvertModalOpen(true);
  };

  const handleConvertSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!detailLead) return;
    convertLead(detailLead.id, convertExistingCustId || undefined, {
      companyName: convertCompanyName,
      taxId: convertTaxId,
      contactName: convertContactName,
      dealTitle: convertDealTitle,
      dealAmount: convertDealAmount,
      expectedCloseDate: convertExpectedDate,
    });
    setIsConvertModalOpen(false);
  };

  const handleBatchDistribute = (rep: string) => {
    if (selectedLeadIds.length === 0) return;
    distributeLeads(selectedLeadIds, rep);
    setSelectedLeadIds([]);
    setIsDistributeModalOpen(false);
  };

  const handleAddActivitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!detailLead || !actTitle) return;
    addActivity({
      type: actType,
      title: actTitle,
      description: actDesc,
      targetType: 'lead',
      targetId: detailLead.id,
      targetCode: detailLead.code,
      targetName: detailLead.fullName,
      startTime: new Date().toISOString(),
      priority: 'Trung bình',
      assignedTo: detailLead.assignedTo,
    });
    updateLead(detailLead.id, { lastContactedAt: new Date().toISOString().replace('T', ' ').substring(0, 16) });
    setActTitle('');
    setActDesc('');
    setIsActivityModalOpen(false);
  };

  const urgentCount = leads.filter(isUncontactedOverThreshold).length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
                <UserPlus className="w-5 h-5" />
              </span>
              Quản lý Lead (Khách hàng tiềm năng)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {leads.length} Leads
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Tiếp nhận đầu mối đa kênh, tự động cảnh báo lead tồn đọng và chuyển đổi 1-bước sang Khách hàng &amp; Cơ hội bán hàng.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {selectedLeadIds.length > 0 && (
            <button
              onClick={() => setIsDistributeModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 shadow-xs"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Phân bổ ({selectedLeadIds.length})</span>
            </button>
          )}

          <button
            onClick={() => setIsExcelModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-50 shadow-xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-600" />
            <span>Nhập Excel</span>
          </button>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-sky-600 text-white hover:bg-sky-700 shadow-sm transition-all"
          >
            <UserPlus className="w-4 h-4" />
            <span>Thêm Lead Mới</span>
          </button>
        </div>
      </div>

      {/* Cảnh báo Lead chưa liên hệ > X giờ */}
      {urgentCount > 0 && (
        <div className="bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 rounded-xl p-3 sm:p-4 flex items-center justify-between gap-3 animate-pulse">
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-lg bg-rose-100 dark:bg-rose-900/60 text-rose-600 dark:text-rose-400 shrink-0">
              <Flame className="w-5 h-5" />
            </span>
            <div>
              <h4 className="text-sm font-bold text-rose-900 dark:text-rose-200 flex items-center gap-2">
                Có {urgentCount} Lead mới chưa được liên hệ quá {uncontactedHoursThreshold} giờ!
              </h4>
              <p className="text-xs text-rose-700 dark:text-rose-300 mt-0.5">
                Các dòng màu đỏ đang được ưu tiên hiển thị đầu danh sách. Vui lòng phân bổ hoặc gọi điện ngay để không bỏ lỡ cơ hội.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setStatusFilter('Mới');
              setSearchTerm('');
            }}
            className="px-3 py-1.5 text-xs font-bold rounded-lg bg-rose-600 text-white hover:bg-rose-700 shrink-0"
          >
            Xem ngay →
          </button>
        </div>
      )}

      {/* Phân quyền phân bổ lead banner (Nếu là Sales Staff hoặc đang lọc lead của tôi) */}
      {isSalesStaff && (
        <div className="bg-sky-50 dark:bg-sky-950/40 border border-sky-300 dark:border-sky-800 rounded-xl p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-center gap-3">
            <span className="p-2 rounded-lg bg-sky-100 dark:bg-sky-900/60 text-sky-600 dark:text-sky-300 shrink-0">
              <Users className="w-5 h-5" />
            </span>
            <div>
              <h4 className="text-sm font-bold text-sky-950 dark:text-sky-100 flex items-center gap-2">
                Góc nhìn Chuyên viên Sales: {currentUser.fullName}
                <span className="px-2 py-0.5 rounded text-[11px] bg-sky-200 dark:bg-sky-900 text-sky-800 dark:text-sky-200 font-semibold">
                  {myLeadsCount} Lead được phân bổ
                </span>
              </h4>
              <p className="text-xs text-sky-700 dark:text-sky-300 mt-0.5">
                Bạn có thể cập nhật trạng thái Lead nhanh bằng menu trực tiếp trên từng dòng, hoặc bấm &ldquo;Chuyển đổi&rdquo; sang Cơ hội.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setScopeFilter('assigned_to_me')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                scopeFilter === 'assigned_to_me'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700'
              }`}
            >
              Chỉ Lead của tôi ({myLeadsCount})
            </button>
            <button
              onClick={() => setScopeFilter('all')}
              className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                scopeFilter === 'all'
                  ? 'bg-sky-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700'
              }`}
            >
              Toàn bộ ({leads.length})
            </button>
          </div>
        </div>
      )}

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-1 max-w-md">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Tìm theo mã, họ tên, công ty, SĐT, email..."
              className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-sky-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Trạng thái:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:outline-none"
            >
              <option value="all">Tất cả ({leads.length})</option>
              <option value="Mới">Mới ({leads.filter((l) => l.status === 'Mới').length})</option>
              <option value="Đang liên hệ">Đang liên hệ ({leads.filter((l) => l.status === 'Đang liên hệ').length})</option>
              <option value="Đủ điều kiện">Đủ điều kiện ({leads.filter((l) => l.status === 'Đủ điều kiện').length})</option>
              <option value="Không phù hợp">Không phù hợp ({leads.filter((l) => l.status === 'Không phù hợp').length})</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 font-medium">Nguồn:</span>
            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 focus:outline-none"
            >
              <option value="all">Tất cả nguồn</option>
              <option value="Website">Website</option>
              <option value="Facebook">Facebook</option>
              <option value="Zalo">Zalo</option>
              <option value="Giới thiệu">Giới thiệu</option>
              <option value="Hotline">Hotline</option>
              <option value="Khác">Khác</option>
            </select>
          </div>

          <ColumnVisibilityPicker
            columns={colDefs}
            visibleColumns={visibleColumns}
            onToggle={toggleColumn}
            onSelectAll={selectAll}
            onReset={resetToDefault}
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800 uppercase text-[11px]">
              <tr>
                <th className="py-3 px-3 w-8">
                  <input
                    type="checkbox"
                    checked={selectedLeadIds.length === filteredLeads.length && filteredLeads.length > 0}
                    onChange={(e) => {
                      if (e.target.checked) setSelectedLeadIds(filteredLeads.map((l) => l.id));
                      else setSelectedLeadIds([]);
                    }}
                    className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                  />
                </th>
                {isVisible('code') && <th className="py-3 px-3">Mã Lead</th>}
                {isVisible('name') && <th className="py-3 px-3">Họ Tên / Công Ty</th>}
                {isVisible('contact') && <th className="py-3 px-3">Liên Hệ</th>}
                {isVisible('source') && <th className="py-3 px-3">Nguồn</th>}
                {isVisible('status') && <th className="py-3 px-3">Trạng Thái</th>}
                {isVisible('assigned') && <th className="py-3 px-3">Người Phụ Trách</th>}
                {isVisible('dates') && <th className="py-3 px-3">Ngày Tạo / Liên Hệ</th>}
                {isVisible('actions') && <th className="py-3 px-3 text-right">Thao Tác</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredLeads.map((lead) => {
                const isUrgent = isUncontactedOverThreshold(lead);
                const isSelected = selectedLeadIds.includes(lead.id);

                return (
                  <tr
                    key={lead.id}
                    className={`transition-colors hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer ${
                      isUrgent
                        ? 'bg-rose-50/60 dark:bg-rose-950/20 border-l-4 border-rose-500 font-medium'
                        : isSelected
                        ? 'bg-sky-50/50 dark:bg-sky-950/30'
                        : ''
                    }`}
                    onClick={() => setDetailLead(lead)}
                  >
                    <td className="py-3 px-3" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={(e) => {
                          if (e.target.checked) setSelectedLeadIds((prev) => [...prev, lead.id]);
                          else setSelectedLeadIds((prev) => prev.filter((id) => id !== lead.id));
                        }}
                        className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                      />
                    </td>

                    {isVisible('code') && (
                      <td className="py-3 px-3 font-mono font-bold text-sky-600 dark:text-sky-400">
                        {lead.code}
                      </td>
                    )}

                    {isVisible('name') && (
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                          {lead.fullName}
                          {isUrgent && (
                            <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-600 text-white font-bold animate-pulse">
                              &gt;{uncontactedHoursThreshold}h Chưa Gọi
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 mt-0.5">
                          <Building className="w-3 h-3 text-slate-400 shrink-0" />
                          <span className="truncate max-w-[200px]">{lead.company || 'Cá nhân'}</span>
                        </div>
                      </td>
                    )}

                    {isVisible('contact') && (
                      <td className="py-3 px-3">
                        <div className="flex items-center gap-1 text-slate-700 dark:text-slate-200">
                          <Phone className="w-3 h-3 text-emerald-500" />
                          <span className="font-mono">{lead.phone}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[160px]">
                          {lead.email}
                        </div>
                      </td>
                    )}

                    {isVisible('source') && (
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {lead.source}
                        </span>
                      </td>
                    )}

                    {isVisible('status') && (
                      <td className="py-3 px-3" onClick={(e) => e.stopPropagation()}>
                        <select
                          value={lead.status}
                          onChange={(e) => {
                            const newStatus = e.target.value as LeadStatus;
                            updateLead(lead.id, { status: newStatus });
                            showToast('Cập nhật trạng thái Lead', `Đã đổi trạng thái lead ${lead.fullName} sang: ${newStatus}`);
                          }}
                          className={`text-[11px] font-bold rounded-lg border px-2 py-1 cursor-pointer transition-colors ${
                            lead.status === 'Đủ điều kiện'
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300 dark:bg-emerald-950/70 dark:text-emerald-300 dark:border-emerald-700'
                              : lead.status === 'Đang liên hệ'
                              ? 'bg-sky-50 text-sky-800 border-sky-300 dark:bg-sky-950/70 dark:text-sky-300 dark:border-sky-700'
                              : lead.status === 'Mới'
                              ? 'bg-amber-50 text-amber-800 border-amber-300 dark:bg-amber-950/70 dark:text-amber-300 dark:border-amber-700'
                              : 'bg-slate-100 text-slate-700 border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700'
                          }`}
                        >
                          <option value="Mới">Mới</option>
                          <option value="Đang liên hệ">Đang liên hệ</option>
                          <option value="Đủ điều kiện">Đủ điều kiện</option>
                          <option value="Không phù hợp">Không phù hợp</option>
                        </select>
                      </td>
                    )}

                    {isVisible('assigned') && (
                      <td className="py-3 px-3 font-medium text-slate-800 dark:text-slate-200">
                        {lead.assignedTo}
                      </td>
                    )}

                    {isVisible('dates') && (
                      <td className="py-3 px-3 text-[11px]">
                        <div>{lead.createdAt.split(' ')[0]}</div>
                        <div className="text-slate-400 text-[10px]">
                          {lead.lastContactedAt ? `Gọi: ${lead.lastContactedAt}` : 'Chưa liên hệ'}
                        </div>
                      </td>
                    )}

                    {isVisible('actions') && (
                      <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          {lead.status !== 'Đủ điều kiện' ? (
                            <button
                              onClick={() => openConvertModal(lead)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 transition-colors shadow-xs"
                              title="Chuyển đổi thành Khách hàng & Cơ hội"
                            >
                              <UserCheck className="w-3 h-3" />
                              <span>Chuyển đổi</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => setActiveModule('opportunities')}
                              className="inline-flex items-center gap-1 px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-xs hover:bg-slate-200 font-semibold"
                            >
                              <ExternalLink className="w-3 h-3 text-sky-500" />
                              <span>Xem Deal</span>
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })}
              {filteredLeads.length === 0 && (
                <tr>
                  <td colSpan={1 + (colDefs.filter(c => isVisible(c.id)).length || 1)} className="py-8 text-center text-slate-400">
                    Không tìm thấy lead nào phù hợp với điều kiện tìm kiếm.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Right Drawer: Chi Tiết Lead & Hoạt Động */}
      {detailLead && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-800 h-full overflow-y-auto flex flex-col p-6 shadow-2xl">
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs px-2.5 py-1 rounded bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 font-bold">
                  {detailLead.code}
                </span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold">
                  {detailLead.status}
                </span>
              </div>
              <button
                onClick={() => setDetailLead(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Document Chain Bar */}
            <div className="mt-4">
              <DocumentChainBar
                currentType="lead"
                chain={{
                  leadId: detailLead.id,
                  leadCode: detailLead.code,
                  customerId: detailLead.convertedTo?.customerId,
                  opportunityId: detailLead.convertedTo?.opportunityId,
                }}
              />
            </div>

            {/* Thông tin Lead */}
            <div className="mt-5 space-y-4 text-xs">
              <div>
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  {detailLead.fullName}
                </h2>
                <p className="text-slate-500 font-medium">{detailLead.company || 'Khách hàng cá nhân'}</p>
              </div>

              <div className="grid grid-cols-2 gap-3 bg-slate-50 dark:bg-slate-800/60 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800">
                <div>
                  <span className="text-slate-400 block text-[11px]">Số điện thoại:</span>
                  <span className="font-bold font-mono text-slate-900 dark:text-white">
                    {detailLead.phone}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Email:</span>
                  <span className="font-medium text-slate-900 dark:text-white truncate block">
                    {detailLead.email}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Nguồn thu thập:</span>
                  <span className="font-bold text-sky-600">{detailLead.source}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Người phụ trách:</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    {detailLead.assignedTo}
                  </span>
                </div>
              </div>

              <div>
                <span className="text-slate-400 block text-[11px] mb-1">Nhu cầu / Ghi chú ban đầu:</span>
                <p className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg text-slate-700 dark:text-slate-300 text-xs">
                  {detailLead.notes || 'Chưa có ghi chú'}
                </p>
              </div>

              {/* Nút thao tác nhanh: Gọi điện / Ghi chú / Đặt lịch hẹn */}
              <div className="flex items-center gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  onClick={() => {
                    setActType('Cuộc gọi');
                    setActTitle(`Gọi điện cho ${detailLead.fullName}`);
                    setIsActivityModalOpen(true);
                  }}
                  className="flex-1 py-2 px-3 rounded-lg bg-emerald-600 text-white font-bold flex items-center justify-center gap-1.5 hover:bg-emerald-700 transition-colors shadow-xs"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Gọi Điện</span>
                </button>

                <button
                  onClick={() => {
                    setActType('Ghi chú');
                    setActTitle(`Ghi chú trao đổi với ${detailLead.fullName}`);
                    setIsActivityModalOpen(true);
                  }}
                  className="flex-1 py-2 px-3 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold flex items-center justify-center gap-1.5 hover:bg-slate-200 transition-colors"
                >
                  <MessageSquare className="w-3.5 h-3.5 text-sky-500" />
                  <span>Ghi Chú</span>
                </button>

                <button
                  onClick={() => {
                    setActType('Cuộc hẹn/Họp');
                    setActTitle(`Hẹn gặp tư vấn với ${detailLead.fullName}`);
                    setIsActivityModalOpen(true);
                  }}
                  className="flex-1 py-2 px-3 rounded-lg bg-sky-600 text-white font-bold flex items-center justify-center gap-1.5 hover:bg-sky-700 transition-colors shadow-xs"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Đặt Lịch Hẹn</span>
                </button>
              </div>

              {/* Nút Chuyển đổi lớn nếu chưa chuyển đổi */}
              {detailLead.status !== 'Đủ điều kiện' && (
                <div className="pt-2">
                  <button
                    onClick={() => openConvertModal(detailLead)}
                    className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-md hover:from-emerald-700 hover:to-teal-700 transition-all"
                  >
                    <UserCheck className="w-4 h-4" />
                    <span>Chuyển đổi thành Khách hàng &amp; Cơ hội bán hàng ngay</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal 1: Tạo Lead Mới */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-lg w-full shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-sky-600" />
                Thêm Khách Hàng Tiềm Năng (Lead) Mới
              </h3>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateLead} className="space-y-3.5 mt-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                    Họ và Tên *
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="Nguyễn Văn A"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                    Tên Doanh nghiệp / Tổ chức
                  </label>
                  <input
                    type="text"
                    value={formCompany}
                    onChange={(e) => setFormCompany(e.target.value)}
                    placeholder="Công ty CP ABC"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                    Số Điện Thoại *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="0912 345 678"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="contact@company.vn"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                    Nguồn Thu Thập
                  </label>
                  <select
                    value={formSource}
                    onChange={(e) => setFormSource(e.target.value as LeadSource)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="Website">Website</option>
                    <option value="Facebook">Facebook</option>
                    <option value="Zalo">Zalo</option>
                    <option value="Giới thiệu">Giới thiệu</option>
                    <option value="Hotline">Hotline</option>
                    <option value="Khác">Khác</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                    Người Phụ Trách
                  </label>
                  <select
                    value={formAssignedTo}
                    onChange={(e) => setFormAssignedTo(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                  >
                    <option value="Nguyễn Văn A">Nguyễn Văn A (Nhân viên Sales)</option>
                    <option value="Hồ Hoàng Long">Hồ Hoàng Long (Trưởng Phòng Sale)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                  Nhu cầu chi tiết / Ghi chú
                </label>
                <textarea
                  rows={3}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="Khách hàng quan tâm giải pháp máy chủ, hạ tầng mạng hoặc WMS..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Hủy bỏ
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-sky-600 text-white font-bold hover:bg-sky-700 shadow-sm"
                >
                  Lưu Lead
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Chuyển Đổi Lead (1 bước tạo Khách hàng + Contact + Cơ hội) */}
      {isConvertModalOpen && detailLead && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-xl w-full shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-emerald-600" />
                Chuyển Đổi Lead: {detailLead.code}
              </h3>
              <button
                onClick={() => setIsConvertModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleConvertSubmit} className="space-y-4 mt-4 text-xs">
              <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs">
                Hành động này sẽ tạo đồng thời <strong>Khách hàng mới</strong> (hoặc gán khách hàng cũ), <strong>Người liên hệ</strong> và <strong>Cơ hội bán hàng</strong> ban đầu. Dữ liệu sẽ tự động kế thừa.
              </div>

              {/* Tùy chọn gán vào khách hàng đã có */}
              <div>
                <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                  Chọn Khách Hàng (Tùy chọn gán vào Khách đã có sẵn):
                </label>
                <select
                  value={convertExistingCustId}
                  onChange={(e) => setConvertExistingCustId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                >
                  <option value="">-- Tạo Khách hàng Doanh nghiệp mới từ Lead này --</option>
                  {customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.code} - {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {!convertExistingCustId && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                      Tên Khách Hàng / Công Ty *
                    </label>
                    <input
                      type="text"
                      required
                      value={convertCompanyName}
                      onChange={(e) => setConvertCompanyName(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                      Mã Số Thuế (MST)
                    </label>
                    <input
                      type="text"
                      value={convertTaxId}
                      onChange={(e) => setConvertTaxId(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                    />
                  </div>
                </div>
              )}

              <div className="border-t border-slate-100 dark:border-slate-800 pt-3">
                <h4 className="font-bold text-slate-800 dark:text-slate-200 mb-2">
                  Thông Tin Cơ Hội Bán Hàng (Opportunity):
                </h4>
                <div className="space-y-3">
                  <div>
                    <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                      Tên Cơ Hội *
                    </label>
                    <input
                      type="text"
                      required
                      value={convertDealTitle}
                      onChange={(e) => setConvertDealTitle(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                        Giá Trị Dự Kiến (VNĐ) *
                      </label>
                      <input
                        type="number"
                        step={10000000}
                        required
                        value={convertDealAmount}
                        onChange={(e) => setConvertDealAmount(Number(e.target.value))}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-600 dark:text-slate-300 font-semibold mb-1">
                        Ngày Dự Kiến Chốt *
                      </label>
                      <input
                        type="date"
                        required
                        value={convertExpectedDate}
                        onChange={(e) => setConvertExpectedDate(e.target.value)}
                        className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsConvertModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-100 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-600 text-white font-bold hover:bg-emerald-700 shadow-sm"
                >
                  Xác Nhận Chuyển Đổi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 3: Phân Bổ Hàng Loạt */}
      {isDistributeModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 max-w-sm w-full shadow-2xl">
            <h3 className="font-bold text-slate-900 dark:text-white text-sm mb-3">
              Phân bổ {selectedLeadIds.length} lead đã chọn
            </h3>
            <div className="space-y-2 text-xs">
              <button
                onClick={() => handleBatchDistribute('Nguyễn Văn A')}
                className="w-full py-2.5 px-3 text-left rounded-lg border border-sky-200 dark:border-sky-800 bg-sky-50/70 dark:bg-sky-950/40 hover:bg-sky-100 dark:hover:bg-sky-900/60 font-medium transition-colors"
              >
                Giao cho: <strong className="text-sky-700 dark:text-sky-300">Nguyễn Văn A</strong> (Nhân viên Sales phụ trách)
              </button>
            </div>
            <button
              onClick={() => setIsDistributeModalOpen(false)}
              className="mt-4 w-full py-2 text-xs text-slate-500 hover:text-slate-800 font-semibold"
            >
              Đóng
            </button>
          </div>
        </div>
      )}

      {/* Modal 4: Nhập Excel */}
      {isExcelModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white text-base mb-2">
              Nhập Lead Hàng Loạt từ Excel
            </h3>
            <p className="text-slate-500 mb-4">
              Tải mẫu Excel và tải lên để hệ thống tự động kiểm tra trùng lặp theo số điện thoại và email.
            </p>
            <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-8 text-center bg-slate-50 dark:bg-slate-800/50">
              <FileSpreadsheet className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <p className="font-medium text-slate-700 dark:text-slate-300">
                Kéo thả file .xlsx hoặc bấm để tải lên
              </p>
              <span className="text-[11px] text-slate-400">Dung lượng tối đa: 10MB</span>
            </div>
            <div className="flex items-center justify-end gap-2 mt-5">
              <button
                onClick={() => setIsExcelModalOpen(false)}
                className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={() => {
                  showToast('Đang xử lý Excel', 'Đã nhập thành công 12 lead mới từ tệp Excel.', 'success');
                  setIsExcelModalOpen(false);
                }}
                className="px-4 py-2 rounded-lg bg-emerald-600 text-white font-bold"
              >
                Bắt đầu Nhập
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal 5: Ghi Hoạt Động Nhanh */}
      {isActivityModalOpen && detailLead && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white text-base mb-3">
              Ghi {actType} cho: {detailLead.fullName}
            </h3>
            <form onSubmit={handleAddActivitySubmit} className="space-y-3">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Tiêu đề hoạt động *</label>
                <input
                  type="text"
                  required
                  value={actTitle}
                  onChange={(e) => setActTitle(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Nội dung trao đổi / Kết quả</label>
                <textarea
                  rows={3}
                  value={actDesc}
                  onChange={(e) => setActDesc(e.target.value)}
                  placeholder="Khách hàng phản hồi rất tích cực, yêu cầu gửi báo giá trong tuần..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsActivityModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-sky-600 text-white font-bold"
                >
                  Lưu Hoạt Động
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
