import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { useTechnical } from '../../context/TechnicalContext';
import { WarrantyStockOut, WarrantyStockOutItem, DefectiveItemCollected } from '../../types/technical';
import { APlusLogo } from '../../components/common/APlusLogo';
import {
  Wrench,
  Search,
  Plus,
  CheckCircle2,
  AlertTriangle,
  Printer,
  X,
  Package,
  RotateCcw,
  Calendar,
  Building,
  User,
  ShieldAlert,
} from 'lucide-react';

export const TechnicalWarrantyStockOutView: React.FC = () => {
  const { showToast } = useCRM();
  const { products, warehouses } = useWarehouse();
  const {
    warrantyStockOuts,
    warrantyTickets,
    createWarrantyStockOut,
  } = useTechnical();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStockOut, setSelectedStockOut] = useState<WarrantyStockOut | null>(null);
  const [printStockOut, setPrintStockOut] = useState<WarrantyStockOut | null>(null);

  // Modal tạo phiếu xuất kho bảo hành
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedTicketId, setSelectedTicketId] = useState(warrantyTickets[0]?.id || '');
  const [warehouseId, setWarehouseId] = useState('wh-hn');
  const [technicianName, setTechnicianName] = useState('Lê Hữu Đạt (Kỹ sư Bảo hành)');
  const [notes, setNotes] = useState('Xuất linh kiện thay thế tại chỗ cho khách hàng theo cam kết SLA');

  // Hàng thay thế
  const [replacementItems, setReplacementItems] = useState<WarrantyStockOutItem[]>([
    {
      sku: products[0]?.sku || 'HIK-MAIN-8MP',
      productName: products[0]?.name || 'Bo mạch thay thế Camera IP',
      quantity: 1,
      serialNumber: 'MB-NEW-2026',
      unitPrice: 1500000,
      total: 1500000,
    },
  ]);

  // Hàng hỏng thu hồi
  const [defectiveItems, setDefectiveItems] = useState<DefectiveItemCollected[]>([
    {
      sku: products[0]?.sku || 'HIK-MAIN-8MP',
      productName: 'Bo mạch lỗi thu hồi',
      quantity: 1,
      serialNumber: 'MB-OLD-8892',
      defectReason: 'Cháy chip nguồn mạng do sét đánh lan truyền',
    },
  ]);

  const filteredList = warrantyStockOuts.filter((item) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        item.code.toLowerCase().includes(q) ||
        item.customerName.toLowerCase().includes(q) ||
        item.ticketCode.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicketId) return;

    createWarrantyStockOut(
      selectedTicketId,
      warehouseId,
      technicianName,
      replacementItems,
      defectiveItems,
      notes
    );

    setIsCreateModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-100 dark:border-sky-900/50">
              <Wrench className="w-5 h-5" />
            </span>
            Xuất Kho Bảo Hành &amp; Đổi Trả (Warranty Stock Out)
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Mã chứng từ XBH-2026-xxxx: Quản lý xuất linh kiện / thiết bị thay thế cho sự cố bảo hành và thu hồi thiết bị hỏng về kho cách ly
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#002659] text-white hover:bg-[#001c42] shadow-xs transition-colors shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Tạo phiếu xuất bảo hành</span>
        </button>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="relative max-w-sm w-full">
          <input
            type="text"
            placeholder="Tìm theo số phiếu XBH, mã sự cố, khách hàng..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
          />
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
        </div>

        <div className="text-slate-400 text-xs">
          Tổng cộng: <strong>{filteredList.length}</strong> phiếu xuất bảo hành
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden text-xs">
        <table className="w-full text-left">
          <thead className="bg-slate-100 dark:bg-slate-800 font-bold text-slate-700 dark:text-slate-300">
            <tr>
              <th className="p-3">Số Phiếu &amp; Ngày</th>
              <th className="p-3">Khách Hàng &amp; Sự Cố</th>
              <th className="p-3">Kho Xuất &amp; Kỹ Sư</th>
              <th className="p-3">Thiết Bị / Linh Kiện Xuất Đổi</th>
              <th className="p-3">Hàng Hỏng Thu Hồi</th>
              <th className="p-3 text-center">Trạng Thái</th>
              <th className="p-3 text-center w-20">In Phiếu</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredList.length === 0 ? (
              <tr>
                <td colSpan={7} className="p-8 text-center text-slate-400 italic">
                  Chưa có phiếu xuất bảo hành nào.
                </td>
              </tr>
            ) : (
              filteredList.map((item) => (
                <tr key={item.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="p-3">
                    <span className="font-mono font-bold text-sky-600 block">{item.code}</span>
                    <span className="text-[11px] text-slate-400 font-mono">{item.date}</span>
                  </td>
                  <td className="p-3">
                    <div className="font-semibold text-slate-900 dark:text-white">{item.customerName}</div>
                    <span className="font-mono text-xs text-rose-600 font-bold">
                      Sự cố: {item.ticketCode}
                    </span>
                  </td>
                  <td className="p-3">
                    <div className="font-semibold text-slate-800 dark:text-slate-200">{item.technicianName}</div>
                    <span className="text-[11px] text-slate-400">{item.warehouseName}</span>
                  </td>
                  <td className="p-3 space-y-1">
                    {item.replacementItems.map((r, idx) => (
                      <div key={idx} className="flex items-center gap-1.5">
                        <span className="font-semibold text-slate-900 dark:text-white">{r.productName}</span>
                        <span className="font-mono text-emerald-600 font-bold">x{r.quantity}</span>
                        {r.serialNumber && <span className="font-mono text-[10px] text-slate-400">(SN: {r.serialNumber})</span>}
                      </div>
                    ))}
                  </td>
                  <td className="p-3 space-y-1">
                    {item.defectiveItemsCollected.map((d, idx) => (
                      <div key={idx} className="text-rose-600 text-[11px]">
                        <strong>{d.productName}</strong> x{d.quantity}
                        {d.defectReason && <span className="text-slate-500 block text-[10px] italic">- {d.defectReason}</span>}
                      </div>
                    ))}
                  </td>
                  <td className="p-3 text-center">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">
                      {item.status}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => setPrintStockOut(item)}
                      className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100"
                      title="In phiếu xuất bảo hành"
                    >
                      <Printer className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal: Tạo Phiếu Xuất Bảo Hành */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 my-8 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800 mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                Lập Phiếu Xuất Kho Bảo Hành (XBH)
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-3">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">
                  Chọn Yêu Cầu Sự Cố / Bảo Hành Cần Thay Thế *
                </label>
                <select
                  value={selectedTicketId}
                  onChange={(e) => setSelectedTicketId(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                >
                  {warrantyTickets.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.code} - {t.customerName}: {t.equipmentName} ({t.symptoms})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Kho xuất linh kiện</label>
                  <select
                    value={warehouseId}
                    onChange={(e) => setWarehouseId(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    {warehouses.map((wh) => (
                      <option key={wh.id} value={wh.id}>
                        {wh.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Kỹ sư thực hiện</label>
                  <input
                    type="text"
                    value={technicianName}
                    onChange={(e) => setTechnicianName(e.target.value)}
                    className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-semibold"
                  />
                </div>
              </div>

              <div className="p-3 bg-sky-50 dark:bg-sky-950/40 rounded-lg space-y-2 border border-sky-200 dark:border-sky-800">
                <span className="font-bold text-sky-900 dark:text-sky-200 block">Linh kiện / Thiết bị xuất thay thế:</span>
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <input
                      type="text"
                      placeholder="Tên linh kiện thay thế..."
                      value={replacementItems[0]?.productName || ''}
                      onChange={(e) => {
                        const updated = [...replacementItems];
                        updated[0].productName = e.target.value;
                        setReplacementItems(updated);
                      }}
                      className="w-full p-1.5 rounded border border-sky-300 bg-white dark:bg-slate-800 font-medium"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Serial mới..."
                      value={replacementItems[0]?.serialNumber || ''}
                      onChange={(e) => {
                        const updated = [...replacementItems];
                        updated[0].serialNumber = e.target.value;
                        setReplacementItems(updated);
                      }}
                      className="w-full p-1.5 rounded border border-sky-300 bg-white dark:bg-slate-800 font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-lg space-y-2 border border-rose-200 dark:border-rose-800">
                <span className="font-bold text-rose-900 dark:text-rose-200 block">Hàng lỗi thu hồi về kho cách ly:</span>
                <div className="grid grid-cols-3 gap-2">
                  <div className="col-span-2">
                    <input
                      type="text"
                      placeholder="Tên thiết bị / linh kiện hỏng thu hồi..."
                      value={defectiveItems[0]?.productName || ''}
                      onChange={(e) => {
                        const updated = [...defectiveItems];
                        updated[0].productName = e.target.value;
                        setDefectiveItems(updated);
                      }}
                      className="w-full p-1.5 rounded border border-rose-300 bg-white dark:bg-slate-800 font-medium"
                    />
                  </div>
                  <div>
                    <input
                      type="text"
                      placeholder="Lý do hỏng..."
                      value={defectiveItems[0]?.defectReason || ''}
                      onChange={(e) => {
                        const updated = [...defectiveItems];
                        updated[0].defectReason = e.target.value;
                        setDefectiveItems(updated);
                      }}
                      className="w-full p-1.5 rounded border border-rose-300 bg-white dark:bg-slate-800 text-[11px]"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-medium mb-1">Ghi chú biên bản</label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full p-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#002659] text-white font-semibold shadow-xs"
                >
                  Xác nhận xuất bảo hành
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal In Phiếu Xuất Bảo Hành */}
      {printStockOut && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-xl max-w-2xl w-full p-8 shadow-2xl my-8 text-xs font-serif leading-relaxed">
            <div className="flex justify-between items-start pb-4 border-b border-slate-300 mb-6">
              <APlusLogo />
              <div className="text-right">
                <h4 className="font-bold text-sm">CÔNG TY CỔ PHẦN CÔNG NGHỆ A+</h4>
                <p className="text-[11px] text-slate-500">Mã phiếu: {printStockOut.code}</p>
                <p className="text-[11px] text-slate-500">Ngày lập: {printStockOut.date}</p>
              </div>
            </div>

            <div className="text-center my-6">
              <h2 className="text-lg font-bold uppercase tracking-wider">PHIẾU XUẤT KHO BẢO HÀNH &amp; THU HỒI HÀNG LỖI</h2>
              <p className="text-[11px] italic">Căn cứ theo yêu cầu sự cố: {printStockOut.ticketCode}</p>
            </div>

            <div className="space-y-1.5 mb-6">
              <p>- Khách hàng: <strong>{printStockOut.customerName}</strong></p>
              <p>- Kho xuất thiết bị: <strong>{printStockOut.warehouseName}</strong></p>
              <p>- Kỹ sư thực hiện thay thế: <strong>{printStockOut.technicianName}</strong></p>
            </div>

            <h4 className="font-bold mb-2">1. Hàng hóa / Linh kiện xuất thay thế:</h4>
            <table className="w-full text-left border-collapse border border-slate-300 mb-4">
              <thead className="bg-slate-100 font-bold">
                <tr>
                  <th className="border border-slate-300 p-2">Tên linh kiện thay thế</th>
                  <th className="border border-slate-300 p-2 font-mono text-center">Serial Number</th>
                  <th className="border border-slate-300 p-2 text-center w-16">SL</th>
                </tr>
              </thead>
              <tbody>
                {printStockOut.replacementItems.map((r, idx) => (
                  <tr key={idx}>
                    <td className="border border-slate-300 p-2 font-semibold">{r.productName}</td>
                    <td className="border border-slate-300 p-2 font-mono text-center">{r.serialNumber || '-'}</td>
                    <td className="border border-slate-300 p-2 text-center font-bold">{r.quantity}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <h4 className="font-bold mb-2">2. Hàng hóa / Thiết bị hỏng thu hồi về kho cách ly:</h4>
            <table className="w-full text-left border-collapse border border-slate-300 mb-6">
              <thead className="bg-slate-100 font-bold">
                <tr>
                  <th className="border border-slate-300 p-2">Tên thiết bị thu hồi</th>
                  <th className="border border-slate-300 p-2 text-center w-16">SL</th>
                  <th className="border border-slate-300 p-2">Tình trạng hư hỏng / Lý do thu hồi</th>
                </tr>
              </thead>
              <tbody>
                {printStockOut.defectiveItemsCollected.map((d, idx) => (
                  <tr key={idx}>
                    <td className="border border-slate-300 p-2 font-semibold">{d.productName}</td>
                    <td className="border border-slate-300 p-2 text-center font-bold">{d.quantity}</td>
                    <td className="border border-slate-300 p-2 text-rose-700 italic">{d.defectReason}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="grid grid-cols-3 gap-2 text-center pt-8 border-t border-slate-300">
              <div>
                <p className="font-bold">Đại diện khách hàng ký nhận</p>
                <div className="h-16" />
                <p className="font-semibold">Khách hàng</p>
              </div>
              <div>
                <p className="font-bold">Kỹ sư bảo hành</p>
                <div className="h-16" />
                <p className="font-semibold">{printStockOut.technicianName}</p>
              </div>
              <div>
                <p className="font-bold">Thủ kho xuất hàng</p>
                <div className="h-16" />
                <p className="font-semibold">Thủ kho</p>
              </div>
            </div>

            <div className="mt-8 pt-4 border-t border-slate-200 flex justify-end gap-2 no-print">
              <button
                onClick={() => setPrintStockOut(null)}
                className="px-4 py-2 border border-slate-300 rounded font-sans font-bold"
              >
                Đóng
              </button>
              <button
                onClick={() => window.print()}
                className="px-4 py-2 bg-sky-600 text-white rounded font-sans font-bold"
              >
                In Phiếu (PDF)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
