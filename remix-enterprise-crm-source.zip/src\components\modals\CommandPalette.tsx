import React, { useState, useEffect, useRef } from 'react';
import { useCRM } from '../../context/CRMContext';
import {
  Search,
  Plus,
  Briefcase,
  Users2,
  CheckSquare,
  GitBranch,
  BarChart3,
  Moon,
  Sun,
  FileSpreadsheet,
  DollarSign,
  FileText,
  PhoneCall,
  Clock,
  ArrowRight,
  X,
  Target,
} from 'lucide-react';

export const CommandPalette: React.FC = () => {
  const {
    commandPaletteOpen,
    setCommandPaletteOpen,
    setActiveModule,
    leads,
    opportunities,
    contacts,
    theme,
    setTheme,
    language,
    showToast,
  } = useCRM();

  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const isVi = language === 'vi';

  // Global keydown listener for Cmd+K / Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCommandPaletteOpen(!commandPaletteOpen);
      }
      if (e.key === 'Escape' && commandPaletteOpen) {
        setCommandPaletteOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [commandPaletteOpen, setCommandPaletteOpen]);

  useEffect(() => {
    if (commandPaletteOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [commandPaletteOpen]);

  if (!commandPaletteOpen) return null;

  // Actions list
  const systemActions = [
    {
      id: 'new-lead',
      category: 'Quick Action',
      title: isVi ? 'Tạo Khách hàng tiềm năng mới (Lead)' : 'Create New Lead',
      subtitle: isVi ? 'Mở danh sách và biểu mẫu tạo Lead' : 'Open leads workspace and create modal',
      icon: Plus,
      iconColor: 'text-[#002659] bg-slate-100',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('leads');
      },
    },
    {
      id: 'new-deal',
      category: 'Quick Action',
      title: isVi ? 'Tạo Cơ hội thương mại (Deal / Opportunity)' : 'Create Deal Opportunity',
      subtitle: isVi ? 'Thêm deal mới vào Pipeline bán hàng' : 'Add new deal into sales pipeline',
      icon: Briefcase,
      iconColor: 'text-emerald-600 bg-emerald-50',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('opportunities');
      },
    },
    {
      id: 'new-quote',
      category: 'Sales',
      title: isVi ? 'Lập Báo giá & Đề xuất (Quotation)' : 'Create Quotation',
      subtitle: isVi ? 'Mở trình dựng báo giá sản phẩm & chiết khấu' : 'Open quote builder',
      icon: FileSpreadsheet,
      iconColor: 'text-sky-600 bg-sky-50',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('quotations');
      },
    },
    {
      id: 'my-tasks',
      category: 'Tasks',
      title: isVi ? 'Xem công việc cần làm hôm nay' : "View Today's Tasks",
      subtitle: isVi ? 'Danh sách các cuộc gọi và cuộc họp đến hạn' : 'Tasks and follow-ups due today',
      icon: CheckSquare,
      iconColor: 'text-rose-600 bg-rose-50',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('tasks');
      },
    },
    {
      id: 'accounting-debt',
      category: 'Accounting',
      title: isVi ? 'Kế toán: Quản lý Công nợ' : 'Accounting: Debt Management',
      subtitle: isVi ? 'Theo dõi công nợ phải thu, phải trả và sổ chi tiết' : 'Manage receivables and payables',
      icon: DollarSign,
      iconColor: 'text-emerald-600 bg-emerald-50',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('accounting-debt');
      },
    },
    {
      id: 'accounting-invoices',
      category: 'Accounting',
      title: isVi ? 'Kế toán: Hóa đơn & Báo giá' : 'Accounting: Invoices & Quotes',
      subtitle: isVi ? 'Hóa đơn bán ra, mua vào, quản lý số HĐĐT' : 'Manage sales/purchase invoices and e-invoices',
      icon: FileSpreadsheet,
      iconColor: 'text-blue-600 bg-blue-50',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('accounting-invoices');
      },
    },
    {
      id: 'accounting-cashflow',
      category: 'Accounting',
      title: isVi ? 'Kế toán: Giao dịch & Dòng tiền' : 'Accounting: Cash Flow',
      subtitle: isVi ? 'Sổ quỹ thu chi, số dư ngân hàng và dự báo dòng tiền' : 'Cash transactions and forecasting',
      icon: DollarSign,
      iconColor: 'text-amber-600 bg-amber-50',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('accounting-transactions');
      },
    },
    {
      id: 'accounting-reports',
      category: 'Accounting',
      title: isVi ? 'Kế toán: Báo cáo tài chính quản trị' : 'Accounting: Financial Reports',
      subtitle: isVi ? 'Báo cáo P&L quản trị, phân tích tuổi nợ và biên lợi nhuận' : 'Management P&L, aging and margin reports',
      icon: FileText,
      iconColor: 'text-purple-600 bg-purple-50',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('accounting-reports');
      },
    },
    {
      id: 'toggle-theme',
      category: 'Appearance',
      title: isVi ? 'Đổi chế độ Sáng / Tối' : 'Toggle Dark / Light Theme',
      subtitle: theme === 'modern-dark' ? 'Chuyển sang Corporate Blue' : 'Chuyển sang Modern Dark Executive',
      icon: theme === 'modern-dark' ? Sun : Moon,
      iconColor: 'text-slate-600 bg-slate-100',
      action: () => {
        setTheme(theme === 'modern-dark' ? 'corporate-blue' : 'modern-dark');
        setCommandPaletteOpen(false);
        showToast('Giao diện', 'Đã chuyển đổi chủ đề hiển thị');
      },
    },
  ];

  // Matching records
  const matchingLeads = leads
    .filter(
      (l) =>
        l.fullName.toLowerCase().includes(query.toLowerCase()) ||
        l.company.toLowerCase().includes(query.toLowerCase()) ||
        l.code.toLowerCase().includes(query.toLowerCase())
    )
    .slice(0, 3)
    .map((l) => ({
      id: `rec-lead-${l.id}`,
      category: 'Records: Leads',
      title: `${l.fullName} — ${l.company}`,
      subtitle: `Điểm tiềm năng: ${l.score}/100 • Trạng thái: ${l.status}`,
      icon: Target,
      iconColor: 'text-blue-600 bg-blue-50',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('leads');
      },
    }));

  const matchingDeals = opportunities
    .filter(
      (o) =>
        o.title.toLowerCase().includes(query.toLowerCase()) ||
        o.company.toLowerCase().includes(query.toLowerCase()) ||
        o.code.toLowerCase().includes(query.toLowerCase())
    )
    .slice(0, 3)
    .map((o) => ({
      id: `rec-deal-${o.id}`,
      category: 'Records: Deals',
      title: `${o.title} (${o.company})`,
      subtitle: `Giá trị: ${(o.amount / 1000000).toFixed(0)} Tr ₫ • Giai đoạn: ${o.stage}`,
      icon: Briefcase,
      iconColor: 'text-emerald-600 bg-emerald-50',
      action: () => {
        setCommandPaletteOpen(false);
        setActiveModule('opportunities');
      },
    }));

  const allFiltered = [
    ...systemActions.filter(
      (a) =>
        a.title.toLowerCase().includes(query.toLowerCase()) ||
        a.subtitle.toLowerCase().includes(query.toLowerCase()) ||
        a.category.toLowerCase().includes(query.toLowerCase())
    ),
    ...(query.trim() ? [...matchingLeads, ...matchingDeals] : []),
  ];

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1) % Math.max(1, allFiltered.length));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 + allFiltered.length) % Math.max(1, allFiltered.length));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (allFiltered[selectedIndex]) {
        allFiltered[selectedIndex].action();
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-6 sm:pt-20 px-2.5 sm:px-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-2xl bg-white dark:bg-[#001226] rounded-2xl shadow-2xl border border-slate-200 dark:border-sky-900/50 overflow-hidden flex flex-col max-h-[88vh] sm:max-h-[80vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 px-4 py-3.5 border-b border-slate-200 dark:border-sky-900/40">
          <Search className="w-5 h-5 text-slate-400 dark:text-sky-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyDown}
            placeholder={
              isVi
                ? 'Tìm kiếm khách hàng, deals, báo giá, hoặc gõ lệnh... (ESC để đóng)'
                : 'Search records, deals, quotations, or run commands... (ESC to close)'
            }
            className="w-full text-sm bg-transparent text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-400 focus:outline-hidden"
          />
          <button
            onClick={() => setCommandPaletteOpen(false)}
            className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-[#001633] shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List */}
        <div className="flex-1 overflow-y-auto p-2 divide-y divide-slate-100 dark:divide-sky-950">
          {allFiltered.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              {isVi ? 'Không tìm thấy kết quả phù hợp' : 'No matching results found'}
            </div>
          ) : (
            <div className="space-y-1">
              {allFiltered.map((item, idx) => {
                const IconComponent = item.icon;
                const isSelected = idx === selectedIndex;
                return (
                  <button
                    key={item.id}
                    onClick={item.action}
                    onMouseEnter={() => setSelectedIndex(idx)}
                    className={`w-full text-left px-3 py-2.5 rounded-xl flex items-center justify-between gap-3 transition-colors ${
                      isSelected
                        ? 'bg-[#F0F7FD] dark:bg-[#001633] text-[#002659] dark:text-sky-300'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-[#001633]/60'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div
                        className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${item.iconColor}`}
                      >
                        <IconComponent className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-semibold truncate text-slate-900 dark:text-slate-100">
                            {item.title}
                          </span>
                          <span className="text-[10px] px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-sky-950/80 text-slate-500 dark:text-sky-400 font-medium">
                            {item.category}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                          {item.subtitle}
                        </p>
                      </div>
                    </div>
                    {isSelected && (
                      <ArrowRight className="w-4 h-4 text-[#3661C9] dark:text-sky-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer shortcuts helper */}
        <div className="px-4 py-2 bg-slate-50 dark:bg-[#001633] border-t border-slate-200 dark:border-sky-900/40 flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-3">
            <span>
              <kbd className="px-1.5 py-0.5 rounded-sm bg-white dark:bg-[#001226] border border-slate-200 dark:border-sky-800 text-[10px] font-mono shadow-2xs mr-1">
                ↑↓
              </kbd>
              {isVi ? 'Di chuyển' : 'Navigate'}
            </span>
            <span>
              <kbd className="px-1.5 py-0.5 rounded-sm bg-white dark:bg-[#001226] border border-slate-200 dark:border-sky-800 text-[10px] font-mono shadow-2xs mr-1">
                Enter
              </kbd>
              {isVi ? 'Chọn' : 'Select'}
            </span>
          </div>
          <span className="text-[10px] text-slate-400">
            A+ Command Engine • {allFiltered.length} {isVi ? 'tác vụ' : 'actions'}
          </span>
        </div>
      </div>
    </div>
  );
};
