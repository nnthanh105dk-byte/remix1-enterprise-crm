import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSettings } from '../../context/SettingsContext';
import { SyncRunRecord, DataImportExportLog, SystemAuditLogItem } from '../../types/settings';
import {
  Activity,
  RefreshCw,
  FileSpreadsheet,
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Download,
  RotateCcw,
  Search,
  Filter,
  Eye,
  Clock,
  Layers,
  ArrowDownLeft,
  ArrowUpRight,
} from 'lucide-react';

export const SettingsSyncLogsView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    syncRuns,
    triggerManualSync,
    importExportLogs,
    rollbackImport,
    auditLogs,
    canAccessSettings,
  } = useSettings();

  const [activeTab, setActiveTab] = useState<'sync' | 'import_export' | 'audit'>('sync');

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [moduleFilter, setModuleFilter] = useState('all');
  const [sensitiveOnly, setSensitiveOnly] = useState(false);

  // Selected error detail modal
  const [selectedSyncError, setSelectedSyncError] = useState<SyncRunRecord | null>(null);

  // Filtered audit logs
  const filteredAuditLogs = useMemo(() => {
    return (auditLogs || []).filter((a) => {
      if (sensitiveOnly && !a.isSensitiveAccess) return false;
      if (moduleFilter !== 'all' && a.module !== moduleFilter) return false;
      if (searchTerm) {
        const q = searchTerm.toLowerCase();
        return (
          a.userName.toLowerCase().includes(q) ||
          a.objectCode.toLowerCase().includes(q) ||
          a.objectName.toLowerCase().includes(q) ||
          a.changesSummary.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [auditLogs, sensitiveOnly, moduleFilter, searchTerm]);

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 border border-cyan-200 dark:border-cyan-800">
            <Activity className="w-5 h-5" />
          </span>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              Giám Sát &amp; Nhật Ký Hệ Thống (Monitoring Logs)
            </h1>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Nhật ký đồng bộ tích hợp, lịch sử nhập/xuất file Excel có tính năng hoàn tác, và nhật ký hoạt động (Audit log) bất biến.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => showToast('Xuất Nhật ký', 'Đã tải xuống file Excel toàn bộ nhật ký kiểm toán.', 'success')}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 text-xs font-semibold flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Xuất file Audit Log</span>
          </button>
        </div>
      </div>

      {/* Tabs Switcher */}
      <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 text-xs">
        <button
          onClick={() => setActiveTab('sync')}
          className={`px-4 py-2.5 font-bold border-b-2 flex items-center gap-2 ${
            activeTab === 'sync'
              ? 'border-cyan-600 text-cyan-600 dark:text-cyan-400 bg-cyan-50/50 dark:bg-cyan-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <RefreshCw className="w-4 h-4" />
          <span>Đồng Bộ &amp; Tích Hợp ({(syncRuns || []).length})</span>
        </button>

        <button
          onClick={() => setActiveTab('import_export')}
          className={`px-4 py-2.5 font-bold border-b-2 flex items-center gap-2 ${
            activeTab === 'import_export'
              ? 'border-cyan-600 text-cyan-600 dark:text-cyan-400 bg-cyan-50/50 dark:bg-cyan-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Nhập / Xuất Dữ Liệu ({(importExportLogs || []).length})</span>
        </button>

        <button
          onClick={() => setActiveTab('audit')}
          className={`px-4 py-2.5 font-bold border-b-2 flex items-center gap-2 ${
            activeTab === 'audit'
              ? 'border-cyan-600 text-cyan-600 dark:text-cyan-400 bg-cyan-50/50 dark:bg-cyan-950/20'
              : 'border-transparent text-slate-600 hover:text-slate-900'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Nhật Ký Hoạt Động (Audit Log - {(auditLogs || []).length})</span>
        </button>
      </div>

      {/* TAB 1: ĐỒNG BỘ & TÍCH HỢP */}
      {activeTab === 'sync' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex items-center justify-between pb-2 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Lịch Sử Các Tiến Trình Đồng Bộ &amp; Tích Hợp</h3>
              <p className="text-[11px] text-slate-400">Theo dõi tiến trình đồng bộ dữ liệu kết nối nội bộ giữa các phân hệ nghiệp vụ.</p>
            </div>
            <button
              onClick={() => triggerManualSync('Đồng bộ Dữ liệu Kho - Kỹ thuật')}
              className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-700 text-white font-bold flex items-center gap-1.5 shadow-sm"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Chạy đồng bộ ngay</span>
            </button>
          </div>

          <div className="border rounded-xl overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 font-semibold border-b">
                <tr>
                  <th className="px-3 py-2.5">Thời gian</th>
                  <th className="px-3 py-2.5">Kênh nguồn / Đích</th>
                  <th className="px-3 py-2.5">Chiều</th>
                  <th className="px-3 py-2.5">Số bản ghi (Thành công / Lỗi)</th>
                  <th className="px-3 py-2.5">Thời lượng</th>
                  <th className="px-3 py-2.5">Người kích hoạt</th>
                  <th className="px-3 py-2.5">Trạng thái</th>
                  <th className="px-3 py-2.5 text-right">Chi tiết</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {syncRuns.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-50/50">
                    <td className="px-3 py-2.5 font-mono text-slate-600">{r.startTime}</td>
                    <td className="px-3 py-2.5 font-bold text-slate-900 dark:text-white">{r.sourceDestination}</td>
                    <td className="px-3 py-2.5">
                      {r.direction === 'INBOUND' ? (
                        <span className="flex items-center gap-1 text-blue-600 font-semibold">
                          <ArrowDownLeft className="w-3.5 h-3.5" /> Nhận vào
                        </span>
                      ) : (
                        <span className="flex items-center gap-1 text-purple-600 font-semibold">
                          <ArrowUpRight className="w-3.5 h-3.5" /> Đẩy ra
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 font-mono font-bold">
                      <span className="text-emerald-600">{r.successRecords}</span> /{' '}
                      <span className={r.failedRecords > 0 ? 'text-rose-600' : 'text-slate-400'}>{r.failedRecords} lỗi</span>
                    </td>
                    <td className="px-3 py-2.5 font-mono text-slate-500">{r.durationMs} ms</td>
                    <td className="px-3 py-2.5">{r.triggeredBy}</td>
                    <td className="px-3 py-2.5">
                      {r.status === 'SUCCESS' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">Thành công</span>
                      )}
                      {r.status === 'PARTIAL' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700">Một phần lỗi</span>
                      )}
                      {r.status === 'FAILED' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">Thất bại</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      {r.errorDetails && r.errorDetails.length > 0 ? (
                        <button
                          onClick={() => setSelectedSyncError(r)}
                          className="px-2 py-1 rounded bg-rose-50 text-rose-600 border border-rose-200 font-semibold"
                        >
                          Xem {r.errorDetails.length} lỗi
                        </button>
                      ) : (
                        <span className="text-slate-400">—</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: NHẬP / XUẤT DỮ LIỆU */}
      {activeTab === 'import_export' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex items-center justify-between pb-2 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Nhật Ký Nhập / Xuất Excel Toàn Hệ Thống</h3>
              <p className="text-[11px] text-slate-400">Kiểm tra kết quả import từng dòng lỗi và hỗ trợ hoàn tác thu hồi dữ liệu nhập nhầm.</p>
            </div>
          </div>

          <div className="border rounded-xl overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 font-semibold border-b">
                <tr>
                  <th className="px-3 py-2.5">Thời gian</th>
                  <th className="px-3 py-2.5">Loại</th>
                  <th className="px-3 py-2.5">Module &amp; Đối tượng</th>
                  <th className="px-3 py-2.5">Tên tệp</th>
                  <th className="px-3 py-2.5">Số dòng</th>
                  <th className="px-3 py-2.5">Người thực hiện</th>
                  <th className="px-3 py-2.5">Trạng thái</th>
                  <th className="px-3 py-2.5 text-right">Hoàn tác</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {importExportLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="px-3 py-2.5 font-mono text-slate-600">{log.timestamp}</td>
                    <td className="px-3 py-2.5 font-bold">
                      {log.type === 'IMPORT' ? (
                        <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-700">Nhập Excel</span>
                      ) : (
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700">Xuất Excel</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 font-bold text-slate-900 dark:text-white">
                      {log.entityType}
                      <span className="block text-[10px] text-slate-400 font-normal">{log.moduleName}</span>
                    </td>
                    <td className="px-3 py-2.5 font-mono text-slate-600">{log.fileName}</td>
                    <td className="px-3 py-2.5 font-mono">
                      <span className="text-emerald-600 font-bold">{log.successRows}</span> / {log.totalRows} dòng
                    </td>
                    <td className="px-3 py-2.5">{log.performedBy}</td>
                    <td className="px-3 py-2.5">
                      {log.status === 'SUCCESS' ? (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700">Hoàn tất</span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-700">{log.errorRows} lỗi dòng</span>
                      )}
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      {log.type === 'IMPORT' && log.canRollback && !log.isRolledBack && (
                        <button
                          onClick={() => rollbackImport(log.id)}
                          className="px-2.5 py-1 text-rose-600 hover:bg-rose-50 border border-rose-200 rounded-lg text-xs font-semibold flex items-center gap-1 ml-auto"
                          title="Thu hồi các bản ghi vừa nhập"
                        >
                          <RotateCcw className="w-3 h-3" />
                          <span>Hoàn tác</span>
                        </button>
                      )}
                      {log.isRolledBack && (
                        <span className="text-slate-400 italic text-[11px]">Đã hoàn tác</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT LOG (NHẬT KÝ HOẠT ĐỘNG) */}
      {activeTab === 'audit' && (
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4 text-xs">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-2 border-b">
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">Nhật Ký Kiểm Toán Hoạt Động (Audit Log)</h3>
              <p className="text-[11px] text-slate-400">Dữ liệu chỉ đọc, không thể chỉnh sửa hoặc xóa bởi bất kỳ người dùng nào.</p>
            </div>

            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-300 bg-amber-50 dark:bg-amber-950/30 text-amber-800 dark:text-amber-300 font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={sensitiveOnly}
                  onChange={(e) => setSensitiveOnly(e.target.checked)}
                  className="rounded text-amber-600"
                />
                <span>Chỉ xem: Dữ liệu nhạy cảm</span>
              </label>
            </div>
          </div>

          <div className="border rounded-xl overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 dark:bg-slate-800 text-slate-600 font-semibold border-b">
                <tr>
                  <th className="px-3 py-2.5">Thời gian &amp; IP</th>
                  <th className="px-3 py-2.5">Người thực hiện</th>
                  <th className="px-3 py-2.5">Module</th>
                  <th className="px-3 py-2.5">Hành động</th>
                  <th className="px-3 py-2.5">Đối tượng</th>
                  <th className="px-3 py-2.5">Chi tiết thay đổi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredAuditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="px-3 py-2.5 font-mono text-slate-600 whitespace-nowrap">
                      {log.timestamp}
                      <span className="block text-[10px] text-slate-400">{log.ipAddress}</span>
                    </td>
                    <td className="px-3 py-2.5 font-bold text-slate-900 dark:text-white">
                      {log.userName}
                      <span className="block text-[10px] text-slate-400 font-normal">{log.userRole}</span>
                    </td>
                    <td className="px-3 py-2.5 font-semibold text-slate-600">{log.module}</td>
                    <td className="px-3 py-2.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.action === 'TẠO MỚI'
                            ? 'bg-emerald-100 text-emerald-700'
                            : log.action === 'CẬP NHẬT'
                            ? 'bg-blue-100 text-blue-700'
                            : log.action === 'XÓA'
                            ? 'bg-rose-100 text-rose-700'
                            : log.action === 'DUYỆT'
                            ? 'bg-purple-100 text-purple-700'
                            : log.action === 'XEM DỮ LIỆU NHẠY CẢM'
                            ? 'bg-amber-100 text-amber-700 font-extrabold'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {log.action}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 font-mono font-bold text-slate-800 dark:text-slate-200">
                      {log.objectCode}
                      <span className="block text-[10px] text-slate-400 font-normal">{log.objectName}</span>
                    </td>
                    <td className="px-3 py-2.5 text-slate-700 dark:text-slate-300">
                      {log.changesSummary}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Chi Tiết Lỗi Đồng Bộ */}
      {selectedSyncError && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-5 border shadow-xl space-y-4 text-xs">
            <div className="flex items-center justify-between border-b pb-2">
              <span className="font-bold text-base text-rose-600">Chi Tiết Lỗi Đồng Bộ</span>
              <button onClick={() => setSelectedSyncError(null)} className="text-slate-400 hover:text-slate-600">✕</button>
            </div>
            <div className="space-y-2">
              <p className="font-semibold text-slate-800 dark:text-slate-200">
                Kênh: <strong>{selectedSyncError.sourceDestination}</strong>
              </p>
              <div className="space-y-1.5 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 font-mono text-[11px]">
                {selectedSyncError.errorDetails?.map((err, i) => (
                  <div key={i} className="text-rose-700 dark:text-rose-300">
                    &bull; Dòng {err.line}: {err.entityId ? `[${err.entityId}] ` : ''}{err.message}
                  </div>
                ))}
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  showToast('Thử lại', 'Hệ thống đang tiến hành đẩy lại các dòng bị lỗi.', 'info');
                  setSelectedSyncError(null);
                }}
                className="px-4 py-2 bg-rose-600 text-white font-bold rounded-xl"
              >
                Thử lại các dòng lỗi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
