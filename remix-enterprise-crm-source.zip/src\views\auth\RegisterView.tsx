import React, { useState, useEffect } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import {
  Building2,
  Lock,
  Mail,
  User,
  Phone,
  Eye,
  EyeOff,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  Users,
  TrendingUp,
  Settings2,
  ShieldCheck,
  Sparkles,
  Shield,
  MapPin,
  FileText,
  Database,
  ExternalLink,
} from 'lucide-react';
import { CompanyRegistrationRequest } from '../../types/auth';

export const RegisterView: React.FC = () => {
  const {
    submitCompanyRegistration,
    checkCompanyCodeAvailability,
    setAuthScreenMode,
    setIsPlatformMode,
  } = useMultiTenant();

  const [companyName, setCompanyName] = useState('');
  const [companyCode, setCompanyCode] = useState('');
  const [taxCode, setTaxCode] = useState('');
  const [companyPhone, setCompanyPhone] = useState('');
  const [companyAddress, setCompanyAddress] = useState('');
  const [adminName, setAdminName] = useState('');
  const [email, setEmail] = useState('');
  const [adminPhone, setAdminPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [agreedTerms, setAgreedTerms] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [isCodeManual, setIsCodeManual] = useState(false);

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [submittedRequest, setSubmittedRequest] = useState<CompanyRegistrationRequest | null>(null);

  // Realtime Code Validation
  const [codeValidation, setCodeValidation] = useState<{ valid: boolean; available: boolean; error?: string }>({
    valid: false,
    available: false,
  });

  // Tự động sinh mã công ty theo tên
  const handleCompanyNameChange = (val: string) => {
    setCompanyName(val);
    if (!isCodeManual) {
      const autoCode = val
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-zA-Z0-9]/g, '')
        .toUpperCase()
        .slice(0, 10);
      setCompanyCode(autoCode);
    }
  };

  useEffect(() => {
    if (!companyCode.trim()) {
      setCodeValidation({ valid: false, available: false });
      return;
    }
    const res = checkCompanyCodeAvailability(companyCode);
    setCodeValidation(res);
  }, [companyCode]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!companyCode.trim()) {
      setErrorMessage('Vui lòng nhập hoặc sinh mã công ty.');
      return;
    }

    if (password.length < 6) {
      setErrorMessage('Mật khẩu phải chứa ít nhất 6 ký tự.');
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage('Mật khẩu và xác nhận mật khẩu không trùng khớp.');
      return;
    }

    if (!agreedTerms) {
      setErrorMessage('Vui lòng đồng ý với Điều khoản dịch vụ và Chính sách bảo mật.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await submitCompanyRegistration({
        companyName,
        companyCode: companyCode.toUpperCase().trim(),
        taxCode,
        phone: companyPhone,
        address: companyAddress,
        adminName,
        email,
        adminPhone,
        password,
        agreedTerms,
      });

      if (res.success && res.request) {
        setSubmittedRequest(res.request);
      } else {
        setErrorMessage(res.error || 'Đã có lỗi xảy ra khi gửi đăng ký.');
      }
    } catch (err: any) {
      setErrorMessage('Đã xảy ra lỗi hệ thống khi đăng ký.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-white text-[#172033] flex flex-col lg:flex-row">
      {/* ========================================================= */}
      {/* CỘT TRÁI: HERO SHOWCASE (CHUẨN TEMPLATE THIẾT KẾ)         */}
      {/* ========================================================= */}
      <div className="w-full lg:w-[56%] xl:w-[58%] bg-[#F4F8FD] p-6 sm:p-10 lg:p-14 flex flex-col justify-between relative overflow-hidden border-b lg:border-b-0 lg:border-r border-slate-200/80">
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-300/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 right-0 w-[500px] h-[500px] bg-sky-200/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col h-full justify-between gap-6">
          {/* Header Thương Hiệu */}
          <div className="flex items-center gap-3">
            <img
              src="/logo-aplus-transparent.png"
              alt="A+ Enterprise Logo"
              className="w-11 h-11 object-contain drop-shadow-sm select-none"
            />
            <div>
              <div className="text-[19px] font-black tracking-tight text-[#002659] leading-tight font-sans">
                A+ Enterprise CRM
              </div>
              <div className="text-[12px] font-semibold text-[#475467] leading-tight mt-0.5">
                Quản trị thông minh – Tăng trưởng bền vững
              </div>
            </div>
          </div>

          {/* Tiêu Đề Chính & Giới Thiệu */}
          <div className="mt-2 lg:mt-4">
            <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-black tracking-tight text-[#002659] leading-[1.15]">
              Kiến tạo cơ sở dữ liệu<br />
              <span className="text-[#2563EB]">Độc lập &amp; Bảo mật toàn diện</span>
            </h1>
            <p className="mt-3.5 text-[14px] sm:text-[14.5px] text-[#475467] leading-relaxed max-w-xl font-medium">
              Đăng ký doanh nghiệp để được Super Admin duyệt và tự động cấp phát CSDL riêng biệt (Isolated Multi-Tenant Database), phân quyền Admin tối cao và quản trị mọi chi nhánh.
            </p>

            {/* 4 Feature Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 mt-6">
              {[
                { icon: Users, label: 'Quản lý khách hàng' },
                { icon: TrendingUp, label: 'Tối ưu kinh doanh' },
                { icon: Settings2, label: 'Tự động hóa quy trình' },
                { icon: ShieldCheck, label: 'Bảo mật dữ liệu' },
              ].map((feat, idx) => {
                const IconComponent = feat.icon;
                return (
                  <div
                    key={idx}
                    className="bg-white/95 backdrop-blur-xs border border-blue-100/90 rounded-xl p-3 shadow-2xs hover:shadow-xs transition-all flex flex-col items-center text-center gap-2 group hover:-translate-y-0.5"
                  >
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2563EB] flex items-center justify-center transition-colors group-hover:bg-[#2563EB] group-hover:text-white">
                      <IconComponent className="w-4.5 h-4.5" />
                    </div>
                    <span className="text-[12px] font-bold text-[#1E293B] leading-tight">
                      {feat.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 3D Mockup */}
          <div className="relative mt-2 sm:mt-4 flex flex-col items-center">
            <div className="relative w-full max-w-[560px] rounded-2xl overflow-hidden shadow-xl border border-white/60 bg-white/40 backdrop-blur-xs">
              <img
                src="/crm-login-hero.jpg"
                alt="A+ Enterprise CRM Showcase"
                className="w-full h-auto object-cover select-none"
              />
              <div className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 bg-white/95 backdrop-blur-md shadow-lg rounded-full px-4 py-2 border border-blue-100 flex items-center gap-2.5">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <Database className="w-3.5 h-3.5" />
                </div>
                <span className="text-[12.5px] font-bold text-[#002659]">
                  Cơ sở dữ liệu độc lập cho từng công ty
                </span>
              </div>
            </div>

            <div className="mt-4 flex items-center gap-2 text-center text-[#2563EB]">
              <Sparkles className="w-4 h-4 text-blue-500 shrink-0" />
              <span className="text-[15px] sm:text-[16px] font-semibold italic tracking-wide">
                Cùng doanh nghiệp Việt vươn xa hơn
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* CỘT PHẢI: FORM ĐĂNG KÝ DOANH NGHIỆP MỚI                  */}
      {/* ========================================================= */}
      <div className="w-full lg:w-[44%] xl:w-[42%] bg-white p-6 sm:p-10 lg:p-14 flex flex-col justify-between overflow-y-auto">
        <div className="flex items-center justify-end">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-50 border border-slate-200/80 text-[12px] font-bold text-[#2563EB] tracking-wide">
            <span>A+ Enterprise</span>
            <span className="text-slate-300">—</span>
            <span className="text-slate-500 font-medium">Đăng Ký</span>
          </div>
        </div>

        <div className="w-full max-w-[440px] mx-auto my-auto py-4">
          <div className="text-center mb-6">
            <img
              src="/logo-aplus-transparent.png"
              alt="A+ Enterprise Logo"
              className="w-16 h-16 object-contain mx-auto mb-3 drop-shadow-sm select-none"
            />
            <h2 className="text-[25px] sm:text-[27px] font-black tracking-tight text-[#002659] leading-tight">
              Đăng Ký Doanh Nghiệp Mới
            </h2>
            <p className="mt-1 text-[13.5px] text-[#667085] font-medium">
              Khởi tạo không gian làm việc và cấp phát CSDL riêng cho doanh nghiệp
            </p>
          </div>

          {/* Màn hình thành công khi gửi yêu cầu đăng ký */}
          {submittedRequest ? (
            <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-b from-blue-50/80 to-white border border-blue-200/80 shadow-xs space-y-4 animate-in fade-in">
              <div className="w-14 h-14 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-xs">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <div className="text-center">
                <h3 className="text-lg font-black text-[#002659]">
                  Đã Gửi Yêu Cầu Thành Công!
                </h3>
                <p className="text-xs text-[#475467] mt-1 leading-relaxed">
                  Yêu cầu khởi tạo công ty <strong className="text-slate-900">{submittedRequest.companyName}</strong> đã được chuyển tới Cổng Quản Trị Super Admin để duyệt và cấp phát CSDL riêng.
                </p>
              </div>

              {/* Thông tin đăng ký */}
              <div className="p-3.5 rounded-xl bg-white border border-slate-200/90 space-y-2 text-xs">
                <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                  <span className="text-slate-500">Mã công ty đã cấp:</span>
                  <span className="font-mono font-bold text-blue-600 text-sm">{submittedRequest.companyCode}</span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                  <span className="text-slate-500">Tên CSDL dự kiến:</span>
                  <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                    DB_{submittedRequest.companyCode}
                  </span>
                </div>
                <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                  <span className="text-slate-500">Email quản trị (Admin):</span>
                  <span className="font-medium text-slate-800">{submittedRequest.email}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-500">Trạng thái:</span>
                  <span className="font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded">
                    ĐANG CHỜ DUYỆT (PENDING)
                  </span>
                </div>
              </div>

              {/* Action buttons */}
              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPlatformMode(true)}
                  className="w-full h-11 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs sm:text-sm shadow-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Shield className="w-4 h-4" />
                  <span>Vào Cổng Super Admin duyệt ngay →</span>
                </button>
                <button
                  type="button"
                  onClick={() => setAuthScreenMode('LOGIN')}
                  className="w-full h-11 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-semibold text-xs sm:text-sm transition-colors cursor-pointer"
                >
                  Quay lại trang Đăng nhập
                </button>
              </div>
            </div>
          ) : (
            <>
              {errorMessage && (
                <div className="mb-4 p-3 rounded-xl bg-[#FDF2E9] border border-[#E96F22] text-[#E96F22] text-[13px] flex items-center gap-2.5 animate-in fade-in">
                  <AlertTriangle className="w-4 h-4 text-[#E96F22] shrink-0" />
                  <span className="font-medium text-xs sm:text-[13px]">{errorMessage}</span>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-3.5">
                {/* 1. Tên doanh nghiệp */}
                <div>
                  <label className="block text-[12.5px] font-bold text-[#172033] mb-1">
                    Tên doanh nghiệp *
                  </label>
                  <div className="relative">
                    <Building2 className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={companyName}
                      onChange={(e) => handleCompanyNameChange(e.target.value)}
                      placeholder="VD: Công ty Cổ phần Công nghệ Aplus"
                      required
                      className="w-full pl-10 pr-3 h-11 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all"
                    />
                  </div>
                </div>

                {/* 2. Mã công ty (Company Code) */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-[12.5px] font-bold text-[#172033]">
                      Mã công ty (Company Code) *
                    </label>
                    <span className="text-[11px] text-slate-400 font-mono">CSDL: DB_{companyCode || '...'}</span>
                  </div>
                  <div className="relative">
                    <input
                      type="text"
                      value={companyCode}
                      onChange={(e) => {
                        setIsCodeManual(true);
                        setCompanyCode(e.target.value.toUpperCase().trim());
                      }}
                      placeholder="Mã định danh viết hoa (VD: APLUS)"
                      required
                      className="w-full px-3.5 h-11 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14px] uppercase font-mono font-bold focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all"
                    />
                    {companyCode && (
                      <div className="absolute right-3 top-1/2 -translate-y-1/2">
                        {codeValidation.available ? (
                          <span className="text-emerald-600 font-bold text-[11px] flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-md">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Khả dụng
                          </span>
                        ) : (
                          <span className="text-rose-600 font-bold text-[11px] flex items-center gap-1 bg-rose-50 px-2 py-0.5 rounded-md">
                            <AlertTriangle className="w-3.5 h-3.5" /> Đã tồn tại
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>

                {/* 3. MST & SĐT Doanh Nghiệp */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[12px] font-bold text-[#172033] mb-1">
                      Mã số thuế (MST)
                    </label>
                    <div className="relative">
                      <FileText className="w-4 h-4 text-[#98A2B3] absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={taxCode}
                        onChange={(e) => setTaxCode(e.target.value)}
                        placeholder="VD: 0109988776"
                        className="w-full pl-9 pr-2.5 h-10 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[13px] font-mono focus:outline-hidden focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100 transition-all"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[12px] font-bold text-[#172033] mb-1">
                      Hotline doanh nghiệp
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-[#98A2B3] absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="tel"
                        value={companyPhone}
                        onChange={(e) => setCompanyPhone(e.target.value)}
                        placeholder="VD: 024 3888 9999"
                        className="w-full pl-9 pr-2.5 h-10 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[13px] focus:outline-hidden focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100 transition-all"
                      />
                    </div>
                  </div>
                </div>

                {/* 4. Địa chỉ trụ sở */}
                <div>
                  <label className="block text-[12px] font-bold text-[#172033] mb-1">
                    Địa chỉ trụ sở chính
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-[#98A2B3] absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={companyAddress}
                      onChange={(e) => setCompanyAddress(e.target.value)}
                      placeholder="Tòa nhà, Đường, Quận/Huyện, Tỉnh/TP"
                      className="w-full pl-9 pr-3 h-10 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[13px] focus:outline-hidden focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100 transition-all"
                    />
                  </div>
                </div>

                {/* Dải phân cách thông tin Quản trị viên */}
                <div className="pt-2 border-t border-slate-100">
                  <span className="text-[11px] font-bold text-[#475467] uppercase tracking-wider block mb-2.5">
                    Thông tin tài khoản Quản trị viên (Admin)
                  </span>
                </div>

                {/* 5. Họ tên Quản trị viên */}
                <div>
                  <div className="relative">
                    <User className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={adminName}
                      onChange={(e) => setAdminName(e.target.value)}
                      placeholder="Họ và tên Quản trị viên *"
                      required
                      className="w-full pl-10 pr-3 h-11 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all"
                    />
                  </div>
                </div>

                {/* 6. Email người đại diện */}
                <div>
                  <div className="relative">
                    <Mail className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Email đăng nhập quản trị *"
                      required
                      className="w-full pl-10 pr-3 h-11 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all"
                    />
                  </div>
                </div>

                {/* 7. Mật khẩu & Nhập lại */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#98A2B3] absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Mật khẩu *"
                      required
                      className="w-full pl-9 pr-9 h-11 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[13.5px] focus:outline-hidden focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100 transition-all font-mono"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#98A2B3] hover:text-[#172033] p-1 cursor-pointer"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-[#98A2B3] absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="Xác nhận mật khẩu *"
                      required
                      className="w-full pl-9 pr-3 h-11 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[13.5px] focus:outline-hidden focus:border-[#2563EB] focus:ring-2 focus:ring-blue-100 transition-all font-mono"
                    />
                  </div>
                </div>

                {/* Điều khoản dịch vụ */}
                <div className="pt-1">
                  <label className="flex items-start gap-2.5 cursor-pointer text-[12px] text-[#667085]">
                    <input
                      type="checkbox"
                      checked={agreedTerms}
                      onChange={(e) => setAgreedTerms(e.target.checked)}
                      className="rounded border-[#D0D5DD] text-[#2563EB] mt-0.5"
                    />
                    <span>
                      Tôi đồng ý với <strong className="text-[#002659]">Điều khoản dịch vụ</strong> và <strong className="text-[#002659]">Chính sách bảo mật dữ liệu</strong> của A+ Enterprise CRM.
                    </span>
                  </label>
                </div>

                {/* Nút Submit */}
                <button
                  type="submit"
                  disabled={isLoading || !codeValidation.available}
                  className="w-full h-12 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white font-bold text-[15px] shadow-md hover:shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed mt-2 cursor-pointer"
                >
                  {isLoading ? (
                    <span>Đang gửi thông tin đăng ký...</span>
                  ) : (
                    <>
                      <span>Đăng ký doanh nghiệp</span>
                      <ArrowRight className="w-4.5 h-4.5" />
                    </>
                  )}
                </button>
              </form>
            </>
          )}

          {/* Navigation Links Tách Biệt */}
          <div className="mt-6 pt-4 border-t border-slate-100 space-y-2 text-center text-[13px] text-[#667085]">
            <div>
              Đã có tài khoản?{' '}
              <button
                type="button"
                onClick={() => setAuthScreenMode('LOGIN')}
                className="font-bold text-[#2563EB] hover:underline cursor-pointer"
              >
                Đăng nhập ngay
              </button>
            </div>
            <div>
              <button
                type="button"
                onClick={() => setAuthScreenMode('JOIN_COMPANY')}
                className="font-semibold text-slate-700 hover:text-blue-600 cursor-pointer"
              >
                Muốn xin tham gia công ty có sẵn?
              </button>
              <span className="mx-2 text-slate-300">•</span>
              <button
                type="button"
                onClick={() => setAuthScreenMode('ACCEPT_INVITE')}
                className="text-slate-600 hover:text-blue-600 font-semibold cursor-pointer"
              >
                Có mã lời mời?
              </button>
            </div>
          </div>
        </div>

        {/* Footer Bản Quyền */}
        <div className="text-center text-[12px] text-slate-400 mt-4">
          © 2026 A+ Enterprise. All rights reserved.
        </div>
      </div>
    </div>
  );
};
