import React, { useState } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import {
  Lock,
  User,
  Eye,
  EyeOff,
  ArrowRight,
  ShieldAlert,
  AlertTriangle,
  Shield,
  Users,
  TrendingUp,
  Settings2,
  ShieldCheck,
  HelpCircle,
  Sparkles,
} from 'lucide-react';

export const LoginView: React.FC = () => {
  const {
    login,
    loginError,
    isLockedOut,
    lockoutRemainingSeconds,
    rememberCompanyCode,
    resetLockout,
    setAuthScreenMode,
    setIsPlatformMode,
  } = useMultiTenant();

  const [companyCode, setCompanyCode] = useState(rememberCompanyCode || 'APLUS');
  const [emailOrUser, setEmailOrUser] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [remember, setRemember] = useState(true);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrUser) return;
    setIsLoading(true);
    try {
      const targetCode = companyCode ? companyCode.toUpperCase().trim() : 'APLUS';
      await login(targetCode, emailOrUser, password, remember);
    } catch (err: any) {
      console.error('[LoginView Submit Error]:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickLogin = async (loginId: string) => {
    setCompanyCode('APLUS');
    setEmailOrUser(loginId);
    setPassword('password123');
    setIsLoading(true);
    try {
      await login('APLUS', loginId, 'password123', true);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-white text-[#172033] flex flex-col lg:flex-row">
      {/* ========================================================= */}
      {/* CỘT TRÁI: HERO SHOWCASE (THEO THIẾT KẾ THAM KHẢO)          */}
      {/* ========================================================= */}
      <div className="w-full lg:w-[56%] xl:w-[58%] bg-[#F4F8FD] p-6 sm:p-10 lg:p-14 flex flex-col justify-between relative overflow-hidden border-b lg:border-b-0 lg:border-r border-slate-200/80">
        {/* Ambient background glow */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-300/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-10 right-0 w-[500px] h-[500px] bg-sky-200/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col h-full justify-between gap-6">
          {/* 1. Header Thương Hiệu Góc Trái */}
          <div className="flex items-center gap-3">
            <img
              src="/logo-aplus-transparent.png"
              alt="A+ Enterprise Logo"
              className="w-11 h-11 object-contain drop-shadow-sm select-none"
            />
            <div>
              <div className="text-[19px] font-black tracking-tight text-[#002659] leading-tight font-sans">
                A+ Enterprise CRM
              </div>
              <div className="text-[12px] font-semibold text-[#475467] leading-tight mt-0.5">
                Quản trị thông minh – Tăng trưởng bền vững
              </div>
            </div>
          </div>

          {/* 2. Tiêu Đề Chính & Giới Thiệu */}
          <div className="mt-2 lg:mt-4">
            <h1 className="text-3xl sm:text-4xl lg:text-[42px] font-black tracking-tight text-[#002659] leading-[1.15]">
              Kết nối khách hàng<br />
              <span className="text-[#2563EB]">Kiến tạo tăng trưởng</span>
            </h1>
            <p className="mt-3.5 text-[14px] sm:text-[14.5px] text-[#475467] leading-relaxed max-w-xl font-medium">
              A+ Enterprise CRM – Nền tảng quản trị khách hàng toàn diện, giúp doanh nghiệp tối ưu vận hành, chăm sóc khách hàng và bứt phá doanh thu.
            </p>

            {/* 3. 4 Huy Hiệu Tính Năng (Feature Pills) */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3 mt-6">
              {[
                { icon: Users, label: 'Quản lý khách hàng' },
                { icon: TrendingUp, label: 'Tối ưu kinh doanh' },
                { icon: Settings2, label: 'Tự động hóa quy trình' },
                { icon: ShieldCheck, label: 'Bảo mật dữ liệu' },
              ].map((feat, idx) => {
                const IconComponent = feat.icon;
                return (
                  <div
                    key={idx}
                    className="bg-white/95 backdrop-blur-xs border border-blue-100/90 rounded-xl p-3 shadow-2xs hover:shadow-xs transition-all flex flex-col items-center text-center gap-2 group hover:-translate-y-0.5"
                  >
                    <div className="w-8 h-8 rounded-lg bg-blue-50 text-[#2563EB] flex items-center justify-center transition-colors group-hover:bg-[#2563EB] group-hover:text-white">
                      <IconComponent className="w-4.5 h-4.5" />
                    </div>
                    <span className="text-[12px] font-bold text-[#1E293B] leading-tight">
                      {feat.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 4. Hình Ảnh Mockup Laptop 3D Thiết Kế Mới Với Logo A+ */}
          <div className="relative mt-2 sm:mt-4 flex flex-col items-center">
            <div className="relative w-full max-w-[560px] rounded-2xl overflow-hidden shadow-xl border border-white/60 bg-white/40 backdrop-blur-xs">
              <img
                src="/crm-login-hero.jpg"
                alt="A+ Enterprise CRM 3D Dashboard Showcase"
                className="w-full h-auto object-cover select-none"
              />

              {/* Floating Pill: Khách hàng là trung tâm */}
              <div className="absolute bottom-4 left-4 sm:bottom-6 sm:left-6 bg-white/95 backdrop-blur-md shadow-lg rounded-full px-4 py-2 border border-blue-100 flex items-center gap-2.5 animate-bounce-slow">
                <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs">
                  <Users className="w-3.5 h-3.5" />
                </div>
                <span className="text-[12.5px] font-bold text-[#002659]">
                  Khách hàng là trung tâm
                </span>
              </div>
            </div>

            {/* Slogan Thư Pháp / Italic Dưới Hình Ảnh */}
            <div className="mt-4 flex items-center gap-2 text-center text-[#2563EB]">
              <Sparkles className="w-4 h-4 text-blue-500 shrink-0" />
              <span className="text-[15px] sm:text-[16px] font-semibold italic tracking-wide">
                Cùng doanh nghiệp Việt vươn xa hơn
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* CỘT PHẢI: FORM ĐĂNG NHẬP (CHUẨN FORM DESIGN THAM KHẢO)     */}
      {/* ========================================================= */}
      <div className="w-full lg:w-[44%] xl:w-[42%] bg-white p-6 sm:p-10 lg:p-14 flex flex-col justify-between">
        {/* Top Header Phải: A+ Enterprise — CRM */}
        <div className="flex items-center justify-end">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-50 border border-slate-200/80 text-[12px] font-bold text-[#2563EB] tracking-wide">
            <span>A+ Enterprise</span>
            <span className="text-slate-300">—</span>
            <span className="text-slate-500 font-medium">CRM</span>
          </div>
        </div>

        {/* Khung Form Chính Giữa */}
        <div className="w-full max-w-[420px] mx-auto my-auto py-4">
          {/* Logo A+ Trung Tâm Cột Phải */}
          <div className="text-center mb-6">
            <img
              src="/logo-aplus-transparent.png"
              alt="A+ Enterprise Logo"
              className="w-16 h-16 object-contain mx-auto mb-3 drop-shadow-sm select-none"
            />
            <h2 className="text-[25px] sm:text-[27px] font-black tracking-tight text-[#002659] leading-tight">
              A+ Enterprise CRM
            </h2>
            <p className="mt-1 text-[13.5px] text-[#667085] font-medium">
              Đăng nhập để tiếp tục sử dụng hệ thống
            </p>
          </div>

          {/* Cảnh báo tạm khóa tài khoản */}
          {isLockedOut && (
            <div className="mb-4 p-3.5 rounded-xl bg-[#FDF2E9] border border-[#E96F22] text-[#E96F22] text-[13px] flex items-start justify-between gap-3 animate-in fade-in">
              <div className="flex items-start gap-2.5">
                <ShieldAlert className="w-5 h-5 text-[#E96F22] shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block text-sm">Tài khoản tạm thời bị khóa!</span>
                  <span className="text-xs">
                    Tự động mở lại sau {lockoutRemainingSeconds}s.
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={resetLockout}
                className="px-3 py-1.5 text-xs font-bold rounded-lg bg-[#E96F22] text-white hover:bg-[#d35f17] shrink-0 transition-colors cursor-pointer shadow-xs"
              >
                Mở khóa ngay
              </button>
            </div>
          )}

          {/* Cảnh báo lỗi thông thường */}
          {loginError && !isLockedOut && (
            <div className="mb-4 p-3 rounded-xl bg-[#FDF2E9] border border-[#E96F22] text-[#E96F22] text-[13px] flex items-center gap-2.5 animate-in fade-in">
              <AlertTriangle className="w-4 h-4 text-[#E96F22] shrink-0" />
              <span className="font-medium text-xs sm:text-[13px]">{loginError}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {/* Input 1: Tài khoản / Mã nhân viên */}
            <div>
              <div className="relative">
                <User className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={emailOrUser}
                  onChange={(e) => setEmailOrUser(e.target.value)}
                  placeholder="Mã nhân viên hoặc Email"
                  required
                  disabled={isLockedOut}
                  className="w-full pl-10 pr-3 h-12 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14.5px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all"
                />
              </div>
            </div>

            {/* Input 2: Mật khẩu */}
            <div>
              <div className="relative">
                <Lock className="w-4.5 h-4.5 text-[#98A2B3] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mật khẩu"
                  required
                  disabled={isLockedOut}
                  className="w-full pl-10 pr-10 h-12 rounded-xl border border-[#D0D5DD] bg-white text-[#172033] placeholder-[#98A2B3] text-[14.5px] focus:outline-hidden focus:border-[#2563EB] focus:ring-4 focus:ring-blue-100 transition-all font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#98A2B3] hover:text-[#172033] p-1 cursor-pointer transition-colors"
                  aria-label="Hiện mật khẩu"
                >
                  {showPassword ? <EyeOff className="w-4.5 h-4.5" /> : <Eye className="w-4.5 h-4.5" />}
                </button>
              </div>
            </div>

            {/* Nút Đăng Nhập Chính (Màu Xanh Royal Chuẩn Design) */}
            <button
              type="submit"
              disabled={isLoading || isLockedOut}
              className="w-full h-12 rounded-xl bg-[#2563EB] hover:bg-[#1D4ED8] active:bg-[#1E40AF] text-white font-bold text-[15px] shadow-md hover:shadow-lg shadow-blue-500/20 flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed mt-2 cursor-pointer"
            >
              {isLoading ? (
                <span>Đang kết nối CSDL và xác thực...</span>
              ) : (
                <>
                  <span>Đăng nhập</span>
                  <ArrowRight className="w-4.5 h-4.5" />
                </>
              )}
            </button>
          </form>

          {/* Dải Phân Cách: Hoặc */}
          <div className="relative my-5">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[#E5EAF1]" />
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="bg-white px-3 text-[#98A2B3] font-semibold">
                Hoặc
              </span>
            </div>
          </div>

          {/* Nút Đăng nhập bằng Google */}
          <button
            type="button"
            onClick={() => handleQuickLogin('huy.nk@apluscorp.vn')}
            className="w-full h-12 rounded-xl border border-[#D0D5DD] hover:border-slate-400 bg-white hover:bg-slate-50/80 text-[#344054] font-semibold text-[14px] flex items-center justify-center gap-3 transition-colors cursor-pointer shadow-2xs"
          >
            {/* Google 4-Color Icon */}
            <svg className="w-4.5 h-4.5 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
              />
              <path
                fill="#34A853"
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
              />
              <path
                fill="#FBBC05"
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
              />
              <path
                fill="#EA4335"
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
              />
            </svg>
            <span>Đăng nhập bằng Google</span>
          </button>

          {/* Quên Mật Khẩu Link */}
          <div className="mt-4 text-center">
            <button
              type="button"
              onClick={() => setAuthScreenMode('FORGOT_PASSWORD')}
              className="inline-flex items-center gap-1.5 text-[13px] font-medium text-[#475467] hover:text-[#2563EB] transition-colors cursor-pointer"
            >
              <HelpCircle className="w-3.5 h-3.5 text-[#98A2B3]" />
              <span>Bạn quên mật khẩu?</span>
            </button>
          </div>

          {/* Khung Chọn Nhanh 5 Tài Khoản Thử Nghiệm */}
          <div className="mt-6 pt-4 border-t border-slate-100">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-[#64748B] uppercase tracking-wider">
                Chọn nhanh 5 vai trò thử nghiệm:
              </span>
              <span className="text-[10.5px] font-mono text-slate-400">Pass: password123</span>
            </div>
            <div className="grid grid-cols-2 gap-1.5">
              {[
                { name: 'Nguyễn Khắc Huy', role: 'Super Admin', login: 'huy.nk@apluscorp.vn' },
                { name: 'Hồ Minh Châu', role: 'Ban Giám Đốc', login: 'chau.hm@apluscorp.vn' },
                { name: 'Nguyễn Nhật Thanh', role: 'Admin', login: 'thanh.nn@apluscorp.vn' },
                { name: 'Hồ Hoàng Long', role: 'TP. Sale', login: 'long.hh@apluscorp.vn' },
              ].map((acc) => (
                <button
                  key={acc.login}
                  type="button"
                  onClick={() => handleQuickLogin(acc.login)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200/90 hover:border-blue-500 bg-slate-50/60 hover:bg-blue-50/50 text-left transition-all cursor-pointer group"
                >
                  <div className="text-[12px] font-bold text-slate-800 group-hover:text-blue-700 truncate">
                    {acc.name}
                  </div>
                  <div className="text-[10px] text-slate-500 font-semibold truncate">
                    {acc.role}
                  </div>
                </button>
              ))}
              {/* Nút tài khoản thứ 5 full width */}
              <button
                type="button"
                onClick={() => handleQuickLogin('vana.sales@apluscorp.vn')}
                className="col-span-2 px-2.5 py-1.5 rounded-lg border border-slate-200/90 hover:border-blue-500 bg-slate-50/60 hover:bg-blue-50/50 text-left transition-all cursor-pointer group flex items-center justify-between"
              >
                <div>
                  <span className="text-[12px] font-bold text-slate-800 group-hover:text-blue-700">
                    Nguyễn Văn A
                  </span>
                  <span className="text-[11px] text-slate-500 ml-2 font-semibold">
                    (Nhân Viên Sale)
                  </span>
                </div>
                <span className="text-[10.5px] text-blue-600 font-bold group-hover:translate-x-0.5 transition-transform">
                  Vào ngay →
                </span>
              </button>
            </div>
          </div>

          {/* Điều hướng các luồng đăng ký, tham gia, lời mời & Super Admin */}
          <div className="mt-4 pt-3 border-t border-slate-100 space-y-2 text-[12px] text-[#667085]">
            <div className="flex items-center justify-between">
              <button
                type="button"
                onClick={() => setAuthScreenMode('REGISTER')}
                className="font-bold text-[#2563EB] hover:underline cursor-pointer"
              >
                Đăng ký doanh nghiệp mới
              </button>
              <button
                type="button"
                onClick={() => setIsPlatformMode(true)}
                className="inline-flex items-center gap-1 text-slate-500 hover:text-purple-700 font-semibold cursor-pointer"
              >
                <Shield className="w-3 h-3 text-purple-600" />
                <span>Cổng Super Admin</span>
              </button>
            </div>
            <div className="flex items-center justify-between pt-1 border-t border-slate-50 text-[11.5px]">
              <button
                type="button"
                onClick={() => setAuthScreenMode('JOIN_COMPANY')}
                className="text-slate-600 hover:text-blue-600 font-medium cursor-pointer"
              >
                Xin tham gia công ty có sẵn
              </button>
              <button
                type="button"
                onClick={() => setAuthScreenMode('ACCEPT_INVITE')}
                className="text-slate-600 hover:text-blue-600 font-medium cursor-pointer"
              >
                Kích hoạt mã thư mời
              </button>
            </div>
          </div>
        </div>

        {/* Footer Bản Quyền */}
        <div className="text-center text-[12px] text-slate-400 mt-4">
          © 2026 A+ Enterprise. All rights reserved.
        </div>
      </div>
    </div>
  );
};
