import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { SPEC_SECTIONS, SCREEN_DETAILED_SPECS, SpecSection } from '../data/specificationData';
import {
  BookOpen,
  Search,
  Download,
  Copy,
  Check,
  FileCode,
  Layers,
  ShieldCheck,
  Layout,
  Terminal,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';

export const SpecSuiteView: React.FC = () => {
  const { language, themeDef, openScreenSpec, t } = useCRM();
  const isVi = language === 'vi';

  const [activeTab, setActiveTab] = useState<'24-chapters' | 'screens-detail'>('24-chapters');
  const [selectedSectionId, setSelectedSectionId] = useState<string>('sitemap');
  const [selectedScreenCode, setSelectedScreenCode] = useState<string>('SCR-DASHBOARD');
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredSections = SPEC_SECTIONS.filter((sec) => {
    const matchesSearch =
      sec.titleVi.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sec.titleEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sec.summaryVi.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = categoryFilter === 'all' || sec.category === categoryFilter;
    return matchesSearch && matchesCat;
  });

  const activeSection = SPEC_SECTIONS.find((s) => s.id === selectedSectionId) || SPEC_SECTIONS[0];
  const activeScreenSpec = SCREEN_DETAILED_SPECS.find((s) => s.code === selectedScreenCode) || SCREEN_DETAILED_SPECS[0];

  const handleCopyMarkdown = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExportFullSpecMarkdown = () => {
    let fullDoc = `# TÀI LIỆU ĐẶC TẢ HỆ THỐNG A+ ENTERPRISE CRM SUITE (24 CHƯƠNG CHUẨN HÓA)\n`;
    fullDoc += `*Phiên bản: 3.4.2 Enterprise | Bản quyền: Tập đoàn Công nghệ số A+ | Kiến trúc Multi-Tenant Database Cô lập (Database-per-Tenant)*\n\n`;

    SPEC_SECTIONS.forEach((sec) => {
      fullDoc += `## ${sec.number}. ${isVi ? sec.titleVi : sec.titleEn}\n\n`;
      fullDoc += `${isVi ? sec.summaryVi : sec.summaryEn}\n\n`;
      fullDoc += `${isVi ? sec.contentMarkdownVi : sec.contentMarkdownEn}\n\n`;
      fullDoc += `---\n\n`;
    });

    fullDoc += `# ĐẶC TẢ CHI TIẾT TỪNG MÀN HÌNH (SCREENS A - L)\n\n`;
    SCREEN_DETAILED_SPECS.forEach((scr) => {
      fullDoc += `### ${scr.code} - ${isVi ? scr.nameVi : scr.nameEn}\n`;
      fullDoc += `**Mục đích:** ${isVi ? scr.purposeVi : scr.purposeEn}\n`;
      fullDoc += `**Bố cục UI:** ${isVi ? scr.uiLayoutVi : scr.uiLayoutEn}\n\n`;
      fullDoc += `**API Endpoints:**\n`;
      scr.apiIntegration.forEach((api) => {
        fullDoc += `- [${api.method}] \`${api.endpoint}\`: ${isVi ? api.descriptionVi : api.descriptionEn}\n`;
      });
      fullDoc += `\n---\n\n`;
    });

    const blob = new Blob([fullDoc], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `A_PLUS_Enterprise_CRM_Specifications_24_Chapters.md`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Top Banner Header */}
      <div className={`p-6 rounded-3xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow} flex flex-col md:flex-row md:items-center justify-between gap-4 border-l-4 border-l-blue-600`}>
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-blue-600/10 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400">
              <BookOpen className="w-5 h-5" />
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
              {isVi ? 'Hồ sơ Đặc tả Kỹ thuật Hệ thống (24 Chương)' : 'Enterprise Specification Explorer (24 Specs)'}
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-2xl leading-relaxed">
            {isVi
              ? 'Tài liệu kiến trúc toàn diện: Sơ đồ sitemap, luồng người dùng, ma trận phân quyền 6 vai trò, quy chuẩn UI Component và chi tiết đặc tả các màn hình A - J.'
              : 'Complete architectural specification: sitemap, journeys, 6-role RBAC matrix, and detailed per-screen specs A through J.'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleExportFullSpecMarkdown}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs shadow-md shadow-blue-500/20 transition-all hover:scale-102"
          >
            <Download className="w-4 h-4" />
            <span>{isVi ? 'Tải Toàn bộ Hồ sơ (.MD)' : 'Download Full Spec (.MD)'}</span>
          </button>
        </div>
      </div>

      {/* Main Tabs: 24 Chapters vs Screen Details (A - J) */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('24-chapters')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === '24-chapters'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>{isVi ? '24 Chương Đặc tả Toàn diện' : '24 Specification Chapters'}</span>
        </button>
        <button
          onClick={() => setActiveTab('screens-detail')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${
            activeTab === 'screens-detail'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <FileCode className="w-4 h-4" />
          <span>{isVi ? 'Đặc tả Màn hình Chi tiết (A - J)' : 'Screen Deep Specs (A - J)'}</span>
        </button>
      </div>

      {/* Tab 1: 24 Chapters Explorer */}
      {activeTab === '24-chapters' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Navigation: Chapter List (4 cols) */}
          <div className="lg:col-span-4 space-y-3">
            {/* Search within chapters */}
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={isVi ? 'Tìm kiếm trong 24 chương...' : 'Search 24 chapters...'}
                className="w-full pl-9 pr-3 py-2 rounded-xl text-xs border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900"
              />
            </div>

            {/* Category Filter Pills */}
            <div className="flex flex-wrap gap-1">
              {[
                { id: 'all', label: 'Tất cả' },
                { id: 'architecture', label: 'Kiến trúc' },
                { id: 'ux-flow', label: 'Luồng UX' },
                { id: 'security', label: 'Bảo mật/RBAC' },
                { id: 'components', label: 'Giao diện' },
                { id: 'system', label: 'Hệ thống' },
              ].map((c) => (
                <button
                  key={c.id}
                  onClick={() => setCategoryFilter(c.id)}
                  className={`px-2.5 py-1 rounded-lg text-[10px] font-semibold border ${
                    categoryFilter === c.id
                      ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 border-transparent'
                      : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>

            {/* Chapter Items List */}
            <div className={`rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} p-2 max-h-[620px] overflow-y-auto space-y-1 divide-y divide-slate-100 dark:divide-slate-800/60`}>
              {filteredSections.map((sec) => {
                const isSelected = selectedSectionId === sec.id;
                return (
                  <button
                    key={sec.id}
                    onClick={() => setSelectedSectionId(sec.id)}
                    className={`w-full text-left p-3 rounded-xl transition-all flex items-start justify-between gap-2 ${
                      isSelected
                        ? 'bg-blue-50/80 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <div>
                      <div className={`text-xs font-bold ${isSelected ? 'text-blue-600 dark:text-blue-400' : 'text-slate-800 dark:text-slate-200'}`}>
                        {isVi ? sec.titleVi : sec.titleEn}
                      </div>
                      <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {isVi ? sec.summaryVi : sec.summaryEn}
                      </div>
                    </div>
                    <ChevronRight className={`w-4 h-4 shrink-0 mt-0.5 ${isSelected ? 'text-blue-600' : 'text-slate-300'}`} />
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right Reader: Active Chapter Content (8 cols) */}
          <div className="lg:col-span-8">
            <div className={`p-6 sm:p-8 rounded-3xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow} space-y-6 min-h-[620px]`}>
              {/* Reader Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300 font-bold">
                      Chương {activeSection.number} / 24
                    </span>
                    <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      {activeSection.category}
                    </span>
                  </div>
                  <h2 className="text-lg sm:text-xl font-black text-slate-900 dark:text-slate-100 mt-1">
                    {isVi ? activeSection.titleVi : activeSection.titleEn}
                  </h2>
                </div>

                <button
                  onClick={() =>
                    handleCopyMarkdown(
                      isVi ? activeSection.contentMarkdownVi : activeSection.contentMarkdownEn,
                      activeSection.id
                    )
                  }
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 transition-colors w-max"
                >
                  {copiedId === activeSection.id ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                      <span className="text-emerald-600">Đã sao chép!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Markdown</span>
                    </>
                  )}
                </button>
              </div>

              {/* Summary Lead */}
              <div className="p-4 rounded-2xl bg-blue-50/50 dark:bg-blue-950/20 border border-blue-200/60 dark:border-blue-900/40 text-xs font-medium text-slate-700 dark:text-slate-300 leading-relaxed">
                📌 <strong>Tóm tắt cốt lõi:</strong> {isVi ? activeSection.summaryVi : activeSection.summaryEn}
              </div>

              {/* Markdown Content Box */}
              <div className="prose prose-sm dark:prose-invert max-w-none text-xs leading-relaxed text-slate-800 dark:text-slate-200 space-y-4">
                <div className="p-5 rounded-2xl bg-slate-950 text-slate-100 font-mono text-[11px] overflow-x-auto whitespace-pre-wrap border border-slate-800">
                  {isVi ? activeSection.contentMarkdownVi : activeSection.contentMarkdownEn}
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* Tab 2: Detailed Screen Specifications (A - J) */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Screen Picker Tabs (4 cols) */}
          <div className="lg:col-span-4 space-y-2">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2">
              Danh mục 10 Phân hệ (Screens A - J)
            </div>
            {SCREEN_DETAILED_SPECS.map((scr) => {
              const isSelected = selectedScreenCode === scr.code;
              return (
                <button
                  key={scr.code}
                  onClick={() => setSelectedScreenCode(scr.code)}
                  className={`w-full text-left p-3.5 rounded-2xl border transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-blue-600 text-white border-blue-600 shadow-md scale-101'
                      : `${themeDef.classes.cardBg} border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 hover:border-blue-400`
                  }`}
                >
                  <div>
                    <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded font-bold ${
                      isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400'
                    }`}>
                      {scr.code}
                    </span>
                    <div className="font-bold text-xs mt-1">
                      {isVi ? scr.nameVi : scr.nameEn}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 opacity-70 shrink-0" />
                </button>
              );
            })}
          </div>

          {/* Screen Deep Spec Sheet (8 cols) */}
          <div className="lg:col-span-8">
            <div className={`p-6 sm:p-8 rounded-3xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow} space-y-6`}>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 gap-3">
                <div>
                  <span className="font-mono text-xs px-2.5 py-0.5 rounded bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 font-bold">
                    {activeScreenSpec.code}
                  </span>
                  <h2 className="text-xl font-black text-slate-900 dark:text-slate-100 mt-1">
                    {isVi ? activeScreenSpec.nameVi : activeScreenSpec.nameEn}
                  </h2>
                </div>

                <button
                  onClick={() => openScreenSpec(activeScreenSpec.code)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-xs"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Mở Drawer Xem Đặc tả</span>
                </button>
              </div>

              {/* Purpose & Layout */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                  <span className="font-bold text-slate-400 uppercase text-[10px] block mb-1">Mục đích màn hình</span>
                  <p className="text-slate-800 dark:text-slate-200 leading-relaxed">
                    {isVi ? activeScreenSpec.purposeVi : activeScreenSpec.purposeEn}
                  </p>
                </div>
                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                  <span className="font-bold text-slate-400 uppercase text-[10px] block mb-1">Bố cục giao diện UI</span>
                  <p className="text-slate-800 dark:text-slate-200 leading-relaxed">
                    {isVi ? activeScreenSpec.uiLayoutVi : activeScreenSpec.uiLayoutEn}
                  </p>
                </div>
              </div>

              {/* User Actions */}
              <div>
                <h4 className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-2">
                  Tác vụ Người dùng (User Actions)
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  {(isVi ? activeScreenSpec.userActionsVi : activeScreenSpec.userActionsEn).map((act, i) => (
                    <div key={i} className="flex items-start gap-2 p-2 rounded-lg bg-slate-50 dark:bg-slate-800/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                      <span>{act}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* API Endpoints */}
              <div>
                <h4 className="text-xs font-bold text-emerald-600 uppercase tracking-wider mb-2">
                  Tích hợp API RESTful Endpoints
                </h4>
                <div className="space-y-2">
                  {activeScreenSpec.apiIntegration.map((api, i) => (
                    <div key={i} className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-[11px] px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300">
                          {api.method}
                        </span>
                        <span className="font-mono font-bold text-slate-900 dark:text-slate-100">
                          {api.endpoint}
                        </span>
                      </div>
                      <span className="text-slate-500 text-[11px]">
                        {isVi ? api.descriptionVi : api.descriptionEn}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
