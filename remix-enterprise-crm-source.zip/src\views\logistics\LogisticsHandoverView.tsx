import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import { HandoverRecord, HandoverItemCheck } from '../../types/logistics';
import { APlusLogo } from '../../components/common/APlusLogo';
import {
  FileCheck2,
  Plus,
  Search,
  CheckCircle2,
  AlertTriangle,
  Printer,
  X,
  Truck,
  RotateCcw,
  Check,
  Calendar,
  Layers,
} from 'lucide-react';

export const LogisticsHandoverView: React.FC = () => {
  const { showToast } = useCRM();
  const { handovers, createHandoverRecord, confirmHandoverRecord, createStockInForReturnedGoods, shipments } = useLogistics();

  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [selectedRecord, setSelectedRecord] = useState<HandoverRecord | null>(null);
  const [printRecord, setPrintRecord] = useState<HandoverRecord | null>(null);

  // Modal Create Handover
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formType, setFormType] = useState<HandoverRecord['type']>('Bàn giao xuất phát');
  const [selectedShipmentId, setSelectedShipmentId] = useState(shipments[0]?.id || '');
  const [formDeliverer, setFormDeliverer] = useState('Nguyễn Tiến Dũng (Thủ kho Tổng)');
  const [formReceiver, setFormReceiver] = useState('Nguyễn Văn Mạnh (Tài xế)');
  const [formNotes, setFormNotes] = useState('');

  // End of trip details
  const [codExpected, setCodExpected] = useState<number>(45000000);
  const [codActual, setCodActual] = useState<number>(45000000);
  const [discrepancyNote, setDiscrepancyNote] = useState('');

  const filteredRecords = handovers.filter((h) => {
    if (typeFilter !== 'all' && h.type !== typeFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        h.code.toLowerCase().includes(q) ||
        h.shipmentCode.toLowerCase().includes(q) ||
        h.delivererName.toLowerCase().includes(q) ||
        h.receiverName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const sh = shipments.find((s) => s.id === selectedShipmentId);
    if (!sh) return;

    const itemsCheck: HandoverItemCheck[] = [
      {
        sku: 'MED-KIT-01',
        productName: 'Tủ Thuốc Cứu Thương Tiêu Chuẩn Doanh Nghiệp',
        quantityExpected: 15,
        quantityActual: 15,
      },
      {
        sku: 'MED-MASK-N95',
        productName: 'Khẩu trang Y tế Chuyên dụng N95',
        quantityExpected: 25,
        quantityActual: 25,
      },
    ];

    const hasDiscrepancy = formType === 'Bàn giao cuối chuyến' && codExpected !== codActual;

    createHandoverRecord({
      type: formType,
      shipmentId: sh.id,
      shipmentCode: sh.code,
      delivererName: formDeliverer,
      receiverName: formReceiver,
      confirmedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: hasDiscrepancy ? 'Có chênh lệch' : 'Đã xác nhận',
      itemsCheck,
      cashCheck:
        formType === 'Bàn giao cuối chuyến'
          ? {
              codExpected,
              codActual,
              discrepancyNote,
            }
          : undefined,
      notes: formNotes,
    });

    setIsCreateModalOpen(false);
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
              <FileCheck2 className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Biên Bản Bàn Giao (Handover)
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Biên bản bàn giao xuất phát (Kho ➔ Tài xế) và bàn giao cuối chuyến (Tài xế ➔ Kho/Kế toán, đối soát COD và hàng hoàn).
          </p>
        </div>

        <button
          onClick={() => setIsCreateModalOpen(true)}
          className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
        >
          <Plus className="w-4 h-4" />
          <span>Lập Biên Bản Mới</span>
        </button>
      </div>

      {/* Filter & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo mã biên bản (BBG-2026-xxxx), chuyến, người giao..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800"
          />
        </div>

        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="text-xs px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
        >
          <option value="all">Tất cả loại biên bản</option>
          <option value="Bàn giao xuất phát">Bàn giao xuất phát (Kho ➔ Xe)</option>
          <option value="Bàn giao cuối chuyến">Bàn giao cuối chuyến (Xe ➔ Kho/Quỹ)</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] text-slate-500 uppercase font-semibold">
            <tr>
              <th className="p-3">Số biên bản &amp; Thời gian</th>
              <th className="p-3">Loại biên bản</th>
              <th className="p-3">Chuyến hàng</th>
              <th className="p-3">Bên giao</th>
              <th className="p-3">Bên nhận</th>
              <th className="p-3 text-center">Trạng thái</th>
              <th className="p-3 text-center">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredRecords.length === 0 ? (
              <tr>
                <td colSpan={7} className="py-10 text-center text-slate-400">
                  Không có biên bản bàn giao nào.
                </td>
              </tr>
            ) : (
              filteredRecords.map((bbg) => (
                <tr key={bbg.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                  <td className="p-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {bbg.code}
                    <div className="text-[10px] text-slate-400 font-sans font-normal">{bbg.confirmedAt}</div>
                  </td>
                  <td className="p-3 font-semibold">
                    <span
                      className={`px-2 py-0.5 rounded text-[10.5px] ${
                        bbg.type === 'Bàn giao xuất phát'
                          ? 'bg-sky-50 text-sky-700 dark:bg-sky-950 dark:text-sky-300'
                          : 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300'
                      }`}
                    >
                      {bbg.type}
                    </span>
                  </td>
                  <td className="p-3 font-mono text-sky-600 font-bold">{bbg.shipmentCode}</td>
                  <td className="p-3">{bbg.delivererName}</td>
                  <td className="p-3 font-medium">{bbg.receiverName}</td>
                  <td className="p-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        bbg.status === 'Đã xác nhận'
                          ? 'bg-emerald-100 text-emerald-800'
                          : bbg.status === 'Có chênh lệch'
                          ? 'bg-rose-100 text-rose-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {bbg.status}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => setSelectedRecord(bbg)}
                        className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 font-semibold text-slate-700 dark:text-slate-300"
                      >
                        Chi tiết
                      </button>
                      <button
                        onClick={() => setPrintRecord(bbg)}
                        className="p-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-600"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Drawer Chi tiết Biên bản */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end animate-fade-in">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col border-l">
            <div className="p-4 sm:p-5 border-b flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
              <div>
                <span className="font-mono text-base font-bold text-emerald-600">{selectedRecord.code}</span>
                <span className="ml-2 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200">
                  {selectedRecord.type}
                </span>
                <p className="text-xs text-slate-500 mt-0.5">Xác nhận lúc: {selectedRecord.confirmedAt}</p>
              </div>
              <button onClick={() => setSelectedRecord(null)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Chuyến hàng liên quan:</span>
                  <span className="font-mono font-bold text-sky-600">{selectedRecord.shipmentCode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Bên bàn giao:</span>
                  <span className="font-semibold">{selectedRecord.delivererName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Bên nhận bàn giao:</span>
                  <span className="font-semibold">{selectedRecord.receiverName}</span>
                </div>
              </div>

              {/* Items Table */}
              <div>
                <h4 className="font-bold text-slate-700 dark:text-slate-300 uppercase mb-2">
                  Đối chiếu danh mục hàng hóa
                </h4>
                <table className="w-full border rounded-xl overflow-hidden text-left">
                  <thead className="bg-slate-100 dark:bg-slate-800 text-[11px]">
                    <tr>
                      <th className="p-2">Sản phẩm</th>
                      <th className="p-2 text-center">Dự kiến</th>
                      <th className="p-2 text-center">Thực nhận</th>
                      <th className="p-2 text-center">Chênh lệch</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {selectedRecord.itemsCheck.map((it, i) => (
                      <tr key={i}>
                        <td className="p-2">
                          <div className="font-semibold">{it.productName}</div>
                          <div className="text-[10px] font-mono text-slate-400">{it.sku}</div>
                        </td>
                        <td className="p-2 text-center">{it.quantityExpected}</td>
                        <td className="p-2 text-center font-bold text-emerald-600">{it.quantityActual}</td>
                        <td className="p-2 text-center">
                          {it.quantityActual === it.quantityExpected ? (
                            <span className="text-slate-400 font-mono">0</span>
                          ) : (
                            <span className="text-rose-600 font-bold">
                              {it.quantityActual - it.quantityExpected}
                            </span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Cash Check if End of Trip */}
              {selectedRecord.cashCheck && (
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border space-y-1.5">
                  <h4 className="font-bold text-slate-700 uppercase">Đối chiếu tiền thu hộ (COD)</h4>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Tiền thu hộ phải nộp:</span>
                    <span className="font-bold">{selectedRecord.cashCheck.codExpected.toLocaleString()} đ</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Tiền thực nộp về quỹ:</span>
                    <span className="font-bold text-emerald-600 text-sm">
                      {selectedRecord.cashCheck.codActual.toLocaleString()} đ
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 border-t flex items-center justify-between gap-2 bg-slate-50 dark:bg-slate-800/40">
              {selectedRecord.returnedItems && selectedRecord.returnedItems.length > 0 ? (
                <button
                  onClick={() => createStockInForReturnedGoods(selectedRecord.id)}
                  className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Tạo phiếu nhập kho hàng hoàn</span>
                </button>
              ) : <div />}

              <button
                onClick={() => setPrintRecord(selectedRecord)}
                className="px-4 py-2 rounded-lg bg-indigo-600 text-white font-bold text-xs flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>In Biên Bản</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Lập Biên Bản */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-5 shadow-2xl border space-y-4">
            <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <FileCheck2 className="w-5 h-5 text-emerald-500" />
              <span>Lập Biên Bản Bàn Giao Mới</span>
            </h3>

            <form onSubmit={handleCreateSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Loại biên bản</label>
                <select
                  value={formType}
                  onChange={(e: any) => setFormType(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-800"
                >
                  <option value="Bàn giao xuất phát">Bàn giao xuất phát (Thủ kho ➔ Tài xế)</option>
                  <option value="Bàn giao cuối chuyến">Bàn giao cuối chuyến (Tài xế ➔ Kho / Quỹ)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Chuyến hàng liên quan</label>
                <select
                  value={selectedShipmentId}
                  onChange={(e) => setSelectedShipmentId(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-800"
                >
                  {shipments.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code} - {s.driverName} ({s.departureDate})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Bên giao</label>
                  <input
                    type="text"
                    value={formDeliverer}
                    onChange={(e) => setFormDeliverer(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Bên nhận</label>
                  <input
                    type="text"
                    value={formReceiver}
                    onChange={(e) => setFormReceiver(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border"
                  />
                </div>
              </div>

              {formType === 'Bàn giao cuối chuyến' && (
                <div className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-xl space-y-2 border">
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="block text-slate-500">COD phải nộp (đ)</label>
                      <input
                        type="number"
                        value={codExpected}
                        onChange={(e) => setCodExpected(Number(e.target.value))}
                        className="w-full px-2 py-1 rounded border"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-500">COD thực nộp (đ)</label>
                      <input
                        type="number"
                        value={codActual}
                        onChange={(e) => setCodActual(Number(e.target.value))}
                        className="w-full px-2 py-1 rounded border"
                      />
                    </div>
                  </div>
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg border text-slate-600"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-emerald-600 text-white font-bold"
                >
                  Xác Nhận Lập Biên Bản
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Mẫu In Biên Bản Bàn Giao Chuẩn */}
      {printRecord && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-2xl max-w-2xl w-full p-8 shadow-2xl my-8 space-y-6">
            <div className="flex items-start justify-between border-b pb-4">
              <div className="flex items-center gap-3">
                <APlusLogo size={40} />
                <div>
                  <h2 className="text-sm font-bold uppercase">CÔNG TY CỔ PHẦN CÔNG NGHỆ &amp; GIẢI PHÁP A+</h2>
                  <p className="text-xs text-slate-500">Bộ phận Quản lý Vận hành Kho &amp; Vận chuyển</p>
                </div>
              </div>
              <div className="text-right">
                <h1 className="text-base font-bold text-emerald-700 uppercase">BIÊN BẢN BÀN GIAO</h1>
                <p className="text-xs font-mono font-bold">{printRecord.code}</p>
              </div>
            </div>

            <div className="text-xs space-y-1">
              <p>Loại biên bản: <strong>{printRecord.type}</strong></p>
              <p>Chuyến vận chuyển: <strong>{printRecord.shipmentCode}</strong></p>
              <p>Thời gian thực hiện: {printRecord.confirmedAt}</p>
              <p>Bên giao: <strong>{printRecord.delivererName}</strong></p>
              <p>Bên nhận: <strong>{printRecord.receiverName}</strong></p>
            </div>

            <table className="w-full border text-xs">
              <thead className="bg-slate-100">
                <tr>
                  <th className="p-2 border text-center">STT</th>
                  <th className="p-2 border">Tên hàng hóa</th>
                  <th className="p-2 border text-center">SKU</th>
                  <th className="p-2 border text-center">SL Dự kiến</th>
                  <th className="p-2 border text-center">SL Thực nhận</th>
                </tr>
              </thead>
              <tbody>
                {printRecord.itemsCheck.map((it, idx) => (
                  <tr key={idx}>
                    <td className="p-2 border text-center">{idx + 1}</td>
                    <td className="p-2 border font-medium">{it.productName}</td>
                    <td className="p-2 border font-mono text-center">{it.sku}</td>
                    <td className="p-2 border text-center">{it.quantityExpected}</td>
                    <td className="p-2 border text-center font-bold">{it.quantityActual}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            {printRecord.cashCheck && (
              <div className="p-3 bg-slate-50 border rounded text-xs space-y-1">
                <p>Tiền thu hộ COD dự kiến: <strong>{printRecord.cashCheck.codExpected.toLocaleString()} VNĐ</strong></p>
                <p>Tiền thu hộ COD thực nộp: <strong>{printRecord.cashCheck.codActual.toLocaleString()} VNĐ</strong></p>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4 text-center text-xs pt-8">
              <div>
                <p className="font-bold">ĐẠI DIỆN BÊN GIAO</p>
                <div className="h-14" />
                <p className="font-semibold">{printRecord.delivererName}</p>
              </div>
              <div>
                <p className="font-bold">ĐẠI DIỆN BÊN NHẬN</p>
                <div className="h-14" />
                <p className="font-semibold">{printRecord.receiverName}</p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t print:hidden">
              <button
                onClick={() => setPrintRecord(null)}
                className="px-4 py-2 rounded-lg border text-slate-600 text-xs font-semibold"
              >
                Đóng
              </button>
              <button
                onClick={() => window.print()}
                className="px-5 py-2 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center gap-1"
              >
                <Printer className="w-4 h-4" />
                <span>In Biên Bản</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
