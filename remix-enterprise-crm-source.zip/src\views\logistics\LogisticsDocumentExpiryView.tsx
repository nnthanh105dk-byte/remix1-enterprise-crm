import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import { DocumentExpiry, DocumentExpiryType, DocumentRelatedTarget } from '../../types/logistics';
import {
  FileText,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Plus,
  ShieldAlert,
  RotateCw,
  Calendar,
  X,
  FileSpreadsheet,
} from 'lucide-react';

export const LogisticsDocumentExpiryView: React.FC = () => {
  const { showToast } = useCRM();
  const { documentExpiries, renewDocument, addDocumentExpiry } = useLogistics();

  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Renewal Modal
  const [renewingDoc, setRenewingDoc] = useState<DocumentExpiry | null>(null);
  const [newDocNumber, setNewDocNumber] = useState('');
  const [newExpiryDate, setNewExpiryDate] = useState('');
  const [renewalNotes, setRenewalNotes] = useState('');

  // New Doc Modal
  const [isNewDocModalOpen, setIsNewDocModalOpen] = useState(false);
  const [formNumber, setFormNumber] = useState('');
  const [formType, setFormType] = useState<DocumentExpiryType>('Đăng kiểm xe');
  const [formTargetType, setFormTargetType] = useState<DocumentRelatedTarget>('Xe');
  const [formTargetName, setFormTargetName] = useState('');
  const [formIssueDate, setFormIssueDate] = useState(new Date().toISOString().split('T')[0]);
  const [formExpiryDate, setFormExpiryDate] = useState(
    new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [formNotes, setFormNotes] = useState('');

  // Statistics
  const expiredDocs = documentExpiries.filter((d) => d.status === 'Đã hết hạn');
  const within30Days = documentExpiries.filter((d) => d.status === 'Cận hạn (≤30 ngày)');
  const within60Days = documentExpiries.filter((d) => d.status === 'Cận hạn (31-60 ngày)');
  const within90Days = documentExpiries.filter((d) => d.status === 'Cận hạn (61-90 ngày)');

  const filteredDocs = documentExpiries.filter((d) => {
    if (typeFilter !== 'all' && d.documentType !== typeFilter) return false;
    if (statusFilter !== 'all' && d.status !== statusFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        d.documentNumber.toLowerCase().includes(q) ||
        d.targetName.toLowerCase().includes(q) ||
        d.documentType.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleOpenRenewModal = (doc: DocumentExpiry) => {
    setRenewingDoc(doc);
    setNewDocNumber(`${doc.documentNumber}-NEW`);
    setNewExpiryDate(new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
    setRenewalNotes('');
  };

  const handleRenewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!renewingDoc || !newDocNumber.trim() || !newExpiryDate) return;
    renewDocument(renewingDoc.id, newDocNumber.trim(), newExpiryDate, renewalNotes);
    setRenewingDoc(null);
  };

  const handleCreateNewDocSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNumber.trim() || !formTargetName.trim()) {
      showToast('Lỗi', 'Vui lòng nhập đầy đủ số giấy tờ và tên đối tượng.', 'warning');
      return;
    }

    const expTime = new Date(formExpiryDate).getTime();
    const daysRemaining = Math.round((expTime - Date.now()) / (1000 * 60 * 60 * 24));
    let status: DocumentExpiry['status'] = 'Còn hạn';
    if (daysRemaining < 0) status = 'Đã hết hạn';
    else if (daysRemaining <= 30) status = 'Cận hạn (≤30 ngày)';
    else if (daysRemaining <= 60) status = 'Cận hạn (31-60 ngày)';
    else if (daysRemaining <= 90) status = 'Cận hạn (61-90 ngày)';

    addDocumentExpiry({
      documentNumber: formNumber.trim(),
      documentType: formType,
      relatedType: formTargetType,
      targetId: `target-${Date.now()}`,
      targetName: formTargetName.trim(),
      issueDate: formIssueDate,
      expiryDate: formExpiryDate,
      daysRemaining,
      status,
      notes: formNotes,
    });

    setIsNewDocModalOpen(false);
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border border-rose-200 dark:border-rose-800">
              <ShieldAlert className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Theo Dõi Giấy Tờ Sắp Hết Hạn
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Quản lý hạn đăng kiểm xe, bảo hiểm, bằng lái tài xế, hợp đồng đối tác vận tải và giấy phép lưu hành sản phẩm.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => showToast('Xuất Excel', 'Đang tải danh sách theo dõi hạn giấy tờ (.xlsx)...')}
            className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs sm:text-sm font-semibold flex items-center gap-1.5"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>Xuất Excel</span>
          </button>
          <button
            onClick={() => setIsNewDocModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm Hồ Sơ Giấy Tờ</span>
          </button>
        </div>
      </div>

      {/* 4 Thống kê cảnh báo cấp độ màu giống Quản lý kho */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-xl bg-rose-50/60 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-rose-700 dark:text-rose-300 font-semibold">Đã Hết Hạn</span>
            <span className="w-2.5 h-2.5 rounded-full bg-rose-600 animate-pulse" />
          </div>
          <p className="text-2xl font-bold text-rose-700 dark:text-rose-400 mt-1">
            {expiredDocs.length} <span className="text-xs font-normal">giấy tờ</span>
          </p>
          <p className="text-[11px] text-rose-500 mt-1">Cấm phân công phương tiện/tài xế</p>
        </div>

        <div className="p-4 rounded-xl bg-amber-50/60 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-amber-700 dark:text-amber-300 font-semibold">Cận Hạn ≤ 30 Ngày</span>
            <Clock className="w-4 h-4 text-amber-600" />
          </div>
          <p className="text-2xl font-bold text-amber-700 dark:text-amber-400 mt-1">
            {within30Days.length} <span className="text-xs font-normal">giấy tờ</span>
          </p>
          <p className="text-[11px] text-amber-600 mt-1">Cần lập lịch gia hạn trong tháng</p>
        </div>

        <div className="p-4 rounded-xl bg-yellow-50/60 dark:bg-yellow-950/40 border border-yellow-200 dark:border-yellow-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-yellow-800 dark:text-yellow-300 font-semibold">Hạn 31 - 60 Ngày</span>
            <Calendar className="w-4 h-4 text-yellow-600" />
          </div>
          <p className="text-2xl font-bold text-yellow-800 dark:text-yellow-400 mt-1">
            {within60Days.length} <span className="text-xs font-normal">giấy tờ</span>
          </p>
          <p className="text-[11px] text-yellow-700 mt-1">Chuẩn bị hồ sơ &amp; kinh phí</p>
        </div>

        <div className="p-4 rounded-xl bg-sky-50/60 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs text-sky-700 dark:text-sky-300 font-semibold">Hạn 61 - 90 Ngày</span>
            <CheckCircle2 className="w-4 h-4 text-sky-600" />
          </div>
          <p className="text-2xl font-bold text-sky-700 dark:text-sky-400 mt-1">
            {within90Days.length} <span className="text-xs font-normal">giấy tờ</span>
          </p>
          <p className="text-[11px] text-sky-600 mt-1">Trạng thái an toàn</p>
        </div>
      </div>

      {/* Filter & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo số giấy tờ, tên xe, tài xế..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border bg-slate-50 dark:bg-slate-800"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="text-xs px-3 py-1.5 rounded-lg border bg-white dark:bg-slate-800"
          >
            <option value="all">Tất cả loại giấy tờ</option>
            <option value="Đăng kiểm xe">Đăng kiểm xe</option>
            <option value="Bảo hiểm xe">Bảo hiểm xe</option>
            <option value="Bằng lái tài xế">Bằng lái tài xế</option>
            <option value="Hợp đồng đơn vị vận chuyển">Hợp đồng ĐVVC</option>
            <option value="Giấy phép/đăng ký sản phẩm">Giấy phép sản phẩm</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="text-xs px-3 py-1.5 rounded-lg border bg-white dark:bg-slate-800"
          >
            <option value="all">Tất cả mức cảnh báo</option>
            <option value="Đã hết hạn">Đã hết hạn</option>
            <option value="Cận hạn (≤30 ngày)">Cận hạn (≤30 ngày)</option>
            <option value="Cận hạn (31-60 ngày)">Cận hạn (31-60 ngày)</option>
            <option value="Cận hạn (61-90 ngày)">Cận hạn (61-90 ngày)</option>
            <option value="Còn hạn">Còn hạn</option>
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] text-slate-500 uppercase font-semibold">
            <tr>
              <th className="p-3">Số giấy tờ</th>
              <th className="p-3">Loại giấy tờ</th>
              <th className="p-3">Đối tượng gắn liền</th>
              <th className="p-3">Ngày hết hạn</th>
              <th className="p-3 text-center">Thời gian còn lại</th>
              <th className="p-3 text-center">Trạng thái cảnh báo</th>
              <th className="p-3 text-center">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredDocs.map((doc) => (
              <tr
                key={doc.id}
                className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 ${
                  doc.status === 'Đã hết hạn' ? 'bg-rose-50/30 dark:bg-rose-950/20' : ''
                }`}
              >
                <td className="p-3 font-mono font-bold text-slate-900 dark:text-white">
                  {doc.documentNumber}
                  {doc.renewedDate && (
                    <div className="text-[10px] text-emerald-600 font-normal">Đã gia hạn ngày {doc.renewedDate}</div>
                  )}
                </td>
                <td className="p-3 font-semibold text-slate-700 dark:text-slate-300">{doc.documentType}</td>
                <td className="p-3">
                  <div className="font-semibold text-slate-800 dark:text-slate-200">{doc.targetName}</div>
                  <div className="text-[10px] text-slate-400 font-sans">Nhóm: {doc.relatedType}</div>
                </td>
                <td className="p-3 font-medium text-slate-800 dark:text-slate-200">{doc.expiryDate}</td>
                <td className="p-3 text-center">
                  <span
                    className={`font-bold ${
                      doc.daysRemaining < 0
                        ? 'text-rose-600'
                        : doc.daysRemaining <= 30
                        ? 'text-amber-600'
                        : 'text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {doc.daysRemaining < 0 ? `Quá hạn ${Math.abs(doc.daysRemaining)} ngày` : `Còn ${doc.daysRemaining} ngày`}
                  </span>
                </td>
                <td className="p-3 text-center">
                  <span
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold ${
                      doc.status === 'Đã hết hạn'
                        ? 'bg-rose-100 text-rose-800 animate-pulse'
                        : doc.status === 'Cận hạn (≤30 ngày)'
                        ? 'bg-amber-100 text-amber-800'
                        : doc.status === 'Cận hạn (31-60 ngày)'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {doc.status}
                  </span>
                </td>
                <td className="p-3 text-center">
                  <button
                    onClick={() => handleOpenRenewModal(doc)}
                    className="px-3 py-1 rounded bg-sky-50 hover:bg-sky-100 text-sky-700 dark:bg-sky-950 dark:text-sky-300 font-semibold flex items-center gap-1 mx-auto"
                  >
                    <RotateCw className="w-3.5 h-3.5" />
                    <span>Gia Hạn</span>
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal Gia Hạn Giấy Tờ */}
      {renewingDoc && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 shadow-2xl border space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <RotateCw className="w-4 h-4 text-sky-500" />
              <span>Gia Hạn Giấy Tờ: {renewingDoc.targetName}</span>
            </h3>

            <p className="text-xs text-slate-500">
              Nhập số giấy tờ mới và thời hạn hiệu lực mới để cập nhật vào hệ thống:
            </p>

            <form onSubmit={handleRenewSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Số giấy tờ mới</label>
                <input
                  type="text"
                  value={newDocNumber}
                  onChange={(e) => setNewDocNumber(e.target.value)}
                  className="w-full px-3 py-2 rounded border"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Hạn hiệu lực mới</label>
                <input
                  type="date"
                  value={newExpiryDate}
                  onChange={(e) => setNewExpiryDate(e.target.value)}
                  className="w-full px-3 py-2 rounded border"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Ghi chú gia hạn</label>
                <textarea
                  rows={2}
                  value={renewalNotes}
                  onChange={(e) => setRenewalNotes(e.target.value)}
                  placeholder="Ví dụ: Đã khám tại Trạm 29-03V, nộp phí 320k..."
                  className="w-full px-3 py-2 rounded border"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setRenewingDoc(null)}
                  className="px-3.5 py-1.5 rounded border text-slate-600"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-sky-600 text-white font-bold"
                >
                  Lưu Gia Hạn
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Thêm Hồ Sơ Mới */}
      {isNewDocModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 shadow-2xl border space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <Plus className="w-4 h-4 text-rose-500" />
              <span>Thêm Hồ Sơ Giấy Tờ Mới</span>
            </h3>

            <form onSubmit={handleCreateNewDocSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Loại giấy tờ</label>
                <select
                  value={formType}
                  onChange={(e: any) => setFormType(e.target.value)}
                  className="w-full px-3 py-2 rounded border"
                >
                  <option value="Đăng kiểm xe">Đăng kiểm xe</option>
                  <option value="Bảo hiểm xe">Bảo hiểm xe</option>
                  <option value="Giấy đăng ký xe">Giấy đăng ký xe</option>
                  <option value="Bằng lái tài xế">Bằng lái tài xế</option>
                  <option value="Hợp đồng đơn vị vận chuyển">Hợp đồng đơn vị vận chuyển</option>
                  <option value="Giấy phép/đăng ký sản phẩm">Giấy phép/đăng ký sản phẩm</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Gắn với đối tượng</label>
                  <select
                    value={formTargetType}
                    onChange={(e: any) => setFormTargetType(e.target.value)}
                    className="w-full px-3 py-2 rounded border"
                  >
                    <option value="Xe">Xe</option>
                    <option value="Tài xế">Tài xế</option>
                    <option value="Đơn vị vận chuyển">Đơn vị vận chuyển</option>
                    <option value="Nhà cung cấp">Nhà cung cấp</option>
                    <option value="Sản phẩm">Sản phẩm</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Tên đối tượng</label>
                  <input
                    type="text"
                    value={formTargetName}
                    onChange={(e) => setFormTargetName(e.target.value)}
                    placeholder="Xe 29C-882.14..."
                    className="w-full px-3 py-2 rounded border"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Số giấy tờ</label>
                <input
                  type="text"
                  value={formNumber}
                  onChange={(e) => setFormNumber(e.target.value)}
                  placeholder="KD-29C88214-2026..."
                  className="w-full px-3 py-2 rounded border"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Ngày cấp</label>
                  <input
                    type="date"
                    value={formIssueDate}
                    onChange={(e) => setFormIssueDate(e.target.value)}
                    className="w-full px-3 py-2 rounded border"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Ngày hết hạn</label>
                  <input
                    type="date"
                    value={formExpiryDate}
                    onChange={(e) => setFormExpiryDate(e.target.value)}
                    className="w-full px-3 py-2 rounded border"
                    required
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsNewDocModalOpen(false)}
                  className="px-3.5 py-1.5 rounded border text-slate-600"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded bg-rose-600 text-white font-bold"
                >
                  Lưu Hồ Sơ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
