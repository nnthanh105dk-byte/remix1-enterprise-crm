import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import { PurchaseInvoice, PurchaseInvoiceItem } from '../../types/logistics';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import {
  FileText,
  Search,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Plus,
  ShieldCheck,
  Building,
  CreditCard,
  DollarSign,
  ArrowRight,
  ShieldAlert,
  X,
} from 'lucide-react';

export const LogisticsPurchaseInvoicesView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const {
    purchaseInvoices,
    approveInvoiceException,
    createPaymentRequest,
    purchaseOrders,
  } = useLogistics();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedInvoice, setSelectedInvoice] = useState<PurchaseInvoice | null>(null);

  // Exception Approval Modal
  const [isExceptionModalOpen, setIsExceptionModalOpen] = useState(false);
  const [exceptionApprover, setExceptionApprover] = useState('Trần Minh Đức (Giám đốc)');
  const [exceptionReason, setExceptionReason] = useState('Chấp thuận sai số nhỏ hoặc đợt giao bù trong tuần');

  // KPI Calculations
  const totalPayable = purchaseInvoices
    .filter((pi) => pi.status !== 'Đã thanh toán' && pi.status !== 'Hủy')
    .reduce((sum, pi) => sum + pi.remainingAmount, 0);

  const overdueInvoices = purchaseInvoices.filter((pi) => {
    if (pi.status === 'Đã thanh toán' || pi.status === 'Hủy') return false;
    const dueTime = new Date(pi.dueDate).getTime();
    return !isNaN(dueTime) && dueTime < Date.now();
  });
  const totalOverdue = overdueInvoices.reduce((sum, pi) => sum + pi.remainingAmount, 0);

  const dueIn7Days = purchaseInvoices.filter((pi) => {
    if (pi.status === 'Đã thanh toán' || pi.status === 'Hủy') return false;
    const dueTime = new Date(pi.dueDate).getTime();
    const diff = dueTime - Date.now();
    return diff > 0 && diff <= 7 * 24 * 60 * 60 * 1000;
  });

  const filteredInvoices = purchaseInvoices.filter((pi) => {
    if (statusFilter !== 'all' && pi.status !== statusFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        pi.code.toLowerCase().includes(q) ||
        pi.supplierInvoiceNumber.toLowerCase().includes(q) ||
        pi.supplierName.toLowerCase().includes(q) ||
        pi.purchaseOrderCode.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleApproveExceptionSubmit = () => {
    if (!selectedInvoice || !exceptionReason.trim()) return;
    approveInvoiceException(selectedInvoice.id, exceptionApprover, exceptionReason);
    setIsExceptionModalOpen(false);
    setSelectedInvoice((prev) => (prev ? { ...prev, status: 'Chờ thanh toán' } : null));
  };

  const handleQuickCreatePaymentRequest = (inv: PurchaseInvoice) => {
    if (inv.status === 'Chênh lệch') {
      showToast('Bị chặn', 'Hóa đơn chênh lệch đối chiếu 3 bên không thể lập đề nghị thanh toán cho tới khi được duyệt ngoại lệ.', 'warning');
      return;
    }
    createPaymentRequest({
      requestDate: new Date().toISOString().split('T')[0],
      requesterName: 'Bộ phận Mua hàng & Logistics',
      department: 'Logistics',
      type: 'Thanh toán nhà cung cấp',
      beneficiaryName: inv.supplierName,
      beneficiaryBank: 'Ngân hàng đối tác của NCC',
      beneficiaryAccount: '0011002345678',
      relatedDocumentIds: [inv.id],
      relatedDocumentCodes: [inv.code],
      totalAmount: inv.remainingAmount,
      amountInWords: '',
      paymentMethod: 'Chuyển khoản',
      dueDate: inv.dueDate,
      reason: `Thanh toán hóa đơn mua hàng ${inv.code} (Số HĐ NCC: ${inv.supplierInvoiceNumber})`,
    });
    setActiveModule('logistics-payment-requests');
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
              <FileText className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Hóa Đơn Mua Hàng &amp; Đối Chiếu 3 Bên
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Đối chiếu tự động giữa Đơn mua (PO) - Phiếu nhập kho - Hóa đơn NCC, phát hiện chênh lệch giá &amp; số lượng trước khi chi tiền.
          </p>
        </div>

        <button
          onClick={() => setActiveModule('logistics-payment-requests')}
          className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs sm:text-sm font-semibold flex items-center gap-1.5"
        >
          <span>Xem Đề nghị thanh toán</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* 3 KPI Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Tổng nợ phải trả NCC</span>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
            {totalPayable.toLocaleString()} đ
          </p>
          <p className="text-[11px] text-slate-400 mt-1">Các hóa đơn chưa thanh toán hoặc thanh toán 1 phần</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Hóa đơn quá hạn thanh toán</span>
          <p className="text-2xl font-bold text-rose-600 dark:text-rose-400 mt-1">
            {totalOverdue.toLocaleString()} đ
          </p>
          <p className="text-[11px] text-rose-500 mt-1">{overdueInvoices.length} hóa đơn đã vượt hạn cam kết</p>
        </div>

        <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-medium">Đến hạn trong 7 ngày tới</span>
          <p className="text-2xl font-bold text-amber-600 dark:text-amber-400 mt-1">
            {dueIn7Days.reduce((sum, pi) => sum + pi.remainingAmount, 0).toLocaleString()} đ
          </p>
          <p className="text-[11px] text-slate-400 mt-1">{dueIn7Days.length} hóa đơn sắp đến hạn</p>
        </div>
      </div>

      {/* Filter & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo số HĐ (HDM-2026-xxxx), số HĐ NCC, NCC..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border bg-slate-50 dark:bg-slate-800"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="text-xs px-3 py-1.5 rounded-lg border bg-white dark:bg-slate-800"
        >
          <option value="all">Tất cả trạng thái</option>
          <option value="Chờ thanh toán">Chờ thanh toán</option>
          <option value="Chênh lệch">Chênh lệch (3-Way Mismatch)</option>
          <option value="Thanh toán một phần">Thanh toán một phần</option>
          <option value="Đã thanh toán">Đã thanh toán</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] text-slate-500 uppercase font-semibold">
            <tr>
              <th className="p-3">Mã HĐ &amp; Số HĐ NCC</th>
              <th className="p-3">Nhà cung cấp</th>
              <th className="p-3">Đơn mua liên quan</th>
              <th className="p-3 text-right">Tổng tiền</th>
              <th className="p-3 text-right">Còn nợ</th>
              <th className="p-3">Hạn thanh toán</th>
              <th className="p-3 text-center">Đối chiếu 3 bên</th>
              <th className="p-3 text-center">Trạng thái</th>
              <th className="p-3 text-center">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredInvoices.map((pi) => {
              const isOverdue =
                pi.status !== 'Đã thanh toán' &&
                new Date(pi.dueDate).getTime() < Date.now();

              return (
                <tr
                  key={pi.id}
                  className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 ${
                    pi.status === 'Chênh lệch'
                      ? 'bg-rose-50/30 dark:bg-rose-950/20'
                      : ''
                  }`}
                >
                  <td className="p-3 font-mono font-bold text-indigo-600">
                    {pi.code}
                    <div className="text-[10px] text-slate-500 font-sans">
                      Số NCC: <strong>{pi.supplierInvoiceNumber}</strong> ({pi.invoiceSeries})
                    </div>
                  </td>
                  <td className="p-3 font-semibold text-slate-800 dark:text-slate-200 max-w-[200px] truncate">
                    {pi.supplierName}
                  </td>
                  <td className="p-3 font-mono text-sky-600">{pi.purchaseOrderCode}</td>
                  <td className="p-3 text-right font-bold text-slate-900 dark:text-white">
                    {pi.totalAmount.toLocaleString()} đ
                  </td>
                  <td className="p-3 text-right font-bold text-rose-600">
                    {pi.remainingAmount.toLocaleString()} đ
                  </td>
                  <td className="p-3">
                    <span className={isOverdue ? 'text-rose-600 font-bold' : ''}>
                      {pi.dueDate}
                      {isOverdue && ' (Quá hạn)'}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    {pi.threeWayMatchStatus === 'Khớp' ? (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-3 h-3" /> Khớp 100%
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-600 bg-rose-50 dark:bg-rose-950/60 px-2 py-0.5 rounded-full animate-pulse">
                        <AlertTriangle className="w-3 h-3" /> {pi.threeWayMatchStatus}
                      </span>
                    )}
                  </td>
                  <td className="p-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        pi.status === 'Đã thanh toán'
                          ? 'bg-emerald-100 text-emerald-800'
                          : pi.status === 'Chênh lệch'
                          ? 'bg-rose-100 text-rose-800'
                          : pi.status === 'Thanh toán một phần'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {pi.status}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => setSelectedInvoice(pi)}
                        className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 font-semibold"
                      >
                        Đối chiếu
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Drawer Chi tiết Đối chiếu 3 bên */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end animate-fade-in">
          <div className="w-full max-w-2xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col border-l">
            <div className="p-4 sm:p-5 border-b flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
              <div>
                <span className="font-mono text-base font-bold text-indigo-600">
                  {selectedInvoice.code}
                </span>
                <span
                  className={`ml-2 px-2 py-0.5 rounded text-[10px] font-bold ${
                    selectedInvoice.status === 'Chênh lệch' ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {selectedInvoice.threeWayMatchStatus}
                </span>
                <h3 className="text-sm font-semibold mt-0.5">{selectedInvoice.supplierName}</h3>
              </div>
              <button onClick={() => setSelectedInvoice(null)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-xl border space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Số HĐ nhà cung cấp:</span>
                  <span className="font-bold">{selectedInvoice.supplierInvoiceNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Đơn mua hàng liên quan:</span>
                  <span className="font-mono font-bold text-sky-600">
                    {selectedInvoice.purchaseOrderCode}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Tổng tiền / Còn nợ:</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {selectedInvoice.totalAmount.toLocaleString()} đ / Còn nợ:{' '}
                    <span className="text-rose-600">{selectedInvoice.remainingAmount.toLocaleString()} đ</span>
                  </span>
                </div>
              </div>

              {/* Bảng đối chiếu 3 bên từng dòng */}
              <div>
                <h4 className="font-bold text-slate-700 dark:text-slate-300 uppercase mb-2">
                  Bảng đối chiếu 3 bên (Đơn mua PO - Phiếu nhập kho - Hóa đơn)
                </h4>
                <div className="border rounded-xl overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 text-[11px]">
                      <tr>
                        <th className="p-2">Sản phẩm</th>
                        <th className="p-2 text-center">SL Đặt (PO)</th>
                        <th className="p-2 text-center">SL Thực Nhập</th>
                        <th className="p-2 text-center">SL Hóa Đơn</th>
                        <th className="p-2 text-right">Đơn giá PO</th>
                        <th className="p-2 text-right">Đơn giá HĐ</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {selectedInvoice.items.map((it, idx) => (
                        <tr
                          key={idx}
                          className={it.lineDiscrepancy ? 'bg-rose-50/50 dark:bg-rose-950/20 text-rose-900 dark:text-rose-200' : ''}
                        >
                          <td className="p-2">
                            <div className="font-semibold">{it.productName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{it.sku}</div>
                            {it.discrepancyDetail && (
                              <div className="text-[10px] text-rose-600 italic mt-0.5 font-medium">
                                * {it.discrepancyDetail}
                              </div>
                            )}
                          </td>
                          <td className="p-2 text-center">{it.poQuantity}</td>
                          <td className="p-2 text-center font-bold text-emerald-600">{it.stockInQuantity}</td>
                          <td className={`p-2 text-center font-bold ${it.lineDiscrepancy ? 'text-rose-600' : ''}`}>
                            {it.invoiceQuantity}
                          </td>
                          <td className="p-2 text-right">{it.poPrice.toLocaleString()}</td>
                          <td className="p-2 text-right font-bold">{it.invoicePrice.toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Exception approval note if exists */}
              {selectedInvoice.exceptionApproval && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 space-y-1">
                  <p className="font-bold flex items-center gap-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>Đã duyệt ngoại lệ chênh lệch</span>
                  </p>
                  <p>Người duyệt: {selectedInvoice.exceptionApproval.approvedBy} ({selectedInvoice.exceptionApproval.approvedAt})</p>
                  <p>Lý do: "{selectedInvoice.exceptionApproval.reason}"</p>
                </div>
              )}
            </div>

            <div className="p-4 border-t flex items-center justify-between gap-2 bg-slate-50">
              {selectedInvoice.status === 'Chênh lệch' ? (
                <button
                  onClick={() => setIsExceptionModalOpen(true)}
                  className="px-4 py-2 rounded-lg bg-amber-600 text-white font-bold text-xs hover:bg-amber-700"
                >
                  Duyệt Ngoại Lệ Chênh Lệch
                </button>
              ) : (
                <div />
              )}

              <button
                disabled={selectedInvoice.status === 'Chênh lệch'}
                onClick={() => handleQuickCreatePaymentRequest(selectedInvoice)}
                className={`px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-1.5 ${
                  selectedInvoice.status === 'Chênh lệch'
                    ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
                    : 'bg-indigo-600 text-white hover:bg-indigo-700 shadow-xs'
                }`}
              >
                <span>Tạo Đề Nghị Thanh Toán</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal Duyệt ngoại lệ */}
      {isExceptionModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-5 shadow-2xl border space-y-4">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-500" />
              <span>Duyệt Ngoại Lệ Chênh Lệch Hóa Đơn</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-600 font-semibold mb-1">Cấp phê duyệt ngoại lệ</label>
                <input
                  type="text"
                  value={exceptionApprover}
                  onChange={(e) => setExceptionApprover(e.target.value)}
                  className="w-full px-3 py-2 rounded border"
                />
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Lý do chấp thuận ngoại lệ</label>
                <textarea
                  rows={3}
                  value={exceptionReason}
                  onChange={(e) => setExceptionReason(e.target.value)}
                  className="w-full px-3 py-2 rounded border"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t">
              <button
                onClick={() => setIsExceptionModalOpen(false)}
                className="px-3.5 py-1.5 rounded border text-slate-600 text-xs"
              >
                Hủy
              </button>
              <button
                onClick={handleApproveExceptionSubmit}
                className="px-4 py-1.5 rounded bg-amber-600 text-white font-bold text-xs"
              >
                Xác Nhận Mở Khóa Thanh Toán
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
