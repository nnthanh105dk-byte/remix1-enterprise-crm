import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useLogistics } from '../../context/LogisticsContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { PurchaseOrder, PurchaseOrderItem } from '../../types/logistics';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import { APlusLogo } from '../../components/common/APlusLogo';
import { numberToVietnameseWords } from '../../utils/vietnameseNumberWords';
import {
  ShoppingCart,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Printer,
  X,
  Building,
  DollarSign,
  AlertTriangle,
  ArrowRight,
  Send,
  Trash2,
  PackagePlus,
} from 'lucide-react';

export const LogisticsPurchaseOrdersView: React.FC = () => {
  const { showToast, setActiveModule } = useCRM();
  const {
    purchaseOrders,
    createPurchaseOrder,
    approvePurchaseOrder,
    sendPurchaseOrderToSupplier,
    suppliers,
  } = useLogistics();
  const { products, warehouses } = useWarehouse();

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const [selectedOrder, setSelectedOrder] = useState<PurchaseOrder | null>(null);
  const [printOrder, setPrintOrder] = useState<PurchaseOrder | null>(null);

  // Modal Create Purchase Order
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formSupplierId, setFormSupplierId] = useState(suppliers[0]?.id || '');
  const [formWarehouseId, setFormWarehouseId] = useState(warehouses[0]?.id || 'wh-hn');
  const [formDate, setFormDate] = useState(new Date().toISOString().split('T')[0]);
  const [formDeliveryDate, setFormDeliveryDate] = useState(
    new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
  );
  const [formPaymentTerms, setFormPaymentTerms] = useState('Thanh toán 100% sau 30 ngày nhận hàng');
  const [formNotes, setFormNotes] = useState('');

  const [formItems, setFormItems] = useState<PurchaseOrderItem[]>([
    {
      sku: products[0]?.sku || 'SKU-001',
      productName: products[0]?.name || 'Sản phẩm 1',
      unit: products[0]?.unit || 'Bộ',
      quantity: 10,
      receivedQuantity: 0,
      unitPrice: products[0]?.costPrice || 5000000,
      discountPercent: 0,
      vatRate: 10,
      total: (products[0]?.costPrice || 5000000) * 10 * 1.1,
      lastPurchasePrice: (products[0]?.costPrice || 5000000) * 0.98,
    },
  ]);

  const filteredOrders = purchaseOrders.filter((po) => {
    if (statusFilter !== 'all' && po.status !== statusFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        po.code.toLowerCase().includes(q) ||
        po.supplierName.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleAddItem = () => {
    const prod = products[0];
    if (!prod) return;
    setFormItems((prev) => [
      ...prev,
      {
        sku: prod.sku,
        productName: prod.name,
        unit: prod.unit,
        quantity: 5,
        receivedQuantity: 0,
        unitPrice: prod.costPrice,
        discountPercent: 0,
        vatRate: 10,
        total: Math.round(prod.costPrice * 5 * 1.1),
        lastPurchasePrice: Math.round(prod.costPrice * 0.98),
      },
    ]);
  };

  const handleUpdateItem = (index: number, updates: Partial<PurchaseOrderItem>) => {
    setFormItems((prev) =>
      prev.map((item, idx) => {
        if (idx !== index) return item;
        const updated = { ...item, ...updates };
        const sub = updated.quantity * updated.unitPrice * (1 - updated.discountPercent / 100);
        const vat = Math.round((sub * updated.vatRate) / 100);
        updated.total = sub + vat;
        return updated;
      })
    );
  };

  const handleProductChange = (index: number, sku: string) => {
    const prod = products.find((p) => p.sku === sku);
    if (!prod) return;
    handleUpdateItem(index, {
      sku: prod.sku,
      productName: prod.name,
      unit: prod.unit,
      unitPrice: prod.costPrice,
      lastPurchasePrice: Math.round(prod.costPrice * 0.98),
    });
  };

  const handleDeleteItem = (index: number) => {
    setFormItems((prev) => prev.filter((_, i) => i !== index));
  };

  // Nút "Tạo đơn mua từ hàng sắp hết" (Auto-populate low stock items)
  const handleAutoPopulateLowStock = () => {
    const lowStockItems: PurchaseOrderItem[] = [];

    products.forEach((p) => {
      const totalStock = Object.values(p.stocks).reduce((a, b) => a + b, 0);
      const allocated = p.reserved || 0;
      const available = Math.max(0, totalStock - allocated);

      if (available <= p.minSafeStock) {
        const suggestedQty = Math.max(10, p.optimalStock - available);
        const sub = suggestedQty * p.costPrice;
        const vat = Math.round(sub * 0.1);

        lowStockItems.push({
          sku: p.sku,
          productName: p.name,
          unit: p.unit,
          quantity: suggestedQty,
          receivedQuantity: 0,
          unitPrice: p.costPrice,
          discountPercent: 0,
          vatRate: 10,
          total: sub + vat,
          lastPurchasePrice: Math.round(p.costPrice * 0.97),
        });
      }
    });

    if (lowStockItems.length === 0) {
      showToast('Thông báo', 'Hiện không có sản phẩm nào dưới mức tồn tối thiểu.', 'info');
      return;
    }

    setFormItems(lowStockItems);
    setIsCreateModalOpen(true);
    showToast('Tự động gợi ý hàng sắp hết', `Đã tự động lấy ${lowStockItems.length} mã hàng cần nhập thêm vào đơn mua.`);
  };

  const formSubTotal = formItems.reduce((sum, it) => sum + it.quantity * it.unitPrice * (1 - it.discountPercent / 100), 0);
  const formVatTotal = formItems.reduce((sum, it) => sum + ((it.quantity * it.unitPrice * (1 - it.discountPercent / 100)) * it.vatRate) / 100, 0);
  const formGrandTotal = formSubTotal + formVatTotal;

  const handleCreateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formItems.length === 0) {
      showToast('Lỗi', 'Đơn mua phải có ít nhất 1 dòng sản phẩm.', 'warning');
      return;
    }

    const supp = suppliers.find((s) => s.id === formSupplierId);
    const wh = warehouses.find((w) => w.id === formWarehouseId);
    if (!supp || !wh) return;

    createPurchaseOrder({
      orderDate: formDate,
      expectedDeliveryDate: formDeliveryDate,
      supplierId: supp.id,
      supplierName: supp.name,
      supplierPhone: supp.phone,
      supplierAddress: supp.address,
      warehouseId: wh.id,
      warehouseName: wh.name,
      items: formItems,
      subTotal: Math.round(formSubTotal),
      vatAmount: Math.round(formVatTotal),
      totalAmount: Math.round(formGrandTotal),
      amountInWords: numberToVietnameseWords(Math.round(formGrandTotal)),
      paymentTerms: formPaymentTerms,
      notes: formNotes,
    });

    setIsCreateModalOpen(false);
  };

  return (
    <div className="space-y-5 animate-fade-in pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 sm:p-6 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
              <ShoppingCart className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">
              Đơn Mua Hàng (Purchase Orders)
            </h1>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Lập đơn mua hàng gửi NCC, đối chiếu tiến độ nhận hàng và lập đơn mua bổ sung từ hàng sắp hết tồn kho.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleAutoPopulateLowStock}
            className="px-3.5 py-2 rounded-xl bg-amber-50 hover:bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300 text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors border border-amber-200 dark:border-amber-800"
          >
            <PackagePlus className="w-4 h-4 text-amber-500" />
            <span>Tạo đơn từ hàng sắp hết</span>
          </button>
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-semibold flex items-center gap-1.5 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Tạo Đơn Mua Hàng</span>
          </button>
        </div>
      </div>

      {/* Filter & Search */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row gap-3 items-center justify-between">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo số đơn (DMH-2026-xxxx), nhà cung cấp..."
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border bg-slate-50 dark:bg-slate-800"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="text-xs px-3 py-1.5 rounded-lg border bg-white dark:bg-slate-800"
        >
          <option value="all">Tất cả trạng thái</option>
          <option value="Chờ duyệt">Chờ duyệt</option>
          <option value="Đã duyệt">Đã duyệt</option>
          <option value="Đã gửi nhà cung cấp">Đã gửi nhà cung cấp</option>
          <option value="Đang nhận hàng">Đang nhận hàng</option>
          <option value="Hoàn tất">Hoàn tất</option>
        </select>
      </div>

      {/* Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 dark:bg-slate-800 text-[11px] text-slate-500 uppercase font-semibold">
            <tr>
              <th className="p-3">Số đơn &amp; Ngày đặt</th>
              <th className="p-3">Nhà cung cấp</th>
              <th className="p-3 text-right">Tổng tiền</th>
              <th className="p-3">Ngày giao dự kiến</th>
              <th className="p-3 text-center">Tiến độ nhận hàng</th>
              <th className="p-3 text-center">Trạng thái</th>
              <th className="p-3 text-center">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {filteredOrders.map((po) => (
              <tr key={po.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                <td className="p-3 font-mono font-bold text-sky-600">
                  {po.code}
                  <div className="text-[10px] text-slate-400 font-sans font-normal">{po.orderDate}</div>
                </td>
                <td className="p-3 font-semibold text-slate-800 dark:text-slate-200 max-w-[200px] truncate">
                  {po.supplierName}
                </td>
                <td className="p-3 text-right font-bold text-slate-900 dark:text-white">
                  {po.totalAmount.toLocaleString()} đ
                </td>
                <td className="p-3 font-medium">{po.expectedDeliveryDate}</td>
                <td className="p-3 text-center">
                  <span
                    className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                      po.receivingProgress === 'Đã nhận đủ'
                        ? 'bg-emerald-100 text-emerald-800'
                        : po.receivingProgress === 'Nhận một phần'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {po.receivingProgress}
                  </span>
                </td>
                <td className="p-3 text-center">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-100 text-sky-800">
                    {po.status}
                  </span>
                </td>
                <td className="p-3 text-center">
                  <div className="flex items-center justify-center gap-1">
                    <button
                      onClick={() => setSelectedOrder(po)}
                      className="px-2 py-1 rounded bg-slate-100 dark:bg-slate-800 font-semibold"
                    >
                      Chi tiết
                    </button>
                    <button
                      onClick={() => setPrintOrder(po)}
                      className="p-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-600"
                    >
                      <Printer className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Drawer Chi Tiết Đơn Mua Hàng */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex justify-end animate-fade-in">
          <div className="w-full max-w-xl bg-white dark:bg-slate-900 h-full shadow-2xl flex flex-col border-l">
            <div className="p-4 sm:p-5 border-b flex items-center justify-between bg-slate-50 dark:bg-slate-800/60">
              <div>
                <span className="font-mono text-base font-bold text-sky-600">{selectedOrder.code}</span>
                <span className="ml-2 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-200">
                  {selectedOrder.status}
                </span>
                <h3 className="text-sm font-semibold mt-0.5">{selectedOrder.supplierName}</h3>
              </div>
              <button onClick={() => setSelectedOrder(null)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 text-xs">
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl border space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-400">Kho nhận hàng:</span>
                  <span className="font-semibold">{selectedOrder.warehouseName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Ngày giao dự kiến:</span>
                  <span className="font-semibold">{selectedOrder.expectedDeliveryDate}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Điều khoản thanh toán:</span>
                  <span className="font-semibold">{selectedOrder.paymentTerms}</span>
                </div>
                <div className="flex justify-between pt-1 border-t">
                  <span className="text-slate-500 font-bold">Tổng thanh toán:</span>
                  <span className="font-bold text-slate-900 dark:text-white text-sm">
                    {selectedOrder.totalAmount.toLocaleString()} VNĐ
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 italic">({selectedOrder.amountInWords})</div>
              </div>

              {/* Items */}
              <div>
                <h4 className="font-bold text-slate-700 dark:text-slate-300 uppercase mb-2">
                  Danh mục hàng hóa mua
                </h4>
                <div className="border rounded-xl overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 text-[11px]">
                      <tr>
                        <th className="p-2">Sản phẩm</th>
                        <th className="p-2 text-center">SL đặt</th>
                        <th className="p-2 text-center">Đã nhận</th>
                        <th className="p-2 text-right">Đơn giá</th>
                        <th className="p-2 text-right">Thành tiền</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {selectedOrder.items.map((it, idx) => (
                        <tr key={idx}>
                          <td className="p-2">
                            <div className="font-semibold">{it.productName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{it.sku}</div>
                          </td>
                          <td className="p-2 text-center font-bold">{it.quantity}</td>
                          <td className="p-2 text-center font-bold text-emerald-600">
                            {it.receivedQuantity}
                          </td>
                          <td className="p-2 text-right">{it.unitPrice.toLocaleString()}</td>
                          <td className="p-2 text-right font-bold">{it.total.toLocaleString()}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="p-4 border-t flex justify-between gap-2 bg-slate-50">
              <button
                onClick={() => setPrintOrder(selectedOrder)}
                className="px-3 py-1.5 rounded border text-slate-700 text-xs flex items-center gap-1"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>In PO</span>
              </button>

              <div className="flex items-center gap-2">
                {selectedOrder.status === 'Chờ duyệt' && (
                  <button
                    onClick={() => {
                      approvePurchaseOrder(selectedOrder.id);
                      setSelectedOrder((prev) => (prev ? { ...prev, status: 'Đã duyệt' } : null));
                    }}
                    className="px-3.5 py-1.5 rounded bg-emerald-600 text-white font-bold text-xs"
                  >
                    Duyệt Đơn Mua
                  </button>
                )}

                {selectedOrder.status === 'Đã duyệt' && (
                  <button
                    onClick={() => {
                      sendPurchaseOrderToSupplier(selectedOrder.id);
                      setSelectedOrder((prev) => (prev ? { ...prev, status: 'Đã gửi nhà cung cấp' } : null));
                    }}
                    className="px-3.5 py-1.5 rounded bg-sky-600 text-white font-bold text-xs flex items-center gap-1"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Gửi Nhà Cung Cấp</span>
                  </button>
                )}

                {(selectedOrder.status === 'Đã duyệt' ||
                  selectedOrder.status === 'Đã gửi nhà cung cấp' ||
                  selectedOrder.status === 'Đang nhận hàng') && (
                  <button
                    onClick={() => setActiveModule('logistics-stock-in')}
                    className="px-3.5 py-1.5 rounded bg-indigo-600 text-white font-bold text-xs flex items-center gap-1"
                  >
                    <span>Tạo Phiếu Nhập Kho</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Soạn Đơn Mua Hàng */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-3xl w-full p-6 shadow-2xl border space-y-4 my-8">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <ShoppingCart className="w-5 h-5 text-sky-500" />
                <span>Soạn Đơn Mua Hàng Mới (Purchase Order)</span>
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)}>
                <X className="w-5 h-5 text-slate-400" />
              </button>
            </div>

            <form onSubmit={handleCreateSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Nhà cung cấp</label>
                  <select
                    value={formSupplierId}
                    onChange={(e) => setFormSupplierId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-800"
                  >
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.code} - {s.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Kho nhận hàng</label>
                  <select
                    value={formWarehouseId}
                    onChange={(e) => setFormWarehouseId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border bg-white dark:bg-slate-800"
                  >
                    {warehouses.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.code} - {w.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Ngày đặt hàng</label>
                  <input
                    type="date"
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Ngày giao dự kiến</label>
                  <input
                    type="date"
                    value={formDeliveryDate}
                    onChange={(e) => setFormDeliveryDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border"
                  />
                </div>
              </div>

              {/* Items List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-700 uppercase">Danh mục sản phẩm mua</label>
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="px-2.5 py-1 rounded bg-sky-50 text-sky-700 font-semibold flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Thêm dòng</span>
                  </button>
                </div>

                <div className="border rounded-xl overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-slate-100 text-[11px]">
                      <tr>
                        <th className="p-2 w-48">Sản phẩm</th>
                        <th className="p-2 text-center w-20">Số lượng</th>
                        <th className="p-2 text-right w-28">Đơn giá mua</th>
                        <th className="p-2 text-center w-16">VAT %</th>
                        <th className="p-2 text-right w-28">Thành tiền</th>
                        <th className="p-2 w-8"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {formItems.map((item, idx) => (
                        <tr key={idx}>
                          <td className="p-2">
                            <select
                              value={item.sku}
                              onChange={(e) => handleProductChange(idx, e.target.value)}
                              className="w-full p-1 rounded border text-xs"
                            >
                              {products.map((p) => (
                                <option key={p.sku} value={p.sku}>
                                  {p.name} ({p.sku})
                                </option>
                              ))}
                            </select>
                            {item.lastPurchasePrice && (
                              <div className="text-[10px] text-slate-400 mt-0.5">
                                Giá mua gần nhất: {item.lastPurchasePrice.toLocaleString()} đ
                              </div>
                            )}
                          </td>
                          <td className="p-2 text-center">
                            <input
                              type="number"
                              min={1}
                              value={item.quantity}
                              onChange={(e) => handleUpdateItem(idx, { quantity: Number(e.target.value) })}
                              className="w-16 p-1 rounded border text-center font-bold"
                            />
                          </td>
                          <td className="p-2 text-right">
                            <input
                              type="number"
                              value={item.unitPrice}
                              onChange={(e) => handleUpdateItem(idx, { unitPrice: Number(e.target.value) })}
                              className="w-24 p-1 rounded border text-right font-medium"
                            />
                          </td>
                          <td className="p-2 text-center font-semibold">10%</td>
                          <td className="p-2 text-right font-bold text-slate-800">
                            {item.total.toLocaleString()}
                          </td>
                          <td className="p-2 text-center">
                            <button
                              type="button"
                              onClick={() => handleDeleteItem(idx)}
                              className="text-slate-400 hover:text-rose-500"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-right">
                  <div>Tiền hàng: <strong>{Math.round(formSubTotal).toLocaleString()} đ</strong></div>
                  <div>Thuế VAT 10%: <strong>{Math.round(formVatTotal).toLocaleString()} đ</strong></div>
                  <div className="text-sm font-bold text-slate-900">
                    Tổng cộng: {Math.round(formGrandTotal).toLocaleString()} VNĐ
                  </div>
                  <div className="text-[11px] text-slate-500 italic">
                    ({numberToVietnameseWords(Math.round(formGrandTotal))})
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Điều khoản thanh toán &amp; Ghi chú</label>
                <input
                  type="text"
                  value={formPaymentTerms}
                  onChange={(e) => setFormPaymentTerms(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border mb-2"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg border text-slate-600 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-sky-600 text-white font-bold"
                >
                  Lập Đơn Mua Hàng
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Mẫu In PO */}
      {printOrder && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-2xl max-w-3xl w-full p-8 shadow-2xl my-8 space-y-6">
            <div className="flex items-start justify-between border-b pb-4">
              <div className="flex items-center gap-3">
                <APlusLogo size={42} />
                <div>
                  <h2 className="text-sm font-bold uppercase">CÔNG TY CỔ PHẦN CÔNG NGHỆ &amp; GIẢI PHÁP A+</h2>
                  <p className="text-xs text-slate-500">Phòng Mua hàng &amp; Quản trị Chuỗi cung ứng</p>
                </div>
              </div>
              <div className="text-right">
                <h1 className="text-base font-bold text-sky-700 uppercase">ĐƠN ĐẶT HÀNG MUA (PO)</h1>
                <p className="text-xs font-mono font-bold">{printOrder.code}</p>
                <p className="text-[11px] text-slate-400">Ngày: {printOrder.orderDate}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <p>Nhà cung cấp: <strong>{printOrder.supplierName}</strong></p>
                <p>Địa chỉ: {printOrder.supplierAddress}</p>
                <p>Điện thoại: {printOrder.supplierPhone}</p>
              </div>
              <div>
                <p>Kho nhận hàng: <strong>{printOrder.warehouseName}</strong></p>
                <p>Ngày giao dự kiến: <strong>{printOrder.expectedDeliveryDate}</strong></p>
                <p>Điều khoản: {printOrder.paymentTerms}</p>
              </div>
            </div>

            <table className="w-full border text-xs">
              <thead className="bg-slate-100">
                <tr>
                  <th className="p-2 border text-center w-10">STT</th>
                  <th className="p-2 border">Tên hàng hóa</th>
                  <th className="p-2 border text-center w-24">Mã SKU</th>
                  <th className="p-2 border text-center w-16">ĐVT</th>
                  <th className="p-2 border text-center w-20">Số lượng</th>
                  <th className="p-2 border text-right w-24">Đơn giá</th>
                  <th className="p-2 border text-right w-28">Thành tiền</th>
                </tr>
              </thead>
              <tbody>
                {printOrder.items.map((it, idx) => (
                  <tr key={idx}>
                    <td className="p-2 border text-center">{idx + 1}</td>
                    <td className="p-2 border font-medium">{it.productName}</td>
                    <td className="p-2 border text-center font-mono">{it.sku}</td>
                    <td className="p-2 border text-center">{it.unit}</td>
                    <td className="p-2 border text-center font-bold">{it.quantity}</td>
                    <td className="p-2 border text-right">{it.unitPrice.toLocaleString()}</td>
                    <td className="p-2 border text-right font-bold">{it.total.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>

            <div className="text-right text-xs space-y-1">
              <div>Tổng tiền hàng: <strong>{printOrder.subTotal.toLocaleString()} VNĐ</strong></div>
              <div>Thuế GTGT (VAT): <strong>{printOrder.vatAmount.toLocaleString()} VNĐ</strong></div>
              <div className="text-sm font-bold text-slate-900">
                Tổng thanh toán: {printOrder.totalAmount.toLocaleString()} VNĐ
              </div>
              <div className="italic text-slate-500">Bằng chữ: {printOrder.amountInWords}</div>
            </div>

            <div className="grid grid-cols-2 gap-4 text-center text-xs pt-8">
              <div>
                <p className="font-bold">ĐẠI DIỆN BÊN MUA</p>
                <div className="h-16" />
                <p className="font-semibold">Trưởng Bộ phận Logistics &amp; Mua hàng</p>
              </div>
              <div>
                <p className="font-bold">ĐẠI DIỆN NHÀ CUNG CẤP</p>
                <div className="h-16" />
                <p className="font-semibold">{printOrder.supplierName}</p>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t print:hidden">
              <button
                onClick={() => setPrintOrder(null)}
                className="px-4 py-2 rounded-lg border text-slate-600 text-xs font-semibold"
              >
                Đóng
              </button>
              <button
                onClick={() => window.print()}
                className="px-5 py-2 rounded-lg bg-sky-600 text-white font-bold text-xs flex items-center gap-1"
              >
                <Printer className="w-4 h-4" />
                <span>In PO</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
