import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { Product, InventoryTransaction } from '../types/crm';
import {
  Boxes,
  Plus,
  ArrowDownToLine,
  ArrowUpFromLine,
  FileCode,
  AlertTriangle,
  History,
  Building,
  CheckCircle2,
  X,
  Search,
} from 'lucide-react';

export const InventoryView: React.FC = () => {
  const {
    products,
    stockTransactions,
    addStockMovement,
    addProduct,
    hasPermission,
    language,
    themeDef,
    openScreenSpec,
    t,
  } = useCRM();

  const isVi = language === 'vi';
  const [activeTab, setActiveTab] = useState<'products' | 'transactions'>('products');
  const [searchTerm, setSearchTerm] = useState('');

  // Movement Modal
  const [isMovementModalOpen, setIsMovementModalOpen] = useState(false);
  const [movementType, setMovementType] = useState<InventoryTransaction['type']>('Nhập kho');
  const [selectedProductId, setSelectedProductId] = useState<string>(products[0]?.id || '');
  const [selectedWarehouse, setSelectedWarehouse] = useState<InventoryTransaction['warehouse']>('Kho Hà Nội');
  const [movementQty, setMovementQty] = useState<number>(5);
  const [movementReason, setMovementReason] = useState<string>('Nhập bổ sung nguồn hàng dự phòng');

  const canCreate = hasPermission('inventory', 'create');

  const formatVND = (num: number) => {
    return num.toLocaleString() + ' ₫';
  };

  // Stock sums
  const totalHanoi = products.reduce((sum, p) => sum + p.stockHanoi, 0);
  const totalDanang = products.reduce((sum, p) => sum + p.stockDanang, 0);
  const totalHCM = products.reduce((sum, p) => sum + p.stockHCM, 0);

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleMovementSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId || movementQty <= 0) return;
    addStockMovement(movementType, selectedWarehouse, selectedProductId, movementQty, movementReason);
    setIsMovementModalOpen(false);
  };

  const openMovementDialog = (type: InventoryTransaction['type']) => {
    setMovementType(type);
    setMovementReason(
      type === 'Nhập kho'
        ? 'Nhập khẩu bổ sung lô hàng mới theo hợp đồng cung ứng'
        : 'Xuất kho bàn giao lắp đặt cho khách hàng'
    );
    setIsMovementModalOpen(true);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
              {t.inventory}
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              3 Tổng Kho Toàn Quốc
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isVi
              ? 'Quản lý danh mục hàng hóa, theo dõi tồn kho 3 miền và lập phiếu điều chuyển nhập/xuất kho.'
              : 'Multi-depot stock governance, product catalog SKU tracking, and inventory movement orders.'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 flex-wrap">
          <button
            onClick={() => openScreenSpec('SCR-INVENTORY')}
            className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] sm:text-xs font-medium border border-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            <FileCode className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="hidden md:inline">{isVi ? 'Đặc tả Màn hình H' : 'Spec Screen H'}</span>
            <span className="md:hidden">Spec H</span>
          </button>

          {canCreate && (
            <>
              <button
                onClick={() => openMovementDialog('Nhập kho')}
                className="flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-[11px] sm:text-xs shadow-xs whitespace-nowrap shrink-0"
              >
                <ArrowDownToLine className="w-3.5 h-3.5 shrink-0" />
                <span className="hidden sm:inline">{t.stockIn}</span>
                <span className="sm:hidden">Nhập</span>
              </button>

              <button
                onClick={() => openMovementDialog('Xuất kho')}
                className="flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-1.5 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-medium text-[11px] sm:text-xs shadow-xs whitespace-nowrap shrink-0"
              >
                <ArrowUpFromLine className="w-3.5 h-3.5 shrink-0" />
                <span className="hidden sm:inline">{t.stockOut}</span>
                <span className="sm:hidden">Xuất</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* 3 Regional Depot Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className={`p-4 rounded-xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow}`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">Kho Hà Nội (Bắc Bộ)</span>
            <Building className="w-4 h-4 text-blue-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-2">
            {totalHanoi} <span className="text-xs font-normal text-slate-400">thiết bị / licenses</span>
          </div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">Sức chứa khả dụng 85%</div>
        </div>

        <div className={`p-4 rounded-xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow}`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">Kho Đà Nẵng (Trung Bộ)</span>
            <Building className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-2">
            {totalDanang} <span className="text-xs font-normal text-slate-400">thiết bị / licenses</span>
          </div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">Sức chứa khả dụng 91%</div>
        </div>

        <div className={`p-4 rounded-xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow}`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase">Kho TP.HCM (Nam Bộ)</span>
            <Building className="w-4 h-4 text-purple-600" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-2">
            {totalHCM} <span className="text-xs font-normal text-slate-400">thiết bị / licenses</span>
          </div>
          <div className="text-[11px] text-emerald-600 font-medium mt-1">Sức chứa khả dụng 78%</div>
        </div>
      </div>

      {/* Tabs: Products Catalog vs Stock Transactions */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('products')}
          className={`px-3 py-1.5 rounded-lg text-[11px] sm:text-xs font-medium transition-all whitespace-nowrap shrink-0 ${
            activeTab === 'products'
              ? 'bg-[#002659] text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <span className="hidden sm:inline">{isVi ? 'Danh mục Sản phẩm & Tồn kho' : 'Product Catalog & Depots'}</span>
          <span className="sm:hidden">{isVi ? 'Sản phẩm' : 'Products'}</span>
        </button>
        <button
          onClick={() => setActiveTab('transactions')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] sm:text-xs font-medium transition-all whitespace-nowrap shrink-0 ${
            activeTab === 'transactions'
              ? 'bg-[#002659] text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <History className="w-3.5 h-3.5 shrink-0" />
          <span className="hidden sm:inline">{t.stockTransactions} ({stockTransactions.length})</span>
          <span className="sm:hidden">Lịch sử ({stockTransactions.length})</span>
        </button>
      </div>

      {activeTab === 'products' ? (
        /* Products Table */
        <div className={`rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} overflow-hidden shadow-xs`}>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead className={`${themeDef.classes.tableHeaderBg} border-b border-slate-200 dark:border-slate-800 font-bold uppercase tracking-wider text-[11px]`}>
                <tr>
                  <th className="py-3.5 px-4 font-mono">{t.sku}</th>
                  <th className="py-3.5 px-4">{t.productName}</th>
                  <th className="py-3.5 px-4">{t.category}</th>
                  <th className="py-3.5 px-4">{t.sellingPrice}</th>
                  <th className="py-3.5 px-4 text-center">{t.stockHn}</th>
                  <th className="py-3.5 px-4 text-center">{t.stockDn}</th>
                  <th className="py-3.5 px-4 text-center">{t.stockHcm}</th>
                  <th className="py-3.5 px-4 text-center font-bold">{t.totalStock}</th>
                  <th className="py-3.5 px-4 whitespace-nowrap">{t.status}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredProducts.map((p) => {
                  const total = p.stockHanoi + p.stockDanang + p.stockHCM;
                  const isLow = total <= p.minSafeStock;

                  return (
                    <tr key={p.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-blue-400">
                        {p.sku}
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-900 dark:text-slate-100">
                        <div>{p.name}</div>
                        <div className="text-[11px] text-slate-400 font-normal">ĐVT: {p.unit}</div>
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                        {p.category}
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100">
                        {formatVND(p.sellingPrice)}
                      </td>
                      <td className="py-3 px-4 text-center font-mono">{p.stockHanoi}</td>
                      <td className="py-3 px-4 text-center font-mono">{p.stockDanang}</td>
                      <td className="py-3 px-4 text-center font-mono">{p.stockHCM}</td>
                      <td className="py-3 px-4 text-center font-mono font-bold text-sm">
                        <span className={isLow ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-slate-100'}>
                          {total}
                        </span>
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        {isLow ? (
                          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-600 dark:text-amber-400 whitespace-nowrap">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 dark:bg-amber-400 shrink-0" />
                            <span>Sắp hết hàng</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 shrink-0" />
                            <span>Đang kinh doanh</span>
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Stock Transactions Log */
        <div className={`rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} overflow-hidden shadow-xs`}>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead className={`${themeDef.classes.tableHeaderBg} border-b border-slate-200 dark:border-slate-800 font-bold uppercase tracking-wider text-[11px]`}>
                <tr>
                  <th className="py-3.5 px-4 font-mono">Mã Phiếu</th>
                  <th className="py-3.5 px-4 whitespace-nowrap">Loại giao dịch</th>
                  <th className="py-3.5 px-4">Kho hàng</th>
                  <th className="py-3.5 px-4">Sản phẩm / SKU</th>
                  <th className="py-3.5 px-4 text-right">Số lượng</th>
                  <th className="py-3.5 px-4">Người thực hiện</th>
                  <th className="py-3.5 px-4">Lý do điều chuyển</th>
                  <th className="py-3.5 px-4 font-mono">Thời gian</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {stockTransactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-mono font-bold text-blue-600 dark:text-blue-400">
                      {tx.txCode}
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span
                        className={`inline-flex items-center gap-1.5 text-xs font-medium whitespace-nowrap ${
                          tx.type === 'Nhập kho'
                            ? 'text-emerald-600 dark:text-emerald-400'
                            : 'text-amber-600 dark:text-amber-400'
                        }`}
                      >
                        <span
                          className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                            tx.type === 'Nhập kho'
                              ? 'bg-emerald-600 dark:bg-emerald-400'
                              : 'bg-amber-500 dark:bg-amber-400'
                          }`}
                        />
                        <span>{tx.type}</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800 dark:text-slate-200">
                      {tx.warehouse}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900 dark:text-slate-100">{tx.productName}</div>
                      <div className="text-[10px] font-mono text-slate-400">{tx.sku}</div>
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-sm">
                      {tx.type === 'Nhập kho' ? '+' : '-'}{tx.quantity} {tx.unit}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">{tx.performedBy}</td>
                    <td className="py-3 px-4 text-slate-500 max-w-xs truncate">{tx.reason}</td>
                    <td className="py-3 px-4 font-mono text-slate-400">{tx.createdAt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Inward / Outward Movement */}
      {isMovementModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                {movementType === 'Nhập kho' ? (
                  <ArrowDownToLine className="w-5 h-5 text-emerald-600" />
                ) : (
                  <ArrowUpFromLine className="w-5 h-5 text-amber-600" />
                )}
                <span>Lập Phiếu {movementType}</span>
              </h3>
              <button onClick={() => setIsMovementModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleMovementSubmit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Chọn Sản phẩm / SKU *</label>
                <select
                  value={selectedProductId}
                  onChange={(e) => setSelectedProductId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                >
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.sku} - {p.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Kho tiếp nhận / xuất *</label>
                  <select
                    value={selectedWarehouse}
                    onChange={(e) => setSelectedWarehouse(e.target.value as InventoryTransaction['warehouse'])}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="Kho Hà Nội">Kho Hà Nội</option>
                    <option value="Kho Đà Nẵng">Kho Đà Nẵng</option>
                    <option value="Kho TP.HCM">Kho TP.HCM</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Số lượng *</label>
                  <input
                    type="number"
                    min="1"
                    value={movementQty}
                    onChange={(e) => setMovementQty(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold mb-1">Lý do điều chuyển / Ghi chú</label>
                <textarea
                  rows={2}
                  value={movementReason}
                  onChange={(e) => setMovementReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsMovementModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-white font-bold ${
                    movementType === 'Nhập kho' ? 'bg-emerald-600 hover:bg-emerald-700' : 'bg-amber-600 hover:bg-amber-700'
                  }`}
                >
                  Xác nhận Lập Phiếu
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
