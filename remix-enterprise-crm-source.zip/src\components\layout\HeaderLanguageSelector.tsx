/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * A+ CRM — HEADER LANGUAGE SELECTOR WITH FULL-PAGE AUTO TRANSLATION
 * Tích hợp công cụ dịch tự động toàn trang (Google Translate Engine):
 * Cho phép dịch tức thì toàn bộ nội dung trong giao diện (Menu, Bảng dữ liệu, Thẻ chỉ số, Modal)
 * mà không cần viết thủ công từ điển từng ngôn ngữ.
 */

import React, { useState, useRef, useEffect } from 'react';
import { useCRM } from '../../context/CRMContext';
import { Globe, Check, ChevronDown, RefreshCw } from 'lucide-react';
import {
  SUPPORTED_LANGUAGES,
  SupportedLanguage,
  triggerFullPageTranslation,
  getActiveGoogleTranslateLang,
} from '../../utils/googleTranslate';

export const HeaderLanguageSelector: React.FC = () => {
  const { language, setLanguage, showToast } = useCRM();
  const [isOpen, setIsOpen] = useState(false);
  const [activeCode, setActiveCode] = useState<string>(() => {
    return getActiveGoogleTranslateLang() || language || 'vi';
  });
  const [isTranslating, setIsTranslating] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Sync active code from cookie
  useEffect(() => {
    const currentFromCookie = getActiveGoogleTranslateLang();
    if (currentFromCookie && currentFromCookie !== activeCode) {
      setActiveCode(currentFromCookie);
    }
  }, []);

  // Close when clicking outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const currentLang =
    SUPPORTED_LANGUAGES.find((l) => l.code === activeCode) ||
    SUPPORTED_LANGUAGES.find((l) => l.crmCode === language) ||
    SUPPORTED_LANGUAGES[0];

  const handleSelectLanguage = (lang: SupportedLanguage) => {
    setActiveCode(lang.code);
    setIsOpen(false);
    setIsTranslating(true);

    if (lang.crmCode) {
      setLanguage(lang.crmCode);
    }

    // Trigger full page auto translation
    triggerFullPageTranslation(lang.code);

    if (lang.code === 'vi') {
      showToast(
        'Ngôn ngữ gốc',
        'Đã khôi phục hiển thị Tiếng Việt nguyên bản toàn trang.',
        'info'
      );
    } else {
      showToast(
        'Dịch toàn trang',
        `Đang chuyển đổi và dịch toàn bộ nội dung trang sang ${lang.label} (${lang.flag})...`,
        'success'
      );
    }

    setTimeout(() => {
      setIsTranslating(false);
    }, 800);
  };

  return (
    <div className="relative shrink-0" ref={dropdownRef}>
      {/* Trigger Button */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className={`h-9 px-2.5 rounded-xl border flex items-center gap-1.5 transition-all cursor-pointer text-xs font-semibold select-none ${
          isOpen
            ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-400 dark:border-blue-600 text-blue-600 dark:text-blue-400 shadow-xs'
            : 'bg-white/90 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/80 text-blue-600 dark:text-blue-400 hover:bg-slate-50 dark:hover:bg-slate-750 hover:border-blue-300 dark:hover:border-slate-600'
        }`}
        title="Dịch toàn trang sang ngôn ngữ khác (Auto Translation)"
        aria-label="Chọn ngôn ngữ hiển thị"
      >
        {isTranslating ? (
          <RefreshCw className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 animate-spin" />
        ) : (
          <Globe className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
        )}
        <span className="font-bold tracking-wide">{currentLang.shortLabel}</span>
        <ChevronDown
          className={`w-3 h-3 text-slate-400 transition-transform duration-200 ${
            isOpen ? 'rotate-180 text-blue-600 dark:text-blue-400' : ''
          }`}
        />
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 mt-1.5 w-56 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-xl z-50 py-1 animate-in fade-in slide-in-from-top-1 duration-150 overflow-hidden">
          <div className="max-h-80 overflow-y-auto p-1 space-y-0.5 scrollbar-thin">
            {SUPPORTED_LANGUAGES.map((lang) => {
              const isSelected = lang.code === activeCode;
              return (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => handleSelectLanguage(lang)}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-xl text-xs font-medium transition-colors cursor-pointer text-left ${
                    isSelected
                      ? 'bg-blue-50 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300 font-semibold'
                      : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100/80 dark:hover:bg-slate-800'
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-base shrink-0 leading-none">{lang.flag}</span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="block text-xs truncate leading-tight font-medium">
                          {lang.label}
                        </span>
                        {lang.code === 'vi' && (
                          <span className="text-[9px] px-1 py-0.2 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                            Gốc
                          </span>
                        )}
                      </div>
                      <span className="block text-[10px] text-slate-400 dark:text-slate-500 truncate mt-0.5">
                        {lang.nativeName}
                      </span>
                    </div>
                  </div>

                  {isSelected && (
                    <Check className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 ml-2" />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
