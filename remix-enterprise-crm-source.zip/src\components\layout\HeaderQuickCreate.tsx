import React, { useState, useRef, useEffect } from 'react';
import { useCRM } from '../../context/CRMContext';
import { ActiveModule } from '../../types/crm';
import {
  Plus,
  ChevronDown,
  Target,
  Users,
  Briefcase,
  FileSpreadsheet,
  ShoppingCart,
  Calendar,
  ArrowDownRight,
  ArrowUpRight,
  FileText,
  CreditCard,
  Wrench,
  ShieldAlert,
  UserPlus,
} from 'lucide-react';

interface QuickCreateOption {
  id: string;
  label: string;
  module: ActiveModule;
  icon: React.ComponentType<{ className?: string }>;
}

interface QuickCreateGroup {
  groupName: string;
  items: QuickCreateOption[];
}

export const HeaderQuickCreate: React.FC = () => {
  const { hasPermission, setActiveModule, setCurrentDocCode, language } = useCRM();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  const rawGroups: QuickCreateGroup[] = [
    {
      groupName: language === 'vi' ? 'Quản lý Sales' : language === 'ja' ? '営業管理' : 'Sales Management',
      items: [
        { id: 'lead', label: language === 'vi' ? 'Lead tiềm năng' : language === 'ja' ? '見込み顧客' : 'Lead', module: 'leads', icon: Target },
        { id: 'customer', label: language === 'vi' ? 'Khách hàng' : language === 'ja' ? '顧客' : 'Customer', module: 'customers', icon: Users },
        { id: 'opportunity', label: language === 'vi' ? 'Cơ hội bán hàng' : language === 'ja' ? '商談案件' : 'Opportunity', module: 'opportunities', icon: Briefcase },
        { id: 'quotation', label: language === 'vi' ? 'Báo giá & Đề xuất' : language === 'ja' ? '見積書' : 'Quotation', module: 'quotations', icon: FileSpreadsheet },
        { id: 'order', label: language === 'vi' ? 'Đơn hàng' : language === 'ja' ? '受注' : 'Sales Order', module: 'sales-orders', icon: ShoppingCart },
        { id: 'activity', label: language === 'vi' ? 'Hoạt động / Lịch hẹn' : language === 'ja' ? '活動・予定' : 'Activity / Event', module: 'sales-activities', icon: Calendar },
      ],
    },
    {
      groupName: language === 'vi' ? 'Kho & Vận chuyển' : language === 'ja' ? '在庫・配送' : 'Warehouse & Logistics',
      items: [
        { id: 'stock-in', label: language === 'vi' ? 'Phiếu nhập kho' : language === 'ja' ? '入庫伝票' : 'Stock In Note', module: 'inventory-stock-in', icon: ArrowDownRight },
        { id: 'stock-out', label: language === 'vi' ? 'Phiếu xuất kho' : language === 'ja' ? '出庫伝票' : 'Stock Out Note', module: 'inventory-stock-out', icon: ArrowUpRight },
        { id: 'purchase-order', label: language === 'vi' ? 'Đơn mua hàng' : language === 'ja' ? '発注書' : 'Purchase Order', module: 'logistics-purchase-orders', icon: FileText },
        { id: 'payment-request', label: language === 'vi' ? 'Đề nghị thanh toán' : language === 'ja' ? '支払申請' : 'Payment Request', module: 'logistics-payment-requests', icon: CreditCard },
      ],
    },
    {
      groupName: language === 'vi' ? 'Kỹ thuật & Bảo hành' : language === 'ja' ? '技術・保証' : 'Technical & Warranty',
      items: [
        { id: 'tech-request', label: language === 'vi' ? 'Yêu cầu kỹ thuật' : language === 'ja' ? '技術依頼' : 'Technical Request', module: 'technical-quotations', icon: Wrench },
        { id: 'warranty-request', label: language === 'vi' ? 'Yêu cầu bảo hành' : language === 'ja' ? '保証依頼' : 'Warranty Request', module: 'technical-warranty-stock-out', icon: ShieldAlert },
      ],
    },
    {
      groupName: language === 'vi' ? 'Quản lý Nhân sự' : language === 'ja' ? '人事管理' : 'Human Resources',
      items: [
        { id: 'employee', label: language === 'vi' ? 'Nhân viên mới' : language === 'ja' ? '新規社員' : 'New Employee', module: 'hr-staff', icon: UserPlus },
      ],
    },
  ];

  // Filter groups and items strictly according to user's 'create' permission
  const authorizedGroups = rawGroups
    .map((grp) => ({
      ...grp,
      items: grp.items.filter((item) => hasPermission(item.module, 'create')),
    }))
    .filter((grp) => grp.items.length > 0);

  const handleSelectOption = (opt: QuickCreateOption) => {
    setCurrentDocCode(null);
    setActiveModule(opt.module);
    setIsOpen(false);
    // Dispatch quick create event for any views listening
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('crm:quick-create', { detail: { target: opt.id, module: opt.module } })
      );
    }
  };

  return (
    <div className="relative shrink-0" ref={dropdownRef}>
      {/* Button: Desktop has "+ Tạo mới", Mobile only "+" */}
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] dark:bg-sky-600 dark:hover:bg-sky-500 text-white text-xs font-semibold shadow-xs transition-colors cursor-pointer shrink-0"
        title={language === 'vi' ? 'Tạo mới chứng từ / đối tượng' : language === 'ja' ? '伝票・レコード新規作成' : 'Quick Create Record'}
        aria-label={language === 'vi' ? 'Tạo mới' : language === 'ja' ? '新規作成' : 'Create New'}
      >
        <Plus className="w-3.5 h-3.5 stroke-[2.5]" />
        <span className="hidden sm:inline">
          {language === 'vi' ? 'Tạo mới' : language === 'ja' ? '新規作成' : 'Create'}
        </span>
        <ChevronDown className="hidden sm:inline w-3 h-3 opacity-80" />
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute right-0 sm:right-auto sm:left-0 mt-1.5 w-72 sm:w-80 max-h-[460px] overflow-y-auto bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl p-2 z-50 animate-in fade-in duration-100 divide-y divide-slate-100 dark:divide-slate-800">
          {authorizedGroups.length > 0 ? (
            authorizedGroups.map((grp) => (
              <div key={grp.groupName} className="py-1.5 first:pt-0 last:pb-0">
                <div className="px-2.5 py-1 text-[10px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                  {grp.groupName}
                </div>
                <div className="space-y-0.5">
                  {grp.items.map((item) => {
                    const IconComp = item.icon;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        onClick={() => handleSelectOption(item)}
                        className="w-full text-left px-2.5 py-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-2.5 text-xs text-slate-700 dark:text-slate-200 hover:text-[#002659] dark:hover:text-sky-300 transition-colors cursor-pointer"
                      >
                        <IconComp className="w-4 h-4 text-[#002659] dark:text-sky-400 shrink-0" />
                        <span className="font-medium">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            ))
          ) : (
            <div className="p-4 text-center text-xs text-slate-400">
              {language === 'vi'
                ? 'Bạn không có quyền tạo mới trên các phân hệ.'
                : language === 'ja'
                ? '新規作成権限がありません。'
                : 'You do not have create permissions for any module.'}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
