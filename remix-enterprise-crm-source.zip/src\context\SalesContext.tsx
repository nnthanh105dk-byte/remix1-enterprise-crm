import React, { createContext, useContext, useState } from 'react';
import {
  SalesLead,
  CustomerAccount,
  CustomerContactPerson,
  SalesOpportunity,
  SalesQuotation,
  SalesOrder,
  SalesContract,
  SalesInvoice,
  SalesReceipt,
  SalesActivity,
  OpportunityStageName,
  DocumentChainInfo,
} from '../types/sales';
import {
  INITIAL_CUSTOMERS,
  INITIAL_SALES_LEADS,
  INITIAL_SALES_OPPORTUNITIES,
  INITIAL_SALES_QUOTATIONS,
  INITIAL_SALES_ORDERS,
  INITIAL_SALES_CONTRACTS,
  INITIAL_SALES_INVOICES,
  INITIAL_SALES_RECEIPTS,
  INITIAL_SALES_ACTIVITIES,
} from '../data/mockSalesData';
import { useCRM } from './CRMContext';
import { numberToVietnameseWords } from '../utils/vietnameseNumberWords';
import { INITIAL_WAREHOUSE_PRODUCTS } from '../data/mockWarehouseData';

interface SalesContextType {
  // State
  leads: SalesLead[];
  customers: CustomerAccount[];
  opportunities: SalesOpportunity[];
  quotations: SalesQuotation[];
  orders: SalesOrder[];
  contracts: SalesContract[];
  invoices: SalesInvoice[];
  setInvoices: React.Dispatch<React.SetStateAction<SalesInvoice[]>>;
  receipts: SalesReceipt[];
  activities: SalesActivity[];

  // 1. Leads
  addLead: (lead: Omit<SalesLead, 'id' | 'code' | 'createdAt'>) => SalesLead;
  updateLead: (id: string, updates: Partial<SalesLead>) => void;
  deleteLead: (id: string) => void;
  distributeLeads: (leadIds: string[], assignedTo: string) => void;
  recordContactAttempt: (leadId: string, notes?: string) => void;
  convertLead: (
    leadId: string,
    existingCustomerId?: string,
    customData?: {
      companyName?: string;
      taxId?: string;
      contactName?: string;
      dealTitle?: string;
      dealAmount?: number;
      expectedCloseDate?: string;
    }
  ) => { customer: CustomerAccount; opportunity: SalesOpportunity };

  // 2. Customers
  addCustomer: (customer: Omit<CustomerAccount, 'id' | 'code' | 'createdAt' | 'totalRevenue' | 'currentDebt' | 'openDealsCount'>) => CustomerAccount;
  updateCustomer: (id: string, updates: Partial<CustomerAccount>) => void;
  deleteCustomer: (id: string) => void;

  // 3. Opportunities
  addOpportunity: (opp: Omit<SalesOpportunity, 'id' | 'code' | 'createdAt' | 'chain'>) => SalesOpportunity;
  updateOpportunity: (id: string, updates: Partial<SalesOpportunity>) => void;
  updateOpportunityStage: (
    id: string,
    stage: OpportunityStageName,
    lostReason?: 'Giá cao' | 'Đối thủ' | 'Chưa có ngân sách' | 'Không phản hồi' | 'Khác',
    competitorName?: string
  ) => boolean;
  deleteOpportunity: (id: string) => void;

  // 4. Quotations
  createQuotation: (quote: Omit<SalesQuotation, 'id' | 'code' | 'version' | 'isLatestVersion' | 'amountInWords' | 'subTotal' | 'discountAmountTotal' | 'taxAmount' | 'grandTotal' | 'createdAt' | 'chain'>) => SalesQuotation;
  duplicateQuotationVersion: (quotationId: string) => SalesQuotation;
  updateQuotationStatus: (id: string, status: SalesQuotation['status']) => void;

  // 5. Orders & Approvals
  createOrderFromQuotation: (quotationId: string) => SalesOrder;
  approveOrder: (orderId: string, approverName: string) => void;
  rejectOrder: (orderId: string, reason: string) => void;
  updateOrder: (id: string, updates: Partial<SalesOrder>) => void;

  // 6. Contracts
  createContractFromOrder: (orderId: string, startDate?: string, endDate?: string) => SalesContract;
  updateContractStatus: (contractId: string, status: SalesContract['status']) => void;
  updateContract: (contractId: string, updates: Partial<SalesContract>) => void;
  submitContractForApproval: (contractId: string) => void;
  approveContract: (contractId: string, approvedBy?: string) => void;
  signContractAndCollectDeposit: (
    contractId: string,
    depositAmount: number,
    paymentMethod?: 'Chuyển khoản' | 'Tiền mặt' | 'Khác',
    bankRefNumber?: string
  ) => SalesReceipt;

  // 7. Invoices
  createInvoiceFromMilestone: (contractId: string, milestoneId: string) => SalesInvoice;
  createInvoiceFromOrder: (orderId: string) => SalesInvoice;
  sendInvoicePaymentReminder: (invoiceId: string) => void;

  // 8. Receipts
  createReceiptFromInvoice: (
    invoiceId: string,
    amount: number,
    paymentMethod: 'Chuyển khoản' | 'Tiền mặt' | 'Khác',
    bankRefNumber: string,
    reason: string,
    payerName: string
  ) => SalesReceipt;
  addDirectReceipt: (receipt: Omit<SalesReceipt, 'id' | 'createdAt'>) => SalesReceipt;
  cancelReceipt: (receiptId: string, reason: string) => void;

  // 9. Activities
  addActivity: (activity: Omit<SalesActivity, 'id' | 'code' | 'createdAt' | 'isCompleted'>) => SalesActivity;
  completeActivity: (id: string, nextStepPrompt?: string) => void;
}

const SalesContext = createContext<SalesContextType | undefined>(undefined);

export const SalesProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { showToast, setActiveModule, addNotification } = useCRM();

  const [leads, setLeads] = useState<SalesLead[]>(INITIAL_SALES_LEADS);
  const [customers, setCustomers] = useState<CustomerAccount[]>(INITIAL_CUSTOMERS);
  const [opportunities, setOpportunities] = useState<SalesOpportunity[]>(INITIAL_SALES_OPPORTUNITIES);
  const [quotations, setQuotations] = useState<SalesQuotation[]>(INITIAL_SALES_QUOTATIONS);
  const [orders, setOrders] = useState<SalesOrder[]>(INITIAL_SALES_ORDERS);
  const [contracts, setContracts] = useState<SalesContract[]>(INITIAL_SALES_CONTRACTS);
  const [invoices, setInvoices] = useState<SalesInvoice[]>(INITIAL_SALES_INVOICES);
  const [receipts, setReceipts] = useState<SalesReceipt[]>(INITIAL_SALES_RECEIPTS);
  const [activities, setActivities] = useState<SalesActivity[]>(INITIAL_SALES_ACTIVITIES);

  // Helper check duplicate Lead or Customer
  const checkDuplicateLead = (phone: string, email: string, excludeId?: string) => {
    const dupLead = leads.find((l) => l.id !== excludeId && (l.phone === phone || l.email.toLowerCase() === email.toLowerCase()));
    const dupCust = customers.find((c) => c.phone === phone || c.email.toLowerCase() === email.toLowerCase());
    return { dupLead, dupCust };
  };

  // 1. LEAD ACTIONS
  const addLead = (leadData: Omit<SalesLead, 'id' | 'code' | 'createdAt'>): SalesLead => {
    const { dupLead, dupCust } = checkDuplicateLead(leadData.phone, leadData.email);
    if (dupCust) {
      showToast('Cảnh báo trùng khách hàng', `Số điện thoại/Email trùng với khách hàng đã có: ${dupCust.name}`, 'info');
    } else if (dupLead) {
      showToast('Cảnh báo trùng Lead', `Số điện thoại/Email trùng với Lead đã có: ${dupLead.fullName}`, 'info');
    }

    const id = `lead-${Date.now()}`;
    const code = `LEAD-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const newLead: SalesLead = {
      ...leadData,
      id,
      code,
      createdAt: now,
    };
    setLeads((prev) => [newLead, ...prev]);
    showToast('Tạo Lead thành công', `Đã thêm lead ${newLead.code}: ${newLead.fullName}`);
    return newLead;
  };

  const updateLead = (id: string, updates: Partial<SalesLead>) => {
    setLeads((prev) => prev.map((l) => (l.id === id ? { ...l, ...updates } : l)));
    showToast('Cập nhật thành công', 'Đã lưu thay đổi thông tin Lead.');
  };

  const deleteLead = (id: string) => {
    setLeads((prev) => prev.filter((l) => l.id !== id));
    showToast('Đã xóa Lead', 'Bản ghi lead đã được gỡ khỏi danh sách.');
  };

  // Leader phân bổ Lead cho nhân viên -> Bắn thông báo ngay lập tức
  const distributeLeads = (leadIds: string[], assignedTo: string) => {
    const targetLeads = leads.filter((l) => leadIds.includes(l.id));
    setLeads((prev) =>
      prev.map((l) => (leadIds.includes(l.id) ? { ...l, assignedTo, lastContactedAt: undefined } : l))
    );

    targetLeads.forEach((l) => {
      addNotification({
        title: 'Phân bổ Lead mới (Ưu tiên gọi trong 4h)',
        message: `Leader đã phân bổ cho bạn Lead ${l.code} (${l.fullName} - ${l.company || 'Cá nhân'}). SĐT: ${l.phone}. Vui lòng liên hệ sớm!`,
        type: 'lead',
        linkModule: 'sales-leads',
        entityId: l.id,
        senderName: 'Trưởng phòng Kinh doanh',
      });
    });

    showToast('Phân bổ thành công', `Đã chuyển ${leadIds.length} lead cho nhân viên ${assignedTo}.`);
  };

  // Nhân viên thực hiện thao tác gọi / liên hệ với Lead -> Cập nhật trạng thái & lưu log hoạt động
  const recordContactAttempt = (leadId: string, notes?: string) => {
    const lead = leads.find((l) => l.id === leadId);
    if (!lead) return;
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    setLeads((prev) =>
      prev.map((l) =>
        l.id === leadId
          ? {
              ...l,
              status: l.status === 'Mới' ? 'Đang liên hệ' : l.status,
              lastContactedAt: nowStr,
              notes: notes ? `${l.notes}\n[${nowStr}] ${notes}` : l.notes,
            }
          : l
      )
    );

    const actId = `act-${Date.now()}`;
    const newAct: SalesActivity = {
      id: actId,
      code: `ACT-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      type: 'Cuộc gọi',
      title: `Gọi điện tư vấn giải pháp Web & SaaS cho ${lead.fullName}`,
      description: notes || `Đã gọi điện trao đổi nhu cầu phát triển Website & Nền tảng SaaS A+ Cloud với đại diện ${lead.company || lead.fullName}. Hẹn gửi demo trực tuyến.`,
      targetType: 'lead',
      targetId: lead.id,
      targetCode: lead.code,
      targetName: `${lead.fullName} (${lead.company || 'Cá nhân'})`,
      startTime: nowStr,
      priority: 'Trung bình',
      assignedTo: lead.assignedTo,
      isCompleted: true,
      completedAt: nowStr,
      nextStepPrompt: 'Kỹ thuật khởi tạo môi trường Demo Staging và liên hệ hướng dẫn trải nghiệm',
      createdAt: nowStr,
    };
    setActivities((prev) => [newAct, ...prev]);

    showToast('Ghi nhận liên hệ thành công', `Đã cập nhật liên hệ cho Lead ${lead.code}. Trạng thái chuyển sang Đang liên hệ.`);
  };

  // Nút "Chuyển đổi": 1 bước tạo ra Khách hàng + Người liên hệ + Cơ hội
  const convertLead = (
    leadId: string,
    existingCustomerId?: string,
    customData?: {
      companyName?: string;
      taxId?: string;
      contactName?: string;
      dealTitle?: string;
      dealAmount?: number;
      expectedCloseDate?: string;
    }
  ) => {
    const lead = leads.find((l) => l.id === leadId);
    if (!lead) throw new Error('Lead không tồn tại');

    let targetCustomer: CustomerAccount;

    if (existingCustomerId) {
      const found = customers.find((c) => c.id === existingCustomerId);
      if (!found) throw new Error('Khách hàng không tồn tại');
      targetCustomer = found;
    } else {
      // Tạo Khách hàng mới
      const custId = `cust-${Date.now()}`;
      const custCode = `KH-${Math.floor(1000 + Math.random() * 9000)}`;
      const contactPersonId = `cp-${Date.now()}`;
      const newContact: CustomerContactPerson = {
        id: contactPersonId,
        fullName: customData?.contactName || lead.fullName,
        role: 'Người ra quyết định',
        phone: lead.phone,
        email: lead.email,
        isPrimary: true,
        isDecisionMaker: true,
      };

      targetCustomer = {
        id: custId,
        code: custCode,
        name: customData?.companyName || lead.company || lead.fullName,
        type: lead.company ? 'Doanh nghiệp' : 'Cá nhân',
        taxId: customData?.taxId || `010${Math.floor(1000000 + Math.random() * 9000000)}`,
        phone: lead.phone,
        email: lead.email,
        industry: 'Thương mại & Dịch vụ',
        group: 'Tiềm năng',
        assignedTo: lead.assignedTo,
        totalRevenue: 0,
        currentDebt: 0,
        billingAddress: 'Việt Nam',
        shippingAddresses: ['Việt Nam'],
        contacts: [newContact],
        openDealsCount: 1,
        notes: `Chuyển đổi từ Lead ${lead.code}: ${lead.notes}`,
        createdAt: new Date().toISOString().split('T')[0],
      };

      setCustomers((prev) => [targetCustomer, ...prev]);
    }

    // Tạo Cơ hội mới (Opportunity)
    const oppId = `opp-${Date.now()}`;
    const oppCode = `CH-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOpportunity: SalesOpportunity = {
      id: oppId,
      code: oppCode,
      title: customData?.dealTitle || `Dự án Cung cấp Giải pháp - ${targetCustomer.name}`,
      customerId: targetCustomer.id,
      customerCode: targetCustomer.code,
      customerName: targetCustomer.name,
      contactName: customData?.contactName || lead.fullName,
      amount: customData?.dealAmount || lead.estimatedValue || 350000000,
      stage: 'Khám phá nhu cầu',
      probability: 20,
      expectedCloseDate:
        customData?.expectedCloseDate ||
        new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      leadSource: lead.source,
      interestedProducts: ['HW-SRV-DL380', 'HW-SW-CISCO-9300'],
      assignedTo: lead.assignedTo,
      nextStep: 'Liên hệ khảo sát nhu cầu chi tiết và gửi hồ sơ kỹ thuật',
      nextStepDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      lastActivityDate: new Date().toISOString().split('T')[0],
      chain: {
        leadId: lead.id,
        leadCode: lead.code,
        customerId: targetCustomer.id,
        customerCode: targetCustomer.code,
        customerName: targetCustomer.name,
        opportunityId: oppId,
        opportunityCode: oppCode,
      },
      createdAt: new Date().toISOString().split('T')[0],
    };

    setOpportunities((prev) => [newOpportunity, ...prev]);

    // Cập nhật Lead sang trạng thái 'Đủ điều kiện' và liên kết
    setLeads((prev) =>
      prev.map((l) =>
        l.id === leadId
          ? {
              ...l,
              status: 'Đủ điều kiện',
              convertedTo: {
                customerId: targetCustomer.id,
                contactId: targetCustomer.contacts[0]?.id || '',
                opportunityId: oppId,
                convertedAt: new Date().toISOString(),
              },
            }
          : l
      )
    );

    showToast(
      'Chuyển đổi thành công!',
      `Đã tạo Khách hàng ${targetCustomer.code} và Cơ hội ${newOpportunity.code}.`
    );

    return { customer: targetCustomer, opportunity: newOpportunity };
  };

  // 2. CUSTOMERS ACTIONS
  const addCustomer = (customerData: Omit<CustomerAccount, 'id' | 'code' | 'createdAt' | 'totalRevenue' | 'currentDebt' | 'openDealsCount'>): CustomerAccount => {
    const id = `cust-${Date.now()}`;
    const code = `KH-${Math.floor(1000 + Math.random() * 9000)}`;
    const newCust: CustomerAccount = {
      ...customerData,
      id,
      code,
      totalRevenue: 0,
      currentDebt: 0,
      openDealsCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setCustomers((prev) => [newCust, ...prev]);
    showToast('Tạo Khách hàng thành công', `Đã thêm khách hàng ${newCust.code}: ${newCust.name}`);
    return newCust;
  };

  const updateCustomer = (id: string, updates: Partial<CustomerAccount>) => {
    setCustomers((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
    showToast('Cập nhật thành công', 'Thông tin khách hàng đã được lưu.');
  };

  const deleteCustomer = (id: string) => {
    setCustomers((prev) => prev.filter((c) => c.id !== id));
    showToast('Đã xóa Khách hàng', 'Bản ghi khách hàng đã được gỡ bỏ.');
  };

  // 3. OPPORTUNITIES ACTIONS
  const addOpportunity = (oppData: Omit<SalesOpportunity, 'id' | 'code' | 'createdAt' | 'chain'>): SalesOpportunity => {
    const id = `opp-${Date.now()}`;
    const code = `CH-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newOpp: SalesOpportunity = {
      ...oppData,
      id,
      code,
      chain: {
        customerId: oppData.customerId,
        customerCode: oppData.customerCode,
        customerName: oppData.customerName,
        opportunityId: id,
        opportunityCode: code,
      },
      createdAt: new Date().toISOString().split('T')[0],
    };
    setOpportunities((prev) => [newOpp, ...prev]);
    showToast('Tạo Cơ hội thành công', `Đã thêm cơ hội ${newOpp.code}: ${newOpp.title}`);
    return newOpp;
  };

  const updateOpportunity = (id: string, updates: Partial<SalesOpportunity>) => {
    setOpportunities((prev) =>
      prev.map((o) =>
        o.id === id
          ? { ...o, ...updates, lastActivityDate: new Date().toISOString().split('T')[0] }
          : o
      )
    );
  };

  const updateOpportunityStage = (
    id: string,
    stage: OpportunityStageName,
    lostReason?: 'Giá cao' | 'Đối thủ' | 'Chưa có ngân sách' | 'Không phản hồi' | 'Khác',
    competitorName?: string
  ): boolean => {
    const opp = opportunities.find((o) => o.id === id);
    if (!opp) return false;

    // Rule 1: Chuyển sang "Đàm phán" phải có ít nhất 1 báo giá
    if (stage === 'Đàm phán') {
      const hasQuote = quotations.some((q) => q.opportunityId === id || q.opportunityCode === opp.code);
      if (!hasQuote) {
        showToast(
          'Yêu cầu Báo giá',
          'Cơ hội chuyển sang Đàm phán bắt buộc phải lập ít nhất 1 bản Báo giá trước.',
          'warning'
        );
        return false;
      }
    }

    // Rule 2: Chuyển sang "Thất bại" bắt buộc có lý do
    if (stage === 'Thất bại (Lost)' && !lostReason) {
      showToast('Yêu cầu Lý do thất bại', 'Vui lòng cung cấp lý do thua deal để phục vụ báo cáo.', 'warning');
      return false;
    }

    const probMap: Record<OpportunityStageName, number> = {
      'Khám phá nhu cầu': 20,
      'Báo giá & Đề xuất': 40,
      'Đàm phán': 70,
      'Thành công (Won)': 100,
      'Thất bại (Lost)': 0,
    };

    setOpportunities((prev) =>
      prev.map((o) => {
        if (o.id !== id) return o;
        return {
          ...o,
          stage,
          probability: probMap[stage],
          lostReason: stage === 'Thất bại (Lost)' ? lostReason : undefined,
          competitorName: stage === 'Thất bại (Lost)' ? competitorName : undefined,
          lastActivityDate: new Date().toISOString().split('T')[0],
        };
      })
    );

    // Rule 3: Chuyển sang "Thắng" hiển thị gợi ý tạo đơn hàng ngay
    if (stage === 'Thành công (Won)') {
      showToast('Chúc mừng Thắng Deal!', `Deal ${opp.code} đã Thắng! Bạn có thể Tạo Đơn Hàng ngay bây giờ.`, 'success');
    } else {
      showToast('Cập nhật giai đoạn', `Cơ hội ${opp.code} đã chuyển sang "${stage}" (${probMap[stage]}%).`);
    }

    return true;
  };

  const deleteOpportunity = (id: string) => {
    setOpportunities((prev) => prev.filter((o) => o.id !== id));
    showToast('Đã xóa Cơ hội', 'Bản ghi cơ hội đã được gỡ bỏ.');
  };

  // 4. QUOTATIONS ACTIONS
  const createQuotation = (
    quoteData: Omit<
      SalesQuotation,
      'id' | 'code' | 'version' | 'isLatestVersion' | 'amountInWords' | 'subTotal' | 'discountAmountTotal' | 'taxAmount' | 'grandTotal' | 'createdAt' | 'chain'
    >
  ): SalesQuotation => {
    const id = `quote-${Date.now()}`;
    const code = `BG-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const subTotal = quoteData.items.reduce((sum, item) => sum + item.total, 0);
    const discountAmountTotal = Math.round(subTotal * (quoteData.discountPercentTotal / 100));
    const afterDiscount = subTotal - discountAmountTotal;
    const taxAmount = Math.round(afterDiscount * (quoteData.taxRate / 100));
    const grandTotal = afterDiscount + taxAmount;
    const amountInWords = numberToVietnameseWords(grandTotal);

    // Chiết khấu > 5% cần Trưởng nhóm, > 10% cần Giám đốc
    let requiresApproval = false;
    let approvalRequiredBy: 'Trưởng nhóm' | 'Giám đốc' | undefined;
    let initialStatus = quoteData.status;

    if (quoteData.discountPercentTotal > 10) {
      requiresApproval = true;
      approvalRequiredBy = 'Giám đốc';
      initialStatus = 'Chờ duyệt';
    } else if (quoteData.discountPercentTotal > 5) {
      requiresApproval = true;
      approvalRequiredBy = 'Trưởng nhóm';
      initialStatus = 'Chờ duyệt';
    }

    const newQuotation: SalesQuotation = {
      ...quoteData,
      id,
      code,
      version: 1,
      isLatestVersion: true,
      subTotal,
      discountAmountTotal,
      taxAmount,
      grandTotal,
      amountInWords,
      status: initialStatus,
      requiresApproval,
      approvalRequiredBy,
      chain: {
        customerId: quoteData.customerId,
        customerCode: quoteData.customerCode,
        customerName: quoteData.customerName,
        opportunityId: quoteData.opportunityId,
        opportunityCode: quoteData.opportunityCode,
        quotationId: id,
        quotationCode: code,
      },
      createdAt: new Date().toISOString().split('T')[0],
    };

    setQuotations((prev) => [newQuotation, ...prev]);

    // Tự động liên kết ngược vào Opportunity nếu có
    if (quoteData.opportunityId) {
      setOpportunities((prev) =>
        prev.map((o) =>
          o.id === quoteData.opportunityId
            ? {
                ...o,
                chain: { ...o.chain, quotationId: id, quotationCode: code },
                lastActivityDate: new Date().toISOString().split('T')[0],
              }
            : o
        )
      );
    }

    showToast('Tạo Báo giá thành công', `Đã lập báo giá ${newQuotation.code} (${newQuotation.status}).`);
    return newQuotation;
  };

  const duplicateQuotationVersion = (quotationId: string): SalesQuotation => {
    const parent = quotations.find((q) => q.id === quotationId);
    if (!parent) throw new Error('Báo giá không tồn tại');

    const nextVer = parent.version + 1;
    const newId = `quote-${Date.now()}`;
    const newCode = `${parent.code.split('-v')[0]}-v${nextVer}`;

    // Đánh dấu bản cũ không còn là bản mới nhất
    setQuotations((prev) =>
      prev.map((q) => (q.id === quotationId ? { ...q, isLatestVersion: false } : q))
    );

    const duplicated: SalesQuotation = {
      ...parent,
      id: newId,
      code: newCode,
      version: nextVer,
      isLatestVersion: true,
      parentQuotationCode: parent.code,
      status: 'Nháp',
      title: `${parent.title} (v${nextVer})`,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setQuotations((prev) => [duplicated, ...prev]);
    showToast('Nhân bản phiên bản mới', `Đã tạo phiên bản báo giá ${duplicated.code}`);
    return duplicated;
  };

  const updateQuotationStatus = (id: string, status: SalesQuotation['status']) => {
    const quote = quotations.find((q) => q.id === id);
    if (!quote) return;

    setQuotations((prev) => prev.map((q) => (q.id === id ? { ...q, status } : q)));

    // Khi chuyển sang "Chấp nhận": cơ hội liên quan tự chuyển giai đoạn và hiện thông báo tạo đơn
    if (status === 'Chấp nhận') {
      if (quote.opportunityId) {
        setOpportunities((prev) =>
          prev.map((o) =>
            o.id === quote.opportunityId
              ? {
                  ...o,
                  stage: 'Đàm phán',
                  probability: 70,
                  nextStep: 'Khách đã chấp nhận Báo giá, tiến hành tạo Đơn hàng',
                  nextStepDate: new Date().toISOString().split('T')[0],
                }
              : o
          )
        );
      }
      showToast('Báo giá được chấp nhận', `Báo giá ${quote.code} đã chấp nhận! Nút Tạo Đơn Hàng đã sẵn sàng.`, 'success');
    } else {
      showToast('Cập nhật trạng thái', `Báo giá ${quote.code} đã chuyển sang "${status}".`);
    }
  };

  // 5. ORDERS ACTIONS
  const createOrderFromQuotation = (quotationId: string): SalesOrder => {
    const quote = quotations.find((q) => q.id === quotationId);
    if (!quote) throw new Error('Báo giá không tồn tại');

    const orderId = `ord-${Date.now()}`;
    const orderCode = `DH-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    // Kiểm tra tồn kho khả dụng từ danh mục sản phẩm kho
    let stockSufficient = true;
    const stockWarnings: string[] = [];

    const orderItems = quote.items.map((item) => {
      const whProd = INITIAL_WAREHOUSE_PRODUCTS.find((p) => p.sku === item.sku);
      const totalStock = whProd ? Object.values(whProd.stocks).reduce((a, b) => a + b, 0) : 0;
      const reserved = whProd ? whProd.reserved : 0;
      const available = Math.max(0, totalStock - reserved);

      if (available < item.quantity) {
        stockSufficient = false;
        stockWarnings.push(`SKU ${item.sku}: Đặt ${item.quantity} ${item.unit} nhưng tồn khả dụng chỉ còn ${available} ${item.unit}.`);
      }

      return {
        sku: item.sku,
        productName: item.productName,
        unit: item.unit,
        quantity: item.quantity,
        unitPrice: item.unitPrice,
        discountPercent: item.discountPercent,
        total: item.total,
        availableStock: available,
      };
    });

    const newOrder: SalesOrder = {
      id: orderId,
      code: orderCode,
      quotationId: quote.id,
      quotationCode: quote.code,
      customerId: quote.customerId,
      customerCode: quote.customerCode,
      customerName: quote.customerName,
      orderDate: new Date().toISOString().split('T')[0],
      expectedDeliveryDate: new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      items: orderItems,
      subTotal: quote.subTotal,
      taxAmount: quote.taxAmount,
      totalAmount: quote.grandTotal,
      amountInWords: quote.amountInWords,
      paymentTerms: quote.paymentTerms,
      assignedTo: quote.createdByName || 'Lê Hoàng Yến',
      status: 'Chờ duyệt',
      approvalLevel: quote.grandTotal > 500000000 ? 'Giám đốc' : 'Trưởng nhóm',
      stockSufficient,
      stockWarnings,
      chain: {
        ...quote.chain,
        orderId,
        orderCode,
      },
      createdAt: new Date().toISOString().split('T')[0],
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Cập nhật chain cho Quotation & Opportunity
    setQuotations((prev) =>
      prev.map((q) => (q.id === quotationId ? { ...q, chain: { ...q.chain, orderId, orderCode } } : q))
    );
    if (quote.opportunityId) {
      setOpportunities((prev) =>
        prev.map((o) =>
          o.id === quote.opportunityId
            ? { ...o, chain: { ...o.chain, orderId, orderCode } }
            : o
        )
      );
    }

    if (!stockSufficient) {
      showToast(
        'Cảnh báo tồn kho',
        `Đã tạo đơn ${orderCode} nhưng một số sản phẩm chưa đủ tồn kho khả dụng.`,
        'warning'
      );
    } else {
      showToast('Tạo Đơn hàng thành công', `Đơn hàng ${orderCode} đã tạo và chuyển trạng thái Chờ duyệt.`);
    }

    return newOrder;
  };

  const approveOrder = (orderId: string, approverName: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'Đã duyệt',
              approvedBy: approverName,
              approvedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            }
          : o
      )
    );
    showToast('Phê duyệt đơn hàng thành công', `Đơn hàng ${orderId} đã được phê duyệt. Nút Tạo Hợp đồng & Xuất kho đã mở.`);
  };

  const rejectOrder = (orderId: string, reason: string) => {
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              status: 'Từ chối',
              approvalStatus: 'Từ chối',
              rejectionReason: reason,
              approvedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
            }
          : o
      )
    );
    showToast('Đã từ chối đơn hàng', `Đơn hàng đã bị từ chối với lý do: ${reason}`);
  };

  const updateOrder = (id: string, updates: Partial<SalesOrder>) => {
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, ...updates } : o)));
  };

  // 6. CONTRACTS ACTIONS
  const createContractFromOrder = (orderId: string, startDate?: string, endDate?: string): SalesContract => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) throw new Error('Đơn hàng không tồn tại');

    const contractId = `cont-${Date.now()}`;
    const contractNumber = `HD-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const start = startDate || new Date().toISOString().split('T')[0];
    const end = endDate || new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    const m1Amount = Math.round(order.totalAmount * 0.4);
    const m2Amount = Math.round(order.totalAmount * 0.4);
    const m3Amount = order.totalAmount - m1Amount - m2Amount;

    const newContract: SalesContract = {
      id: contractId,
      contractNumber,
      title: `Hợp đồng Cung ứng Thiết bị & Dịch vụ - ${order.customerName}`,
      orderId: order.id,
      orderCode: order.code,
      customerId: order.customerId,
      customerCode: order.customerCode,
      customerName: order.customerName,
      customerCompany: order.customerName,
      totalValue: order.totalAmount,
      amountInWords: order.amountInWords,
      startDate: start,
      endDate: end,
      status: 'Đang hiệu lực',
      signedDate: new Date().toISOString().split('T')[0],
      manager: order.assignedTo,
      templateVariables: {
        ten_khach_hang: order.customerName,
        gia_tri: new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(order.totalAmount),
        ngay_ky: new Date().toLocaleDateString('vi-VN'),
        dia_chi: 'Việt Nam',
        dai_dien: order.customerName,
        chuc_vu: 'Đại diện thẩm quyền',
      },
      paymentMilestones: [
        {
          id: `ms-${Date.now()}-1`,
          title: 'Đợt 1: Tạm ứng khi ký Hợp đồng (40%)',
          percentage: 40,
          amount: m1Amount,
          dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          isPaid: false,
        },
        {
          id: `ms-${Date.now()}-2`,
          title: 'Đợt 2: Nghiệm thu bàn giao đợt 1 (40%)',
          percentage: 40,
          amount: m2Amount,
          dueDate: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          isPaid: false,
        },
        {
          id: `ms-${Date.now()}-3`,
          title: 'Đợt 3: Nghiệm thu toàn diện & Thanh lý (20%)',
          percentage: 20,
          amount: m3Amount,
          dueDate: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
          isPaid: false,
        },
      ],
      attachments: [{ name: `${contractNumber}-Signed.pdf`, size: '2.5 MB', uploadDate: new Date().toISOString().split('T')[0] }],
      chain: {
        ...order.chain,
        contractId,
        contractCode: contractNumber,
      },
      createdAt: new Date().toISOString().split('T')[0],
    };

    setContracts((prev) => [newContract, ...prev]);

    // Cập nhật trạng thái Order
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? { ...o, contractCreated: true, chain: { ...o.chain, contractId, contractCode: contractNumber } }
          : o
      )
    );

    showToast('Tạo Hợp đồng thành công', `Hợp đồng ${contractNumber} đã được lập với 3 đợt thanh toán.`);
    return newContract;
  };

  const updateContractStatus = (contractId: string, status: SalesContract['status']) => {
    setContracts((prev) => prev.map((c) => (c.id === contractId ? { ...c, status } : c)));
    showToast('Cập nhật trạng thái', `Hợp đồng đã chuyển sang "${status}".`);
  };

  const updateContract = (contractId: string, updates: Partial<SalesContract>) => {
    setContracts((prev) => prev.map((c) => (c.id === contractId ? { ...c, ...updates } : c)));
  };

  // 7. INVOICES ACTIONS
  const createInvoiceFromMilestone = (contractId: string, milestoneId: string): SalesInvoice => {
    const contract = contracts.find((c) => c.id === contractId);
    if (!contract) throw new Error('Hợp đồng không tồn tại');

    const milestone = contract.paymentMilestones.find((m) => m.id === milestoneId);
    if (!milestone) throw new Error('Đợt thanh toán không tồn tại');

    const invId = `inv-${Date.now()}`;
    const invoiceNumber = `HDON-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const subTotal = Math.round(milestone.amount / 1.1);
    const taxAmount = milestone.amount - subTotal;

    const newInvoice: SalesInvoice = {
      id: invId,
      invoiceNumber,
      customerId: contract.customerId,
      customerCode: contract.customerCode,
      customerName: contract.customerName,
      customerTaxId: '0101893452',
      customerAddress: 'Việt Nam',
      contractId: contract.id,
      contractCode: contract.contractNumber,
      orderId: contract.orderId,
      orderCode: contract.orderCode,
      milestoneTitle: milestone.title,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: milestone.dueDate,
      subTotal,
      taxRate: 10,
      taxAmount,
      totalAmount: milestone.amount,
      amountInWords: numberToVietnameseWords(milestone.amount),
      paidAmount: 0,
      remainingAmount: milestone.amount,
      status: 'Chưa thanh toán',
      einvoiceNumber: `00${Math.floor(20000 + Math.random() * 80000)}`,
      einvoiceSymbol: '1C26TBB',
      einvoiceIssuedDate: new Date().toISOString().split('T')[0],
      chain: {
        ...contract.chain,
        invoiceId: invId,
        invoiceCode: invoiceNumber,
      },
      createdAt: new Date().toISOString().split('T')[0],
    };

    setInvoices((prev) => [newInvoice, ...prev]);

    // Gắn mã Hóa đơn vào Milestone của Contract
    setContracts((prev) =>
      prev.map((c) =>
        c.id === contractId
          ? {
              ...c,
              paymentMilestones: c.paymentMilestones.map((m) =>
                m.id === milestoneId ? { ...m, invoiceCode: invoiceNumber } : m
              ),
              chain: { ...c.chain, invoiceId: invId, invoiceCode: invoiceNumber },
            }
          : c
      )
    );

    // Cập nhật công nợ khách hàng
    setCustomers((prev) =>
      prev.map((cust) =>
        cust.id === contract.customerId
          ? { ...cust, currentDebt: cust.currentDebt + milestone.amount }
          : cust
      )
    );

    showToast('Tạo Hóa đơn thành công', `Hóa đơn ${invoiceNumber} đã phát hành cho ${milestone.title}.`);
    return newInvoice;
  };

  const createInvoiceFromOrder = (orderId: string): SalesInvoice => {
    const order = orders.find((o) => o.id === orderId);
    if (!order) throw new Error('Đơn hàng không tồn tại');

    const invId = `inv-${Date.now()}`;
    const invoiceNumber = `HDON-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newInvoice: SalesInvoice = {
      id: invId,
      invoiceNumber,
      customerId: order.customerId,
      customerCode: order.customerCode,
      customerName: order.customerName,
      customerTaxId: '0101893452',
      customerAddress: 'Việt Nam',
      orderId: order.id,
      orderCode: order.code,
      milestoneTitle: `Hóa đơn xuất cho Đơn hàng ${order.code}`,
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: new Date(Date.now() + 15 * 86400000).toISOString().split('T')[0],
      subTotal: order.subTotal,
      taxRate: 10,
      taxAmount: order.taxAmount,
      totalAmount: order.totalAmount,
      amountInWords: order.amountInWords || numberToVietnameseWords(order.totalAmount),
      paidAmount: 0,
      remainingAmount: order.totalAmount,
      status: 'Chưa thanh toán',
      einvoiceNumber: `00${Math.floor(20000 + Math.random() * 80000)}`,
      einvoiceSymbol: '1C26TBB',
      einvoiceIssuedDate: new Date().toISOString().split('T')[0],
      chain: {
        ...order.chain,
        orderId: order.id,
        orderCode: order.code,
        invoiceId: invId,
        invoiceCode: invoiceNumber,
      },
      createdAt: new Date().toISOString().split('T')[0],
    };

    setInvoices((prev) => [newInvoice, ...prev]);

    // Gắn mã Hóa đơn vào chuỗi của Đơn hàng
    setOrders((prev) =>
      prev.map((o) =>
        o.id === orderId
          ? {
              ...o,
              chain: { ...o.chain, invoiceId: invId, invoiceCode: invoiceNumber },
            }
          : o
      )
    );

    // Cập nhật công nợ khách hàng
    setCustomers((prev) =>
      prev.map((cust) =>
        cust.id === order.customerId
          ? { ...cust, currentDebt: cust.currentDebt + order.totalAmount }
          : cust
      )
    );

    showToast('Tạo Hóa đơn thành công', `Hóa đơn ${invoiceNumber} đã phát hành từ Đơn hàng ${order.code}.`);
    return newInvoice;
  };

  const sendInvoicePaymentReminder = (invoiceId: string) => {
    const inv = invoices.find((i) => i.id === invoiceId);
    if (!inv) return;
    showToast('Đã gửi nhắc thanh toán', `Email đối soát & nhắc hạn hóa đơn ${inv.invoiceNumber} đã gửi tới khách hàng.`);
  };

  // 8. RECEIPTS ACTIONS
  const createReceiptFromInvoice = (
    invoiceId: string,
    amount: number,
    paymentMethod: 'Chuyển khoản' | 'Tiền mặt' | 'Khác',
    bankRefNumber: string,
    reason: string,
    payerName: string
  ): SalesReceipt => {
    const inv = invoices.find((i) => i.id === invoiceId);
    if (!inv) throw new Error('Hóa đơn không tồn tại');

    if (amount <= 0 || amount > inv.remainingAmount) {
      throw new Error(`Số tiền thu không hợp lệ. Số nợ còn lại của hóa đơn là ${inv.remainingAmount.toLocaleString()} ₫.`);
    }

    const recId = `rec-${Date.now()}`;
    const receiptNumber = `PT-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newReceipt: SalesReceipt = {
      id: recId,
      receiptNumber,
      date: new Date().toISOString().split('T')[0],
      customerId: inv.customerId,
      customerCode: inv.customerCode,
      customerName: inv.customerName,
      payerName,
      invoiceId: inv.id,
      invoiceNumber: inv.invoiceNumber,
      amount,
      amountInWords: numberToVietnameseWords(amount),
      paymentMethod,
      bankRefNumber: bankRefNumber || undefined,
      reason,
      collectorName: 'Lê Hoàng Yến',
      cashierName: 'Nguyễn Thị Minh Châu (Kế toán)',
      status: 'Hoàn tất',
      chain: {
        ...inv.chain,
        receiptId: recId,
        receiptCode: receiptNumber,
      },
      createdAt: new Date().toISOString().split('T')[0],
    };

    setReceipts((prev) => [newReceipt, ...prev]);

    // 1. TỰ ĐỘNG CẬP NHẬT HÓA ĐƠN
    const newPaid = inv.paidAmount + amount;
    const newRemaining = Math.max(0, inv.totalAmount - newPaid);
    const newInvStatus = newRemaining === 0 ? 'Đã thanh toán' : 'Thanh toán một phần';

    setInvoices((prev) =>
      prev.map((i) =>
        i.id === invoiceId
          ? {
              ...i,
              paidAmount: newPaid,
              remainingAmount: newRemaining,
              status: newInvStatus,
              chain: { ...i.chain, receiptId: recId, receiptCode: receiptNumber },
            }
          : i
      )
    );

    // 2. TỰ ĐỘNG CẬP NHẬT CÔNG NỢ KHÁCH HÀNG & DOANH THU
    setCustomers((prev) =>
      prev.map((c) =>
        c.id === inv.customerId
          ? {
              ...c,
              currentDebt: Math.max(0, c.currentDebt - amount),
              totalRevenue: c.totalRevenue + amount,
              lastPurchaseDate: new Date().toISOString().split('T')[0],
            }
          : c
      )
    );

    // 3. NẾU CÓ CONTRACT & ĐỢT THANH TOÁN -> ĐÁNH DẤU IS_PAID
    if (inv.contractId) {
      setContracts((prev) =>
        prev.map((cont) => {
          if (cont.id !== inv.contractId) return cont;
          return {
            ...cont,
            paymentMilestones: cont.paymentMilestones.map((m) =>
              m.invoiceCode === inv.invoiceNumber && newRemaining === 0 ? { ...m, isPaid: true } : m
            ),
          };
        })
      );
    }

    showToast(
      'Ghi nhận thanh toán thành công!',
      `Đã lập Phiếu thu ${receiptNumber} cho ${amount.toLocaleString()} ₫. Hóa đơn đã cập nhật.`
    );

    return newReceipt;
  };

  const cancelReceipt = (receiptId: string, reason: string) => {
    const rec = receipts.find((r) => r.id === receiptId);
    if (!rec) return;

    setReceipts((prev) =>
      prev.map((r) => (r.id === receiptId ? { ...r, status: 'Đã hủy', cancelReason: reason } : r))
    );

    // Hoàn tác công nợ & số nợ hóa đơn
    if (rec.invoiceId) {
      setInvoices((prev) =>
        prev.map((i) => {
          if (i.id !== rec.invoiceId) return i;
          const newPaid = Math.max(0, i.paidAmount - rec.amount);
          const newRemaining = i.totalAmount - newPaid;
          return {
            ...i,
            paidAmount: newPaid,
            remainingAmount: newRemaining,
            status: newPaid === 0 ? 'Chưa thanh toán' : 'Thanh toán một phần',
          };
        })
      );
    }

    showToast('Đã hủy Phiếu thu', `Phiếu ${rec.receiptNumber} đã hủy. Công nợ hóa đơn được hoàn lại.`);
  };

  const addDirectReceipt = (receiptData: Omit<SalesReceipt, 'id' | 'createdAt'>): SalesReceipt => {
    const recId = `rec-${Date.now()}`;
    const newReceipt: SalesReceipt = {
      ...receiptData,
      id: recId,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setReceipts((prev) => [newReceipt, ...prev]);

    // Cập nhật công nợ khách hàng nếu có
    if (newReceipt.customerId) {
      setCustomers((prev) =>
        prev.map((cust) =>
          cust.id === newReceipt.customerId
            ? {
                ...cust,
                currentDebt: Math.max(0, cust.currentDebt - newReceipt.amount),
                totalRevenue: cust.totalRevenue + newReceipt.amount,
                lastPurchaseDate: newReceipt.date,
              }
            : cust
        )
      );
    }

    // Nếu phiếu thu này đối soát vào một hóa đơn
    if (newReceipt.invoiceId) {
      setInvoices((prev) =>
        prev.map((inv) => {
          if (inv.id !== newReceipt.invoiceId) return inv;
          const newPaid = inv.paidAmount + newReceipt.amount;
          const newRemaining = Math.max(0, inv.totalAmount - newPaid);
          const newStatus = newRemaining === 0 ? 'Đã thanh toán' : 'Thanh toán một phần';
          return {
            ...inv,
            paidAmount: newPaid,
            remainingAmount: newRemaining,
            status: newStatus,
            chain: { ...inv.chain, receiptId: recId, receiptCode: newReceipt.receiptNumber },
          };
        })
      );
    }

    showToast(
      'Ghi nhận Phiếu thu thành công',
      `Phiếu thu ${newReceipt.receiptNumber} (${newReceipt.amount.toLocaleString()} ₫) đã ghi nhận vào sổ quỹ.`
    );

    return newReceipt;
  };

  // 9. ACTIVITIES ACTIONS
  const addActivity = (activityData: Omit<SalesActivity, 'id' | 'code' | 'createdAt' | 'isCompleted'>): SalesActivity => {
    const id = `act-${Date.now()}`;
    const code = `ACT-2026-${Math.floor(1000 + Math.random() * 9000)}`;

    const newActivity: SalesActivity = {
      ...activityData,
      id,
      code,
      isCompleted: false,
      createdAt: new Date().toISOString().split('T')[0],
    };

    setActivities((prev) => [newActivity, ...prev]);

    // Nếu activity gắn với Opportunity -> cập nhật ngày hoạt động gần nhất
    if (activityData.targetType === 'opportunity') {
      setOpportunities((prev) =>
        prev.map((o) =>
          o.id === activityData.targetId
            ? { ...o, lastActivityDate: new Date().toISOString().split('T')[0] }
            : o
        )
      );
    }

    showToast('Tạo Hoạt động thành công', `Đã thêm ${newActivity.type}: ${newActivity.title}`);
    return newActivity;
  };

  const completeActivity = (id: string, nextStepPrompt?: string) => {
    const act = activities.find((a) => a.id === id);
    if (!act) return;

    setActivities((prev) =>
      prev.map((a) =>
        a.id === id
          ? {
              ...a,
              isCompleted: true,
              completedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
              nextStepPrompt: nextStepPrompt || a.nextStepPrompt,
            }
          : a
      )
    );

    // Nếu có nextStepPrompt và gắn với Cơ hội -> tự động cập nhật "Bước tiếp theo" của Cơ hội
    if (nextStepPrompt && act.targetType === 'opportunity') {
      setOpportunities((prev) =>
        prev.map((o) =>
          o.id === act.targetId
            ? {
                ...o,
                nextStep: nextStepPrompt,
                nextStepDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                lastActivityDate: new Date().toISOString().split('T')[0],
              }
            : o
        )
      );
    }

    showToast('Hoàn thành hoạt động', `Hoạt động ${act.code} đã hoàn thành. Đã lưu bước kế tiếp.`);
  };

  // 10. CONTRACT WORKFLOW METHODS (Theo đúng luồng duyệt GĐ, ký HĐ & Thu cọc kế toán)
  const submitContractForApproval = (contractId: string) => {
    const contract = contracts.find((c) => c.id === contractId);
    if (!contract) return;
    setContracts((prev) =>
      prev.map((c) => (c.id === contractId ? { ...c, status: 'Chờ duyệt' } : c))
    );
    addNotification({
      title: 'Hợp đồng mới trình Giám đốc duyệt',
      message: `Sale đã soạn và trình duyệt Hợp đồng ${contract.contractNumber} (${contract.title}) - Khách hàng: ${contract.customerName} trị giá ${contract.totalValue.toLocaleString('vi-VN')} đ.`,
      type: 'approval',
      linkModule: 'sales-contracts',
      entityId: contract.id,
      senderName: contract.manager || 'Nhân viên Sales',
    });
    showToast('Trình duyệt thành công', `Hợp đồng ${contract.contractNumber} đã được chuyển tới Giám đốc phê duyệt.`);
  };

  const approveContract = (contractId: string, approvedBy = 'Nguyễn Văn Giám Đốc (CEO)') => {
    const contract = contracts.find((c) => c.id === contractId);
    if (!contract) return;
    setContracts((prev) =>
      prev.map((c) => (c.id === contractId ? { ...c, status: 'Chờ ký' } : c))
    );
    addNotification({
      title: `Giám đốc đã phê duyệt Hợp đồng ${contract.contractNumber}`,
      message: `${approvedBy} đã phê duyệt Hợp đồng ${contract.contractNumber}. Sale tiến hành ký kết chính thức với khách hàng và thu tiền tạm ứng đợt 1.`,
      type: 'contract',
      linkModule: 'sales-contracts',
      entityId: contract.id,
      senderName: approvedBy,
    });
    showToast('Phê duyệt hợp đồng', `Hợp đồng ${contract.contractNumber} đã được Giám đốc phê duyệt.`);
  };

  const signContractAndCollectDeposit = (
    contractId: string,
    depositAmount: number,
    paymentMethod: 'Chuyển khoản' | 'Tiền mặt' | 'Khác' = 'Chuyển khoản',
    bankRefNumber = 'FT262810849901 - Techcombank SGD'
  ): SalesReceipt => {
    const contract = contracts.find((c) => c.id === contractId);
    if (!contract) throw new Error('Hợp đồng không tồn tại');
    const today = new Date().toISOString().split('T')[0];

    // Cập nhật hợp đồng đã ký và đang hiệu lực
    setContracts((prev) =>
      prev.map((c) =>
        c.id === contractId
          ? {
              ...c,
              status: 'Đang hiệu lực',
              signedDate: today,
              paymentMilestones: c.paymentMilestones.map((m, idx) =>
                idx === 0 ? { ...m, isPaid: true } : m
              ),
            }
          : c
      )
    );

    // Kế toán tạo Phiếu thu tiền cọc
    const recId = `rec-${Date.now()}`;
    const recCode = `PT-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newReceipt: SalesReceipt = {
      id: recId,
      receiptNumber: recCode,
      date: today,
      customerId: contract.customerId,
      customerCode: contract.customerCode,
      customerName: contract.customerName,
      payerName: contract.templateVariables?.dai_dien || contract.customerName,
      payerAddress: contract.templateVariables?.dia_chi || '',
      amount: depositAmount,
      amountInWords: numberToVietnameseWords(depositAmount),
      paymentMethod,
      bankRefNumber,
      reason: `Thu tiền tạm ứng Đợt 1 Hợp đồng số ${contract.contractNumber} (${contract.title})`,
      collectorName: contract.manager,
      cashierName: 'Nguyễn Thị Minh Châu (Kế toán trưởng)',
      status: 'Hoàn tất',
      chain: {
        ...contract.chain,
        contractId: contract.id,
        contractCode: contract.contractNumber,
        receiptId: recId,
        receiptCode: recCode,
      },
      createdAt: today,
    };

    setReceipts((prev) => [newReceipt, ...prev]);

    // Bắn thông báo cho Kỹ thuật và Giám đốc
    addNotification({
      title: 'Kế toán: Đã thu tiền tạm ứng đợt 1',
      message: `Đã thu ${depositAmount.toLocaleString('vi-VN')} đ (Phiếu thu ${recCode}) cho Hợp đồng ${contract.contractNumber}. Kỹ thuật tiến hành lập đề xuất chi phí hạ tầng & triển khai!`,
      type: 'contract',
      linkModule: 'sales-receipts',
      entityId: recId,
      senderName: 'Nguyễn Thị Minh Châu (Kế toán trưởng)',
    });

    showToast('Ký HĐ & Thu cọc thành công', `Đã tạo Phiếu thu ${recCode} số tiền ${depositAmount.toLocaleString('vi-VN')} đ.`);
    return newReceipt;
  };

  return (
    <SalesContext.Provider
      value={{
        leads,
        customers,
        opportunities,
        quotations,
        orders,
        contracts,
        invoices,
        setInvoices,
        receipts,
        activities,

        addLead,
        updateLead,
        deleteLead,
        distributeLeads,
        recordContactAttempt,
        convertLead,

        addCustomer,
        updateCustomer,
        deleteCustomer,

        addOpportunity,
        updateOpportunity,
        updateOpportunityStage,
        deleteOpportunity,

        createQuotation,
        duplicateQuotationVersion,
        updateQuotationStatus,

        createOrderFromQuotation,
        approveOrder,
        rejectOrder,
        updateOrder,

        createContractFromOrder,
        updateContractStatus,
        updateContract,
        submitContractForApproval,
        approveContract,
        signContractAndCollectDeposit,

        createInvoiceFromMilestone,
        createInvoiceFromOrder,
        sendInvoicePaymentReminder,

        createReceiptFromInvoice,
        addDirectReceipt,
        cancelReceipt,

        addActivity,
        completeActivity,
      }}
    >
      {children}
    </SalesContext.Provider>
  );
};

export const useSales = () => {
  const context = useContext(SalesContext);
  if (!context) {
    throw new Error('useSales must be used within a SalesProvider');
  }
  return context;
};
