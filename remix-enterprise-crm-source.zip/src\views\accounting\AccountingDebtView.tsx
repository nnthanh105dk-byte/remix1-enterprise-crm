import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useAccounting } from '../../context/AccountingContext';
import { useSales } from '../../context/SalesContext';
import {
  CustomerDebtSummary,
  SupplierDebtSummary,
  DebtLedgerEntry,
  PaymentChannel,
  CashCategoryType,
} from '../../types/accounting';
import {
  CreditCard,
  Search,
  Filter,
  Download,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Send,
  Plus,
  FileText,
  DollarSign,
  TrendingDown,
  TrendingUp,
  Sliders,
  X,
  ExternalLink,
  Printer,
  ShieldAlert,
  Building2,
  Mail,
  MessageSquare,
  Smartphone,
  ChevronRight,
  Calendar,
  PhoneCall,
} from 'lucide-react';

export const AccountingDebtView: React.FC = () => {
  const { showToast, currentUser } = useCRM();
  const { addActivity } = useSales();
  const {
    customerDebts,
    supplierDebts,
    ledgerEntries,
    updateCreditLimit,
    addDebtAdjustment,
    sendDebtReminder,
    createReceiptFromAccounting,
    createPaymentFromAccounting,
  } = useAccounting();

  const [activeMainTab, setActiveMainTab] = useState<'receivable' | 'payable'>('receivable');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('all');
  const [selectedRiskStatus, setSelectedRiskStatus] = useState('all');
  const [selectedCostCategory, setSelectedCostCategory] = useState('all');

  // Modals state
  const [selectedCustomerForLedger, setSelectedCustomerForLedger] = useState<CustomerDebtSummary | null>(null);
  const [selectedSupplierForLedger, setSelectedSupplierForLedger] = useState<SupplierDebtSummary | null>(null);
  const [reminderTargetCustomer, setReminderTargetCustomer] = useState<CustomerDebtSummary | null>(null);
  const [receiptTargetCustomer, setReceiptTargetCustomer] = useState<CustomerDebtSummary | null>(null);
  const [paymentTargetSupplier, setPaymentTargetSupplier] = useState<SupplierDebtSummary | null>(null);
  const [creditLimitModalCustomer, setCreditLimitModalCustomer] = useState<CustomerDebtSummary | null>(null);
  const [isAdjustmentModalOpen, setIsAdjustmentModalOpen] = useState(false);

  // Form states for Reminder Modal
  const [reminderChannel, setReminderChannel] = useState<'Email' | 'Zalo' | 'SMS'>('Email');
  const [reminderNote, setReminderNote] = useState('');

  // Form states for Receipt Modal
  const [receiptAmount, setReceiptAmount] = useState<number>(0);
  const [receiptChannel, setReceiptChannel] = useState<PaymentChannel>('Vietcombank (0011004321999)');
  const [receiptRefNum, setReceiptRefNum] = useState('');
  const [receiptPayer, setReceiptPayer] = useState('');
  const [receiptReason, setReceiptReason] = useState('');

  // Form states for Payment Modal
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentCategory, setPaymentCategory] = useState<CashCategoryType>('Chi trả nhà cung cấp hàng hóa');
  const [paymentChannel, setPaymentChannel] = useState<PaymentChannel>('Vietcombank (0011004321999)');
  const [paymentRefNum, setPaymentRefNum] = useState('');
  const [paymentReason, setPaymentReason] = useState('');

  // Form states for Adjustment Modal
  const [adjPartnerType, setAdjPartnerType] = useState<'customer' | 'supplier'>('customer');
  const [adjPartnerId, setAdjPartnerId] = useState(customerDebts[0]?.customerId || '');
  const [adjDirection, setAdjDirection] = useState<'increase' | 'decrease'>('decrease');
  const [adjAmount, setAdjAmount] = useState<number>(5000000);
  const [adjReason, setAdjReason] = useState('Chiết khấu thương mại bổ sung theo chính sách Q1');

  // Form states for Credit Limit Modal
  const [editLimitVal, setEditLimitVal] = useState<number>(500000000);
  const [editTermDays, setEditTermDays] = useState<number>(30);
  const [editBlockOrder, setEditBlockOrder] = useState<boolean>(true);

  // Modal Tính dự phòng nợ phải thu khó đòi
  const [isBadDebtModalOpen, setIsBadDebtModalOpen] = useState(false);

  const badDebtProvisions = useMemo(() => {
    return customerDebts
      .filter((c) => c.overdueDebt > 0)
      .map((c) => {
        let provisionRate = 0.3;
        let tierLabel = 'Quá hạn 1 - 30 ngày (30%)';
        if (c.aging.over90 > 0) {
          provisionRate = 1.0;
          tierLabel = 'Quá hạn trên 90 ngày (100%)';
        } else if (c.aging.days61_90 > 0) {
          provisionRate = 0.7;
          tierLabel = 'Quá hạn 61 - 90 ngày (70%)';
        } else if (c.aging.days31_60 > 0) {
          provisionRate = 0.5;
          tierLabel = 'Quá hạn 31 - 60 ngày (50%)';
        }
        const provisionAmount = Math.round(c.overdueDebt * provisionRate);
        return {
          ...c,
          provisionRate,
          tierLabel,
          provisionAmount,
        };
      });
  }, [customerDebts]);

  const totalBadDebtProvision = useMemo(() => {
    return badDebtProvisions.reduce((sum, item) => sum + item.provisionAmount, 0);
  }, [badDebtProvisions]);

  // 1. Phải thu Stats
  const receivableStats = useMemo(() => {
    const totalReceivable = customerDebts.reduce((sum, c) => sum + c.closingDebt, 0);
    const totalOverdue = customerDebts.reduce((sum, c) => sum + c.overdueDebt, 0);
    const overduePct = totalReceivable > 0 ? (totalOverdue / totalReceivable) * 100 : 0;
    const withinTerm = totalReceivable - totalOverdue;
    const dueIn7Days = customerDebts
      .filter((c) => c.closingDebt > 0 && c.overdueDebt === 0)
      .reduce((sum, c) => sum + c.closingDebt * 0.4, 0); // Ước tính đến hạn trong 7 ngày
    const debtorCount = customerDebts.filter((c) => c.closingDebt > 0).length;
    // DSO = Phải thu / Doanh thu quý 1 (4.8 tỷ) * 90 ngày
    const dsoDays = (totalReceivable / 4800000000) * 90;

    return {
      totalReceivable,
      withinTerm,
      totalOverdue,
      overduePct,
      dueIn7Days,
      debtorCount,
      dsoDays: dsoDays.toFixed(1),
    };
  }, [customerDebts]);

  // 2. Phải trả Stats
  const payableStats = useMemo(() => {
    const totalPayable = supplierDebts.reduce((sum, s) => sum + s.closingDebt, 0);
    const totalOverdue = supplierDebts.reduce((sum, s) => sum + s.overdueDebt, 0);
    const withinTerm = totalPayable - totalOverdue;
    const dueIn7Days = supplierDebts
      .filter((s) => s.status === 'Chờ thanh toán')
      .reduce((sum, s) => sum + s.closingDebt * 0.5, 0);
    const supplierCount = supplierDebts.filter((s) => s.closingDebt > 0).length;

    return {
      totalPayable,
      withinTerm,
      totalOverdue,
      dueIn7Days,
      supplierCount,
    };
  }, [supplierDebts]);

  // Lọc danh sách khách hàng
  const filteredCustomerDebts = useMemo(() => {
    return customerDebts.filter((c) => {
      const matchSearch =
        c.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.customerCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        c.taxId.includes(searchTerm) ||
        c.assignedSalesStaff.toLowerCase().includes(searchTerm.toLowerCase());
      const matchRegion = selectedRegion === 'all' || c.region === selectedRegion;
      const matchRisk = selectedRiskStatus === 'all' || c.riskStatus === selectedRiskStatus;
      return matchSearch && matchRegion && matchRisk;
    });
  }, [customerDebts, searchTerm, selectedRegion, selectedRiskStatus]);

  // Lọc danh sách nhà cung cấp
  const filteredSupplierDebts = useMemo(() => {
    return supplierDebts.filter((s) => {
      const matchSearch =
        s.supplierName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.supplierCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.taxId.includes(searchTerm);
      const matchCost = selectedCostCategory === 'all' || s.costCategory === selectedCostCategory;
      return matchSearch && matchCost;
    });
  }, [supplierDebts, searchTerm, selectedCostCategory]);

  // Xử lý gửi nhắc nợ
  const handleConfirmSendReminder = () => {
    if (!reminderTargetCustomer) return;
    sendDebtReminder({
      customerId: reminderTargetCustomer.customerId,
      customerName: reminderTargetCustomer.customerName,
      channel: reminderChannel,
      recipientContact:
        reminderChannel === 'Email'
          ? reminderTargetCustomer.email
          : reminderTargetCustomer.phone,
      debtAmount: reminderTargetCustomer.closingDebt,
      overdueDays: reminderTargetCustomer.overdueDebt > 0 ? 15 : 0,
      contentPreview: `Nhắc công nợ ${reminderTargetCustomer.customerName}: Số tiền ${reminderTargetCustomer.closingDebt.toLocaleString('vi-VN')} đ. Ghi chú: ${reminderNote || 'Đề nghị thanh toán theo hợp đồng'}`,
      hasAttachmentStatement: true,
      status: 'Đã gửi',
    });
    setReminderTargetCustomer(null);
    setReminderNote('');
  };

  // Xử lý tạo phiếu thu
  const handleConfirmCreateReceipt = (e: React.FormEvent) => {
    e.preventDefault();
    if (!receiptTargetCustomer || receiptAmount <= 0) {
      showToast('Lỗi nhập liệu', 'Vui lòng nhập số tiền thu hợp lệ (> 0)');
      return;
    }
    createReceiptFromAccounting({
      customerId: receiptTargetCustomer.customerId,
      customerName: receiptTargetCustomer.customerName,
      amount: receiptAmount,
      channel: receiptChannel,
      bankRefNumber: receiptRefNum,
      payerName: receiptPayer || receiptTargetCustomer.customerName,
      reason: receiptReason || `Thu nợ tiền hàng khách hàng ${receiptTargetCustomer.customerName}`,
    });
    setReceiptTargetCustomer(null);
  };

  // Xử lý tạo phiếu chi
  const handleConfirmCreatePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentTargetSupplier || paymentAmount <= 0) {
      showToast('Lỗi nhập liệu', 'Vui lòng nhập số tiền chi hợp lệ (> 0)');
      return;
    }
    createPaymentFromAccounting({
      supplierId: paymentTargetSupplier.supplierId,
      supplierName: paymentTargetSupplier.supplierName,
      amount: paymentAmount,
      category: paymentCategory,
      channel: paymentChannel,
      bankRefNumber: paymentRefNum,
      reason: paymentReason || `Thanh toán công nợ cho ${paymentTargetSupplier.supplierName}`,
    });
    setPaymentTargetSupplier(null);
  };

  // Xử lý tạo chứng từ điều chỉnh
  const handleConfirmAdjustment = (e: React.FormEvent) => {
    e.preventDefault();
    const partnerName =
      adjPartnerType === 'customer'
        ? customerDebts.find((c) => c.customerId === adjPartnerId)?.customerName || ''
        : supplierDebts.find((s) => s.supplierId === adjPartnerId)?.supplierName || '';

    addDebtAdjustment({
      code: `DC-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString().split('T')[0],
      partnerType: adjPartnerType,
      partnerId: adjPartnerId,
      partnerName,
      direction: adjDirection,
      amount: adjAmount,
      reason: adjReason,
      approvedBy: currentUser?.fullName || 'Kế toán trưởng',
      attachmentFileName: 'Bien_ban_dieu_chinh.pdf',
    });
    setIsAdjustmentModalOpen(false);
  };

  // Xử lý lưu hạn mức
  const handleSaveCreditLimit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!creditLimitModalCustomer) return;
    updateCreditLimit(
      creditLimitModalCustomer.customerId,
      editLimitVal,
      editTermDays,
      editBlockOrder
    );
    setCreditLimitModalCustomer(null);
  };

  return (
    <div className="space-y-6">
      {/* 1. Header & Navigation */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
              Kế toán Quản trị
            </span>
            <span className="text-xs text-slate-400">Nguồn dữ liệu chứng từ Sales & Logistics</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-1">
            Quản lý Công nợ (Phải thu - Phải trả)
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Theo dõi tuổi nợ, hạn mức tín dụng khách hàng, sổ chi tiết công nợ và thực hiện đối trừ chứng từ.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setIsBadDebtModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-300 hover:bg-amber-100 transition-colors shadow-sm"
          >
            <ShieldAlert className="w-4 h-4 text-amber-600" />
            Tính dự phòng nợ phải thu khó đòi
          </button>
          <button
            onClick={() => setIsAdjustmentModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-sm"
          >
            <Sliders className="w-4 h-4 text-slate-500" />
            Điều chỉnh công nợ
          </button>
          <button
            onClick={() =>
              showToast('Xuất báo cáo', 'Đã tải xuống bảng tổng hợp công nợ chi tiết file Excel')
            }
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors shadow-sm"
          >
            <Download className="w-4 h-4" />
            Xuất Excel
          </button>
        </div>
      </div>

      {/* 2. Main Tabs Switcher */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 rounded-t-xl">
        <button
          onClick={() => setActiveMainTab('receivable')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeMainTab === 'receivable'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <TrendingDown className="w-4 h-4" />
          Phải thu khách hàng (Sales)
          <span className="ml-1.5 px-2 py-0.5 text-xs rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
            {customerDebts.length}
          </span>
        </button>

        <button
          onClick={() => setActiveMainTab('payable')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeMainTab === 'payable'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          Phải trả nhà cung cấp & Đối tác (Logistics/Kỹ thuật)
          <span className="ml-1.5 px-2 py-0.5 text-xs rounded-full bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300">
            {supplierDebts.length}
          </span>
        </button>
      </div>

      {/* 3. Phải thu Khách hàng View */}
      {activeMainTab === 'receivable' && (
        <div className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3.5">
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Tổng phải thu</span>
              <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                {receivableStats.totalReceivable.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1 mt-0.5">
                {receivableStats.debtorCount} khách hàng nợ
              </span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Nợ trong hạn</span>
              <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                {receivableStats.withinTerm.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-400">An toàn tín dụng</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-red-200 dark:border-red-900/30 bg-red-50/20 dark:bg-red-900/10 shadow-sm">
              <span className="text-xs font-medium text-red-600 dark:text-red-400 flex items-center justify-between">
                <span>Nợ quá hạn</span>
                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-red-100 dark:bg-red-900/40 text-red-700">
                  {receivableStats.overduePct.toFixed(1)}%
                </span>
              </span>
              <div className="text-lg font-bold text-red-600 dark:text-red-400 mt-1">
                {receivableStats.totalOverdue.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-red-500">Cần đôn đốc nhắc nợ</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Đến hạn trong 7 ngày</span>
              <div className="text-lg font-bold text-amber-600 dark:text-amber-400 mt-1">
                {receivableStats.dueIn7Days.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-400">Dự kiến thu về</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Số ngày thu tiền (DSO)</span>
              <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
                {receivableStats.dsoDays} ngày
              </div>
              <span className="text-[11px] text-slate-400">Mục tiêu &lt; 35 ngày</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Khách nợ rủi ro cao</span>
              <div className="text-lg font-bold text-purple-600 dark:text-purple-400 mt-1">
                {customerDebts.filter((c) => c.riskStatus === 'Rủi ro cao').length} khách
              </div>
              <span className="text-[11px] text-purple-500">Chặn xuất đơn mới</span>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
            <div className="flex-1 w-full md:w-auto relative">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Tìm khách hàng theo tên, mã KH, MST, Sales phụ trách..."
                className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div className="flex items-center gap-2.5 w-full md:w-auto">
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
              >
                <option value="all">Tất cả khu vực</option>
                <option value="Miền Bắc">Miền Bắc</option>
                <option value="Miền Trung">Miền Trung</option>
                <option value="Miền Nam">Miền Nam</option>
              </select>

              <select
                value={selectedRiskStatus}
                onChange={(e) => setSelectedRiskStatus(e.target.value)}
                className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
              >
                <option value="all">Tất cả trạng thái</option>
                <option value="Bình thường">Bình thường</option>
                <option value="Cần nhắc">Cần nhắc</option>
                <option value="Rủi ro cao">Rủi ro cao</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
                <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="px-4 py-3.5">Khách hàng</th>
                    <th className="px-3 py-3.5">Sales phụ trách</th>
                    <th className="px-3 py-3.5 text-right">Phát sinh kỳ</th>
                    <th className="px-3 py-3.5 text-right">Đã thu</th>
                    <th className="px-3 py-3.5 text-right">Còn nợ</th>
                    <th className="px-3 py-3.5 text-right">Quá hạn</th>
                    <th className="px-3 py-3.5 text-center">Phân tích tuổi nợ</th>
                    <th className="px-3 py-3.5 text-right">Hạn mức nợ</th>
                    <th className="px-3 py-3.5 text-center">Trạng thái</th>
                    <th className="px-4 py-3.5 text-center">Hành động</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {filteredCustomerDebts.map((c) => {
                    const isOverLimit = c.closingDebt > c.creditLimit;
                    return (
                      <tr
                        key={c.customerId}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors"
                      >
                        <td className="px-4 py-3.5">
                          <button
                            onClick={() => setSelectedCustomerForLedger(c)}
                            className="font-medium text-slate-900 dark:text-white hover:text-emerald-600 dark:hover:text-emerald-400 text-left transition-colors flex items-center gap-1.5 group"
                          >
                            <span>{c.customerName}</span>
                            <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 text-emerald-500 transition-opacity" />
                          </button>
                          <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                            <span className="font-mono">{c.customerCode}</span>
                            <span>•</span>
                            <span>MST: {c.taxId}</span>
                            <span>•</span>
                            <span className="px-1.5 py-0.2 rounded bg-slate-100 dark:bg-slate-700 text-[10px]">
                              {c.group}
                            </span>
                          </div>
                        </td>

                        <td className="px-3 py-3.5">
                          <div className="font-medium text-slate-800 dark:text-slate-200">
                            {c.assignedSalesStaff}
                          </div>
                          <div className="text-xs text-slate-400">{c.salesDepartment}</div>
                        </td>

                        <td className="px-3 py-3.5 text-right font-medium text-slate-700 dark:text-slate-300">
                          {c.periodIncurred.toLocaleString('vi-VN')} đ
                        </td>

                        <td className="px-3 py-3.5 text-right font-medium text-emerald-600 dark:text-emerald-400">
                          {c.periodPaid.toLocaleString('vi-VN')} đ
                        </td>

                        <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                          {c.closingDebt.toLocaleString('vi-VN')} đ
                        </td>

                        <td className="px-3 py-3.5 text-right font-bold text-red-600 dark:text-red-400">
                          {c.overdueDebt > 0 ? `${c.overdueDebt.toLocaleString('vi-VN')} đ` : '-'}
                        </td>

                        {/* Phân tích tuổi nợ visual bar */}
                        <td className="px-3 py-3.5 text-center">
                          <div className="flex items-center justify-center gap-1 text-[11px] font-mono">
                            <span
                              title={`Chưa đến hạn: ${c.aging.current.toLocaleString('vi-VN')} đ`}
                              className={`px-1.5 py-0.5 rounded ${
                                c.aging.current > 0
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                                  : 'text-slate-300'
                              }`}
                            >
                              0
                            </span>
                            <span
                              title={`Quá hạn 1-30 ngày: ${c.aging.days1_30.toLocaleString('vi-VN')} đ`}
                              className={`px-1.5 py-0.5 rounded ${
                                c.aging.days1_30 > 0
                                  ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300'
                                  : 'text-slate-300'
                              }`}
                            >
                              1-30
                            </span>
                            <span
                              title={`Quá hạn 31-60 ngày: ${c.aging.days31_60.toLocaleString('vi-VN')} đ`}
                              className={`px-1.5 py-0.5 rounded ${
                                c.aging.days31_60 > 0
                                  ? 'bg-orange-100 text-orange-800 dark:bg-orange-900/40 dark:text-orange-300'
                                  : 'text-slate-300'
                              }`}
                            >
                              31-60
                            </span>
                            <span
                              title={`Quá hạn >60 ngày: ${(c.aging.days61_90 + c.aging.over90).toLocaleString('vi-VN')} đ`}
                              className={`px-1.5 py-0.5 rounded ${
                                c.aging.days61_90 + c.aging.over90 > 0
                                  ? 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300 font-bold'
                                  : 'text-slate-300'
                              }`}
                            >
                              &gt;60
                            </span>
                          </div>
                        </td>

                        <td className="px-3 py-3.5 text-right">
                          <button
                            onClick={() => {
                              setCreditLimitModalCustomer(c);
                              setEditLimitVal(c.creditLimit);
                              setEditTermDays(c.creditTermDays);
                              setEditBlockOrder(c.blockNewOrdersOnOverdue);
                            }}
                            className="text-xs hover:underline flex items-center justify-end gap-1 text-slate-700 dark:text-slate-300 font-medium ml-auto"
                          >
                            <span>{c.creditLimit.toLocaleString('vi-VN')} đ</span>
                            <Sliders className="w-3 h-3 text-slate-400" />
                          </button>
                          {isOverLimit && (
                            <div className="text-[10px] text-red-500 font-semibold flex items-center justify-end gap-0.5">
                              <AlertTriangle className="w-2.5 h-2.5" />
                              Vượt hạn mức
                            </div>
                          )}
                        </td>

                        <td className="px-3 py-3.5 text-center">
                          <span
                            className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                              c.riskStatus === 'Bình thường'
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300'
                                : c.riskStatus === 'Cần nhắc'
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
                                : 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                            }`}
                          >
                            {c.riskStatus}
                          </span>
                        </td>

                        <td className="px-4 py-3.5 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => setSelectedCustomerForLedger(c)}
                              title="Xem sổ chi tiết công nợ"
                              className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                            >
                              <FileText className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                setReceiptTargetCustomer(c);
                                setReceiptAmount(c.closingDebt);
                                setReceiptPayer(c.customerName);
                                setReceiptReason(`Thu công nợ khách hàng ${c.customerName}`);
                              }}
                              title="Tạo phiếu thu"
                              className="p-1.5 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/30 rounded-lg transition-colors"
                            >
                              <DollarSign className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => setReminderTargetCustomer(c)}
                              title="Gửi nhắc nợ"
                              className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/30 rounded-lg transition-colors"
                            >
                              <Send className="w-4 h-4" />
                            </button>

                            <button
                              onClick={() => {
                                const amountToCollect = c.overdueDebt > 0 ? c.overdueDebt : c.closingDebt;
                                addActivity({
                                  type: 'Cuộc gọi',
                                  title: `[Giao thu nợ] Đôn đốc công nợ ${amountToCollect.toLocaleString('vi-VN')} đ`,
                                  targetType: 'customer',
                                  targetId: c.customerId,
                                  targetName: c.customerName,
                                  assignedTo: c.assignedSalesStaff || 'Lê Hoàng Yến',
                                  priority: 'Khẩn cấp',
                                  dueDate: new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0],
                                  notes: `Kế toán công nợ giao Sales ${c.assignedSalesStaff} trực tiếp liên hệ khách hàng ${c.customerName} thu hồi công nợ quá hạn. Hạn mức hiện tại: ${c.creditLimit.toLocaleString('vi-VN')} đ.`,
                                  nextStepPrompt: 'Hẹn ngày thanh toán cụ thể hoặc gửi công văn đôn đốc',
                                });
                                showToast(
                                  'Đã giao Sales thu nợ',
                                  `Đã tạo công việc khẩn cấp trong Hoạt động & Lịch hẹn của ${c.assignedSalesStaff} cho khách hàng ${c.customerName}.`,
                                  'success'
                                );
                              }}
                              title="Giao Sales đôn đốc thu nợ"
                              className="p-1.5 text-amber-600 hover:bg-amber-50 dark:hover:bg-amber-900/30 rounded-lg transition-colors"
                            >
                              <PhoneCall className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. Phải trả Nhà cung cấp View */}
      {activeMainTab === 'payable' && (
        <div className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-3.5">
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Tổng phải trả NCC</span>
              <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                {payableStats.totalPayable.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-400">{payableStats.supplierCount} đối tác</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Nợ trong hạn</span>
              <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                {payableStats.withinTerm.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-400">Chưa đến hạn thanh toán</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-red-200 dark:border-red-900/30 bg-red-50/20 dark:bg-red-900/10 shadow-sm">
              <span className="text-xs font-medium text-red-600 dark:text-red-400">Nợ quá hạn phải trả</span>
              <div className="text-lg font-bold text-red-600 dark:text-red-400 mt-1">
                {payableStats.totalOverdue.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-red-500">Cần lập ủy nhiệm chi gấp</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Đến hạn trong 7 ngày</span>
              <div className="text-lg font-bold text-amber-600 dark:text-amber-400 mt-1">
                {payableStats.dueIn7Days.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-400">Kế hoạch chi tuần tới</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Đã duyệt chi chờ chuyển</span>
              <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
                {supplierDebts.filter((s) => s.status === 'Đã duyệt chi').length} phiếu
              </div>
              <span className="text-[11px] text-blue-500">Sẵn sàng xuất quỹ</span>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
            <div className="flex-1 w-full md:w-auto relative">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Tìm nhà cung cấp theo tên, mã NCC, mã số thuế..."
                className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div className="flex items-center gap-2.5 w-full md:w-auto">
              <select
                value={selectedCostCategory}
                onChange={(e) => setSelectedCostCategory(e.target.value)}
                className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
              >
                <option value="all">Tất cả loại chi phí</option>
                <option value="Hàng hóa thiết bị">Hàng hóa thiết bị</option>
                <option value="Cước vận chuyển">Cước vận chuyển</option>
                <option value="Dịch vụ kỹ thuật thầu phụ">Dịch vụ kỹ thuật thầu phụ</option>
                <option value="Vật tư tiêu hao">Vật tư tiêu hao</option>
              </select>
            </div>
          </div>

          {/* Table */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
                <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="px-4 py-3.5">Nhà cung cấp / Đối tác</th>
                    <th className="px-3 py-3.5">Phân loại chi phí</th>
                    <th className="px-3 py-3.5 text-right">Phát sinh kỳ</th>
                    <th className="px-3 py-3.5 text-right">Đã thanh toán</th>
                    <th className="px-3 py-3.5 text-right">Còn phải trả</th>
                    <th className="px-3 py-3.5 text-right">Quá hạn</th>
                    <th className="px-3 py-3.5 text-center">Hạn thanh toán</th>
                    <th className="px-3 py-3.5 text-center">Trạng thái</th>
                    <th className="px-4 py-3.5 text-center">Hành động</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {filteredSupplierDebts.map((s) => (
                    <tr
                      key={s.supplierId}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors"
                    >
                      <td className="px-4 py-3.5">
                        <button
                          onClick={() => setSelectedSupplierForLedger(s)}
                          className="font-medium text-slate-900 dark:text-white hover:text-emerald-600 dark:hover:text-emerald-400 text-left transition-colors flex items-center gap-1.5 group"
                        >
                          <span>{s.supplierName}</span>
                          <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 text-emerald-500 transition-opacity" />
                        </button>
                        <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                          <span className="font-mono">{s.supplierCode}</span>
                          <span>•</span>
                          <span>MST: {s.taxId}</span>
                          {s.bankAccount && (
                            <>
                              <span>•</span>
                              <span>STK: {s.bankAccount} ({s.bankName})</span>
                            </>
                          )}
                        </div>
                      </td>

                      <td className="px-3 py-3.5">
                        <span className="px-2 py-0.5 rounded text-xs font-medium bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-300">
                          {s.costCategory}
                        </span>
                      </td>

                      <td className="px-3 py-3.5 text-right font-medium text-slate-700 dark:text-slate-300">
                        {s.periodIncurred.toLocaleString('vi-VN')} đ
                      </td>

                      <td className="px-3 py-3.5 text-right font-medium text-emerald-600 dark:text-emerald-400">
                        {s.periodPaid.toLocaleString('vi-VN')} đ
                      </td>

                      <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                        {s.closingDebt.toLocaleString('vi-VN')} đ
                      </td>

                      <td className="px-3 py-3.5 text-right font-bold text-red-600 dark:text-red-400">
                        {s.overdueDebt > 0 ? `${s.overdueDebt.toLocaleString('vi-VN')} đ` : '-'}
                      </td>

                      <td className="px-3 py-3.5 text-center text-xs font-mono text-slate-600 dark:text-slate-400">
                        {s.nextDueDate || 'Chưa có'}
                      </td>

                      <td className="px-3 py-3.5 text-center">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                            s.status === 'Đã duyệt chi'
                              ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300'
                              : s.status === 'Quá hạn'
                              ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
                          }`}
                        >
                          {s.status}
                        </span>
                      </td>

                      <td className="px-4 py-3.5 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => setSelectedSupplierForLedger(s)}
                            title="Xem sổ chi tiết công nợ NCC"
                            className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                          >
                            <FileText className="w-4 h-4" />
                          </button>

                          <button
                            onClick={() => {
                              setPaymentTargetSupplier(s);
                              setPaymentAmount(s.closingDebt);
                              setPaymentReason(`Thanh toán tiền hàng/chi phí cho ${s.supplierName}`);
                            }}
                            title="Lập phiếu chi / Đề nghị thanh toán"
                            className="px-2.5 py-1 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors flex items-center gap-1"
                          >
                            <DollarSign className="w-3.5 h-3.5" />
                            Chi tiền
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 1: SỔ CHI TIẾT CÔNG NỢ (KHÁCH HÀNG HOẶC NCC) */}
      {/* ======================================================== */}
      {(selectedCustomerForLedger || selectedSupplierForLedger) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-4xl w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-6">
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
              <div>
                <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                  Sổ chi tiết công nợ
                </span>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                  {selectedCustomerForLedger?.customerName || selectedSupplierForLedger?.supplierName}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Mã:{' '}
                  {selectedCustomerForLedger?.customerCode || selectedSupplierForLedger?.supplierCode} •
                  MST: {selectedCustomerForLedger?.taxId || selectedSupplierForLedger?.taxId} • Kỳ đối
                  chiếu: 01/01/2026 - 31/03/2026
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    showToast('In sổ chi tiết', 'Đã chuyển lệnh in biểu mẫu sổ công nợ chuẩn kế toán')
                  }
                  className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
                  title="In sổ chi tiết"
                >
                  <Printer className="w-5 h-5" />
                </button>
                <button
                  onClick={() => {
                    setSelectedCustomerForLedger(null);
                    setSelectedSupplierForLedger(null);
                  }}
                  className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Sổ chi tiết table */}
            <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800 uppercase font-semibold text-slate-500 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="px-3 py-2.5">Ngày</th>
                    <th className="px-3 py-2.5">Chứng từ</th>
                    <th className="px-3 py-2.5">Số hiệu</th>
                    <th className="px-4 py-2.5">Diễn giải</th>
                    <th className="px-3 py-2.5 text-right">Phát sinh tăng</th>
                    <th className="px-3 py-2.5 text-right">Phát sinh giảm</th>
                    <th className="px-3 py-2.5 text-right">Số dư lũy kế</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {(
                    ledgerEntries[
                      selectedCustomerForLedger?.customerId ||
                        selectedSupplierForLedger?.supplierId ||
                        ''
                    ] || [
                      {
                        id: 'dummy-1',
                        date: '2026-01-01',
                        docType: 'Hóa đơn bán hàng',
                        docCode: 'SỐ DƯ ĐẦU KỲ',
                        description: 'Số dư nợ chuyển sang đầu kỳ',
                        increaseAmount: selectedCustomerForLedger?.openingBalance || 0,
                        decreaseAmount: 0,
                        runningBalance: selectedCustomerForLedger?.openingBalance || 0,
                      },
                    ]
                  ).map((entry, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="px-3 py-2.5 font-mono text-slate-500">{entry.date}</td>
                      <td className="px-3 py-2.5 font-medium text-slate-700 dark:text-slate-300">
                        {entry.docType}
                      </td>
                      <td className="px-3 py-2.5 font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                        {entry.docCode}
                      </td>
                      <td className="px-4 py-2.5 text-slate-600 dark:text-slate-400">
                        {entry.description}
                      </td>
                      <td className="px-3 py-2.5 text-right font-medium text-slate-900 dark:text-white">
                        {entry.increaseAmount > 0
                          ? `${entry.increaseAmount.toLocaleString('vi-VN')} đ`
                          : '-'}
                      </td>
                      <td className="px-3 py-2.5 text-right font-medium text-emerald-600 dark:text-emerald-400">
                        {entry.decreaseAmount > 0
                          ? `${entry.decreaseAmount.toLocaleString('vi-VN')} đ`
                          : '-'}
                      </td>
                      <td className="px-3 py-2.5 text-right font-bold text-slate-900 dark:text-white">
                        {entry.runningBalance.toLocaleString('vi-VN')} đ
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Summary footer */}
            <div className="bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-xs text-slate-500">Số dư nợ cuối kỳ hiện tại:</span>
                <div className="text-lg font-bold text-slate-900 dark:text-white">
                  {(
                    selectedCustomerForLedger?.closingDebt ||
                    selectedSupplierForLedger?.closingDebt ||
                    0
                  ).toLocaleString('vi-VN')}{' '}
                  đ
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setSelectedCustomerForLedger(null);
                    setSelectedSupplierForLedger(null);
                  }}
                  className="px-4 py-2 text-sm font-medium rounded-lg bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200 hover:bg-slate-300 transition-colors"
                >
                  Đóng
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 2: GỬI NHẮC NỢ (REMINDER MODAL) */}
      {/* ======================================================== */}
      {reminderTargetCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-5">
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Send className="w-5 h-5 text-emerald-600" />
                  Gửi thông báo nhắc công nợ
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Khách hàng: {reminderTargetCustomer.customerName}
                </p>
              </div>
              <button
                onClick={() => setReminderTargetCustomer(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  Kênh gửi thông báo
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setReminderChannel('Email')}
                    className={`py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 ${
                      reminderChannel === 'Email'
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    <Mail className="w-3.5 h-3.5" /> Email ({reminderTargetCustomer.email})
                  </button>
                  <button
                    type="button"
                    onClick={() => setReminderChannel('Zalo')}
                    className={`py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 ${
                      reminderChannel === 'Zalo'
                        ? 'border-blue-600 bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    <MessageSquare className="w-3.5 h-3.5" /> Zalo ZNS
                  </button>
                  <button
                    type="button"
                    onClick={() => setReminderChannel('SMS')}
                    className={`py-2 px-3 rounded-lg text-xs font-medium border flex items-center justify-center gap-1.5 ${
                      reminderChannel === 'SMS'
                        ? 'border-purple-600 bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300'
                        : 'border-slate-200 dark:border-slate-700 text-slate-600'
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5" /> Brandname SMS
                  </button>
                </div>
              </div>

              {/* Preview Box */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
                <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                  <span>Nội dung xem trước (Mẫu chuẩn Kế toán):</span>
                  <span className="text-[10px] text-emerald-600 font-normal">Kèm sao kê PDF</span>
                </span>
                <p className="text-slate-600 dark:text-slate-400 leading-relaxed italic">
                  &quot;Kính gửi Quý khách hàng {reminderTargetCustomer.customerName}, Phòng Kế toán
                  thông báo khoản công nợ phát sinh cần thanh toán là{' '}
                  <strong className="text-slate-900 dark:text-white">
                    {reminderTargetCustomer.closingDebt.toLocaleString('vi-VN')} đ
                  </strong>
                  . Vui lòng kiểm tra sao kê đính kèm và hoàn tất thanh toán trước hạn. Trân trọng cảm
                  ơn!&quot;
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Ghi chú bổ sung (tùy chọn)
                </label>
                <textarea
                  rows={2}
                  value={reminderNote}
                  onChange={(e) => setReminderNote(e.target.value)}
                  placeholder="Nhập thông tin số tài khoản hoặc lời nhắn riêng..."
                  className="w-full p-2.5 text-xs rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setReminderTargetCustomer(null)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                Hủy bỏ
              </button>
              <button
                type="button"
                onClick={handleConfirmSendReminder}
                className="px-4 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5"
              >
                <Send className="w-3.5 h-3.5" />
                Xác nhận gửi nhắc nợ
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 3: TẠO PHIẾU THU TỪ KẾ TOÁN */}
      {/* ======================================================== */}
      {receiptTargetCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <form
            onSubmit={handleConfirmCreateReceipt}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-emerald-600" />
                  Lập Phiếu Thu Tiền Hàng
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Đối trừ công nợ khách hàng: {receiptTargetCustomer.customerName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setReceiptTargetCustomer(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Số tiền thu (VND) *
                </label>
                <input
                  type="number"
                  min={1000}
                  value={receiptAmount}
                  onChange={(e) => setReceiptAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold text-base outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <span className="text-[11px] text-slate-400 mt-0.5 block">
                  Công nợ hiện tại: {receiptTargetCustomer.closingDebt.toLocaleString('vi-VN')} đ
                </span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Hình thức thanh toán / Tài khoản đích *
                </label>
                <select
                  value={receiptChannel}
                  onChange={(e) => setReceiptChannel(e.target.value as PaymentChannel)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                >
                  <option value="Vietcombank (0011004321999)">Vietcombank (0011004321999)</option>
                  <option value="Techcombank (19033321456011)">Techcombank (19033321456011)</option>
                  <option value="MB Bank (0888666999)">MB Bank (0888666999)</option>
                  <option value="Tiền mặt tại quỹ">Tiền mặt tại quỹ chính</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Người nộp tiền
                  </label>
                  <input
                    type="text"
                    value={receiptPayer}
                    onChange={(e) => setReceiptPayer(e.target.value)}
                    placeholder="Họ tên người nộp / đại diện"
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Mã tham chiếu ngân hàng
                  </label>
                  <input
                    type="text"
                    value={receiptRefNum}
                    onChange={(e) => setReceiptRefNum(e.target.value)}
                    placeholder="Mã GD / FT..."
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Lý do thu tiền
                </label>
                <input
                  type="text"
                  value={receiptReason}
                  onChange={(e) => setReceiptReason(e.target.value)}
                  placeholder="Diễn giải thu tiền..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setReceiptTargetCustomer(null)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Lập phiếu thu & Trừ nợ
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 4: TẠO PHIẾU CHI CHO NCC */}
      {/* ======================================================== */}
      {paymentTargetSupplier && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <form
            onSubmit={handleConfirmCreatePayment}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-emerald-600" />
                  Lập Phiếu Chi / Thanh Toán NCC
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Đối tác nhận: {paymentTargetSupplier.supplierName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setPaymentTargetSupplier(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Số tiền chi (VND) *
                </label>
                <input
                  type="number"
                  min={1000}
                  value={paymentAmount}
                  onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold text-base outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Tài khoản trích tiền *
                </label>
                <select
                  value={paymentChannel}
                  onChange={(e) => setPaymentChannel(e.target.value as PaymentChannel)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                >
                  <option value="Vietcombank (0011004321999)">Vietcombank (0011004321999)</option>
                  <option value="Techcombank (19033321456011)">Techcombank (19033321456011)</option>
                  <option value="MB Bank (0888666999)">MB Bank (0888666999)</option>
                  <option value="Tiền mặt tại quỹ">Tiền mặt tại quỹ chính</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Mã tham chiếu / Ủy nhiệm chi
                </label>
                <input
                  type="text"
                  value={paymentRefNum}
                  onChange={(e) => setPaymentRefNum(e.target.value)}
                  placeholder="Số UNC hoặc mã giao dịch..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Lý do chi tiền
                </label>
                <input
                  type="text"
                  value={paymentReason}
                  onChange={(e) => setPaymentReason(e.target.value)}
                  placeholder="Diễn giải nội dung chi..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setPaymentTargetSupplier(null)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Xác nhận chi tiền
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 5: CHỨNG TỪ ĐIỀU CHỈNH CÔNG NỢ */}
      {/* ======================================================== */}
      {isAdjustmentModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <form
            onSubmit={handleConfirmAdjustment}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-emerald-600" />
                  Lập Chứng Từ Điều Chỉnh Công Nợ
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Xử lý giảm trừ chiết khấu, trả hàng, bù trừ hoặc xử lý nợ khó đòi
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsAdjustmentModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Đối tượng điều chỉnh
                  </label>
                  <select
                    value={adjPartnerType}
                    onChange={(e) => {
                      const val = e.target.value as 'customer' | 'supplier';
                      setAdjPartnerType(val);
                      setAdjPartnerId(
                        val === 'customer'
                          ? customerDebts[0]?.customerId || ''
                          : supplierDebts[0]?.supplierId || ''
                      );
                    }}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  >
                    <option value="customer">Khách hàng (Phải thu)</option>
                    <option value="supplier">Nhà cung cấp (Phải trả)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Chọn đối tác *
                  </label>
                  <select
                    value={adjPartnerId}
                    onChange={(e) => setAdjPartnerId(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  >
                    {adjPartnerType === 'customer'
                      ? customerDebts.map((c) => (
                          <option key={c.customerId} value={c.customerId}>
                            {c.customerName}
                          </option>
                        ))
                      : supplierDebts.map((s) => (
                          <option key={s.supplierId} value={s.supplierId}>
                            {s.supplierName}
                          </option>
                        ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Chiều hướng điều chỉnh
                  </label>
                  <select
                    value={adjDirection}
                    onChange={(e) => setAdjDirection(e.target.value as 'increase' | 'decrease')}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  >
                    <option value="decrease">Giảm công nợ (Chiết khấu / Trả hàng)</option>
                    <option value="increase">Tăng công nợ (Phí bổ sung / Phạt vi phạm)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Số tiền điều chỉnh (VND) *
                  </label>
                  <input
                    type="number"
                    min={1000}
                    value={adjAmount}
                    onChange={(e) => setAdjAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Lý do điều chỉnh (kèm số biên bản / thỏa thuận) *
                </label>
                <textarea
                  rows={2}
                  required
                  value={adjReason}
                  onChange={(e) => setAdjReason(e.target.value)}
                  placeholder="Ghi rõ căn cứ điều chỉnh công nợ..."
                  className="w-full p-2.5 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsAdjustmentModalOpen(false)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Tạo chứng từ điều chỉnh
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL 6: CÀI ĐẶT HẠN MỨC CÔNG NỢ */}
      {/* ======================================================== */}
      {creditLimitModalCustomer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <form
            onSubmit={handleSaveCreditLimit}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Sliders className="w-5 h-5 text-emerald-600" />
                  Hạn mức tín dụng & Thời hạn nợ
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Khách hàng: {creditLimitModalCustomer.customerName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setCreditLimitModalCustomer(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Hạn mức công nợ tối đa (VND)
                </label>
                <input
                  type="number"
                  min={0}
                  step={10000000}
                  value={editLimitVal}
                  onChange={(e) => setEditLimitVal(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold text-sm outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Thời hạn công nợ (Số ngày)
                </label>
                <input
                  type="number"
                  min={0}
                  max={120}
                  value={editTermDays}
                  onChange={(e) => setEditTermDays(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>

              <div className="pt-2">
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editBlockOrder}
                    onChange={(e) => setEditBlockOrder(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded"
                  />
                  <span className="text-xs text-slate-700 dark:text-slate-300 font-medium">
                    Chặn tạo đơn hàng mới khi khách hàng vượt hạn mức hoặc có nợ quá hạn
                  </span>
                </label>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setCreditLimitModalCustomer(null)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Lưu cấu hình hạn mức
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Modal: Bảng Tính Dự Phòng Nợ Phải Thu Khó Đòi */}
      {isBadDebtModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-800 rounded-xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-700 text-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-700 mb-4">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-slate-900 dark:text-white text-base">
                  Bảng Tính Dự Phòng Nợ Phải Thu Khó Đòi (Kỳ Hiện Tại)
                </h3>
              </div>
              <button
                onClick={() => setIsBadDebtModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 rounded-lg border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-200 text-xs mb-4">
              Công thức trích lập theo mốc tuổi nợ quá hạn: Quá hạn 1-30 ngày: 30% | 31-60 ngày: 50% | 61-90 ngày: 70% | Trên 90 ngày: 100%. Kế toán rà soát và bấm xác nhận để ghi nhận vào báo cáo quản trị.
            </div>

            <div className="overflow-x-auto max-h-80 border rounded-lg border-slate-200 dark:border-slate-700 mb-4">
              <table className="w-full text-left">
                <thead className="bg-slate-50 dark:bg-slate-700/60 font-bold text-slate-600 dark:text-slate-300 sticky top-0">
                  <tr>
                    <th className="p-2.5">Khách hàng</th>
                    <th className="p-2.5 text-right">Tổng nợ</th>
                    <th className="p-2.5 text-right text-rose-600">Nợ quá hạn</th>
                    <th className="p-2.5">Khung tuổi nợ</th>
                    <th className="p-2.5 text-center">Tỷ lệ (%)</th>
                    <th className="p-2.5 text-right text-amber-600">Dự phòng cần trích</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                  {badDebtProvisions.map((item) => (
                    <tr key={item.customerId} className="hover:bg-slate-50/50">
                      <td className="p-2.5">
                        <div className="font-bold text-slate-900 dark:text-white">{item.customerName}</div>
                        <span className="font-mono text-[10px] text-slate-400">{item.customerCode}</span>
                      </td>
                      <td className="p-2.5 text-right font-mono font-medium">
                        {item.closingDebt.toLocaleString()} đ
                      </td>
                      <td className="p-2.5 text-right font-mono font-bold text-rose-600">
                        {item.overdueDebt.toLocaleString()} đ
                      </td>
                      <td className="p-2.5 text-slate-600 dark:text-slate-300">
                        {item.tierLabel}
                      </td>
                      <td className="p-2.5 text-center font-bold font-mono">
                        {(item.provisionRate * 100).toFixed(0)}%
                      </td>
                      <td className="p-2.5 text-right font-mono font-bold text-amber-600">
                        {item.provisionAmount.toLocaleString()} đ
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="flex items-center justify-between p-3.5 bg-slate-100 dark:bg-slate-700/40 rounded-xl mb-4">
              <span className="font-bold text-slate-800 dark:text-slate-200">
                Tổng mức dự phòng đề xuất kỳ này:
              </span>
              <span className="text-base font-extrabold font-mono text-amber-600">
                {totalBadDebtProvision.toLocaleString()} VNĐ
              </span>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setIsBadDebtModalOpen(false)}
                className="px-4 py-2 border rounded-lg text-slate-600 dark:text-slate-300"
              >
                Đóng
              </button>
              <button
                type="button"
                onClick={() => {
                  showToast(
                    'Xác nhận dự phòng thành công',
                    `Đã lưu mức dự phòng ${totalBadDebtProvision.toLocaleString()} VNĐ vào báo cáo tài chính quản trị kỳ này.`
                  );
                  setIsBadDebtModalOpen(false);
                }}
                className="px-4 py-2 rounded-lg bg-amber-600 hover:bg-amber-700 text-white font-bold shadow-sm"
              >
                Xác nhận &amp; Lưu Dự Phòng Kỳ Này
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
