/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import {
  Building2,
  Users,
  Share2,
  CheckCircle2,
  ArrowRight,
  ArrowLeft,
  Copy,
  Check,
  Send,
  Sparkles,
  X,
  Layers,
} from 'lucide-react';

export const OnboardingWizardModal: React.FC = () => {
  const {
    showOnboardingWizard,
    setShowOnboardingWizard,
    currentCompany,
    currentAccount,
    createCompanyInvitation,
  } = useMultiTenant();

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [copiedLink, setCopiedLink] = useState(false);
  const [inviteEmailInput, setInviteEmailInput] = useState('');
  const [inviteSent, setInviteSent] = useState(false);

  // Default departments checklist in Step 2
  const [departments, setDepartments] = useState([
    { name: 'Ban Giám Đốc', selected: true },
    { name: 'Phòng Kinh Doanh (Sales Enterprise)', selected: true },
    { name: 'Phòng Kế Toán & Tài Chính', selected: true },
    { name: 'Phòng Kỹ Thuật & Dịch Vụ Khách Hàng', selected: true },
    { name: 'Phòng Kho & Logistics Vận Chuyển', selected: true },
    { name: 'Phòng Nhân Sự (HR & BHXH)', selected: true },
  ]);

  if (!showOnboardingWizard || !currentCompany) return null;

  const inviteLink = `https://app.apluscorp.vn/join?company=${currentCompany.code}&code=INV-${currentCompany.code.toUpperCase()}-ONBOARD`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(inviteLink);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleSendInviteEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmailInput.trim()) return;
    setInviteSent(true);
    setTimeout(() => {
      setInviteSent(false);
      setInviteEmailInput('');
    }, 3000);
  };

  const handleFinish = () => {
    setShowOnboardingWizard(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-white/10 rounded-2xl max-w-xl w-full shadow-2xl overflow-hidden flex flex-col text-slate-100 animate-in fade-in zoom-in-95 duration-200">
        {/* Modal Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between bg-white/[0.02]">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-500 flex items-center justify-center text-white font-bold text-sm shadow-md">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Thiết Lập Ban Đầu Cho Doanh Nghiệp
              </h2>
              <p className="text-xs text-slate-400">
                Công ty: <span className="font-semibold text-cyan-300">{currentCompany.name}</span> ({currentCompany.code})
              </p>
            </div>
          </div>
          <button
            onClick={handleFinish}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Đóng / Bỏ qua"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Stepper Progress */}
        <div className="px-6 pt-4 pb-2 bg-black/20 border-b border-white/5 flex items-center justify-between text-xs font-semibold">
          <div className={`flex items-center gap-1.5 ${step >= 1 ? 'text-blue-400' : 'text-slate-500'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 1 ? 'bg-blue-600 text-white' : 'bg-slate-700'}`}>1</span>
            <span>Thông tin công ty</span>
          </div>
          <div className="w-8 h-px bg-white/10" />
          <div className={`flex items-center gap-1.5 ${step >= 2 ? 'text-blue-400' : 'text-slate-500'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 2 ? 'bg-blue-600 text-white' : 'bg-slate-700'}`}>2</span>
            <span>Cơ cấu phòng ban</span>
          </div>
          <div className="w-8 h-px bg-white/10" />
          <div className={`flex items-center gap-1.5 ${step >= 3 ? 'text-blue-400' : 'text-slate-500'}`}>
            <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] ${step >= 3 ? 'bg-blue-600 text-white' : 'bg-slate-700'}`}>3</span>
            <span>Mời nhân sự</span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 text-xs">
          {/* BƯỚC 1: XÁC NHẬN THÔNG TIN CÔNG TY */}
          {step === 1 && (
            <div className="space-y-3.5">
              <div className="p-3.5 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-200">
                <span className="font-bold block mb-0.5">🎉 Chúc mừng bạn đã khởi tạo không gian làm việc thành công!</span>
                <span className="text-[11px] text-slate-300">
                  Bạn hiện là <strong>Quản trị công ty</strong> (nhóm quyền Quản trị hệ thống &amp; Giám đốc).
                  Dữ liệu của công ty được cách ly hoàn toàn theo mã định danh duy nhất.
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-slate-400 block text-[10px]">Tên pháp lý:</span>
                  <span className="font-bold text-white text-xs mt-0.5 block">{currentCompany.name}</span>
                </div>
                <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-slate-400 block text-[10px]">Mã định danh (Code):</span>
                  <span className="font-mono font-bold text-cyan-400 text-xs mt-0.5 block">{currentCompany.code}</span>
                </div>
                <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-slate-400 block text-[10px]">Mã số thuế:</span>
                  <span className="font-mono text-white text-xs mt-0.5 block">{currentCompany.taxCode || 'Chưa cập nhật'}</span>
                </div>
                <div className="p-3 rounded-xl bg-white/5 border border-white/10">
                  <span className="text-slate-400 block text-[10px]">Người đại diện / Quản trị:</span>
                  <span className="text-white text-xs mt-0.5 block">{currentAccount?.fullName}</span>
                </div>
              </div>

              <div className="text-[11px] text-slate-400">
                💡 <em>Lưu ý:</em> Bạn luôn có thể chỉnh sửa địa chỉ, logo, tài khoản ngân hàng và chính sách tại{' '}
                <strong className="text-slate-300">Cài đặt hệ thống &gt; Cấu hình hệ thống</strong>.
              </div>
            </div>
          )}

          {/* BƯỚC 2: CƠ CẤU PHÒNG BAN CƠ BẢN */}
          {step === 2 && (
            <div className="space-y-3">
              <p className="text-slate-300">
                Chọn các phòng ban ban đầu bạn muốn khởi tạo trong hệ thống nhân sự:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {departments.map((dept, idx) => (
                  <label
                    key={idx}
                    className={`p-3 rounded-xl border flex items-center gap-2.5 cursor-pointer transition-all ${
                      dept.selected
                        ? 'bg-blue-600/10 border-blue-500/40 text-white'
                        : 'bg-white/5 border-white/10 text-slate-400'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={dept.selected}
                      onChange={(e) => {
                        const next = [...departments];
                        next[idx].selected = e.target.checked;
                        setDepartments(next);
                      }}
                      className="rounded border-white/20 bg-black/30 text-blue-600 focus:ring-0"
                    />
                    <span className="font-semibold text-xs">{dept.name}</span>
                  </label>
                ))}
              </div>

              <p className="text-[11px] text-slate-400 mt-2">
                Bộ mẫu nhóm quyền tương ứng (Admin, Giám đốc, Sales, Kế toán, Kỹ thuật, Kho) đã được tự động seed sẵn.
              </p>
            </div>
          )}

          {/* BƯỚC 3: MỜI NHÂN SỰ ĐẦU TIÊN */}
          {step === 3 && (
            <div className="space-y-4">
              <p className="text-slate-300">
                Sao chép liên kết bên dưới để gửi cho đồng nghiệp hoặc đối tác tham gia ngay vào không gian làm việc:
              </p>

              <div className="p-3 rounded-xl bg-black/30 border border-white/10 space-y-2">
                <span className="text-[10px] text-slate-400 block font-semibold uppercase">
                  Liên kết mời tham gia (Mã công ty đã điền sẵn):
                </span>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    readOnly
                    value={inviteLink}
                    className="flex-1 px-3 py-2 rounded-lg border border-white/10 bg-black/40 text-slate-300 font-mono text-[11px] select-all focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={handleCopyLink}
                    className="px-3.5 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 transition-colors"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedLink ? 'Đã sao chép' : 'Sao chép'}</span>
                  </button>
                </div>
              </div>

              {/* Gửi email giả định */}
              <form onSubmit={handleSendInviteEmail} className="pt-2 border-t border-white/10 space-y-2">
                <span className="text-[11px] font-semibold text-slate-300 block">
                  Hoặc gửi thư mời trực tiếp qua Email:
                </span>
                <div className="flex items-center gap-2">
                  <input
                    type="email"
                    value={inviteEmailInput}
                    onChange={(e) => setInviteEmailInput(e.target.value)}
                    placeholder="dongnghiep@congty.com"
                    className="flex-1 px-3 py-2 rounded-lg border border-white/10 bg-black/30 text-white placeholder-slate-500 text-xs focus:outline-hidden focus:border-blue-400"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-lg bg-white/10 hover:bg-white/20 text-white font-semibold text-xs flex items-center gap-1.5 shrink-0 transition-colors"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Gửi lời mời</span>
                  </button>
                </div>
                {inviteSent && (
                  <p className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1 mt-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Đã tạo lời mời thành công và ghi nhận vào danh sách chờ kích hoạt.</span>
                  </p>
                )}
              </form>
            </div>
          )}
        </div>

        {/* Modal Footer Controls */}
        <div className="p-5 border-t border-white/10 bg-white/[0.02] flex items-center justify-between text-xs">
          <button
            type="button"
            onClick={handleFinish}
            className="text-slate-400 hover:text-slate-200 transition-colors font-medium"
          >
            Bỏ qua thiết lập &amp; Vào làm việc ngay
          </button>

          <div className="flex items-center gap-2">
            {step > 1 && (
              <button
                type="button"
                onClick={() => setStep((s) => (s - 1) as any)}
                className="px-3.5 py-2 rounded-xl border border-white/10 hover:bg-white/5 text-slate-300 font-semibold flex items-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Quay lại</span>
              </button>
            )}

            {step < 3 ? (
              <button
                type="button"
                onClick={() => setStep((s) => (s + 1) as any)}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold flex items-center gap-1.5 shadow-md shadow-blue-500/20"
              >
                <span>Tiếp tục</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            ) : (
              <button
                type="button"
                onClick={handleFinish}
                className="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold flex items-center gap-1.5 shadow-md shadow-emerald-500/20"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Hoàn Tất Thiết Lập &amp; Khởi Động CRM</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
