import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { Lead } from '../types/crm';
import {
  Search,
  Plus,
  Filter,
  Download,
  Trash2,
  Edit,
  ArrowRightCircle,
  FileCode,
  CheckCircle,
  X,
  Phone,
  Mail,
  Building,
  Star,
  Target,
  GitBranch,
  Table as TableIcon,
  Kanban,
  Flame,
  AlertTriangle,
  UserCheck,
  Send,
  Calendar,
  Clock,
  Briefcase,
  ChevronRight,
  ExternalLink,
} from 'lucide-react';

export const LeadsView: React.FC = () => {
  const {
    leads,
    addLead,
    updateLead,
    deleteLead,
    convertLeadToOpportunity,
    hasPermission,
    language,
    themeDef,
    openScreenSpec,
    t,
    setActiveModule,
    showToast,
  } = useCRM();

  const isVi = language === 'vi';

  // Flexible Lark-style views
  type LeadViewTab = 'table' | 'kanban' | 'hot-leads' | 'at-risk' | 'my-leads';
  const [activeTab, setActiveTab] = useState<LeadViewTab>('table');

  // Filters & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [sourceFilter, setSourceFilter] = useState<string>('all');

  // Side Panel Selected Lead State
  const [selectedLead, setSelectedLead] = useState<Lead | null>(leads[0] || null);
  const [sidePanelTab, setSidePanelTab] = useState<'overview' | 'activities' | 'notes'>('overview');

  // Modal State for create / edit
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);

  // Form Fields
  const [formData, setFormData] = useState({
    fullName: '',
    title: 'Giám đốc / Trưởng phòng',
    company: '',
    phone: '',
    email: '',
    source: 'Website' as Lead['source'],
    status: 'Mới' as Lead['status'],
    score: 80,
    estimatedValue: 500000000,
    assignedTo: 'Trần Minh Đức',
    assignedToId: 'usr-2',
    notes: '',
  });

  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const canCreate = hasPermission('leads', 'create');
  const canEdit = hasPermission('leads', 'edit');
  const canDelete = hasPermission('leads', 'delete');
  const canExport = hasPermission('leads', 'export');

  // Filtered Leads
  const filteredLeads = leads.filter((lead) => {
    const matchesSearch =
      lead.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.phone.includes(searchTerm) ||
      lead.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.email.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || lead.status === statusFilter;
    const matchesSource = sourceFilter === 'all' || lead.source === sourceFilter;

    // View tab filters
    if (activeTab === 'hot-leads') {
      return matchesSearch && matchesStatus && matchesSource && lead.score >= 80;
    }
    if (activeTab === 'at-risk') {
      return matchesSearch && matchesStatus && matchesSource && (lead.status === 'Mới' || lead.status === 'Đang liên hệ');
    }
    if (activeTab === 'my-leads') {
      return matchesSearch && matchesStatus && matchesSource && lead.assignedTo.includes('Trần Minh Đức');
    }

    return matchesSearch && matchesStatus && matchesSource;
  });

  const openCreateModal = () => {
    setEditingLead(null);
    setFormData({
      fullName: '',
      title: 'Giám đốc Mua hàng',
      company: '',
      phone: '',
      email: '',
      source: 'Website',
      status: 'Mới',
      score: 75,
      estimatedValue: 450000000,
      assignedTo: 'Trần Minh Đức',
      assignedToId: 'usr-2',
      notes: '',
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const openEditModal = (lead: Lead) => {
    setEditingLead(lead);
    setFormData({
      fullName: lead.fullName,
      title: lead.title,
      company: lead.company,
      phone: lead.phone,
      email: lead.email,
      source: lead.source,
      status: lead.status,
      score: lead.score,
      estimatedValue: lead.estimatedValue,
      assignedTo: lead.assignedTo,
      assignedToId: lead.assignedToId,
      notes: lead.notes,
    });
    setFormErrors({});
    setIsModalOpen(true);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!formData.fullName.trim()) errors.fullName = isVi ? 'Họ tên không được để trống' : 'Full name is required';
    if (!formData.company.trim()) errors.company = isVi ? 'Tên doanh nghiệp là bắt buộc' : 'Company name is required';
    
    const phoneRegex = /^(0[3|5|7|8|9])+([0-9]{8})$/;
    const cleanPhone = formData.phone.replace(/\s+/g, '');
    if (!phoneRegex.test(cleanPhone)) {
      errors.phone = isVi ? 'Số điện thoại VN không hợp lệ' : 'Valid 10-digit VN phone required';
    }

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(formData.email)) {
      errors.email = isVi ? 'Hòm thư Email không đúng chuẩn RFC 5322' : 'Valid email required';
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    if (editingLead) {
      updateLead(editingLead.id, formData);
      if (selectedLead?.id === editingLead.id) {
        setSelectedLead({ ...editingLead, ...formData });
      }
    } else {
      addLead(formData);
    }
    setIsModalOpen(false);
  };

  const exportToCSV = () => {
    const headers = ['Mã Lead', 'Họ tên', 'Doanh nghiệp', 'Số điện thoại', 'Email', 'Nguồn', 'Trạng thái', 'Điểm', 'Giá trị dự kiến'];
    const rows = filteredLeads.map((l) => [
      l.code,
      l.fullName,
      `"${l.company}"`,
      l.phone,
      l.email,
      l.source,
      l.status,
      l.score,
      l.estimatedValue,
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Leads_Export_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const renderStatus = (status: Lead['status']) => {
    switch (status) {
      case 'Mới':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-sky-600 dark:text-sky-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-sky-500 shrink-0" />
            <span>Mới</span>
          </span>
        );
      case 'Đang liên hệ':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-600 dark:text-amber-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0" />
            <span>Đang liên hệ</span>
          </span>
        );
      case 'Đạt chuẩn':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#3661C9] dark:text-sky-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3661C9] shrink-0" />
            <span>Đạt chuẩn</span>
          </span>
        );
      case 'Đã chuyển đổi':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 shrink-0" />
            <span>Đã chuyển đổi</span>
          </span>
        );
      case 'Không tiềm năng':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 shrink-0" />
            <span>Không tiềm năng</span>
          </span>
        );
    }
  };

  const formatVND = (num: number) => {
    if (num >= 1000000000) return (num / 1000000000).toFixed(1) + ' Tỷ ₫';
    if (num >= 1000000) return (num / 1000000).toFixed(0) + ' Tr ₫';
    return num.toLocaleString() + ' ₫';
  };

  const handleNextBestActionExecute = (lead: Lead) => {
    showToast(
      'Thực hiện thành công',
      `Đã tạo công việc theo dõi & lịch gọi cho ${lead.fullName} (${lead.company})`
    );
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
              {t.leads}
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-200 dark:bg-[#001633] text-slate-700 dark:text-sky-300 font-mono font-bold">
              {filteredLeads.length} records
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            {isVi
              ? 'Không gian làm việc: Thu thập, đánh giá và chuyển đổi Lead thành Cơ hội thương mại.'
              : 'Nurture, score, and convert qualified leads into active deal pipeline opportunities.'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 flex-wrap">
          {canExport && (
            <button
              onClick={exportToCSV}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-sky-900 hover:bg-slate-100 dark:hover:bg-[#001633] text-xs font-medium text-slate-700 dark:text-slate-300 transition-colors whitespace-nowrap shrink-0"
            >
              <Download className="w-3.5 h-3.5 shrink-0" />
              <span>{t.export}</span>
            </button>
          )}

          {canCreate && (
            <button
              onClick={openCreateModal}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white text-xs font-semibold transition-colors shadow-xs whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5 shrink-0" />
              <span>{isVi ? 'Tạo Lead' : 'New Lead'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Lark-style Workspace Navigation Tabs & Filter Bar */}
      <div className="p-2.5 rounded-2xl bg-white dark:bg-[#001226] border border-slate-200 dark:border-sky-900/40 space-y-2.5 shadow-2xs">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 dark:border-sky-950 pb-2">
          {/* View Modes Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
            <button
              onClick={() => setActiveTab('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                activeTab === 'table'
                  ? 'bg-[#F0F7FD] dark:bg-[#001633] text-[#002659] dark:text-sky-300 border border-[#3661C9]/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <TableIcon className="w-3.5 h-3.5 text-[#3661C9]" />
              <span>{isVi ? 'Bảng dữ liệu' : 'Table View'}</span>
            </button>

            <button
              onClick={() => setActiveTab('kanban')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                activeTab === 'kanban'
                  ? 'bg-[#F0F7FD] dark:bg-[#001633] text-[#002659] dark:text-sky-300 border border-[#3661C9]/20'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Kanban className="w-3.5 h-3.5 text-purple-600" />
              <span>Kanban</span>
            </button>

            <button
              onClick={() => setActiveTab('hot-leads')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                activeTab === 'hot-leads'
                  ? 'bg-amber-50 dark:bg-amber-950/60 text-[#E96F22] border border-amber-300/40'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Flame className="w-3.5 h-3.5 text-[#E96F22]" />
              <span>{isVi ? 'Hot Leads (Điểm >= 80)' : 'Hot Leads'}</span>
            </button>

            <button
              onClick={() => setActiveTab('at-risk')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                activeTab === 'at-risk'
                  ? 'bg-rose-50 dark:bg-rose-950/60 text-rose-600 border border-rose-300/40'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
              <span>{isVi ? 'Cần xử lý (At Risk)' : 'At Risk'}</span>
            </button>

            <button
              onClick={() => setActiveTab('my-leads')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                activeTab === 'my-leads'
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 border border-emerald-300/40'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isVi ? 'Lead của tôi' : 'My Leads'}</span>
            </button>
          </div>
        </div>

        {/* Search & Status Filters */}
        <div className="flex flex-col md:flex-row gap-2.5 items-stretch md:items-center justify-between">
          <div className="relative flex-1 max-w-md">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={isVi ? 'Tìm kiếm tên, công ty, SĐT, mã Lead...' : 'Search by name, company, phone, code...'}
              className="w-full text-xs pl-8 pr-3 py-2 rounded-xl border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-hidden"
            />
          </div>

          <div className="flex items-center gap-2">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs py-2 px-3 rounded-xl border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-700 dark:text-slate-200 focus:outline-hidden"
            >
              <option value="all">{isVi ? 'Tất cả trạng thái' : 'All Status'}</option>
              <option value="Mới">Mới</option>
              <option value="Đang liên hệ">Đang liên hệ</option>
              <option value="Đạt chuẩn">Đạt chuẩn</option>
              <option value="Đã chuyển đổi">Đã chuyển đổi</option>
              <option value="Không tiềm năng">Không tiềm năng</option>
            </select>

            <select
              value={sourceFilter}
              onChange={(e) => setSourceFilter(e.target.value)}
              className="text-xs py-2 px-3 rounded-xl border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-700 dark:text-slate-200 focus:outline-hidden"
            >
              <option value="all">{isVi ? 'Tất cả nguồn' : 'All Sources'}</option>
              <option value="Website">Website</option>
              <option value="Facebook">Facebook</option>
              <option value="Zalo">Zalo</option>
              <option value="Referral">Referral</option>
              <option value="Exhibition">Triển lãm</option>
              <option value="Cold Call">Cold Call</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Container: Workspace Data + Right Side Detail Panel */}
      <div className="flex flex-col xl:flex-row gap-4 items-start">
        {/* Workspace Table / Kanban */}
        <div className="flex-1 w-full min-w-0">
          {activeTab === 'kanban' ? (
            /* Kanban View - Horizontal swipeable on mobile */
            <div className="flex sm:grid sm:grid-cols-2 lg:grid-cols-4 gap-3.5 overflow-x-auto pb-3 snap-x snap-mandatory scroll-smooth">
              {(['Mới', 'Đang liên hệ', 'Đạt chuẩn', 'Đã chuyển đổi'] as Lead['status'][]).map(
                (stage) => {
                  const stageLeads = filteredLeads.filter((l) => l.status === stage);
                  return (
                    <div
                      key={stage}
                      className="w-[270px] sm:w-auto shrink-0 sm:shrink snap-start p-3 rounded-2xl bg-slate-100/70 dark:bg-[#001226] border border-slate-200 dark:border-sky-900/40 flex flex-col min-h-[420px]"
                    >
                      <div className="flex items-center justify-between mb-3 px-1">
                        <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-tight">
                          {stage}
                        </span>
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white dark:bg-[#001633] text-slate-600 dark:text-sky-300 font-bold border border-slate-200 dark:border-sky-900">
                          {stageLeads.length}
                        </span>
                      </div>

                      <div className="space-y-2.5 flex-1 overflow-y-auto">
                        {stageLeads.map((lead) => (
                          <div
                            key={lead.id}
                            onClick={() => setSelectedLead(lead)}
                            className={`p-3.5 rounded-xl bg-white dark:bg-[#001633] border cursor-pointer transition-all shadow-2xs hover:border-[#3661C9] ${
                              selectedLead?.id === lead.id
                                ? 'border-[#3661C9] dark:border-sky-400 ring-2 ring-[#3661C9]/20'
                                : 'border-slate-200 dark:border-sky-900/50'
                            }`}
                          >
                            <div className="flex items-center justify-between text-[11px] mb-1">
                              <span className="font-mono text-slate-400 font-semibold">{lead.code}</span>
                              <span className="font-bold text-[#E96F22] flex items-center gap-0.5">
                                <Star className="w-3 h-3" /> {lead.score}/100
                              </span>
                            </div>
                            <div className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">
                              {lead.fullName}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                              {lead.company}
                            </div>

                            <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-sky-950 flex items-center justify-between text-[10px] text-slate-400">
                              <span className="font-semibold text-slate-700 dark:text-slate-300">
                                {formatVND(lead.estimatedValue)}
                              </span>
                              <span>{lead.assignedTo.split(' ').pop()}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                }
              )}
            </div>
          ) : (
            /* Table & Mobile Card View */
            <div className="rounded-2xl bg-white dark:bg-[#001226] border border-slate-200 dark:border-sky-900/40 overflow-hidden shadow-2xs">
              {/* Mobile View: Touch-Friendly Card List (md:hidden) */}
              <div className="block md:hidden divide-y divide-slate-100 dark:divide-sky-950">
                {filteredLeads.length === 0 ? (
                  <div className="text-center py-10 text-slate-400 text-xs">
                    {isVi ? 'Không tìm thấy khách hàng tiềm năng' : 'No matching leads found'}
                  </div>
                ) : (
                  filteredLeads.map((lead) => {
                    const isSelected = selectedLead?.id === lead.id;
                    return (
                      <div
                        key={lead.id}
                        onClick={() => setSelectedLead(lead)}
                        className={`p-3.5 space-y-2 cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-[#F0F7FD] dark:bg-[#001633]'
                            : 'hover:bg-slate-50 dark:hover:bg-[#001633]/60'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <div className="font-semibold text-xs text-slate-900 dark:text-slate-100 truncate">
                              {lead.fullName}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                              {lead.title} • {lead.company}
                            </div>
                          </div>
                          <div className="shrink-0">{renderStatus(lead.status)}</div>
                        </div>

                        <div className="flex items-center justify-between text-[11px] pt-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-[10px] text-slate-400 font-semibold">{lead.code}</span>
                            <span className="font-semibold text-[#002659] dark:text-sky-300 font-mono">
                              {formatVND(lead.estimatedValue)}
                            </span>
                          </div>

                          <div className="flex items-center gap-1.5 font-bold text-xs text-[#E96F22] font-mono">
                            <Star className="w-3 h-3" />
                            <span>{lead.score}/100</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-sky-950/60 text-[10px] text-slate-400">
                          <span>{lead.assignedTo}</span>
                          <span className="text-[#3661C9] font-medium flex items-center gap-0.5">
                            Chi tiết <ChevronRight className="w-3 h-3" />
                          </span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Desktop / Tablet View: Rich Lark Base Table (hidden md:block) */}
              <div className="hidden md:block overflow-x-auto">
                <table className="w-full text-left text-xs divide-y divide-slate-100 dark:divide-sky-950">
                  <thead className="bg-slate-50 dark:bg-[#001633] text-slate-500 dark:text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                    <tr>
                      <th className="py-3 px-3.5">Mã & Khách hàng</th>
                      <th className="py-3 px-3">Doanh nghiệp</th>
                      <th className="py-3 px-3">Điểm tiềm năng</th>
                      <th className="py-3 px-3">Trạng thái</th>
                      <th className="py-3 px-3">Giá trị dự kiến</th>
                      <th className="py-3 px-3">Phụ trách</th>
                      <th className="py-3 px-3 text-right">Thao tác</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-sky-950">
                    {filteredLeads.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="text-center py-12 text-slate-400">
                          {isVi ? 'Không tìm thấy khách hàng tiềm năng phù hợp' : 'No matching leads found'}
                        </td>
                      </tr>
                    ) : (
                      filteredLeads.map((lead) => {
                        const isSelected = selectedLead?.id === lead.id;
                        return (
                          <tr
                            key={lead.id}
                            onClick={() => setSelectedLead(lead)}
                            className={`cursor-pointer transition-colors ${
                              isSelected
                                ? 'bg-[#F0F7FD] dark:bg-[#001633]'
                                : 'hover:bg-slate-50/80 dark:hover:bg-[#001633]/60'
                            }`}
                          >
                            <td className="py-3 px-3.5">
                              <div className="font-semibold text-slate-900 dark:text-slate-100">
                                {lead.fullName}
                              </div>
                              <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                                {lead.code} • {lead.source}
                              </div>
                            </td>

                            <td className="py-3 px-3">
                              <div className="font-medium text-slate-800 dark:text-slate-200 truncate max-w-[160px]">
                                {lead.company}
                              </div>
                              <div className="text-[10px] text-slate-400">{lead.title}</div>
                            </td>

                            <td className="py-3 px-3">
                              <div className="flex items-center gap-1.5">
                                <span
                                  className={`text-xs font-bold font-mono ${
                                    lead.score >= 80 ? 'text-[#E96F22]' : 'text-slate-700 dark:text-slate-300'
                                  }`}
                                >
                                  {lead.score}
                                </span>
                                <span className="text-[10px] text-slate-400">/100</span>
                                {lead.score >= 80 && (
                                  <span className="text-[9px] px-1 py-0.2 rounded-xs bg-amber-100 dark:bg-amber-950 text-[#E96F22] font-bold uppercase">
                                    Hot
                                  </span>
                                )}
                              </div>
                            </td>

                            <td className="py-3 px-3">{renderStatus(lead.status)}</td>

                            <td className="py-3 px-3 font-semibold text-slate-800 dark:text-slate-200">
                              {formatVND(lead.estimatedValue)}
                            </td>

                            <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                              {lead.assignedTo}
                            </td>

                            <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                              <div className="flex items-center justify-end gap-1">
                                {canEdit && (
                                  <button
                                    onClick={() => openEditModal(lead)}
                                    className="p-1 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100"
                                    title="Sửa"
                                  >
                                    <Edit className="w-3.5 h-3.5" />
                                  </button>
                                )}
                                {lead.status !== 'Đã chuyển đổi' && (
                                  <button
                                    onClick={() => convertLeadToOpportunity(lead.id)}
                                    className="p-1 rounded-md text-[#3661C9] hover:bg-blue-50 dark:hover:bg-sky-950"
                                    title="Chuyển đổi thành Deal"
                                  >
                                    <ArrowRightCircle className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* ======================= SECTION 15 & 42: RIGHT SIDE DETAIL PANEL ======================= */}
        {selectedLead && (
          <div className="w-full xl:w-96 rounded-2xl bg-white dark:bg-[#001226] border border-slate-200 dark:border-sky-900/40 p-4 sm:p-5 space-y-4 shadow-sm shrink-0">
            {/* Lead Avatar & Quick Info with Close Button */}
            <div className="flex items-start justify-between pb-3 border-b border-slate-100 dark:border-sky-950 gap-2">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-10 h-10 rounded-full bg-linear-to-br from-[#002659] to-[#3661C9] text-white flex items-center justify-center font-bold text-sm shadow-xs shrink-0">
                  {selectedLead.fullName.charAt(0)}
                </div>
                <div className="min-w-0">
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                    {selectedLead.fullName}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                    {selectedLead.title} • {selectedLead.company}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <div className="text-right">
                  {renderStatus(selectedLead.status)}
                </div>
                <button
                  onClick={() => setSelectedLead(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                  title="Đóng chi tiết"
                  aria-label="Đóng chi tiết"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* LEAD SCORE BREAKDOWN */}
            <div className="p-3.5 rounded-xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 space-y-2.5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-bold text-[#E96F22]">
                  <Star className="w-3.5 h-3.5" />
                  <span>ĐIỂM ĐÁNH GIÁ TIỀM NĂNG</span>
                </div>
                <div className="text-sm font-extrabold font-mono text-[#E96F22]">
                  {selectedLead.score} <span className="text-xs text-slate-400">/ 100</span>
                </div>
              </div>

              {/* Progress bars breakdown */}
              <div className="space-y-1.5 text-[10px] text-slate-600 dark:text-slate-300">
                <div className="flex items-center justify-between">
                  <span>Nhu cầu (Need)</span>
                  <span className="font-mono font-bold">95%</span>
                </div>
                <div className="w-full h-1.5 bg-amber-100 dark:bg-amber-900/40 rounded-full overflow-hidden">
                  <div className="h-full bg-[#E96F22] rounded-full" style={{ width: '95%' }} />
                </div>

                <div className="flex items-center justify-between pt-0.5">
                  <span>Ngân sách (Budget)</span>
                  <span className="font-mono font-bold">80%</span>
                </div>
                <div className="w-full h-1.5 bg-amber-100 dark:bg-amber-900/40 rounded-full overflow-hidden">
                  <div className="h-full bg-[#E96F22] rounded-full" style={{ width: '80%' }} />
                </div>

                <div className="flex items-center justify-between pt-0.5">
                  <span>Người quyết định (Decision Maker)</span>
                  <span className="font-mono font-bold">90%</span>
                </div>
                <div className="w-full h-1.5 bg-amber-100 dark:bg-amber-900/40 rounded-full overflow-hidden">
                  <div className="h-full bg-[#E96F22] rounded-full" style={{ width: '90%' }} />
                </div>

                <div className="flex items-center justify-between pt-0.5">
                  <span>Tiến độ (Timeline)</span>
                  <span className="font-mono font-bold">75%</span>
                </div>
                <div className="w-full h-1.5 bg-amber-100 dark:bg-amber-900/40 rounded-full overflow-hidden">
                  <div className="h-full bg-[#E96F22] rounded-full" style={{ width: '75%' }} />
                </div>
              </div>
            </div>

            {/* GỢI Ý HÀNH ĐỘNG TIẾP THEO */}
            <div className="p-3 rounded-xl bg-blue-50/70 dark:bg-sky-950/40 border border-blue-200 dark:border-sky-800 space-y-2">
              <div className="text-[10px] uppercase font-bold text-[#3661C9] dark:text-sky-300 flex items-center gap-1">
                <span>HÀNH ĐỘNG TIẾP THEO ĐỀ XUẤT</span>
              </div>
              <p className="text-xs text-slate-800 dark:text-slate-200 font-medium">
                {isVi
                  ? `Khách hàng chưa phản hồi báo giá trong 2 ngày. Nên gọi follow-up và gửi tài liệu demo hôm nay.`
                  : `Customer has not replied to quote in 2 days. Recommend calling today.`}
              </p>
              <button
                onClick={() => handleNextBestActionExecute(selectedLead)}
                className="w-full py-1.5 rounded-lg bg-[#3661C9] hover:bg-[#294eb0] text-white text-xs font-semibold shadow-2xs transition-colors flex items-center justify-center gap-1.5"
              >
                <span>{isVi ? 'Thực hiện ngay' : 'Execute Action'}</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Action Bar */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                onClick={() => showToast('Cuộc gọi', `Đang kết nối tới ${selectedLead.phone}...`)}
                className="p-2 rounded-lg border border-slate-200 dark:border-sky-900 hover:bg-slate-50 dark:hover:bg-[#001633] flex items-center justify-center gap-1.5 font-medium text-slate-700 dark:text-slate-200"
              >
                <Phone className="w-3.5 h-3.5 text-[#3661C9]" />
                <span>{isVi ? 'Gọi điện' : 'Call'}</span>
              </button>

              <button
                onClick={() => showToast('Email', `Mở trình gửi email tới ${selectedLead.email}`)}
                className="p-2 rounded-lg border border-slate-200 dark:border-sky-900 hover:bg-slate-50 dark:hover:bg-[#001633] flex items-center justify-center gap-1.5 font-medium text-slate-700 dark:text-slate-200"
              >
                <Mail className="w-3.5 h-3.5 text-sky-600" />
                <span>Email</span>
              </button>

              <button
                onClick={() => convertLeadToOpportunity(selectedLead.id)}
                className="col-span-2 p-2 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white font-semibold flex items-center justify-center gap-1.5 shadow-2xs"
              >
                <Briefcase className="w-3.5 h-3.5" />
                <span>{isVi ? 'Chuyển đổi thành Cơ hội (Deal)' : 'Convert to Opportunity'}</span>
              </button>
            </div>

            {/* Detail Tabs */}
            <div className="space-y-3 pt-2">
              <div className="flex border-b border-slate-100 dark:border-sky-950 text-xs">
                <button
                  onClick={() => setSidePanelTab('overview')}
                  className={`pb-1.5 px-2 font-semibold transition-colors ${
                    sidePanelTab === 'overview'
                      ? 'border-b-2 border-[#002659] text-[#002659] dark:text-sky-400'
                      : 'text-slate-400'
                  }`}
                >
                  {isVi ? 'Tổng quan' : 'Overview'}
                </button>
                <button
                  onClick={() => setSidePanelTab('activities')}
                  className={`pb-1.5 px-2 font-semibold transition-colors ${
                    sidePanelTab === 'activities'
                      ? 'border-b-2 border-[#002659] text-[#002659] dark:text-sky-400'
                      : 'text-slate-400'
                  }`}
                >
                  {isVi ? 'Hoạt động' : 'Activities'}
                </button>
                <button
                  onClick={() => setSidePanelTab('notes')}
                  className={`pb-1.5 px-2 font-semibold transition-colors ${
                    sidePanelTab === 'notes'
                      ? 'border-b-2 border-[#002659] text-[#002659] dark:text-sky-400'
                      : 'text-slate-400'
                  }`}
                >
                  {isVi ? 'Ghi chú' : 'Notes'}
                </button>
              </div>

              {sidePanelTab === 'overview' && (
                <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
                  <div className="flex justify-between py-1 border-b border-slate-50 dark:border-sky-950">
                    <span className="text-slate-400">Số điện thoại:</span>
                    <span className="font-mono font-medium">{selectedLead.phone}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50 dark:border-sky-950">
                    <span className="text-slate-400">Hòm thư:</span>
                    <span className="truncate max-w-[170px]">{selectedLead.email}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50 dark:border-sky-950">
                    <span className="text-slate-400">Giá trị dự kiến:</span>
                    <span className="font-bold text-[#E96F22]">{formatVND(selectedLead.estimatedValue)}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50 dark:border-sky-950">
                    <span className="text-slate-400">Nhân sự phụ trách:</span>
                    <span className="font-medium">{selectedLead.assignedTo}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-50 dark:border-sky-950">
                    <span className="text-slate-400">Ngày tạo:</span>
                    <span>{selectedLead.createdAt}</span>
                  </div>
                </div>
              )}

              {sidePanelTab === 'activities' && (
                <div className="space-y-2 text-xs">
                  <div className="p-2 rounded-lg bg-slate-50 dark:bg-[#001633] space-y-0.5">
                    <div className="font-semibold text-slate-800 dark:text-slate-200">
                      Đã gửi Email Báo giá giải pháp CRM
                    </div>
                    <div className="text-[10px] text-slate-400">Hôm qua 14:30 • Trần Minh Đức</div>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-50 dark:bg-[#001633] space-y-0.5">
                    <div className="font-semibold text-slate-800 dark:text-slate-200">
                      Cuộc gọi tư vấn 12 phút
                    </div>
                    <div className="text-[10px] text-slate-400">28/09/2026 • Trần Minh Đức</div>
                  </div>
                </div>
              )}

              {sidePanelTab === 'notes' && (
                <div className="text-xs text-slate-600 dark:text-slate-400 p-2.5 rounded-lg bg-slate-50 dark:bg-[#001633] italic">
                  "{selectedLead.notes || 'Chưa có ghi chú bổ sung cho khách hàng này.'}"
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Create / Edit Lead Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-[#001226] rounded-2xl shadow-2xl border border-slate-200 dark:border-sky-900/50 p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-sky-950">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                {editingLead
                  ? isVi
                    ? 'Chỉnh sửa Khách hàng Tiềm năng'
                    : 'Edit Lead'
                  : isVi
                  ? 'Thêm Khách hàng Tiềm năng mới'
                  : 'New Lead'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-md text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    {isVi ? 'Họ và tên' : 'Full Name'} *
                  </label>
                  <input
                    type="text"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-900 dark:text-slate-100 focus:outline-hidden"
                  />
                  {formErrors.fullName && <div className="text-[10px] text-rose-500 mt-0.5">{formErrors.fullName}</div>}
                </div>

                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    {isVi ? 'Chức vụ' : 'Title'}
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-900 dark:text-slate-100 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  {isVi ? 'Tên doanh nghiệp' : 'Company'} *
                </label>
                <input
                  type="text"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-900 dark:text-slate-100 focus:outline-hidden"
                />
                {formErrors.company && <div className="text-[10px] text-rose-500 mt-0.5">{formErrors.company}</div>}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    {isVi ? 'Số điện thoại' : 'Phone'} *
                  </label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-900 dark:text-slate-100 focus:outline-hidden"
                  />
                  {formErrors.phone && <div className="text-[10px] text-rose-500 mt-0.5">{formErrors.phone}</div>}
                </div>

                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Email *
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-900 dark:text-slate-100 focus:outline-hidden"
                  />
                  {formErrors.email && <div className="text-[10px] text-rose-500 mt-0.5">{formErrors.email}</div>}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    {isVi ? 'Nguồn gốc' : 'Source'}
                  </label>
                  <select
                    value={formData.source}
                    onChange={(e) => setFormData({ ...formData, source: e.target.value as any })}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-900 dark:text-slate-100 focus:outline-hidden"
                  >
                    <option value="Website">Website</option>
                    <option value="Facebook">Facebook</option>
                    <option value="Zalo">Zalo</option>
                    <option value="Referral">Referral</option>
                    <option value="Exhibition">Exhibition</option>
                    <option value="Cold Call">Cold Call</option>
                  </select>
                </div>

                <div>
                  <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    {isVi ? 'Trạng thái' : 'Status'}
                  </label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-900 dark:text-slate-100 focus:outline-hidden"
                  >
                    <option value="Mới">Mới</option>
                    <option value="Đang liên hệ">Đang liên hệ</option>
                    <option value="Đạt chuẩn">Đạt chuẩn</option>
                    <option value="Đã chuyển đổi">Đã chuyển đổi</option>
                    <option value="Không tiềm năng">Không tiềm năng</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  {isVi ? 'Giá trị dự kiến (VNĐ)' : 'Estimated Value'}
                </label>
                <input
                  type="number"
                  value={formData.estimatedValue}
                  onChange={(e) => setFormData({ ...formData, estimatedValue: Number(e.target.value) })}
                  className="w-full p-2.5 rounded-lg border border-slate-200 dark:border-sky-900 bg-slate-50 dark:bg-[#001633] text-slate-900 dark:text-slate-100 focus:outline-hidden"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100 dark:border-sky-950">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-200 dark:border-sky-900 hover:bg-slate-50 text-slate-700 dark:text-slate-300"
                >
                  {isVi ? 'Hủy' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white font-semibold"
                >
                  {isVi ? 'Lưu thông tin' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
