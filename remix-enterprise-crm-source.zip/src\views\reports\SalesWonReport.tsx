import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { ReportFilterState } from '../../types/crm';
import { ReportFilterBar } from '../../components/reports/ReportFilterBar';
import { ExecutiveStatCard } from '../../components/reports/ReportCharts';
import { MOCK_WON_DEALS, MockWonDeal } from '../../data/mockReportsData';
import {
  Award,
  DollarSign,
  Clock,
  CircleDollarSign,
  Search,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  Eye,
  CheckCircle2,
  X,
} from 'lucide-react';

interface SalesWonReportProps {
  filter: ReportFilterState;
  onChangeFilter: (updated: Partial<ReportFilterState>) => void;
}

export const SalesWonReport: React.FC<SalesWonReportProps> = ({
  filter,
  onChangeFilter,
}) => {
  const { themeDef } = useCRM();
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<keyof MockWonDeal>('value');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedDeal, setSelectedDeal] = useState<MockWonDeal | null>(null);

  const itemsPerPage = 8;

  // Filter deals
  const filteredDeals = MOCK_WON_DEALS.filter((d) => {
    if (filter.teamId !== 'all' && d.teamId !== filter.teamId) return false;
    if (filter.salesRepId !== 'all' && d.repId !== filter.salesRepId) return false;
    if (filter.region !== 'all' && d.region !== filter.region) return false;
    if (filter.source !== 'all' && d.source !== filter.source) return false;
    if (filter.productId !== 'all' && d.productName !== filter.productId) return false;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const match =
        d.title.toLowerCase().includes(q) ||
        d.code.toLowerCase().includes(q) ||
        d.customerCompany.toLowerCase().includes(q) ||
        d.repName.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Sort deals
  const sortedDeals = [...filteredDeals].sort((a, b) => {
    let aVal = a[sortField];
    let bVal = b[sortField];
    if (typeof aVal === 'string') {
      return sortOrder === 'asc'
        ? (aVal as string).localeCompare(bVal as string)
        : (bVal as string).localeCompare(aVal as string);
    }
    return sortOrder === 'asc' ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number);
  });

  // Pagination
  const totalPages = Math.ceil(sortedDeals.length / itemsPerPage) || 1;
  const paginatedDeals = sortedDeals.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  // Top Statistics
  const totalWonCount = filteredDeals.length;
  const totalWonValue = filteredDeals.reduce((sum, d) => sum + d.value, 0);
  const avgWonValue = totalWonCount > 0 ? Math.round(totalWonValue / totalWonCount) : 0;
  const avgCycleDays = totalWonCount > 0 ? Math.round(filteredDeals.reduce((sum, d) => sum + d.cycleDays, 0) / totalWonCount) : 0;

  const handleSort = (field: keyof MockWonDeal) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  return (
    <div className="space-y-6">
      {/* Shared Filter Bar */}
      <ReportFilterBar
        filter={filter}
        onChangeFilter={onChangeFilter}
        reportTitle="Báo cáo Deal Thắng (Closed Won)"
      />

      {/* Top 4 Summary Cards (Executive Style: Chỉ hiển thị Tiêu đề và Con số, bấm ! xem giải thích) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <ExecutiveStatCard
          title="Tổng số Deal thắng"
          value={`${totalWonCount} deal`}
          icon={Award}
          iconColor="bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800"
          explanation="Tổng số lượng hợp đồng đã ký kết chính thức và chuyển sang trạng thái thành công."
        />

        <ExecutiveStatCard
          title="Tổng giá trị mang lại"
          value={`${(totalWonValue / 1000000000).toFixed(2)} Tỷ`}
          valueColor="text-sky-600 dark:text-sky-400"
          icon={DollarSign}
          iconColor="bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400 border-sky-200 dark:border-sky-800"
          explanation="Tổng giá trị hợp đồng đã hoàn tất đối soát và ghi nhận vào doanh số của kỳ."
        />

        <ExecutiveStatCard
          title="Giá trị trung bình / Deal"
          value={`${(avgWonValue / 1000000).toFixed(0)} Tr`}
          icon={CircleDollarSign}
          iconColor="bg-purple-50 dark:bg-purple-950/50 text-purple-600 dark:text-purple-400 border-purple-200 dark:border-purple-800"
          explanation="Quy mô giá trị giao dịch bình quân của mỗi thương vụ chốt thành công."
        />

        <ExecutiveStatCard
          title="Chu kỳ chốt trung bình"
          value={`${avgCycleDays} ngày`}
          valueColor="text-amber-600 dark:text-amber-400"
          icon={Clock}
          iconColor="bg-amber-50 dark:bg-amber-950/50 text-amber-600 dark:text-amber-400 border-amber-200 dark:border-amber-800"
          explanation="Thời gian bình quân từ lúc tạo cơ hội đến khi hoàn tất ký hợp đồng và nhận tiền đặt cọc."
        />
      </div>

      {/* Table Container with Search & Pagination */}
      <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-xs space-y-4`}>
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <h2 className="section-title">
            Danh sách Deal Thắng (Closed Won Deals)
          </h2>
        </div>

        {/* Search Toolbar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative max-w-sm w-full">
            <input
              type="text"
              placeholder="Tìm theo tên deal, mã, khách hàng, nhân viên..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-sky-500 focus:outline-hidden"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>

          <div className="text-xs text-slate-500">
            Hiển thị <span className="font-bold text-slate-800 dark:text-slate-200">{filteredDeals.length}</span> deal
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
              <tr>
                <th onClick={() => handleSort('code')} className="py-3 px-3 cursor-pointer hover:text-sky-600">
                  <div className="flex items-center gap-1">
                    Mã deal <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th onClick={() => handleSort('title')} className="py-3 px-3 cursor-pointer hover:text-sky-600">
                  <div className="flex items-center gap-1">
                    Tên deal <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3">Khách hàng</th>
                <th onClick={() => handleSort('value')} className="py-3 px-3 text-right cursor-pointer hover:text-sky-600">
                  <div className="flex items-center justify-end gap-1">
                    Giá trị <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3">Nhân viên phụ trách</th>
                <th onClick={() => handleSort('wonDate')} className="py-3 px-3 cursor-pointer hover:text-sky-600">
                  <div className="flex items-center gap-1">
                    Ngày chốt <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th onClick={() => handleSort('cycleDays')} className="py-3 px-3 text-center cursor-pointer hover:text-sky-600">
                  <div className="flex items-center justify-center gap-1">
                    Số ngày chốt <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3">Sản phẩm</th>
                <th className="py-3 px-3">Nguồn</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {paginatedDeals.map((deal) => (
                <tr
                  key={deal.id}
                  onClick={() => setSelectedDeal(deal)}
                  className="hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer transition-colors"
                >
                  <td className="py-3 px-3 font-mono text-[11px] font-bold text-sky-600 dark:text-sky-400">
                    {deal.code}
                  </td>
                  <td className="py-3 px-3">
                    <p className="font-bold text-slate-900 dark:text-white hover:text-sky-600 transition-colors">
                      {deal.title}
                    </p>
                  </td>
                  <td className="py-3 px-3">
                    <p className="font-semibold text-slate-800 dark:text-slate-200">{deal.customerCompany}</p>
                    <p className="text-[11px] text-slate-500">{deal.customerName}</p>
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {(deal.value / 1000000).toLocaleString('vi-VN')} Tr
                  </td>
                  <td className="py-3 px-3 text-slate-700 dark:text-slate-300">
                    <p className="font-medium">{deal.repName}</p>
                    <p className="text-[10px] text-slate-400">{deal.teamName.replace('Đội ', '')}</p>
                  </td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-400 font-mono">
                    {deal.wonDate}
                  </td>
                  <td className="py-3 px-3 text-center font-bold text-slate-800 dark:text-slate-200">
                    {deal.cycleDays} ngày
                  </td>
                  <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                    {deal.productName}
                  </td>
                  <td className="py-3 px-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {deal.source}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
          <span className="text-slate-500">
            Trang {currentPage} / {totalPages}
          </span>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Deal Details Modal / Drawer */}
      {selectedDeal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 dark:border-slate-800 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
              <div>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                  Deal Thắng (Won)
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1">
                  {selectedDeal.title}
                </h3>
                <span className="font-mono text-xs text-sky-600">{selectedDeal.code}</span>
              </div>
              <button
                onClick={() => setSelectedDeal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50">
                  <span className="text-slate-500">Khách hàng:</span>
                  <p className="font-bold text-slate-900 dark:text-white mt-0.5">{selectedDeal.customerCompany}</p>
                  <p className="text-slate-500">{selectedDeal.customerName}</p>
                </div>
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50">
                  <span className="text-slate-500">Giá trị hợp đồng:</span>
                  <p className="font-bold font-mono text-emerald-600 dark:text-emerald-400 text-base mt-0.5">
                    {(selectedDeal.value / 1000000).toLocaleString('vi-VN')} Tr
                  </p>
                  <span className="text-[10px] text-emerald-600 font-semibold">Đã thu tiền mặt đợt 1</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-500 text-[11px]">Ngày tạo:</span>
                  <p className="font-semibold">{selectedDeal.createdAt}</p>
                </div>
                <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-500 text-[11px]">Ngày chốt:</span>
                  <p className="font-semibold text-emerald-600">{selectedDeal.wonDate}</p>
                </div>
                <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                  <span className="text-slate-500 text-[11px]">Chu kỳ:</span>
                  <p className="font-semibold">{selectedDeal.cycleDays} ngày</p>
                </div>
              </div>

              <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50">
                <p><span className="text-slate-500">Nhân viên phụ trách:</span> <span className="font-bold">{selectedDeal.repName} ({selectedDeal.teamName})</span></p>
                <p className="mt-1"><span className="text-slate-500">Sản phẩm:</span> <span className="font-semibold">{selectedDeal.productName}</span></p>
                <p className="mt-1"><span className="text-slate-500">Nguồn khách hàng:</span> <span className="font-semibold">{selectedDeal.source}</span></p>
              </div>
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setSelectedDeal(null)}
                className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
