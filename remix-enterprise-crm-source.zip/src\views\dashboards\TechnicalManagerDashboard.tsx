import React from 'react';
import { useCRM } from '../../context/CRMContext';
import { useTechnical } from '../../context/TechnicalContext';
import {
  Wrench,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FolderKanban,
  FileText,
  Boxes,
  Users,
  ArrowRight,
  ChevronRight,
  ShieldAlert,
  Building,
} from 'lucide-react';

export const TechnicalManagerDashboard: React.FC = () => {
  const { currentUser, setActiveModule, showToast } = useCRM();
  const {
    projects,
    contracts,
    warrantyStockOuts,
    expiringContracts,
  } = useTechnical();

  const handleUpdateProjectStatus = (projectId: string, title: string) => {
    showToast('Kỹ thuật', `Cập nhật tiến độ dự án: ${title}`);
  };

  return (
    <div className="space-y-6 max-w-[1400px] mx-auto pb-12">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden border border-emerald-900/50">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-radial from-emerald-500/20 via-transparent to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.fullName}
              className="w-16 h-16 rounded-full border-2 border-emerald-400/80 object-cover shadow-lg shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight">
                  Chào anh {currentUser.fullName}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/30 text-emerald-200 border border-emerald-400/30">
                  Trưởng Phòng Kỹ Thuật (Technical Manager)
                </span>
              </div>
              <p className="text-slate-300 text-sm mt-1">
                Quản trị toàn bộ phân hệ Kỹ thuật: Thi công dự án, Nghiệm thu công trình, Định mức vật tư BOM, và Cam kết SLA bảo hành.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setActiveModule('technical-customers')}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-sm font-bold shadow-md transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Wrench className="w-4 h-4" />
              <span>Quản Lý Dự Án Kỹ Thuật</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. 4 Technical KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Dự án đang thi công */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Dự án đang triển khai
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <FolderKanban className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {projects.length} Dự án
            </div>
            <div className="text-xs text-slate-500 mt-1 flex items-center justify-between">
              <span>Đúng tiến độ:</span>
              <span className="font-bold text-emerald-600">
                {projects.filter((p) => p.status !== 'Tạm dừng').length} / {projects.length}
              </span>
            </div>
          </div>
        </div>

        {/* KPI 2: Tỷ lệ ký nghiệm thu */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Tỷ lệ ký nghiệm thu bàn giao
            </span>
            <div className="w-8 h-8 rounded-lg bg-sky-100 dark:bg-sky-950 text-sky-600 dark:text-sky-400 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-sky-600 dark:text-sky-400">
              92.5%
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Biên bản đã ký đủ điều kiện Kế toán xuất hóa đơn
            </div>
          </div>
        </div>

        {/* KPI 3: Bảo hành SLA khẩn cấp */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Đơn bảo hành SLA khẩn cấp
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-amber-600 dark:text-amber-400">
              3 Đơn
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Thời gian xử lý cam kết: &lt; 4 giờ làm việc
            </div>
          </div>
        </div>

        {/* KPI 4: Định mức BOM cấu hình */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Báo giá định mức BOM
            </span>
            <div className="w-8 h-8 rounded-lg bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center">
              <Boxes className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-purple-600 dark:text-purple-400">
              28 Bộ BOM
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Khớp mã linh kiện phần cứng kho tổng
            </div>
          </div>
        </div>
      </div>

      {/* 3. Danh sách Dự án thi công Kỹ thuật trọng điểm */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Dự án Kỹ thuật &amp; Thi công đang thực hiện
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Theo dõi tiến độ hoàn thành và tình trạng nghiệm thu bàn giao.
              </p>
            </div>
            <button
              onClick={() => setActiveModule('technical-master-planning')}
              className="text-xs font-semibold text-emerald-600 hover:underline flex items-center gap-1 cursor-pointer"
            >
              <span>Kế hoạch tổng thể</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="mt-4 space-y-4">
            {projects.slice(0, 5).map((proj) => (
              <div
                key={proj.id}
                className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850 hover:border-emerald-300 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs text-slate-400">{proj.code}</span>
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                        {proj.name}
                      </h4>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-500 mt-1">
                      <span className="flex items-center gap-1">
                        <Building className="w-3 h-3 text-slate-400" />
                        <span>{proj.customerName}</span>
                      </span>
                      <span>•</span>
                      <span>Kỹ sư trưởng: <strong>{proj.managerName}</strong></span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                        proj.status === 'Đang triển khai'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {proj.status}
                    </span>
                    <div className="text-xs text-slate-400 mt-1 font-mono">
                      Hạn: {proj.endDate}
                    </div>
                  </div>
                </div>

                <div className="mt-3">
                  <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 mb-1">
                    <span>Tiến độ thi công:</span>
                    <span className="font-bold font-mono text-emerald-600">{proj.progress}%</span>
                  </div>
                  <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                    <div
                      className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                      style={{ width: `${proj.progress}%` }}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Phím tắt phân hệ kỹ thuật */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-3">
              Phân hệ Kỹ thuật chuyên môn
            </h3>
            <div className="space-y-2 text-xs">
              {[
                { id: 'technical-customers', label: 'Hồ sơ kỹ thuật khách hàng', desc: 'Quản lý 30 cơ sở công trình' },
                { id: 'technical-quotations', label: 'Báo giá kỹ thuật & BOM', desc: 'Bóc tách cấu hình vật tư' },
                { id: 'technical-contracts', label: 'Hợp đồng kỹ thuật & Bảo trì', desc: 'SLA bảo dưỡng định kỳ' },
                { id: 'technical-warranty-stock-out', label: 'Xuất kho linh kiện bảo hành', desc: 'Lô vật tư thay thế' },
                { id: 'reports-technical', label: 'Báo cáo khối kỹ thuật', desc: 'Thống kê SLA & Nghiệm thu' },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => setActiveModule(m.id as any)}
                  className="w-full text-left p-3 rounded-lg border border-slate-200 dark:border-slate-800 hover:border-emerald-500 hover:bg-emerald-50/40 dark:hover:bg-emerald-950/20 transition-all flex items-center justify-between cursor-pointer group"
                >
                  <div>
                    <div className="font-bold text-slate-900 dark:text-white group-hover:text-emerald-600">
                      {m.label}
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{m.desc}</div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-transform" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
