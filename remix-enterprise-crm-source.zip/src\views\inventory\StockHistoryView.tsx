import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useWarehouse } from '../../context/WarehouseContext';
import { StockMove } from '../../data/mockWarehouseData';
import {
  History,
  Calendar,
  AlertTriangle,
  Search,
  Filter,
  FileSpreadsheet,
  Layers,
  Clock,
  ArrowRight,
  TrendingUp,
  X,
  Building,
  CheckCircle2,
  AlertCircle,
  Eye,
} from 'lucide-react';

export interface StockHistoryViewProps {
  viewMode?: 'warehouse' | 'logistics';
}

export const StockHistoryView: React.FC<StockHistoryViewProps> = ({ viewMode = 'warehouse' }) => {
  const { themeDef, showToast } = useCRM();
  const { warehouses, products, stockMoves } = useWarehouse();

  // 3 Tabs
  const [activeTab, setActiveTab] = useState<'transactions' | 'daily_summary' | 'as_of_date'>('transactions');

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedWarehouseId, setSelectedWarehouseId] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [onlyAbnormal, setOnlyAbnormal] = useState<boolean>(false);
  const [selectedSkuFilter, setSelectedSkuFilter] = useState<string>('all');
  const [selectedDateFilter, setSelectedDateFilter] = useState<string>('all');

  // Tab c: As of date target
  const [asOfDate, setAsOfDate] = useState<string>('2026-10-01');

  // Selected SKU for Right Drawer
  const [drawerSku, setDrawerSku] = useState<string | null>(null);

  // Filtered Stock Moves
  const filteredMoves = stockMoves.filter((m) => {
    if (selectedWarehouseId !== 'all' && m.warehouseId !== selectedWarehouseId) return false;
    if (selectedType !== 'all' && m.type !== selectedType) return false;
    if (selectedSkuFilter !== 'all' && m.sku !== selectedSkuFilter) return false;
    if (selectedDateFilter !== 'all' && m.date !== selectedDateFilter) return false;
    if (onlyAbnormal && !m.isAbnormal) return false;

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const match =
        m.sku.toLowerCase().includes(q) ||
        m.productName.toLowerCase().includes(q) ||
        m.refCode.toLowerCase().includes(q) ||
        m.performedBy.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });

  // Unique Dates for Calendar Heatmap & Daily Summary
  const sampleDates = [
    { date: '2026-09-28', count: 3, inQty: 10, outQty: 8 },
    { date: '2026-09-29', count: 5, inQty: 25, outQty: 14 },
    { date: '2026-09-30', count: 8, inQty: 40, outQty: 22 },
    { date: '2026-10-01', count: 4, inQty: 12, outQty: 16 },
    { date: '2026-10-02', count: 12, inQty: 154, outQty: 6 },
    { date: '2026-10-03', count: 9, inQty: 150, outQty: 15 },
    { date: '2026-10-04', count: 6, inQty: 2, outQty: 26 },
  ];

  // Daily Summary Data Calculation (Nhập - Xuất - Tồn)
  // Quy tắc: Tồn đầu ngày = Tồn cuối ngày hôm trước. Nếu lệch, tô đỏ!
  interface DailySummaryRow {
    date: string;
    openingStock: number;
    totalIn: number;
    totalOut: number;
    closingStock: number;
    closingValue: number;
    isDiscrepancy?: boolean;
  }

  const dailySummaryData: DailySummaryRow[] = [
    { date: '2026-09-28', openingStock: 520, totalIn: 10, totalOut: 8, closingStock: 522, closingValue: 1840000000 },
    { date: '2026-09-29', openingStock: 522, totalIn: 25, totalOut: 14, closingStock: 533, closingValue: 1890000000 },
    { date: '2026-09-30', openingStock: 533, totalIn: 40, totalOut: 22, closingStock: 551, closingValue: 1960000000 },
    { date: '2026-10-01', openingStock: 551, totalIn: 12, totalOut: 16, closingStock: 547, closingValue: 1945000000 },
    { date: '2026-10-02', openingStock: 547, totalIn: 154, totalOut: 6, closingStock: 695, closingValue: 2420000000 },
    { date: '2026-10-03', openingStock: 695, totalIn: 150, totalOut: 15, closingStock: 830, closingValue: 2680000000 },
    { date: '2026-10-04', openingStock: 830, totalIn: 2, totalOut: 26, closingStock: 806, closingValue: 2620000000 },
  ];

  // Tab c: As of date comparison
  const asOfDateProducts = products.map((p) => {
    const currentQty = Object.values(p.stocks).reduce((sum, v) => sum + v, 0);
    // Simulate stock on selected date
    const historicalQty = Math.max(0, currentQty + (p.sku === 'HW-SRV-DL380' ? 2 : p.sku === 'MED-GEL-CLEAN-500' ? 15 : -4));
    const variance = currentQty - historicalQty;
    return {
      ...p,
      currentQty,
      historicalQty,
      variance,
    };
  });

  const drawerProductData = products.find((p) => p.sku === drawerSku);

  return (
    <div className="space-y-6">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5">
            <span className="p-2 rounded-lg bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400 border border-purple-100 dark:border-purple-900/50">
              <History className="w-5 h-5" />
            </span>
            {viewMode === 'logistics' ? 'Lịch Sử Kho Theo Ngày (Góc nhìn Vận chuyển)' : 'Lịch sử kho theo ngày (Stock Movement History)'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {viewMode === 'logistics'
              ? 'Theo dõi diễn biến xuất nhập tồn theo ngày để điều phối kế hoạch giao nhận và cung ứng hàng hóa.'
              : 'Truy vết biến động kho bất biến, báo cáo Nhập - Xuất - Tồn và xem lại ảnh chụp tồn kho trong quá khứ'}
          </p>
        </div>

        {/* 3 Main Tabs Switcher */}
        <div className="inline-flex rounded-xl bg-slate-100 dark:bg-slate-800 p-1 text-xs">
          <button
            onClick={() => setActiveTab('transactions')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeTab === 'transactions'
                ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            a) Nhật ký giao dịch
          </button>
          <button
            onClick={() => setActiveTab('daily_summary')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeTab === 'daily_summary'
                ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            b) Tổng hợp theo ngày (N-X-T)
          </button>
          <button
            onClick={() => setActiveTab('as_of_date')}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeTab === 'as_of_date'
                ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-sky-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            c) Tồn kho tại thời điểm
          </button>
        </div>
      </div>

      {/* Calendar Heatmap (Lịch nhiệt theo ngày trong tháng) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-2">
        <div className="flex items-center justify-between text-xs mb-1">
          <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-sky-500" />
            Lịch nhiệt biến động kho 7 ngày gần đây (Calendar Heatmap)
          </span>
          <span className="text-slate-400 text-[11px]">Bấm vào ngày để lọc xem chi tiết</span>
        </div>

        <div className="grid grid-cols-7 gap-2 pt-1">
          {sampleDates.map((d) => {
            const isSelected = selectedDateFilter === d.date;
            const intensity =
              d.count >= 10 ? 'bg-sky-600 text-white' :
              d.count >= 6 ? 'bg-sky-100 text-sky-900 dark:bg-sky-950/80 dark:text-sky-200' :
              'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300';

            return (
              <button
                key={d.date}
                onClick={() => setSelectedDateFilter(isSelected ? 'all' : d.date)}
                className={`p-2.5 rounded-lg border text-center transition-all ${intensity} ${
                  isSelected ? 'ring-2 ring-sky-500 font-bold' : 'border-slate-200 dark:border-slate-800'
                }`}
              >
                <span className="text-[10px] block font-mono">{d.date.slice(5)}</span>
                <p className="text-sm font-bold font-mono mt-0.5">{d.count} GD</p>
                <span className="text-[10px] block text-emerald-600 font-medium">+{d.inQty} / -{d.outQty}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Shared Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative max-w-sm w-full">
            <input
              type="text"
              placeholder="Tìm theo mã SKU, tên hàng, chứng từ..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Toggle Chỉ hiện bất thường */}
            <button
              onClick={() => setOnlyAbnormal(!onlyAbnormal)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
                onlyAbnormal
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>Chỉ hiện bất thường</span>
            </button>

            {/* Select Kho */}
            <select
              value={selectedWarehouseId}
              onChange={(e) => setSelectedWarehouseId(e.target.value)}
              className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả kho</option>
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>

            {/* Select Loại giao dịch */}
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg px-2.5 py-1.5 font-medium"
            >
              <option value="all">Tất cả loại giao dịch</option>
              <option value="Nhập mua">Nhập mua</option>
              <option value="Xuất bán">Xuất bán</option>
              <option value="Xuất hủy">Xuất hủy</option>
              <option value="Điều chỉnh kiểm kê">Điều chỉnh kiểm kê</option>
            </select>

            <button
              onClick={() => {
                showToast('Chốt tồn thành công', 'Đã thực hiện chốt số dư tồn kho cuối ngày hôm nay thủ công. Số dư đã được lưu vào sổ chốt tồn.');
              }}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-sky-200 dark:border-sky-800 bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 text-xs font-semibold hover:bg-sky-100 transition-colors"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Chốt tồn cuối ngày</span>
            </button>

            <button
              onClick={() => showToast('Xuất báo cáo', 'Đang kết xuất tệp Excel lịch sử biến động kho.')}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-emerald-200 dark:border-emerald-800 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 text-xs font-semibold"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Xuất Excel</span>
            </button>
          </div>
        </div>
      </div>

      {/* TAB A: Nhật ký giao dịch */}
      {activeTab === 'transactions' && (
        <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-4 sm:p-5 shadow-xs space-y-4`}>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-3">Thời gian</th>
                  <th className="py-3 px-3">Loại giao dịch</th>
                  <th className="py-3 px-3">Số chứng từ</th>
                  <th className="py-3 px-3">Mã SKU &amp; Sản phẩm</th>
                  <th className="py-3 px-3">Số Lô</th>
                  <th className="py-3 px-3 text-right">Số lượng biến động</th>
                  <th className="py-3 px-3 text-right">Tồn sau GD</th>
                  <th className="py-3 px-3">Người thực hiện</th>
                  <th className="py-3 px-3">Ghi chú</th>
                  <th className="py-3 px-3 text-center">Bất thường</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {filteredMoves.map((m) => (
                  <tr
                    key={m.id}
                    onClick={() => setDrawerSku(m.sku)}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/40 cursor-pointer"
                  >
                    <td className="py-3 px-3 text-slate-500 font-mono text-[11px] whitespace-nowrap">
                      {m.timestamp}
                    </td>
                    <td className="py-3 px-3">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        m.quantity > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}>
                        {m.type}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono font-bold text-sky-600">{m.refCode}</td>
                    <td className="py-3 px-3">
                      <p className="font-bold text-slate-900 dark:text-white hover:text-sky-600">{m.productName}</p>
                      <span className="font-mono text-[10px] text-slate-400">{m.sku}</span>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-500">{m.lotNumber || '-'}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-sm">
                      <span className={m.quantity > 0 ? 'text-emerald-600' : 'text-rose-600'}>
                        {m.quantity > 0 ? `+${m.quantity}` : m.quantity}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                      {m.balanceAfter}
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">{m.performedBy}</td>
                    <td className="py-3 px-3 text-slate-500 text-[11px] max-w-xs truncate">{m.notes}</td>
                    <td className="py-3 px-3 text-center">
                      {m.isAbnormal ? (
                        <span
                          className="p-1 rounded bg-amber-100 text-amber-800 font-bold inline-flex items-center gap-1 text-[10px]"
                          title={m.abnormalReason}
                        >
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                          <span>Bất thường</span>
                        </span>
                      ) : (
                        <span className="text-slate-400">-</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB B: Tổng hợp theo ngày (Nhập - Xuất - Tồn) */}
      {activeTab === 'daily_summary' && (
        <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-4 sm:p-5 shadow-xs space-y-4`}>
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-sky-500" />
                Báo cáo Nhập - Xuất - Tồn theo ngày
              </h3>
              <p className="text-xs text-slate-500">
                Quy tắc kiểm soát: Tồn đầu ngày hôm sau PHẢI bằng Tồn cuối ngày hôm trước
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-3">Ngày báo cáo</th>
                  <th className="py-3 px-3 text-right">Tồn đầu ngày</th>
                  <th className="py-3 px-3 text-right text-emerald-600">Tổng nhập (+)</th>
                  <th className="py-3 px-3 text-right text-rose-600">Tổng xuất (-)</th>
                  <th className="py-3 px-3 text-right">Tồn cuối ngày</th>
                  <th className="py-3 px-3 text-right">Giá trị tồn cuối</th>
                  <th className="py-3 px-3 text-center">Kiểm tra số dư</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {dailySummaryData.map((row) => (
                  <tr key={row.date} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-3 font-semibold font-mono text-slate-800 dark:text-slate-200">{row.date}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-700 dark:text-slate-300">{row.openingStock}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600">+{row.totalIn}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-rose-600">-{row.totalOut}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-sky-600 text-sm">{row.closingStock}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                      {(row.closingValue / 1000000).toLocaleString('vi-VN')} Tr
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 dark:bg-emerald-950 px-2 py-0.5 rounded-full">
                        <CheckCircle2 className="w-3 h-3" /> Khớp 100%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB C: Tồn kho tại thời điểm (Xem lại quá khứ) */}
      {activeTab === 'as_of_date' && (
        <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-4 sm:p-5 shadow-xs space-y-4`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-purple-500" />
                Truy vấn ảnh chụp tồn kho tại thời điểm quá khứ (As-of Date)
              </h3>
              <p className="text-xs text-slate-500">
                Phục vụ đối chiếu sổ cái kế toán và kiểm kê định kỳ
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">Chọn ngày chốt:</span>
              <input
                type="date"
                value={asOfDate}
                onChange={(e) => setAsOfDate(e.target.value)}
                className="text-xs px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 font-mono"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-300 font-bold border-y border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3 px-3">Mã SKU &amp; Sản phẩm</th>
                  <th className="py-3 px-3">Nhóm hàng</th>
                  <th className="py-3 px-3 text-right">Tồn vào cuối ngày {asOfDate}</th>
                  <th className="py-3 px-3 text-right">Tồn hiện tại</th>
                  <th className="py-3 px-3 text-right">Chênh lệch</th>
                  <th className="py-3 px-3 text-right">Giá trị tồn thời điểm</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {asOfDateProducts.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-3">
                      <p className="font-bold text-slate-900 dark:text-white">{p.name}</p>
                      <span className="font-mono text-[10px] text-sky-600">{p.sku}</span>
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">{p.category}</td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-purple-600 text-sm">
                      {p.historicalQty} {p.unit}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-700 dark:text-slate-300">
                      {p.currentQty} {p.unit}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold">
                      <span className={p.variance >= 0 ? 'text-emerald-600' : 'text-rose-600'}>
                        {p.variance >= 0 ? `+${p.variance}` : p.variance}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-slate-900 dark:text-white">
                      {((p.historicalQty * p.costPrice) / 1000000).toLocaleString('vi-VN')} Tr
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Right Drawer: Single SKU Movement History */}
      {drawerProductData && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 w-full max-w-lg h-full shadow-2xl p-6 overflow-y-auto border-l border-slate-200 dark:border-slate-800 flex flex-col justify-between animate-in slide-in-from-right duration-200">
            <div>
              <div className="flex items-start justify-between pb-4 border-b border-slate-200 dark:border-slate-800 mb-4">
                <div>
                  <span className="text-xs font-mono font-bold text-sky-600">{drawerProductData.sku}</span>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                    {drawerProductData.name}
                  </h3>
                  <p className="text-xs text-slate-500">{drawerProductData.category}</p>
                </div>
                <button
                  onClick={() => setDrawerSku(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="space-y-4">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  Lịch sử mọi giao dịch của riêng sản phẩm này
                </h4>

                <div className="space-y-2">
                  {stockMoves.filter((m) => m.sku === drawerProductData.sku).map((m) => (
                    <div key={m.id} className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-800 text-xs space-y-1">
                      <div className="flex items-center justify-between">
                        <span className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                          m.quantity > 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {m.type}
                        </span>
                        <span className={`font-mono font-bold ${m.quantity > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                          {m.quantity > 0 ? `+${m.quantity}` : m.quantity} {drawerProductData.unit}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-slate-500 text-[11px]">
                        <span>Chứng từ: <strong className="text-slate-800 dark:text-slate-200">{m.refCode}</strong></span>
                        <span>Tồn sau: <strong className="font-mono text-slate-800 dark:text-slate-200">{m.balanceAfter}</strong></span>
                      </div>
                      <p className="text-[10px] text-slate-400">{m.timestamp} • {m.performedBy} ({m.warehouseName})</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setDrawerSku(null)}
                className="w-full py-2 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
