import React from 'react';
import { useCRM } from '../../context/CRMContext';
import { ActiveModule } from '../../types/crm';
import {
  LayoutDashboard,
  FileBarChart,
  Warehouse,
  Wallet,
  Menu,
} from 'lucide-react';

interface MobileBottomNavProps {
  onOpenMobileMenu: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ onOpenMobileMenu }) => {
  const { activeModule, setActiveModule, language } = useCRM();
  const isVi = language === 'vi';

  const navTabs: {
    id: ActiveModule | 'menu';
    labelVi: string;
    labelEn: string;
    icon: React.ComponentType<{ className?: string }>;
    badge?: number;
    isMenuTrigger?: boolean;
  }[] = [
    {
      id: 'dashboard',
      labelVi: 'Dashboard',
      labelEn: 'Dashboard',
      icon: LayoutDashboard,
    },
    {
      id: 'reports',
      labelVi: 'Báo cáo',
      labelEn: 'Reports',
      icon: FileBarChart,
    },
    {
      id: 'inventory',
      labelVi: 'Quản lý kho',
      labelEn: 'Warehouse',
      icon: Warehouse,
    },
    {
      id: 'sales',
      labelVi: 'Quản lý Sales',
      labelEn: 'Sales',
      icon: Wallet,
    },
    {
      id: 'menu',
      labelVi: 'Menu',
      labelEn: 'Menu',
      icon: Menu,
      isMenuTrigger: true,
    },
  ];

  return (
    <nav
      aria-label="Thanh điều hướng di động"
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#001226]/95 backdrop-blur-md border-t border-slate-200 dark:border-sky-950 transition-colors shadow-lg pb-safe"
    >
      <div className="grid grid-cols-5 items-center h-14">
        {navTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = !tab.isMenuTrigger && activeModule === tab.id;
          const label = isVi ? tab.labelVi : tab.labelEn;

          return (
            <button
              key={tab.id}
              onClick={() => {
                if (tab.isMenuTrigger) {
                  onOpenMobileMenu();
                } else {
                  setActiveModule(tab.id as ActiveModule);
                }
              }}
              className={`flex flex-col items-center justify-center h-full w-full relative transition-colors touch-manipulation select-none ${
                isActive
                  ? 'text-[#002659] dark:text-sky-400 font-bold'
                  : 'text-slate-500 dark:text-slate-400 hover:text-slate-800'
              }`}
            >
              {/* Active subtle pill highlight */}
              {isActive && (
                <span className="absolute top-1 w-6 h-0.75 bg-[#002659] dark:bg-sky-400 rounded-full" />
              )}

              <div className="relative">
                <Icon className={`w-5 h-5 ${isActive ? 'scale-105' : ''} transition-transform`} />
                {tab.badge !== undefined && (
                  <span className="absolute -top-1.5 -right-2.5 min-w-[15px] h-[15px] px-0.5 text-[9px] font-mono font-bold rounded-full bg-[#E96F22] text-white flex items-center justify-center">
                    {tab.badge}
                  </span>
                )}
              </div>

              <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-[56px]">
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
