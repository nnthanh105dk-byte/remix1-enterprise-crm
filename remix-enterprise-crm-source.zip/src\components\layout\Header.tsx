import React from 'react';
import { useCRM } from '../../context/CRMContext';
import { Menu } from 'lucide-react';
import { HeaderBreadcrumb } from './HeaderBreadcrumb';
import { HeaderSearch } from './HeaderSearch';
import { HeaderQuickCreate } from './HeaderQuickCreate';
import { HeaderLanguageSelector } from './HeaderLanguageSelector';
import { HeaderNotifications } from './HeaderNotifications';
import { HeaderUserMenu } from './HeaderUserMenu';

interface HeaderProps {
  onToggleSidebarMobile: () => void;
}

/**
 * CRM Header Bar
 * Tuân thủ đúng 6 phần tử từ trái sang phải:
 * 1) Nút Menu (thu gọn/mở menu bên trái, mobile dạng ngăn kéo)
 * 2) Breadcrumb (sinh tự động từ cấu trúc menu, có mã chứng từ ở cấp cuối)
 * 3) Tìm kiếm (ô nhập từ khóa, kết quả nhóm theo loại, phím tắt /, mobile toàn màn hình)
 * 4) Nút "+ Tạo mới" (lối tắt tạo nhanh theo nhóm module và quyền)
 * 5) Thông báo (chuông có số chưa đọc, tab Tất cả | Chưa đọc, thao tác người dùng khác, giữ 90 ngày)
 * 6) Avatar (menu cá nhân 7 mục, chuyển tab Hồ sơ của tôi, giao diện Sáng/Tối/Thiết bị)
 */
export const Header: React.FC<HeaderProps> = ({ onToggleSidebarMobile }) => {
  const { toggleSidebarCollapsed, themeDef } = useCRM();

  return (
    <header
      className={`sticky top-0 z-30 h-14 w-full ${themeDef.classes.headerBg} border-b ${themeDef.classes.headerBorder} flex items-center justify-between px-2.5 sm:px-4 md:px-5 lg:px-6 gap-2 transition-colors duration-200 select-none`}
    >
      {/* 1) Nút Menu & 2) Breadcrumb (Bên trái) */}
      <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0 max-w-[45%] md:max-w-[40%] lg:max-w-[35%] shrink">
        {/* 1) Nút Menu */}
        <button
          type="button"
          onClick={() => {
            if (typeof window !== 'undefined' && window.innerWidth < 768) {
              onToggleSidebarMobile();
            } else {
              toggleSidebarCollapsed();
            }
          }}
          className="p-1.5 rounded-lg text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 shrink-0 transition-colors cursor-pointer"
          aria-label="Thu gọn/mở menu bên trái"
          title="Thu gọn / mở thanh menu bên trái"
        >
          <Menu className="w-5 h-5" />
        </button>

        {/* 2) Breadcrumb */}
        <HeaderBreadcrumb />
      </div>

      {/* 3) Tìm kiếm (Ở giữa) */}
      <HeaderSearch />

      {/* 4) Nút "+ Tạo mới", Ngôn ngữ, Thông báo, Divider, Avatar (Bên phải) */}
      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
        {/* 4) Nút "+ Tạo mới" */}
        <HeaderQuickCreate />

        {/* 5) Chọn ngôn ngữ hiển thị */}
        <HeaderLanguageSelector />

        {/* 6) Thông báo hệ thống */}
        <HeaderNotifications />

        {/* Vạch phân cách tinh gọn */}
        <div className="h-6 w-px bg-slate-200 dark:bg-slate-700/80 mx-0.5 sm:mx-1 shrink-0" />

        {/* 7) Avatar & Thông tin User (Menu cá nhân) */}
        <HeaderUserMenu />
      </div>
    </header>
  );
};
