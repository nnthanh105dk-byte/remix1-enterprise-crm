import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { Quotation, QuotationItem } from '../types/crm';
import {
  FileSpreadsheet,
  Plus,
  Printer,
  CheckCircle,
  XCircle,
  FileCode,
  Calendar,
  DollarSign,
  User,
  Trash2,
  X,
  Sparkles,
  Building,
} from 'lucide-react';

export const QuotationsView: React.FC = () => {
  const {
    quotations,
    addQuotation,
    updateQuotationStatus,
    deleteQuotation,
    products,
    hasPermission,
    currentTenant,
    currentUser,
    language,
    themeDef,
    openScreenSpec,
    t,
  } = useCRM();

  const isVi = language === 'vi';
  const [selectedQuoteForPreview, setSelectedQuoteForPreview] = useState<Quotation | null>(null);

  // Create Modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: 'Báo giá Giải pháp CRM Cloud & Bản quyền Enterprise 2026',
    customerName: 'Trương Gia Bảo',
    customerCompany: 'Tổng Công Ty Dược Liệu Á Châu',
    customerEmail: 'baotg@asiapharma.vn',
    customerPhone: '0903 112 334',
    taxRate: 10,
    validUntil: '2026-10-31',
    paymentTerms: 'Đợt 1 tạm ứng 40%, Đợt 2 sau UAT 40%, Đợt 3 nghiệm thu bàn giao 20%',
    notes: 'Bảo hành 12 tháng, hỗ trợ kỹ thuật On-site 24/7.',
    items: [
      {
        id: 'item-1',
        productId: 'prod-1',
        productName: 'Bản quyền V-Enterprise CRM (Gói 100 User / Năm)',
        sku: 'SW-CRM-100U',
        unit: 'Gói',
        quantity: 1,
        unitPrice: 500000000,
        discountPercent: 5,
        total: 475000000,
      },
    ] as QuotationItem[],
  });

  const canCreate = hasPermission('quotations', 'create');
  const canApprove = hasPermission('quotations', 'approve');
  const canDelete = hasPermission('quotations', 'delete');

  const formatVND = (num: number) => {
    return num.toLocaleString() + ' ₫';
  };

  const calculateTotals = (items: QuotationItem[], taxRate: number) => {
    const subTotal = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
    const discountTotal = items.reduce(
      (sum, item) => sum + (item.quantity * item.unitPrice * item.discountPercent) / 100,
      0
    );
    const afterDiscount = subTotal - discountTotal;
    const taxTotal = (afterDiscount * taxRate) / 100;
    const grandTotal = afterDiscount + taxTotal;

    return { subTotal, discountTotal, taxTotal, grandTotal };
  };

  const handleAddItem = (productId: string) => {
    const prod = products.find((p) => p.id === productId);
    if (!prod) return;

    const newItem: QuotationItem = {
      id: `item-${Date.now()}`,
      productId: prod.id,
      productName: prod.name,
      sku: prod.sku,
      unit: prod.unit,
      quantity: 1,
      unitPrice: prod.sellingPrice,
      discountPercent: 0,
      total: prod.sellingPrice,
    };

    setFormData((prev) => ({
      ...prev,
      items: [...prev.items, newItem],
    }));
  };

  const handleRemoveItem = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index),
    }));
  };

  const handleItemChange = (index: number, field: 'quantity' | 'discountPercent' | 'unitPrice', val: number) => {
    setFormData((prev) => {
      const updated = [...prev.items];
      const item = { ...updated[index], [field]: val };
      item.total = item.quantity * item.unitPrice * (1 - item.discountPercent / 100);
      updated[index] = item;
      return { ...prev, items: updated };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim() || formData.items.length === 0) return;

    const { subTotal, discountTotal, taxTotal, grandTotal } = calculateTotals(
      formData.items,
      formData.taxRate
    );

    addQuotation({
      ...formData,
      subTotal,
      discountTotal,
      taxTotal,
      grandTotal,
      status: 'Chờ phê duyệt',
      createdByName: currentUser.fullName,
    });

    setIsCreateModalOpen(false);
  };

  const renderStatus = (status: Quotation['status']) => {
    switch (status) {
      case 'Được chấp thuận':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 shrink-0" />
            <span>Được chấp thuận</span>
          </span>
        );
      case 'Chờ phê duyệt':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-600 dark:text-amber-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 dark:bg-amber-400 shrink-0" />
            <span>Chờ phê duyệt</span>
          </span>
        );
      case 'Đã gửi':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-600 dark:text-sky-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-sky-400 shrink-0" />
            <span>Đã gửi</span>
          </span>
        );
      case 'Từ chối':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-600 dark:text-rose-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 dark:bg-rose-400 shrink-0" />
            <span>Từ chối</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 dark:bg-slate-500 shrink-0" />
            <span>{status}</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
              {t.quotations}
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {quotations.length} quotes
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isVi
              ? 'Lập báo giá đa dòng sản phẩm/dịch vụ, tính tự động thuế VAT, chiết khấu và xuất PDF tiêu chuẩn.'
              : 'Multi-line item proposal engine with automatic tax/discounts and enterprise PDF generation.'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 flex-wrap">
          <button
            onClick={() => openScreenSpec('SCR-QUOTATION')}
            className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] sm:text-xs font-medium border border-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            <FileCode className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="hidden md:inline">{isVi ? 'Đặc tả Màn hình E' : 'Spec Screen E'}</span>
            <span className="md:hidden">Spec E</span>
          </button>

          {canCreate && (
            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="flex items-center gap-1 px-2 py-1 sm:px-3 sm:py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white text-[11px] sm:text-xs font-medium transition-colors shadow-xs whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">{isVi ? 'Lập Báo giá mới' : 'New Quotation'}</span>
              <span className="sm:hidden">{isVi ? 'Báo giá' : 'New'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Quotations Table */}
      <div className="rounded-xl bg-white border border-[#E5E7EB] overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className={`${themeDef.classes.tableHeaderBg} border-b border-slate-200 dark:border-slate-800 font-bold uppercase tracking-wider text-[11px]`}>
              <tr>
                <th className="py-3.5 px-4 font-mono">{t.quoteCode}</th>
                <th className="py-3.5 px-4">{t.quoteTitle}</th>
                <th className="py-3.5 px-4">{t.customer}</th>
                <th className="py-3.5 px-4">{t.grandTotal}</th>
                <th className="py-3.5 px-4">{t.validUntil}</th>
                <th className="py-3.5 px-4">{t.status}</th>
                <th className="py-3.5 px-4 text-right">{t.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {quotations.map((quote) => (
                <tr key={quote.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-mono font-semibold text-blue-600 dark:text-blue-400">
                    {quote.code}
                  </td>
                  <td className="py-3 px-4 font-medium text-slate-900 dark:text-slate-100 max-w-xs">
                    <div>{quote.title}</div>
                    <div className="text-[11px] text-slate-400 font-normal">
                      {quote.items.length} hạng mục • Lập bởi {quote.createdByName}
                    </div>
                  </td>
                  <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                    <div>{quote.customerName}</div>
                    <div className="text-[11px] text-slate-400">{quote.customerCompany}</div>
                  </td>
                  <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-slate-100">
                    {formatVND(quote.grandTotal)}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-500">
                    {quote.validUntil}
                  </td>
                  <td className="py-3 px-4 whitespace-nowrap">
                    {renderStatus(quote.status)}
                  </td>
                  <td className="py-3 px-4 text-right">
                    <div className="flex items-center justify-end gap-1">
                      {/* Preview PDF */}
                      <button
                        onClick={() => setSelectedQuoteForPreview(quote)}
                        className="p-1.5 rounded-lg text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/40"
                        title="Xem trước & In Báo giá PDF"
                      >
                        <Printer className="w-4 h-4" />
                      </button>

                      {/* Approve / Reject buttons if manager */}
                      {canApprove && quote.status === 'Chờ phê duyệt' && (
                        <>
                          <button
                            onClick={() => updateQuotationStatus(quote.id, 'Được chấp thuận')}
                            className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40"
                            title="Duyệt báo giá này"
                          >
                            <CheckCircle className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => updateQuotationStatus(quote.id, 'Từ chối')}
                            className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                            title="Từ chối báo giá"
                          >
                            <XCircle className="w-4 h-4" />
                          </button>
                        </>
                      )}

                      {canDelete && (
                        <button
                          onClick={() => deleteQuotation(quote.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
                          title={t.delete}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal PDF Preview */}
      {selectedQuoteForPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
              <div className="flex items-center gap-2">
                <Printer className="w-5 h-5 text-blue-600" />
                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {isVi ? 'Bản in Báo giá Doanh nghiệp (Printable PDF)' : 'Commercial Quotation Document'}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 text-white font-semibold text-xs flex items-center gap-1.5 shadow-sm"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>In / Xuất PDF</span>
                </button>
                <button
                  onClick={() => setSelectedQuoteForPreview(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Sheet Body */}
            <div className="p-4 sm:p-8 overflow-y-auto space-y-6 text-slate-900 dark:text-slate-100 bg-white dark:bg-slate-900 font-sans text-xs">
              {/* Org Header */}
              <div className="flex flex-col sm:flex-row justify-between sm:items-start gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
                <div>
                  <h2 className="text-base font-extrabold text-blue-600 uppercase tracking-tight">
                    {currentTenant.name}
                  </h2>
                  <p className="text-slate-500 mt-1">Domain: {currentTenant.domain} • MST: {currentTenant.taxId}</p>
                  <p className="text-slate-500">Trụ sở: Hà Nội & TP. Hồ Chí Minh, Việt Nam</p>
                </div>
                <div className="sm:text-right">
                  <div className="font-mono text-sm font-bold text-slate-900 dark:text-slate-100">
                    {selectedQuoteForPreview.code}
                  </div>
                  <div className="text-slate-500 mt-1">Ngày lập: {selectedQuoteForPreview.createdAt}</div>
                  <div className="text-slate-500">Hiệu lực đến: {selectedQuoteForPreview.validUntil}</div>
                </div>
              </div>

              {/* Title & Customer */}
              <div className="text-center py-2">
                <h1 className="text-lg font-black uppercase text-slate-900 dark:text-slate-100 tracking-wide">
                  BÁO GIÁ THƯƠNG MẠI
                </h1>
                <p className="text-slate-600 dark:text-slate-400 font-medium mt-1">
                  {selectedQuoteForPreview.title}
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4">
                <div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase">Kính gửi Khách hàng:</div>
                  <div className="font-bold text-sm text-slate-900 dark:text-slate-100 mt-0.5">
                    {selectedQuoteForPreview.customerName}
                  </div>
                  <div className="text-slate-600 dark:text-slate-400">{selectedQuoteForPreview.customerCompany}</div>
                </div>
                <div>
                  <div className="text-[10px] font-bold text-slate-400 uppercase">Thông tin liên hệ:</div>
                  <div className="font-mono mt-0.5">{selectedQuoteForPreview.customerPhone}</div>
                  <div className="text-slate-600 dark:text-slate-400">{selectedQuoteForPreview.customerEmail}</div>
                </div>
              </div>

              {/* Line Items Table with horizontal scroll safety */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[540px]">
                  <thead>
                    <tr className="border-b-2 border-slate-900 dark:border-slate-200 text-slate-900 dark:text-slate-100 font-bold">
                      <th className="py-2">STT</th>
                      <th className="py-2">Sản phẩm / Dịch vụ</th>
                      <th className="py-2">ĐVT</th>
                      <th className="py-2 text-right">SL</th>
                      <th className="py-2 text-right">Đơn giá</th>
                      <th className="py-2 text-right">CK (%)</th>
                      <th className="py-2 text-right">Thành tiền</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                    {selectedQuoteForPreview.items.map((item, idx) => (
                      <tr key={item.id}>
                        <td className="py-2.5 font-mono">{idx + 1}</td>
                        <td className="py-2.5 font-medium">
                          <div>{item.productName}</div>
                          <div className="text-[10px] text-slate-400 font-mono">SKU: {item.sku}</div>
                        </td>
                        <td className="py-2.5">{item.unit}</td>
                        <td className="py-2.5 text-right font-mono">{item.quantity}</td>
                        <td className="py-2.5 text-right font-mono">{formatVND(item.unitPrice)}</td>
                        <td className="py-2.5 text-right font-mono">{item.discountPercent}%</td>
                        <td className="py-2.5 text-right font-mono font-bold">{formatVND(item.total)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Financial Calculation Summary */}
              <div className="flex justify-end pt-3">
                <div className="w-72 space-y-1.5 text-right border-t border-slate-200 dark:border-slate-800 pt-3">
                  <div className="flex justify-between text-slate-600 dark:text-slate-400">
                    <span>Tổng tiền hàng:</span>
                    <span className="font-mono">{formatVND(selectedQuoteForPreview.subTotal)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 dark:text-slate-400">
                    <span>Chiết khấu:</span>
                    <span className="font-mono text-emerald-600">-{formatVND(selectedQuoteForPreview.discountTotal)}</span>
                  </div>
                  <div className="flex justify-between text-slate-600 dark:text-slate-400">
                    <span>Thuế GTGT (VAT {selectedQuoteForPreview.taxRate}%):</span>
                    <span className="font-mono">{formatVND(selectedQuoteForPreview.taxTotal)}</span>
                  </div>
                  <div className="flex justify-between text-sm font-extrabold text-blue-600 dark:text-blue-400 pt-2 border-t border-slate-300 dark:border-slate-700">
                    <span>TỔNG CỘNG THANH TOÁN:</span>
                    <span className="font-mono">{formatVND(selectedQuoteForPreview.grandTotal)}</span>
                  </div>
                </div>
              </div>

              {/* Terms & Signatures */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 grid grid-cols-2 gap-8 text-center text-xs">
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">ĐẠI DIỆN KHÁCH HÀNG</div>
                  <div className="text-[11px] text-slate-400 italic">(Ký, ghi rõ họ tên và đóng dấu)</div>
                  <div className="h-20" />
                  <div className="font-semibold">{selectedQuoteForPreview.customerName}</div>
                </div>
                <div>
                  <div className="font-bold text-slate-800 dark:text-slate-200">ĐẠI DIỆN DOANH NGHIỆP</div>
                  <div className="text-[11px] text-slate-400 italic">(Ký, ghi rõ họ tên và đóng dấu)</div>
                  <div className="h-20" />
                  <div className="font-semibold">{selectedQuoteForPreview.createdByName}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Create Quotation */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6 flex flex-col max-h-[92vh]">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Lập Báo giá & Dự toán Thương mại Mới
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4 overflow-y-auto flex-1 text-xs">
              <div>
                <label className="block font-semibold mb-1">Tiêu đề Báo giá *</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Khách hàng nhận báo giá</label>
                  <input
                    type="text"
                    value={formData.customerName}
                    onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Tên công ty / Doanh nghiệp</label>
                  <input
                    type="text"
                    value={formData.customerCompany}
                    onChange={(e) => setFormData({ ...formData, customerCompany: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 sm:gap-3">
                <div>
                  <label className="block font-semibold mb-1">Số điện thoại</label>
                  <input
                    type="text"
                    value={formData.customerPhone}
                    onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Thuế VAT (%)</label>
                  <select
                    value={formData.taxRate}
                    onChange={(e) => setFormData({ ...formData, taxRate: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                  >
                    <option value={8}>8% (Nghị định giảm thuế)</option>
                    <option value={10}>10% (Tiêu chuẩn)</option>
                    <option value={0}>0% (Không chịu thuế)</option>
                  </select>
                </div>
                <div>
                  <label className="block font-semibold mb-1">Hạn hiệu lực báo giá</label>
                  <input
                    type="date"
                    value={formData.validUntil}
                    onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                  />
                </div>
              </div>

              {/* Line items generator */}
              <div className="border border-slate-200 dark:border-slate-800 rounded-xl p-3 sm:p-4 bg-slate-50/50 dark:bg-slate-800/30">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 mb-3">
                  <h4 className="font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider text-[11px]">
                    Danh mục Hạng mục Báo giá ({formData.items.length})
                  </h4>
                  <div className="flex items-center gap-2">
                    <select
                      onChange={(e) => {
                        if (e.target.value) {
                          handleAddItem(e.target.value);
                          e.target.value = '';
                        }
                      }}
                      className="w-full sm:w-auto px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs font-medium"
                    >
                      <option value="">Chọn sản phẩm từ Kho...</option>
                      {products.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.sku} - {p.name} ({formatVND(p.sellingPrice)})
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="space-y-2">
                  {formData.items.map((item, idx) => (
                    <div
                      key={item.id}
                      className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-12 gap-2 items-center"
                    >
                      <div className="sm:col-span-5 truncate">
                        <div className="font-semibold text-slate-900 dark:text-slate-100">{item.productName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{item.sku}</div>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block">Số lượng</label>
                        <input
                          type="number"
                          min="1"
                          value={item.quantity}
                          onChange={(e) => handleItemChange(idx, 'quantity', Number(e.target.value))}
                          className="w-full px-2 py-1 rounded border border-slate-200 dark:border-slate-800 font-mono"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="text-[10px] text-slate-400 block">Chiết khấu %</label>
                        <input
                          type="number"
                          min="0"
                          max="50"
                          value={item.discountPercent}
                          onChange={(e) => handleItemChange(idx, 'discountPercent', Number(e.target.value))}
                          className="w-full px-2 py-1 rounded border border-slate-200 dark:border-slate-800 font-mono"
                        />
                      </div>

                      <div className="sm:col-span-2 font-mono font-bold text-right text-slate-800 dark:text-slate-200">
                        {formatVND(item.total)}
                      </div>

                      <div className="sm:col-span-1 text-right">
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          className="text-slate-400 hover:text-rose-500"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Dynamic Math Summary */}
              {(() => {
                const totals = calculateTotals(formData.items, formData.taxRate);
                return (
                  <div className="p-3 rounded-xl bg-blue-50/60 dark:bg-blue-950/30 border border-blue-200/80 dark:border-blue-900/40 text-right space-y-1">
                    <div className="text-slate-600 dark:text-slate-400">
                      Tạm tính: <span className="font-mono font-bold">{formatVND(totals.subTotal)}</span>
                    </div>
                    <div className="text-slate-600 dark:text-slate-400">
                      Chiết khấu: <span className="font-mono text-emerald-600">-{formatVND(totals.discountTotal)}</span>
                    </div>
                    <div className="text-slate-600 dark:text-slate-400">
                      Thuế VAT ({formData.taxRate}%): <span className="font-mono">{formatVND(totals.taxTotal)}</span>
                    </div>
                    <div className="text-sm font-black text-blue-600 dark:text-blue-400 pt-1">
                      Tổng thanh toán: <span className="font-mono">{formatVND(totals.grandTotal)}</span>
                    </div>
                  </div>
                );
              })()}

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-white font-bold ${themeDef.classes.primaryButton}`}
                >
                  Tạo & Gửi Phê duyệt
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
