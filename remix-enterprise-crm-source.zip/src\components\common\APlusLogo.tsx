import React, { useState } from 'react';

interface APlusLogoProps {
  className?: string;
  size?: number;
  variant?: 'mark' | 'full';
  showSubtitle?: boolean;
}

export const APlusLogo: React.FC<APlusLogoProps> = ({
  className = '',
  size = 32,
  variant = 'mark',
  showSubtitle = true,
}) => {
  const [imageError, setImageError] = useState(false);

  // SVG Fallback emblem matching the exact brand geometry
  const SvgFallback = (
    <svg
      viewBox="0 0 400 360"
      width={size}
      height={size}
      className={`shrink-0 ${className}`}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="A+ Enterprise CRM Logo"
    >
      <defs>
        <linearGradient id="aplus-blue-gradient" x1="50%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#38BDF8" />
          <stop offset="42%" stopColor="#2563EB" />
          <stop offset="100%" stopColor="#1E3A8A" />
        </linearGradient>
        <linearGradient id="aplus-orange-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#EA580C" />
          <stop offset="100%" stopColor="#F97316" />
        </linearGradient>
      </defs>
      <path d="M 200 15 L 20 315 L 120 315 L 175 220 L 245 105 Z" fill="url(#aplus-blue-gradient)" />
      <path d="M 255 235 L 390 315 L 305 315 L 205 235 Z" fill="#1E3A8A" />
      <rect x="218" y="152" width="100" height="28" rx="2" fill="url(#aplus-orange-gradient)" />
      <rect x="248" y="118" width="28" height="90" rx="2" fill="url(#aplus-orange-gradient)" />
      <rect x="290" y="152" width="28" height="28" fill="#F97316" rx="2" />
      <rect x="270" y="118" width="16" height="16" fill="#EA580C" rx="1.5" />
      <rect x="295" y="112" width="10" height="10" fill="#EA580C" rx="1" />
      <rect x="312" y="96" width="8" height="8" fill="#EA580C" rx="1" />
      <rect x="310" y="80" width="9" height="9" fill="#EA580C" rx="1" />
      <rect x="318" y="73" width="5" height="5" fill="#F97316" rx="0.5" />
      <rect x="325" y="65" width="8" height="8" fill="#EA580C" rx="1" />
    </svg>
  );

  const Emblem = imageError ? (
    SvgFallback
  ) : (
    <img
      src="/logo-aplus-transparent.png"
      alt="A+ Enterprise CRM Logo"
      width={size}
      height={size}
      style={{ width: `${size}px`, height: `${size}px` }}
      onError={() => setImageError(true)}
      className={`shrink-0 object-contain select-none ${className}`}
    />
  );

  if (variant === 'mark') {
    return Emblem;
  }

  // Full brand lockup: Emblem + 'A+ Enterprise CRM'
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {Emblem}
      <div className="flex flex-col min-w-0">
        <span className="text-sm font-bold tracking-tight leading-none text-[#002659] dark:text-sky-400 font-sans">
          A+ Enterprise CRM
        </span>
        {showSubtitle && (
          <span className="text-[9.5px] font-semibold text-slate-500 dark:text-slate-400 tracking-wider uppercase mt-1 truncate">
            Hệ Thống Quản Trị Khách Hàng Doanh Nghiệp
          </span>
        )}
      </div>
    </div>
  );
};
