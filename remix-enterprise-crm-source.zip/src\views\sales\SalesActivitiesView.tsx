import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { SalesActivity, ActivityType, ActivityPriority } from '../../types/sales';
import {
  CalendarCheck,
  Plus,
  Search,
  Phone,
  Calendar,
  Mail,
  CheckSquare,
  MessageSquare,
  Clock,
  AlertTriangle,
  CheckCircle2,
  X,
  Bell,
  User,
  ArrowRight,
  Filter,
} from 'lucide-react';

export const SalesActivitiesView: React.FC = () => {
  const { showToast } = useCRM();
  const { activities, addActivity, completeActivity, leads, customers, opportunities } = useSales();

  const [viewMode, setViewMode] = useState<'today' | 'calendar'>('today');
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Complete Modal with Next Step Prompt
  const [isCompleteModalOpen, setIsCompleteModalOpen] = useState(false);
  const [completingActivity, setCompletingActivity] = useState<SalesActivity | null>(null);
  const [nextStepText, setNextStepText] = useState('');

  // New Activity Modal
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [formType, setFormType] = useState<ActivityType>('Cuộc gọi');
  const [formTitle, setFormTitle] = useState('');
  const [formDesc, setFormDesc] = useState('');
  const [formTargetType, setFormTargetType] = useState<'lead' | 'customer' | 'opportunity'>('opportunity');
  const [formTargetId, setFormTargetId] = useState('');
  const [formStartTime, setFormStartTime] = useState(new Date().toISOString().substring(0, 16));
  const [formPriority, setFormPriority] = useState<ActivityPriority>('Trung bình');
  const [formAssignedTo, setFormAssignedTo] = useState('Lê Hoàng Yến');

  // Filtered
  const filteredActivities = activities.filter((act) => {
    if (typeFilter !== 'all' && act.type !== typeFilter) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        act.title.toLowerCase().includes(q) ||
        act.description.toLowerCase().includes(q) ||
        act.targetName.toLowerCase().includes(q) ||
        act.assignedTo.toLowerCase().includes(q)
      );
    }
    return true;
  });

  // Calculate Overdue
  const isOverdue = (act: SalesActivity) => {
    if (act.isCompleted) return false;
    const time = new Date(act.startTime).getTime();
    return !isNaN(time) && time < Date.now();
  };

  const overdueCount = activities.filter(isOverdue).length;
  const completedTodayCount = activities.filter((a) => a.isCompleted).length;

  const handleOpenCompleteModal = (act: SalesActivity) => {
    setCompletingActivity(act);
    setNextStepText(act.nextStepPrompt || 'Gặp gỡ chốt hợp đồng trong tuần tới');
    setIsCompleteModalOpen(true);
  };

  const handleConfirmComplete = () => {
    if (!completingActivity) return;
    completeActivity(completingActivity.id, nextStepText);
    setIsCompleteModalOpen(false);
    setCompletingActivity(null);
  };

  const handleCreateActivitySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let targetName = 'Chung';
    let targetCode = '';

    if (formTargetType === 'lead') {
      const l = leads.find((item) => item.id === formTargetId) || leads[0];
      targetName = l ? l.fullName : 'Lead';
      targetCode = l ? l.code : '';
    } else if (formTargetType === 'customer') {
      const c = customers.find((item) => item.id === formTargetId) || customers[0];
      targetName = c ? c.name : 'Khách hàng';
      targetCode = c ? c.code : '';
    } else {
      const o = opportunities.find((item) => item.id === formTargetId) || opportunities[0];
      targetName = o ? o.title : 'Cơ hội';
      targetCode = o ? o.code : '';
    }

    addActivity({
      type: formType,
      title: formTitle,
      description: formDesc,
      targetType: formTargetType,
      targetId: formTargetId || 'opp-1',
      targetCode: targetCode || 'CH-2026-0001',
      targetName,
      startTime: formStartTime,
      priority: formPriority,
      assignedTo: formAssignedTo,
      nextStepPrompt: 'Lên kế hoạch bước tiếp theo sau khi trao đổi',
    });

    setIsCreateModalOpen(false);
    setFormTitle('');
    setFormDesc('');
  };

  const getActivityIcon = (type: ActivityType) => {
    switch (type) {
      case 'Cuộc gọi':
        return <Phone className="w-4 h-4 text-emerald-500" />;
      case 'Cuộc hẹn/Họp':
        return <Calendar className="w-4 h-4 text-sky-500" />;
      case 'Email':
        return <Mail className="w-4 h-4 text-purple-500" />;
      case 'Nhiệm vụ':
        return <CheckSquare className="w-4 h-4 text-amber-500" />;
      case 'Ghi chú':
        return <MessageSquare className="w-4 h-4 text-slate-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800">
                <CalendarCheck className="w-5 h-5" />
              </span>
              Hoạt Động &amp; Lịch Hẹn Bán Hàng (Activities &amp; Appointments)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {activities.length} Hoạt động
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Quản lý công việc hôm nay, lịch hẹn với khách hàng, tự động gợi ý bước kế tiếp và làm nguồn số liệu cho báo cáo Hiệu suất nhân viên.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <div className="flex items-center rounded-lg border border-slate-200 dark:border-slate-800 p-0.5 bg-slate-100 dark:bg-slate-800 text-xs">
            <button
              onClick={() => setViewMode('today')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
                viewMode === 'today'
                  ? 'bg-white dark:bg-slate-900 text-sky-600 dark:text-sky-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Việc hôm nay ({activities.filter((a) => !a.isCompleted).length})
            </button>
            <button
              onClick={() => setViewMode('calendar')}
              className={`px-3 py-1.5 rounded-md font-semibold transition-all ${
                viewMode === 'calendar'
                  ? 'bg-white dark:bg-slate-900 text-sky-600 dark:text-sky-400 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Xem theo Lịch
            </button>
          </div>

          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-lg bg-sky-600 text-white hover:bg-sky-700 shadow-sm"
          >
            <Plus className="w-4 h-4" />
            <span>Thêm Hoạt Động</span>
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200">
          <span className="text-[14.5px] font-bold text-slate-800 dark:text-slate-100 tracking-tight">Việc cần hoàn thành</span>
          <h3 className="text-2xl sm:text-[28px] font-black font-mono text-sky-600 dark:text-sky-400 mt-1.5 leading-none tabular-nums">
            {activities.filter((a) => !a.isCompleted).length} Việc
          </h3>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-rose-200/90 dark:border-rose-900/60 rounded-xl p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200">
          <span className="text-[14.5px] font-bold text-rose-700 dark:text-rose-400 tracking-tight">Việc quá hạn xử lý</span>
          <h3 className="text-2xl sm:text-[28px] font-black font-mono text-rose-600 dark:text-rose-400 mt-1.5 leading-none tabular-nums">
            {overdueCount} Việc
          </h3>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4.5 shadow-[0_4px_16px_rgba(0,0,0,0.05)] hover:shadow-[0_8px_24px_rgba(0,0,0,0.08)] hover:-translate-y-0.5 transition-all duration-200">
          <span className="text-[14.5px] font-bold text-slate-800 dark:text-slate-100 tracking-tight">Đã hoàn thành gần đây</span>
          <h3 className="text-2xl sm:text-[28px] font-black font-mono text-emerald-600 dark:text-emerald-400 mt-1.5 leading-none tabular-nums">
            {completedTodayCount} Việc
          </h3>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo tiêu đề, đối tượng, người phụ trách..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-medium">Loại hoạt động:</span>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200"
          >
            <option value="all">Tất cả loại hình</option>
            <option value="Cuộc gọi">Cuộc gọi</option>
            <option value="Cuộc hẹn/Họp">Cuộc hẹn/Họp</option>
            <option value="Email">Email</option>
            <option value="Nhiệm vụ">Nhiệm vụ</option>
            <option value="Ghi chú">Ghi chú</option>
          </select>
        </div>
      </div>

      {/* Main List */}
      <div className="space-y-3">
        {filteredActivities.map((act) => {
          const overdue = isOverdue(act);

          return (
            <div
              key={act.id}
              className={`p-4 rounded-xl border bg-white dark:bg-slate-900 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs ${
                overdue
                  ? 'border-rose-400 dark:border-rose-800 bg-rose-50/20'
                  : act.isCompleted
                  ? 'border-slate-200 dark:border-slate-800 opacity-75'
                  : 'border-slate-200 dark:border-slate-800 shadow-2xs hover:shadow-xs'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 shrink-0 mt-0.5">
                  {getActivityIcon(act.type)}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-slate-900 dark:text-white text-sm">
                      {act.title}
                    </span>
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                      {act.type}
                    </span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        act.priority === 'Khẩn cấp'
                          ? 'bg-rose-100 text-rose-800'
                          : act.priority === 'Cao'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {act.priority}
                    </span>
                    {overdue && (
                      <span className="px-2 py-0.5 rounded text-[10px] bg-rose-600 text-white font-bold animate-pulse">
                        Quá Hạn
                      </span>
                    )}
                  </div>

                  <p className="text-slate-600 dark:text-slate-400">{act.description}</p>

                  <div className="flex items-center gap-4 text-slate-400 text-[11px] pt-1">
                    <span className="font-medium text-slate-700 dark:text-slate-300">
                      Gắn với: <strong>{act.targetName}</strong> ({act.targetCode})
                    </span>
                    <span className="flex items-center gap-1 font-mono">
                      <Clock className="w-3 h-3" />
                      {act.startTime.replace('T', ' ')}
                    </span>
                    <span>Phụ trách: <strong>{act.assignedTo}</strong></span>
                  </div>

                  {act.isCompleted && act.completedAt && (
                    <div className="text-[10px] text-emerald-600 font-semibold pt-0.5">
                      ✓ Đã hoàn thành lúc: {act.completedAt}
                    </div>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-2 shrink-0">
                {!act.isCompleted ? (
                  <button
                    onClick={() => handleOpenCompleteModal(act)}
                    className="px-3.5 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 hover:bg-emerald-700 shadow-xs"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Hoàn Thành &amp; Lên Bước Kế Tiếp</span>
                  </button>
                ) : (
                  <span className="px-3 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-500 font-semibold">
                    Đã Xong
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal: Hoàn Thành & Gợi Ý Đặt Lịch Bước Kế Tiếp */}
      {isCompleteModalOpen && completingActivity && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl text-xs space-y-3">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                Hoàn Thành Hoạt Động
              </h3>
              <button onClick={() => setIsCompleteModalOpen(false)} className="text-slate-400 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-slate-600 dark:text-slate-300">
              Đánh dấu hoàn thành: <strong>{completingActivity.title}</strong>
            </p>

            <div className="p-3 rounded-xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800 space-y-2">
              <span className="font-bold text-sky-800 dark:text-sky-300 block text-[11px]">
                Gợi ý chuẩn CRM: "Đặt lịch bước tiếp theo"
              </span>
              <p className="text-slate-500 text-[11px]">
                Sau khi kết thúc tương tác này, việc kế tiếp bạn cần làm với khách hàng/cơ hội này là gì?
              </p>
              <textarea
                rows={2}
                value={nextStepText}
                onChange={(e) => setNextStepText(e.target.value)}
                placeholder="Ví dụ: Gọi lại vào thứ 5 để chốt hợp đồng, gửi bản sửa đổi..."
                className="w-full px-3 py-1.5 rounded-lg border border-sky-300 dark:border-sky-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsCompleteModalOpen(false)}
                className="px-3.5 py-1.5 rounded-lg border border-slate-300 text-slate-600 font-semibold"
              >
                Hủy
              </button>
              <button
                onClick={handleConfirmComplete}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white font-bold"
              >
                Xác Nhận &amp; Lưu Bước Tiếp Theo
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Thêm Hoạt Động Mới */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-lg w-full shadow-2xl text-xs space-y-3.5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center gap-2">
                <CalendarCheck className="w-5 h-5 text-sky-600" />
                Lên Lịch Hoạt Động Mới
              </h3>
              <button onClick={() => setIsCreateModalOpen(false)} className="text-slate-400 p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateActivitySubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Loại hoạt động</label>
                  <select
                    value={formType}
                    onChange={(e) => setFormType(e.target.value as ActivityType)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="Cuộc gọi">Cuộc gọi</option>
                    <option value="Cuộc hẹn/Họp">Cuộc hẹn/Họp</option>
                    <option value="Email">Email</option>
                    <option value="Nhiệm vụ">Nhiệm vụ</option>
                    <option value="Ghi chú">Ghi chú</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Mức độ ưu tiên</label>
                  <select
                    value={formPriority}
                    onChange={(e) => setFormPriority(e.target.value as ActivityPriority)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="Trung bình">Trung bình</option>
                    <option value="Cao">Cao</option>
                    <option value="Khẩn cấp">Khẩn cấp</option>
                    <option value="Thấp">Thấp</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Tiêu đề hoạt động *</label>
                <input
                  type="text"
                  required
                  value={formTitle}
                  onChange={(e) => setFormTitle(e.target.value)}
                  placeholder="Họp trao đổi hợp đồng, gọi tư vấn báo giá..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Đối tượng gắn kết</label>
                  <select
                    value={formTargetType}
                    onChange={(e) => setFormTargetType(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                  >
                    <option value="opportunity">Cơ hội bán hàng</option>
                    <option value="lead">Lead</option>
                    <option value="customer">Khách hàng</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-600 font-semibold mb-1">Thời gian bắt đầu *</label>
                  <input
                    type="datetime-local"
                    required
                    value={formStartTime}
                    onChange={(e) => setFormStartTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-600 font-semibold mb-1">Chi tiết nội dung</label>
                <textarea
                  rows={2}
                  value={formDesc}
                  onChange={(e) => setFormDesc(e.target.value)}
                  placeholder="Nội dung cần chuẩn bị trước cuộc họp..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2 rounded-lg border border-slate-300 text-slate-600 font-semibold"
                >
                  Hủy
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-lg bg-sky-600 text-white font-bold"
                >
                  Lưu Hoạt Động
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
