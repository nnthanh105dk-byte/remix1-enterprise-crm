/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import { Building2, ArrowRight, ShieldCheck, LogOut, Check } from 'lucide-react';

export const WorkspaceSelectModal: React.FC = () => {
  const {
    pendingMultiCompanySelection,
    selectWorkspace,
    logout,
  } = useMultiTenant();

  if (!pendingMultiCompanySelection || pendingMultiCompanySelection.length === 0) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-[#001738] to-[#000d1e] text-slate-100 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-blue-600 to-cyan-500 shadow-lg shadow-blue-500/25 mb-3">
            <Building2 className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-xl font-bold text-white">Chọn Không Gian Làm Việc</h2>
          <p className="mt-1 text-xs text-slate-400">
            Tài khoản của bạn thuộc nhiều công ty. Vui lòng chọn tổ chức muốn truy cập:
          </p>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl space-y-3">
          {pendingMultiCompanySelection.map((company) => (
            <button
              key={company.id}
              onClick={() => selectWorkspace(company.id)}
              className="w-full p-4 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 hover:border-blue-400/50 transition-all text-left flex items-center justify-between group"
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold text-sm shrink-0">
                  {company.code.substring(0, 2).toUpperCase()}
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white group-hover:text-cyan-300 transition-colors">
                    {company.name}
                  </h3>
                  <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-400">
                    <span className="font-mono bg-white/10 px-1.5 py-0.5 rounded text-[10px]">
                      {company.code}
                    </span>
                    <span>• {company.plan}</span>
                    <span>• {company.userCount} thành viên</span>
                  </div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-cyan-300 group-hover:translate-x-1 transition-all" />
            </button>
          ))}

          <div className="pt-3 border-t border-white/10 text-center">
            <button
              type="button"
              onClick={logout}
              className="text-xs text-slate-400 hover:text-slate-200 inline-flex items-center gap-1.5 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Đăng nhập bằng tài khoản khác</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
