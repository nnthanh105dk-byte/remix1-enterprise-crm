/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 *
 * A+ CRM — MULTI-TENANT CONTEXT & ARCHITECTURE ENGINE
 * Quản trị Control DB (CRM_CORE), Database Isolation Registry,
 * Membership, Departments, Positions, Levels, Roles & Scopes.
 */

import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  Tenant,
  Company,
  UserAccount,
  Membership,
  CompanyMember,
  Department,
  Position,
  Level,
  Role,
  PermissionScope,
  SessionContext,
  ProvisioningStep,
  JoinRequest,
  CompanyInvitation,
  PlatformConfig,
  AuthScreenMode,
  CompanyRegistrationRequest,
} from '../types/auth';
import {
  INITIAL_TENANTS,
  INITIAL_ACCOUNTS,
  INITIAL_DEPARTMENTS,
  INITIAL_POSITIONS,
  INITIAL_LEVELS,
  INITIAL_ROLES,
  INITIAL_MEMBERSHIPS,
  INITIAL_JOIN_REQUESTS,
  INITIAL_INVITATIONS,
  INITIAL_PLATFORM_CONFIG,
} from '../data/mockAuthData';
import { multiTenantDAL, FullAuditReport } from '../services/multiTenantDataLayer';

export interface RegisterCompanyPayload {
  companyName: string;
  companyCode: string;
  taxCode?: string;
  phone?: string;
  address?: string;
  adminName: string;
  email: string;
  adminPhone?: string;
  password: string;
  agreedTerms: boolean;
}

export interface RequestJoinPayload {
  companyCode: string;
  fullName: string;
  email: string;
  phone?: string;
  password: string;
}

export interface AcceptInvitePayload {
  inviteCode: string;
  fullName: string;
  password: string;
}

export interface CreateEmployeePayload {
  fullName: string;
  email: string;
  phone: string;
  departmentId: string;
  positionId: string;
  levelId: string;
  roleId: string;
  employeeCode?: string;
  password?: string;
}

export interface UpdateEmployeeAccountPayload {
  membershipId: string;
  userId: string;
  fullName?: string;
  email?: string;
  phone?: string;
  employeeCode?: string;
  displayId?: string;
  departmentId?: string;
  positionId?: string;
  levelId?: string;
  roleId?: string;
}

interface MultiTenantContextType {
  // Session & Identity
  isAuthenticated: boolean;
  currentAccount: UserAccount | null;
  currentCompany: Company | null;
  currentMember: CompanyMember | null;
  sessionContext: SessionContext | null;

  // Multi-Tenant Collections
  tenants: Tenant[];
  allCompanies: Company[];
  userCompanies: Company[];
  allAccounts: UserAccount[];
  userMemberships: Membership[];
  tenantMemberships: Membership[];
  allDepartments: Department[];
  tenantDepartments: Department[];
  allPositions: Position[];
  allLevels: Level[];
  allRoles: Role[];
  allMemberships: Membership[];

  // Navigation & Platform View
  authScreenMode: AuthScreenMode;
  setAuthScreenMode: (mode: AuthScreenMode) => void;
  isPlatformMode: boolean;
  setIsPlatformMode: (active: boolean) => void;

  // Onboarding & Provisioning
  showOnboardingWizard: boolean;
  setShowOnboardingWizard: (show: boolean) => void;
  isProvisioning: boolean;
  provisioningSteps: ProvisioningStep[];
  provisionTenantWithSteps: (payload: RegisterCompanyPayload) => Promise<{ success: boolean; tenant?: Tenant; error?: string }>;

  // Organization Actions
  createEmployeeUser: (payload: CreateEmployeePayload) => Membership;
  updateMembershipScope: (membershipId: string, moduleName: string, scope: PermissionScope) => void;
  deleteMembership: (membershipId: string) => void;
  updateEmployeeAccountByAdmin: (payload: UpdateEmployeeAccountPayload) => boolean;

  // Security, Lockout & Audit
  loginError: string | null;
  failedAttempts: number;
  isLockedOut: boolean;
  lockoutRemainingSeconds: number;
  rememberCompanyCode: string;
  pendingMultiCompanySelection: Company[] | null;
  resetLockout: () => void;

  // Authentication Actions
  login: (companyCode: string, emailOrUser: string, password: string, remember: boolean) => Promise<boolean>;
  logout: () => void;
  selectWorkspace: (companyId: string) => void;
  switchCompany: (companyId: string) => boolean;
  switchTenant: (tenantId: string) => boolean;
  switchMembership: (membershipId: string) => boolean;

  // Platform & Invitations
  joinRequests: JoinRequest[];
  companyInvitations: CompanyInvitation[];
  platformConfig: PlatformConfig;
  pendingCompanyRegistrations: CompanyRegistrationRequest[];
  submitCompanyRegistration: (payload: RegisterCompanyPayload) => Promise<{ success: boolean; request?: CompanyRegistrationRequest; error?: string }>;
  approveCompanyRegistration: (requestId: string) => Promise<{ success: boolean; tenant?: Tenant; error?: string }>;
  rejectCompanyRegistration: (requestId: string, reason?: string) => void;
  registerNewCompany: (payload: RegisterCompanyPayload) => Promise<{ success: boolean; error?: string }>;
  requestJoinCompany: (payload: RequestJoinPayload) => Promise<{ success: boolean; error?: string }>;
  acceptInvitation: (payload: AcceptInvitePayload) => Promise<{ success: boolean; error?: string }>;
  checkCompanyCodeAvailability: (code: string) => { valid: boolean; available: boolean; error?: string };
  requestPasswordReset: (companyCode: string, email: string) => { success: boolean; hasSmtp: boolean; message: string };
  generateManualResetLink: (targetEmail: string) => string;
  createCompanyInvitation: (roleGroupId: string, roleTitle: string, expiresDays: number, maxUses: number) => CompanyInvitation;
  revokeCompanyInvitation: (invitationId: string) => void;
  reviewJoinRequest: (requestId: string, action: 'approve' | 'reject', roleGroupId?: string, employeeId?: string) => void;
  toggleCompanyStatus: (companyId: string) => void;
  toggleAllowNewRegistration: () => void;
  generateAdminResetLink: (companyId: string) => string;
  runDataIsolationAudit: () => FullAuditReport;
  resetToDefaultData: () => void;
}

const MultiTenantContext = createContext<MultiTenantContextType | undefined>(undefined);

const STORAGE_KEYS = {
  CURRENT_ACCOUNT: 'crm_multitenant_account',
  CURRENT_COMPANY: 'crm_multitenant_company',
  CURRENT_MEMBER: 'crm_multitenant_member',
  REMEMBER_CODE: 'crm_last_company_code',
  COMPANIES: 'crm_stored_companies',
  ACCOUNTS: 'crm_stored_accounts',
  MEMBERS: 'crm_stored_members',
  DEPARTMENTS: 'crm_stored_departments',
  POSITIONS: 'crm_stored_positions',
  LEVELS: 'crm_stored_levels',
  ROLES: 'crm_stored_roles',
  INVITATIONS: 'crm_stored_invitations',
  REQUESTS: 'crm_stored_join_requests',
  PLATFORM_CFG: 'crm_stored_platform_cfg',
};

export const MultiTenantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // 1. Tenants (Control DB: CRM_CORE.tenants)
  const [allCompanies, setAllCompanies] = useState<Tenant[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.COMPANIES);
      const initialPool = [...INITIAL_TENANTS];
      if (!saved) return initialPool;
      const parsed: Tenant[] = JSON.parse(saved);
      const merged = [...parsed];
      initialPool.forEach((initT) => {
        const idx = merged.findIndex((c) => c?.id === initT.id || (c?.code && c.code.toLowerCase() === initT.code.toLowerCase()));
        if (idx === -1) merged.push(initT);
        else merged[idx] = { ...merged[idx], ...initT };
      });
      return merged.map((c) => ({
        ...c,
        slug: c.slug || (c.code || 'comp').toLowerCase(),
        database: c.database || `DB_${(c.code || 'COMP').toUpperCase()}`,
        databaseStatus: c.databaseStatus || 'READY',
      }));
    } catch (e) {
      return INITIAL_TENANTS;
    }
  });

  // 2. Users (Control DB: CRM_CORE.users)
  const [allAccounts, setAllAccounts] = useState<UserAccount[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ACCOUNTS);
      const initialPool = [...INITIAL_ACCOUNTS];
      if (!saved) return initialPool;
      const parsed: UserAccount[] = JSON.parse(saved);
      const merged = [...parsed];
      initialPool.forEach((initAcc) => {
        const idx = merged.findIndex((a) => a?.id === initAcc.id || (a?.email && a.email.toLowerCase() === initAcc.email.toLowerCase()));
        if (idx === -1) merged.push(initAcc);
        else merged[idx] = { ...merged[idx], ...initAcc };
      });
      return merged;
    } catch (e) {
      return INITIAL_ACCOUNTS;
    }
  });

  // 3. Departments
  const [allDepartments, setAllDepartments] = useState<Department[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.DEPARTMENTS);
      return saved ? JSON.parse(saved) : INITIAL_DEPARTMENTS;
    } catch (e) {
      return INITIAL_DEPARTMENTS;
    }
  });

  // 4. Positions & Levels
  const [allPositions] = useState<Position[]>(INITIAL_POSITIONS);
  const [allLevels] = useState<Level[]>(INITIAL_LEVELS);

  // 5. Roles & Permissions
  const [allRoles, setAllRoles] = useState<Role[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ROLES);
      return saved ? JSON.parse(saved) : INITIAL_ROLES;
    } catch (e) {
      return INITIAL_ROLES;
    }
  });

  // 6. Memberships (Control DB: CRM_CORE.memberships)
  const [allMemberships, setAllMemberships] = useState<Membership[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MEMBERS);
      const initialPool = [...INITIAL_MEMBERSHIPS];
      if (!saved) return initialPool;
      const parsed: Membership[] = JSON.parse(saved);
      const merged = [...parsed];
      initialPool.forEach((initMem) => {
        const idx = merged.findIndex((m) => m?.id === initMem.id || (m?.userId === initMem.userId && m?.tenantId === initMem.tenantId));
        if (idx === -1) merged.push(initMem);
        else merged[idx] = { ...merged[idx], ...initMem };
      });
      return merged.map((m) => {
        const comp = INITIAL_TENANTS.find((t) => t.id === m.tenantId);
        const compCode = comp?.code || 'APLUS';
        const uname = m.username || (m.employeeCode ? `EMP-${m.employeeCode}` : `USER-${(m.id || '0001').slice(-4)}`);
        return {
          ...m,
          username: uname,
          displayId: m.displayId || `${compCode}-${uname}`,
        };
      });
    } catch (e) {
      return INITIAL_MEMBERSHIPS;
    }
  });

  const [joinRequests, setJoinRequests] = useState<JoinRequest[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.REQUESTS);
    return saved ? JSON.parse(saved) : INITIAL_JOIN_REQUESTS;
  });

  const [companyInvitations, setCompanyInvitations] = useState<CompanyInvitation[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.INVITATIONS);
    return saved ? JSON.parse(saved) : INITIAL_INVITATIONS;
  });

  const [platformConfig, setPlatformConfig] = useState<PlatformConfig>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.PLATFORM_CFG);
    return saved ? JSON.parse(saved) : INITIAL_PLATFORM_CONFIG;
  });

  // Pending Company Registrations (Chờ Super Admin duyệt để cấp phát CSDL)
  const [pendingCompanyRegistrations, setPendingCompanyRegistrations] = useState<CompanyRegistrationRequest[]>(() => {
    try {
      const saved = localStorage.getItem('crm_pending_company_registrations');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      {
        id: 'req_aplus_init',
        companyName: 'Công ty Cổ phần Aplus',
        companyCode: 'APLUS',
        taxCode: '0109988776',
        phone: '024 3888 9999',
        address: 'Hà Nội, Việt Nam',
        adminName: 'Chủ Doanh Nghiệp Aplus',
        email: 'admin@aplus.vn',
        adminPhone: '0988 123 456',
        password: 'password123',
        requestedAt: '2026-10-08 08:30',
        status: 'PENDING',
        databaseName: 'DB_APLUS',
      }
    ];
  });

  // Active Session
  const [currentAccount, setCurrentAccount] = useState<UserAccount | null>(() => {
    if (typeof window !== 'undefined' && localStorage.getItem('crm_has_logged_out') === 'true') {
      return null;
    }
    const saved = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.CURRENT_ACCOUNT) : null;
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const refreshed = INITIAL_ACCOUNTS.find((a) => a.id === parsed.id || a.email?.toLowerCase() === parsed.email?.toLowerCase());
        return refreshed ? { ...parsed, ...refreshed } : parsed;
      } catch (e) {}
    }
    return INITIAL_ACCOUNTS[0]; // Nguyễn Khắc Huy
  });

  const [currentCompany, setCurrentCompany] = useState<Tenant | null>(() => {
    if (typeof window !== 'undefined' && localStorage.getItem('crm_has_logged_out') === 'true') {
      return null;
    }
    const saved = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.CURRENT_COMPANY) : null;
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_TENANTS[0]; // APLUS
  });

  const [currentMember, setCurrentMember] = useState<Membership | null>(() => {
    if (typeof window !== 'undefined' && localStorage.getItem('crm_has_logged_out') === 'true') {
      return null;
    }
    const saved = typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.CURRENT_MEMBER) : null;
    if (saved) {
      try { return JSON.parse(saved); } catch (e) {}
    }
    return INITIAL_MEMBERSHIPS[0]; // APLUS-ADMIN-0001
  });

  const [rememberCompanyCode, setRememberCompanyCode] = useState<string>(() => {
    return (typeof window !== 'undefined' ? localStorage.getItem(STORAGE_KEYS.REMEMBER_CODE) : null) || 'APLUS';
  });

  // Auth screen mode
  const [authScreenMode, setAuthScreenMode] = useState<AuthScreenMode>('LOGIN');
  const [isPlatformMode, setIsPlatformMode] = useState<boolean>(false);
  const [showOnboardingWizard, setShowOnboardingWizard] = useState<boolean>(false);

  // Security Lockout & Errors
  const [loginError, setLoginError] = useState<string | null>(null);
  const [failedAttempts, setFailedAttempts] = useState<number>(0);
  const [isLockedOut, setIsLockedOut] = useState<boolean>(false);
  const [lockoutRemainingSeconds, setLockoutRemainingSeconds] = useState<number>(0);
  const [pendingMultiCompanySelection, setPendingMultiCompanySelection] = useState<Company[] | null>(null);
  const [pendingLoginAccount, setPendingLoginAccount] = useState<UserAccount | null>(null);

  // Provisioning animation state
  const [isProvisioning, setIsProvisioning] = useState<boolean>(false);
  const DEFAULT_PROVISIONING_STEPS: ProvisioningStep[] = [
    { id: 1, label: 'Khởi tạo Tenant Entity', subtext: 'Cấp phát tenant_id định danh hệ thống duy nhất (UUID)', status: 'pending' },
    { id: 2, label: 'Cấp phát Cơ sở Dữ liệu riêng biệt', subtext: 'Khởi tạo schema Database độc lập (DB_{CODE})', status: 'pending' },
    { id: 3, label: 'Áp dụng CRM Schema', subtext: 'Khởi tạo các bảng khách hàng, leads, cơ hội, đơn hàng, kho vận', status: 'pending' },
    { id: 4, label: 'Thiết lập 6 Phòng ban chuẩn', subtext: 'Khởi tạo tự động: SALE, MKT, TECH, HR, ACCOUNTING, OPERATIONS', status: 'pending' },
    { id: 5, label: 'Thiết lập Vai trò & Scopes', subtext: 'Cấu hình ma trận phân quyền RBAC đa cấp độ (OWN, TEAM, DEPT, COMPANY)', status: 'pending' },
    { id: 6, label: 'Tạo tài khoản Tenant Owner', subtext: 'Gán quyền COMPANY_ADMIN và sinh Username ADMIN-0001', status: 'pending' },
    { id: 7, label: 'Đăng ký vào CRM_CORE Registry', subtext: 'Đồng bộ kết nối Control DB và kích hoạt trạng thái READY', status: 'pending' },
  ];
  const [provisioningSteps, setProvisioningSteps] = useState<ProvisioningStep[]>(DEFAULT_PROVISIONING_STEPS);

  const resetLockout = () => {
    setIsLockedOut(false);
    setLockoutRemainingSeconds(0);
    setFailedAttempts(0);
    setLoginError(null);
  };

  // Sync DAL active database whenever currentCompany changes
  useEffect(() => {
    if (currentCompany) {
      multiTenantDAL.setActiveCompanyId(currentCompany.id);
      localStorage.setItem(STORAGE_KEYS.CURRENT_COMPANY, JSON.stringify(currentCompany));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_COMPANY);
    }
  }, [currentCompany]);

  useEffect(() => {
    if (currentAccount) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_ACCOUNT, JSON.stringify(currentAccount));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_ACCOUNT);
    }
  }, [currentAccount]);

  useEffect(() => {
    if (currentMember) {
      localStorage.setItem(STORAGE_KEYS.CURRENT_MEMBER, JSON.stringify(currentMember));
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_MEMBER);
    }
  }, [currentMember]);

  // Persist datasets
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COMPANIES, JSON.stringify(allCompanies));
  }, [allCompanies]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(allAccounts));
  }, [allAccounts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEMBERS, JSON.stringify(allMemberships));
  }, [allMemberships]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DEPARTMENTS, JSON.stringify(allDepartments));
  }, [allDepartments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ROLES, JSON.stringify(allRoles));
  }, [allRoles]);

  // Lockout countdown timer
  useEffect(() => {
    let timer: any;
    if (isLockedOut && lockoutRemainingSeconds > 0) {
      timer = setInterval(() => {
        setLockoutRemainingSeconds((prev) => {
          if (prev <= 1) {
            setIsLockedOut(false);
            setFailedAttempts(0);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [isLockedOut, lockoutRemainingSeconds]);

  /**
   * SESSION CONTEXT: Trả lời 5 câu hỏi cốt lõi tại mọi thời điểm
   */
  const sessionContext: SessionContext | null = useMemo(() => {
    if (!currentAccount || !currentCompany || !currentMember) return null;
    const dept = allDepartments.find((d) => d.id === currentMember.departmentId);
    const pos = allPositions.find((p) => p.id === currentMember.positionId);
    const lvl = allLevels.find((l) => l.id === currentMember.levelId);
    const role = allRoles.find((r) => r.id === currentMember.roleId);

    return {
      userId: currentAccount.id,
      tenantId: currentCompany.id,
      membershipId: currentMember.id,
      tenantCode: currentCompany.code,
      tenantName: currentCompany.name,
      database: currentCompany.database || `DB_${currentCompany.code.toUpperCase()}`,
      databaseStatus: currentCompany.databaseStatus || 'READY',
      username: currentMember.username || 'USER-0001',
      displayId: currentMember.displayId || `${currentCompany.code}-USER-0001`,
      fullName: currentAccount.fullName,
      roleCode: role?.code || 'USER',
      roleTitle: currentMember.roleTitle || role?.name || 'Nhân sự',
      departmentCode: dept?.code || 'GENERAL',
      departmentName: dept?.name || 'Toàn doanh nghiệp',
      positionName: pos?.name || 'Chuyên viên',
      levelName: lvl?.name || 'Staff',
      primaryScope: role?.defaultScope || 'OWN',
      permissions: currentMember.permissions || role?.permissions || [],
    };
  }, [currentAccount, currentCompany, currentMember, allDepartments, allPositions, allLevels, allRoles]);

  // List of memberships belonging to current account (for switching)
  const userMemberships = useMemo(() => {
    if (!currentAccount) return [];
    return allMemberships.filter((m) => m.userId === currentAccount.id && m.status === 'active');
  }, [currentAccount, allMemberships]);

  // List of companies current account belongs to
  const userCompanies = useMemo(() => {
    if (!currentAccount) return [];
    const compIds = userMemberships.map((m) => m.tenantId);
    return allCompanies.filter((c) => compIds.includes(c.id));
  }, [currentAccount, userMemberships, allCompanies]);

  // Memberships of current tenant
  const tenantMemberships = useMemo(() => {
    if (!currentCompany) return [];
    return allMemberships.filter((m) => m.tenantId === currentCompany.id);
  }, [currentCompany, allMemberships]);

  // Departments of current tenant
  const tenantDepartments = useMemo(() => {
    if (!currentCompany) return [];
    return allDepartments.filter((d) => d.tenantId === currentCompany.id);
  }, [currentCompany, allDepartments]);

  /**
   * Validate company code format and availability
   */
  const checkCompanyCodeAvailability = (code: string) => {
    const normalized = code.trim().toUpperCase();
    const regex = /^[A-Z0-9-]{3,20}$/;
    if (!regex.test(normalized)) {
      return {
        valid: false,
        available: false,
        error: 'Mã công ty phải từ 3-20 ký tự, gồm chữ in hoa (A-Z), số (0-9) và dấu gạch (-).',
      };
    }
    const exists = allCompanies.some((c) => c.code.toUpperCase() === normalized);
    if (exists) {
      return {
        valid: true,
        available: false,
        error: 'Mã công ty này đã được sử dụng. Vui lòng chọn mã khác.',
      };
    }
    return { valid: true, available: true };
  };

  /**
   * HANDLE LOGIN (Hỗ trợ: Email, Username SALE-0001, DisplayID APLUS-SALE-0001)
   */
  const login = async (
    companyCode: string,
    emailOrUser: string,
    password: string,
    remember: boolean
  ): Promise<boolean> => {
    try {
      setLoginError(null);

      if (isLockedOut) {
        setLoginError(`Tài khoản tạm thời bị khóa. Vui lòng bấm "Mở khóa ngay" hoặc thử lại sau ${lockoutRemainingSeconds} giây.`);
        return false;
      }

      const rawInput = (emailOrUser || '').trim();
      if (!rawInput) {
        setLoginError('Vui lòng nhập Username (ví dụ: SALE-0001) hoặc Email.');
        return false;
      }

      const cleanInput = rawInput.toLowerCase();
      const cleanCode = (companyCode || '').trim().toUpperCase();

      // Combined pools to guarantee latest demo accounts are always found even with legacy localStorage
      const poolCompanies = [
        ...allCompanies,
        ...INITIAL_TENANTS.filter((it) => !allCompanies.some((c) => c.id === it.id)),
      ];
      const poolAccounts = [
        ...allAccounts,
        ...INITIAL_ACCOUNTS.filter((ia) => !allAccounts.some((a) => a.id === ia.id)),
      ];
      const poolMemberships = [
        ...allMemberships,
        ...INITIAL_MEMBERSHIPS.filter((im) => !allMemberships.some((m) => m.id === im.id)),
      ];

      // 1. Tìm Target Tenant nếu có mã công ty hoặc subdomain
      let targetTenant: Tenant | undefined;
      if (cleanCode && cleanCode !== 'PLATFORM' && cleanCode !== 'CUSTOM') {
        targetTenant = poolCompanies.find(
          (c) =>
            (c.code && c.code.toUpperCase() === cleanCode) ||
            (c.slug && c.slug.toUpperCase() === cleanCode) ||
            (cleanCode === 'DEMO' && (c.code?.toUpperCase() === 'APLUS' || c.slug?.toLowerCase() === 'aplus'))
        );
      }

      // 2. Tìm Membership theo Username (SALE-0001) hoặc Display ID (APLUS-SALE-0001) hoặc employeeCode
      let matchedMembership = poolMemberships.find((m) => {
        const u = m.username ? m.username.toLowerCase() : '';
        const d = m.displayId ? m.displayId.toLowerCase() : '';
        const e = m.employeeCode ? m.employeeCode.toLowerCase() : '';
        const matchName = u === cleanInput || d === cleanInput || e === cleanInput;
        if (targetTenant) {
          return matchName && m.tenantId === targetTenant.id;
        }
        return matchName;
      });

      // Nếu có targetTenant nhưng chưa match vì user chỉ gõ username không kèm tenant:
      if (!matchedMembership && targetTenant) {
        matchedMembership = poolMemberships.find((m) => {
          const u = m.username ? m.username.toLowerCase() : '';
          const d = m.displayId ? m.displayId.toLowerCase() : '';
          return (u === cleanInput || d === cleanInput) && m.tenantId === targetTenant!.id;
        });
      }

      // 3. Tìm User Account tương ứng
      let matchedAccount: UserAccount | undefined;
      if (matchedMembership) {
        matchedAccount = poolAccounts.find((a) => a.id === matchedMembership!.userId);
        if (!targetTenant) {
          targetTenant = poolCompanies.find((c) => c.id === matchedMembership!.tenantId);
        }
      } else {
        // Tìm theo email hoặc họ tên hoặc ID hoặc username alias
        matchedAccount = poolAccounts.find((a) => {
          const emailLower = (a.email || '').toLowerCase();
          const emailPrefix = emailLower.split('@')[0];
          const idLower = (a.id || '').toLowerCase();
          const nameLower = (a.fullName || '').toLowerCase();
          return (
            emailLower === cleanInput ||
            emailPrefix === cleanInput ||
            idLower === cleanInput ||
            nameLower === cleanInput
          );
        });

        // Hỗ trợ alias email multi-tenant demo (b.nguyen@multicorp.vn hoặc vanb.consult@global.vn)
        if (!matchedAccount && (cleanInput === 'b.nguyen@multicorp.vn' || cleanInput === 'vanb.consult@global.vn')) {
          matchedAccount = poolAccounts.find((a) => a.id === 'usr_nguyenvanb_multi' || a.id === 'usr_nguyenvanb_alias');
        }
      }

      if (!matchedAccount) {
        // Thử tìm trong fallback tài khoản mẫu của APLUS
        if (cleanInput.includes('vana') || cleanInput.includes('sale-0001')) {
          matchedAccount = poolAccounts.find((a) => a.id === 'usr_vana_62zc') || INITIAL_ACCOUNTS.find((a) => a.id === 'usr_vana_62zc');
          if (!targetTenant) targetTenant = poolCompanies[0];
        } else if (cleanInput.includes('thanh') || cleanInput === 'admin' || cleanInput === 'admin-0001' || cleanInput === 'admin-0002') {
          matchedAccount = poolAccounts.find((a) => a.id === 'usr_thanh_93la') || INITIAL_ACCOUNTS.find((a) => a.id === 'usr_thanh_93la');
          if (!targetTenant) targetTenant = poolCompanies[0];
        } else if (cleanInput.includes('superadmin') || cleanInput.includes('huy')) {
          matchedAccount = poolAccounts.find((a) => a.id === 'usr_huy_72jd') || INITIAL_ACCOUNTS[0];
          if (!targetTenant) targetTenant = poolCompanies[0];
        } else if (cleanInput.includes('chau') || cleanInput.includes('dir-0001')) {
          matchedAccount = poolAccounts.find((a) => a.id === 'usr_chau_81ks') || INITIAL_ACCOUNTS[1];
          if (!targetTenant) targetTenant = poolCompanies[0];
        } else if (cleanInput.includes('long') || cleanInput.includes('sale-0002')) {
          matchedAccount = poolAccounts.find((a) => a.id === 'usr_long_41pb') || INITIAL_ACCOUNTS[3];
          if (!targetTenant) targetTenant = poolCompanies[0];
        } else if (cleanInput.includes('mkt-0005') || cleanInput.includes('tranb')) {
          matchedAccount = poolAccounts.find((a) => a.id === 'usr_tranb_55mk') || INITIAL_ACCOUNTS[4];
          if (!targetTenant) targetTenant = poolCompanies.find((c) => c.code === 'ABC') || poolCompanies[1];
        }
      }

      // 4. Kiểm tra mật khẩu (linh hoạt cho môi trường thử nghiệm và demo)
      const inputPass = (password || '').trim();
      const isValidPassword =
        matchedAccount &&
        (inputPass === matchedAccount.passwordHash ||
          inputPass === 'password123' ||
          inputPass === '123456' ||
          inputPass === 'admin123' ||
          inputPass === '12345678' ||
          inputPass === 'aplus123' ||
          inputPass.length >= 3); // Chấp nhận mọi mật khẩu trong prototype demo để không làm gián đoạn người dùng

      if (!matchedAccount || !isValidPassword) {
        const nextFail = failedAttempts + 1;
        setFailedAttempts(nextFail);
        if (nextFail >= 7) {
          setIsLockedOut(true);
          setLockoutRemainingSeconds(300); // 5 phút (có nút mở khóa ngay)
          setLoginError('Tài khoản bị tạm khóa do nhập sai mật khẩu quá 7 lần. Bấm "Mở khóa ngay" để tiếp tục.');
        } else {
          setLoginError(`Thông tin tài khoản hoặc mật khẩu không khớp. Mật khẩu dùng chung: password123`);
        }
        return false;
      }

      if (matchedAccount.status === 'locked') {
        setLoginError('Tài khoản của bạn đã bị khóa. Vui lòng bấm "Mở khóa ngay" hoặc liên hệ Quản trị viên.');
        return false;
      }

      // Platform SuperAdmin direct access
      if (matchedAccount.isPlatformAdmin && cleanCode === 'PLATFORM') {
        setCurrentAccount(matchedAccount);
        setIsPlatformMode(true);
        if (typeof window !== 'undefined') localStorage.removeItem('crm_has_logged_out');
        return true;
      }

      // 5. Xác định Membership hợp lệ cho User trong Tenant
      let userMems = poolMemberships.filter(
        (m) => m.userId === matchedAccount!.id && m.status === 'active'
      );

      // Nếu user chưa có membership, tạo fallback membership phù hợp
      if (userMems.length === 0) {
        const defaultTenant = targetTenant || poolCompanies[0];
        const fallbackMem: Membership = {
          id: `mem_${matchedAccount.id}_${defaultTenant.id}`,
          tenantId: defaultTenant.id,
          userId: matchedAccount.id,
          roleId: 'role_company_admin',
          username: cleanInput.toUpperCase(),
          displayId: `${defaultTenant.code}-${cleanInput.toUpperCase()}`,
          roleTitle: 'Thành viên hệ thống',
          status: 'active',
          joinedAt: new Date().toISOString().split('T')[0],
          permissions: DEFAULT_PERMISSIONS_MATRIX('COMPANY'),
        };
        userMems = [fallbackMem];
        setAllMemberships((prev) => [...prev, fallbackMem]);
      }

      // Nếu có mã công ty mục tiêu
      if (targetTenant) {
        let memInTarget = userMems.find((m) => m.tenantId === targetTenant!.id);
        if (!memInTarget) {
          // Nếu user chưa thuộc targetTenant nhưng đăng nhập vào subdomain đó, tự động cấp quyền truy cập demo
          memInTarget = {
            id: `mem_${matchedAccount.id}_${targetTenant.id}`,
            tenantId: targetTenant.id,
            userId: matchedAccount.id,
            roleId: 'role_company_admin',
            username: matchedMembership?.username || cleanInput.toUpperCase(),
            displayId: `${targetTenant.code}-${matchedMembership?.username || cleanInput.toUpperCase()}`,
            roleTitle: 'Thành viên tổ chức',
            status: 'active',
            joinedAt: new Date().toISOString().split('T')[0],
            permissions: DEFAULT_PERMISSIONS_MATRIX('COMPANY'),
          };
          setAllMemberships((prev) => [...prev, memInTarget!]);
        }

        setCurrentAccount(matchedAccount);
        setCurrentCompany(targetTenant);
        setCurrentMember(memInTarget);
        setFailedAttempts(0);
        setIsPlatformMode(false);
        setLoginError(null);
        multiTenantDAL.setActiveCompanyId(targetTenant.id);

        if (typeof window !== 'undefined') {
          localStorage.removeItem('crm_has_logged_out');
          localStorage.setItem(STORAGE_KEYS.CURRENT_ACCOUNT, JSON.stringify(matchedAccount));
          localStorage.setItem(STORAGE_KEYS.CURRENT_COMPANY, JSON.stringify(targetTenant));
          localStorage.setItem(STORAGE_KEYS.CURRENT_MEMBER, JSON.stringify(memInTarget));
          if (remember) {
            localStorage.setItem(STORAGE_KEYS.REMEMBER_CODE, targetTenant.code);
            setRememberCompanyCode(targetTenant.code);
          }
        }
        return true;
      }

      // Nếu không nhập mã công ty:
      if (userMems.length === 1) {
        const singleMem = userMems[0];
        const singleComp = poolCompanies.find((c) => c.id === singleMem.tenantId) || poolCompanies[0];
        setCurrentAccount(matchedAccount);
        setCurrentCompany(singleComp);
        setCurrentMember(singleMem);
        setFailedAttempts(0);
        setIsPlatformMode(false);
        setLoginError(null);
        multiTenantDAL.setActiveCompanyId(singleComp.id);

        if (typeof window !== 'undefined') {
          localStorage.removeItem('crm_has_logged_out');
          localStorage.setItem(STORAGE_KEYS.CURRENT_ACCOUNT, JSON.stringify(matchedAccount));
          localStorage.setItem(STORAGE_KEYS.CURRENT_COMPANY, JSON.stringify(singleComp));
          localStorage.setItem(STORAGE_KEYS.CURRENT_MEMBER, JSON.stringify(singleMem));
        }
        return true;
      }

      // Nếu thuộc nhiều công ty -> Mở modal chọn Workspace
      const accessibleComps = poolCompanies.filter((c) => userMems.some((m) => m.tenantId === c.id));
      setPendingLoginAccount(matchedAccount);
      setPendingMultiCompanySelection(accessibleComps);
      setAuthScreenMode('SELECT_WORKSPACE');
      return true;
    } catch (err: any) {
      console.error('[MultiTenant Auth Error]:', err);
      setLoginError(`Lỗi xác thực: ${err?.message || 'Không thể kết nối CSDL'}. Vui lòng thử lại.`);
      return false;
    }
  };

  /**
   * Chọn không gian làm việc sau khi xác thực email/password thành công
   */
  const selectWorkspace = (companyId: string) => {
    const targetComp = allCompanies.find((c) => c.id === companyId);
    if (!targetComp || !pendingLoginAccount) return;

    const mem = allMemberships.find(
      (m) => m.userId === pendingLoginAccount.id && m.tenantId === targetComp.id
    );

    if (mem) {
      setCurrentAccount(pendingLoginAccount);
      setCurrentCompany(targetComp);
      setCurrentMember(mem);
      setFailedAttempts(0);
      setIsPlatformMode(false);
      setAuthScreenMode('LOGIN');
      setPendingLoginAccount(null);
      setPendingMultiCompanySelection(null);
      if (typeof window !== 'undefined') localStorage.removeItem('crm_has_logged_out');
    }
  };

  /**
   * CHUYỂN ĐỔI TENANT (Tenant Switching - Section 16)
   * 1. Invalidate current context
   * 2. Resolve new Membership
   * 3. Load new role & permissions
   * 4. Connect new Tenant Database
   */
  const switchTenant = (tenantId: string): boolean => {
    if (!currentAccount) return false;
    const targetComp = allCompanies.find((c) => c.id === tenantId);
    if (!targetComp) return false;

    const targetMem = allMemberships.find(
      (m) => m.userId === currentAccount.id && m.tenantId === targetComp.id && m.status === 'active'
    );

    if (!targetMem) return false;

    // Invalidate & Resolve new Context
    setCurrentCompany(targetComp);
    setCurrentMember(targetMem);
    multiTenantDAL.setActiveCompanyId(targetComp.id);

    localStorage.setItem(STORAGE_KEYS.CURRENT_COMPANY, JSON.stringify(targetComp));
    localStorage.setItem(STORAGE_KEYS.CURRENT_MEMBER, JSON.stringify(targetMem));
    localStorage.setItem(STORAGE_KEYS.REMEMBER_CODE, targetComp.code);
    setRememberCompanyCode(targetComp.code);

    return true;
  };

  const switchCompany = (companyId: string): boolean => {
    return switchTenant(companyId);
  };

  const switchMembership = (membershipId: string): boolean => {
    const targetMem = allMemberships.find((m) => m.id === membershipId);
    if (!targetMem) return false;
    const targetComp = allCompanies.find((c) => c.id === targetMem.tenantId);
    if (!targetComp) return false;

    setCurrentCompany(targetComp);
    setCurrentMember(targetMem);
    multiTenantDAL.setActiveCompanyId(targetComp.id);
    return true;
  };

  /**
   * ĐĂNG XUẤT
   */
  const logout = () => {
    setCurrentAccount(null);
    setCurrentCompany(null);
    setCurrentMember(null);
    setIsPlatformMode(false);
    setAuthScreenMode('LOGIN');
    if (typeof window !== 'undefined') {
      localStorage.setItem('crm_has_logged_out', 'true');
      localStorage.removeItem(STORAGE_KEYS.CURRENT_ACCOUNT);
      localStorage.removeItem(STORAGE_KEYS.CURRENT_COMPANY);
      localStorage.removeItem(STORAGE_KEYS.CURRENT_MEMBER);
    }
  };

  /**
   * PROVISION DATABASE WORKFLOW (Section 07 & 08)
   * UI hiển thị tiến trình: Tạo doanh nghiệp -> Cấp phát CSDL -> Apply Schema ->
   * Tạo phòng ban -> Tạo vai trò -> Tạo Owner -> Đăng ký CRM_CORE -> READY.
   */
  const provisionTenantWithSteps = async (
    payload: RegisterCompanyPayload
  ): Promise<{ success: boolean; tenant?: Tenant; error?: string }> => {
    setIsProvisioning(true);
    setProvisioningSteps(DEFAULT_PROVISIONING_STEPS);

    const code = payload.companyCode.trim().toUpperCase();
    const slug = code.toLowerCase();
    const tenantId = `tenant_${slug}_${Date.now().toString(36)}`;
    const dbName = `DB_${code}`;
    const userId = `usr_owner_${Date.now().toString(36)}`;

    // Helper step update
    const setStepState = (id: number, status: 'running' | 'completed' | 'error') => {
      setProvisioningSteps((prev) =>
        prev.map((s) => (s.id === id ? { ...s, status } : s))
      );
    };

    try {
      // Step 1: Tạo Tenant Entity
      setStepState(1, 'running');
      await new Promise((r) => setTimeout(r, 400));
      setStepState(1, 'completed');

      // Step 2: Cấp phát Database riêng biệt
      setStepState(2, 'running');
      await new Promise((r) => setTimeout(r, 450));
      setStepState(2, 'completed');

      // Step 3: Áp dụng CRM Schema
      setStepState(3, 'running');
      await new Promise((r) => setTimeout(r, 450));
      setStepState(3, 'completed');

      // Step 4: Tạo 6 phòng ban mặc định
      setStepState(4, 'running');
      const newDepts: Department[] = [
        { id: `dept_${slug}_sale`, tenantId, code: 'SALE', name: 'Phòng Kinh Doanh (Sales)', description: 'Quản trị khách hàng và doanh thu', userCount: 1 },
        { id: `dept_${slug}_mkt`, tenantId, code: 'MKT', name: 'Phòng Tiếp Thị (Marketing)', description: 'Thu hút khách hàng tiềm năng', userCount: 0 },
        { id: `dept_${slug}_tech`, tenantId, code: 'TECH', name: 'Phòng Kỹ Thuật (Technology)', description: 'Khảo sát và triển khai dự án', userCount: 0 },
        { id: `dept_${slug}_hr`, tenantId, code: 'HR', name: 'Phòng Nhân Sự (HR)', description: 'Quản trị nhân sự và phúc lợi', userCount: 0 },
        { id: `dept_${slug}_acc`, tenantId, code: 'ACCOUNTING', name: 'Phòng Kế Toán (Accounting)', description: 'Quản trị dòng tiền và hóa đơn', userCount: 0 },
        { id: `dept_${slug}_ops`, tenantId, code: 'OPERATIONS', name: 'Phòng Vận Hành (Operations)', description: 'Quản lý kho và giao vận', userCount: 0 },
      ];
      setAllDepartments((prev) => [...prev, ...newDepts]);
      await new Promise((r) => setTimeout(r, 350));
      setStepState(4, 'completed');

      // Step 5: Thiết lập Vai trò & Scopes (Quyền Admin)
      setStepState(5, 'running');
      const newRole: Role = {
        id: `role_${slug}_admin`,
        tenantId,
        code: 'ADMIN',
        name: 'Admin',
        description: 'Toàn quyền quản trị điều hành doanh nghiệp',
        defaultScope: 'COMPANY',
        permissions: [
          { module: 'Customer', moduleLabel: 'Khách hàng', actions: ['view', 'create', 'edit', 'delete'], scope: 'COMPANY' },
          { module: 'Lead', moduleLabel: 'Leads', actions: ['view', 'create', 'edit', 'delete'], scope: 'COMPANY' },
          { module: 'Deal', moduleLabel: 'Deals', actions: ['view', 'create', 'edit', 'delete'], scope: 'COMPANY' },
          { module: 'Order', moduleLabel: 'Đơn hàng & Hợp đồng', actions: ['view', 'create', 'edit', 'delete'], scope: 'COMPANY' },
          { module: 'Inventory', moduleLabel: 'Kho & Vật tư', actions: ['view', 'create', 'edit', 'delete'], scope: 'COMPANY' },
          { module: 'Technical', moduleLabel: 'Kỹ thuật & Dự án', actions: ['view', 'create', 'edit', 'delete'], scope: 'COMPANY' },
          { module: 'HR', moduleLabel: 'Nhân sự', actions: ['view', 'create', 'edit', 'delete'], scope: 'COMPANY' },
          { module: 'Report', moduleLabel: 'Báo cáo', actions: ['view', 'create', 'edit', 'delete'], scope: 'COMPANY' },
          { module: 'Settings', moduleLabel: 'Cài đặt', actions: ['view', 'edit'], scope: 'COMPANY' },
        ],
      };
      setAllRoles((prev) => [...prev, newRole]);
      await new Promise((r) => setTimeout(r, 350));
      setStepState(5, 'completed');

      // Step 6: Tạo Owner User & Membership với vai trò Admin
      setStepState(6, 'running');
      const newOwnerAccount: UserAccount = {
        id: userId,
        email: payload.email.trim().toLowerCase(),
        fullName: payload.adminName.trim(),
        phone: payload.adminPhone || payload.phone || '',
        avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces',
        passwordHash: payload.password,
        status: 'active',
        failedAttempts: 0,
        createdAt: new Date().toISOString().split('T')[0],
      };
      setAllAccounts((prev) => [...prev, newOwnerAccount]);

      const newOwnerMembership: Membership = {
        id: `mem_${slug}_owner`,
        tenantId,
        userId,
        departmentId: newDepts[0].id,
        positionId: 'pos_aplus_dir',
        levelId: 'lvl_dir',
        roleId: newRole.id,
        employeeCode: '0001',
        username: 'ADMIN-0001',
        displayId: `${code}-ADMIN-0001`,
        roleTitle: 'Admin',
        status: 'active',
        joinedAt: new Date().toISOString().split('T')[0],
        permissions: newRole.permissions,
      };
      setAllMemberships((prev) => [...prev, newOwnerMembership]);
      await new Promise((r) => setTimeout(r, 400));
      setStepState(6, 'completed');

      // Step 7: Đăng ký vào CRM_CORE Registry
      setStepState(7, 'running');
      const newTenant: Tenant = {
        id: tenantId,
        code,
        slug,
        name: payload.companyName.trim(),
        database: dbName,
        databaseStatus: 'READY',
        schemaVersion: 'v3.4.2-enterprise',
        storageGb: 0.1,
        plan: 'Enterprise',
        status: 'active',
        userCount: 1,
        maxUsers: 100,
        departmentCount: 6,
        customerCount: 0,
        dealCount: 0,
        taxCode: payload.taxCode || '0109988776',
        phone: payload.phone || '',
        address: payload.address || 'Việt Nam',
        email: payload.email,
        createdAt: new Date().toISOString().split('T')[0],
        lastBackup: 'Vừa khởi tạo',
        lastActivity: 'Vừa xong',
      };
      setAllCompanies((prev) => [...prev, newTenant]);
      await new Promise((r) => setTimeout(r, 450));
      setStepState(7, 'completed');

      // Đăng nhập tự động vào Tenant mới với vai trò Admin
      setCurrentAccount(newOwnerAccount);
      setCurrentCompany(newTenant);
      setCurrentMember(newOwnerMembership);
      setIsPlatformMode(false);
      setAuthScreenMode('LOGIN');
      setShowOnboardingWizard(false);
      setIsProvisioning(false);

      return { success: true, tenant: newTenant };
    } catch (e: any) {
      setIsProvisioning(false);
      return { success: false, error: e.message || 'Lỗi khi cấp phát cơ sở dữ liệu.' };
    }
  };

  /**
   * Đăng ký doanh nghiệp mới (Tạo yêu cầu chờ Super Admin duyệt)
   */
  const submitCompanyRegistration = async (
    payload: RegisterCompanyPayload
  ): Promise<{ success: boolean; request?: CompanyRegistrationRequest; error?: string }> => {
    const code = payload.companyCode.trim().toUpperCase();
    const existingComp = allCompanies.find((c) => c.code.toUpperCase() === code);
    if (existingComp) {
      return { success: false, error: `Mã công ty "${code}" đã tồn tại trong hệ thống.` };
    }

    const newReq: CompanyRegistrationRequest = {
      id: `req_${Date.now().toString(36)}`,
      companyName: payload.companyName.trim(),
      companyCode: code,
      taxCode: payload.taxCode,
      phone: payload.phone,
      address: payload.address,
      adminName: payload.adminName.trim(),
      email: payload.email.trim().toLowerCase(),
      adminPhone: payload.adminPhone,
      password: payload.password,
      requestedAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      status: 'PENDING',
      databaseName: `DB_${code}`,
    };

    setPendingCompanyRegistrations((prev) => {
      const updated = [newReq, ...prev.filter((r) => r.companyCode !== code)];
      try {
        localStorage.setItem('crm_pending_company_registrations', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });

    return { success: true, request: newReq };
  };

  /**
   * Super Admin phê duyệt yêu cầu đăng ký & cấp phát CSDL riêng biệt
   */
  const approveCompanyRegistration = async (
    requestId: string
  ): Promise<{ success: boolean; tenant?: Tenant; error?: string }> => {
    const req = pendingCompanyRegistrations.find((r) => r.id === requestId);
    if (!req) return { success: false, error: 'Không tìm thấy yêu cầu đăng ký.' };

    const payload: RegisterCompanyPayload = {
      companyName: req.companyName,
      companyCode: req.companyCode,
      taxCode: req.taxCode,
      phone: req.phone,
      address: req.address,
      adminName: req.adminName,
      email: req.email,
      adminPhone: req.adminPhone,
      password: req.password,
      agreedTerms: true,
    };

    const res = await provisionTenantWithSteps(payload);
    if (res.success && res.tenant) {
      setPendingCompanyRegistrations((prev) => {
        const updated = prev.map((r) =>
          r.id === requestId ? { ...r, status: 'APPROVED' as const, approvedAt: new Date().toISOString().replace('T', ' ').slice(0, 16) } : r
        );
        try {
          localStorage.setItem('crm_pending_company_registrations', JSON.stringify(updated));
        } catch (e) {}
        return updated;
      });
      return { success: true, tenant: res.tenant };
    }
    return res;
  };

  /**
   * Super Admin từ chối yêu cầu đăng ký
   */
  const rejectCompanyRegistration = (requestId: string) => {
    setPendingCompanyRegistrations((prev) => {
      const updated = prev.map((r) =>
        r.id === requestId ? { ...r, status: 'REJECTED' as const } : r
      );
      try {
        localStorage.setItem('crm_pending_company_registrations', JSON.stringify(updated));
      } catch (e) {}
      return updated;
    });
  };

  const registerNewCompany = async (payload: RegisterCompanyPayload) => {
    const res = await submitCompanyRegistration(payload);
    return { success: res.success, error: res.error };
  };

  /**
   * TẠO NHÂN VIÊN MỚI (User & Membership Creation - Section 11 & 12)
   * Tự động sinh:
   * - Username: {DEPT_CODE}-{EMP_CODE} (e.g. SALE-0003)
   * - Display ID: {TENANT_CODE}-{DEPT_CODE}-{EMP_CODE} (e.g. APLUS-SALE-0003)
   */
  const createEmployeeUser = (payload: CreateEmployeePayload): Membership => {
    if (!currentCompany) throw new Error('Không có Tenant nào đang mở.');

    const dept = allDepartments.find((d) => d.id === payload.departmentId);
    const deptCode = dept?.code || 'GEN';
    const role = allRoles.find((r) => r.id === payload.roleId);

    // Tính mã nhân viên tiếp theo
    const currentDeptMems = allMemberships.filter(
      (m) => m.tenantId === currentCompany.id && m.departmentId === payload.departmentId
    );
    const nextNum = currentDeptMems.length + 1;
    const employeeCode = payload.employeeCode || nextNum.toString().padStart(4, '0');

    const username = `${deptCode}-${employeeCode}`;
    const displayId = `${currentCompany.code}-${deptCode}-${employeeCode}`;

    // Tìm hoặc tạo User Account
    let account = allAccounts.find((a) => a.email.toLowerCase() === payload.email.toLowerCase());
    if (!account) {
      account = {
        id: `usr_${Date.now().toString(36)}`,
        email: payload.email.trim().toLowerCase(),
        fullName: payload.fullName.trim(),
        phone: payload.phone.trim(),
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=100&h=100&fit=crop&crop=faces',
        passwordHash: payload.password || 'password123',
        status: 'active',
        failedAttempts: 0,
        createdAt: new Date().toISOString().split('T')[0],
      };
      setAllAccounts((prev) => [...prev, account!]);
    }

    const pos = allPositions.find((p) => p.id === payload.positionId);
    const newMem: Membership = {
      id: `mem_${Date.now().toString(36)}`,
      tenantId: currentCompany.id,
      userId: account.id,
      departmentId: payload.departmentId,
      positionId: payload.positionId,
      levelId: payload.levelId,
      roleId: payload.roleId,
      employeeCode,
      username,
      displayId,
      roleTitle: pos?.name || role?.name || 'Chuyên viên',
      status: 'active',
      joinedAt: new Date().toISOString().split('T')[0],
      permissions: role?.permissions || [],
    };

    setAllMemberships((prev) => [...prev, newMem]);

    // Cập nhật số lượng user trong Tenant
    setAllCompanies((prev) =>
      prev.map((c) => (c.id === currentCompany.id ? { ...c, userCount: c.userCount + 1 } : c))
    );

    return newMem;
  };

  /**
   * CẬP NHẬT SCOPE CHO THÀNH VIÊN
   */
  const updateMembershipScope = (membershipId: string, moduleName: string, scope: PermissionScope) => {
    setAllMemberships((prev) =>
      prev.map((m) => {
        if (m.id === membershipId) {
          const updatedPerms = m.permissions.map((p) =>
            p.module === moduleName ? { ...p, scope } : p
          );
          return { ...m, permissions: updatedPerms };
        }
        return m;
      })
    );
  };

  const deleteMembership = (membershipId: string) => {
    setAllMemberships((prev) => prev.filter((m) => m.id !== membershipId));
  };

  /**
   * CẬP NHẬT TÀI KHOẢN NHÂN VIÊN TỪ ADMIN (Thay đổi Mã ID, Email, Họ tên, Phòng ban,...)
   * Chỉ Quản trị viên (Admin) hoặc người được phân quyền mới có thể thực hiện
   */
  const updateEmployeeAccountByAdmin = (payload: UpdateEmployeeAccountPayload): boolean => {
    // 1. Cập nhật UserAccount (Họ tên, email, phone)
    setAllAccounts((prev) => {
      const updatedList = prev.map((acc) => {
        if (acc.id === payload.userId) {
          const updated = {
            ...acc,
            fullName: payload.fullName !== undefined ? payload.fullName.trim() : acc.fullName,
            email: payload.email !== undefined ? payload.email.trim().toLowerCase() : acc.email,
            phone: payload.phone !== undefined ? payload.phone.trim() : acc.phone,
          };
          if (currentAccount?.id === acc.id) {
            setCurrentAccount(updated);
            if (typeof window !== 'undefined') {
              localStorage.setItem(STORAGE_KEYS.CURRENT_ACCOUNT, JSON.stringify(updated));
            }
          }
          return updated;
        }
        return acc;
      });
      if (typeof window !== 'undefined') {
        localStorage.setItem(STORAGE_KEYS.ACCOUNTS, JSON.stringify(updatedList));
      }
      return updatedList;
    });

    // 2. Cập nhật Membership (employeeCode, displayId, username, departmentId, positionId, levelId, roleId)
    setAllMemberships((prev) => {
      const updatedList = prev.map((mem) => {
        if (mem.id === payload.membershipId) {
          const dept = payload.departmentId ? allDepartments.find((d) => d.id === payload.departmentId) : undefined;
          const deptCode = dept?.code || mem.username.split('-')[0] || 'GEN';
          const empCode = payload.employeeCode !== undefined ? payload.employeeCode.trim() : mem.employeeCode;
          const pos = payload.positionId ? allPositions.find((p) => p.id === payload.positionId) : undefined;
          const role = payload.roleId ? allRoles.find((r) => r.id === payload.roleId) : undefined;

          const newUsername = payload.employeeCode !== undefined ? `${deptCode}-${empCode}` : mem.username;
          const newDisplayId = payload.displayId !== undefined 
            ? payload.displayId.trim() 
            : (payload.employeeCode !== undefined ? `${currentCompany?.code || 'APLUS'}-${deptCode}-${empCode}` : mem.displayId);

          const updatedMem: Membership = {
            ...mem,
            departmentId: payload.departmentId || mem.departmentId,
            positionId: payload.positionId || mem.positionId,
            levelId: payload.levelId || mem.levelId,
            roleId: payload.roleId || mem.roleId,
            employeeCode: empCode,
            username: newUsername,
            displayId: newDisplayId,
            roleTitle: pos?.name || role?.name || mem.roleTitle,
            permissions: role?.permissions || mem.permissions,
          };

          if (currentMember?.id === mem.id) {
            setCurrentMember(updatedMem);
            if (typeof window !== 'undefined') {
              localStorage.setItem(STORAGE_KEYS.CURRENT_MEMBER, JSON.stringify(updatedMem));
            }
          }
          return updatedMem;
        }
        return mem;
      });
      return updatedList;
    });

    return true;
  };

  const requestJoinCompany = async (payload: RequestJoinPayload) => {
    const newReq: JoinRequest = {
      id: `req-${Date.now()}`,
      companyId: currentCompany?.id || 'tenant_aplus',
      accountId: currentAccount?.id || 'usr_guest',
      fullName: payload.fullName,
      email: payload.email,
      phone: payload.phone || '',
      requestedAt: new Date().toISOString().split('T')[0],
      status: 'pending',
    };
    setJoinRequests((prev) => [newReq, ...prev]);
    return { success: true };
  };

  const acceptInvitation = async (payload: AcceptInvitePayload) => {
    return { success: true };
  };

  const requestPasswordReset = (companyCode: string, email: string) => {
    return { success: true, hasSmtp: true, message: `Đã gửi hướng dẫn khôi phục mật khẩu đến ${email}.` };
  };

  const generateManualResetLink = (targetEmail: string) => {
    return `https://aplus.crm.aplus.vn/reset-password?token=RST-${Date.now().toString(36)}`;
  };

  const createCompanyInvitation = (roleGroupId: string, roleTitle: string, expiresDays: number, maxUses: number): CompanyInvitation => {
    const inv: CompanyInvitation = {
      id: `inv-${Date.now()}`,
      companyId: currentCompany?.id || 'tenant_aplus',
      code: `INV-${currentCompany?.code || 'APLUS'}-${Math.random().toString(36).substr(2, 4).toUpperCase()}`,
      roleGroupId,
      roleTitle,
      expiresAt: new Date(Date.now() + expiresDays * 86400000).toISOString().split('T')[0],
      maxUses,
      usedCount: 0,
      createdAt: new Date().toISOString().split('T')[0],
      createdBy: currentAccount?.fullName || 'Admin',
      status: 'active',
      linkUrl: `https://${currentCompany?.slug || 'aplus'}.crm.aplus.vn/join`,
    };
    setCompanyInvitations((prev) => [inv, ...prev]);
    return inv;
  };

  const revokeCompanyInvitation = (invitationId: string) => {
    setCompanyInvitations((prev) => prev.filter((i) => i.id !== invitationId));
  };

  const reviewJoinRequest = (requestId: string, action: 'approve' | 'reject') => {
    setJoinRequests((prev) =>
      prev.map((r) => (r.id === requestId ? { ...r, status: action === 'approve' ? 'approved' : 'rejected' } : r))
    );
  };

  const toggleCompanyStatus = (companyId: string) => {
    setAllCompanies((prev) =>
      prev.map((c) =>
        c.id === companyId
          ? { ...c, status: c.status === 'active' ? 'suspended' : 'active' }
          : c
      )
    );
  };

  const toggleAllowNewRegistration = () => {
    setPlatformConfig((prev) => ({
      ...prev,
      allowNewCompanyRegistration: !prev.allowNewCompanyRegistration,
    }));
  };

  const generateAdminResetLink = (companyId: string) => {
    return `https://crm.aplus.vn/admin/reset?tenant=${companyId}&key=${Date.now()}`;
  };

  const runDataIsolationAudit = (): FullAuditReport => {
    return multiTenantDAL.runIsolationAudit();
  };

  const resetToDefaultData = () => {
    try {
      if (typeof window !== 'undefined') {
        Object.values(STORAGE_KEYS).forEach((k) => localStorage.removeItem(k));
        localStorage.removeItem('crm_has_logged_out');
      }
      setAllCompanies(INITIAL_TENANTS);
      setAllAccounts(INITIAL_ACCOUNTS);
      setAllMemberships(INITIAL_MEMBERSHIPS);
      setAllDepartments(INITIAL_DEPARTMENTS);
      setAllRoles(INITIAL_ROLES);
      setCurrentCompany(INITIAL_TENANTS[0]);
      setCurrentAccount(INITIAL_ACCOUNTS[0]);
      setCurrentMember(INITIAL_MEMBERSHIPS[0]);
      setIsLockedOut(false);
      setFailedAttempts(0);
      setLockoutRemainingSeconds(0);
      setLoginError(null);
      setIsPlatformMode(false);
      setAuthScreenMode('LOGIN');
      multiTenantDAL.setActiveCompanyId(INITIAL_TENANTS[0].id);
    } catch (e) {
      console.error('Error resetting data:', e);
    }
  };

  const isAuthenticated = !!currentAccount && !!currentCompany && !!currentMember;

  return (
    <MultiTenantContext.Provider
      value={{
        isAuthenticated,
        currentAccount,
        currentCompany,
        currentMember,
        sessionContext,
        tenants: allCompanies,
        allCompanies,
        userCompanies,
        allAccounts,
        userMemberships,
        tenantMemberships,
        allDepartments,
        tenantDepartments,
        allPositions,
        allLevels,
        allRoles,
        allMemberships,
        authScreenMode,
        setAuthScreenMode,
        isPlatformMode,
        setIsPlatformMode,
        showOnboardingWizard,
        setShowOnboardingWizard,
        isProvisioning,
        provisioningSteps,
        provisionTenantWithSteps,
        createEmployeeUser,
        updateMembershipScope,
        deleteMembership,
        updateEmployeeAccountByAdmin,
        loginError,
        failedAttempts,
        isLockedOut,
        lockoutRemainingSeconds,
        rememberCompanyCode,
        pendingMultiCompanySelection,
        resetLockout,
        login,
        logout,
        selectWorkspace,
        switchCompany,
        switchTenant,
        switchMembership,
        joinRequests,
        companyInvitations,
        platformConfig,
        pendingCompanyRegistrations,
        submitCompanyRegistration,
        approveCompanyRegistration,
        rejectCompanyRegistration,
        registerNewCompany,
        requestJoinCompany,
        acceptInvitation,
        checkCompanyCodeAvailability,
        requestPasswordReset,
        generateManualResetLink,
        createCompanyInvitation,
        revokeCompanyInvitation,
        reviewJoinRequest,
        toggleCompanyStatus,
        toggleAllowNewRegistration,
        generateAdminResetLink,
        runDataIsolationAudit,
        resetToDefaultData,
      }}
    >
      {children}
    </MultiTenantContext.Provider>
  );
};

export const useMultiTenant = () => {
  const context = useContext(MultiTenantContext);
  if (!context) {
    throw new Error('useMultiTenant must be used within a MultiTenantProvider');
  }
  return context;
};
