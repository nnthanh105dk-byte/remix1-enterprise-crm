import React, { useState, useEffect } from 'react';
import { useCRM } from '../context/CRMContext';
import { DirectorDashboard } from './dashboards/DirectorDashboard';
import { TechnicalManagerDashboard } from './dashboards/TechnicalManagerDashboard';
import { SalesManagerDashboard } from './dashboards/SalesManagerDashboard';
import { SalesStaffDashboard } from './dashboards/SalesStaffDashboard';
import {
  Settings2,
  Calendar,
  CheckCircle2,
  Circle,
  Plus,
  ArrowUpRight,
  TrendingUp,
  AlertCircle,
  Eye,
  EyeOff,
  MoveUp,
  MoveDown,
  RotateCcw,
  X,
  Sparkles,
  PhoneCall,
  Mail,
  FileCheck2,
  Clock,
  ArrowRight,
  Check,
  DollarSign,
  Users,
  Target,
  Percent,
  Briefcase,
  Layers,
  ChevronDown,
} from 'lucide-react';

export interface DashboardWidgetConfig {
  id: string;
  name: string;
  category: 'sales' | 'customer' | 'task' | 'management' | 'ai';
  categoryLabel: string;
  enabled: boolean;
  colSpan?: 1 | 2 | 3;
}

const DEFAULT_WIDGETS: DashboardWidgetConfig[] = [
  { id: 'kpi_cards', name: 'Chỉ số KPI chính (Doanh thu, Khách hàng, Cơ hội, Chuyển đổi)', category: 'sales', categoryLabel: 'Sales', enabled: true, colSpan: 3 },
  { id: 'ai_insight', name: 'AI Insight & Khuyến nghị điều hành', category: 'ai', categoryLabel: 'Trí tuệ nhân tạo', enabled: true, colSpan: 3 },
  { id: 'revenue_pipeline', name: 'Biểu đồ Doanh thu & Phễu Pipeline', category: 'sales', categoryLabel: 'Sales', enabled: true, colSpan: 2 },
  { id: 'tasks_today', name: 'Công việc & Nhắc nhở hôm nay', category: 'task', categoryLabel: 'Công việc', enabled: true, colSpan: 1 },
  { id: 'top_customers', name: 'Top Khách hàng trọng điểm', category: 'customer', categoryLabel: 'Khách hàng', enabled: true, colSpan: 2 },
  { id: 'activity_timeline', name: 'Nhật ký hoạt động (Timeline)', category: 'management', categoryLabel: 'Quản lý', enabled: true, colSpan: 1 },
];

const STORAGE_KEY = 'aplus_enterprise_crm_dashboard_layout_v1';

export const RoleDemoBanner: React.FC = () => {
  const { currentUser, switchDemoUser } = useCRM();

  const demoRoles = [
    {
      id: 'usr-1',
      name: 'Nguyễn Khắc Huy',
      role: 'Super Admin',
      scope: 'Toàn hệ thống',
      badgeClass: 'bg-purple-100 text-purple-700 dark:bg-purple-950 dark:text-purple-300 border-purple-200 dark:border-purple-800',
      activeRing: 'border-purple-500 bg-purple-50/60 dark:bg-purple-950/40 ring-2 ring-purple-500/20 shadow-xs',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=faces',
    },
    {
      id: 'usr-2',
      name: 'Hồ Minh Châu',
      role: 'Ban Giám Đốc',
      scope: 'Xem Báo Cáo',
      badgeClass: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
      activeRing: 'border-indigo-500 bg-indigo-50/60 dark:bg-indigo-950/40 ring-2 ring-indigo-500/20 shadow-xs',
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&h=100&fit=crop&crop=faces',
    },
    {
      id: 'usr-3',
      name: 'Nguyễn Nhật Thanh',
      role: 'TP. Kỹ Thuật',
      scope: 'Module Kỹ Thuật',
      badgeClass: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
      activeRing: 'border-emerald-500 bg-emerald-50/60 dark:bg-emerald-950/40 ring-2 ring-emerald-500/20 shadow-xs',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=faces',
    },
    {
      id: 'usr-4',
      name: 'Hồ Hoàng Long',
      role: 'TP. Sale',
      scope: 'Module Sales',
      badgeClass: 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 border-amber-200 dark:border-amber-800',
      activeRing: 'border-amber-500 bg-amber-50/60 dark:bg-amber-950/40 ring-2 ring-amber-500/20 shadow-xs',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=faces',
    },
    {
      id: 'usr-5',
      name: 'Nguyễn Văn A',
      role: 'NV. Sales',
      scope: 'Lead & Deal Phân Bổ',
      badgeClass: 'bg-cyan-100 text-cyan-800 dark:bg-cyan-950 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800',
      activeRing: 'border-cyan-500 bg-cyan-50/60 dark:bg-cyan-950/40 ring-2 ring-cyan-500/20 shadow-xs',
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=100&h=100&fit=crop&crop=faces',
    },
  ];

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2.5 pb-2 border-b border-slate-100 dark:border-slate-800">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
            Chế độ kiểm thử phân quyền 5 vị trí:
          </span>
          <span className="text-[11px] px-2 py-0.5 rounded font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
            Hiện tại: {currentUser.fullName} ({currentUser.role})
          </span>
        </div>
        <span className="text-[11px] text-slate-400">
          Nhấp chuột 1 chạm để đổi giao diện Dashboard &amp; phân quyền thực tế
        </span>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
        {demoRoles.map((item) => {
          const isActive = currentUser.fullName.includes(item.name) || currentUser.id === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => switchDemoUser(item.id)}
              className={`text-left p-2 rounded-lg border transition-all cursor-pointer flex items-center gap-2.5 ${
                isActive
                  ? item.activeRing
                  : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50/50 dark:bg-slate-800/40'
              }`}
            >
              <img
                src={item.avatar}
                alt={item.name}
                className="w-8 h-8 rounded-full object-cover shrink-0 border border-slate-200 dark:border-slate-700"
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1">
                  <span className="text-xs font-bold text-slate-800 dark:text-white truncate">
                    {item.name}
                  </span>
                  {isActive && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                </div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate">
                  {item.role}
                </div>
                <span className={`inline-block text-[9px] px-1 rounded font-medium border mt-0.5 truncate ${item.badgeClass}`}>
                  {item.scope}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export const DashboardView: React.FC = () => {
  const {
    leads,
    contacts,
    opportunities,
    currentUser,
    currentRole,
    switchDemoUser,
    setActiveModule,
    showToast,
  } = useCRM();

  // Date range filter & Custom comparison state
  type DateRangePreset = 'today' | '7days' | 'month' | 'quarter' | 'custom';
  const [dateRange, setDateRange] = useState<DateRangePreset>('month');

  // Active dates used across the dashboard
  const [startDate, setStartDate] = useState<string>('2026-10-01');
  const [endDate, setEndDate] = useState<string>('2026-10-06');
  const [compareStartDate, setCompareStartDate] = useState<string>('2026-09-01');
  const [compareEndDate, setCompareEndDate] = useState<string>('2026-09-06');
  const [enableCompare, setEnableCompare] = useState<boolean>(true);

  // Popover state
  const [isDatePickerOpen, setIsDatePickerOpen] = useState<boolean>(false);
  const [tempStartDate, setTempStartDate] = useState<string>('2026-10-01');
  const [tempEndDate, setTempEndDate] = useState<string>('2026-10-06');
  const [tempCompareStartDate, setTempCompareStartDate] = useState<string>('2026-09-01');
  const [tempCompareEndDate, setTempCompareEndDate] = useState<string>('2026-09-06');

  // Format date display
  const formatDateDisplay = (dateStr: string) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return dateStr;
  };

  const formatDateShort = (dateStr: string) => {
    if (!dateStr) return '';
    const parts = dateStr.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}`;
    return dateStr;
  };

  // Get dynamic comparison label based on active period
  const getComparisonLabel = () => {
    if (!enableCompare) return '';
    if (dateRange === 'today') return 'so với hôm qua';
    if (dateRange === '7days') return 'so với tuần trước';
    if (dateRange === 'month') return 'so với tháng trước';
    if (dateRange === 'quarter') return 'so với quý trước';
    if (dateRange === 'custom') {
      return `so với cùng kỳ (${formatDateShort(compareStartDate)} - ${formatDateShort(compareEndDate)})`;
    }
    return 'so với cùng kỳ';
  };

  const handleSelectPreset = (preset: DateRangePreset) => {
    setDateRange(preset);
    if (preset === 'today') {
      const today = '2026-10-06';
      const yesterday = '2026-10-05';
      setStartDate(today);
      setEndDate(today);
      setCompareStartDate(yesterday);
      setCompareEndDate(yesterday);
      setTempStartDate(today);
      setTempEndDate(today);
      setTempCompareStartDate(yesterday);
      setTempCompareEndDate(yesterday);
    } else if (preset === '7days') {
      const start = '2026-09-30';
      const end = '2026-10-06';
      const compStart = '2026-09-23';
      const compEnd = '2026-09-29';
      setStartDate(start);
      setEndDate(end);
      setCompareStartDate(compStart);
      setCompareEndDate(compEnd);
      setTempStartDate(start);
      setTempEndDate(end);
      setTempCompareStartDate(compStart);
      setTempCompareEndDate(compEnd);
    } else if (preset === 'month') {
      const start = '2026-10-01';
      const end = '2026-10-06';
      const compStart = '2026-09-01';
      const compEnd = '2026-09-06';
      setStartDate(start);
      setEndDate(end);
      setCompareStartDate(compStart);
      setCompareEndDate(compEnd);
      setTempStartDate(start);
      setTempEndDate(end);
      setTempCompareStartDate(compStart);
      setTempCompareEndDate(compEnd);
    } else if (preset === 'quarter') {
      const start = '2026-10-01';
      const end = '2026-12-31';
      const compStart = '2026-07-01';
      const compEnd = '2026-09-30';
      setStartDate(start);
      setEndDate(end);
      setCompareStartDate(compStart);
      setCompareEndDate(compEnd);
      setTempStartDate(start);
      setTempEndDate(end);
      setTempCompareStartDate(compStart);
      setTempCompareEndDate(compEnd);
    }
    setIsDatePickerOpen(false);
  };

  const handleCalcPreviousPeriod = () => {
    const start = new Date(tempStartDate);
    const end = new Date(tempEndDate);
    if (isNaN(start.getTime()) || isNaN(end.getTime())) return;
    const diffTime = Math.abs(end.getTime() - start.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;

    const newEnd = new Date(start);
    newEnd.setDate(newEnd.getDate() - 1);
    const newStart = new Date(newEnd);
    newStart.setDate(newStart.getDate() - diffDays + 1);

    const pad = (n: number) => n.toString().padStart(2, '0');
    setTempCompareStartDate(`${newStart.getFullYear()}-${pad(newStart.getMonth() + 1)}-${pad(newStart.getDate())}`);
    setTempCompareEndDate(`${newEnd.getFullYear()}-${pad(newEnd.getMonth() + 1)}-${pad(newEnd.getDate())}`);
  };

  const handleCalcLastMonth = () => {
    const start = new Date(tempStartDate);
    const end = new Date(tempEndDate);
    if (isNaN(start.getTime()) || isNaN(end.getTime())) return;
    const newStart = new Date(start);
    newStart.setMonth(newStart.getMonth() - 1);
    const newEnd = new Date(end);
    newEnd.setMonth(newEnd.getMonth() - 1);

    const pad = (n: number) => n.toString().padStart(2, '0');
    setTempCompareStartDate(`${newStart.getFullYear()}-${pad(newStart.getMonth() + 1)}-${pad(newStart.getDate())}`);
    setTempCompareEndDate(`${newEnd.getFullYear()}-${pad(newEnd.getMonth() + 1)}-${pad(newEnd.getDate())}`);
  };

  const handleApplyCustomDates = () => {
    setStartDate(tempStartDate);
    setEndDate(tempEndDate);
    setCompareStartDate(tempCompareStartDate);
    setCompareEndDate(tempCompareEndDate);
    setDateRange('custom');
    setIsDatePickerOpen(false);
    showToast('Thời gian phân tích', `Đã áp dụng từ ${formatDateDisplay(tempStartDate)} đến ${formatDateDisplay(tempEndDate)}`);
  };

  // Dynamic KPI values & changes based on dateRange
  const getKpiData = () => {
    switch (dateRange) {
      case 'today':
        return {
          revenue: { val: '12.5M', change: '+5.4%', note: '(Doanh thu thực nhận trong ngày)' },
          customers: { val: '24', change: '+4.2%', note: '(3 khách hàng mới phát sinh hôm nay)' },
          deals: { val: '8', change: '+8.5%', note: '(2 deal quan trọng cần theo sát)' },
          conversion: { val: '22.5%', change: '+1.8%', note: '(Tỷ lệ chốt ổn định trong ngày)' },
        };
      case '7days':
        return {
          revenue: { val: '84.2M', change: '+9.6%', note: '(Doanh thu thực nhận tuần này)' },
          customers: { val: '186', change: '+6.8%', note: '(18 khách hàng mới phát sinh trong tuần)' },
          deals: { val: '45', change: '+11.0%', note: '(9 deal quan trọng đang chốt)' },
          conversion: { val: '23.8%', change: '+2.4%', note: '(Tăng trưởng chuyển đổi so với tuần trước)' },
        };
      case 'quarter':
        return {
          revenue: { val: '980.0M', change: '+16.5%', note: '(Doanh thu lũy kế quý)' },
          customers: { val: '3,410', change: '+11.2%', note: '(125 khách hàng mới phát sinh trong quý)' },
          deals: { val: '342', change: '+18.4%', note: '(54 deal lớn trong pipeline)' },
          conversion: { val: '26.2%', change: '+4.5%', note: '(Vượt kế hoạch chỉ tiêu quý)' },
        };
      case 'custom':
      case 'month':
      default:
        return {
          revenue: { val: '326.5M', change: '+12.8%', note: '(Doanh thu thực nhận qua tài khoản & tiền mặt)' },
          customers: { val: '1,284', change: '+8.4%', note: '(42 khách hàng mới phát sinh trong kỳ)' },
          deals: { val: '128', change: '+14.2%', note: '(18 deal quan trọng đang cần chốt)' },
          conversion: { val: '24.8%', change: '+3.2%', note: '(Vượt chỉ tiêu trung bình của kỳ)' },
        };
    }
  };

  const kpis = getKpiData();

  // Interactive toggle notes for AI Insight cards & KPI cards (mặc định mở gọn gàng 2 dòng, bấm ! để thu gọn/mở lại)
  const [openInsightNotes, setOpenInsightNotes] = useState<Record<string, boolean>>({});
  const [openKpiNotes, setOpenKpiNotes] = useState<Record<string, boolean>>({
    'kpi-revenue': true,
    'kpi-customers': true,
    'kpi-deals': true,
    'kpi-conversion': true,
  });

  const toggleInsightNote = (id: string) => {
    setOpenInsightNotes((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  const toggleKpiNote = (id: string) => {
    setOpenKpiNotes((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Custom Dashboard Widgets
  const [widgets, setWidgets] = useState<DashboardWidgetConfig[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback to default
    }
    return DEFAULT_WIDGETS;
  });

  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);
  const [tempWidgets, setTempWidgets] = useState<DashboardWidgetConfig[]>(widgets);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(widgets));
    } catch {
      // ignore
    }
  }, [widgets]);

  const handleOpenCustomize = () => {
    setTempWidgets([...widgets]);
    setIsCustomizeOpen(true);
  };

  const handleToggleWidget = (id: string) => {
    setTempWidgets((prev) =>
      prev.map((w) => (w.id === id ? { ...w, enabled: !w.enabled } : w))
    );
  };

  const handleMoveWidget = (index: number, direction: 'up' | 'down') => {
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex < 0 || targetIndex >= tempWidgets.length) return;
    const updated = [...tempWidgets];
    const [moved] = updated.splice(index, 1);
    updated.splice(targetIndex, 0, moved);
    setTempWidgets(updated);
  };

  const handleResetWidgets = () => {
    setTempWidgets(DEFAULT_WIDGETS);
  };

  const handleSaveWidgets = () => {
    setWidgets(tempWidgets);
    setIsCustomizeOpen(false);
    showToast('Tùy chỉnh dashboard', 'Đã lưu bố cục giao diện của bạn.');
  };

  // Interactive Task List
  const [tasks, setTasks] = useState([
    { id: 't-1', title: 'Gọi xác nhận nhu cầu triển khai ERP cho Dược Liệu Á Châu', time: '10:32', urgent: true, completed: false, owner: 'Thanh' },
    { id: 't-2', title: 'Gửi báo giá gói Cloud Server v2 cho VNPAY Solutions (120M)', time: '11:00', urgent: false, completed: false, owner: 'Thanh' },
    { id: 't-3', title: 'Họp chốt điều khoản thanh toán & bảo hành cùng Tập đoàn Masan', time: '14:30', urgent: true, completed: false, owner: 'Thanh' },
    { id: 't-4', title: 'Gửi lại bản thảo hợp đồng cung cấp thiết bị số', time: '16:00', urgent: false, completed: true, owner: 'Thanh' },
  ]);

  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [isAddingTask, setIsAddingTask] = useState(false);

  const toggleTask = (id: string) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, completed: !t.completed } : t))
    );
  };

  const handleCreateTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    setTasks([
      {
        id: `t-${Date.now()}`,
        title: newTaskTitle.trim(),
        time: 'Hôm nay',
        urgent: false,
        completed: false,
        owner: currentUser.fullName.split(' ').pop() || 'Tôi',
      },
      ...tasks,
    ]);
    setNewTaskTitle('');
    setIsAddingTask(false);
    showToast('Công việc', 'Đã thêm công việc mới vào danh sách hôm nay.');
  };

  // Financial calculations
  const totalPipelineAmount = opportunities
    .filter((o) => o.stage !== 'Thất bại (Lost)')
    .reduce((sum, o) => sum + (o.amount || 0), 0);

  const wonAmount = opportunities
    .filter((o) => o.stage === 'Thành công (Won)')
    .reduce((sum, o) => sum + (o.amount || 0), 0);

  const userName = currentUser?.fullName?.split(' ').pop() || 'Thanh';

  // Role-based Dashboard Views
  if (currentRole === 'Director' || currentUser.fullName === 'Hồ Minh Châu') {
    return (
      <div className="space-y-6 max-w-[1400px] mx-auto pb-12">
        <DirectorDashboard />
      </div>
    );
  }

  if (currentRole === 'Technical Manager' || currentUser.fullName === 'Nguyễn Nhật Thanh') {
    return (
      <div className="space-y-6 max-w-[1400px] mx-auto pb-12">
        <TechnicalManagerDashboard />
      </div>
    );
  }

  if (currentRole === 'Sales Manager' || currentUser.fullName === 'Hồ Hoàng Long') {
    return (
      <div className="space-y-6 max-w-[1400px] mx-auto pb-12">
        <SalesManagerDashboard />
      </div>
    );
  }

  if (currentRole === 'Sales Staff' || currentUser.fullName === 'Nguyễn Văn A') {
    return (
      <div className="space-y-6 max-w-[1400px] mx-auto pb-12">
        <SalesStaffDashboard />
      </div>
    );
  }

  return (
    <div className="space-y-6 max-w-[1400px] mx-auto pb-12">
      {/* 01. DASHBOARD HEADER */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200/90 dark:border-slate-800 pb-5">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-[26px] sm:text-[28px] font-bold text-[#172033] dark:text-white tracking-tight">
              Tổng quan
            </h1>
            <span className="inline-flex items-center px-2 py-0.5 rounded-md text-[12px] font-semibold bg-sky-50 dark:bg-sky-950/60 text-sky-800 dark:text-sky-300 border border-sky-200 dark:border-sky-800">
              Doanh nghiệp
            </span>
          </div>
          <p className="text-[14px] text-slate-500 dark:text-slate-400 mt-1">
            Chào anh {userName}, đây là tình hình hoạt động của doanh nghiệp hôm nay.
          </p>
        </div>

        <div className="flex items-center gap-2.5 shrink-0 flex-wrap relative">
          {/* Time Range & Comparison Filter Trigger Button */}
          <div className="relative">
            <button
              type="button"
              onClick={() => {
                setTempStartDate(startDate);
                setTempEndDate(endDate);
                setTempCompareStartDate(compareStartDate);
                setTempCompareEndDate(compareEndDate);
                setIsDatePickerOpen(!isDatePickerOpen);
              }}
              className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-[13.5px] font-medium text-slate-800 dark:text-slate-200 hover:border-sky-500 focus:outline-hidden focus:border-sky-600 transition-colors cursor-pointer shadow-2xs flex items-center gap-2"
              title="Chọn khoảng thời gian xem dữ liệu & kỳ so sánh"
            >
              <Calendar className="w-4 h-4 text-sky-600 dark:text-sky-400 shrink-0" />
              <span>
                {dateRange === 'today' && 'Hôm nay (vs hôm qua)'}
                {dateRange === '7days' && '7 ngày qua (vs tuần trước)'}
                {dateRange === 'month' && 'Tháng này (vs tháng trước)'}
                {dateRange === 'quarter' && 'Quý này (vs quý trước)'}
                {dateRange === 'custom' && `Từ ${formatDateShort(startDate)} đến ${formatDateShort(endDate)}`}
              </span>
              <ChevronDown className={`w-3.5 h-3.5 text-slate-400 transition-transform ${isDatePickerOpen ? 'rotate-180' : ''}`} />
            </button>

            {/* Date Range & Comparison Popover Dropdown */}
            {isDatePickerOpen && (
              <div className="absolute right-0 mt-2 w-[340px] sm:w-[440px] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl p-4.5 z-50 animate-in fade-in zoom-in-95 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                    <span className="font-bold text-[14px] text-slate-900 dark:text-white">
                      Bộ lọc Thời gian & Kỳ so sánh
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsDatePickerOpen(false)}
                    className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                {/* Quick Presets */}
                <div>
                  <span className="text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-2">
                    Chọn nhanh chu kỳ:
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    {[
                      { id: 'today', label: 'Hôm nay', sub: 'so với hôm qua' },
                      { id: '7days', label: '7 ngày qua', sub: 'so với tuần trước' },
                      { id: 'month', label: 'Tháng này', sub: 'so với tháng trước' },
                      { id: 'quarter', label: 'Quý này', sub: 'so với quý trước' },
                    ].map((p) => (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => handleSelectPreset(p.id as DateRangePreset)}
                        className={`px-2.5 py-2 rounded-lg text-left border transition-all cursor-pointer ${
                          dateRange === p.id
                            ? 'border-sky-500 bg-sky-50/80 dark:bg-sky-950/60 text-sky-900 dark:text-sky-200 shadow-2xs font-semibold'
                            : 'border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300'
                        }`}
                      >
                        <div className="text-[13px] font-medium leading-tight">{p.label}</div>
                        <div className="text-[11px] text-slate-400 dark:text-slate-500 mt-0.5">{p.sub}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Section 1: Khoảng thời gian Từ... Đến... */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <span className="text-[12px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-sky-500"></span>
                    Khoảng thời gian xem dữ liệu:
                  </span>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11.5px] text-slate-500 mb-1">Từ ngày</label>
                      <input
                        type="date"
                        value={tempStartDate}
                        onChange={(e) => setTempStartDate(e.target.value)}
                        className="w-full text-[13px] px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-sky-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[11.5px] text-slate-500 mb-1">Đến ngày</label>
                      <input
                        type="date"
                        value={tempEndDate}
                        onChange={(e) => setTempEndDate(e.target.value)}
                        className="w-full text-[13px] px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-sky-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Section 2: So sánh từ.. ngày.. tháng.. Đến ngày.. tháng.. */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[12px] font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                      So sánh với cùng kỳ:
                    </span>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={handleCalcPreviousPeriod}
                        className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-sky-100 text-slate-600 dark:text-slate-300 hover:text-sky-600 cursor-pointer transition-colors"
                        title="Tự động lùi về kỳ liền trước cùng số ngày"
                      >
                        Kỳ liền trước
                      </button>
                      <button
                        type="button"
                        onClick={handleCalcLastMonth}
                        className="text-[11px] px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 hover:bg-sky-100 text-slate-600 dark:text-slate-300 hover:text-sky-600 cursor-pointer transition-colors"
                        title="So sánh với tháng trước"
                      >
                        Tháng trước
                      </button>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11.5px] text-slate-500 mb-1">So sánh từ ngày</label>
                      <input
                        type="date"
                        value={tempCompareStartDate}
                        onChange={(e) => setTempCompareStartDate(e.target.value)}
                        className="w-full text-[13px] px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-[11.5px] text-slate-500 mb-1">Đến ngày</label>
                      <input
                        type="date"
                        value={tempCompareEndDate}
                        onChange={(e) => setTempCompareEndDate(e.target.value)}
                        className="w-full text-[13px] px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:outline-hidden focus:border-emerald-500"
                      />
                    </div>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setIsDatePickerOpen(false)}
                    className="px-3 py-1.5 text-[13px] font-medium text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg cursor-pointer transition-colors"
                  >
                    Đóng
                  </button>
                  <button
                    type="button"
                    onClick={handleApplyCustomDates}
                    className="px-4 py-1.5 text-[13px] font-semibold text-white bg-[#002659] hover:bg-[#001f4a] rounded-lg shadow-xs cursor-pointer transition-colors"
                  >
                    Áp dụng bộ lọc
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick Create Deal */}
          <button
            onClick={() => setActiveModule('opportunities')}
            className="h-9 px-3.5 rounded-lg bg-[#002659] hover:bg-[#001f4a] text-white text-[13.5px] font-medium transition-colors shadow-xs flex items-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Tạo cơ hội</span>
          </button>

          {/* Customize Dashboard Modal Trigger */}
          <button
            onClick={handleOpenCustomize}
            className="h-9 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-[13.5px] font-medium text-slate-700 dark:text-slate-300 transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
            title="Tùy chỉnh giao diện dashboard"
          >
            <Settings2 className="w-4 h-4 text-slate-400" />
            <span className="hidden sm:inline">Tùy chỉnh dashboard</span>
          </button>
        </div>
      </div>

      {/* RENDER WIDGETS DYNAMICALLY ACCORDING TO USER CONFIG */}
      {widgets.filter((w) => w.enabled).map((widget) => {
        // --- 1. KPI CARDS (Đơn giản, nổi bật tiêu đề & số lớn, điểm nhấn màu góc card, bóng nổi nhẹ) ---
        if (widget.id === 'kpi_cards') {
          return (
            <div key={widget.id} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {/* KPI 1: Doanh thu */}
              <div className="relative overflow-hidden bg-gradient-to-br from-sky-50/70 via-white to-white dark:from-sky-950/25 dark:via-slate-900 dark:to-slate-900 border border-sky-100/90 dark:border-sky-900/40 rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.1)] hover:-translate-y-0.5 transition-all duration-200 hover:border-sky-300 dark:hover:border-sky-700 flex flex-col justify-between">
                {/* Vệt màu ở góc trên bên phải */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-sky-500/20 via-sky-500/5 to-transparent rounded-bl-full pointer-events-none opacity-90" />
                <div className="absolute top-0 right-0 w-12 h-1 rounded-bl-sm bg-sky-500 pointer-events-none" />

                <div className="relative z-10">
                  <div className="flex items-center justify-between">
                    <span className="text-[15px] font-bold text-slate-800 dark:text-slate-100 tracking-tight">
                      Doanh thu
                    </span>
                    <div className="w-8.5 h-8.5 rounded-lg bg-sky-100/80 dark:bg-sky-900/50 text-sky-600 dark:text-sky-400 flex items-center justify-center shrink-0 shadow-2xs">
                      <DollarSign className="w-4.5 h-4.5" />
                    </div>
                  </div>
                  <div className="text-[34px] sm:text-[36px] font-black text-slate-900 dark:text-white tracking-tight mt-2.5 font-mono tabular-nums leading-none">
                    {kpis.revenue.val}
                  </div>
                </div>

                {/* So sánh cùng kỳ trực tiếp, tinh gọn */}
                <div className="relative z-10 mt-3.5 flex items-center gap-1.5 flex-wrap">
                  <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md font-bold text-[11.5px] bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/70 dark:border-emerald-800 shrink-0 whitespace-nowrap">
                    <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                    {kpis.revenue.change}
                  </span>
                  <span className="text-[12px] font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap">
                    {getComparisonLabel()}
                  </span>
                </div>
              </div>

              {/* KPI 2: Khách hàng */}
              <div className="relative overflow-hidden bg-gradient-to-br from-indigo-50/70 via-white to-white dark:from-indigo-950/25 dark:via-slate-900 dark:to-slate-900 border border-indigo-100/90 dark:border-indigo-900/40 rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.1)] hover:-translate-y-0.5 transition-all duration-200 hover:border-indigo-300 dark:hover:border-indigo-700 flex flex-col justify-between">
                {/* Vệt màu ở góc trên bên phải */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-indigo-500/20 via-indigo-500/5 to-transparent rounded-bl-full pointer-events-none opacity-90" />
                <div className="absolute top-0 right-0 w-12 h-1 rounded-bl-sm bg-indigo-500 pointer-events-none" />

                <div className="relative z-10">
                  <div className="flex items-center justify-between">
                    <span className="text-[15px] font-bold text-slate-800 dark:text-slate-100 tracking-tight">
                      Khách hàng
                    </span>
                    <div className="w-8.5 h-8.5 rounded-lg bg-indigo-100/80 dark:bg-indigo-900/50 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shrink-0 shadow-2xs">
                      <Users className="w-4.5 h-4.5" />
                    </div>
                  </div>
                  <div className="text-[34px] sm:text-[36px] font-black text-slate-900 dark:text-white tracking-tight mt-2.5 font-mono tabular-nums leading-none">
                    {kpis.customers.val}
                  </div>
                </div>

                <div className="relative z-10 mt-3.5 flex items-center gap-1.5 flex-wrap">
                  <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md font-bold text-[11.5px] bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/70 dark:border-emerald-800 shrink-0 whitespace-nowrap">
                    <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                    {kpis.customers.change}
                  </span>
                  <span className="text-[12px] font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap">
                    {getComparisonLabel()}
                  </span>
                </div>
              </div>

              {/* KPI 3: Cơ hội bán hàng */}
              <div className="relative overflow-hidden bg-gradient-to-br from-amber-50/70 via-white to-white dark:from-amber-950/25 dark:via-slate-900 dark:to-slate-900 border border-amber-100/90 dark:border-amber-900/40 rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.1)] hover:-translate-y-0.5 transition-all duration-200 hover:border-amber-300 dark:hover:border-amber-700 flex flex-col justify-between">
                {/* Vệt màu ở góc trên bên phải */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-amber-500/20 via-amber-500/5 to-transparent rounded-bl-full pointer-events-none opacity-90" />
                <div className="absolute top-0 right-0 w-12 h-1 rounded-bl-sm bg-amber-500 pointer-events-none" />

                <div className="relative z-10">
                  <div className="flex items-center justify-between">
                    <span className="text-[15px] font-bold text-slate-800 dark:text-slate-100 tracking-tight">
                      Cơ hội bán hàng
                    </span>
                    <div className="w-8.5 h-8.5 rounded-lg bg-amber-100/80 dark:bg-amber-900/50 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0 shadow-2xs">
                      <Target className="w-4.5 h-4.5" />
                    </div>
                  </div>
                  <div className="text-[34px] sm:text-[36px] font-black text-slate-900 dark:text-white tracking-tight mt-2.5 font-mono tabular-nums leading-none">
                    {kpis.deals.val}
                  </div>
                </div>

                <div className="relative z-10 mt-3.5 flex items-center gap-1.5 flex-wrap">
                  <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md font-bold text-[11.5px] bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/70 dark:border-emerald-800 shrink-0 whitespace-nowrap">
                    <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                    {kpis.deals.change}
                  </span>
                  <span className="text-[12px] font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap">
                    {getComparisonLabel()}
                  </span>
                </div>
              </div>

              {/* KPI 4: Tỷ lệ chuyển đổi */}
              <div className="relative overflow-hidden bg-gradient-to-br from-emerald-50/70 via-white to-white dark:from-emerald-950/25 dark:via-slate-900 dark:to-slate-900 border border-emerald-100/90 dark:border-emerald-900/40 rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.1)] hover:-translate-y-0.5 transition-all duration-200 hover:border-emerald-300 dark:hover:border-emerald-700 flex flex-col justify-between">
                {/* Vệt màu ở góc trên bên phải */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-emerald-500/20 via-emerald-500/5 to-transparent rounded-bl-full pointer-events-none opacity-90" />
                <div className="absolute top-0 right-0 w-12 h-1 rounded-bl-sm bg-emerald-500 pointer-events-none" />

                <div className="relative z-10">
                  <div className="flex items-center justify-between">
                    <span className="text-[15px] font-bold text-slate-800 dark:text-slate-100 tracking-tight">
                      Tỷ lệ chuyển đổi
                    </span>
                    <div className="w-8.5 h-8.5 rounded-lg bg-emerald-100/80 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 shadow-2xs">
                      <TrendingUp className="w-4.5 h-4.5" />
                    </div>
                  </div>
                  <div className="text-[34px] sm:text-[36px] font-black text-slate-900 dark:text-white tracking-tight mt-2.5 font-mono tabular-nums leading-none">
                    {kpis.conversion.val}
                  </div>
                </div>

                <div className="relative z-10 mt-3.5 flex items-center gap-1.5 flex-wrap">
                  <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md font-bold text-[11.5px] bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200/70 dark:border-emerald-800 shrink-0 whitespace-nowrap">
                    <TrendingUp className="w-3.5 h-3.5 shrink-0" />
                    {kpis.conversion.change}
                  </span>
                  <span className="text-[12px] font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap">
                    {getComparisonLabel()}
                  </span>
                </div>
              </div>
            </div>
          );
        }

        // --- 2. AI INSIGHT & CẢNH BÁO ---
        // (Header không có '!', còn 3 thẻ cơ hội con có nút '!' góc phải trên, bấm vào hiện ra chú thích)
        if (widget.id === 'ai_insight') {
          return (
            <div
              key={widget.id}
              className="bg-gradient-to-br from-sky-50/50 via-indigo-50/30 to-slate-50/40 dark:from-slate-900 dark:via-sky-950/20 dark:to-slate-900 border border-sky-100/90 dark:border-sky-900/40 rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] transition-all space-y-3"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-sky-100/80 dark:border-slate-800 pb-3">
                <h2 className="section-title">
                  <Sparkles className="w-4.5 h-4.5 mr-2 text-[#0284c7] dark:text-sky-400 inline shrink-0" />
                  AI Insight & Khuyến nghị điều hành
                </h2>

                <button
                  onClick={() => setActiveModule('opportunities')}
                  className="px-3 py-1.5 rounded-lg text-[13px] font-semibold text-sky-700 dark:text-sky-300 bg-white dark:bg-slate-800 hover:bg-sky-50 dark:hover:bg-slate-750 border border-sky-200/80 dark:border-sky-800/80 transition-colors self-start sm:self-auto cursor-pointer shadow-2xs"
                >
                  Xem phân tích chi tiết →
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 pt-1">
                {/* AI Card 1: Emerald highlight (3 cơ hội có khả năng chốt cao) */}
                <div className="p-3.5 rounded-lg bg-white/90 dark:bg-slate-900/90 border border-emerald-100 dark:border-emerald-900/40 hover:bg-emerald-50/30 dark:hover:bg-emerald-950/20 transition-all shadow-2xs space-y-1.5">
                  <div className="flex items-center justify-between gap-1.5">
                    <div className="text-[13.5px] font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 min-w-0">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                      <span className="truncate">3 cơ hội có khả năng chốt cao</span>
                    </div>
                    {/* Nút ! ở góc phải trên */}
                    <button
                      type="button"
                      onClick={() => toggleInsightNote('insight-1')}
                      className={`w-4.5 h-4.5 rounded-full flex items-center justify-center text-[10.5px] font-bold transition-all shadow-2xs shrink-0 cursor-pointer ${
                        openInsightNotes['insight-1']
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 hover:bg-emerald-100 dark:bg-slate-800 dark:hover:bg-emerald-950 text-slate-500 hover:text-emerald-700 dark:text-slate-400'
                      }`}
                      title="Bấm để xem chú thích: Dự kiến hoàn tất trong 7 ngày tới với giá trị ước tính 280.000.000đ."
                    >
                      !
                    </button>
                  </div>
                  {/* Dòng chú thích bên dưới hiện ra khi bấm vào ! */}
                  {openInsightNotes['insight-1'] && (
                    <p className="text-[12.5px] text-slate-600 dark:text-slate-400 leading-relaxed pl-4 pt-1 border-t border-emerald-100/80 dark:border-emerald-900/40 animate-in fade-in duration-150">
                      Dự kiến hoàn tất trong 7 ngày tới với giá trị ước tính 280.000.000đ.
                    </p>
                  )}
                </div>

                {/* AI Card 2: Amber highlight (8 khách hàng chưa được follow-up) */}
                <div className="p-3.5 rounded-lg bg-white/90 dark:bg-slate-900/90 border border-amber-100 dark:border-amber-900/40 hover:bg-amber-50/30 dark:hover:bg-amber-950/20 transition-all shadow-2xs space-y-1.5">
                  <div className="flex items-center justify-between gap-1.5">
                    <div className="text-[13.5px] font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 min-w-0">
                      <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                      <span className="truncate">8 khách hàng chưa được follow-up</span>
                    </div>
                    {/* Nút ! ở góc phải trên */}
                    <button
                      type="button"
                      onClick={() => toggleInsightNote('insight-2')}
                      className={`w-4.5 h-4.5 rounded-full flex items-center justify-center text-[10.5px] font-bold transition-all shadow-2xs shrink-0 cursor-pointer ${
                        openInsightNotes['insight-2']
                          ? 'bg-amber-600 text-white'
                          : 'bg-slate-100 hover:bg-amber-100 dark:bg-slate-800 dark:hover:bg-amber-950 text-slate-500 hover:text-amber-700 dark:text-slate-400'
                      }`}
                      title="Bấm để xem chú thích: Chưa có liên hệ > 5 ngày. Cần nhắc nhân viên phụ trách gọi lại ngay."
                    >
                      !
                    </button>
                  </div>
                  {/* Dòng chú thích bên dưới hiện ra khi bấm vào ! */}
                  {openInsightNotes['insight-2'] && (
                    <p className="text-[12.5px] text-slate-600 dark:text-slate-400 leading-relaxed pl-4 pt-1 border-t border-amber-100/80 dark:border-amber-900/40 animate-in fade-in duration-150">
                      Chưa có liên hệ &gt; 5 ngày. Cần nhắc nhân viên phụ trách gọi lại ngay.
                    </p>
                  )}
                </div>

                {/* AI Card 3: Sky highlight (Doanh thu hiện thấp hơn mục tiêu 12%) */}
                <div className="p-3.5 rounded-lg bg-white/90 dark:bg-slate-900/90 border border-sky-100 dark:border-sky-900/40 hover:bg-sky-50/30 dark:hover:bg-sky-950/20 transition-all shadow-2xs space-y-1.5">
                  <div className="flex items-center justify-between gap-1.5">
                    <div className="text-[13.5px] font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2 min-w-0">
                      <span className="w-2 h-2 rounded-full bg-sky-500 shrink-0" />
                      <span className="truncate">Doanh thu hiện thấp hơn mục tiêu 12%</span>
                    </div>
                    {/* Nút ! ở góc phải trên */}
                    <button
                      type="button"
                      onClick={() => toggleInsightNote('insight-3')}
                      className={`w-4.5 h-4.5 rounded-full flex items-center justify-center text-[10.5px] font-bold transition-all shadow-2xs shrink-0 cursor-pointer ${
                        openInsightNotes['insight-3']
                          ? 'bg-sky-600 text-white'
                          : 'bg-slate-100 hover:bg-sky-100 dark:bg-slate-800 dark:hover:bg-sky-950 text-slate-500 hover:text-sky-700 dark:text-slate-400'
                      }`}
                      title="Bấm để xem chú thích: Khuyến nghị đẩy mạnh chốt các báo giá kỹ thuật đang trong giai đoạn đàm phán."
                    >
                      !
                    </button>
                  </div>
                  {/* Dòng chú thích bên dưới hiện ra khi bấm vào ! */}
                  {openInsightNotes['insight-3'] && (
                    <p className="text-[12.5px] text-slate-600 dark:text-slate-400 leading-relaxed pl-4 pt-1 border-t border-sky-100/80 dark:border-sky-900/40 animate-in fade-in duration-150">
                      Khuyến nghị đẩy mạnh chốt các báo giá kỹ thuật đang trong giai đoạn đàm phán.
                    </p>
                  )}
                </div>
              </div>
            </div>
          );
        }

        // --- 3. REVENUE & PIPELINE WITH TASKS TODAY (No '!' on titles) ---
        if (widget.id === 'revenue_pipeline') {
          return (
            <div key={widget.id} className="grid grid-cols-1 lg:grid-cols-3 gap-5 sm:gap-6">
              {/* Sales Pipeline & Revenue Funnel (2 Cols) */}
              <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] transition-all space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <h2 className="section-title">
                    Phễu cơ hội & Tiến độ kinh doanh
                  </h2>
                  <button
                    onClick={() => setActiveModule('opportunities')}
                    className="text-[13px] font-semibold text-[#002659] dark:text-sky-400 hover:underline cursor-pointer"
                  >
                    Mở Pipeline →
                  </button>
                </div>

                {/* Minimalist Visual Pipeline Bars with Modern Gradients */}
                <div className="space-y-3.5 pt-1">
                  {[
                    { stage: 'Mới liên hệ', count: 32, value: '180M', width: '90%', barGradient: 'bg-gradient-to-r from-sky-400 to-blue-600' },
                    { stage: 'Tư vấn giải pháp', count: 24, value: '310M', width: '72%', barGradient: 'bg-gradient-to-r from-blue-500 to-indigo-600' },
                    { stage: 'Gửi báo giá', count: 18, value: '260M', width: '55%', barGradient: 'bg-gradient-to-r from-indigo-500 to-violet-600' },
                    { stage: 'Đàm phán hợp đồng', count: 11, value: '190M', width: '38%', barGradient: 'bg-gradient-to-r from-amber-400 to-orange-500' },
                    { stage: 'Thành công (Won)', count: 9, value: '145M', width: '25%', barGradient: 'bg-gradient-to-r from-emerald-400 to-teal-600' },
                  ].map((row) => (
                    <div key={row.stage} className="space-y-1.5">
                      <div className="flex items-center justify-between text-[13.5px]">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-slate-800 dark:text-slate-200">{row.stage}</span>
                          <span className="text-[12px] text-slate-400 dark:text-slate-500">({row.count} cơ hội)</span>
                        </div>
                        <span className="font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                          {row.value}
                        </span>
                      </div>
                      <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className={`h-full ${row.barGradient} rounded-full transition-all duration-300 shadow-2xs`}
                          style={{ width: row.width }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Tasks for Today (1 Col) */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] transition-all flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                    <div className="flex items-center gap-2">
                      <h2 className="section-title">
                        Công việc hôm nay
                      </h2>
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {tasks.filter((t) => !t.completed).length} việc
                      </span>
                    </div>

                    <button
                      onClick={() => setIsAddingTask(!isAddingTask)}
                      className="p-1 rounded-lg text-[#002659] dark:text-sky-400 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors"
                      title="Thêm công việc"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>

                  {isAddingTask && (
                    <form onSubmit={handleCreateTask} className="flex gap-2">
                      <input
                        type="text"
                        value={newTaskTitle}
                        onChange={(e) => setNewTaskTitle(e.target.value)}
                        placeholder="Nội dung công việc mới..."
                        className="flex-1 h-8.5 px-3 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-[13px] text-slate-800 dark:text-slate-200 focus:outline-hidden focus:border-sky-500"
                        autoFocus
                      />
                      <button
                        type="submit"
                        className="px-3 h-8.5 bg-[#002659] hover:bg-[#001f4a] text-white text-[12.5px] font-semibold rounded-lg cursor-pointer transition-colors shadow-2xs"
                      >
                        Lưu
                      </button>
                    </form>
                  )}

                  <div className="space-y-2 pt-1">
                    {tasks.map((task, idx) => (
                      <div
                        key={task.id}
                        onClick={() => toggleTask(task.id)}
                        className={`p-2.5 rounded-lg border transition-all cursor-pointer flex items-start gap-2.5 ${
                          idx % 2 === 0
                            ? 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800'
                            : 'bg-slate-50/60 dark:bg-slate-800/40 border-slate-200/60 dark:border-slate-800/60'
                        } hover:border-sky-300 dark:hover:border-sky-700 hover:bg-sky-50/40 dark:hover:bg-sky-950/20`}
                      >
                        <button
                          type="button"
                          className="mt-0.5 text-slate-400 hover:text-sky-600 shrink-0 cursor-pointer"
                        >
                          {task.completed ? (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Circle className="w-4 h-4 text-slate-300 dark:text-slate-600" />
                          )}
                        </button>
                        <div className="min-w-0 flex-1">
                          <p
                            className={`text-[13px] font-medium leading-snug ${
                              task.completed ? 'line-through text-slate-400 dark:text-slate-600' : 'text-slate-800 dark:text-slate-200'
                            }`}
                          >
                            {task.title}
                          </p>
                          <div className="flex items-center gap-2 mt-1">
                            <span className="text-[11.5px] text-slate-400 dark:text-slate-500 font-mono">{task.time}</span>
                            {task.urgent && !task.completed && (
                              <span className="px-1.5 py-0.2 rounded-md text-[11px] font-bold bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200/60 dark:border-amber-800">
                                Gấp
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 mt-2">
                  <button
                    onClick={() => setActiveModule('tasks')}
                    className="w-full py-1.5 text-center text-[12.5px] font-semibold text-[#002659] dark:text-sky-400 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                  >
                    Xem tất cả công việc →
                  </button>
                </div>
              </div>
            </div>
          );
        }

        // --- 4. TOP CUSTOMERS (No '!' on title) & ACTIVITY TIMELINE ---
        if (widget.id === 'top_customers') {
          return (
            <div key={widget.id} className="grid grid-cols-1 lg:grid-cols-3 gap-5 sm:gap-6">
              {/* Top Key Customers Table with Alternating White/Gray Rows (2 Cols) */}
              <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] transition-all space-y-3.5">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <h2 className="section-title">
                    Khách hàng trọng điểm cần chăm sóc
                  </h2>
                  <button
                    onClick={() => setActiveModule('customers')}
                    className="text-[13px] font-semibold text-[#002659] dark:text-sky-400 hover:underline cursor-pointer"
                  >
                    Tất cả khách hàng →
                  </button>
                </div>

                <div className="overflow-x-auto rounded-lg border border-slate-200/80 dark:border-slate-800">
                  <table className="w-full text-left border-collapse text-[13px]">
                    <thead>
                      <tr className="bg-slate-100/75 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 border-b border-slate-200 dark:border-slate-700">
                        <th className="py-2.5 px-4 font-semibold text-[12px] uppercase tracking-wider">Khách hàng</th>
                        <th className="py-2.5 px-4 font-semibold text-[12px] uppercase tracking-wider">Công ty</th>
                        <th className="py-2.5 px-4 font-semibold text-[12px] uppercase tracking-wider">Trạng thái</th>
                        <th className="py-2.5 px-4 font-semibold text-[12px] uppercase tracking-wider">Người phụ trách</th>
                        <th className="py-2.5 px-4 font-semibold text-[12px] uppercase tracking-wider text-right">Ngân sách</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[
                        { name: 'Nguyễn Văn An', company: 'Công ty Cổ phần Dược Liệu Á Châu', status: 'Tiềm năng', owner: 'Thanh', budget: '180M' },
                        { name: 'Trần Minh Tuấn', company: 'VNPAY Solutions', status: 'Đang đàm phán', owner: 'Long', budget: '350M' },
                        { name: 'Phạm Quỳnh Nga', company: 'FPT Software Hà Nội', status: 'Đã báo giá', owner: 'Thanh', budget: '420M' },
                        { name: 'Hoàng Quốc Việt', company: 'Tập đoàn Cơ khí Việt Nhật', status: 'Khách hàng VIP', owner: 'Đức', budget: '580M' },
                      ].map((c, index) => {
                        // Alternate row styling: White and Soft Gray
                        const isEven = index % 2 === 0;
                        const rowBg = isEven
                          ? 'bg-white dark:bg-slate-900'
                          : 'bg-slate-50/75 dark:bg-slate-800/40';

                        // Status badge styling
                        const getStatusBadge = (status: string) => {
                          switch (status) {
                            case 'Tiềm năng':
                              return 'bg-sky-50 dark:bg-sky-950/50 text-sky-700 dark:text-sky-300 border border-sky-200/70 dark:border-sky-800';
                            case 'Đang đàm phán':
                              return 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300 border border-indigo-200/70 dark:border-indigo-800';
                            case 'Đã báo giá':
                              return 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200/70 dark:border-amber-800';
                            case 'Khách hàng VIP':
                              return 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200/70 dark:border-emerald-800 font-semibold';
                            default:
                              return 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200';
                          }
                        };

                        return (
                          <tr
                            key={c.name}
                            className={`${rowBg} hover:bg-sky-50/60 dark:hover:bg-sky-950/30 transition-colors border-b border-slate-100 dark:border-slate-800/60 last:border-b-0`}
                          >
                            <td className="py-3 px-4 font-semibold text-slate-900 dark:text-white">
                              {c.name}
                            </td>
                            <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                              {c.company}
                            </td>
                            <td className="py-3 px-4">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[11.5px] font-medium ${getStatusBadge(c.status)}`}>
                                {c.status}
                              </span>
                            </td>
                            <td className="py-3 px-4 text-slate-600 dark:text-slate-300">
                              {c.owner}
                            </td>
                            <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 dark:text-white">
                              {c.budget}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Activity Timeline (No '!' on title) */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] transition-all space-y-3.5">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
                  <h2 className="section-title">
                    Nhật ký hoạt động
                  </h2>
                </div>

                <div className="space-y-4 pt-1 text-[13px]">
                  {/* Today Group */}
                  <div className="space-y-2.5">
                    <span className="text-[11.5px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                      Hôm nay
                    </span>
                    <div className="space-y-3 pl-3 border-l-2 border-slate-200 dark:border-slate-700">
                      <div className="space-y-0.5">
                        <span className="text-[11.5px] font-mono text-slate-400">10:32</span>
                        <p className="text-slate-800 dark:text-slate-200 leading-snug">
                          <strong className="text-slate-900 dark:text-white">Thanh</strong> đã gọi cho khách hàng Dược Liệu Á Châu.
                        </p>
                      </div>
                      <div className="space-y-0.5">
                        <span className="text-[11.5px] font-mono text-slate-400">09:15</span>
                        <p className="text-slate-800 dark:text-slate-200 leading-snug">
                          Đã gửi báo giá <strong className="text-slate-900 dark:text-white">120.000.000đ</strong> cho VNPAY Solutions.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Yesterday Group */}
                  <div className="space-y-2.5 pt-1">
                    <span className="text-[11.5px] font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider">
                      Hôm qua
                    </span>
                    <div className="space-y-3 pl-3 border-l-2 border-slate-200 dark:border-slate-700">
                      <div className="space-y-0.5">
                        <span className="text-[11.5px] font-mono text-slate-400">16:20</span>
                        <p className="text-slate-800 dark:text-slate-200 leading-snug">
                          Khách hàng FPT Software đã phản hồi xác nhận hợp đồng.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        }

        return null;
      })}

      {/* 05. CUSTOM DASHBOARD MODAL */}
      {isCustomizeOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95">
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="text-[17px] font-bold text-slate-900 dark:text-white">
                  ⚙ Tùy chỉnh Dashboard
                </h3>
                <p className="text-[12.5px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Bật/tắt và sắp xếp thứ tự hiển thị các khối nội dung trên bảng tổng quan.
                </p>
              </div>
              <button
                onClick={() => setIsCustomizeOpen(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body - Widget Library */}
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
              <div className="text-[13.5px] font-semibold text-slate-800 dark:text-slate-200">
                Thư viện Widget (Bấm để bật/tắt hoặc đổi vị trí)
              </div>

              <div className="space-y-2">
                {tempWidgets.map((w, index) => (
                  <div
                    key={w.id}
                    className={`flex items-center justify-between p-3.5 rounded-lg border transition-colors ${
                      w.enabled
                        ? 'border-sky-300 dark:border-sky-700 bg-sky-50/50 dark:bg-sky-950/30'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-850 opacity-75'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <button
                        type="button"
                        onClick={() => handleToggleWidget(w.id)}
                        className={`w-5 h-5 rounded-md flex items-center justify-center cursor-pointer transition-colors ${
                          w.enabled ? 'bg-[#002659] text-white' : 'border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800'
                        }`}
                      >
                        {w.enabled && <Check className="w-3.5 h-3.5" />}
                      </button>

                      <div className="min-w-0">
                        <div className="text-[13.5px] font-semibold text-slate-900 dark:text-white truncate">
                          {w.name}
                        </div>
                        <span className="text-[12px] text-slate-500 dark:text-slate-400">
                          Nhóm: {w.categoryLabel}
                        </span>
                      </div>
                    </div>

                    {/* Move controls */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleMoveWidget(index, 'up')}
                        disabled={index === 0}
                        className="p-1.5 rounded-md text-slate-500 hover:bg-white dark:hover:bg-slate-800 hover:text-[#002659] dark:hover:text-sky-400 disabled:opacity-30 cursor-pointer transition-colors"
                        title="Di chuyển lên"
                      >
                        <MoveUp className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleMoveWidget(index, 'down')}
                        disabled={index === tempWidgets.length - 1}
                        className="p-1.5 rounded-md text-slate-500 hover:bg-white dark:hover:bg-slate-800 hover:text-[#002659] dark:hover:text-sky-400 disabled:opacity-30 cursor-pointer transition-colors"
                        title="Di chuyển xuống"
                      >
                        <MoveDown className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3.5 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-850 flex items-center justify-between">
              <button
                type="button"
                onClick={handleResetWidgets}
                className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-[12.5px] font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white flex items-center gap-1.5 cursor-pointer shadow-2xs transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Đặt lại mặc định</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsCustomizeOpen(false)}
                  className="px-3.5 py-1.5 rounded-lg text-[13px] font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white cursor-pointer transition-colors"
                >
                  Hủy
                </button>
                <button
                  type="button"
                  onClick={handleSaveWidgets}
                  className="px-4 py-1.5 rounded-lg bg-[#002659] hover:bg-[#001f4a] text-white text-[13px] font-semibold transition-colors shadow-2xs cursor-pointer"
                >
                  Lưu cấu hình
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
