import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { Contract } from '../types/crm';
import {
  FileCheck2,
  Plus,
  FileCode,
  Calendar,
  CheckCircle2,
  Clock,
  AlertCircle,
  X,
  CreditCard,
  DollarSign,
} from 'lucide-react';

export const ContractsView: React.FC = () => {
  const {
    contracts,
    addContract,
    toggleMilestonePaid,
    deleteContract,
    hasPermission,
    language,
    themeDef,
    openScreenSpec,
    t,
  } = useCRM();

  const isVi = language === 'vi';
  const [selectedContract, setSelectedContract] = useState<Contract | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const [formData, setFormData] = useState({
    contractNumber: `HD-2026/10/VG-${Math.floor(100 + Math.random() * 900)}`,
    title: 'Hợp đồng Cung cấp Dịch vụ Điện toán Đám mây & Bảo mật CRM 2026',
    customerName: 'Trương Gia Bảo - Dược Liệu Á Châu',
    quotationCode: 'BG-2026-0089',
    totalValue: 825000000,
    startDate: '2026-10-01',
    endDate: '2027-09-30',
    status: 'Đang hiệu lực' as Contract['status'],
    manager: 'Trần Minh Đức',
    paymentMilestones: [
      {
        title: 'Đợt 1: Tạm ứng ngay sau khi ký hợp đồng (40%)',
        percentage: 40,
        amount: 330000000,
        dueDate: '2026-10-10',
        isPaid: true,
      },
      {
        title: 'Đợt 2: Nghiệm thu kỹ thuật triển khai (40%)',
        percentage: 40,
        amount: 330000000,
        dueDate: '2026-12-15',
        isPaid: false,
      },
      {
        title: 'Đợt 3: Bàn giao toàn diện & Nghiệm thu (20%)',
        percentage: 20,
        amount: 165000000,
        dueDate: '2027-02-28',
        isPaid: false,
      },
    ],
  });

  const canCreate = hasPermission('contracts', 'create');

  const formatVND = (num: number) => {
    return num.toLocaleString() + ' ₫';
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title.trim()) return;
    addContract(formData);
    setIsModalOpen(false);
  };

  const renderStatus = (status: Contract['status']) => {
    switch (status) {
      case 'Đang hiệu lực':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 shrink-0" />
            <span>Đang hiệu lực</span>
          </span>
        );
      case 'Sắp hết hạn':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-600 dark:text-amber-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500 dark:bg-amber-400 shrink-0 animate-ping" />
            <span>Sắp hết hạn</span>
          </span>
        );
      case 'Đang soạn thảo':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400 dark:bg-slate-500 shrink-0" />
            <span>Đang soạn thảo</span>
          </span>
        );
      case 'Chờ ký duyệt':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-600 dark:text-sky-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-600 dark:bg-sky-400 shrink-0" />
            <span>Chờ ký duyệt</span>
          </span>
        );
      case 'Đã hoàn tất':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-purple-600 dark:text-purple-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-purple-600 dark:bg-purple-400 shrink-0" />
            <span>Đã hoàn tất</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-600 dark:text-rose-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 dark:bg-rose-400 shrink-0" />
            <span>{status}</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
              {t.contracts}
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {contracts.length} active
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isVi
              ? 'Quản lý vòng đời hợp đồng thương mại, theo dõi giải ngân theo tiến độ từng đợt và cảnh báo đáo hạn.'
              : 'Commercial contract governance, milestone payment tracking, and automated renewal triggers.'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 flex-wrap">
          <button
            onClick={() => openScreenSpec('SCR-CONTRACT')}
            className="flex items-center gap-1 px-2 py-1 sm:px-2.5 sm:py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] sm:text-xs font-medium border border-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            <FileCode className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="hidden md:inline">{isVi ? 'Đặc tả Màn hình F' : 'Spec Screen F'}</span>
            <span className="md:hidden">Spec F</span>
          </button>

          {canCreate && (
            <button
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-1 px-2 py-1 sm:px-3.5 sm:py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white text-[11px] sm:text-xs font-medium transition-colors shadow-xs whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">{isVi ? 'Tạo Hợp đồng' : 'Draft Contract'}</span>
              <span className="sm:hidden">{isVi ? 'Hợp đồng' : 'New'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Contract Registry List */}
      <div className="grid grid-cols-1 gap-4">
        {contracts.map((cnt) => {
          const totalPaid = cnt.paymentMilestones
            .filter((m) => m.isPaid)
            .reduce((sum, m) => sum + m.amount, 0);
          const percentPaid = Math.round((totalPaid / cnt.totalValue) * 100);

          return (
            <div
              key={cnt.id}
              className="p-5 rounded-xl bg-white border border-[#E5E7EB] shadow-xs transition-colors hover:border-slate-300"
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400 px-2 py-0.5 rounded bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-900">
                      {cnt.contractNumber}
                    </span>
                    {renderStatus(cnt.status)}
                    {cnt.quotationCode && (
                      <span className="text-[11px] text-slate-400 font-mono">
                        Từ: {cnt.quotationCode}
                      </span>
                    )}
                  </div>
                  <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mt-2">
                    {cnt.title}
                  </h3>
                  <div className="text-xs text-slate-500 mt-1 flex flex-wrap items-center gap-x-3 gap-y-1">
                    <span>{cnt.customerName}</span>
                    <span className="hidden xs:inline">•</span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {cnt.startDate} ➔ {cnt.endDate}
                    </span>
                    <span className="hidden xs:inline">•</span>
                    <span>Quản lý: {cnt.manager}</span>
                  </div>
                </div>

                <div className="lg:text-right">
                  <div className="text-xs text-slate-400 uppercase font-semibold">Giá trị hợp đồng</div>
                  <div className="text-xl font-black font-mono text-slate-900 dark:text-slate-100 mt-0.5">
                    {formatVND(cnt.totalValue)}
                  </div>
                  <div className="text-xs text-emerald-600 font-semibold mt-1">
                    Đã thanh toán: {formatVND(totalPaid)} ({percentPaid}%)
                  </div>
                </div>
              </div>

              {/* Milestone Progress Bar */}
              <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800">
                <div className="flex items-center justify-between text-xs mb-2">
                  <span className="font-bold text-slate-700 dark:text-slate-300">
                    Tiến độ giải ngân từng đợt (Payment Milestones):
                  </span>
                  <span className="font-mono font-bold text-blue-600">{percentPaid}% Hoàn tất</span>
                </div>

                <div className="w-full h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden mb-4">
                  <div
                    className="h-full rounded-full bg-linear-to-r from-blue-600 to-emerald-500 transition-all duration-500"
                    style={{ width: `${percentPaid}%` }}
                  />
                </div>

                {/* Milestone breakdown items */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {cnt.paymentMilestones.map((m, idx) => (
                    <div
                      key={idx}
                      onClick={() => toggleMilestonePaid(cnt.id, idx)}
                      className={`p-3 rounded-xl border text-xs cursor-pointer transition-all ${
                        m.isPaid
                          ? 'bg-emerald-50/50 dark:bg-emerald-950/20 border-emerald-300 dark:border-emerald-800'
                          : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700 hover:border-blue-400'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[180px]">
                          {m.title}
                        </span>
                        {m.isPaid ? (
                          <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-600">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            Đã thu
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-[11px] text-amber-600">
                            <Clock className="w-3.5 h-3.5" />
                            Chưa thu
                          </span>
                        )}
                      </div>
                      <div className="mt-2 flex items-center justify-between font-mono">
                        <span className="font-bold text-slate-900 dark:text-slate-100">
                          {formatVND(m.amount)}
                        </span>
                        <span className="text-[11px] text-slate-400">Hạn: {m.dueDate}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal Add Contract */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-4 sm:p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Khởi tạo Hợp đồng Kinh tế Mới
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Số Hợp đồng *</label>
                <input
                  type="text"
                  required
                  value={formData.contractNumber}
                  onChange={(e) => setFormData({ ...formData, contractNumber: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono font-bold"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Nội dung Hợp đồng *</label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Đại diện Khách hàng</label>
                <input
                  type="text"
                  value={formData.customerName}
                  onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Giá trị hợp đồng (VNĐ)</label>
                  <input
                    type="number"
                    value={formData.totalValue}
                    onChange={(e) => setFormData({ ...formData, totalValue: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Trạng thái</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as Contract['status'] })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                  >
                    <option value="Đang hiệu lực">Đang hiệu lực</option>
                    <option value="Chờ ký duyệt">Chờ ký duyệt</option>
                    <option value="Đang soạn thảo">Đang soạn thảo</option>
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Ngày hiệu lực</label>
                  <input
                    type="date"
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Ngày kết thúc</label>
                  <input
                    type="date"
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-white font-bold ${themeDef.classes.primaryButton}`}
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
