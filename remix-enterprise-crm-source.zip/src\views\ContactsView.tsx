import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { Contact, Opportunity } from '../types/crm';
import {
  Search,
  Plus,
  Phone,
  Mail,
  Building,
  User,
  MapPin,
  Calendar,
  Clock,
  Briefcase,
  CheckSquare,
  FileText,
  ChevronRight,
  ArrowLeft,
  X,
  Edit2,
  Trash2,
  Send,
  MessageSquare,
  DollarSign,
  TrendingUp,
} from 'lucide-react';

interface ActivityItem {
  id: string;
  type: 'call' | 'email' | 'meeting' | 'deal' | 'note';
  title: string;
  description: string;
  timestamp: string;
  author: string;
}

export const ContactsView: React.FC = () => {
  const {
    contacts,
    addContact,
    updateContact,
    deleteContact,
    opportunities,
    hasPermission,
    language,
    setActiveModule,
    showToast,
  } = useCRM();

  const isVi = language === 'vi';
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);
  const [detailTab, setDetailTab] = useState<'overview' | 'activity' | 'deals' | 'tasks' | 'notes'>('overview');

  // Customer Edit/Create Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<Contact | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    fullName: '',
    company: '',
    title: 'Giám đốc Mua hàng',
    email: '',
    phone: '',
    type: 'Khách hàng VIP' as Contact['type'],
    address: 'Tầng 12, Keangnam Landmark, Cầu Giấy',
    city: 'Hà Nội',
    dealsCount: 1,
    totalSpent: 120000000,
    assignedTo: 'Trần Minh Đức',
  });

  // Mock interactive notes & activity
  const [notes, setNotes] = useState<Record<string, { id: string; text: string; date: string; author: string }[]>>({
    'contact-1': [
      { id: 'n1', text: 'Khách hàng cần triển khai gấp trong Q4, ngân sách đã phê duyệt 1.2B.', date: 'Hôm nay 10:15', author: 'Trần Minh Đức' },
      { id: 'n2', text: 'Đã gửi hồ sơ năng lực và danh sách các khách hàng tiêu biểu cùng ngành.', date: '28/09/2026', author: 'Lê Hoàng Yến' },
    ],
  });
  const [newNoteText, setNewNoteText] = useState('');

  const [activities, setActivities] = useState<Record<string, ActivityItem[]>>({
    'contact-1': [
      { id: 'act-1', type: 'call', title: 'Gọi điện tư vấn kỹ thuật', description: 'Đã trao đổi với anh An về việc tích hợp API với hệ thống ERP cũ.', timestamp: 'Hôm nay 09:30', author: 'Trần Minh Đức' },
      { id: 'act-2', type: 'email', title: 'Gửi báo giá chính thức BG-2026-003', description: 'Đã gửi email bảng giá thiết bị và chi phí bản quyền năm đầu.', timestamp: 'Hôm qua 15:20', author: 'Lê Hoàng Yến' },
      { id: 'act-3', type: 'deal', title: 'Tạo cơ hội: Cung cấp giải pháp CRM Enterprise', description: 'Giá trị deal ước tính 650.000.000 ₫, xác suất 70%.', timestamp: '28/09/2026', author: 'Trần Minh Đức' },
    ],
  });

  const canCreate = hasPermission('contacts', 'create');
  const canEdit = hasPermission('contacts', 'edit');
  const canDelete = hasPermission('contacts', 'delete');

  // Filtered contacts
  const filteredContacts = contacts.filter((c) => {
    const matchesSearch =
      c.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
      c.phone.includes(searchTerm) ||
      c.email.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = statusFilter === 'all' || c.type === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Format currency
  const formatVND = (num: number) => {
    if (num >= 1000000000) {
      return (num / 1000000000).toFixed(1) + ' Tỷ ₫';
    }
    if (num >= 1000000) {
      return (num / 1000000).toFixed(0) + ' Tr ₫';
    }
    return num.toLocaleString() + ' ₫';
  };

  // Status mapping as defined in Section 18
  const getStatusBadge = (type: Contact['type']) => {
    switch (type) {
      case 'Khách hàng VIP':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 shrink-0" />
            <span>Customer VIP</span>
          </span>
        );
      case 'Khách hàng thân thiết':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#3661C9] dark:text-sky-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-[#3661C9] dark:bg-sky-400 shrink-0" />
            <span>Customer</span>
          </span>
        );
      case 'Khách hàng mới':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-indigo-600 dark:text-sky-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 dark:bg-sky-400 shrink-0" />
            <span>Prospect</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-[#E96F22] dark:text-amber-400 whitespace-nowrap">
            <span className="w-1.5 h-1.5 rounded-full bg-[#E96F22] dark:bg-amber-400 shrink-0" />
            <span>Lead</span>
          </span>
        );
    }
  };

  const openCreateModal = () => {
    setEditingContact(null);
    setFormData({
      fullName: '',
      company: '',
      title: 'Giám đốc Mua hàng',
      email: '',
      phone: '',
      type: 'Khách hàng mới',
      address: 'Tầng 5, Tòa nhà Detech, Tôn Thất Thuyết',
      city: 'Hà Nội',
      dealsCount: 0,
      totalSpent: 0,
      assignedTo: 'Trần Minh Đức',
    });
    setIsModalOpen(true);
  };

  const openEditModal = (c: Contact, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingContact(c);
    setFormData({
      fullName: c.fullName,
      company: c.company,
      title: c.title,
      email: c.email,
      phone: c.phone,
      type: c.type,
      address: c.address,
      city: c.city,
      dealsCount: c.dealsCount,
      totalSpent: c.totalSpent,
      assignedTo: c.assignedTo,
    });
    setIsModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim() || !formData.company.trim()) return;

    if (editingContact) {
      updateContact(editingContact.id, formData);
      if (selectedContact?.id === editingContact.id) {
        setSelectedContact({ ...selectedContact, ...formData });
      }
      showToast('Thành công', 'Cập nhật thông tin khách hàng thành công');
    } else {
      addContact(formData);
      showToast('Thành công', 'Đã thêm khách hàng mới vào hệ thống');
    }
    setIsModalOpen(false);
  };

  const handleAddNote = (contactId: string) => {
    if (!newNoteText.trim()) return;
    const newNote = {
      id: `note-${Date.now()}`,
      text: newNoteText.trim(),
      date: 'Vừa xong',
      author: 'Tôi',
    };
    setNotes((prev) => ({
      ...prev,
      [contactId]: [newNote, ...(prev[contactId] || [])],
    }));
    setNewNoteText('');
    showToast('Đã lưu ghi chú', 'Ghi chú đã được thêm vào hồ sơ khách hàng');
  };

  const handleLogCall = (contact: Contact) => {
    const newAct: ActivityItem = {
      id: `act-${Date.now()}`,
      type: 'call',
      title: `Đã kết nối cuộc gọi với ${contact.fullName}`,
      description: `Cuộc gọi thoại qua hotline lúc ${new Date().toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}.`,
      timestamp: 'Vừa xong',
      author: 'Tôi',
    };
    setActivities((prev) => ({
      ...prev,
      [contact.id]: [newAct, ...(prev[contact.id] || [])],
    }));
    showToast('Đã ghi nhận cuộc gọi', `Ghi log cuộc gọi thành công cho ${contact.fullName}`);
  };

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* 01. Context Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-bold text-[#0F172A] tracking-tight">
              {isVi ? 'Khách hàng' : 'Customer Management'}
            </h1>
            <span className="text-xs font-mono font-medium text-[#64748B] bg-slate-100 px-2 py-0.5 rounded">
              {contacts.length} {isVi ? 'bản ghi' : 'records'}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-[#64748B] mt-0.5">
            {isVi
              ? 'Quản lý toàn bộ danh bạ, lịch sử tương tác và giá trị quan hệ khách hàng.'
              : 'Unified customer operations, contact history, and account revenue.'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 flex-wrap">
          {canCreate && (
            <button
              onClick={openCreateModal}
              className="flex items-center gap-1 px-2 py-1 sm:px-3.5 sm:py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white text-[11px] sm:text-xs font-medium transition-colors shadow-xs whitespace-nowrap shrink-0"
            >
              <Plus className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">{isVi ? 'Thêm khách hàng' : 'Add Customer'}</span>
              <span className="sm:hidden">{isVi ? 'Khách hàng' : 'Add'}</span>
            </button>
          )}
        </div>
      </div>

      {/* 02. Search & Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-[#E5E7EB]">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={isVi ? 'Tìm theo tên, công ty, email, số điện thoại...' : 'Search by name, company, email, phone...'}
            className="w-full h-8.5 pl-8.5 pr-3 text-xs rounded-lg border border-[#E5E7EB] bg-[#F7F9FC] focus:bg-white focus:outline-hidden focus:border-[#3661C9] transition-colors"
          />
        </div>

        {/* Filter Dropdowns */}
        <div className="flex items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="h-8.5 px-2.5 text-xs rounded-lg border border-[#E5E7EB] bg-white text-slate-700 focus:outline-hidden focus:border-[#3661C9]"
          >
            <option value="all">{isVi ? 'Tất cả trạng thái' : 'All Statuses'}</option>
            <option value="Khách hàng VIP">VIP Customer</option>
            <option value="Khách hàng thân thiết">Loyal Customer</option>
            <option value="Khách hàng mới">New Prospect</option>
            <option value="Đối tác">Partner</option>
          </select>
        </div>
      </div>

      {/* 03. Customer Table (Data-First, Clean Row Height, Hover, No Zebra) */}
      <div className="bg-white border border-[#E5E7EB] rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#E5E7EB] bg-[#F8FAFC] text-[11px] font-semibold uppercase tracking-wider text-[#64748B]">
                <th className="py-2.5 px-4">{isVi ? 'Khách hàng' : 'Customer'}</th>
                <th className="py-2.5 px-4">{isVi ? 'Công ty' : 'Company'}</th>
                <th className="py-2.5 px-4">{isVi ? 'Trạng thái' : 'Status'}</th>
                <th className="py-2.5 px-4">{isVi ? 'Phụ trách (Owner)' : 'Owner'}</th>
                <th className="py-2.5 px-4 text-right">{isVi ? 'Tổng chi tiêu' : 'Total Revenue'}</th>
                <th className="py-2.5 px-4 text-center">{isVi ? 'Cập nhật' : 'Updated'}</th>
                <th className="py-2.5 px-4 text-right">{isVi ? 'Hành động' : 'Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E7EB] text-xs">
              {filteredContacts.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-[#64748B]">
                    <div className="max-w-xs mx-auto space-y-2">
                      <p className="text-sm font-medium text-slate-800">
                        {isVi ? 'Chưa tìm thấy khách hàng' : 'No customers found'}
                      </p>
                      <p className="text-xs text-slate-500">
                        {isVi ? 'Hãy thử tìm kiếm với từ khóa khác hoặc tạo mới khách hàng.' : 'Try adjusting filters or add a new customer.'}
                      </p>
                      {canCreate && (
                        <button
                          onClick={openCreateModal}
                          className="mt-2 px-3 py-1.5 bg-[#002659] text-white text-xs rounded-lg font-medium"
                        >
                          + {isVi ? 'Thêm khách hàng' : 'Add Customer'}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filteredContacts.map((contact, idx) => (
                  <tr
                    key={contact.id}
                    onClick={() => {
                      setSelectedContact(contact);
                      setDetailTab('overview');
                    }}
                    className={`hover:bg-[#F8FAFC] cursor-pointer transition-colors group ${
                      selectedContact?.id === contact.id ? 'bg-[#F0F7FD]/60' : ''
                    }`}
                  >
                    {/* Customer Name & Email */}
                    <td className="py-3 px-4">
                      <div className="font-semibold text-[#0F172A] group-hover:text-[#002659] transition-colors">
                        {contact.fullName}
                      </div>
                      <div className="text-[11px] text-[#64748B] font-mono mt-0.5">
                        {contact.phone}
                      </div>
                    </td>

                    {/* Company & Title */}
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-800">{contact.company}</div>
                      <div className="text-[11px] text-slate-500">{contact.title}</div>
                    </td>

                    {/* Status System Badge */}
                    <td className="py-3 px-4 whitespace-nowrap">
                      {getStatusBadge(contact.type)}
                    </td>

                    {/* Owner */}
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-[#002659] font-bold text-[10px] flex items-center justify-center">
                          {contact.assignedTo.split(' ').pop()?.[0]}
                        </span>
                        <span className="text-slate-700">{contact.assignedTo}</span>
                      </div>
                    </td>

                    {/* Total Spent */}
                    <td className="py-3 px-4 text-right font-mono font-semibold text-slate-900 tabular-nums">
                      {formatVND(contact.totalSpent)}
                    </td>

                    {/* Last Updated */}
                    <td className="py-3 px-4 text-center text-[11px] text-slate-400 font-mono whitespace-nowrap">
                      {idx % 3 === 0 ? '10 phút trước' : idx % 3 === 1 ? '1 giờ trước' : 'Hôm qua'}
                    </td>

                    {/* Quick Row Actions */}
                    <td className="py-3 px-4 text-right whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => {
                            setSelectedContact(contact);
                            setDetailTab('overview');
                          }}
                          className="px-2 py-1 text-[11px] font-medium text-[#3661C9] hover:bg-[#F0F7FD] rounded transition-colors"
                        >
                          {isVi ? 'Xem hồ sơ' : 'Inspect'}
                        </button>
                        {canEdit && (
                          <button
                            onClick={(e) => openEditModal(contact, e)}
                            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded"
                            title="Chỉnh sửa"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        {canDelete && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              if (window.confirm(`Xác nhận xóa khách hàng ${contact.fullName}?`)) {
                                deleteContact(contact.id);
                                if (selectedContact?.id === contact.id) setSelectedContact(null);
                                showToast('Đã xóa', 'Đã gỡ bỏ khách hàng khỏi hệ thống', 'info');
                              }
                            }}
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded"
                            title="Xóa"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* 04. Customer Detail Slide-Over Drawer (Mục 16) */}
      {selectedContact && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/40 backdrop-blur-xs flex justify-end animate-in fade-in duration-150">
          <div className="w-full max-w-2xl bg-white h-full shadow-2xl flex flex-col border-l border-[#E5E7EB] animate-in slide-in-from-right duration-200">
            {/* Header of Detail Panel */}
            <div className="p-4 sm:p-5 border-b border-[#E5E7EB] bg-[#F8FAFC]">
              <div className="flex items-center justify-between mb-3">
                <button
                  onClick={() => setSelectedContact(null)}
                  className="flex items-center gap-1.5 text-xs text-[#64748B] hover:text-[#002659] font-medium"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>{isVi ? 'Quay lại danh sách' : 'Back to list'}</span>
                </button>

                <div className="flex items-center gap-1">
                  {canEdit && (
                    <button
                      onClick={() => openEditModal(selectedContact)}
                      className="px-2.5 py-1 text-xs font-medium border border-[#E5E7EB] rounded-lg bg-white hover:bg-slate-50 text-slate-700"
                    >
                      {isVi ? 'Chỉnh sửa' : 'Edit'}
                    </button>
                  )}
                  <button
                    onClick={() => setSelectedContact(null)}
                    className="p-1 text-slate-400 hover:text-slate-700 rounded-lg"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Title & Quick Actions */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-[#0F172A]">
                      {selectedContact.fullName}
                    </h2>
                    {getStatusBadge(selectedContact.type)}
                  </div>
                  <p className="text-xs text-[#64748B] mt-0.5">
                    {selectedContact.title} • {selectedContact.company}
                  </p>
                </div>

                {/* Direct 1-Click Action Buttons */}
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => handleLogCall(selectedContact)}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 shadow-xs"
                    title="Gọi điện thoại"
                  >
                    <Phone className="w-3.5 h-3.5 text-[#3661C9]" />
                    <span>{isVi ? 'Gọi' : 'Call'}</span>
                  </button>

                  <a
                    href={`mailto:${selectedContact.email}`}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-[#E5E7EB] bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 shadow-xs"
                    title="Gửi Email"
                  >
                    <Mail className="w-3.5 h-3.5 text-[#3661C9]" />
                    <span>Email</span>
                  </a>

                  <button
                    onClick={() => {
                      setSelectedContact(null);
                      setActiveModule('opportunities');
                    }}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#002659] hover:bg-[#001a3d] text-white text-xs font-medium shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isVi ? 'Tạo deal' : 'Deal'}</span>
                  </button>
                </div>
              </div>

              {/* Detail Tabs */}
              <div className="flex items-center gap-1 mt-4 pt-2 border-t border-[#E5E7EB] overflow-x-auto">
                <button
                  onClick={() => setDetailTab('overview')}
                  className={`px-2.5 sm:px-3 py-1 text-[11px] sm:text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    detailTab === 'overview'
                      ? 'bg-white text-[#002659] font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {isVi ? 'Tổng quan' : 'Overview'}
                </button>
                <button
                  onClick={() => setDetailTab('activity')}
                  className={`px-2.5 sm:px-3 py-1 text-[11px] sm:text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    detailTab === 'activity'
                      ? 'bg-white text-[#002659] font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span className="hidden sm:inline">{isVi ? 'Lịch sử hoạt động' : 'Activity'}</span>
                  <span className="sm:hidden">{isVi ? 'Lịch sử' : 'Act'}</span>
                </button>
                <button
                  onClick={() => setDetailTab('deals')}
                  className={`px-2.5 sm:px-3 py-1 text-[11px] sm:text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    detailTab === 'deals'
                      ? 'bg-white text-[#002659] font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <span className="hidden sm:inline">{isVi ? 'Deals / Cơ hội' : 'Deals'}</span>
                  <span className="sm:hidden">Deals</span>
                </button>
                <button
                  onClick={() => setDetailTab('notes')}
                  className={`px-2.5 sm:px-3 py-1 text-[11px] sm:text-xs font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 ${
                    detailTab === 'notes'
                      ? 'bg-white text-[#002659] font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {isVi ? 'Ghi chú' : 'Notes'}
                </button>
              </div>
            </div>

            {/* Content Area of Detail Panel */}
            <div className="flex-1 overflow-y-auto p-5 space-y-5">
              {/* TAB 1: OVERVIEW */}
              {detailTab === 'overview' && (
                <div className="space-y-5">
                  {/* Quick KPI stats */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-lg border border-[#E5E7EB] bg-[#F8FAFC]">
                      <div className="text-[10px] uppercase font-semibold text-[#64748B]">
                        {isVi ? 'Tổng giá trị giao dịch' : 'Total Spent'}
                      </div>
                      <div className="text-lg font-bold text-[#0F172A] font-mono mt-1">
                        {formatVND(selectedContact.totalSpent)}
                      </div>
                    </div>
                    <div className="p-3 rounded-lg border border-[#E5E7EB] bg-[#F8FAFC]">
                      <div className="text-[10px] uppercase font-semibold text-[#64748B]">
                        {isVi ? 'Số lượng deal tham gia' : 'Deals Count'}
                      </div>
                      <div className="text-lg font-bold text-[#0F172A] font-mono mt-1">
                        {selectedContact.dealsCount} deals
                      </div>
                    </div>
                  </div>

                  {/* Core Information Grid */}
                  <div className="rounded-xl border border-[#E5E7EB] p-4 space-y-3.5">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      {isVi ? 'Thông tin liên hệ & Đơn vị' : 'Contact & Organization'}
                    </h3>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                      <div>
                        <span className="text-[11px] text-slate-400 block">{isVi ? 'Số điện thoại' : 'Phone'}</span>
                        <span className="font-mono font-medium text-slate-800">{selectedContact.phone}</span>
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 block">Email</span>
                        <span className="font-medium text-slate-800">{selectedContact.email}</span>
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 block">{isVi ? 'Công ty / Đơn vị' : 'Company'}</span>
                        <span className="font-medium text-slate-800">{selectedContact.company}</span>
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 block">{isVi ? 'Chức vụ' : 'Title'}</span>
                        <span className="font-medium text-slate-800">{selectedContact.title}</span>
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 block">{isVi ? 'Người phụ trách' : 'Assigned Owner'}</span>
                        <span className="font-medium text-slate-800">{selectedContact.assignedTo}</span>
                      </div>
                      <div>
                        <span className="text-[11px] text-slate-400 block">{isVi ? 'Địa bàn / Tỉnh thành' : 'City'}</span>
                        <span className="font-medium text-slate-800">{selectedContact.city}</span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-[#E5E7EB]">
                      <span className="text-[11px] text-slate-400 block">{isVi ? 'Địa chỉ văn phòng' : 'Address'}</span>
                      <span className="text-xs text-slate-700">{selectedContact.address}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: ACTIVITY TIMELINE (Mục 16) */}
              {detailTab === 'activity' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      {isVi ? 'Dòng thời gian tương tác' : 'Interaction History'}
                    </h3>
                    <button
                      onClick={() => handleLogCall(selectedContact)}
                      className="text-xs text-[#3661C9] hover:underline font-medium"
                    >
                      + {isVi ? 'Ghi nhận cuộc gọi' : 'Log call'}
                    </button>
                  </div>

                  <div className="relative pl-5 space-y-4 border-l-2 border-slate-200">
                    {(activities[selectedContact.id] || activities['contact-1'] || []).map((act) => (
                      <div key={act.id} className="relative group">
                        {/* Dot */}
                        <div className="absolute -left-[27px] top-1 w-3 h-3 rounded-full bg-[#3661C9] ring-4 ring-white" />
                        <div className="text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-[#0F172A]">{act.title}</span>
                            <span className="text-[11px] text-slate-400 font-mono">{act.timestamp}</span>
                          </div>
                          <p className="text-slate-600 mt-0.5 leading-relaxed">{act.description}</p>
                          <span className="text-[10px] text-slate-400 mt-1 block">
                            {isVi ? 'Thực hiện bởi:' : 'By:'} {act.author}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: DEALS */}
              {detailTab === 'deals' && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      {isVi ? 'Danh sách Deals & Cơ hội' : 'Associated Deals'}
                    </h3>
                    <button
                      onClick={() => {
                        setSelectedContact(null);
                        setActiveModule('opportunities');
                      }}
                      className="text-xs text-[#3661C9] hover:underline font-medium"
                    >
                      + {isVi ? 'Tạo deal mới' : 'New Deal'}
                    </button>
                  </div>

                  <div className="space-y-2">
                    {opportunities
                      .filter((o) => o.company === selectedContact.company || o.contactName === selectedContact.fullName)
                      .map((opp) => (
                        <div
                          key={opp.id}
                          className="p-3 rounded-lg border border-[#E5E7EB] hover:border-slate-300 transition-colors bg-white flex items-center justify-between"
                        >
                          <div>
                            <div className="font-semibold text-xs text-slate-900">{opp.title}</div>
                            <div className="text-[11px] text-slate-500 mt-0.5">
                              {opp.stage} • Xác suất {opp.probability}%
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold font-mono text-xs text-[#002659]">
                              {formatVND(opp.amount)}
                            </div>
                            <span className="text-[10px] text-slate-400">{opp.expectedCloseDate}</span>
                          </div>
                        </div>
                      ))}

                    {opportunities.filter((o) => o.company === selectedContact.company || o.contactName === selectedContact.fullName).length === 0 && (
                      <div className="p-4 rounded-lg border border-dashed border-[#E5E7EB] text-center text-xs text-slate-500">
                        {isVi ? 'Chưa có deal liên kết với khách hàng này.' : 'No active deals for this contact.'}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 4: NOTES */}
              {detailTab === 'notes' && (
                <div className="space-y-4">
                  {/* Note input */}
                  <div className="space-y-2">
                    <textarea
                      value={newNoteText}
                      onChange={(e) => setNewNoteText(e.target.value)}
                      placeholder={isVi ? 'Ghi lại nội dung ghi chú quan trọng về khách hàng...' : 'Write notes on customer preferences, blockers, agreements...'}
                      rows={3}
                      className="w-full text-xs p-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                    />
                    <div className="flex justify-end">
                      <button
                        onClick={() => handleAddNote(selectedContact.id)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-[#002659] text-white text-xs font-medium rounded-lg"
                      >
                        <Send className="w-3 h-3" />
                        <span>{isVi ? 'Lưu ghi chú' : 'Save Note'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Notes list */}
                  <div className="space-y-2.5">
                    {(notes[selectedContact.id] || notes['contact-1'] || []).map((n) => (
                      <div key={n.id} className="p-3 rounded-lg bg-[#F8FAFC] border border-[#E5E7EB] text-xs">
                        <p className="text-slate-800 leading-relaxed">{n.text}</p>
                        <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2 pt-1 border-t border-slate-200">
                          <span>{n.author}</span>
                          <span>{n.date}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* 05. Create / Edit Contact Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-[#E5E7EB] max-w-lg w-full shadow-2xl overflow-hidden animate-in fade-in duration-150">
            <div className="px-5 py-4 border-b border-[#E5E7EB] flex items-center justify-between bg-[#F8FAFC]">
              <h3 className="text-sm font-bold text-[#0F172A]">
                {editingContact
                  ? isVi ? 'Chỉnh sửa thông tin khách hàng' : 'Edit Customer'
                  : isVi ? 'Thêm khách hàng mới' : 'Add New Customer'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleFormSubmit} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">
                  {isVi ? 'Họ và tên khách hàng *' : 'Customer Name *'}
                </label>
                <input
                  type="text"
                  required
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  placeholder="Ví dụ: Nguyễn Văn An"
                  className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Công ty / Tổ chức *' : 'Company *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    placeholder="Ví dụ: Dược Liệu Á Châu"
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Chức danh' : 'Job Title'}
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Số điện thoại' : 'Phone'}
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="0912345678"
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="an.nguyen@example.com"
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Phân loại khách hàng' : 'Customer Category'}
                  </label>
                  <select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value as Contact['type'] })}
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] bg-white focus:outline-hidden focus:border-[#3661C9]"
                  >
                    <option value="Khách hàng VIP">Khách hàng VIP</option>
                    <option value="Khách hàng thân thiết">Khách hàng thân thiết</option>
                    <option value="Khách hàng mới">Khách hàng mới (Prospect)</option>
                    <option value="Đối tác">Đối tác (Partner)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">
                    {isVi ? 'Tỉnh thành' : 'City'}
                  </label>
                  <input
                    type="text"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">
                  {isVi ? 'Địa chỉ' : 'Address'}
                </label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full h-9 px-3 rounded-lg border border-[#E5E7EB] focus:outline-hidden focus:border-[#3661C9]"
                />
              </div>

              <div className="pt-3 border-t border-[#E5E7EB] flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 rounded-lg border border-[#E5E7EB] text-slate-700 hover:bg-slate-50 font-medium"
                >
                  {isVi ? 'Hủy bỏ' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-[#002659] text-white font-medium hover:bg-[#001a3d] shadow-xs"
                >
                  {isVi ? 'Lưu thông tin' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
