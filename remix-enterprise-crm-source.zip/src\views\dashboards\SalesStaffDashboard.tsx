import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import {
  Phone,
  Mail,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  Target,
  DollarSign,
  TrendingUp,
  AlertCircle,
  Building,
  User,
  ExternalLink,
  ChevronRight,
  Flame,
  Award,
  Plus,
} from 'lucide-react';
import { LeadStatus, OpportunityStageName } from '../../types/sales';

export const SalesStaffDashboard: React.FC = () => {
  const { currentUser, setActiveModule, showToast } = useCRM();
  const { leads, updateLead, opportunities, updateOpportunity } = useSales();

  // Filter Leads assigned to current user (defaulting to Nguyễn Văn A)
  const myLeads = leads.filter(
    (l) => l.assignedTo === currentUser.fullName || l.assignedTo === 'Nguyễn Văn A'
  );

  // Filter Opportunities assigned to current user
  const myOpportunities = opportunities.filter(
    (o) => o.assignedTo === currentUser.fullName || o.assignedTo === 'Nguyễn Văn A'
  );

  // Status transitions
  const handleUpdateLeadStatus = (leadId: string, currentStatus: LeadStatus) => {
    let nextStatus: LeadStatus = 'Đang liên hệ';
    if (currentStatus === 'Mới') nextStatus = 'Đang liên hệ';
    else if (currentStatus === 'Đang liên hệ') nextStatus = 'Đủ điều kiện';
    else if (currentStatus === 'Đủ điều kiện') nextStatus = 'Mới';

    updateLead(leadId, {
      status: nextStatus,
      lastContactedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    });
    showToast('Cập nhật trạng thái Lead', `Đã chuyển sang trạng thái: "${nextStatus}"`);
  };

  const handleAdvanceDealStage = (oppId: string, currentStage: OpportunityStageName) => {
    const stageFlow: OpportunityStageName[] = [
      'Khảo sát & Đánh giá nhu cầu',
      'Xây dựng giải pháp kỹ thuật',
      'Báo giá & Đề xuất',
      'Đàm phán',
      'Thành công (Won)',
    ];
    const currentIndex = stageFlow.indexOf(currentStage);
    const nextIndex = (currentIndex + 1) % stageFlow.length;
    const nextStage = stageFlow[nextIndex];

    updateOpportunity(oppId, { stage: nextStage });
    showToast('Cập nhật tiến độ Deal', `Deal đã chuyển sang giai đoạn: "${nextStage}"`);
  };

  // Today's Appointments & Tasks for Sales Staff
  const [appointments, setAppointments] = useState([
    {
      id: 'apt-1',
      time: '09:30 - 10:30',
      client: 'Lê Văn Thành (Công ty CP Sữa Quốc Tế LOF)',
      type: 'Họp trực tuyến Teams',
      note: 'Demo luồng đơn hàng đại lý B2B & tồn kho chi nhánh',
      completed: true,
    },
    {
      id: 'apt-2',
      time: '14:00 - 15:00',
      client: 'Hoàng Minh Tuấn (FPT Retail)',
      type: 'Gặp trực tiếp văn phòng',
      note: 'Thống nhất điều khoản thanh toán & ký hợp đồng gói CRM',
      completed: false,
    },
    {
      id: 'apt-3',
      time: '16:30 - 17:00',
      client: 'Trần Thị Thu Trang (Phúc Long Masan)',
      type: 'Gọi điện thoại Zalo',
      note: 'Gửi bảng báo giá điều chỉnh chiết khấu 5% đợt 1',
      completed: false,
    },
  ]);

  const toggleAppointment = (id: string) => {
    setAppointments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, completed: !a.completed } : a))
    );
    showToast('Lịch làm việc', 'Đã cập nhật trạng thái cuộc hẹn.');
  };

  // Calculations
  const targetRevenue = 1000000000; // 1 Tỷ
  const actualRevenue = 820000000; // 820 Triệu
  const progressPercent = Math.round((actualRevenue / targetRevenue) * 100);

  return (
    <div className="space-y-6 max-w-[1400px] mx-auto pb-12">
      {/* 1. Header Banner */}
      <div className="bg-gradient-to-r from-[#002659] via-[#0A3A7A] to-[#1E4A8A] rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-96 bg-radial from-cyan-400/20 via-transparent to-transparent pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={currentUser.avatar}
              alt={currentUser.fullName}
              className="w-16 h-16 rounded-full border-2 border-white/80 object-cover shadow-md shrink-0"
            />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl font-bold tracking-tight">
                  Xin chào, {currentUser.fullName}
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-cyan-400/20 text-cyan-200 border border-cyan-300/30">
                  Chuyên Viên Sales B2B
                </span>
              </div>
              <p className="text-sky-200 text-sm mt-1">
                Không gian làm việc &amp; Quản trị khách hàng cá nhân. Bạn đang phụ trách{' '}
                <strong className="text-white">{myLeads.length} Lead nóng</strong> và{' '}
                <strong className="text-white">{myOpportunities.length} Cơ hội Deal</strong> cần xử lý hôm nay.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setActiveModule('leads')}
              className="px-4 py-2 bg-white text-[#002659] hover:bg-sky-50 rounded-lg text-sm font-bold shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
            >
              <span>Xem danh sách Lead của tôi</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 2. 4 Personal KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Doanh số cá nhân */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Chỉ tiêu tháng cá nhân
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Target className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              820.000.000 ₫
            </div>
            <div className="flex items-center justify-between text-xs text-slate-500 mt-1">
              <span>Mục tiêu: 1.000.000.000 ₫</span>
              <span className="font-bold text-emerald-600">{progressPercent}%</span>
            </div>
            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full mt-2 overflow-hidden">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* KPI 2: Lead được phân bổ */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Lead được phân bổ cho tôi
            </span>
            <div className="w-8 h-8 rounded-lg bg-cyan-100 dark:bg-cyan-950 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
              <Flame className="w-4 h-4 text-orange-500" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {myLeads.length} Lead
            </div>
            <div className="text-xs text-slate-500 mt-1">
              <span className="text-amber-600 font-bold">
                {myLeads.filter((l) => l.status === 'Mới').length} Lead mới
              </span>{' '}
              cần gọi ngay trong ngày
            </div>
          </div>
        </div>

        {/* KPI 3: Cơ hội / Deal đang mở */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Cơ hội Deal phụ trách
            </span>
            <div className="w-8 h-8 rounded-lg bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {myOpportunities.length} Deals
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Tổng giá trị:{' '}
              <span className="font-bold text-indigo-600 font-mono">
                {myOpportunities.reduce((s, o) => s + (o.amount || 0), 0).toLocaleString('vi-VN')} ₫
              </span>
            </div>
          </div>
        </div>

        {/* KPI 4: Cuộc hẹn & Hoạt động hôm nay */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Lịch gặp khách hàng hôm nay
            </span>
            <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400 flex items-center justify-center">
              <Calendar className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              {appointments.filter((a) => !a.completed).length} / {appointments.length} Cuộc hẹn
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Đã hoàn tất {appointments.filter((a) => a.completed).length} lịch hẹn
            </div>
          </div>
        </div>
      </div>

      {/* 3. Main Content: Leads được phân bổ & Deals phụ trách */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column (2 Cols): Danh sách Leads nóng của tôi */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-slate-900 dark:text-white">
                    Leads nóng được phân bổ cho {currentUser.fullName}
                  </h3>
                  <span className="text-xs bg-cyan-100 text-cyan-800 dark:bg-cyan-950 dark:text-cyan-300 px-2 py-0.5 rounded-full font-semibold">
                    {myLeads.length} Lead
                  </span>
                </div>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Bấm trực tiếp vào trạng thái để chuyển giai đoạn tác nghiệp ngay trên màn hình.
                </p>
              </div>
              <button
                onClick={() => setActiveModule('leads')}
                className="text-xs font-semibold text-[#002659] dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Xem tất cả</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-4 divide-y divide-slate-100 dark:divide-slate-800">
              {myLeads.map((lead) => (
                <div
                  key={lead.id}
                  className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 px-2 rounded-lg transition-colors"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs text-slate-400">{lead.code}</span>
                      <h4 className="font-bold text-sm text-slate-900 dark:text-white truncate">
                        {lead.fullName}
                      </h4>
                      <span className="text-xs text-slate-500 truncate">({lead.company})</span>
                    </div>
                    <div className="flex items-center gap-4 mt-1 text-xs text-slate-500 dark:text-slate-400">
                      <span className="flex items-center gap-1">
                        <Phone className="w-3 h-3 text-emerald-600" />
                        <span className="font-mono">{lead.phone}</span>
                      </span>
                      <span className="hidden sm:inline">•</span>
                      <span>Dự kiến: <strong className="text-slate-700 dark:text-slate-300 font-mono">{(lead.estimatedValue || 0).toLocaleString('vi-VN')} ₫</strong></span>
                      <span className="hidden sm:inline">•</span>
                      <span>Nguồn: <strong>{lead.source}</strong></span>
                    </div>
                    {lead.notes && (
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-1 italic bg-slate-50 dark:bg-slate-800/60 p-1 rounded">
                        "{lead.notes}"
                      </p>
                    )}
                  </div>

                  {/* Actions & Status Changer */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleUpdateLeadStatus(lead.id, lead.status)}
                      title="Bấm để đổi trạng thái"
                      className={`px-2.5 py-1 rounded-md text-xs font-bold border transition-all cursor-pointer flex items-center gap-1.5 ${
                        lead.status === 'Mới'
                          ? 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                          : lead.status === 'Đang liên hệ'
                          ? 'bg-sky-50 text-sky-700 border-sky-200 hover:bg-sky-100'
                          : 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                      }`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-current" />
                      <span>{lead.status}</span>
                      <span className="text-[10px] opacity-70">↻</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        window.location.href = `tel:${lead.phone}`;
                        showToast('Cuộc gọi', `Đang kết nối tới ${lead.fullName}...`);
                      }}
                      className="p-1.5 rounded-md text-emerald-600 hover:bg-emerald-50 border border-slate-200 dark:border-slate-700 hover:border-emerald-300 cursor-pointer"
                      title="Gọi điện thoại"
                    >
                      <Phone className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Deals / Cơ hội bán hàng của tôi */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Cơ hội Deal đang theo đuổi
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  Bấm chuyển giai đoạn để cập nhật tiến độ deal.
                </p>
              </div>
              <button
                onClick={() => setActiveModule('opportunities')}
                className="text-xs font-semibold text-[#002659] dark:text-sky-400 hover:underline flex items-center gap-1 cursor-pointer"
              >
                <span>Xem tất cả Deal</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              {myOpportunities.map((opp) => (
                <div
                  key={opp.id}
                  className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-850 hover:border-sky-300 dark:hover:border-sky-700 transition-colors"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs text-slate-400">{opp.code}</span>
                        <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                          {opp.title}
                        </h4>
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-2">
                        <Building className="w-3 h-3 text-slate-400" />
                        <span>{opp.customerName}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-base font-bold font-mono text-emerald-600 dark:text-emerald-400">
                        {opp.amount.toLocaleString('vi-VN')} ₫
                      </div>
                      <div className="text-[11px] text-slate-400">Xác suất: {opp.probability}%</div>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-200/70 dark:border-slate-700/60 flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-slate-500">Giai đoạn:</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-800 px-2 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                        {opp.stage}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleAdvanceDealStage(opp.id, opp.stage)}
                      className="px-2.5 py-1 text-xs font-semibold bg-[#002659] hover:bg-[#001f4a] text-white rounded-md transition-colors cursor-pointer flex items-center gap-1 shadow-2xs"
                    >
                      <span>Chuyển bước kế tiếp</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column (1 Col): Lịch hẹn hôm nay & Nhắc nhở */}
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#002659] dark:text-sky-400" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Lịch gặp &amp; Cuộc gọi hôm nay
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">Hôm nay</span>
            </div>

            <div className="mt-4 space-y-3">
              {appointments.map((apt) => (
                <div
                  key={apt.id}
                  onClick={() => toggleAppointment(apt.id)}
                  className={`p-3 rounded-lg border transition-all cursor-pointer ${
                    apt.completed
                      ? 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 opacity-60'
                      : 'bg-white dark:bg-slate-850 border-sky-100 dark:border-sky-900/40 hover:border-sky-300 shadow-2xs'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs font-bold text-sky-700 dark:text-sky-300 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      <span>{apt.time}</span>
                    </span>
                    <input
                      type="checkbox"
                      checked={apt.completed}
                      onChange={() => {}}
                      className="rounded text-[#002659] focus:ring-0 cursor-pointer"
                    />
                  </div>
                  <div className="font-bold text-xs text-slate-900 dark:text-white mt-1.5">
                    {apt.client}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{apt.type}</div>
                  <div className="text-[11px] text-slate-600 dark:text-slate-400 italic mt-1 bg-slate-50 dark:bg-slate-800 p-1 rounded">
                    {apt.note}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-gradient-to-br from-sky-50 to-indigo-50/50 dark:from-sky-950/20 dark:to-indigo-950/20 border border-sky-100 dark:border-sky-900/40 rounded-xl p-5 shadow-xs">
            <h4 className="text-sm font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-sky-600" />
              <span>Thao tác nhanh cho Sales</span>
            </h4>
            <div className="space-y-2 text-xs">
              <button
                onClick={() => setActiveModule('quotations')}
                className="w-full text-left p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-semibold hover:border-sky-500 hover:text-sky-600 transition-colors flex items-center justify-between cursor-pointer"
              >
                <span>Tạo báo giá mới cho khách hàng</span>
                <Plus className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setActiveModule('customers')}
                className="w-full text-left p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-semibold hover:border-sky-500 hover:text-sky-600 transition-colors flex items-center justify-between cursor-pointer"
              >
                <span>Tra cứu hồ sơ khách hàng của tôi</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => setActiveModule('my-profile')}
                className="w-full text-left p-2.5 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-semibold hover:border-sky-500 hover:text-sky-600 transition-colors flex items-center justify-between cursor-pointer"
              >
                <span>Cập nhật hồ sơ cá nhân &amp; Chữ ký</span>
                <User className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
