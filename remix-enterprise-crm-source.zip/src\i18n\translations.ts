import { LanguageCode } from '../types/crm';

export interface Dictionary {
  // Common
  search: string;
  filter: string;
  create: string;
  edit: string;
  delete: string;
  cancel: string;
  save: string;
  export: string;
  import: string;
  actions: string;
  status: string;
  viewDetails: string;
  close: string;
  refresh: string;
  all: string;
  confirmDelete: string;
  yes: string;
  no: string;
  success: string;
  error: string;
  loading: string;
  noData: string;
  totalRecords: string;
  page: string;
  rowsPerPage: string;
  inspectSpec: string;

  // Navigation & Modules
  dashboard: string;
  okr: string;
  leads: string;
  contacts: string;
  opportunities: string;
  quotations: string;
  contracts: string;
  customerCare: string;
  inventory: string;
  reports: string;
  settings: string;
  specifications: string;

  // Roles
  superAdmin: string;
  tenantAdmin: string;
  salesManager: string;
  salesStaff: string;
  customerCareStaff: string;
  warehouseStaff: string;

  // Header
  switchTenant: string;
  switchRole: string;
  switchLanguage: string;
  switchTheme: string;
  notifications: string;
  markAllRead: string;
  profile: string;
  logout: string;
  systemArchitecture: string;
  currentTenant: string;
  activeRole: string;

  // Dashboard
  totalRevenue: string;
  pipelineValue: string;
  newLeadsMonth: string;
  winRate: string;
  revenueChartTitle: string;
  salesFunnelTitle: string;
  recentDeals: string;
  slaUrgentTickets: string;
  inventoryAlerts: string;
  quickActions: string;

  // Leads
  leadCode: string;
  leadName: string;
  company: string;
  phone: string;
  email: string;
  source: string;
  leadScore: string;
  assignedStaff: string;
  convertToOpportunity: string;
  newLead: string;

  // Opportunities
  dealName: string;
  stage: string;
  dealValue: string;
  probability: string;
  expectedClose: string;
  kanbanView: string;
  tableView: string;

  // Quotations
  quoteCode: string;
  quoteTitle: string;
  customer: string;
  grandTotal: string;
  validUntil: string;
  previewPdf: string;
  approveQuote: string;
  rejectQuote: string;
  addItem: string;

  // Contracts
  contractCode: string;
  contractTitle: string;
  contractValue: string;
  startDate: string;
  endDate: string;
  paymentMilestones: string;

  // Customer Care
  ticketCode: string;
  channel: string;
  subject: string;
  priority: string;
  slaRemaining: string;
  csatScore: string;
  resolveTicket: string;

  // Inventory
  sku: string;
  productName: string;
  category: string;
  unit: string;
  sellingPrice: string;
  stockHn: string;
  stockDn: string;
  stockHcm: string;
  totalStock: string;
  stockTransactions: string;
  stockIn: string;
  stockOut: string;

  // Settings
  tenantSettings: string;
  userManagement: string;
  rolePermissions: string;
  notificationCenter: string;
  languageSettings: string;
  themeSettings: string;
  activityLogs: string;
  auditLogs: string;

  // Theme Names
  themeCorporateBlue: string;
  themeModernDark: string;
  themeProfessionalGray: string;
  themeEnterpriseGreen: string;
  themeFintechPurple: string;
  themeStartupOrange: string;
  themeMaterialDesign: string;
  themeGlassmorphism: string;
  themeMinimalist: string;
  themeCustomBuilder: string;
}

export const translations: Record<'vi' | 'en', Dictionary> = {
  vi: {
    // Common
    search: 'Tìm kiếm nhanh (Tên, mã, email, sđt)...',
    filter: 'Bộ lọc nâng cao',
    create: 'Thêm mới',
    edit: 'Chỉnh sửa',
    delete: 'Xóa bản ghi',
    cancel: 'Hủy thao tác',
    save: 'Lưu thay đổi',
    export: 'Xuất dữ liệu Excel/CSV',
    import: 'Nhập từ file',
    actions: 'Hành động',
    status: 'Trạng thái',
    viewDetails: 'Xem chi tiết',
    close: 'Đóng',
    refresh: 'Làm mới',
    all: 'Tất cả',
    confirmDelete: 'Bạn có chắc chắn muốn xóa bản ghi này? Hành động này sẽ được ghi vào Audit Log an ninh.',
    yes: 'Đồng ý',
    no: 'Quay lại',
    success: 'Thao tác thành công',
    error: 'Có lỗi xảy ra',
    loading: 'Đang tải dữ liệu...',
    noData: 'Chưa có bản ghi nào',
    totalRecords: 'Tổng số bản ghi',
    page: 'Trang',
    rowsPerPage: 'Số dòng mỗi trang',
    inspectSpec: 'Đặc tả màn hình này (Spec)',

    // Navigation & Modules
    dashboard: 'Tổng quan Dashboard',
    okr: 'Mục tiêu OKR & KPI',
    leads: 'Quản lý Khách hàng tiềm năng (Leads)',
    contacts: 'Danh bạ Khách hàng (Contacts)',
    opportunities: 'Cơ hội bán hàng (Opportunities)',
    quotations: 'Báo giá & Đề xuất (Quotations)',
    contracts: 'Hợp đồng kinh tế (Contracts)',
    customerCare: 'Chăm sóc & Hỗ trợ (Customer Care)',
    inventory: 'Quản lý Kho & Sản phẩm (Inventory)',
    reports: 'Báo cáo & Phân tích (Reports)',
    settings: 'Cài đặt hệ thống (Settings)',
    specifications: 'Hồ sơ Đặc tả Hệ thống (Specifications)',

    // Roles
    superAdmin: 'Super Admin (Quản trị tối cao)',
    tenantAdmin: 'Tenant Admin (Quản trị viên Doanh nghiệp)',
    salesManager: 'Sales Manager (Trưởng phòng Kinh doanh)',
    salesStaff: 'Sales Staff (Chuyên viên Bán hàng)',
    customerCareStaff: 'Customer Care Staff (Chuyên viên CSKH)',
    warehouseStaff: 'Warehouse Staff (Thủ kho / Vận hành)',

    // Header
    switchTenant: 'Chọn Doanh nghiệp (Tenant)',
    switchRole: 'Giả lập Vai trò (Role Switcher)',
    switchLanguage: 'Ngôn ngữ hiển thị',
    switchTheme: 'Giao diện & Mẫu Template',
    notifications: 'Thông báo',
    markAllRead: 'Đã đọc tất cả',
    profile: 'Hồ sơ người dùng',
    logout: 'Đăng xuất',
    systemArchitecture: 'Hồ sơ Đặc tả & Kiến trúc',
    currentTenant: 'Doanh nghiệp hiện tại',
    activeRole: 'Vai trò phân quyền',

    // Dashboard
    totalRevenue: 'Tổng doanh thu thực tế',
    pipelineValue: 'Giá trị Pipeline cơ hội',
    newLeadsMonth: 'Leads mới tháng này',
    winRate: 'Tỷ lệ chốt thành công',
    revenueChartTitle: 'Doanh thu & Dự phóng theo Quý (Tỷ VNĐ)',
    salesFunnelTitle: 'Phễu chuyển đổi Bán hàng (Sales Funnel)',
    recentDeals: 'Cơ hội sắp chốt hợp đồng',
    slaUrgentTickets: 'Ticket CSKH cảnh báo SLA (Khẩn cấp)',
    inventoryAlerts: 'Sản phẩm sắp chạm ngưỡng tồn kho an toàn',
    quickActions: 'Tác vụ xử lý nhanh',

    // Leads
    leadCode: 'Mã Lead',
    leadName: 'Họ tên & Người đại diện',
    company: 'Doanh nghiệp',
    phone: 'Số điện thoại',
    email: 'Hòm thư Email',
    source: 'Nguồn tiếp cận',
    leadScore: 'Điểm tiềm năng (Score)',
    assignedStaff: 'Nhân viên phụ trách',
    convertToOpportunity: 'Chuyển đổi thành Cơ hội',
    newLead: 'Tạo Khách hàng tiềm năng mới',

    // Opportunities
    dealName: 'Tên Cơ hội & Dự án',
    stage: 'Giai đoạn',
    dealValue: 'Giá trị dự kiến',
    probability: 'Xác suất (%)',
    expectedClose: 'Ngày dự kiến chốt',
    kanbanView: 'Dạng bảng Kanban',
    tableView: 'Dạng bảng danh sách',

    // Quotations
    quoteCode: 'Mã báo giá',
    quoteTitle: 'Tiêu đề báo giá',
    customer: 'Khách hàng nhận',
    grandTotal: 'Tổng tiền (gồm VAT)',
    validUntil: 'Hạn hiệu lực',
    previewPdf: 'Xem trước Báo giá PDF',
    approveQuote: 'Phê duyệt báo giá',
    rejectQuote: 'Từ chối duyệt',
    addItem: 'Thêm dòng sản phẩm/dịch vụ',

    // Contracts
    contractCode: 'Số hợp đồng',
    contractTitle: 'Nội dung hợp đồng',
    contractValue: 'Giá trị hợp đồng',
    startDate: 'Ngày hiệu lực',
    endDate: 'Ngày đáo hạn',
    paymentMilestones: 'Tiến độ thanh toán',

    // Customer Care
    ticketCode: 'Mã Ticket',
    channel: 'Kênh tiếp nhận',
    subject: 'Tiêu đề sự cố / Yêu cầu',
    priority: 'Độ ưu tiên',
    slaRemaining: 'Thời gian SLA còn lại',
    csatScore: 'Đánh giá CSAT',
    resolveTicket: 'Hoàn tất & Đóng ticket',

    // Inventory
    sku: 'Mã SKU',
    productName: 'Tên sản phẩm / Thiết bị',
    category: 'Danh mục',
    unit: 'Đơn vị tính',
    sellingPrice: 'Giá bán niêm yết',
    stockHn: 'Kho Hà Nội',
    stockDn: 'Kho Đà Nẵng',
    stockHcm: 'Kho TP.HCM',
    totalStock: 'Tổng tồn kho',
    stockTransactions: 'Lịch sử Nhập / Xuất kho',
    stockIn: 'Tạo phiếu Nhập kho',
    stockOut: 'Tạo phiếu Xuất kho',

    // Settings
    tenantSettings: 'Cấu hình Đơn vị (Tenant)',
    userManagement: 'Quản lý Tài khoản & Nhân sự',
    rolePermissions: 'Ma trận Phân quyền 6 Vai trò',
    notificationCenter: 'Trung tâm Quản lý Thông báo',
    languageSettings: 'Bộ máy Đa ngôn ngữ (i18n)',
    themeSettings: 'Bộ máy Giao diện (Theme Engine)',
    activityLogs: 'Nhật ký Hoạt động (Activity Log)',
    auditLogs: 'Nhật ký An ninh (Audit Log)',

    // Theme Names
    themeCorporateBlue: '1. Corporate Blue (Doanh nghiệp Xanh Navy)',
    themeModernDark: '2. Modern Dark (Công nghệ Tối cao cấp)',
    themeProfessionalGray: '3. Professional Gray (Đơn sắc Xám Chuyên nghiệp)',
    themeEnterpriseGreen: '4. Enterprise Green (Tập đoàn Xanh Lá Bền vững)',
    themeFintechPurple: '5. Fintech Purple (Tài chính Tím Hiện đại)',
    themeStartupOrange: '6. Startup Orange (Khởi nghiệp Cam Năng động)',
    themeMaterialDesign: '7. Material Design (Google Material Chuẩn mực)',
    themeGlassmorphism: '8. Glassmorphism (Kính mờ Tinh tế Acrylic)',
    themeMinimalist: '9. Minimalist (Tối giản Tinh gọn Border-first)',
    themeCustomBuilder: '10. Custom Theme Builder (Tùy biến bảng màu trực tiếp)',
  },
  en: {
    // Common
    search: 'Quick search (Name, code, email, phone)...',
    filter: 'Advanced Filter',
    create: 'Add New',
    edit: 'Edit Record',
    delete: 'Delete Record',
    cancel: 'Cancel',
    save: 'Save Changes',
    export: 'Export Excel/CSV',
    import: 'Import from File',
    actions: 'Actions',
    status: 'Status',
    viewDetails: 'View Details',
    close: 'Close',
    refresh: 'Refresh',
    all: 'All',
    confirmDelete: 'Are you sure you want to delete this record? This action will be logged in Security Audit Log.',
    yes: 'Yes, proceed',
    no: 'Cancel',
    success: 'Operation completed successfully',
    error: 'An error occurred',
    loading: 'Loading data...',
    noData: 'No records found',
    totalRecords: 'Total records',
    page: 'Page',
    rowsPerPage: 'Rows per page',
    inspectSpec: 'Inspect Screen Specification',

    // Navigation & Modules
    dashboard: 'Dashboard Overview',
    okr: 'OKR & KPI Targets',
    leads: 'Lead Management',
    contacts: 'Contact Directory',
    opportunities: 'Opportunities Pipeline',
    quotations: 'Quotations & Proposals',
    contracts: 'Economic Contracts',
    customerCare: 'Customer Care & Helpdesk',
    inventory: 'Inventory & Product Catalog',
    reports: 'Reports & Analytics',
    settings: 'System Settings',
    specifications: 'System Specifications Explorer',

    // Roles
    superAdmin: 'Super Admin (System Owner)',
    tenantAdmin: 'Tenant Admin (Enterprise Manager)',
    salesManager: 'Sales Manager',
    salesStaff: 'Sales Staff',
    customerCareStaff: 'Customer Care Staff',
    warehouseStaff: 'Warehouse Staff',

    // Header
    switchTenant: 'Select Enterprise Tenant',
    switchRole: 'Simulate User Role',
    switchLanguage: 'Language',
    switchTheme: 'UI Template & Theme',
    notifications: 'Notifications',
    markAllRead: 'Mark all as read',
    profile: 'User Profile',
    logout: 'Log Out',
    systemArchitecture: 'Architecture & Specifications',
    currentTenant: 'Active Tenant',
    activeRole: 'Active RBAC Role',

    // Dashboard
    totalRevenue: 'Total Realized Revenue',
    pipelineValue: 'Pipeline Forecast Value',
    newLeadsMonth: 'New Leads This Month',
    winRate: 'Opportunity Win Rate',
    revenueChartTitle: 'Quarterly Revenue & Projections ($B / Tr VND)',
    salesFunnelTitle: 'Sales Conversion Funnel',
    recentDeals: 'Deals Closing Soon',
    slaUrgentTickets: 'High-Priority SLA Ticket Alerts',
    inventoryAlerts: 'Products Below Safety Stock',
    quickActions: 'Quick Workflow Actions',

    // Leads
    leadCode: 'Lead Code',
    leadName: 'Contact Name & Rep',
    company: 'Company',
    phone: 'Phone Number',
    email: 'Work Email',
    source: 'Acquisition Source',
    leadScore: 'Lead Score',
    assignedStaff: 'Assigned Specialist',
    convertToOpportunity: 'Convert to Opportunity',
    newLead: 'Create New Lead',

    // Opportunities
    dealName: 'Deal & Opportunity Name',
    stage: 'Sales Stage',
    dealValue: 'Estimated Deal Amount',
    probability: 'Probability (%)',
    expectedClose: 'Expected Close Date',
    kanbanView: 'Kanban Board View',
    tableView: 'Tabular List View',

    // Quotations
    quoteCode: 'Quote Code',
    quoteTitle: 'Proposal Title',
    customer: 'Recipient Customer',
    grandTotal: 'Grand Total (incl. VAT)',
    validUntil: 'Valid Until',
    previewPdf: 'Preview Quote PDF',
    approveQuote: 'Approve Quotation',
    rejectQuote: 'Reject Quotation',
    addItem: 'Add Line Item',

    // Contracts
    contractCode: 'Contract Number',
    contractTitle: 'Contract Title',
    contractValue: 'Contract Value',
    startDate: 'Effective Date',
    endDate: 'Expiration Date',
    paymentMilestones: 'Payment Milestones',

    // Customer Care
    ticketCode: 'Ticket #',
    channel: 'Ingress Channel',
    subject: 'Issue Title / Inquiry',
    priority: 'Priority Level',
    slaRemaining: 'SLA Time Left',
    csatScore: 'CSAT Rating',
    resolveTicket: 'Resolve & Close Ticket',

    // Inventory
    sku: 'SKU Code',
    productName: 'Product / Hardware Name',
    category: 'Product Category',
    unit: 'Unit of Measure',
    sellingPrice: 'Unit Price',
    stockHn: 'Hanoi Depot',
    stockDn: 'Danang Depot',
    stockHcm: 'HCMC Depot',
    totalStock: 'Total Available Stock',
    stockTransactions: 'Warehouse Movement Logs',
    stockIn: 'Stock-In Inward Receipt',
    stockOut: 'Stock-Out Outward Dispatch',

    // Settings
    tenantSettings: 'Enterprise Tenant Profile',
    userManagement: 'User & Staff Directory',
    rolePermissions: '6-Role RBAC Permission Matrix',
    notificationCenter: 'Notification Center Rules',
    languageSettings: 'Multi-Language i18n Engine',
    themeSettings: 'Theme Engine & 10 Templates',
    activityLogs: 'User Activity Logs',
    auditLogs: 'Security Audit Logs',

    // Theme Names
    themeCorporateBlue: '1. Corporate Blue (Deep Navy Enterprise)',
    themeModernDark: '2. Modern Dark (High-Contrast Tech Slate)',
    themeProfessionalGray: '3. Professional Gray (Zinc Monochrome)',
    themeEnterpriseGreen: '4. Enterprise Green (Sustainable Emerald)',
    themeFintechPurple: '5. Fintech Purple (Indigo & Violet Banking)',
    themeStartupOrange: '6. Startup Orange (Dynamic Amber & Tangerine)',
    themeMaterialDesign: '7. Material Design (Standard Elevation & Indigo)',
    themeGlassmorphism: '8. Glassmorphism (Frosted Acrylic Translucent)',
    themeMinimalist: '9. Minimalist (Border-First High Whitespace)',
    themeCustomBuilder: '10. Custom Theme Builder (Live Palette Tuner)',
  },
  ja: {
    // Common
    search: 'クイック検索 (名前、コード、メール、電話番号)...',
    filter: '高度なフィルター',
    create: '新規作成',
    edit: '編集',
    delete: '削除',
    cancel: 'キャンセル',
    save: '保存',
    export: 'Excel/CSVエクスポート',
    import: 'ファイルからインポート',
    actions: '操作',
    status: 'ステータス',
    viewDetails: '詳細を見る',
    close: '閉じる',
    refresh: '更新',
    all: 'すべて',
    confirmDelete: 'このレコードを削除してもよろしいですか？この操作はセキュリティ監査ログに記録されます。',
    yes: 'はい',
    no: 'いいえ',
    success: '処理が成功しました',
    error: 'エラーが発生しました',
    loading: 'データを読み込み中...',
    noData: 'データがありません',
    totalRecords: '総件数',
    page: 'ページ',
    rowsPerPage: '表示件数/ページ',
    inspectSpec: '画面仕様 (Spec)',

    // Navigation & Modules
    dashboard: 'ダッシュボード',
    okr: 'OKR・目標管理',
    leads: '見込み顧客管理',
    contacts: '連絡先一覧',
    opportunities: '商談・案件管理',
    quotations: '見積書・提案管理',
    contracts: '契約管理',
    customerCare: 'カスタマーサポート',
    inventory: '在庫・製品管理',
    reports: 'レポート・分析',
    settings: 'システム設定',
    specifications: 'システム設計書',

    // Roles
    superAdmin: 'スーパー管理者 (Super Admin)',
    tenantAdmin: 'テナント管理者 (Tenant Admin)',
    salesManager: '営業部長 (Sales Manager)',
    salesStaff: '営業担当 (Sales Staff)',
    customerCareStaff: 'CSサポート担当',
    warehouseStaff: '倉庫・物流担当',

    // Header
    switchTenant: '企業切り替え (Tenant)',
    switchRole: '役割切り替え (Role)',
    switchLanguage: '表示言語',
    switchTheme: 'テーマ・UIスタイル',
    notifications: '通知',
    markAllRead: 'すべて既読にする',
    profile: 'プロフィール',
    logout: 'ログアウト',
    systemArchitecture: 'システム構成・仕様',
    currentTenant: '現在の企業',
    activeRole: '現在の権限',

    // Dashboard
    totalRevenue: '総売上実績',
    pipelineValue: 'パイプライン総額',
    newLeadsMonth: '今月の新規リード',
    winRate: '成約率',
    revenueChartTitle: '四半期売上と予測',
    salesFunnelTitle: 'セールスファネル',
    recentDeals: '成約間近の商談',
    slaUrgentTickets: 'SLA緊急チケット',
    inventoryAlerts: '安全在庫警告商品',
    quickActions: 'クイックアクション',

    // Leads
    leadCode: 'リード番号',
    leadName: '氏名・代表者',
    company: '会社名',
    phone: '電話番号',
    email: 'メールアドレス',
    source: '獲得経路',
    leadScore: '見込みスコア',
    assignedStaff: '担当者',
    convertToOpportunity: '商談へ昇格',
    newLead: '新規リード作成',

    // Opportunities
    dealName: '案件・商談名',
    stage: '商談ステージ',
    dealValue: '想定金額',
    probability: '成約確度 (%)',
    expectedClose: '成約予定日',
    kanbanView: 'カンバン表示',
    tableView: 'リスト表示',

    // Quotations
    quoteCode: '見積番号',
    quoteTitle: '見積件名',
    customer: '提出先顧客',
    grandTotal: '合計金額 (税込)',
    validUntil: '有効期限',
    previewPdf: 'PDFプレビュー',
    approveQuote: '見積承認',
    rejectQuote: '見積却下',
    addItem: '品目追加',

    // Contracts
    contractCode: '契約番号',
    contractTitle: '契約件名',
    contractValue: '契約金額',
    startDate: '開始日',
    endDate: '満了日',
    paymentMilestones: '支払いスケジュール',

    // Customer Care
    ticketCode: 'チケット番号',
    channel: '受付チャネル',
    subject: '件名・問い合わせ内容',
    priority: '優先度',
    slaRemaining: 'SLA残り時間',
    csatScore: 'CSAT満足度',
    resolveTicket: 'チケット完了',

    // Inventory
    sku: 'SKUコード',
    productName: '商品名・機器名',
    category: 'カテゴリー',
    unit: '単位',
    sellingPrice: '定価・販売価格',
    stockHn: 'ハノイ倉庫',
    stockDn: 'ダナン倉庫',
    stockHcm: 'ホーチミン倉庫',
    totalStock: '総在庫数',
    stockTransactions: '入出庫履歴',
    stockIn: '入庫伝票作成',
    stockOut: '出庫伝票作成',

    // Settings
    tenantSettings: '企業・テナント設定',
    userManagement: 'ユーザー・社員管理',
    rolePermissions: 'ロール・権限マトリクス',
    notificationCenter: '通知センター設定',
    languageSettings: '多言語設定 (i18n)',
    themeSettings: 'テーマ・UI設定',
    activityLogs: '操作履歴ログ',
    auditLogs: 'セキュリティ監査ログ',

    // Theme Names
    themeCorporateBlue: '1. コーポレートブルー (Corporate Blue)',
    themeModernDark: '2. モダンダーク (Modern Dark)',
    themeProfessionalGray: '3. プロフェッショナルグレー',
    themeEnterpriseGreen: '4. エメラルドグリーン',
    themeFintechPurple: '5. フィンテックパープル',
    themeStartupOrange: '6. スタートアップオレンジ',
    themeMaterialDesign: '7. マテリアルデザイン',
    themeGlassmorphism: '8. グラスモーフィズム',
    themeMinimalist: '9. ミニマリスト',
    themeCustomBuilder: '10. カスタムテーマビルダー',
  },
};

export const MENU_TRANSLATIONS: Record<LanguageCode, Record<string, string>> = {
  vi: {
    dashboard: 'Dashboard',
    reports: 'Báo cáo',
    inventory: 'Quản lý kho',
    sales: 'Quản lý Sales',
    logistics: 'Quản lý Vận chuyển',
    accounting: 'Kế toán',
    technical: 'Kỹ thuật',
    hr: 'Quản lý nhân sự',
    settings: 'Cài đặt hệ thống',

    // Reports
    'report-group-sales': 'Sales',
    'sales-overview': 'Tổng quan Sales',
    'sales-revenue': 'Doanh thu',
    'sales-forecast': 'Dự báo doanh số',
    'sales-funnel': 'Phễu bán hàng',
    'sales-won': 'Deal thắng',
    'sales-lost': 'Deal thua',
    'sales-productivity': 'Hiệu suất nhân viên',
    'sales-leads': 'Quản lý & phân tích Lead',
    'reports-inventory': 'Kho',
    'reports-logistics': 'Vận chuyển',
    'reports-accounting': 'Kế toán',
    'reports-technical': 'Kỹ thuật',
    'reports-hr': 'Nhân sự',

    // Inventory
    'inventory-overview': 'Tổng quan tồn kho',
    'inventory-stock-in': 'Nhập kho',
    'inventory-stock-out': 'Xuất kho',
    'inventory-history': 'Lịch sử kho theo ngày',
    'inventory-expiry': 'Hàng sắp hết hạn',

    // Sales
    leads: 'Lead',
    customers: 'Khách hàng',
    opportunities: 'Cơ hội bán hàng',
    quotations: 'Báo giá',
    'sales-orders': 'Đơn hàng & Phê duyệt',
    contracts: 'Hợp đồng',
    'sales-invoices': 'Hóa đơn',
    'sales-receipts': 'Phiếu thu',
    'sales-activities': 'Hoạt động & Lịch hẹn',
    tasks: 'Công việc',
    calendar: 'Lịch làm việc',

    // Logistics
    'logistics-order-approval': 'Duyệt đơn hàng',
    'logistics-stock-out': 'Xuất kho vận chuyển',
    'logistics-delivery-notes': 'Phiếu giao hàng',
    'logistics-shipments': 'Chuyến hàng',
    'logistics-handover': 'Biên bản bàn giao',
    'logistics-cod-collections': 'Thu hộ tiền COD',
    'logistics-purchase-orders': 'Đơn mua hàng',
    'logistics-purchase-invoices': 'Hóa đơn mua hàng',
    'logistics-stock-in': 'Nhập kho mua hàng',
    'logistics-payment-requests': 'Đề nghị thanh toán',
    'logistics-stock-history': 'Lịch sử vận chuyển',
    'logistics-approaching-expiry': 'Hàng cận hạn',
    'logistics-document-expiry': 'Giấy tờ sắp hết hạn',

    // Accounting
    'accounting-debt': 'Công nợ',
    'accounting-invoices': 'Hóa đơn & Báo giá',
    'accounting-transactions': 'Giao dịch & Dòng tiền',
    'accounting-reports': 'Báo cáo tài chính',

    // Technical
    'technical-customers': 'Hồ sơ khách hàng',
    'technical-directory': 'Danh mục kỹ thuật',
    'technical-quotations': 'Báo giá kỹ thuật',
    'technical-contracts': 'Hợp đồng kỹ thuật',
    'technical-master-planning': 'Kế hoạch tổng thể',
    'technical-payment-requests': 'Đề nghị thanh toán KT',
    'technical-warranty-stock-out': 'Xuất kho bảo hành',
    'technical-expiring-contracts': 'Hợp đồng sắp hết hạn',

    // HR
    'hr-staff': 'Nhân viên',
    'hr-insurance': 'Bảo hiểm xã hội',
    'my-profile': 'Hồ sơ của tôi',

    // Settings
    'settings-users': 'Người dùng',
    'settings-permissions': 'Nhóm quyền',
    'settings-system': 'Cấu hình hệ thống',
    'settings-app': 'Cấu hình nghiệp vụ',
    'settings-dictionary': 'Từ điển giá trị',
    'settings-directories': 'Danh mục dữ liệu',
    'settings-sync-logs': 'Nhật ký đồng bộ',

    // Section headers
    'header-crm': '[CRM & Bán hàng]',
    'header-inventory-inout': '[Nhập / Xuất kho]',
    'header-inventory-history': '[Lịch sử kho]',
    'header-logistics-delivery': '[Xuất kho & Giao hàng]',
    'header-logistics-purchase': '[Mua hàng & Nhập kho]',
    'header-logistics-history': '[Lịch sử & Giấy tờ]',
    'header-settings-system': '[Hệ thống & Phân quyền]',
    'header-settings-data': '[Cấu hình & Dữ liệu]',
    'header-settings-monitoring': '[Giám sát]',
  },
  en: {
    dashboard: 'Dashboard',
    reports: 'Reports',
    inventory: 'Inventory',
    sales: 'Sales Management',
    logistics: 'Logistics',
    accounting: 'Accounting',
    technical: 'Technical',
    hr: 'Human Resources',
    settings: 'System Settings',

    // Reports
    'report-group-sales': 'Sales',
    'sales-overview': 'Sales Overview',
    'sales-revenue': 'Revenue',
    'sales-forecast': 'Sales Forecast',
    'sales-funnel': 'Sales Funnel',
    'sales-won': 'Won Deals',
    'sales-lost': 'Lost Deals',
    'sales-productivity': 'Staff Productivity',
    'sales-leads': 'Lead Analytics',
    'reports-inventory': 'Inventory',
    'reports-logistics': 'Logistics',
    'reports-accounting': 'Accounting',
    'reports-technical': 'Technical',
    'reports-hr': 'HR',

    // Inventory
    'inventory-overview': 'Inventory Overview',
    'inventory-stock-in': 'Stock In',
    'inventory-stock-out': 'Stock Out',
    'inventory-history': 'Daily Stock History',
    'inventory-expiry': 'Expiring Stock',

    // Sales
    leads: 'Leads',
    customers: 'Customers',
    opportunities: 'Opportunities',
    quotations: 'Quotations',
    'sales-orders': 'Orders & Approvals',
    contracts: 'Contracts',
    'sales-invoices': 'Invoices',
    'sales-receipts': 'Receipts',
    'sales-activities': 'Activities & Calendar',
    tasks: 'Tasks',
    calendar: 'Schedule',

    // Logistics
    'logistics-order-approval': 'Order Approval',
    'logistics-stock-out': 'Dispatch Stock-out',
    'logistics-delivery-notes': 'Delivery Notes',
    'logistics-shipments': 'Shipments',
    'logistics-handover': 'Handover Protocol',
    'logistics-cod-collections': 'COD Collections',
    'logistics-purchase-orders': 'Purchase Orders',
    'logistics-purchase-invoices': 'Purchase Invoices',
    'logistics-stock-in': 'Purchase Stock-in',
    'logistics-payment-requests': 'Payment Requests',
    'logistics-stock-history': 'Shipping Logs',
    'logistics-approaching-expiry': 'Near Expiry Goods',
    'logistics-document-expiry': 'Expiring Documents',

    // Accounting
    'accounting-debt': 'Debt & Receivables',
    'accounting-invoices': 'Invoices & Quotes',
    'accounting-transactions': 'Cashflow & Transactions',
    'accounting-reports': 'Financial Reports',

    // Technical
    'technical-customers': 'Customer Records',
    'technical-directory': 'Technical Catalogs',
    'technical-quotations': 'Technical Quotes',
    'technical-contracts': 'Technical Contracts',
    'technical-master-planning': 'Master Planning',
    'technical-payment-requests': 'Payment Requests',
    'technical-warranty-stock-out': 'Warranty Stock-out',
    'technical-expiring-contracts': 'Expiring Contracts',

    // HR
    'hr-staff': 'Staff Directory',
    'hr-insurance': 'Social Insurance',
    'my-profile': 'My Profile',

    // Settings
    'settings-users': 'Users & Staff',
    'settings-permissions': 'Roles & Permissions',
    'settings-system': 'System Configuration',
    'settings-app': 'Business Workflows',
    'settings-dictionary': 'Value Dictionary',
    'settings-directories': 'Data Directories',
    'settings-sync-logs': 'Sync Logs',

    // Section headers
    'header-crm': '[CRM & Sales]',
    'header-inventory-inout': '[Stock In / Out]',
    'header-inventory-history': '[Stock History]',
    'header-logistics-delivery': '[Shipping & Delivery]',
    'header-logistics-purchase': '[Purchasing & Inbound]',
    'header-logistics-history': '[History & Documents]',
    'header-settings-system': '[System & Permissions]',
    'header-settings-data': '[Configuration & Data]',
    'header-settings-monitoring': '[Monitoring]',
  },
  ja: {
    dashboard: 'ダッシュボード',
    reports: 'レポート',
    inventory: '在庫管理',
    sales: '営業管理',
    logistics: '物流・配送',
    accounting: '会計管理',
    technical: '技術管理',
    hr: '人事管理',
    settings: 'システム設定',

    // Reports
    'report-group-sales': '営業',
    'sales-overview': '営業概要',
    'sales-revenue': '売上高',
    'sales-forecast': '売上予測',
    'sales-funnel': 'セールスファネル',
    'sales-won': '成約商談',
    'sales-lost': '失注商談',
    'sales-productivity': '従業員生産性',
    'sales-leads': 'リード分析',
    'reports-inventory': '在庫',
    'reports-logistics': '配送',
    'reports-accounting': '会計',
    'reports-technical': '技術',
    'reports-hr': '人事',

    // Inventory
    'inventory-overview': '在庫概要',
    'inventory-stock-in': '入庫',
    'inventory-stock-out': '出庫',
    'inventory-history': '日別在庫履歴',
    'inventory-expiry': '賞味期限間近',

    // Sales
    leads: '見込み顧客',
    customers: '顧客一覧',
    opportunities: '商談案件',
    quotations: '見積書',
    'sales-orders': '受注・承認',
    contracts: '契約',
    'sales-invoices': '請求書',
    'sales-receipts': '領収書',
    'sales-activities': '活動・予定',
    tasks: 'タスク',
    calendar: 'スケジュール',

    // Logistics
    'logistics-order-approval': '注文承認',
    'logistics-stock-out': '配送出庫',
    'logistics-delivery-notes': '納品書',
    'logistics-shipments': '配送便',
    'logistics-handover': '引渡記録',
    'logistics-cod-collections': '代引回収',
    'logistics-purchase-orders': '発注書',
    'logistics-purchase-invoices': '仕入請求書',
    'logistics-stock-in': '仕入入庫',
    'logistics-payment-requests': '支払申請',
    'logistics-stock-history': '配送履歴',
    'logistics-approaching-expiry': '期限間近品',
    'logistics-document-expiry': '書類期限管理',

    // Accounting
    'accounting-debt': '売掛金・債権',
    'accounting-invoices': '請求書・見積書',
    'accounting-transactions': '資金移動・収支',
    'accounting-reports': '財務レポート',

    // Technical
    'technical-customers': '技術顧客カルテ',
    'technical-directory': '技術カタログ',
    'technical-quotations': '技術見積',
    'technical-contracts': '技術契約',
    'technical-master-planning': '総合計画',
    'technical-payment-requests': '技術支払申請',
    'technical-warranty-stock-out': '保証出庫',
    'technical-expiring-contracts': '満期間近契約',

    // HR
    'hr-staff': '社員一覧',
    'hr-insurance': '社会保険',
    'my-profile': 'マイプロフィール',

    // Settings
    'settings-users': 'ユーザー管理',
    'settings-permissions': '権限グループ',
    'settings-system': 'システム構成',
    'settings-app': '業務設定',
    'settings-dictionary': 'データ辞書',
    'settings-directories': 'マスタデータ',
    'settings-sync-logs': '同期ログ',

    // Section headers
    'header-crm': '[CRM・営業]',
    'header-inventory-inout': '[入庫・出庫]',
    'header-inventory-history': '[在庫履歴]',
    'header-logistics-delivery': '[出荷・配送]',
    'header-logistics-purchase': '[購買・仕入]',
    'header-logistics-history': '[履歴・書類]',
    'header-settings-system': '[システム・権限]',
    'header-settings-data': '[設定・マスタ]',
    'header-settings-monitoring': '[監視]',
  },
};

export function getMenuTitle(id: string, defaultLabel: string, lang: LanguageCode = 'vi'): string {
  return MENU_TRANSLATIONS[lang]?.[id] || MENU_TRANSLATIONS['vi']?.[id] || defaultLabel;
}

export function formatCurrencyShort(val: number, lang: LanguageCode = 'vi'): string {
  const abs = Math.abs(val);
  const sign = val < 0 ? '-' : '';
  if (lang === 'en') {
    if (abs >= 1_000_000_000) return `${sign}${(abs / 1_000_000_000).toFixed(2)} B`;
    if (abs >= 1_000_000) return `${sign}${(abs / 1_000_000).toLocaleString('en-US', { maximumFractionDigits: 1 })} M`;
    return `${sign}${abs.toLocaleString('en-US')}`;
  }
  if (lang === 'ja') {
    if (abs >= 1_000_000_000) return `${sign}${(abs / 1_000_000_000).toFixed(2)} 億`;
    if (abs >= 1_000_000) return `${sign}${(abs / 1_000_000).toLocaleString('ja-JP', { maximumFractionDigits: 1 })} 百万`;
    return `${sign}${abs.toLocaleString('ja-JP')}`;
  }
  // vi default
  if (abs >= 1_000_000_000) return `${sign}${(abs / 1_000_000_000).toFixed(2)} Tỷ`;
  if (abs >= 1_000_000) return `${sign}${(abs / 1_000_000).toLocaleString('vi-VN', { maximumFractionDigits: 1 })} Tr`;
  return `${sign}${abs.toLocaleString('vi-VN')} ₫`;
}

export const REPORT_TRANSLATIONS: Record<LanguageCode, Record<string, string>> = {
  vi: {
    // KPI Cards
    recognizedRevenue: 'Doanh thu ghi nhận (Won)',
    cashCollected: 'Doanh thu thực thu (Tiền mặt)',
    currentQuota: 'Chỉ tiêu Quota kỳ này',
    variance: 'Chênh lệch (Variance)',
    wonContractsExplain: 'Tổng giá trị hợp đồng đã chốt thành công và đủ điều kiện ghi nhận doanh số.',
    collectedExplainPrefix: 'Đã thu hồi',
    collectedExplainSuffix: 'trên tổng doanh thu ký kết thành công.',
    quotaExplainPrefix: 'Tỷ lệ hoàn thành kế hoạch đạt',
    quotaExplainSuffix: 'so với chỉ tiêu giao phó ban đầu.',
    varianceSurplus: 'Doanh số vượt chỉ tiêu kỳ vọng so với kế hoạch.',
    varianceDeficit: 'Khoảng thiếu hụt doanh số cần bù đắp so với chỉ tiêu Quota.',

    // Chart
    revenueTrendTitle: 'Diễn biến Doanh thu ghi nhận & Thực thu so với Mục tiêu qua các tháng',
    revenueTrendSubtitle: 'So sánh đường mục tiêu (Quota) và đối soát dòng tiền thu thực tế',
    legendRecognized: 'Doanh thu ghi nhận',
    legendCollected: 'Thực thu tiền mặt',
    legendQuota: 'Mục tiêu (Quota)',

    // Table
    multidimTableTitle: 'Bảng chi tiết Doanh thu đa chiều',
    multidimTableSubtitle: 'Chuyển đổi góc nhìn phân tích theo từng tiêu chí nghiệp vụ',
    groupBy: 'Nhóm theo:',
    team: 'Đội Sales',
    rep: 'Nhân viên',
    product: 'Sản phẩm',
    region: 'Khu vực',
    source: 'Nguồn Lead',
    customer: 'Khách hàng',

    // Table headers
    thEntity: 'Đối tượng phân tích',
    thQuota: 'Mục tiêu (Quota)',
    thRecognized: 'Doanh thu ghi nhận',
    thCollected: 'Doanh thu thực thu',
    thAttainment: '% Đạt',
    thVariance: 'Chênh lệch (VND)',
    totalSystem: 'TỔNG CỘNG HỆ THỐNG',

    // Filter Bar
    filterTitle: 'Bộ lọc báo cáo',
    filterCountSuffix: 'điều kiện',
    filterDefault: '(Mặc định)',
    roleViewActive: 'Quyền xem: Đang mở',
    roleViewBtn: 'Quyền xem dữ liệu',
    savedFilters: 'Bộ lọc đã lưu',
    saveFilter: 'Lưu bộ lọc',
    resetFilter: 'Đặt lại',
    exportExcel: 'Xuất Excel',
    printPdf: 'In / PDF',
    presetToday: 'Hôm nay',
    presetWeek: 'Tuần này',
    presetMonth: 'Tháng này (T10)',
    presetQuarter: 'Quý này (Q4)',
    presetYear: 'Năm nay (2026)',
    presetCustom: 'Tùy chọn ngày',
    selectSavedFilter: 'Bộ lọc đã lưu',

    // Units & labels
    teamLeader: 'Trưởng nhóm:',
    contractsCount: 'hợp đồng',
    wonDealsCount: 'deal thắng',
    membersCount: 'nhân sự',
    salesRevenueReportTitle: 'Báo cáo Doanh thu Sales',
  },
  en: {
    // KPI Cards
    recognizedRevenue: 'Recognized Revenue (Won)',
    cashCollected: 'Cash Collected (Actual)',
    currentQuota: 'Current Period Quota',
    variance: 'Variance vs Quota',
    wonContractsExplain: 'Total value of closed won contracts eligible for revenue recognition.',
    collectedExplainPrefix: 'Collected',
    collectedExplainSuffix: 'of total recognized closed contracts.',
    quotaExplainPrefix: 'Attainment rate reached',
    quotaExplainSuffix: 'against the initial quota target.',
    varianceSurplus: 'Revenue exceeded initial plan target.',
    varianceDeficit: 'Revenue gap required to meet the quota target.',

    // Chart
    revenueTrendTitle: 'Recognized Revenue & Cash Collected vs Quota Across Months',
    revenueTrendSubtitle: 'Compare monthly quota baseline against actual cash collections',
    legendRecognized: 'Recognized Revenue',
    legendCollected: 'Cash Collected',
    legendQuota: 'Target Quota',

    // Table
    multidimTableTitle: 'Multi-dimensional Revenue Breakdown',
    multidimTableSubtitle: 'Switch business perspectives across operational dimensions',
    groupBy: 'Group by:',
    team: 'Sales Team',
    rep: 'Sales Rep',
    product: 'Product',
    region: 'Region',
    source: 'Lead Source',
    customer: 'Customer',

    // Table headers
    thEntity: 'Dimension / Entity',
    thQuota: 'Target Quota',
    thRecognized: 'Recognized Rev',
    thCollected: 'Cash Collected',
    thAttainment: '% Attained',
    thVariance: 'Variance',
    totalSystem: 'TOTAL SYSTEM',

    // Filter Bar
    filterTitle: 'Report Filters',
    filterCountSuffix: 'active filters',
    filterDefault: '(Default)',
    roleViewActive: 'Role View: Active',
    roleViewBtn: 'Data Role View',
    savedFilters: 'Saved Filters',
    saveFilter: 'Save Filter',
    resetFilter: 'Reset',
    exportExcel: 'Export Excel',
    printPdf: 'Print / PDF',
    presetToday: 'Today',
    presetWeek: 'This Week',
    presetMonth: 'This Month (M10)',
    presetQuarter: 'This Quarter (Q4)',
    presetYear: 'This Year (2026)',
    presetCustom: 'Custom Dates',
    selectSavedFilter: 'Saved filters',

    // Units & labels
    teamLeader: 'Team Leader:',
    contractsCount: 'contracts',
    wonDealsCount: 'won deals',
    membersCount: 'members',
    salesRevenueReportTitle: 'Sales Revenue Report',
  },
  ja: {
    // KPI Cards
    recognizedRevenue: '確定売上高 (成約)',
    cashCollected: '回収実績 (現金)',
    currentQuota: '今期ノルマ目標',
    variance: '目標差異 (乖離)',
    wonContractsExplain: '成約完了し売上計上条件を満たした契約総額。',
    collectedExplainPrefix: '成約総額の',
    collectedExplainSuffix: 'を回収完了済み。',
    quotaExplainPrefix: '当初目標ノルマに対する達成率は',
    quotaExplainSuffix: 'です。',
    varianceSurplus: '売上高が目標ノルマを超過達成しました。',
    varianceDeficit: '目標ノルマ達成までに必要な不足額です。',

    // Chart
    revenueTrendTitle: '月別 確定売上・回収実績・ノルマ目標 推移',
    revenueTrendSubtitle: '目標ノルマラインと実際の回収キャッシュフローの対比分析',
    legendRecognized: '確定売上高',
    legendCollected: '回収実績 (現金)',
    legendQuota: '目標 (Quota)',

    // Table
    multidimTableTitle: '多次元 売上詳細分析テーブル',
    multidimTableSubtitle: '業務軸に応じた多角的な分析視点の切り替え',
    groupBy: 'グループ化:',
    team: '営業チーム',
    rep: '営業担当者',
    product: '製品・品目',
    region: '担当地域',
    source: 'リード獲得元',
    customer: '顧客企業',

    // Table headers
    thEntity: '分析対象・ディメンション',
    thQuota: '目標 (Quota)',
    thRecognized: '確定売上高',
    thCollected: '回収実績',
    thAttainment: '達成率',
    thVariance: '目標差異 (VND)',
    totalSystem: 'システム総合計',

    // Filter Bar
    filterTitle: 'レポートフィルター',
    filterCountSuffix: '件の絞り込み',
    filterDefault: '(デフォルト)',
    roleViewActive: '権限視点: 展開中',
    roleViewBtn: '閲覧権限別視点',
    savedFilters: '保存済み条件',
    saveFilter: '条件を保存',
    resetFilter: 'リセット',
    exportExcel: 'Excel出力',
    printPdf: '印刷・PDF',
    presetToday: '本日',
    presetWeek: '今週',
    presetMonth: '今月 (10月)',
    presetQuarter: '今四半期 (Q4)',
    presetYear: '今年度 (2026)',
    presetCustom: '日付指定',
    selectSavedFilter: '保存済みフィルター',

    // Units & labels
    teamLeader: 'リーダー:',
    contractsCount: '件の契約',
    wonDealsCount: '件成約',
    membersCount: '名',
    salesRevenueReportTitle: '売上高分析レポート',
  },
};

export function getReportText(key: string, lang: LanguageCode = 'vi'): string {
  return REPORT_TRANSLATIONS[lang]?.[key] || REPORT_TRANSLATIONS['vi']?.[key] || key;
}

export function translateEntityName(name: string, lang: LanguageCode = 'vi'): string {
  if (lang === 'vi') return name;

  const dictionary: Record<string, { en: string; ja: string }> = {
    // Teams
    'Đội Sales Miền Bắc': { en: 'Northern Sales Team', ja: '北部営業チーム' },
    'Đội Sales Miền Nam': { en: 'Southern Sales Team', ja: '南部営業チーム' },
    'Đội Enterprise B2B': { en: 'Enterprise B2B Team', ja: 'エンタープライズB2Bチーム' },
    'Đội SMB & Khách hàng số': { en: 'SMB & Digital Team', ja: 'SMB・デジタルチーム' },

    // Regions
    'Miền Bắc': { en: 'Northern Region', ja: '北部地域' },
    'Miền Trung': { en: 'Central Region', ja: '中部地域' },
    'Miền Nam': { en: 'Southern Region', ja: '南部地域' },
    'Khu vực Miền Bắc': { en: 'Northern Region', ja: '北部地域' },
    'Khu vực Miền Trung': { en: 'Central Region', ja: '中部地域' },
    'Khu vực Miền Nam': { en: 'Southern Region', ja: '南部地域' },

    // Products
    'Gói Enterprise CRM': { en: 'Enterprise CRM Suite', ja: 'エンタープライズCRM' },
    'Giải pháp ERP Cloud': { en: 'Cloud ERP Solution', ja: 'クラウドERP' },
    'Module Kho Vận WMS': { en: 'WMS Warehouse Module', ja: 'WMS倉庫管理モジュール' },
    'Dịch vụ Tích hợp API': { en: 'API Integration Service', ja: 'API連携インテグレーション' },
    'Cổng Portal B2B': { en: 'B2B Customer Portal', ja: 'B2B顧客ポータル' },
    'Gói Chăm sóc Khách hàng': { en: 'Customer Care Package', ja: 'カスタマーケアパック' },

    // Sources
    'Nguồn Facebook': { en: 'Facebook Source', ja: 'Facebook経由' },
    'Nguồn Zalo': { en: 'Zalo Source', ja: 'Zalo経由' },
    'Nguồn Website': { en: 'Website Source', ja: 'Webサイト経由' },
    'Nguồn Giới thiệu': { en: 'Referral Source', ja: '紹介経由' },
    'Nguồn Hotline': { en: 'Hotline Source', ja: '電話窓口経由' },
    'Nguồn Triển lãm': { en: 'Exhibition Source', ja: '展示会経由' },
    'Giới thiệu': { en: 'Referral', ja: '紹介' },
    'Triển lãm': { en: 'Exhibition', ja: '展示会' },
  };

  return dictionary[name]?.[lang] || name;
}

