/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import { FullAuditReport } from '../../services/multiTenantDataLayer';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Play,
  RotateCcw,
  X,
  Building2,
  Database,
  Lock,
} from 'lucide-react';

interface DataIsolationAuditModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const DataIsolationAuditModal: React.FC<DataIsolationAuditModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { runDataIsolationAudit, currentCompany } = useMultiTenant();
  const [report, setReport] = useState<FullAuditReport | null>(null);
  const [isRunning, setIsRunning] = useState(false);

  if (!isOpen) return null;

  const handleRunTest = () => {
    setIsRunning(true);
    setTimeout(() => {
      const res = runDataIsolationAudit();
      setReport(res);
      setIsRunning(false);
    }, 400);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full shadow-2xl p-6 space-y-4 text-xs animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Báo Cáo Kiểm Tra Cách Ly Dữ Liệu Đa Doanh Nghiệp (Multi-Tenant Audit)
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Xác minh tính độc lập tuyệt đối giữa Công ty A (demo) và Công ty B (cty-b)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Action Bar */}
        <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
          <div>
            <span className="font-bold text-slate-900 dark:text-white block">
              Kiểm thử bảo mật truy cập chéo (Cross-Tenant Penetration Test)
            </span>
            <span className="text-[11px] text-slate-500 dark:text-slate-400">
              Chạy 5 kịch bản rà quét: Bản ghi, Tìm kiếm toàn văn, Truy cập ID trực tiếp, Hồ sơ lương, Sổ nợ kế toán.
            </span>
          </div>
          <button
            type="button"
            onClick={handleRunTest}
            disabled={isRunning}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold flex items-center justify-center gap-1.5 shadow-sm shrink-0 transition-colors"
          >
            {isRunning ? (
              <>
                <RotateCcw className="w-3.5 h-3.5 animate-spin" />
                <span>Đang quét bảo mật...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>{report ? 'Chạy lại kiểm tra' : 'Bắt đầu kiểm tra ngay'}</span>
              </>
            )}
          </button>
        </div>

        {/* Results Container */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {report ? (
            <>
              {/* Overall Score */}
              <div
                className={`p-4 rounded-xl border flex items-center justify-between ${
                  report.overallStatus === 'PASSED'
                    ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                    : 'bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  {report.overallStatus === 'PASSED' ? (
                    <CheckCircle2 className="w-8 h-8 text-emerald-500 shrink-0" />
                  ) : (
                    <XCircle className="w-8 h-8 text-rose-500 shrink-0" />
                  )}
                  <div>
                    <h3 className="font-bold text-sm">
                      {report.overallStatus === 'PASSED'
                        ? 'XÁC THỰC CÁCH LY THÀNH CÔNG: 100% ĐẠT CHUẨN'
                        : 'PHÁT HIỆN CẢNH BÁO BẢO MẬT'}
                    </h3>
                    <p className="text-[11px] opacity-90 mt-0.5">
                      Thời điểm kiểm tra: {report.timestamp} • Đạt {report.passedTests}/{report.totalTests} tiêu chí
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-600 text-white shadow-2xs">
                    PASS
                  </span>
                </div>
              </div>

              {/* Individual Test Cases */}
              <div className="space-y-2">
                {report.results.map((res) => (
                  <div
                    key={res.testId}
                    className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-[10px] bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded text-slate-500">
                          {res.testId}
                        </span>
                        <span className="font-bold text-slate-900 dark:text-white">
                          {res.testName}
                        </span>
                      </div>
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                          res.status === 'PASSED'
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                            : 'bg-rose-100 text-rose-700'
                        }`}
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        <span>ĐẠT ({res.latencyMs}ms)</span>
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-600 dark:text-slate-300">
                      {res.details}
                    </p>

                    <div className="flex items-center gap-3 text-[10px] text-slate-400 pt-1 border-t border-slate-100 dark:border-slate-800/60 font-mono">
                      <span>Phạm vi thử: {res.companyTested}</span>
                      <span>• Đối tượng quét: {res.targetCompanyQueried}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Compliance Notes */}
              <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 space-y-1">
                <span className="font-bold text-slate-700 dark:text-slate-300 block">
                  Nguyên tắc cách ly kỹ thuật:
                </span>
                <ul className="list-disc pl-4 space-y-0.5">
                  {report.complianceNotes.map((note, idx) => (
                    <li key={idx}>{note}</li>
                  ))}
                </ul>
              </div>
            </>
          ) : (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <Database className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-600 stroke-[1.5]" />
              <p>Chưa có dữ liệu kiểm thử. Vui lòng bấm "Bắt đầu kiểm tra ngay" ở trên.</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold"
          >
            Đóng Báo Cáo
          </button>
        </div>
      </div>
    </div>
  );
};
