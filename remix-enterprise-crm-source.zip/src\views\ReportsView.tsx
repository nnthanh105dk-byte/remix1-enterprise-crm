import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import {
  BarChart3,
  Download,
  Calendar,
  Award,
  TrendingUp,
  FileCode,
  PieChart,
  CheckCircle2,
  Printer,
} from 'lucide-react';

export const ReportsView: React.FC = () => {
  const {
    language,
    themeDef,
    openScreenSpec,
    t,
  } = useCRM();

  const isVi = language === 'vi';
  const [timeRange, setTimeRange] = useState<'month' | 'quarter' | 'year'>('quarter');
  const [showCategoryNote, setShowCategoryNote] = useState(false);
  const [showSlaNote, setShowSlaNote] = useState(false);

  const salesReps = [
    { name: 'Trần Minh Đức', title: 'Sales Manager', revenue: 2388000000, target: 2000000000, wonDeals: 6, avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&auto=format&fit=crop&q=80' },
    { name: 'Lê Hoàng Yến', title: 'Sales Staff', revenue: 1470000000, target: 1500000000, wonDeals: 4, avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&auto=format&fit=crop&q=80' },
    { name: 'Phạm Hải Đăng', title: 'Senior Rep', revenue: 980000000, target: 1000000000, wonDeals: 3, avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80' },
  ];

  const formatVND = (num: number) => {
    return (num / 1000000000).toFixed(2) + ' Tỷ ₫';
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
              {t.reports}
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300 font-mono font-bold">
              BI Analytics
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isVi
              ? 'Phân tích đa chiều doanh thu bán hàng, bảng xếp hạng nhân sự xuất sắc và tuân thủ SLA.'
              : 'Multi-dimensional executive reporting, sales rep leaderboards, and SLA compliance.'}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => openScreenSpec('SCR-REPORTS')}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium border border-slate-200 transition-colors whitespace-nowrap shrink-0"
          >
            <FileCode className="w-3.5 h-3.5 text-blue-600 shrink-0" />
            <span className="hidden md:inline">{isVi ? 'Đặc tả Màn hình I' : 'Spec Screen I'}</span>
            <span className="md:hidden">Spec I</span>
          </button>

          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg border border-[#E5E7EB] hover:bg-slate-50 text-xs font-medium text-slate-700 transition-colors whitespace-nowrap shrink-0"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span className="hidden sm:inline">In Báo cáo</span>
            <span className="sm:hidden">In</span>
          </button>
        </div>
      </div>

      {/* Time Range Filter Bar */}
      <div className="p-3 rounded-xl bg-white border border-[#E5E7EB] flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-[#3661C9] shrink-0" />
            <span className="text-xs font-semibold text-slate-800">
              {isVi ? 'Kỳ Báo Cáo:' : 'Window:'}
            </span>
          </div>
          <div className="flex items-center gap-1 p-0.5 rounded-lg bg-[#F7F9FC] border border-[#E5E7EB] text-[11px] sm:text-xs overflow-x-auto">
            <button
              onClick={() => setTimeRange('month')}
              className={`px-2 sm:px-3 py-1 rounded-md font-medium transition-all whitespace-nowrap shrink-0 ${
                timeRange === 'month' ? 'bg-white shadow-xs text-[#002659] font-bold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <span className="hidden sm:inline">Tháng này</span>
              <span className="sm:hidden">Tháng</span>
            </button>
            <button
              onClick={() => setTimeRange('quarter')}
              className={`px-2 sm:px-3 py-1 rounded-md font-medium transition-all whitespace-nowrap shrink-0 ${
                timeRange === 'quarter' ? 'bg-white shadow-xs text-[#002659] font-bold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <span className="hidden sm:inline">Quý 3/2026</span>
              <span className="sm:hidden">Quý 3</span>
            </button>
            <button
              onClick={() => setTimeRange('year')}
              className={`px-2 sm:px-3 py-1 rounded-md font-medium transition-all whitespace-nowrap shrink-0 ${
                timeRange === 'year' ? 'bg-white shadow-xs text-[#002659] font-bold' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <span className="hidden sm:inline">Cả năm 2026</span>
              <span className="sm:hidden">Năm 2026</span>
            </button>
          </div>
        </div>

        <div className="text-xs text-slate-500 font-mono">
          Thời gian tổng hợp: 01/07/2026 ➔ 30/09/2026
        </div>
      </div>

      {/* Sales Rep Leaderboard */}
      <div className="p-5 rounded-xl bg-white border border-[#E5E7EB] shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h3 className="section-title">
                {isVi ? 'Bảng Xếp hạng Doanh số Nhân sự (Sales Rep Leaderboard)' : 'Sales Rep Leaderboard'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Hiệu suất chốt hợp đồng và tỷ lệ hoàn thành KPI thực tế
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {salesReps.map((rep, idx) => {
            const pct = Math.round((rep.revenue / rep.target) * 100);
            return (
              <div
                key={idx}
                className="p-4 rounded-xl border border-slate-200/80 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="flex items-center gap-3">
                  <span className="w-7 h-7 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200 flex items-center justify-center font-bold text-xs font-mono">
                    #{idx + 1}
                  </span>
                  <img src={rep.avatar} alt={rep.name} className="w-10 h-10 rounded-full object-cover border" />
                  <div>
                    <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">{rep.name}</h4>
                    <p className="text-xs text-slate-400">{rep.title} • {rep.wonDeals} deals thành công</p>
                  </div>
                </div>

                <div className="flex-1 max-w-md">
                  <div className="flex justify-between text-xs mb-1.5 font-mono">
                    <span className="font-bold text-slate-800 dark:text-slate-200">{formatVND(rep.revenue)}</span>
                    <span className="text-slate-500">Mục tiêu: {formatVND(rep.target)} ({pct}%)</span>
                  </div>
                  <div className="w-full h-2.5 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        pct >= 100 ? 'bg-emerald-500' : pct >= 80 ? 'bg-blue-500' : 'bg-amber-500'
                      }`}
                      style={{ width: `${Math.min(100, pct)}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Grid: 2 Breakdown widgets */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Category Revenue Breakdown */}
        <div className={`p-6 rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow}`}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="section-title">
              Cơ cấu Doanh thu theo Ngành hàng
            </h3>
            <button
              type="button"
              onClick={() => setShowCategoryNote(!showCategoryNote)}
              className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold transition-all shadow-2xs cursor-pointer ${
                showCategoryNote
                  ? 'bg-[#002659] text-white ring-2 ring-sky-300 dark:ring-sky-700'
                  : 'bg-slate-100 hover:bg-sky-100 dark:bg-slate-800 dark:hover:bg-sky-950 text-slate-500 hover:text-sky-600 dark:text-slate-400'
              }`}
              title="Bấm để xem giải thích tỷ trọng ngành hàng"
            >
              !
            </button>
          </div>
          {showCategoryNote && (
            <p className="text-xs text-slate-500 mb-4 animate-in fade-in duration-150 pb-2 border-b border-slate-100 dark:border-slate-800">
              Tỷ trọng đóng góp giữa Phần mềm SaaS, Thiết bị và Dịch vụ tư vấn triển khai.
            </p>
          )}

          <div className="space-y-3">
            {[
              { label: 'Bản quyền Phần mềm CRM Cloud SaaS', pct: 54, val: '2.61 Tỷ ₫', color: 'bg-blue-600' },
              { label: 'Thiết bị Máy chủ & Gateway Appliance', pct: 28, val: '1.35 Tỷ ₫', color: 'bg-indigo-600' },
              { label: 'Dịch vụ Tư vấn Tích hợp Hệ thống', pct: 18, val: '0.87 Tỷ ₫', color: 'bg-emerald-600' },
            ].map((c, i) => (
              <div key={i} className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-medium text-slate-700 dark:text-slate-300">{c.label}</span>
                  <span className="font-mono font-bold">{c.val} ({c.pct}%)</span>
                </div>
                <div className="w-full h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div className={`h-full rounded-full ${c.color}`} style={{ width: `${c.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* SLA Ticket Resolution Quality */}
        <div className={`p-6 rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow}`}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="section-title">
              Chỉ số Tuân thủ Cam kết SLA Hỗ trợ
            </h3>
            <button
              type="button"
              onClick={() => setShowSlaNote(!showSlaNote)}
              className={`w-5 h-5 rounded-full flex items-center justify-center text-[11px] font-bold transition-all shadow-2xs cursor-pointer ${
                showSlaNote
                  ? 'bg-[#002659] text-white ring-2 ring-sky-300 dark:ring-sky-700'
                  : 'bg-slate-100 hover:bg-sky-100 dark:bg-slate-800 dark:hover:bg-sky-950 text-slate-500 hover:text-sky-600 dark:text-slate-400'
              }`}
              title="Bấm để xem chi tiết cam kết SLA"
            >
              !
            </button>
          </div>
          {showSlaNote && (
            <p className="text-xs text-slate-500 mb-4 animate-in fade-in duration-150 pb-2 border-b border-slate-100 dark:border-slate-800">
              Tỷ lệ xử lý sự cố kỹ thuật đúng hạn và điểm hài lòng CSAT từ khách hàng.
            </p>
          )}

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 text-center">
              <div className="text-2xl font-black font-mono text-emerald-600">96.4%</div>
              <div className="text-xs text-slate-600 dark:text-slate-300 font-medium mt-1">
                Đúng hạn SLA
              </div>
            </div>
            <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-center">
              <div className="text-2xl font-black font-mono text-amber-600">4.85 / 5.0</div>
              <div className="text-xs text-slate-600 dark:text-slate-300 font-medium mt-1">
                Điểm CSAT Trung bình
              </div>
            </div>
          </div>

          {showSlaNote && (
            <div className="mt-4 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 text-xs text-slate-500 border border-slate-200/80 dark:border-slate-800 animate-in fade-in duration-150">
              ✓ Tổng số 142 sự cố được tiếp nhận và đóng trong quý, thời gian phản hồi trung bình là 18 phút.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
