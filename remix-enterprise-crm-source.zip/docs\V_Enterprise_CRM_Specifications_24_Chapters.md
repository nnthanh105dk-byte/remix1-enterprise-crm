# TÀI LIỆU ĐẶC TẢ HỆ THỐNG A+ ENTERPRISE CRM SUITE (24 CHƯƠNG CHUẨN HÓA)
*Phiên bản: 3.4.2 Enterprise | Bản quyền: Tập đoàn Công nghệ số A+ | Kiến trúc Multi-Tenant Database Cô lập (Database-per-Tenant)*

---

## 1. 1. Sơ đồ Trang web (Sitemap)

Cây phân cấp cấu trúc điều hướng toàn diện cho nền tảng A+ Enterprise CRM đa doanh nghiệp với mô hình Quản trị Nền tảng (Platform Core) và Không gian Doanh nghiệp Độc lập (Tenant Workspaces).

### SƠ ĐỒ ĐIỀU HƯỚNG TỔNG THỂ (A+ ENTERPRISE CRM SITEMAP)
```text
/ (Root Authentication & Database Router)
│
├── /auth/login (Đăng nhập doanh nghiệp: Mã công ty + Email/Tên đăng nhập + Mật khẩu)
├── /auth/register (Đăng ký Doanh nghiệp mới -> Gửi yêu cầu PENDING tới Super Admin)
├── /auth/join-company (Nhân sự tìm mã doanh nghiệp & Gửi yêu cầu gia nhập)
├── /auth/accept-invite (Kích hoạt tài khoản nhân sự từ Link / Token lời mời)
├── /auth/select-workspace (Chọn Không gian Doanh nghiệp nếu tài khoản thuộc nhiều Tenant)
│
├── /platform (Bảng điều khiển Quản trị Nền tảng Toàn cầu - Super Admin Root)
│   ├── /tenants-registry (Quản trị danh mục Doanh nghiệp & Cấp phát Database)
│   ├── /pending-approvals (Phê duyệt yêu cầu Đăng ký Doanh nghiệp mới & Auto-provision DB)
│   ├── /system-architecture (Sơ đồ Kiến trúc CSDL CRM_CORE & Các DB Tenant độc lập)
│   └── /global-audit (Nhật ký An ninh & Giám sát Tải toàn hệ thống)
│
└── /app/:tenantId/* (Không gian Làm việc Doanh nghiệp Độc lập - VD: DB_APLUS)
    │
    ├── /dashboard (Executive Overview, KPI Cockpit & Phân tích Điều hành)
    │
    ├── /sales (Kinh doanh & Quản trị Bán hàng Toàn diện)
    │   ├── /leads (Khách hàng tiềm năng, Chấm điểm Lead Score, Chuyển đổi Cơ hội)
    │   ├── /customers (Danh bạ Khách hàng & Hồ sơ 360 độ)
    │   ├── /opportunities (Phễu Cơ hội Bán hàng: Kanban kéo thả 5 giai đoạn & Bảng Table)
    │   ├── /quotations (Báo giá thương mại, Bộ tính giá đa dòng, Chiết khấu & Duyệt cấp quản lý)
    │   ├── /contracts (Hợp đồng kinh tế, Quản lý mốc nghiệm thu & Cảnh báo gia hạn)
    │   ├── /activities (Lịch sử cuộc gọi, Nhật ký họp & Chăm sóc định kỳ)
    │   └── /tasks-calendar (Quản lý công việc & Lịch công tác kinh doanh)
    │
    ├── /technical (Khối Kỹ thuật & Dự án Triển khai - TP. Kỹ thuật)
    │   ├── /surveys (Khảo sát hiện trường & Đo đạc công trình)
    │   ├── /bom (Bóc tách Định mức Vật tư & Dự toán Thiết bị)
    │   └── /acceptance (Nghiệm thu Kỹ thuật & Bàn giao Dự án)
    │
    ├── /logistics (Vận hành Kho & Chuỗi Cung ứng)
    │   ├── /inventory (Danh mục Sản phẩm, SKU, Quản lý Tồn kho 3 Chi nhánh Bắc - Trung - Nam)
    │   ├── /stock-in-out (Phiếu Nhập - Xuất - Chuyển kho nội bộ)
    │   └── /delivery (Điều phối vận chuyển & Bàn giao thiết bị)
    │
    ├── /accounting (Tài chính - Kế toán & Dòng tiền)
    │   ├── /debt (Quản trị Công nợ Phải thu / Phải trả khách hàng)
    │   ├── /invoices (Xuất Hóa đơn Điện tử VAT & Đối soát Doanh thu)
    │   └── /cashflow (Sổ quỹ & Báo cáo Dòng tiền Thực thu - Thực chi)
    │
    ├── /hr (Nhân sự & Tổ chức Nội bộ)
    │   ├── /employees (Hồ sơ Nhân sự & Hợp đồng Lao động)
    │   └── /my-profile (Hồ sơ Cá nhân & Đổi mật khẩu)
    │
    ├── /reports (Báo cáo & Phân tích Đa chiều)
    │   ├── /sales-analytics (Doanh thu theo Phòng ban, Xếp hạng Sales Reps & Dự báo Doanh số)
    │   ├── /executive-pnl (Báo cáo P&L & Hiệu quả Dự án dành cho Ban Giám Đốc)
    │   └── /inventory-reports (Báo cáo Vòng quay Hàng tồn & Cảnh báo an toàn)
    │
    └── /settings (Cài đặt Hệ thống Doanh nghiệp - Company Admin)
        ├── /organization (Cơ cấu Tổ chức: Phòng ban, Chức vụ, Cấp bậc & Nhân sự)
        ├── /permissions (Ma trận Nhóm quyền RBAC & Phạm vi Phân quyền Scopes: OWN/TEAM/DEPT/COMPANY)
        ├── /invitations (Tạo Link Lời mời & Phê duyệt Yêu cầu Xin gia nhập)
        ├── /architecture (Sơ đồ Kết nối Database độc lập của Tenant)
        ├── /themes (Bộ máy Giao diện: 10 Templates Doanh nghiệp & Custom Theme Builder)
        └── /specs (Hồ sơ Đặc tả Kỹ thuật Hệ thống 24 Chương Chuẩn hóa)
```

---

## 2. 2. Kiến trúc Thông tin (Information Architecture)

Mô hình lưu trữ dữ liệu cô lập theo kiến trúc Database-per-Tenant, đảm bảo toàn vẹn dữ liệu và phân tách ranh giới doanh nghiệp tuyệt đối.

### MÔ HÌNH KIẾN TRÚC DỮ LIỆU A+ ENTERPRISE CRM
1. **Mức độ Cô lập Vật lý (Database-per-Tenant Isolation):**
   - **Control Database (`CRM_CORE`):** Quản lý định danh toàn cầu bao gồm Registry danh bạ Tenant, User Accounts toàn nền tảng, Memberships, Yêu cầu đăng ký công ty mới (`pending_registrations`) và Nhật ký an ninh hệ thống.
   - **Tenant Databases riêng biệt (`DB_APLUS`, `DB_ABC`, `DB_XYZ`,...):** Mỗi công ty sở hữu một CSDL vật lý độc lập chứa toàn bộ dữ liệu nghiệp vụ: Khách hàng, Báo giá, Hợp đồng, Kho bãi, Kế toán, Kỹ thuật, Lịch sử giao dịch. Tuyệt đối không lưu lẫn dữ liệu giữa các công ty.
2. **Dòng Luân chuyển Dữ liệu Nghiệp vụ (End-to-End Pipeline):**
   `Tiếp nhận Lead`
     ➔ Phân công Nhân viên Sales (`Scope: OWN`)
     ➔ Chuyển đổi thành `Contact` & `Khách hàng Doanh nghiệp`
     ➔ Khởi tạo `Opportunity (Cơ hội bán hàng)` qua Pipeline 5 bước
     ➔ Phòng Kỹ thuật khảo sát & bóc tách `BOM Vật tư` (nếu có dự án kỹ thuật)
     ➔ Phát hành `Quotation (Báo giá)` ➔ Trưởng phòng Sale duyệt chiết khấu
     ➔ Ký kết `Contract (Hợp đồng kinh tế)`
     ➔ Kế toán mở `Công nợ & Hóa đơn VAT`
     ➔ Kho vận xuất `Phiếu Xuất kho & Giao hàng`
     ➔ Kích hoạt `CSKH & Bảo hành định kỳ`.

---

## 3. 3. Hành trình Người dùng & Phân cấp Vai trò (User Journeys)

Quy trình trải nghiệm người dùng được cá nhân hóa chặt chẽ theo 5 vai trò hạt nhân và các vai trò mở rộng trong hệ thống A+ Enterprise CRM.

### HÀNH TRÌNH CÁC VAI TRÒ CHÍNH (5 TÀI KHOẢN MẪU THỰC TẾ)

1. **Super Admin Nền tảng (Nguyễn Khắc Huy - Quản trị Hạ tầng & Platform Root):**
   - **Phạm vi trách nhiệm:** Không trực tiếp thao tác vào dữ liệu kinh doanh của một công ty con, mà thực hiện quản trị hạ tầng toàn cầu.
   - **Hành trình:** Đăng nhập vào nền tảng ➔ Truy cập `/platform` ➔ Tiếp nhận các yêu cầu đăng ký doanh nghiệp mới đang chờ duyệt ➔ Thẩm định thông tin pháp lý & mã công ty (VD: APLUS) ➔ Bấm Duyệt đăng ký ➔ Hệ thống tự động kích hoạt tiến trình Provisioning (Tạo Database `DB_APLUS`, Migrate Schema v3.4.2, Cấp tài khoản Company Admin) ➔ Giám sát dung lượng lưu trữ, hiệu năng và kiểm tra Audit Log an ninh toàn hệ sinh thái.

2. **Admin Doanh nghiệp / Tenant Admin (Nguyễn Nhật Thanh - Toàn quyền Quản trị Công ty):**
   - **Phạm vi trách nhiệm:** Toàn quyền cấu hình, vận hành và phân quyền cho toàn bộ nhân sự trong Tenant được phân công (`tenant_aplus` - `DB_APLUS`).
   - **Hành trình:** Đăng nhập bằng mã công ty `APLUS` ➔ Thiết lập cơ cấu tổ chức (Tạo Phòng ban: Kinh doanh, Kỹ thuật, Kế toán, Kho; Tạo Chức vụ & Cấp bậc) ➔ Khởi tạo tài khoản nhân viên hoặc phát hành Link lời mời / Phê duyệt nhân sự xin gia nhập ➔ Gán vai trò RBAC và thiết lập Scope phạm vi dữ liệu (OWN, TEAM, DEPARTMENT, COMPANY) ➔ Cấu hình bộ nhận diện thương hiệu, giao diện và giám sát nhật ký người dùng.

3. **Ban Giám Đốc (Hồ Minh Châu - Giám đốc Điều hành / Board Director):**
   - **Phạm vi trách nhiệm:** Quyền xem toàn diện cấp Doanh nghiệp (`Scope: COMPANY`), tập trung vào số liệu điều hành, không tham gia cấu hình kỹ thuật.
   - **Hành trình:** Đăng nhập hệ thống ➔ Xem Executive Dashboard & KPI Cockpit thời gian thực (Tổng doanh thu, Biên lợi nhuận, Giá trị Pipeline, Tiến độ các hợp đồng lớn) ➔ Truy cập Báo cáo Điều hành P&L, Phễu chuyển đổi toàn công ty, Báo cáo tồn kho 3 miền và tình hình công nợ tài chính ➔ Ra quyết định chiến lược và chỉ đạo các Trưởng phòng.

4. **Trưởng Phòng Sale (Hồ Hoàng Long - Quản lý Kinh doanh / Sales Manager):**
   - **Phạm vi trách nhiệm:** Toàn quyền điều hành và quản trị dữ liệu của toàn bộ Phòng Kinh Doanh (`Scope: DEPARTMENT`).
   - **Hành trình:** Đăng nhập hệ thống ➔ Theo dõi Dashboard doanh số của phòng và tiến độ chỉ tiêu KPI của từng Sales Rep ➔ Tiếp nhận Leads mới từ Marketing và phân bổ cho nhân viên kinh doanh ➔ Phê duyệt các Báo giá có chiết khấu cao hoặc giá trị lớn (>500 triệu VNĐ) ➔ Giám sát Pipeline cơ hội bán hàng, thúc đẩy chốt hợp đồng và xem 8 báo cáo phân tích chuyên sâu của phòng Sale.

5. **Nhân Viên Sale (Nguyễn Văn A - Chuyên viên Kinh doanh / Sales Staff):**
   - **Phạm vi trách nhiệm:** Chỉ xem và thao tác trên tập dữ liệu Khách hàng, Leads, Deals được phân bổ trực tiếp cho cá nhân (`Scope: OWN`).
   - **Hành trình:** Đăng nhập hệ thống ➔ Xem Dashboard công việc cá nhân (Leads cần gọi hôm nay, Lịch hẹn khách hàng, Task cần xử lý) ➔ Khai thác danh sách Lead được giao, thực hiện cuộc gọi, ghi chú tương tác ➔ Chuyển đổi Lead thành Cơ hội và kéo thẻ trên Kanban Pipeline ➔ Tạo Báo giá gửi Trưởng phòng duyệt ➔ Lập Hợp đồng khi khách hàng đồng ý ký kết và theo dõi hoa hồng doanh số cá nhân.

---

## 4. 4. Cấu trúc Điều hướng (Navigation Structure)

1. **Global Header:**
   - **Định danh Tenant & Database:** Hiển thị Tên công ty (`APLUS`), Mã định danh (`APLUS`), CSDL đang kết nối (`DB_APLUS - Sẵn sàng`).
   - **Huy hiệu Vai trò chuẩn hóa:** Hiển thị chức danh thực tế với màu sắc chuyên biệt (Super Admin: Tím Hoàng Gia, Admin: Xanh Dương Đậm, Ban Giám Đốc: Chàm Indigo, Trưởng Phòng Sale: Vàng Hổ Phách, Nhân Viên Sale: Xanh Cyan).
   - **Bộ chuyển đổi Workspace:** Cho phép người dùng chuyển đổi nhanh giữa các công ty nếu có nhiều Membership.
   - **Global Search (Omni-Search):** Tìm kiếm tức thì theo Mã khách hàng, Tên Deal, Số Báo giá, Mã Hợp đồng.
   - **Trung tâm Thông báo Đẩy:** Nhận cảnh báo Duyệt báo giá, Lead mới, Hạn hợp đồng, Vi phạm SLA.
2. **Breadcrumb Động:** Điều hướng ngữ cảnh phân cấp sâu `Trang chủ / Module / Phân khu / Chi tiết bản ghi`.
3. **Tab Panels Đa chế độ:** Hỗ trợ chuyển đổi nhanh (VD: Chuyển đổi Kanban Board / Bảng Table tại Cơ hội; 5 Tabs chi tiết hồ sơ nhân sự).

---

## 5. 5. Cấu trúc Menu Sidebar Phân quyền (Sidebar Structure)

Hệ thống Sidebar phân cấp 3 tầng với kiểm soát hiển thị nghiêm ngặt theo vai trò (Role-based menu filtering):

- **1. Tổng quan (Dashboard):** Hiển thị cho toàn bộ người dùng; nội dung widget tự động lọc theo vai trò và Scope.
- **2. Kinh doanh & Bán hàng (Sales Hub):**
  - Khách hàng tiềm năng (Leads)
  - Khách hàng (Customers)
  - Cơ hội bán hàng (Opportunities - Kanban & Table)
  - Báo giá & Đề xuất (Quotations)
  - Hợp đồng kinh tế (Contracts)
  - Hoạt động bán hàng & Lịch hẹn (Activities, Tasks, Calendar)
- **3. Khối Kỹ thuật (Technical Projects):** Dành cho TP. Kỹ thuật & Kỹ sư dự án (Khảo sát, Bóc tách BOM vật tư, Nghiệm thu).
- **4. Kho vận & Logistics:** Dành cho Thủ kho & Quản lý chuỗi cung ứng (Tồn kho 3 chi nhánh, Phiếu nhập xuất, Điều phối).
- **5. Tài chính - Kế toán (Accounting):** Dành cho Ban Giám Đốc & Kế toán (Công nợ, Hóa đơn VAT, Sổ quỹ, Báo cáo tài chính).
- **6. Nhân sự (HR):** Hồ sơ nhân sự toàn công ty và Hồ sơ cá nhân của nhân viên.
- **7. Báo cáo & Phân tích (Reports):** Báo cáo Doanh thu, Hiệu suất Sales, P&L Điều hành, Kho vận, Kỹ thuật.
- **8. Cài đặt Hệ thống (Settings):** Dành cho Company Admin (Quản trị nhân sự, Phân quyền RBAC & Scopes, Bộ nhận diện giao diện, Cấu hình doanh nghiệp).
- **9. Hồ sơ Đặc tả Kỹ thuật (Specifications):** Trung tâm tra cứu 24 chương đặc tả hệ thống và tài liệu kỹ thuật chuẩn A+.

---

## 6. 6. Thiết kế Thanh Đầu trang (Header Layout)

- **Chiều cao tiêu chuẩn:** `h-16 (64px)`, gắn cố định trên đỉnh trình duyệt (`sticky top-0 z-30`).
- **Giao diện Kính mờ (Backdrop Blur):** Tương thích 10 bộ Theme mẫu và hiệu ứng Glassmorphism.
- **Thông tin Định danh Tài khoản:** Hiển thị Avatar, Họ tên, Tên đăng nhập chuẩn hóa (`APLUS-SALE-0001`), và Huy hiệu vai trò nổi bật.

---

## 7. 7. Bố cục Màn hình Dashboard (Dashboard Layout)

Thiết kế lưới linh hoạt (Responsive Grid Cockpit) điều chỉnh theo vai trò truy cập:
1. **Hàng 1 (Chỉ số KPI Chiến lược):**
   - Doanh thu thực đạt & Tỷ lệ hoàn thành mục tiêu tháng.
   - Tổng giá trị Pipeline cơ hội đang theo đuổi.
   - Số lượng Khách hàng tiềm năng mới tiếp nhận.
   - Tỷ lệ chốt hợp đồng thành công (Win Rate %).
2. **Hàng 2 (Biểu đồ Đa chiều):**
   - Biểu đồ Doanh thu chuỗi thời gian so sánh kế hoạch.
   - Biểu đồ Phễu chuyển đổi Bán hàng Sales Funnel 5 tầng.
3. **Hàng 3 (Cảnh báo Hành động Nhanh):**
   - Danh sách Cơ hội giá trị cao cần chốt trong tuần.
   - Hợp đồng sắp đến hạn thanh toán / nghiệm thu.
   - Cảnh báo tồn kho an toàn & Đề xuất xuất nhập vật tư.

---

## 8. 8. Danh mục Tất cả Màn hình Chính (Screen Inventory)

- **Màn hình A:** Dashboard Tổng quan Điều hành Doanh nghiệp
- **Màn hình B:** Quản lý Khách hàng Tiềm năng (Leads Management)
- **Màn hình C:** Danh bạ Khách hàng & Hồ sơ 360 độ (Customers & Contacts)
- **Màn hình D:** Phễu Cơ hội Bán hàng (Opportunities Pipeline - Kanban & Table)
- **Màn hình E:** Quản lý Báo giá & Bộ tính giá đa dòng (Quotations Generator)
- **Màn hình F:** Quản lý Hợp đồng Kinh tế & Mốc Thanh toán (Contracts)
- **Màn hình G:** Quản lý Kỹ thuật, Khảo sát & Dự toán BOM (Technical Projects)
- **Màn hình H:** Quản lý Kho bãi & Chuỗi cung ứng 3 Miền (Inventory & Depots)
- **Màn hình I:** Báo cáo & Phân tích Đa chiều (BI Reports & P&L)
- **Màn hình J:** Quản trị Doanh nghiệp, Nhân sự & Phân quyền RBAC (Settings & Org)
- **Màn hình K:** Quản trị Nền tảng Toàn cầu dành cho Super Admin (Platform Admin & DB Provisioning)
- **Màn hình L:** Xác thực & Gia nhập Doanh nghiệp (Login, Register, Join Company, Accept Invite)

---

## 9. 9. Sơ đồ Luồng Chuyển tiếp Nghiệp vụ (Business Screen Flow)

```text
[Đăng ký Doanh nghiệp] ──(Gửi yêu cầu PENDING)──> [Super Admin Duyệt tại /platform]
                                                            │
                                             (Auto-provision DB_[CODE])
                                                            ▼
                                              [Company Admin Nhận quyền]
                                                            │
                                         ┌──────────────────┴──────────────────┐
                                         ▼                                     ▼
                                [Tạo cơ cấu & Phân quyền]             [Mời nhân sự qua Token/Link]
                                         │                                     │
                                         └──────────────────┬──────────────────┘
                                                            ▼
                                              [Nhân viên Đăng nhập theo Scope]
                                                            │
    ┌───────────────────────────────────────────────────────┴───────────────────────────────────────────┐
    ▼                                                                                                   ▼
[Leads Mới] ──(Chuyển đổi)──> [Opportunities Pipeline] ──(Tạo Báo giá)──> [Quotation Builder] ──(Duyệt)──> [Hợp đồng]
                                                                                                            │
                                                                   ┌────────────────────────────────────────┴────────┐
                                                                   ▼                                                 ▼
                                                          [Kho xuất thiết bị]                               [Kế toán xuất VAT]
```

---

## 10. 10. Ma trận Phân quyền & Phạm vi Dữ liệu Scopes (Permissions Matrix)

Hệ thống A+ Enterprise CRM áp dụng cơ chế kết hợp chặt chẽ giữa **Vai trò Nghiệp vụ (RBAC)** và **Phạm vi Tiếp cận Dữ liệu (Data Access Scope)**:

### 1. QUY CHUẨN 4 TẦNG PHẠM VI TIẾP CẬN DỮ LIỆU (DATA SCOPES)
- **OWN (Cá nhân):** Người dùng chỉ nhìn thấy và xử lý các bản ghi do chính mình tạo ra hoặc được phân bổ phụ trách trực tiếp.
- **TEAM (Đội nhóm):** Áp dụng cho Trưởng nhóm (Leader), nhìn thấy toàn bộ dữ liệu của các thành viên trong nhóm phụ trách.
- **DEPARTMENT (Phòng ban):** Áp dụng cho Trưởng phòng (Manager), toàn quyền giám sát và phê duyệt dữ liệu của toàn bộ phòng ban.
- **COMPANY (Doanh nghiệp):** Áp dụng cho Ban Giám Đốc và Admin, nhìn thấy toàn bộ dữ liệu của toàn bộ các phòng ban trong công ty.

### 2. BẢNG MA TRẬN PHÂN QUYỀN RBAC & SCOPE THEO VAI TRÒ HẠT NHÂN
| Phân hệ / Module | Super Admin (Nền tảng) | Company Admin (Công ty) | Ban Giám Đốc (Director) | Trưởng Phòng Sale (Sale Mgr) | Nhân Viên Sale (Sale Staff) | TP. Kỹ Thuật (Tech Mgr) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Phạm vi mặc định** | SYSTEM / ROOT | COMPANY | COMPANY | DEPARTMENT | OWN | DEPARTMENT |
| **Bảng điều khiển (Dashboard)** | Xem hạ tầng toàn cầu | Xem toàn công ty | Xem toàn công ty (KPI, P&L) | Xem phòng Kinh doanh | Xem chỉ tiêu cá nhân | Xem khối Kỹ thuật |
| **Khách hàng tiềm năng (Leads)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ | Full phòng Sales | Xem, Tạo, Sửa (Lead của mình) | - |
| **Khách hàng (Customers)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ | Full phòng Sales | Xem, Tạo, Sửa (Khách của mình) | Xem hồ sơ kỹ thuật |
| **Cơ hội (Opportunities)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ | Full phòng Sales | Xem, Tạo, Sửa (Deal của mình) | - |
| **Báo giá (Quotations)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ | Xem, Tạo, Sửa, Duyệt chiết khấu | Xem, Tạo, Sửa (Chờ duyệt) | Xem định mức giá |
| **Hợp đồng (Contracts)** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ, Duyệt | Xem, Tạo, Phê duyệt | Xem hợp đồng phụ trách | Xem điều khoản kỹ thuật |
| **Kỹ thuật & Dự toán BOM** | Giám sát Audit | Toàn quyền (Full) | Xem tiến độ dự án | Xem BOM liên quan | - | Toàn quyền (Khảo sát, BOM, NT) |
| **Kho vận (Inventory)** | Giám sát Audit | Toàn quyền (Full) | Xem tồn kho 3 miền | Xem danh mục sản phẩm | Xem tồn khả dụng | Xem vật tư kỹ thuật |
| **Kế toán & Công nợ** | Giám sát Audit | Toàn quyền (Full) | Xem toàn bộ dòng tiền | Xem công nợ khách của phòng | Xem công nợ khách của mình | - |
| **Cài đặt & Cơ cấu tổ chức** | Quản trị Nền tảng | Toàn quyền cấu hình | Xem cơ cấu | - | - | - |
| **Duyệt Đăng ký Doanh nghiệp** | Toàn quyền độc quyền | - | - | - | - | - |

---

## 11. 11. Quy trình Nghiệp vụ Chi tiết (Enterprise Workflows)

### 1. QUY TRÌNH ĐĂNG KÝ DOANH NGHIỆP VÀ CẤP PHÁT DATABASE (5 BƯỚC)
1. **Bước 1 - Chủ doanh nghiệp Đăng ký:** Truy cập màn hình Đăng ký Doanh nghiệp (`/auth/register`), điền đầy đủ Tên công ty, Mã công ty độc nhất (VD: `APLUS`), Mã số thuế, Thông tin tài khoản Admin và mật khẩu khởi tạo.
2. **Bước 2 - Thẩm định tại Quản trị Nền tảng:** Yêu cầu được lưu vào bảng `pending_registrations` ở trạng thái `PENDING`. Super Admin (`Nguyễn Khắc Huy`) nhận thông báo tại Bảng Điều Khiển Nền Tảng (`/platform`).
3. **Bước 3 - Phê duyệt & Kích hoạt Provisioning:** Super Admin thẩm định tính hợp lệ và nhấn "Phê duyệt Doanh nghiệp". Hệ thống khởi chạy chuỗi tác vụ tự động:
   - Tạo Database cô lập mới `DB_[MÃ_CÔNG_TY]`.
   - Chạy Schema Migration v3.4.2 Enterprise.
   - Cấp phát dung lượng lưu trữ phân vùng.
   - Khởi tạo tài khoản Quản trị viên Doanh nghiệp (`Company Admin`) cho người đăng ký.
4. **Bước 4 - Bàn giao Không gian Làm việc:** Trạng thái chuyển sang `APPROVED`, công ty xuất hiện trong danh mục Tenants chính thức với Database trạng thái `READY`.
5. **Bước 5 - Thiết lập Tổ chức:** Company Admin đăng nhập lần đầu, cấu hình thông tin doanh nghiệp, cơ cấu phòng ban và bắt đầu thêm nhân viên.

### 2. QUY TRÌNH KINH DOANH KHÉP KÍN (COMMERCE PIPELINE)
1. **Tiếp nhận & Nuôi dưỡng Lead:** Tiếp nhận tự động từ Website, Hotline, Zalo OA hoặc triển lãm. Hệ thống tính điểm tiềm năng (Lead Score 0-100) và gán cho Nhân viên Sale theo vòng tròn luân phiên (Round-robin) hoặc chỉ định thủ công.
2. **Đánh giá Tiềm năng & Chuyển đổi:** Nhân viên Sale gọi điện tư vấn. Khi xác định khách hàng có nhu cầu mua hàng thực tế, nhấn nút "Chuyển đổi thành Cơ hội" để tự động sinh hồ sơ Khách hàng và thẻ Deal trên Kanban Pipeline.
3. **Phối hợp Kỹ thuật (Đối với Hàng kỹ thuật / Dự án):** Nhân viên Sale yêu cầu hỗ trợ kỹ thuật -> Trưởng phòng Kỹ thuật cử kỹ sư đi khảo sát hiện trường và lập bảng bóc tách định mức vật tư `BOM`.
4. **Tạo Báo giá & Phê duyệt:** Nhân viên Sale lập Báo giá đa dòng, áp dụng bảng giá niêm yết từ Kho. Nếu có mức chiết khấu vượt thẩm quyền (>10%), hệ thống tự động gửi yêu cầu phê duyệt tới Trưởng phòng Sale.
5. **Ký Hợp đồng & Triển khai:** Khách hàng đồng ý báo giá -> Tự động chuyển đổi thành Hợp đồng kinh tế -> Phân kỳ các đợt thanh toán và giao dịch viên kho xuất hàng.

---

## 12. 12. Thao tác Dữ liệu CRUD & Tính Toàn vẹn Dữ liệu (CRUD Operations)

- **Mã Định danh Chuẩn hóa:** Hệ thống kết hợp giữa UUID hệ thống và Mã hiển thị thân thiện:
  - Khách hàng: `KH-APLUS-0012`
  - Khách tiềm năng: `LEAD-2026-0891`
  - Cơ hội bán hàng: `OPP-2026-0412`
  - Báo giá thương mại: `BG-2026-0158`
  - Hợp đồng kinh tế: `HD-2026-0092`
  - Nhân viên: `APLUS-SALE-0001`
- **Soft Delete & Khôi phục An toàn:** Dữ liệu kinh doanh nhạy cảm (Hợp đồng, Báo giá đã duyệt, Khách hàng) áp dụng cơ chế Soft-delete (đánh dấu cờ `isDeleted: true`), chỉ Super Admin và Company Admin mới có quyền truy xuất thùng rác hoặc xóa vĩnh viễn.
- **Audit Logging Tự động:** Mọi hành vi tạo mới, cập nhật giá trị nhạy cảm (thay đổi giá bán, chiết khấu, phân quyền) đều được ghi nhật ký kiểm toán với IP, Timestamp và Người thực hiện.

---

## 13. 13. Quy tắc Xác thực Dữ liệu (Validation Rules)

- **Mã Công ty (Company Code):** Chữ in hoa không dấu, độ dài từ 3 đến 10 ký tự, không chứa ký tự đặc biệt (VD: `APLUS`, `ABC`, `VINFAST`), là duy nhất trên toàn nền tảng.
- **Số điện thoại Việt Nam:** Đúng 10 chữ số, bắt đầu bằng các đầu số chuẩn: `^(0[3|5|7|8|9])+([0-9]{8})$`.
- **Mã số thuế Doanh nghiệp (Tax Code):** Chuẩn 10 số (Doanh nghiệp độc lập) hoặc 13 số có dấu gạch ngang (Chi nhánh trực thuộc).
- **Định dạng Tiền tệ:** Không âm, có bộ định dạng phân cách hàng nghìn rõ ràng (`VNĐ` hoặc `USD`).
- **Phân kỳ Hợp đồng:** Tổng giá trị các đợt thanh toán phải khớp chính xác 100% với Tổng giá trị Hợp đồng sau thuế.

---

## 14. 14. Xử lý Lỗi & Thông báo Hệ thống (Error Handling)

- **401 Unauthorized:** Tự động điều hướng về màn hình Đăng nhập doanh nghiệp khi phiên làm việc hết hạn.
- **403 Forbidden:** Hiển thị thông báo giới hạn quyền hạn thân thiện: *"Tài khoản của bạn với vai trò hiện tại không thuộc phạm vi (Scope) được phép chỉnh sửa dữ liệu này. Vui lòng liên hệ Quản trị viên Doanh nghiệp."*
- **409 Conflict:** Thông báo lỗi trùng lặp khi cố gắng đăng ký mã công ty, số điện thoại hoặc mã hợp đồng đã tồn tại trong cùng CSDL Tenant.
- **Hệ thống Toast Thông báo:** Bốn trạng thái trực quan: Success (Xanh lá), Error (Đỏ san hô), Warning (Vàng hổ phách), Info (Xanh công nghệ).

---

## 15. 15. Thư viện Thành phần Giao diện Chuẩn (UI Components)

- **Typography:** Phông chữ chính `Plus Jakarta Sans`, các số liệu tài chính, mã định danh và SKU sử dụng `JetBrains Mono`.
- **Hệ thống Nút bấm (Button Standards):** Phân cấp trực quan rõ ràng giữa Hành động chính (Primary - Gradient thương hiệu A+), Hành động phụ (Secondary/Outline), và Hành động nguy hiểm (Danger - Đỏ).
- **Huy hiệu Trạng thái (Status Badges):** Được thiết kế với độ tương phản cao, viền mỏng tinh tế, hỗ trợ Dark Mode hoàn hảo.

---

## 16. 16. Thành phần Tái sử dụng (Reusable Components)

1. `<PageHeader title breadcrumb actionButtons />`: Thanh tiêu đề đồng nhất cho tất cả các màn hình.
2. `<StatCard label value trend icon />`: Thẻ chỉ số KPI đo lường tốc độ tăng trưởng.
3. `<EmptyState icon title description action />`: Giao diện tinh tế khi bảng dữ liệu trống.
4. `<ConfirmDialog isOpen title message confirmText cancelText onConfirm onCancel />`: Hộp thoại xác nhận an toàn trước các thao tác nhạy cảm.
5. `<RoleBadge roleCode size />`: Huy hiệu vai trò tự động gán màu sắc chuẩn hóa A+.

---

## 17. 17. Thành phần Biểu mẫu (Form Components)

- Các trường bắt buộc đánh dấu hoa thị đỏ `*`.
- Hỗ trợ xem trước tài liệu và hình ảnh trực quan khi tải lên.
- Bộ chọn Ngày tháng (DatePicker) bản địa hóa theo định dạng ngày Việt Nam `DD/MM/YYYY`.
- Bộ tính toán Tiền tệ tự động cập nhật số tiền bằng chữ tiếng Việt (VD: *Một tỷ hai trăm triệu đồng chẵn*).

---

## 18. 18. Thành phần Bảng Dữ liệu Doanh nghiệp (Data Table Components)

- Hỗ trợ Sticky Header cố định khi cuộn danh sách dài.
- Bộ lọc Đa tiêu chí kết hợp (Lọc theo phòng ban, theo người phụ trách, theo trạng thái, theo khoảng thời gian).
- Tính năng Sắp xếp đa cột và Phân trang linh hoạt (10, 25, 50, 100 bản ghi/trang).
- Nút xuất dữ liệu ra định dạng Excel (.xlsx) và in mẫu biểu PDF chuyên nghiệp.

---

## 19. 19. Thành phần Hộp thoại & Trình trượt Drawer (Modal & Drawer)

- Lớp phủ nền mờ Acrylic Glassmorphism (`backdrop-blur-sm bg-black/40`).
- Trình trượt Slide-over Drawer xem nhanh hồ sơ 360 độ của Khách hàng hoặc Báo giá mà không cần rời khỏi màn hình danh sách.
- Hỗ trợ đóng nhanh qua phím `ESC` và tự động khóa cuộn trang nền.

---

## 20. 20. Thư viện Widget Màn hình Tổng quan (Dashboard Widgets)

1. **Widget Doanh thu & Tăng trưởng:** So sánh doanh số lũy kế thực tế với chỉ tiêu kinh doanh theo từng tháng.
2. **Widget Phễu Bán hàng (Sales Funnel):** Đo lường tỷ lệ chuyển đổi qua 5 nấc: Leads (100%) ➔ Liên hệ (65%) ➔ Đề xuất Báo giá (42%) ➔ Đàm phán (28%) ➔ Ký hợp đồng (18%).
3. **Widget Hiệu suất Sales Reps:** Bảng xếp hạng thi đua doanh số các chuyên viên kinh doanh xuất sắc nhất.
4. **Widget Cảnh báo Tồn kho & Đơn hàng:** Đồng hồ giám sát các mã vật tư sắp chạm ngưỡng tối thiểu.

---

## 21. 21. Widget Báo cáo & Phân tích Đa chiều (Report Widgets)

- Báo cáo Cơ cấu Doanh thu theo Ngành nghề và Nhóm sản phẩm.
- Báo cáo Lợi nhuận gộp và Tỷ suất sinh lời theo từng Hợp đồng kinh tế.
- Báo cáo Tuân thủ Quy trình Kỹ thuật và Thời gian nghiệm thu công trình.

---

## 22. 22. Trung tâm Thông báo Tức thì (Notification Center)

- Chuông thông báo trên Header hiển thị số lượng tin chưa đọc màu đỏ nổi bật.
- Phân loại tab thông báo thông minh: Tất cả, Bán hàng & Báo giá, Cảnh báo Hợp đồng, An ninh & Hệ thống.
- Hỗ trợ đánh dấu đọc toàn bộ trong 1 cú nhấp và nhấp để mở trực tiếp màn hình nghiệp vụ liên quan.

---

## 23. 23. Bộ máy Giao diện & 10 Mẫu Doanh nghiệp (Theme Engine)

Hệ thống hỗ trợ 10 bộ giao diện chuẩn mực chuyển đổi tức thì cùng bộ tạo Theme cá nhân hóa:
1. **A+ Corporate Blue (Mặc định):** Xanh Navy công nghệ sang trọng, biểu trưng cho sự tin cậy và chuyên nghiệp của Tập đoàn A+.
2. **Modern Dark:** Nền đen OLED công nghệ cao, giảm mỏi mắt cho chuyên viên làm việc ban đêm.
3. **Professional Gray:** Tông xám trung tính tinh tế, tối ưu hóa sự tập trung vào dữ liệu và biểu đồ.
4. **Enterprise Green:** Xanh ngọc lục bảo và teal, phong cách tập đoàn phát triển bền vững.
5. **Fintech Purple:** Tím hoàng gia & Indigo, phong cách ngân hàng số & tài chính hiện đại.
6. **Startup Orange:** Cam ấm & Hổ phách năng động, dành cho các doanh nghiệp tăng trưởng nhanh.
7. **Material Design:** Chuẩn mực thiết kế phẳng với bo góc và bóng đổ mềm mại.
8. **Glassmorphism:** Hiệu ứng kính mờ Acrylic trong suốt cao cấp.
9. **Minimalist:** Thiết kế tối giản tinh gọn, chú trọng đường nét biên mỏng.
10. **Custom Theme Builder:** Cho phép Admin doanh nghiệp tự tùy chỉnh mã màu HEX chủ đạo, độ bo góc nút bấm, kiểu phông chữ phù hợp bộ nhận diện thương hiệu của riêng công ty mình.

---

## 24. 24. Bộ máy Đa ngôn ngữ & Bản địa hóa (Multi-Language Engine)

- **Ngôn ngữ mặc định:** Tiếng Việt (`vi`) với từ điển thuật ngữ chuẩn mực cho thị trường B2B Việt Nam.
- **Ngôn ngữ mở rộng:** Tiếng Anh (`en`), Tiếng Nhật (`ja`).
- **Định dạng chuẩn:**
  - Tiền tệ: `1.500.000.000 ₫` hoặc `$1,500,000`.
  - Ngày tháng: `DD/MM/YYYY` (Tiếng Việt) và `YYYY-MM-DD` (Quốc tế).
  - Thuế suất: Tích hợp đầy đủ các mức thuế GTGT hiện hành (0%, 5%, 8%, 10%).

---

# PHỤ LỤC: ĐẶC TẢ CHI TIẾT TỪNG MÀN HÌNH CHÍNH (SCREENS A - L)

### SCR-A: Dashboard Tổng quan Doanh nghiệp (Executive Cockpit)
- **Mục đích:** Cung cấp cái nhìn toàn cảnh về tình hình kinh doanh, doanh thu, cảnh báo khẩn cấp và hiệu suất vận hành theo thời gian thực. Tự động điều chỉnh dữ liệu hiển thị theo vai trò (Super Admin / Admin / Ban Giám Đốc / Trưởng Phòng Sale / Nhân Viên Sale).
- **Bố cục UI:** 4 thẻ KPI chiến lược đầu trang, 2 biểu đồ phân tích chuỗi thời gian giữa trang, 3 danh sách cảnh báo vận hành cuối trang.

### SCR-B: Quản lý Khách hàng Tiềm năng (Leads Management)
- **Mục đích:** Tiếp nhận, chấm điểm chất lượng (Lead Score), phân bổ người phụ trách và chuyển đổi thành Cơ hội bán hàng.
- **Bố cục UI:** Thanh tìm kiếm và lọc nguồn gốc; Bảng danh sách Lead; Modal tạo mới/chỉnh sửa; Nút chuyển đổi nhanh thành Khách hàng & Cơ hội.

### SCR-C: Danh bạ Khách hàng (Customers & Contacts)
- **Mục đích:** Lưu trữ hồ sơ 360 độ của khách hàng, người liên hệ chính, lịch sử tương tác, danh sách hợp đồng đã ký và công nợ lũy kế.
- **Bố cục UI:** Bảng danh bạ chi tiết kèm bộ lọc phân loại (VIP, Thân thiết, Tiềm năng); Drawer xem nhanh hồ sơ toàn diện; Modal cập nhật thông tin.

### SCR-D: Phễu Cơ hội Bán hàng (Opportunities Pipeline)
- **Mục đích:** Trực quan hóa quy trình bán hàng qua 5 giai đoạn, tính toán xác suất thành công và dự báo doanh số chốt deal.
- **Bố cục UI:** Chuyển đổi linh hoạt giữa Kanban Board kéo thả 5 cột và Bảng dữ liệu Table; Modal khởi tạo Deal; Nút sinh nhanh Báo giá.

### SCR-E: Quản lý Báo giá (Quotations Generator)
- **Mục đích:** Tạo lập báo giá thương mại đa dòng, tính toán chiết khấu và thuế VAT tự động, gửi phê duyệt cấp quản lý và xuất bản in PDF chuyên nghiệp.
- **Bố cục UI:** Bảng theo dõi trạng thái báo giá (Bản nháp, Chờ duyệt, Đã duyệt, Đã gửi); Trình tạo báo giá tích hợp bộ chọn sản phẩm từ kho; Modal xem trước bản in PDF.

### SCR-F: Quản lý Hợp đồng Kinh tế (Contracts Management)
- **Mục đích:** Quản lý vòng đời hợp đồng, giá trị cam kết, các mốc thanh toán/nghiệm thu từng đợt và cảnh báo sắp đến ngày đáo hạn.
- **Bố cục UI:** Bảng danh sách hợp đồng kèm thanh tiến độ thanh toán %; Chi tiết phân kỳ thanh toán (Milestones); Modal lập hợp đồng.

### SCR-G: Khối Kỹ thuật & Dự án Triển khai (Technical Projects)
- **Mục đích:** Khảo sát hiện trường, bóc tách định mức vật tư BOM, lập dự toán thi công và tổ chức nghiệm thu kỹ thuật bàn giao cho khách hàng.
- **Bố cục UI:** Danh sách phiếu khảo sát; Bảng bóc tách định mức BOM vật tư liên kết với Kho; Biên bản nghiệm thu kỹ thuật.

### SCR-H: Quản lý Kho & Chuỗi Cung ứng (Inventory & Logistics)
- **Mục đích:** Quản lý danh mục sản phẩm, mã SKU, theo dõi số lượng tồn kho khả dụng tại 3 chi nhánh (Hà Nội, Đà Nẵng, TP.HCM) và lập phiếu xuất nhập kho.
- **Bố cục UI:** Thống kê tồn kho 3 miền; Danh mục sản phẩm kèm cảnh báo thiếu hàng; Lịch sử phiếu Nhập/Xuất kho; Modal lập phiếu kho.

### SCR-I: Báo cáo & Phân tích Đa chiều (BI Analytics)
- **Mục đích:** Cung cấp báo cáo phân tích chuyên sâu cho các cấp lãnh đạo: Doanh thu theo phòng ban, Hiệu suất Sales Reps, Báo cáo P&L điều hành, Vòng quay hàng tồn kho.
- **Bố cục UI:** Bộ chọn khoảng thời gian tùy biến; Nút xuất dữ liệu Excel; Biểu đồ trực quan và bảng số liệu so sánh cùng kỳ.

### SCR-J: Cài đặt Hệ thống & Cơ cấu Tổ chức (Settings & Org)
- **Mục đích:** Trung tâm quản trị doanh nghiệp dành cho Company Admin: Thiết lập Cơ cấu tổ chức (Phòng ban, Chức vụ, Cấp bậc), Quản lý tài khoản nhân viên, Ma trận phân quyền RBAC & Scopes (OWN, TEAM, DEPARTMENT, COMPANY), Bộ máy giao diện 10 mẫu và Nhật ký hoạt động.
- **Bố cục UI:** Thanh điều hướng các chuyên mục cấu hình; Bảng danh sách nhân viên kèm cấp bậc và vai trò; Modal phân quyền chi tiết 5 tab.

### SCR-K: Bảng Điều khiển Nền tảng Toàn cầu (Platform Admin - Super Admin)
- **Mục đích:** Dành riêng cho Super Admin (`Nguyễn Khắc Huy`) để quản trị toàn bộ hệ sinh thái: Phê duyệt yêu cầu Đăng ký Doanh nghiệp mới, Tự động cấp phát Database (`DB_[CODE]`), Giám sát hạ tầng máy chủ và Audit logs an ninh toàn cầu.
- **Bố cục UI:** Thống kê tổng số Database online; Bảng duyệt yêu cầu đăng ký chờ duyệt (Pending Requests); Quản lý danh mục Tenant; Sơ đồ kiến trúc CSDL.

### SCR-L: Xác thực & Gia nhập Doanh nghiệp (Authentication Suite)
- **Mục đích:** Bộ giao diện xác thực đồng bộ chuẩn thiết kế A+ (Logo A+ trong suốt, 3D Hero Showcase, Layout 2 cột hiện đại):
  - **Login:** Đăng nhập doanh nghiệp với Mã công ty, Tài khoản và Mật khẩu.
  - **Register:** Đăng ký thành lập doanh nghiệp mới gửi yêu cầu tới Super Admin.
  - **Join Company:** Nhân sự tìm mã doanh nghiệp để gửi yêu cầu xin gia nhập.
  - **Accept Invite:** Kích hoạt tài khoản nhân viên qua Link / Token lời mời được cấp.
  - **Select Workspace:** Bộ chọn không gian làm việc cho người dùng thuộc nhiều công ty.
