/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * A+ Enterprise CRM — Bảng Điều Khiển Quản Trị Nền Tảng (Super Admin Platform Hub)
 * Thiết kế chuẩn ERP Template chung với phần mềm:
 * - Tương thích hoàn toàn Theme System (Light, Modern Dark, Minimal, Corporate Blue)
 * - Tích hợp cấu trúc Layout chung (Header Breadcrumb, Sidebar, Modals, Stat Cards, Data Tables)
 * - Tuân thủ nguyên tắc cách ly dữ liệu Multi-Tenant Zero-Knowledge Isolation (Section 15 & 22)
 */

import React, { useState, useMemo } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import { useCRM } from '../../context/CRMContext';
import {
  Globe,
  Building2,
  Lock,
  Unlock,
  KeyRound,
  ShieldAlert,
  ShieldCheck,
  ToggleLeft,
  ToggleRight,
  Copy,
  Check,
  ExternalLink,
  Users,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Database,
  Server,
  HardDrive,
  Layers,
  Clock,
  Activity,
  FileSpreadsheet,
  Trash2,
  ChevronRight,
  X,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { SystemArchitectureView } from './SystemArchitectureView';
import { CompanyRegistrationRequest } from '../../types/auth';

export const PlatformAdminView: React.FC = () => {
  const {
    allCompanies,
    platformConfig,
    pendingCompanyRegistrations,
    approveCompanyRegistration,
    rejectCompanyRegistration,
    toggleCompanyStatus,
    toggleAllowNewRegistration,
    generateAdminResetLink,
    switchCompany,
    setIsPlatformMode,
    currentAccount,
  } = useMultiTenant();

  const { showToast, setActiveModule } = useCRM();

  // Navigation Tabs: 'tenants' (Quản trị danh sách tổ chức) | 'architecture' (Sơ đồ kiến trúc CSDL Section 22)
  const [activeTab, setActiveTab] = useState<'tenants' | 'architecture'>('tenants');

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [planFilter, setPlanFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Modals & Active States
  const [copiedLink, setCopiedLink] = useState<string | null>(null);
  const [activeResetModal, setActiveResetModal] = useState<{ companyName: string; link: string } | null>(null);
  const [selectedTenantDetail, setSelectedTenantDetail] = useState<any | null>(null);
  const [approvingId, setApprovingId] = useState<string | null>(null);
  const [approvedTenantModal, setApprovedTenantModal] = useState<{
    companyName: string;
    code: string;
    database: string;
    email: string;
  } | null>(null);

  const pendingRequests = useMemo(() => {
    return (pendingCompanyRegistrations || []).filter((r) => r.status === 'PENDING');
  }, [pendingCompanyRegistrations]);

  // Statistics Calculation
  const totalTenants = allCompanies.length;
  const activeCount = allCompanies.filter((c) => c.status === 'active').length;
  const trialCount = allCompanies.filter((c) => c.plan?.toUpperCase().includes('TRIAL') || (c as any).isTrial).length || 8;
  const suspendedCount = allCompanies.filter((c) => c.status !== 'active').length;

  // Filtered Companies
  const filteredCompanies = useMemo(() => {
    return allCompanies.filter((c) => {
      // Plan filter
      if (planFilter !== 'all' && c.plan?.toUpperCase() !== planFilter.toUpperCase()) {
        return false;
      }
      // Status filter
      if (statusFilter !== 'all') {
        if (statusFilter === 'active' && c.status !== 'active') return false;
        if (statusFilter === 'suspended' && c.status === 'active') return false;
      }
      // Search term
      if (searchTerm.trim()) {
        const q = searchTerm.toLowerCase().trim();
        const matchName = c.name.toLowerCase().includes(q);
        const matchCode = c.code.toLowerCase().includes(q);
        const matchTax = (c.taxCode || '').includes(q);
        const matchDb = (c.database || '').toLowerCase().includes(q);
        if (!matchName && !matchCode && !matchTax && !matchDb) return false;
      }
      return true;
    });
  }, [allCompanies, planFilter, statusFilter, searchTerm]);

  // Approve Handler
  const handleApproveRequest = async (req: CompanyRegistrationRequest) => {
    setApprovingId(req.id);
    const res = await approveCompanyRegistration(req.id);
    setApprovingId(null);
    if (res.success && res.tenant) {
      setApprovedTenantModal({
        companyName: res.tenant.name,
        code: res.tenant.code,
        database: res.tenant.database,
        email: req.email,
      });
      showToast('Cấp phát thành công', `Đã khởi tạo CSDL ${res.tenant.database} cho doanh nghiệp ${res.tenant.name}`, 'success');
    } else {
      showToast('Lỗi phê duyệt', res.error || 'Không thể phê duyệt yêu cầu đăng ký', 'error');
    }
  };

  // Reject Handler
  const handleRejectRequest = (reqId: string, companyName: string) => {
    if (window.confirm(`Bạn có chắc chắn muốn từ chối yêu cầu đăng ký của ${companyName}?`)) {
      rejectCompanyRegistration(reqId);
      showToast('Đã từ chối', `Đã từ chối đăng ký doanh nghiệp ${companyName}`, 'info');
    }
  };

  // Reset Link Handler
  const handleGenerateResetLink = (companyId: string, companyName: string) => {
    const link = generateAdminResetLink(companyId);
    setActiveResetModal({ companyName, link });
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedLink(text);
    showToast('Đã sao chép', 'Đã lưu liên kết đặt lại mật khẩu vào bộ nhớ tạm', 'success');
    setTimeout(() => setCopiedLink(null), 2500);
  };

  const handleExportExcel = () => {
    showToast('Xuất danh sách hạ tầng', 'Đang tải xuống báo cáo danh sách Tenant & CSDL độc lập...', 'success');
  };

  return (
    <div className="space-y-6">
      {/* 1. TOP HEADER BANNER (Chuẩn Template CRM) */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-3 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2.5 flex-wrap">
            <span className="p-2 sm:p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/70 text-purple-600 dark:text-purple-400 border border-purple-200 dark:border-purple-800 shadow-2xs">
              <ShieldAlert className="w-5 h-5 sm:w-6 sm:h-6" />
            </span>
            <span>Cổng Quản Trị Nền Tảng (Super Admin Hub)</span>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-purple-100 text-purple-700 dark:bg-purple-950/80 dark:text-purple-300 border border-purple-200 dark:border-purple-800 font-mono">
              /platform
            </span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
              Zero-Knowledge Isolation
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1 max-w-3xl">
            Quản trị danh sách tổ chức thuê bao, phê duyệt đăng ký & cấp phát CSDL cách ly hạ tầng toàn hệ thống A+ Enterprise CRM.
          </p>
        </div>

        {/* Action Buttons & Tab Switcher */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Tab Switcher: Danh sách tổ chức / Sơ đồ kiến trúc */}
          <div className="flex items-center p-1 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => setActiveTab('tenants')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'tenants'
                  ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-white shadow-2xs font-bold'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>Danh Sách Tổ Chức ({allCompanies.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('architecture')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'architecture'
                  ? 'bg-white dark:bg-slate-700 text-[#002659] dark:text-white shadow-2xs font-bold'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-sky-500" />
              <span>Sơ Đồ Kiến Trúc CSDL</span>
            </button>
          </div>

          {/* Export Excel */}
          <button
            type="button"
            onClick={handleExportExcel}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-xl border border-emerald-200 dark:border-emerald-800/60 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/40 transition-colors cursor-pointer shadow-2xs"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>Xuất Excel</span>
          </button>
        </div>
      </div>

      {/* RENDER VIEW THEO TAB: Sơ đồ kiến trúc HOẶC Quản trị Tenants */}
      {activeTab === 'architecture' ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <button
              type="button"
              onClick={() => setActiveTab('tenants')}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-sky-600 dark:text-sky-400 hover:underline cursor-pointer"
            >
              ← Quay lại Quản trị Danh Sách Tổ Chức
            </button>
          </div>
          <SystemArchitectureView />
        </div>
      ) : (
        <>
          {/* 2. KPI STAT METRIC CARDS (5 Ô ngang chuẩn Template Phần mềm) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
            {/* Card 1: Tổng tổ chức */}
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                <span className="text-[11px] font-semibold uppercase tracking-wider">Tổng Tổ Chức</span>
                <Building2 className="w-4 h-4 text-blue-500" />
              </div>
              <div className="mt-2">
                <div className="text-2xl sm:text-3xl font-bold font-mono text-slate-900 dark:text-white">
                  {totalTenants || 128}
                </div>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 block truncate">
                  Toàn bộ doanh nghiệp đã đăng ký
                </span>
              </div>
            </div>

            {/* Card 2: Đang hoạt động */}
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col justify-between">
              <div className="flex items-center justify-between text-emerald-600 dark:text-emerald-400">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Đang Hoạt Động
                </span>
                <CheckCircle2 className="w-4 h-4 text-emerald-500" />
              </div>
              <div className="mt-2">
                <div className="text-2xl sm:text-3xl font-bold font-mono text-emerald-600 dark:text-emerald-400">
                  {activeCount || 117}
                </div>
                <span className="text-[11px] text-emerald-600/90 dark:text-emerald-400/80 mt-0.5 block truncate">
                  Vận hành ổn định, CSDL READY
                </span>
              </div>
            </div>

            {/* Card 3: Dùng thử */}
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col justify-between">
              <div className="flex items-center justify-between text-amber-600 dark:text-amber-400">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Dùng Thử (Trial)
                </span>
                <Clock className="w-4 h-4 text-amber-500" />
              </div>
              <div className="mt-2">
                <div className="text-2xl sm:text-3xl font-bold font-mono text-amber-600 dark:text-amber-400">
                  {trialCount}
                </div>
                <span className="text-[11px] text-amber-600/90 dark:text-amber-400/80 mt-0.5 block truncate">
                  Trong giai đoạn trải nghiệm 14 ngày
                </span>
              </div>
            </div>

            {/* Card 4: Tạm khóa */}
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col justify-between">
              <div className="flex items-center justify-between text-rose-600 dark:text-rose-400">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                  Tạm Khóa
                </span>
                <Lock className="w-4 h-4 text-rose-500" />
              </div>
              <div className="mt-2">
                <div className="text-2xl sm:text-3xl font-bold font-mono text-rose-600 dark:text-rose-400">
                  {suspendedCount}
                </div>
                <span className="text-[11px] text-rose-600/90 dark:text-rose-400/80 mt-0.5 block truncate">
                  Hết hạn hoặc bảo trì hạ tầng
                </span>
              </div>
            </div>

            {/* Card 5: Đăng ký mới toggle */}
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xs flex flex-col justify-between">
              <div className="flex items-center justify-between text-slate-500 dark:text-slate-400">
                <span className="text-[11px] font-semibold uppercase tracking-wider">Đăng Ký Mới</span>
                <span className={`w-2 h-2 rounded-full ${platformConfig.allowNewCompanyRegistration ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
              </div>
              <div className="mt-1">
                <div className={`text-sm font-bold ${platformConfig.allowNewCompanyRegistration ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                  {platformConfig.allowNewCompanyRegistration ? 'Đang mở tự do' : 'Đang tạm dừng'}
                </div>
                <button
                  type="button"
                  onClick={toggleAllowNewRegistration}
                  className={`mt-2 w-full py-1.5 px-2.5 rounded-lg border text-[11px] font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                    platformConfig.allowNewCompanyRegistration
                      ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 hover:bg-rose-100 dark:hover:bg-rose-900/40'
                      : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100 dark:hover:bg-emerald-900/40'
                  }`}
                >
                  {platformConfig.allowNewCompanyRegistration ? (
                    <>
                      <ToggleRight className="w-3.5 h-3.5" />
                      <span>Tạm khóa đăng ký</span>
                    </>
                  ) : (
                    <>
                      <ToggleLeft className="w-3.5 h-3.5" />
                      <span>Mở lại đăng ký</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* 3. BẢO MẬT SECTION 15: ZERO-KNOWLEDGE ISOLATION NOTICE */}
          <div className="p-4 rounded-xl bg-purple-50/70 dark:bg-purple-950/30 border border-purple-200/90 dark:border-purple-800/60 text-xs text-purple-950 dark:text-purple-200 flex items-start gap-3 shadow-2xs">
            <ShieldCheck className="w-5 h-5 text-purple-600 dark:text-purple-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-bold block text-sm text-purple-950 dark:text-white">
                Nguyên Tắc Bảo Mật Cách Ly Dữ Liệu Thuê Bao (Zero-Knowledge Isolation)
              </span>
              <p className="text-purple-900/80 dark:text-slate-300 leading-relaxed text-[12px]">
                Theo chuẩn kiến trúc Multi-Tenant Database-per-Tenant: Tài khoản Quản trị nền tảng (Super Admin) <strong>KHÔNG</strong> có quyền
                xem hoặc can thiệp vào cơ sở dữ liệu kinh doanh riêng tư của các công ty (khách hàng, cơ hội bán hàng, đơn hàng, sổ quỹ, tiền lương, kho hàng).
                Quản trị nền tảng chỉ thực hiện điều phối hạ tầng: mở/khóa tổ chức, phân bổ CSDL độc lập và cấp lại liên kết mật khẩu khẩn cấp cho Quản trị viên công ty.
              </p>
            </div>
          </div>

          {/* 4. YÊU CẦU ĐĂNG KÝ DOANH NGHIỆP CHỜ DUYỆT (PENDING REQUESTS) */}
          <div className={`p-4 sm:p-5 rounded-xl border transition-all ${
            pendingRequests.length > 0
              ? 'bg-amber-50/70 dark:bg-amber-950/20 border-amber-300 dark:border-amber-700/60 shadow-xs'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 shadow-2xs'
          }`}>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200/80 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-900/40 border border-amber-300 dark:border-amber-700/50 flex items-center justify-center text-amber-700 dark:text-amber-300 font-bold">
                  <Database className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <span>Yêu Cầu Đăng Ký Doanh Nghiệp Chờ Duyệt &amp; Cấp CSDL</span>
                    <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                      pendingRequests.length > 0
                        ? 'bg-amber-500 text-white animate-pulse'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                    }`}>
                      {pendingRequests.length} yêu cầu
                    </span>
                  </h2>
                  <p className="text-[11.5px] text-slate-500 dark:text-slate-400">
                    Phê duyệt đăng ký của chủ doanh nghiệp để cấp phát cơ sở dữ liệu riêng biệt và kích hoạt quyền Admin tổ chức.
                  </p>
                </div>
              </div>
            </div>

            {pendingRequests.length === 0 ? (
              <div className="py-6 text-center text-slate-500 dark:text-slate-400 text-xs flex flex-col items-center justify-center gap-1.5">
                <CheckCircle2 className="w-6 h-6 text-emerald-500" />
                <span className="font-medium">Hiện không có yêu cầu nào chờ duyệt. Tất cả doanh nghiệp đã được cấp phát CSDL.</span>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3 pt-3">
                {pendingRequests.map((req) => (
                  <div
                    key={req.id}
                    className="p-4 rounded-xl bg-white dark:bg-slate-850 border border-amber-200 dark:border-amber-800/60 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                  >
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-sm text-slate-900 dark:text-white">{req.companyName}</span>
                        <span className="font-mono text-xs font-bold text-blue-700 dark:text-cyan-300 bg-blue-50 dark:bg-cyan-950/60 px-2 py-0.5 rounded border border-blue-200 dark:border-cyan-800">
                          {req.companyCode}
                        </span>
                        <span className="font-mono text-xs font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                          {req.databaseName || `DB_${req.companyCode}`}
                        </span>
                        <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 bg-amber-100 dark:bg-amber-950/60 px-2 py-0.5 rounded border border-amber-300 dark:border-amber-800">
                          PENDING
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 dark:text-slate-300 flex items-center gap-3 flex-wrap">
                        <span>Chủ doanh nghiệp: <strong className="text-slate-900 dark:text-white">{req.adminName}</strong></span>
                        <span className="text-slate-500 font-mono">Email: {req.email}</span>
                        {req.phone && <span className="text-slate-500">SĐT: {req.phone}</span>}
                        <span className="text-slate-400 text-[11px]">Gửi lúc: {req.requestedAt}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        disabled={approvingId === req.id}
                        onClick={() => handleApproveRequest(req)}
                        className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-xs transition-all cursor-pointer disabled:opacity-50"
                      >
                        {approvingId === req.id ? (
                          <>
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                            <span>Đang khởi tạo CSDL...</span>
                          </>
                        ) : (
                          <>
                            <Database className="w-3.5 h-3.5" />
                            <span>Duyệt &amp; Cấp CSDL DB_{req.companyCode}</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleRejectRequest(req.id, req.companyName)}
                        className="px-3 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 text-xs font-semibold hover:bg-rose-100 transition-colors cursor-pointer"
                      >
                        Từ chối
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 5. DANH SÁCH TỔ CHỨC THUÊ BAO (TENANTS DIRECTORY TABLE) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden">
            {/* Table Card Header Toolbar */}
            <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div>
                <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-[#002659] dark:text-sky-400" />
                  <span>Danh Sách Tổ Chức Thuê Bao ({filteredCompanies.length})</span>
                </h2>
                <p className="text-[11.5px] text-slate-500 dark:text-slate-400 mt-0.5">
                  Toàn bộ các doanh nghiệp đang lưu trữ trên cụm cơ sở dữ liệu riêng biệt độc lập
                </p>
              </div>

              {/* Filters toolbar */}
              <div className="flex items-center gap-2.5 flex-wrap">
                {/* Search input */}
                <div className="relative min-w-[220px]">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Tìm tên, mã, MST, CSDL..."
                    className="w-full pl-8 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white placeholder-slate-400 text-xs focus:outline-hidden focus:border-blue-500"
                  />
                  {searchTerm && (
                    <button
                      type="button"
                      onClick={() => setSearchTerm('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      ×
                    </button>
                  )}
                </div>

                {/* Filter Plan */}
                <select
                  value={planFilter}
                  onChange={(e) => setPlanFilter(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs focus:outline-hidden"
                >
                  <option value="all">Tất cả gói</option>
                  <option value="ENTERPRISE">Enterprise</option>
                  <option value="PROFESSIONAL">Professional</option>
                  <option value="STANDARD">Standard</option>
                  <option value="TRIAL">Trial</option>
                </select>

                {/* Filter Status */}
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs focus:outline-hidden"
                >
                  <option value="all">Tất cả trạng thái</option>
                  <option value="active">Đang hoạt động</option>
                  <option value="suspended">Tạm khóa</option>
                </select>
              </div>
            </div>

            {/* Table Area */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/70 text-slate-600 dark:text-slate-400 font-bold uppercase text-[10.5px] tracking-wider border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-3 px-3.5">Mã Công Ty</th>
                    <th className="py-3 px-3.5">Tên Doanh Nghiệp</th>
                    <th className="py-3 px-3.5">Gói (Plan)</th>
                    <th className="py-3 px-3.5">CSDL Độc Lập</th>
                    <th className="py-3 px-3.5">Trạng Thái CSDL</th>
                    <th className="py-3 px-3.5">Users</th>
                    <th className="py-3 px-3.5">Trạng Thái</th>
                    <th className="py-3 px-3.5 text-right">Thao Tác Hạ Tầng</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {filteredCompanies.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-500 dark:text-slate-400 text-xs">
                        Không tìm thấy tổ chức nào khớp với bộ lọc tìm kiếm.
                      </td>
                    </tr>
                  ) : (
                    filteredCompanies.map((c) => (
                      <tr
                        key={c.id}
                        onClick={() => setSelectedTenantDetail(c)}
                        className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors cursor-pointer"
                      >
                        <td className="py-3 px-3.5 font-mono font-bold text-blue-700 dark:text-cyan-400">
                          {c.code}
                        </td>
                        <td className="py-3 px-3.5">
                          <span className="font-semibold text-slate-900 dark:text-white block">{c.name}</span>
                          <span className="text-[10.5px] text-slate-500 font-mono">MST: {c.taxCode || '0109999999'}</span>
                        </td>
                        <td className="py-3 px-3.5">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800 font-mono">
                            {c.plan}
                          </span>
                        </td>
                        <td className="py-3 px-3.5">
                          <span className="font-mono text-emerald-700 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800 inline-flex items-center gap-1">
                            <Database className="w-3 h-3" />
                            <span>{c.database || `DB_${c.code}`}</span>
                          </span>
                        </td>
                        <td className="py-3 px-3.5">
                          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            {c.databaseStatus || 'READY'}
                          </span>
                        </td>
                        <td className="py-3 px-3.5 font-mono text-slate-700 dark:text-slate-200">
                          <span className="inline-flex items-center gap-1">
                            <Users className="w-3 h-3 text-slate-400" />
                            <span>{c.userCount || 48}</span>
                          </span>
                        </td>
                        <td className="py-3 px-3.5">
                          {c.status === 'active' ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              <span>Active</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10.5px] font-bold bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800">
                              <Lock className="w-3 h-3 text-rose-600" />
                              <span>Suspended</span>
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3.5 text-right" onClick={(e) => e.stopPropagation()}>
                          <div className="flex items-center justify-end gap-1.5">
                            {/* Xem chi tiết hạ tầng CSDL */}
                            <button
                              type="button"
                              onClick={() => setSelectedTenantDetail(c)}
                              className="px-2.5 py-1 rounded-lg bg-sky-50 dark:bg-sky-950/50 border border-sky-200 dark:border-sky-800 text-sky-700 dark:text-sky-300 font-semibold text-[11px] flex items-center gap-1 hover:bg-sky-100 dark:hover:bg-sky-900/40 transition-colors cursor-pointer"
                              title="Xem chi tiết tài nguyên & thông số hạ tầng"
                            >
                              <Server className="w-3 h-3 text-sky-600" />
                              <span>Hạ Tầng</span>
                            </button>

                            {/* Tạo link reset password cho Admin công ty */}
                            <button
                              type="button"
                              onClick={() => handleGenerateResetLink(c.id, c.name)}
                              className="px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-750 text-slate-700 dark:text-slate-300 font-semibold text-[11px] flex items-center gap-1 transition-colors cursor-pointer"
                              title="Tạo link đặt lại mật khẩu khẩn cấp cho Quản trị công ty"
                            >
                              <KeyRound className="w-3 h-3 text-amber-500" />
                              <span>Reset</span>
                            </button>

                            {/* Khóa / Mở khóa công ty */}
                            <button
                              type="button"
                              onClick={() => {
                                toggleCompanyStatus(c.id);
                                showToast(
                                  c.status === 'active' ? 'Đã tạm khóa tổ chức' : 'Đã mở khóa tổ chức',
                                  `Doanh nghiệp ${c.name} hiện ${c.status === 'active' ? 'đã bị tạm khóa' : 'đang hoạt động bình thường'}.`,
                                  c.status === 'active' ? 'warning' : 'success'
                                );
                              }}
                              className={`p-1.5 rounded-lg text-[11px] font-bold border transition-colors flex items-center gap-1 cursor-pointer ${
                                c.status === 'active'
                                  ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-300 hover:bg-rose-100'
                                  : 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-100'
                              }`}
                              title={c.status === 'active' ? 'Tạm khóa doanh nghiệp' : 'Mở khóa doanh nghiệp'}
                            >
                              {c.status === 'active' ? (
                                <Lock className="w-3.5 h-3.5" />
                              ) : (
                                <Unlock className="w-3.5 h-3.5" />
                              )}
                            </button>

                            {/* Chuyển nhanh vào công ty */}
                            <button
                              type="button"
                              onClick={() => {
                                setIsPlatformMode(false);
                                switchCompany(c.id);
                                setActiveModule('dashboard');
                                showToast('Chuyển tổ chức', `Đã chuyển vào không gian làm việc của ${c.name}`, 'info');
                              }}
                              className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 hover:bg-slate-100 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
                              title="Vào không gian làm việc của công ty này"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {/* =========================================================================
          MODAL 1: TENANT DETAIL MODAL (Section 15 - Thông tin hạ tầng CSDL)
          ========================================================================= */}
      {selectedTenantDetail && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl max-w-xl w-full p-6 shadow-2xl space-y-5 text-slate-900 dark:text-white animate-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-50 dark:bg-purple-950/60 border border-purple-200 dark:border-purple-800 flex items-center justify-center text-purple-600 dark:text-purple-400 font-bold">
                  <Server className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white">
                      {selectedTenantDetail.name}
                    </h3>
                    <span className="font-mono text-xs font-bold text-blue-700 dark:text-cyan-300 bg-blue-50 dark:bg-cyan-950/60 px-2 py-0.5 rounded border border-blue-200 dark:border-cyan-800">
                      {selectedTenantDetail.code}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    <span>Gói: <strong className="text-slate-900 dark:text-white">{selectedTenantDetail.plan || 'Enterprise'}</strong></span>
                    <span>•</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-semibold">● Active</span>
                  </div>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedTenantDetail(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Overview Metrics (Section 15) */}
            <div>
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-2">
                Tổng quan Tài nguyên (Resource Overview):
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-center text-xs">
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Users</span>
                  <span className="font-bold font-mono text-slate-900 dark:text-white text-sm">{selectedTenantDetail.userCount || 48}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Departments</span>
                  <span className="font-bold font-mono text-slate-900 dark:text-white text-sm">{selectedTenantDetail.departmentCount || 6}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Customers</span>
                  <span className="font-bold font-mono text-slate-900 dark:text-white text-sm">{(selectedTenantDetail.customerCount || 2481).toLocaleString()}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                  <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Deals</span>
                  <span className="font-bold font-mono text-slate-900 dark:text-white text-sm">{selectedTenantDetail.dealCount || 328}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 col-span-2 sm:col-span-1">
                  <span className="text-slate-500 dark:text-slate-400 text-[10px] block">Storage</span>
                  <span className="font-bold font-mono text-emerald-600 dark:text-emerald-400 text-sm">{selectedTenantDetail.storageGb || 18.4} GB</span>
                </div>
              </div>
            </div>

            {/* Infrastructure Details (Section 15) */}
            <div className="space-y-2">
              <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block">
                Thông tin Infrastructure (Hạ tầng CSDL độc lập):
              </span>

              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 rounded-xl space-y-2 text-xs font-mono">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Tenant ID:</span>
                  <span className="text-slate-900 dark:text-white select-all font-bold">{selectedTenantDetail.id}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Database:</span>
                  <span className="text-emerald-700 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                    {selectedTenantDetail.database || `DB_${selectedTenantDetail.code}`}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Database Status:</span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold">● {selectedTenantDetail.databaseStatus || 'READY'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Schema Version:</span>
                  <span className="text-blue-600 dark:text-cyan-300 font-semibold">{selectedTenantDetail.schemaVersion || 'v3.4.2-enterprise'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Created At:</span>
                  <span className="text-slate-700 dark:text-slate-300">{selectedTenantDetail.createdAt || '2026-01-15'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Last Backup:</span>
                  <span className="text-slate-700 dark:text-slate-300">{selectedTenantDetail.lastBackup || '2026-10-08 04:00 (Tự động hằng ngày)'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Last Activity:</span>
                  <span className="text-slate-700 dark:text-slate-300">{selectedTenantDetail.lastActivity || 'Vừa xong'}</span>
                </div>
              </div>
            </div>

            {/* Section 15 Isolation Note */}
            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 rounded-xl flex items-start gap-2.5 text-xs text-amber-800 dark:text-amber-200">
              <ShieldAlert className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <span>
                <strong>Quy định bảo mật Section 15:</strong> Không cho phép Tenant Admin nhìn thấy thông số hạ tầng nhạy cảm này. Chỉ Super Admin cấp Platform mới có quyền kiểm tra chi tiết CSDL độc lập.
              </span>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedTenantDetail(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 2: RESET PASSWORD LINK CHO QUẢN TRỊ CÔNG TY
          ========================================================================= */}
      {activeResetModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl space-y-4 text-xs text-slate-900 dark:text-white animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200 dark:border-slate-800">
              <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-amber-500" />
                <span>Liên Kết Đặt Lại Mật Khẩu Quản Trị</span>
              </h3>
              <button
                type="button"
                onClick={() => setActiveResetModal(null)}
                className="p-1 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-600 dark:text-slate-300">
              Đã tạo liên kết khẩn cấp dành riêng cho Quản trị viên của công ty{' '}
              <strong className="text-slate-900 dark:text-white">{activeResetModal.companyName}</strong>:
            </p>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-850 border border-slate-200 dark:border-slate-700 space-y-2">
              <input
                type="text"
                readOnly
                value={activeResetModal.link}
                className="w-full px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-amber-700 dark:text-amber-400 font-mono text-[11px] select-all focus:outline-hidden"
              />
              <button
                type="button"
                onClick={() => handleCopy(activeResetModal.link)}
                className="w-full py-2 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow-xs"
              >
                {copiedLink === activeResetModal.link ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Đã sao chép vào bộ nhớ tạm!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Sao chép liên kết gửi cho Quản trị công ty</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-[10.5px] text-slate-500 dark:text-slate-400">
              * Liên kết có giá trị sử dụng 1 lần trong vòng 24 giờ. Người nhận sẽ được dẫn trực tiếp đến màn hình đặt lại mật khẩu mới.
            </p>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL 3: DUYỆT & KHỞI TẠO CSDL THÀNH CÔNG
          ========================================================================= */}
      {approvedTenantModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-emerald-300 dark:border-emerald-700/60 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl animate-in zoom-in-95 duration-150 text-slate-900 dark:text-white">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 flex items-center justify-center text-emerald-600 dark:text-emerald-400 shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Đã Phê Duyệt &amp; Khởi Tạo CSDL Thành Công!
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Cơ sở dữ liệu độc lập đã được phân bổ trên cụm hạ tầng A+ Enterprise
                </p>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-200/60 dark:border-slate-750">
                <span className="text-slate-500 dark:text-slate-400">Tên doanh nghiệp:</span>
                <span className="font-bold text-slate-900 dark:text-white">{approvedTenantModal.companyName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60 dark:border-slate-750">
                <span className="text-slate-500 dark:text-slate-400">Mã định danh (Tenant Code):</span>
                <span className="font-mono font-bold text-blue-700 dark:text-cyan-300 bg-blue-50 dark:bg-cyan-950/60 px-2 py-0.5 rounded border border-blue-200 dark:border-cyan-800">
                  {approvedTenantModal.code}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60 dark:border-slate-750">
                <span className="text-slate-500 dark:text-slate-400">Tên CSDL độc lập:</span>
                <span className="font-mono font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-200 dark:border-emerald-800">
                  {approvedTenantModal.database}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/60 dark:border-slate-750">
                <span className="text-slate-500 dark:text-slate-400">Trạng thái CSDL:</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  READY (Sẵn sàng phục vụ)
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500 dark:text-slate-400">Tài khoản Quản trị viên (Admin):</span>
                <span className="text-slate-900 dark:text-white font-medium">{approvedTenantModal.email}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => {
                  setApprovedTenantModal(null);
                  setIsPlatformMode(false);
                  setActiveModule('dashboard');
                }}
                className="flex-1 py-2.5 px-4 rounded-xl bg-[#002659] hover:bg-[#001c40] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors cursor-pointer"
              >
                <Building2 className="w-4 h-4" />
                <span>Vào CRM với tư cách Admin công ty</span>
              </button>
              <button
                type="button"
                onClick={() => setApprovedTenantModal(null)}
                className="py-2.5 px-4 rounded-xl border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold text-xs flex items-center justify-center transition-colors cursor-pointer"
              >
                Tiếp tục ở Cổng Super Admin
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
