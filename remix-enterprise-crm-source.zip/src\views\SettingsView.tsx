import React, { useState } from 'react';
import { useCRM } from '../context/CRMContext';
import { User, UserRole, ActiveModule, PermissionAction, ThemePreset } from '../types/crm';
import { THEME_PRESETS } from '../theme/themeEngine';
import {
  Building2,
  Users,
  ShieldCheck,
  Languages,
  Palette,
  Clock,
  ShieldAlert,
  FileCode,
  Plus,
  Check,
  X,
  Trash2,
  Edit,
  Save,
  CheckCircle2,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    currentTenant,
    updateCurrentTenant,
    users,
    addUser,
    updateUserStatus,
    deleteUser,
    rolePermissions,
    updateRolePermission,
    currentRole,
    language,
    setLanguage,
    theme,
    setTheme,
    customTheme,
    setCustomTheme,
    themeDef,
    activityLogs,
    auditLogs,
    openScreenSpec,
    t,
  } = useCRM();

  const isVi = language === 'vi';
  const [activeSubTab, setActiveSubTab] = useState<
    'tenant' | 'users' | 'rbac' | 'language' | 'themes' | 'activity' | 'audit'
  >('tenant');

  // Tenant edit state
  const [tenantName, setTenantName] = useState(currentTenant.name);
  const [tenantTaxId, setTenantTaxId] = useState(currentTenant.taxId);
  const [tenantDomain, setTenantDomain] = useState(currentTenant.domain);
  const [tenantCurrency, setTenantCurrency] = useState(currentTenant.currency);

  // New user modal
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [newUserData, setNewUserData] = useState({
    fullName: '',
    email: '',
    phone: '',
    role: 'Sales Staff' as UserRole,
    department: 'Phòng Bán Hàng Dự Án',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&auto=format&fit=crop&q=80',
    status: 'active' as User['status'],
  });

  const modulesList: ActiveModule[] = [
    'dashboard',
    'leads',
    'contacts',
    'opportunities',
    'quotations',
    'contracts',
    'customer-care',
    'inventory',
    'reports',
    'settings',
  ];

  const actionsList: PermissionAction[] = ['view', 'create', 'edit', 'delete', 'export', 'approve'];

  const allRoles: UserRole[] = [
    'Super Admin',
    'Tenant Admin',
    'Sales Manager',
    'Sales Staff',
    'Customer Care Staff',
    'Warehouse Staff',
  ];

  const [selectedRbacRole, setSelectedRbacRole] = useState<UserRole>('Sales Staff');

  const handleSaveTenant = (e: React.FormEvent) => {
    e.preventDefault();
    updateCurrentTenant({
      name: tenantName,
      taxId: tenantTaxId,
      domain: tenantDomain,
      currency: tenantCurrency,
    });
  };

  const handleAddUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserData.fullName.trim() || !newUserData.email.trim()) return;
    addUser(newUserData);
    setIsAddUserOpen(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-slate-100 tracking-tight">
              {t.settings}
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300 font-mono font-bold">
              Admin Suite
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            {isVi
              ? 'Quản trị hồ sơ doanh nghiệp đa Tenant, tài khoản người dùng, ma trận RBAC, Theme Engine và Audit Log.'
              : 'Multi-tenant settings, user accounts, RBAC permission matrix, theme engine, and security audit logs.'}
          </p>
        </div>

        <button
          onClick={() => openScreenSpec('SCR-SETTINGS')}
          className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] sm:text-xs font-medium border border-slate-200 transition-colors shrink-0"
        >
          <FileCode className="w-3.5 h-3.5 text-blue-600 shrink-0" />
          <span className="hidden md:inline">{isVi ? 'Đặc tả Màn hình J' : 'Spec Screen J'}</span>
          <span className="md:hidden">Spec J</span>
        </button>
      </div>

      {/* 7 Sub-tabs bar */}
      <div className="flex gap-1.5 overflow-x-auto border-b border-[#E5E7EB] pb-2">
        {[
          { id: 'tenant', label: isVi ? 'Doanh nghiệp' : 'Tenant', fullLabel: isVi ? 'Doanh nghiệp (Tenant)' : 'Tenant Profile', icon: Building2 },
          { id: 'users', label: isVi ? 'Tài khoản' : 'Users', fullLabel: isVi ? 'Tài khoản (Users)' : 'User Directory', icon: Users },
          { id: 'rbac', label: isVi ? 'Phân quyền' : 'RBAC', fullLabel: isVi ? 'Ma trận Phân quyền (RBAC)' : 'RBAC Matrix', icon: ShieldCheck },
          { id: 'themes', label: isVi ? 'Giao diện' : 'Themes', fullLabel: isVi ? 'Bộ máy Theme (10 Mẫu)' : 'Theme Engine', icon: Palette },
          { id: 'language', label: isVi ? 'Ngôn ngữ' : 'Language', fullLabel: isVi ? 'Đa ngôn ngữ (i18n)' : 'Multi-Language', icon: Languages },
          { id: 'activity', label: isVi ? 'Hoạt động' : 'Activity', fullLabel: isVi ? 'Nhật ký Hoạt động' : 'Activity Logs', icon: Clock },
          { id: 'audit', label: isVi ? 'Audit' : 'Audit', fullLabel: isVi ? 'Nhật ký An ninh (Audit)' : 'Security Audit', icon: ShieldAlert },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-lg text-[11px] sm:text-xs font-medium whitespace-nowrap transition-colors shrink-0 ${
                isActive
                  ? 'bg-[#002659] text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">{tab.fullLabel}</span>
              <span className="sm:hidden">{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Subtab 1: Tenant Profile */}
      {activeSubTab === 'tenant' && (
        <div className="p-5 rounded-xl bg-white border border-[#E5E7EB] shadow-xs max-w-3xl">
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
            {isVi ? 'Hồ sơ Tổ chức Doanh nghiệp (Enterprise Tenant)' : 'Tenant Organization Settings'}
          </h3>
          <p className="text-xs text-slate-500 mb-6">
            Dữ liệu độc lập hoàn toàn với các tenant khác theo cơ chế cô lập an ninh Row-Level Security.
          </p>

          <form onSubmit={handleSaveTenant} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold mb-1">Tên Doanh nghiệp / Tập đoàn</label>
              <input
                type="text"
                value={tenantName}
                onChange={(e) => setTenantName(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold mb-1">Mã số thuế (Tax ID)</label>
                <input
                  type="text"
                  value={tenantTaxId}
                  onChange={(e) => setTenantTaxId(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Tên miền chính thức (Domain)</label>
                <input
                  type="text"
                  value={tenantDomain}
                  onChange={(e) => setTenantDomain(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block font-semibold mb-1">Đơn vị tiền tệ chính</label>
                <select
                  value={tenantCurrency}
                  onChange={(e) => setTenantCurrency(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                >
                  <option value="VND (₫)">VND (₫) - Đồng Việt Nam</option>
                  <option value="USD ($)">USD ($) - United States Dollar</option>
                </select>
              </div>
              <div>
                <label className="block font-semibold mb-1">Gói dịch vụ kích hoạt</label>
                <input
                  type="text"
                  disabled
                  value={`${currentTenant.plan} (${currentTenant.activeUsers}/${currentTenant.maxUsers} users)`}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-800 font-mono text-slate-500"
                />
              </div>
            </div>

            <div className="pt-4 flex justify-end">
              <button
                type="submit"
                className={`px-5 py-2 rounded-xl text-white font-bold flex items-center gap-1.5 ${themeDef.classes.primaryButton}`}
              >
                <Save className="w-4 h-4" />
                <span>{t.save}</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Subtab 2: User Management */}
      {activeSubTab === 'users' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-xs text-slate-500">
              Danh sách tài khoản nhân viên được cấp quyền truy cập vào Tenant {currentTenant.name}.
            </p>
            <button
              onClick={() => setIsAddUserOpen(true)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold text-white ${themeDef.classes.primaryButton}`}
            >
              <Plus className="w-4 h-4" />
              <span>Thêm Nhân viên Mới</span>
            </button>
          </div>

          <div className={`rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} overflow-hidden shadow-xs`}>
            <table className="w-full text-left text-xs border-collapse">
              <thead className={`${themeDef.classes.tableHeaderBg} border-b border-slate-200 dark:border-slate-800 font-bold uppercase text-[11px]`}>
                <tr>
                  <th className="py-3.5 px-4">Nhân sự</th>
                  <th className="py-3.5 px-4">Email / SĐT</th>
                  <th className="py-3.5 px-4">Phòng ban</th>
                  <th className="py-3.5 px-4">Vai trò (Role)</th>
                  <th className="py-3.5 px-4">Trạng thái</th>
                  <th className="py-3.5 px-4">Đăng nhập gần nhất</th>
                  <th className="py-3.5 px-4 text-right">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-medium text-slate-900 dark:text-slate-100 flex items-center gap-3">
                      <img src={u.avatar} alt={u.fullName} className="w-8 h-8 rounded-full object-cover border" />
                      <div>
                        <div>{u.fullName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">ID: {u.id}</div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <div>{u.email}</div>
                      <div className="font-mono text-slate-400">{u.phone}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-700 dark:text-slate-300">{u.department}</td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="font-mono text-xs font-semibold text-purple-600 dark:text-purple-400">
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 dark:bg-emerald-400 shrink-0" />
                        <span>{u.status}</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-400">{u.lastLogin}</td>
                    <td className="py-3 px-4 text-right">
                      {u.role !== 'Super Admin' && (
                        <button
                          onClick={() => deleteUser(u.id)}
                          className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Subtab 3: RBAC Matrix Editor */}
      {activeSubTab === 'rbac' && (
        <div className={`p-6 rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow}`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Ma trận Phân quyền Truy cập (6 Roles RBAC Matrix)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Thiết lập quyền Xem (View), Tạo (Create), Sửa (Edit), Xóa (Delete), Xuất (Export), và Duyệt (Approve).
              </p>
            </div>

            {/* Select Role to edit */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-400">Chọn Vai trò:</span>
              <select
                value={selectedRbacRole}
                onChange={(e) => setSelectedRbacRole(e.target.value as UserRole)}
                className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-xs font-bold"
              >
                {allRoles.map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Matrix Table */}
          <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 font-bold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3 px-4">Phân hệ / Module</th>
                  {actionsList.map((action) => (
                    <th key={action} className="py-3 px-4 text-center">{action}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {modulesList.map((mod) => {
                  const roleCfg = rolePermissions.find((r) => r.role === selectedRbacRole);
                  const allowedActions = roleCfg?.permissions[mod] || [];

                  return (
                    <tr key={mod} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                      <td className="py-3 px-4 font-bold text-slate-900 dark:text-slate-100 uppercase tracking-tight">
                        {mod}
                      </td>
                      {actionsList.map((act) => {
                        const isChecked = selectedRbacRole === 'Super Admin' || allowedActions.includes(act);
                        const isSuper = selectedRbacRole === 'Super Admin';

                        return (
                          <td key={act} className="py-3 px-4 text-center">
                            <input
                              type="checkbox"
                              disabled={isSuper}
                              checked={isChecked}
                              onChange={(e) =>
                                updateRolePermission(selectedRbacRole, mod, act, e.target.checked)
                              }
                              className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 cursor-pointer disabled:opacity-50"
                            />
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Subtab 4: Theme Engine: 10 Soft Pastel Enterprise Themes */}
      {activeSubTab === 'themes' && (
        <div className="space-y-6">
          <div className={`p-6 rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow}`}>
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                  {isVi ? 'Hệ thống 10 Tông Màu Pastel Doanh Nghiệp (Soft Pastel Themes)' : '10 Enterprise Soft Pastel Themes'}
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  {isVi
                    ? 'Chuyển khung nền bên ngoài sang màu pastel nhẹ, đồng bộ chi tiết nhấn menu sidebar. Thẻ card nội dung giữ nguyên 100% độ tương phản trắng, tối ưu hiệu năng và không gây mỏi mắt.'
                    : 'Subtle outer canvas pastel tint with matched sidebar accents. Inner cards maintain crisp contrast and ultra-fast performance.'}
                </p>
              </div>
              <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 shrink-0 w-fit">
                {isVi ? '10 Tông Màu Pastel' : '10 Pastel Palettes'}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3.5">
              {(Object.keys(THEME_PRESETS) as ThemePreset[]).slice(0, 10).map((themeKey) => {
                const tItem = THEME_PRESETS[themeKey];
                const isSelected = theme === themeKey;

                return (
                  <div
                    key={themeKey}
                    onClick={() => setTheme(themeKey)}
                    className={`p-3.5 rounded-xl border-2 cursor-pointer transition-all flex flex-col justify-between ${
                      isSelected
                        ? 'border-slate-900 dark:border-white bg-white dark:bg-slate-800 shadow-md ring-2 ring-slate-900/10'
                        : 'border-slate-200 dark:border-slate-800 hover:border-slate-400 dark:hover:border-slate-600 bg-white dark:bg-slate-850'
                    }`}
                  >
                    {/* Visual Card simulation */}
                    <div
                      className="w-full h-12 rounded-lg p-1.5 flex items-center justify-between mb-3 border border-black/5"
                      style={{ backgroundColor: tItem.pastelBgColor }}
                    >
                      <div className="h-full w-2.5 rounded-sm" style={{ backgroundColor: tItem.previewColor }} />
                      <div className="h-full flex-1 ml-1.5 bg-white/95 dark:bg-slate-900/90 rounded-sm shadow-2xs border border-black/5 flex items-center justify-end px-1.5">
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-slate-800 dark:text-white" />}
                      </div>
                    </div>

                    <div>
                      <div className="flex items-center gap-1.5 mb-1">
                        <span
                          className="w-3 h-3 rounded-full border border-black/10 shrink-0"
                          style={{ backgroundColor: tItem.previewColor }}
                        />
                        <span className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">
                          {isVi ? tItem.nameVi.replace(/^\d+\.\s*/, '').split('(')[0].trim() : tItem.nameEn}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 truncate">
                        {isVi && tItem.nameVi.includes('(') ? tItem.nameVi.split('(')[1].replace(')', '') : tItem.nameEn}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* Subtab 5: Multi-Language i18n */}
      {activeSubTab === 'language' && (
        <div className={`p-6 rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow} max-w-2xl`}>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
            Bộ máy Đa ngôn ngữ (i18n Engine)
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Hệ thống chọn Tiếng Việt làm ngôn ngữ chuẩn mực mặc định, hỗ trợ chuyển đổi Tiếng Anh và bổ sung ngôn ngữ mới.
          </p>

          <div className="flex items-center gap-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
            <div className="flex-1">
              <div className="font-bold text-xs text-slate-900 dark:text-slate-100">
                Ngôn ngữ hệ thống hiện tại
              </div>
              <div className="text-xs text-slate-500 mt-0.5">
                {language === 'vi' ? 'Tiếng Việt (Việt Nam) - Mặc định' : 'English (United States)'}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setLanguage('vi')}
                className={`px-4 py-2 rounded-xl text-xs font-bold ${
                  language === 'vi' ? 'bg-blue-600 text-white shadow-xs' : 'border border-slate-200 dark:border-slate-700'
                }`}
              >
                Tiếng Việt (Mặc định)
              </button>
              <button
                onClick={() => setLanguage('en')}
                className={`px-4 py-2 rounded-xl text-xs font-bold ${
                  language === 'en' ? 'bg-blue-600 text-white shadow-xs' : 'border border-slate-200 dark:border-slate-700'
                }`}
              >
                English
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Subtab 6: Activity Logs */}
      {activeSubTab === 'activity' && (
        <div className={`p-6 rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} ${themeDef.classes.cardShadow}`}>
          <h3 className="text-base font-bold text-slate-900 dark:text-slate-100 mb-1">
            Nhật ký Hoạt động Người dùng (Activity Log Stream)
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Dòng thời gian ghi nhận hành vi thao tác của tất cả chuyên viên kinh doanh và vận hành.
          </p>

          <div className="space-y-3">
            {activityLogs.map((log) => (
              <div
                key={log.id}
                className="p-3.5 rounded-xl border border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between gap-4 text-xs"
              >
                <div className="flex items-center gap-3">
                  <img src={log.userAvatar} alt={log.userName} className="w-8 h-8 rounded-full object-cover border" />
                  <div>
                    <span className="font-bold text-slate-900 dark:text-slate-100">{log.userName}</span>
                    <span className="text-slate-600 dark:text-slate-300 ml-1.5">{log.actionSummary}</span>
                  </div>
                </div>
                <div className="text-[11px] text-slate-400 font-mono shrink-0">
                  {log.timeAgo} ({log.timestamp})
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Subtab 7: Security Audit Logs */}
      {activeSubTab === 'audit' && (
        <div className={`rounded-2xl ${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} overflow-hidden shadow-xs`}>
          <div className="p-4 border-b border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
              Nhật ký Kiểm toán An ninh Bảo mật (Security Audit Logs)
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Lưu vết bất biến (Immutable) các hành động nhạy cảm: Đăng nhập, Tạo/Sửa/Xóa bản ghi, Cập nhật RBAC, và IP người thực hiện.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className={`${themeDef.classes.tableHeaderBg} border-b border-slate-200 dark:border-slate-800 font-bold uppercase tracking-wider text-[11px]`}>
                <tr>
                  <th className="py-3 px-4 font-mono">Thời gian</th>
                  <th className="py-3 px-4">Tài khoản</th>
                  <th className="py-3 px-4">Hành động</th>
                  <th className="py-3 px-4">Thực thể (Entity)</th>
                  <th className="py-3 px-4 font-mono">Địa chỉ IP</th>
                  <th className="py-3 px-4">Chi tiết thay đổi</th>
                  <th className="py-3 px-4">Kết quả</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 px-4 font-mono text-slate-500">{log.timestamp}</td>
                    <td className="py-2.5 px-4 font-medium text-slate-900 dark:text-slate-100">
                      <div>{log.userName}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{log.userRole}</div>
                    </td>
                    <td className="py-2.5 px-4">
                      <span className="font-mono font-bold px-2 py-0.5 rounded text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {log.action}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 font-mono text-blue-600 dark:text-blue-400">
                      {log.entity} #{log.entityId}
                    </td>
                    <td className="py-2.5 px-4 font-mono text-slate-500">{log.ipAddress}</td>
                    <td className="py-2.5 px-4 text-slate-600 dark:text-slate-300 max-w-sm truncate">
                      {log.details}
                    </td>
                    <td className="py-2.5 px-4">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          log.status === 'SUCCESS'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                        }`}
                      >
                        {log.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Add User */}
      {isAddUserOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-base font-bold text-slate-900 dark:text-slate-100">
                Cấp Tài khoản Nhân sự Mới
              </h3>
              <button onClick={() => setIsAddUserOpen(false)} className="text-slate-400">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleAddUserSubmit} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block font-semibold mb-1">Họ và tên *</label>
                <input
                  type="text"
                  required
                  value={newUserData.fullName}
                  onChange={(e) => setNewUserData({ ...newUserData, fullName: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div>
                <label className="block font-semibold mb-1">Email công việc *</label>
                <input
                  type="email"
                  required
                  value={newUserData.email}
                  onChange={(e) => setNewUserData({ ...newUserData, email: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold mb-1">Số điện thoại</label>
                  <input
                    type="text"
                    value={newUserData.phone}
                    onChange={(e) => setNewUserData({ ...newUserData, phone: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-mono"
                  />
                </div>
                <div>
                  <label className="block font-semibold mb-1">Phòng ban</label>
                  <input
                    type="text"
                    value={newUserData.department}
                    onChange={(e) => setNewUserData({ ...newUserData, department: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900"
                  />
                </div>
              </div>
              <div>
                <label className="block font-semibold mb-1">Vai trò phân quyền (Role) *</label>
                <select
                  value={newUserData.role}
                  onChange={(e) => setNewUserData({ ...newUserData, role: e.target.value as UserRole })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 font-semibold"
                >
                  {allRoles.map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddUserOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 rounded-xl text-white font-bold ${themeDef.classes.primaryButton}`}
                >
                  Tạo Tài Khoản
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
