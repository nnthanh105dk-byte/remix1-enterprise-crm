import React from 'react';
import { useCRM } from '../../context/CRMContext';
import { ReportFilterState } from '../../types/crm';
import { ReportFilterBar } from '../../components/reports/ReportFilterBar';
import { KPICard, FunnelVisualChart, MonthlyComparisonBarChart } from '../../components/reports/ReportCharts';
import {
  MOCK_SALES_REPS,
  MOCK_PIPELINE_DEALS,
  MOCK_HISTORICAL_MONTHS,
} from '../../data/mockReportsData';
import {
  DollarSign,
  Briefcase,
  Layers,
  Award,
  CircleDollarSign,
  UserPlus,
  AlertCircle,
  Clock,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

interface SalesOverviewReportProps {
  filter: ReportFilterState;
  onChangeFilter: (updated: Partial<ReportFilterState>) => void;
}

export const SalesOverviewReport: React.FC<SalesOverviewReportProps> = ({
  filter,
  onChangeFilter,
}) => {
  const { setActiveModule, themeDef } = useCRM();

  // Filtered reps & pipeline
  const filteredReps = MOCK_SALES_REPS.filter((r) => {
    if (filter.teamId !== 'all' && r.teamId !== filter.teamId) return false;
    if (filter.salesRepId !== 'all' && r.id !== filter.salesRepId) return false;
    if (filter.region !== 'all' && r.region !== filter.region) return false;
    return true;
  });

  const totalRevenue = filteredReps.reduce((sum, r) => sum + r.actualRevenue, 0);
  const totalQuota = filteredReps.reduce((sum, r) => sum + r.monthlyQuota, 0);
  const revenuePct = totalQuota > 0 ? Math.round((totalRevenue / totalQuota) * 100) : 0;

  const filteredDeals = MOCK_PIPELINE_DEALS.filter((d) => {
    if (filter.teamId !== 'all' && d.teamId !== filter.teamId) return false;
    if (filter.salesRepId !== 'all' && d.repId !== filter.salesRepId) return false;
    return true;
  });

  const openDealsCount = filteredDeals.length;
  const pipelineValue = filteredDeals.reduce((sum, d) => sum + d.amount, 0);
  const winRate = 68; // 68%
  const avgDealValue = openDealsCount > 0 ? Math.round(pipelineValue / openDealsCount) : 0;
  const newLeadsCount = 48;

  // Top 5 Reps
  const top5Reps = [...filteredReps].sort((a, b) => b.actualRevenue - a.actualRevenue).slice(0, 5);

  // Top 5 Big Deals Closing Soon
  const top5BigDeals = [...filteredDeals].sort((a, b) => b.amount - a.amount).slice(0, 5);

  // Stalled or Overdue Deals
  const stalledDeals = filteredDeals.filter((d) => d.isStagnant);

  const miniFunnelStages = [
    { id: 'f1', name: 'Lead & Liên hệ', count: 120, value: 8500000000, conversionFromPrev: 100, avgDwellDays: 3 },
    { id: 'f2', name: 'Khám phá nhu cầu', count: 75, value: 6200000000, conversionFromPrev: 62, avgDwellDays: 14, isBottleneck: true },
    { id: 'f3', name: 'Báo giá & Đề xuất', count: 42, value: 4300000000, conversionFromPrev: 56, avgDwellDays: 12 },
    { id: 'f4', name: 'Đàm phán & Chốt', count: 28, value: 3100000000, conversionFromPrev: 66, avgDwellDays: 8 },
    { id: 'f5', name: 'Deal Thắng', count: 18, value: 2450000000, conversionFromPrev: 64, avgDwellDays: 4 },
  ];

  return (
    <div className="space-y-6">
      {/* Shared Filter Bar */}
      <ReportFilterBar
        filter={filter}
        onChangeFilter={onChangeFilter}
        reportTitle="Tổng quan Sales"
      />

      {/* Row of 6 KPI Cards: Tinh gọn chỉ Tiêu đề + Số lớn + Điểm nhấn màu góc card */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3 sm:gap-4">
        <KPICard
          title="Doanh thu kỳ này"
          value={`${(totalRevenue / 1000000000).toFixed(2)} Tỷ`}
          icon={DollarSign}
          iconColor="text-emerald-600 bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200 dark:border-emerald-800"
          onClickDrilldown={() => setActiveModule('sales-revenue')}
        />

        <KPICard
          title="Số deal mở"
          value={`${openDealsCount} deal`}
          icon={Briefcase}
          iconColor="text-blue-600 bg-blue-50 dark:bg-blue-950/60 border-blue-200 dark:border-blue-800"
          onClickDrilldown={() => setActiveModule('sales-forecast')}
        />

        <KPICard
          title="Giá trị Pipeline"
          value={`${(pipelineValue / 1000000000).toFixed(2)} Tỷ`}
          icon={Layers}
          iconColor="text-indigo-600 bg-indigo-50 dark:bg-indigo-950/60 border-indigo-200 dark:border-indigo-800"
          onClickDrilldown={() => setActiveModule('sales-funnel')}
        />

        <KPICard
          title="Tỷ lệ thắng"
          value={`${winRate}%`}
          icon={Award}
          iconColor="text-amber-600 bg-amber-50 dark:bg-amber-950/60 border-amber-200 dark:border-amber-800"
          onClickDrilldown={() => setActiveModule('sales-won')}
        />

        <KPICard
          title="Deal trung bình"
          value={`${(avgDealValue / 1000000).toFixed(0)} Tr`}
          icon={CircleDollarSign}
          iconColor="text-purple-600 bg-purple-50 dark:bg-purple-950/60 border-purple-200 dark:border-purple-800"
          onClickDrilldown={() => setActiveModule('sales-won')}
        />

        <KPICard
          title="Lead mới kỳ này"
          value={`${newLeadsCount} Lead`}
          icon={UserPlus}
          iconColor="text-rose-600 bg-rose-50 dark:bg-rose-950/60 border-rose-200 dark:border-rose-800"
          onClickDrilldown={() => setActiveModule('sales-leads')}
        />
      </div>

      {/* Main Charts Grid: Monthly Revenue vs Target & Mini Funnel with Soft Elevation */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Revenue vs Target */}
        <div
          onClick={() => setActiveModule('sales-revenue')}
          className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] cursor-pointer hover:border-sky-400 dark:hover:border-sky-500 transition-all`}
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="section-title">
                <TrendingUp className="w-4.5 h-4.5 text-[#0284c7] dark:text-sky-400 mr-2 shrink-0" />
                Doanh thu theo tháng so với mục tiêu (T05 - T10/2026)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Nhấp để chuyển sang Báo cáo Doanh thu chi tiết
              </p>
            </div>
            <span className="text-xs font-semibold text-sky-600 dark:text-sky-400 inline-flex items-center gap-1">
              Chi tiết <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>

          <MonthlyComparisonBarChart data={MOCK_HISTORICAL_MONTHS} />
        </div>

        {/* Mini Funnel Chart */}
        <div
          onClick={() => setActiveModule('sales-funnel')}
          className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] cursor-pointer hover:border-sky-400 dark:hover:border-sky-500 transition-all`}
        >
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="section-title">
                <Layers className="w-4.5 h-4.5 text-[#0284c7] dark:text-sky-400 mr-2 shrink-0" />
                Phễu bán hàng rút gọn & Điểm nghẽn
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Tỷ lệ chuyển đổi và số ngày tồn đọng qua các giai đoạn
              </p>
            </div>
            <span className="text-xs font-semibold text-sky-600 dark:text-sky-400 inline-flex items-center gap-1">
              Chi tiết <ArrowRight className="w-3.5 h-3.5" />
            </span>
          </div>

          <FunnelVisualChart stages={miniFunnelStages} />
        </div>
      </div>

      {/* Bottom Grid: Top 5 Reps, Top 5 Big Deals, Stalled Deals Warning with Soft Elevation */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* 1. Top 5 Sales Reps */}
        <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] transition-all flex flex-col justify-between`}>
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="section-title">
                <Award className="w-4.5 h-4.5 text-amber-500 mr-2 shrink-0" />
                Top 5 Nhân viên xuất sắc
              </h3>
              <button
                onClick={() => setActiveModule('sales-productivity')}
                className="text-xs text-sky-600 dark:text-sky-400 hover:underline font-semibold"
              >
                Xem tất cả
              </button>
            </div>

            <div className="space-y-3">
              {top5Reps.map((rep, idx) => {
                const quotaPct = Math.round((rep.actualRevenue / rep.monthlyQuota) * 100);

                return (
                  <div key={rep.id} className="flex items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="w-5 h-5 rounded-full bg-slate-100 dark:bg-slate-800 font-bold flex items-center justify-center text-slate-700 dark:text-slate-300 shrink-0">
                        {idx + 1}
                      </span>
                      <img src={rep.avatar} alt={rep.name} className="w-7 h-7 rounded-full object-cover shrink-0" />
                      <div className="min-w-0">
                        <p className="font-bold text-slate-900 dark:text-white truncate">{rep.name}</p>
                        <p className="text-[10px] text-slate-500 truncate">{rep.teamName.replace('Đội ', '')}</p>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="font-bold text-slate-900 dark:text-white font-mono">
                        {(rep.actualRevenue / 1000000).toLocaleString('vi-VN')} Tr
                      </p>
                      <span className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
                        {quotaPct}% quota
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* 2. Top 5 Big Deals Closing Soon */}
        <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] transition-all flex flex-col justify-between`}>
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="section-title">
                <Briefcase className="w-4.5 h-4.5 text-[#0284c7] dark:text-sky-400 mr-2 shrink-0" />
                Top 5 Deal lớn sắp chốt
              </h3>
              <button
                onClick={() => setActiveModule('sales-forecast')}
                className="text-xs text-sky-600 dark:text-sky-400 hover:underline font-semibold"
              >
                Chi tiết
              </button>
            </div>

            <div className="space-y-3">
              {top5BigDeals.map((deal) => (
                <div key={deal.id} className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/50 border border-slate-200/60 dark:border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900 dark:text-white truncate max-w-[170px]" title={deal.title}>
                      {deal.title}
                    </span>
                    <span className="font-bold font-mono text-emerald-600 dark:text-emerald-400">
                      {(deal.amount / 1000000).toLocaleString('vi-VN')} Tr
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400">
                    <span className="truncate">{deal.customerCompany}</span>
                    <span className="font-mono text-sky-600 dark:text-sky-400 font-semibold">{deal.probability}% ({deal.stage})</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* 3. Stalled / Overdue Deals Alert */}
        <div className={`${themeDef.classes.cardBg} ${themeDef.classes.cardBorder} rounded-xl p-5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.09)] transition-all flex flex-col justify-between`}>
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="section-title">
                <AlertCircle className="w-4.5 h-4.5 text-amber-500 mr-2 shrink-0" />
                Deal bị đứng lâu (&gt;14 ngày)
              </h3>
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300">
                {stalledDeals.length} deal
              </span>
            </div>

            <div className="space-y-2.5">
              {stalledDeals.map((deal) => (
                <div key={deal.id} className="p-2.5 rounded-lg bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800/60 text-xs">
                  <div className="flex items-center justify-between font-bold text-slate-900 dark:text-white">
                    <span className="truncate max-w-[160px]">{deal.title}</span>
                    <span className="text-amber-700 dark:text-amber-300 flex items-center gap-1 shrink-0 font-mono text-[11px]">
                      <Clock className="w-3 h-3" /> {deal.dwellDaysInStage} ngày
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
                    <span>Phụ trách: {deal.repName}</span>
                    <span className="font-mono">{(deal.amount / 1000000).toLocaleString('vi-VN')} Tr</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => setActiveModule('sales-funnel')}
            className="w-full mt-4 py-2 px-3 rounded-lg border border-amber-300 dark:border-amber-800 text-xs font-semibold text-amber-800 dark:text-amber-300 hover:bg-amber-100/50 dark:hover:bg-amber-900/30 transition-colors text-center"
          >
            Mở xem xét phễu nghẽn
          </button>
        </div>
      </div>
    </div>
  );
};
