import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useAccounting } from '../../context/AccountingContext';
import {
  CashTransaction,
  CashTransactionType,
  CashCategoryType,
  PaymentChannel,
  BankAccountBalance,
} from '../../types/accounting';
import {
  DollarSign,
  TrendingDown,
  TrendingUp,
  Search,
  Filter,
  Plus,
  Download,
  Calendar,
  Building,
  CheckCircle2,
  Clock,
  AlertTriangle,
  X,
  Printer,
  FileText,
  CreditCard,
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  Check,
  ShieldAlert,
  BarChart3,
} from 'lucide-react';

export const AccountingCashFlowView: React.FC = () => {
  const { showToast, currentUser } = useCRM();
  const {
    cashTransactions,
    bankBalances,
    cashForecasts,
    addCashTransaction,
    cancelCashTransaction,
    reconcileBankBalance,
  } = useAccounting();

  const [activeMainTab, setActiveMainTab] = useState<'petty_cash' | 'cash_forecast'>('petty_cash');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<'all' | 'Thu' | 'Chi'>('all');
  const [selectedChannel, setSelectedChannel] = useState('all');

  // Modals
  const [isCreateTxModalOpen, setIsCreateTxModalOpen] = useState(false);
  const [createTxType, setCreateTxType] = useState<CashTransactionType>('Thu');
  const [txCategory, setTxCategory] = useState<CashCategoryType>('Thu tiền hàng từ khách');
  const [txPartnerType, setTxPartnerType] = useState<'Khách hàng' | 'Nhà cung cấp' | 'Nhân viên' | 'Nội bộ / Khác'>('Khách hàng');
  const [txPartnerName, setTxPartnerName] = useState('');
  const [txAmount, setTxAmount] = useState<number>(10000000);
  const [txChannel, setTxChannel] = useState<PaymentChannel>('Vietcombank (0011004321999)');
  const [txBankRef, setTxBankRef] = useState('');
  const [txReason, setTxReason] = useState('');
  const [txRefDoc, setTxRefDoc] = useState('');

  // Reconcile modal
  const [reconcileBankTarget, setReconcileBankTarget] = useState<BankAccountBalance | null>(null);
  const [actualBalanceInput, setActualBalanceInput] = useState<number>(0);

  // Printing modal
  const [printingTx, setPrintingTx] = useState<CashTransaction | null>(null);

  // Stats calculation
  const stats = useMemo(() => {
    const totalInflow = cashTransactions
      .filter((t) => t.type === 'Thu' && t.status !== 'Đã hủy')
      .reduce((sum, t) => sum + t.amount, 0);
    const totalOutflow = cashTransactions
      .filter((t) => t.type === 'Chi' && t.status !== 'Đã hủy')
      .reduce((sum, t) => sum + t.amount, 0);
    const netCashFlow = totalInflow - totalOutflow;

    const cashInVault = bankBalances.find((b) => b.id === 'bank-vault')?.currentBalance || 0;
    const totalBankCash = bankBalances
      .filter((b) => b.id !== 'bank-vault')
      .reduce((sum, b) => sum + b.currentBalance, 0);
    const grandTotalCash = cashInVault + totalBankCash;

    return {
      totalInflow,
      totalOutflow,
      netCashFlow,
      cashInVault,
      totalBankCash,
      grandTotalCash,
    };
  }, [cashTransactions, bankBalances]);

  // Filter transactions
  const filteredTransactions = useMemo(() => {
    return cashTransactions.filter((tx) => {
      const matchSearch =
        tx.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tx.partnerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        tx.reason.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (tx.bankRefNumber && tx.bankRefNumber.toLowerCase().includes(searchTerm.toLowerCase()));
      const matchType = selectedType === 'all' || tx.type === selectedType;
      const matchChannel = selectedChannel === 'all' || tx.channel.includes(selectedChannel);
      return matchSearch && matchType && matchChannel;
    });
  }, [cashTransactions, searchTerm, selectedType, selectedChannel]);

  // Handle create transaction submit
  const handleConfirmCreateTx = (e: React.FormEvent) => {
    e.preventDefault();
    if (!txPartnerName.trim() || txAmount <= 0) {
      showToast('Lỗi nhập liệu', 'Vui lòng nhập đối tượng và số tiền hợp lệ (> 0)');
      return;
    }
    const codePrefix = createTxType === 'Thu' ? 'PT' : 'PC';
    const newCode = `${codePrefix}-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    addCashTransaction({
      code: newCode,
      type: createTxType,
      date: new Date().toISOString().split('T')[0],
      category: txCategory,
      partnerType: txPartnerType,
      partnerName: txPartnerName,
      amount: txAmount,
      amountInWords: `${txAmount.toLocaleString('vi-VN')} đồng`,
      channel: txChannel,
      bankRefNumber: txBankRef || undefined,
      reason: txReason || `${createTxType === 'Thu' ? 'Thu' : 'Chi'} tiền theo nghiệp vụ`,
      creatorName: currentUser?.fullName || 'Kế toán viên',
      approverName: 'Vũ Hoàng Yến (KTT)',
      cashierName: 'Lê Mai Anh (Thủ quỹ)',
      status: 'Đã thực hiện',
      referenceDocCode: txRefDoc || undefined,
    });
    setIsCreateTxModalOpen(false);
    setTxPartnerName('');
    setTxReason('');
    setTxBankRef('');
    setTxRefDoc('');
  };

  // Handle reconcile submit
  const handleConfirmReconcile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reconcileBankTarget) return;
    reconcileBankBalance(reconcileBankTarget.id, actualBalanceInput);
    setReconcileBankTarget(null);
  };

  return (
    <div className="space-y-6">
      {/* 1. Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
              Kế toán Tiền mặt & Dòng tiền
            </span>
            <span className="text-xs text-slate-400">Sổ quỹ & Ngân hàng</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-1">
            Giao dịch & Dòng tiền (Cash Flow)
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Quản lý sổ quỹ tiền mặt, tài khoản ngân hàng, lập phiếu thu/chi và dự báo cân đối dòng tiền.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              setCreateTxType('Thu');
              setTxCategory('Thu tiền hàng từ khách');
              setTxPartnerType('Khách hàng');
              setIsCreateTxModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white transition-colors shadow-sm"
          >
            <ArrowDownLeft className="w-4 h-4" />
            Lập Phiếu Thu
          </button>
          <button
            onClick={() => {
              setCreateTxType('Chi');
              setTxCategory('Chi trả nhà cung cấp hàng hóa');
              setTxPartnerType('Nhà cung cấp');
              setIsCreateTxModalOpen(true);
            }}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg bg-red-600 hover:bg-red-700 text-white transition-colors shadow-sm"
          >
            <ArrowUpRight className="w-4 h-4" />
            Lập Phiếu Chi
          </button>
        </div>
      </div>

      {/* 2. Main Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 rounded-t-xl">
        <button
          onClick={() => setActiveMainTab('petty_cash')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeMainTab === 'petty_cash'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Wallet className="w-4 h-4" />
          Sổ quỹ & Giao dịch Thu - Chi ({cashTransactions.length})
        </button>

        <button
          onClick={() => setActiveMainTab('cash_forecast')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeMainTab === 'cash_forecast'
              ? 'border-emerald-600 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          Kế hoạch & Dự báo Dòng tiền
        </button>
      </div>

      {/* ======================================================== */}
      {/* TAB 1: SỔ QUỸ & GIAO DỊCH THU CHI */}
      {/* ======================================================== */}
      {activeMainTab === 'petty_cash' && (
        <div className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Tổng thu trong kỳ</span>
              <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1 flex items-center gap-1">
                <ArrowDownLeft className="w-4 h-4" />
                {stats.totalInflow.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-400">Tiền hàng & dịch vụ</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Tổng chi trong kỳ</span>
              <div className="text-lg font-bold text-red-600 dark:text-red-400 mt-1 flex items-center gap-1">
                <ArrowUpRight className="w-4 h-4" />
                {stats.totalOutflow.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-400">Tiền hàng, lương, chi phí</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Dòng tiền thuần (Net)</span>
              <div
                className={`text-lg font-bold mt-1 ${
                  stats.netCashFlow >= 0 ? 'text-blue-600' : 'text-amber-600'
                }`}
              >
                {stats.netCashFlow.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-400">Thu trừ Chi</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
              <span className="text-xs font-medium text-slate-500">Tồn quỹ tiền mặt</span>
              <div className="text-lg font-bold text-slate-900 dark:text-white mt-1">
                {stats.cashInVault.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-400">Két văn phòng</span>
            </div>

            <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/20 dark:bg-emerald-950/10 shadow-sm">
              <span className="text-xs font-medium text-emerald-800 dark:text-emerald-300">
                Tổng số dư ngân hàng
              </span>
              <div className="text-lg font-bold text-emerald-700 dark:text-emerald-400 mt-1">
                {stats.totalBankCash.toLocaleString('vi-VN')} đ
              </div>
              <span className="text-[11px] text-slate-500">3 tài khoản ngân hàng</span>
            </div>
          </div>

          {/* Bank Accounts Overview Horizontal Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
            {bankBalances.map((b) => (
              <div
                key={b.id}
                className="bg-white dark:bg-slate-800 p-3.5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-bold text-slate-900 dark:text-white truncate max-w-[180px]">
                    {b.bankName}
                  </div>
                  <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                    {b.accountNumber}
                  </div>
                  <div className="text-sm font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                    {b.currentBalance.toLocaleString('vi-VN')} đ
                  </div>
                </div>

                <button
                  onClick={() => {
                    setReconcileBankTarget(b);
                    setActualBalanceInput(b.currentBalance);
                  }}
                  title="Đối soát số dư thực tế"
                  className="px-2 py-1 text-[11px] font-medium rounded border border-slate-300 dark:border-slate-600 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
                >
                  Đối soát
                </button>
              </div>
            ))}
          </div>

          {/* Filter Bar */}
          <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
            <div className="flex-1 w-full md:w-auto relative">
              <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Tìm giao dịch theo số phiếu, đối tác, nội dung, mã GD..."
                className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="flex items-center gap-2.5 w-full md:w-auto">
              <select
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value as 'all' | 'Thu' | 'Chi')}
                className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
              >
                <option value="all">Tất cả Loại phiếu</option>
                <option value="Thu">Phiếu Thu (PT)</option>
                <option value="Chi">Phiếu Chi (PC)</option>
              </select>

              <select
                value={selectedChannel}
                onChange={(e) => setSelectedChannel(e.target.value)}
                className="px-3 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-200 outline-none"
              >
                <option value="all">Tất cả tài khoản / quỹ</option>
                <option value="Vietcombank">Vietcombank</option>
                <option value="Techcombank">Techcombank</option>
                <option value="MB Bank">MB Bank</option>
                <option value="Tiền mặt">Tiền mặt tại quỹ</option>
              </select>
            </div>
          </div>

          {/* Transactions Table */}
          <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
                <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="px-4 py-3.5">Số phiếu</th>
                    <th className="px-3 py-3.5">Ngày</th>
                    <th className="px-3 py-3.5 text-center">Loại</th>
                    <th className="px-4 py-3.5">Danh mục & Nội dung</th>
                    <th className="px-4 py-3.5">Đối tượng</th>
                    <th className="px-3 py-3.5">Tài khoản / Quỹ</th>
                    <th className="px-3 py-3.5 text-right">Số tiền</th>
                    <th className="px-3 py-3.5 text-center">Trạng thái</th>
                    <th className="px-4 py-3.5 text-center">In / Thao tác</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                  {filteredTransactions.map((tx) => (
                    <tr
                      key={tx.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors"
                    >
                      <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">
                        {tx.code}
                      </td>

                      <td className="px-3 py-3.5 text-xs font-mono text-slate-500">{tx.date}</td>

                      <td className="px-3 py-3.5 text-center">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-bold ${
                            tx.type === 'Thu'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                              : 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300'
                          }`}
                        >
                          {tx.type}
                        </span>
                      </td>

                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-900 dark:text-white text-xs">
                          {tx.category}
                        </div>
                        <div className="text-xs text-slate-500 truncate max-w-xs">{tx.reason}</div>
                        {tx.referenceDocCode && (
                          <span className="text-[10px] font-mono text-blue-600 block mt-0.5">
                            Kèm: {tx.referenceDocCode}
                          </span>
                        )}
                      </td>

                      <td className="px-4 py-3.5">
                        <div className="font-medium text-slate-800 dark:text-slate-200">
                          {tx.partnerName}
                        </div>
                        <span className="text-[10px] text-slate-400">{tx.partnerType}</span>
                      </td>

                      <td className="px-3 py-3.5 text-xs text-slate-600 dark:text-slate-300">
                        <div>{tx.channel.split('(')[0]}</div>
                        {tx.bankRefNumber && (
                          <div className="text-[10px] font-mono text-slate-400">
                            Ref: {tx.bankRefNumber}
                          </div>
                        )}
                      </td>

                      <td className="px-3 py-3.5 text-right font-bold">
                        <span
                          className={
                            tx.type === 'Thu'
                              ? 'text-emerald-600 dark:text-emerald-400'
                              : 'text-red-600 dark:text-red-400'
                          }
                        >
                          {tx.type === 'Thu' ? '+' : '-'}
                          {tx.amount.toLocaleString('vi-VN')} đ
                        </span>
                      </td>

                      <td className="px-3 py-3.5 text-center">
                        <span
                          className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                            tx.status === 'Đã thực hiện'
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300'
                              : tx.status === 'Chờ duyệt chi'
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
                              : 'bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-300'
                          }`}
                        >
                          {tx.status}
                        </span>
                      </td>

                      <td className="px-4 py-3.5 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            onClick={() => setPrintingTx(tx)}
                            title="In phiếu thu/chi"
                            className="p-1.5 text-slate-600 dark:text-slate-300 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-lg transition-colors"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: KẾ HOẠCH & DỰ BÁO DÒNG TIỀN */}
      {/* ======================================================== */}
      {activeMainTab === 'cash_forecast' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Bảng Cân Đối & Dự Báo Dòng Tiền (4 Tuần Tới)
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Tính toán dựa trên các khoản phải thu đến hạn (Sales), đơn hàng sắp xuất kho, công nợ
                phải trả NCC (Logistics/Kỹ thuật) và chi phí lương/BHXH định kỳ (Quản lý nhân sự).
              </p>
            </div>

            {/* Forecast Table */}
            <div className="overflow-x-auto rounded-lg border border-slate-200 dark:border-slate-700">
              <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
                <thead className="bg-slate-50 dark:bg-slate-900 uppercase font-semibold text-slate-500 border-b border-slate-200 dark:border-slate-700">
                  <tr>
                    <th className="px-4 py-3">Khoảng thời gian</th>
                    <th className="px-3 py-3 text-right">Số dư đầu kỳ</th>
                    <th className="px-3 py-3 text-right text-emerald-600 font-bold">Dự kiến thu (+)</th>
                    <th className="px-3 py-3 text-right text-red-600 font-bold">Dự kiến chi (-)</th>
                    <th className="px-3 py-3 text-right">Dòng tiền thuần</th>
                    <th className="px-3 py-3 text-right">Số dư cuối kỳ</th>
                    <th className="px-3 py-3 text-center">Trạng thái an toàn</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-700">
                  {cashForecasts.map((period, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-700/30">
                      <td className="px-4 py-3 font-semibold text-slate-900 dark:text-white">
                        {period.periodLabel}
                      </td>
                      <td className="px-3 py-3 text-right font-medium">
                        {period.openingCash.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-emerald-600 dark:text-emerald-400">
                        +{period.forecastInflow.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-red-600 dark:text-red-400">
                        -{period.forecastOutflow.toLocaleString('vi-VN')} đ
                      </td>
                      <td
                        className={`px-3 py-3 text-right font-bold ${
                          period.netCashFlow >= 0 ? 'text-blue-600' : 'text-amber-600'
                        }`}
                      >
                        {period.netCashFlow > 0 ? '+' : ''}
                        {period.netCashFlow.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-3 py-3 text-right font-bold text-slate-900 dark:text-white text-sm">
                        {period.closingCash.toLocaleString('vi-VN')} đ
                      </td>
                      <td className="px-3 py-3 text-center">
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          An toàn quỹ
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Breakdown Insights */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 rounded-xl space-y-2">
                <span className="font-bold text-emerald-900 dark:text-emerald-300 text-xs flex items-center gap-1.5">
                  <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
                  Cơ cấu nguồn tiền dự kiến thu về (Tháng 4/2026):
                </span>
                <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1 pl-2">
                  <li>• Thu hồi nợ khách hàng đến hạn: 1.700.000.000 đ (81%)</li>
                  <li>• Thu tạm ứng đơn hàng ký mới: 400.000.000 đ (19%)</li>
                </ul>
              </div>

              <div className="p-4 bg-red-50/40 dark:bg-red-950/20 border border-red-200 dark:border-red-900/40 rounded-xl space-y-2">
                <span className="font-bold text-red-900 dark:text-red-300 text-xs flex items-center gap-1.5">
                  <ArrowUpRight className="w-4 h-4 text-red-600" />
                  Cơ cấu các khoản chi tiền bắt buộc (Tháng 4/2026):
                </span>
                <ul className="text-xs text-slate-600 dark:text-slate-300 space-y-1 pl-2">
                  <li>• Trả nợ nhà cung cấp linh kiện & thiết bị: 1.530.000.000 đ (73%)</li>
                  <li>• Quỹ lương & BHXH nhân viên 50 người: 345.000.000 đ (16%)</li>
                  <li>• Chi phí vận hành, cước vận chuyển logistics: 225.000.000 đ (11%)</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: TẠO PHIẾU THU / CHI MỚI */}
      {/* ======================================================== */}
      {isCreateTxModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <form
            onSubmit={handleConfirmCreateTx}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  {createTxType === 'Thu' ? (
                    <ArrowDownLeft className="w-5 h-5 text-emerald-600" />
                  ) : (
                    <ArrowUpRight className="w-5 h-5 text-red-600" />
                  )}
                  Lập {createTxType === 'Thu' ? 'Phiếu Thu' : 'Phiếu Chi'} Mới
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Ghi nhận biến động dòng tiền vào sổ quỹ và tài khoản ngân hàng
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsCreateTxModalOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Danh mục thu chi *
                  </label>
                  <select
                    value={txCategory}
                    onChange={(e) => setTxCategory(e.target.value as CashCategoryType)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  >
                    {createTxType === 'Thu' ? (
                      <>
                        <option value="Thu tiền hàng từ khách">Thu tiền hàng từ khách</option>
                        <option value="Thu tiền dịch vụ / bảo trì">Thu tiền dịch vụ / bảo trì</option>
                        <option value="Thu hoàn ứng">Thu hoàn ứng nhân viên</option>
                        <option value="Thu lãi tiền gửi">Thu lãi tiền gửi ngân hàng</option>
                        <option value="Thu khác">Thu khác</option>
                      </>
                    ) : (
                      <>
                        <option value="Chi trả nhà cung cấp hàng hóa">Chi trả nhà cung cấp hàng hóa</option>
                        <option value="Chi cước vận chuyển logistics">Chi cước vận chuyển logistics</option>
                        <option value="Chi phí thầu phụ kỹ thuật">Chi phí thầu phụ kỹ thuật</option>
                        <option value="Chi lương & bảo hiểm nhân sự">Chi lương & bảo hiểm nhân sự</option>
                        <option value="Chi tạm ứng công tác">Chi tạm ứng công tác phí</option>
                        <option value="Chi thuê văn phòng & tiện ích">Chi thuê văn phòng & tiện ích</option>
                        <option value="Chi khác">Chi khác</option>
                      </>
                    )}
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Số tiền (VND) *
                  </label>
                  <input
                    type="number"
                    min={1000}
                    value={txAmount}
                    onChange={(e) => setTxAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold text-sm outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Đối tượng giao dịch *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Tên khách hàng, NCC, CBNV..."
                    value={txPartnerName}
                    onChange={(e) => setTxPartnerName(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Tài khoản / Quỹ tiền *
                  </label>
                  <select
                    value={txChannel}
                    onChange={(e) => setTxChannel(e.target.value as PaymentChannel)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                  >
                    <option value="Vietcombank (0011004321999)">Vietcombank (0011004321999)</option>
                    <option value="Techcombank (19033321456011)">Techcombank (19033321456011)</option>
                    <option value="MB Bank (0888666999)">MB Bank (0888666999)</option>
                    <option value="Tiền mặt tại quỹ">Tiền mặt tại quỹ chính</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Mã tham chiếu ngân hàng
                  </label>
                  <input
                    type="text"
                    placeholder="FT... hoặc Số UNC"
                    value={txBankRef}
                    onChange={(e) => setTxBankRef(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Số chứng từ gốc liên kết
                  </label>
                  <input
                    type="text"
                    placeholder="HDON-..., HDM-..., DNTT-..."
                    value={txRefDoc}
                    onChange={(e) => setTxRefDoc(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Nội dung diễn giải *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Diễn giải chi tiết lý do nộp/chi tiền..."
                  value={txReason}
                  onChange={(e) => setTxReason(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setIsCreateTxModalOpen(false)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Hủy bỏ
              </button>
              <button
                type="submit"
                className={`px-4 py-2 text-xs font-medium rounded-lg text-white ${
                  createTxType === 'Thu'
                    ? 'bg-emerald-600 hover:bg-emerald-700'
                    : 'bg-red-600 hover:bg-red-700'
                }`}
              >
                Ghi sổ {createTxType === 'Thu' ? 'Phiếu Thu' : 'Phiếu Chi'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: ĐỐI SOÁT SỐ DƯ TÀI KHOẢN NGÂN HÀNG */}
      {/* ======================================================== */}
      {reconcileBankTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <form
            onSubmit={handleConfirmReconcile}
            className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full border border-slate-200 dark:border-slate-800 shadow-2xl p-6 space-y-4"
          >
            <div className="flex items-start justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-emerald-600" />
                  Đối Soát Số Dư Ngân Hàng
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {reconcileBankTarget.bankName} - STK: {reconcileBankTarget.accountNumber}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setReconcileBankTarget(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3.5 text-xs">
              <div className="bg-slate-50 dark:bg-slate-800 p-3 rounded-lg flex items-center justify-between">
                <span className="text-slate-500">Số dư trên sổ sách CRM:</span>
                <span className="font-bold text-slate-900 dark:text-white text-sm">
                  {reconcileBankTarget.bookBalance.toLocaleString('vi-VN')} đ
                </span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Số dư thực tế theo sao kê ngân hàng (VND) *
                </label>
                <input
                  type="number"
                  min={0}
                  value={actualBalanceInput}
                  onChange={(e) => setActualBalanceInput(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-bold text-base outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              {actualBalanceInput - reconcileBankTarget.bookBalance !== 0 && (
                <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/40 text-amber-900 dark:text-amber-300 flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Chênh lệch sổ sách và sao kê:</span>
                    <p className="mt-0.5 font-mono font-bold">
                      {(actualBalanceInput - reconcileBankTarget.bookBalance).toLocaleString('vi-VN')} đ
                    </p>
                  </div>
                </div>
              )}
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => setReconcileBankTarget(null)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Hủy
              </button>
              <button
                type="submit"
                className="px-4 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white"
              >
                Cập nhật đối soát
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ======================================================== */}
      {/* MODAL: XEM & IN BIỂU MẪU PHIẾU THU / CHI */}
      {/* ======================================================== */}
      {printingTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white rounded-2xl max-w-xl w-full text-slate-900 p-8 space-y-6 shadow-2xl border border-slate-200">
            <div className="flex items-start justify-between border-b pb-4">
              <div>
                <div className="text-xs uppercase font-bold tracking-wider text-slate-500">
                  CÔNG TY CP GIẢI PHÁP CÔNG NGHỆ & THƯƠNG MẠI APLUS
                </div>
                <div className="text-[11px] text-slate-400">
                  Số 18 Tam Trinh, Q. Hai Bà Trưng, TP. Hà Nội • MST: 0108999888
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs font-mono font-bold text-slate-600">
                  Mẫu số 01-TT / 02-TT
                </div>
                <div className="text-[11px] text-slate-400">Ban hành theo TT 200/2014/TT-BTC</div>
              </div>
            </div>

            <div className="text-center space-y-1">
              <h2 className="text-xl font-bold uppercase tracking-wide">
                {printingTx.type === 'Thu' ? 'PHIẾU THU' : 'PHIẾU CHI'}
              </h2>
              <div className="text-xs text-slate-500 font-mono">
                Số: <strong>{printingTx.code}</strong> • Ngày: {printingTx.date}
              </div>
            </div>

            <div className="space-y-2.5 text-xs">
              <div className="flex">
                <span className="w-36 text-slate-500 font-medium">Họ tên người nộp/nhận:</span>
                <span className="font-bold flex-1">{printingTx.partnerName}</span>
              </div>
              <div className="flex">
                <span className="w-36 text-slate-500 font-medium">Lý do thu/chi:</span>
                <span className="flex-1">{printingTx.reason}</span>
              </div>
              <div className="flex">
                <span className="w-36 text-slate-500 font-medium">Số tiền:</span>
                <span className="font-bold text-sm text-emerald-600">
                  {printingTx.amount.toLocaleString('vi-VN')} đ
                </span>
              </div>
              <div className="flex">
                <span className="w-36 text-slate-500 font-medium">Viết bằng chữ:</span>
                <span className="italic flex-1">{printingTx.amountInWords}</span>
              </div>
              <div className="flex">
                <span className="w-36 text-slate-500 font-medium">Tài khoản/Quỹ:</span>
                <span className="flex-1">{printingTx.channel}</span>
              </div>
              {printingTx.referenceDocCode && (
                <div className="flex">
                  <span className="w-36 text-slate-500 font-medium">Kèm theo chứng từ:</span>
                  <span className="flex-1 font-mono font-bold">{printingTx.referenceDocCode}</span>
                </div>
              )}
            </div>

            {/* 4 Chữ ký */}
            <div className="grid grid-cols-4 gap-2 text-center pt-6 text-xs">
              <div>
                <span className="font-bold block">Giám đốc</span>
                <span className="text-[10px] text-slate-400 block">(Ký, họ tên)</span>
                <div className="h-12 flex items-center justify-center font-serif italic text-slate-400">
                  Đặng Tuấn Anh
                </div>
              </div>
              <div>
                <span className="font-bold block">Kế toán trưởng</span>
                <span className="text-[10px] text-slate-400 block">(Ký, họ tên)</span>
                <div className="h-12 flex items-center justify-center font-serif italic text-slate-400">
                  Vũ Hoàng Yến
                </div>
              </div>
              <div>
                <span className="font-bold block">Thủ quỹ</span>
                <span className="text-[10px] text-slate-400 block">(Ký, họ tên)</span>
                <div className="h-12 flex items-center justify-center font-serif italic text-slate-400">
                  Lê Mai Anh
                </div>
              </div>
              <div>
                <span className="font-bold block">Người nộp/nhận</span>
                <span className="text-[10px] text-slate-400 block">(Ký, họ tên)</span>
                <div className="h-12 flex items-center justify-center font-serif italic text-slate-400">
                  (Đã ký)
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-4 border-t">
              <button
                type="button"
                onClick={() => setPrintingTx(null)}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 hover:bg-slate-100"
              >
                Đóng
              </button>
              <button
                type="button"
                onClick={() => {
                  showToast('Lệnh in', 'Đã chuyển phiếu thu/chi ra máy in biểu mẫu');
                  setPrintingTx(null);
                }}
                className="px-4 py-2 text-xs font-medium rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white flex items-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" />
                In phiếu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
