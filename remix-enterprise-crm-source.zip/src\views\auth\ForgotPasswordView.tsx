/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import {
  KeyRound,
  Building2,
  Mail,
  ArrowRight,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';

export const ForgotPasswordView: React.FC = () => {
  const { requestPasswordReset, setAuthScreenMode, rememberCompanyCode } = useMultiTenant();

  const [companyCode, setCompanyCode] = useState(rememberCompanyCode || '');
  const [email, setEmail] = useState('');
  const [result, setResult] = useState<{ success: boolean; hasSmtp: boolean; message: string } | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyCode.trim() || !email.trim()) return;
    const res = requestPasswordReset(companyCode, email);
    setResult(res);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-[#001738] to-[#000d1e] text-slate-100 flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
      <div className="sm:mx-auto sm:w-full sm:max-w-md relative z-10">
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-orange-500 shadow-lg shadow-orange-500/25 mb-3">
            <KeyRound className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">
            Khôi Phục Mật Khẩu
          </h1>
          <p className="mt-1 text-xs text-slate-400">
            Nhập mã công ty và địa chỉ email đã đăng ký tài khoản của bạn
          </p>
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-6 sm:p-8 shadow-2xl">
          {result ? (
            <div className="space-y-4">
              {result.hasSmtp ? (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-3">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="font-bold text-sm text-white mb-1">Đã Gửi Liên Kết!</h3>
                    <p className="leading-relaxed">{result.message}</p>
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-2">
                  <div className="flex items-center gap-2 font-bold text-sm text-white">
                    <HelpCircle className="w-5 h-5 text-amber-400 shrink-0" />
                    <span>Hướng Dẫn Liên Hệ Quản Trị Viên</span>
                  </div>
                  <p className="leading-relaxed">{result.message}</p>
                  <div className="p-2.5 rounded-lg bg-black/30 border border-white/10 text-[11px] text-slate-300">
                    💡 <strong>Gợi ý:</strong> Quản trị viên của công ty bạn có thể vào{' '}
                    <em>Cài đặt hệ thống &gt; Người dùng &gt; Chi tiết tài khoản</em> và bấm nút{' '}
                    <strong>"Tạo liên kết đặt lại mật khẩu"</strong> để cấp lại mật khẩu ngay cho bạn.
                  </div>
                </div>
              )}

              <button
                type="button"
                onClick={() => setAuthScreenMode('LOGIN')}
                className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all mt-3"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Quay lại trang Đăng nhập</span>
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Mã công ty (Company Code) *
                </label>
                <div className="relative">
                  <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={companyCode}
                    onChange={(e) => setCompanyCode(e.target.value.toLowerCase().trim())}
                    placeholder="demo hoặc cty-b"
                    required
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-white/10 bg-black/20 text-white placeholder-slate-500 font-mono focus:outline-hidden focus:border-blue-400"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-semibold mb-1">
                  Địa chỉ Email đăng nhập *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@apluscorp.vn"
                    required
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl border border-white/10 bg-black/20 text-white placeholder-slate-500 focus:outline-hidden focus:border-blue-400"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-bold text-xs shadow-lg shadow-orange-500/20 flex items-center justify-center gap-2 transition-all mt-2"
              >
                <span>Yêu Cầu Đặt Lại Mật Khẩu</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => setAuthScreenMode('LOGIN')}
                  className="text-xs text-slate-400 hover:text-slate-200 inline-flex items-center gap-1.5 transition-colors"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Quay lại trang Đăng nhập</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
