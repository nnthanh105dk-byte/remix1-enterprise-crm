import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { SCREEN_DETAILED_SPECS } from '../../data/specificationData';
import { X, FileCode, CheckCircle, ShieldCheck, Smartphone, Database, Server, Copy, Check } from 'lucide-react';

export const ScreenSpecModal: React.FC = () => {
  const { inspectingScreenCode, closeScreenSpec, language, t } = useCRM();
  const [copiedEndpoint, setCopiedEndpoint] = useState<string | null>(null);

  if (!inspectingScreenCode) return null;

  const spec = SCREEN_DETAILED_SPECS.find((s) => s.code === inspectingScreenCode);
  if (!spec) return null;

  const isVi = language === 'vi';

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedEndpoint(text);
    setTimeout(() => setCopiedEndpoint(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2.5 sm:p-6 bg-slate-950/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl max-h-[92vh] sm:max-h-[90vh] bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 sm:py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-800/50">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <div className="p-2 rounded-xl bg-blue-600/10 text-blue-600 dark:bg-blue-500/20 dark:text-blue-400 shrink-0">
              <FileCode className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="text-[10px] sm:text-xs font-mono px-1.5 py-0.5 rounded bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold">
                  {spec.code}
                </span>
                <span className="text-[11px] sm:text-xs text-blue-600 dark:text-blue-400 font-medium truncate">
                  {isVi ? 'Đặc tả Kỹ thuật Chuẩn' : 'Production Specification'}
                </span>
              </div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-slate-100 mt-0.5 truncate">
                {isVi ? spec.nameVi : spec.nameEn}
              </h3>
            </div>
          </div>
          <button
            onClick={closeScreenSpec}
            className="p-1.5 sm:p-2 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 sm:space-y-6 text-sm text-slate-700 dark:text-slate-300">
          {/* Purpose & UI Layout */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                {isVi ? 'Mục đích Màn hình (Purpose)' : 'Screen Purpose'}
              </h4>
              <p className="text-xs leading-relaxed text-slate-800 dark:text-slate-200">
                {isVi ? spec.purposeVi : spec.purposeEn}
              </p>
            </div>
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                {isVi ? 'Bố cục Giao diện (UI Layout)' : 'UI Layout'}
              </h4>
              <p className="text-xs leading-relaxed text-slate-800 dark:text-slate-200">
                {isVi ? spec.uiLayoutVi : spec.uiLayoutEn}
              </p>
            </div>
          </div>

          {/* User Actions & Components */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-3 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4" />
                {isVi ? 'Tác vụ Người dùng (User Actions)' : 'User Actions'}
              </h4>
              <ul className="space-y-1.5">
                {(isVi ? spec.userActionsVi : spec.userActionsEn).map((action, idx) => (
                  <li key={idx} className="text-xs flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-1.5 shrink-0" />
                    <span>{action}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-purple-600 dark:text-purple-400 mb-3 flex items-center gap-1.5">
                <Database className="w-4 h-4" />
                {isVi ? 'Thành phần Giao diện (Components)' : 'Components'}
              </h4>
              <ul className="space-y-1.5">
                {(isVi ? spec.componentsVi : spec.componentsEn).map((comp, idx) => (
                  <li key={idx} className="text-xs flex items-start gap-2 font-mono">
                    <span className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-1.5 shrink-0" />
                    <span>{comp}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Data Fields & Validation Rules */}
          <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            <div className="px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                {isVi ? 'Cấu trúc Trường Dữ liệu & Ràng buộc (Data Fields & Schema)' : 'Data Fields & Schema'}
              </h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-100/70 dark:bg-slate-800/40 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="py-2.5 px-4 font-mono">Field Key</th>
                    <th className="py-2.5 px-4">{isVi ? 'Tên hiển thị' : 'Label'}</th>
                    <th className="py-2.5 px-4">{isVi ? 'Kiểu dữ liệu' : 'Type'}</th>
                    <th className="py-2.5 px-4">{isVi ? 'Bắt buộc' : 'Required'}</th>
                    <th className="py-2.5 px-4">{isVi ? 'Quy tắc Kiểm tra (Validation)' : 'Validation'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {spec.dataFields.map((field, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                      <td className="py-2 px-4 font-mono text-blue-600 dark:text-blue-400 font-medium">{field.field}</td>
                      <td className="py-2 px-4">{isVi ? field.labelVi : field.labelEn}</td>
                      <td className="py-2 px-4 font-mono text-slate-500">{field.type}</td>
                      <td className="py-2 px-4">
                        {field.required ? (
                          <span className="text-rose-600 font-bold">* Required</span>
                        ) : (
                          <span className="text-slate-400">Optional</span>
                        )}
                      </td>
                      <td className="py-2 px-4 font-mono text-slate-600 dark:text-slate-300">{field.validation}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* API Endpoints */}
          <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
            <div className="px-4 py-3 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-600" />
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                {isVi ? 'Tích hợp API RESTful (Endpoints)' : 'API Endpoints Integration'}
              </h4>
            </div>
            <div className="p-4 space-y-3">
              {spec.apiIntegration.map((api, idx) => (
                <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 p-3 rounded-lg bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${
                        api.method === 'GET'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-900/60 dark:text-blue-300'
                          : api.method === 'POST'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/60 dark:text-emerald-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-900/60 dark:text-amber-300'
                      }`}
                    >
                      {api.method}
                    </span>
                    <span className="font-mono text-xs font-medium text-slate-900 dark:text-slate-100">
                      {api.endpoint}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-xs text-slate-600 dark:text-slate-400">
                      {isVi ? api.descriptionVi : api.descriptionEn}
                    </span>
                    <button
                      onClick={() => copyToClipboard(api.endpoint)}
                      className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                      title="Copy endpoint"
                    >
                      {copiedEndpoint === api.endpoint ? (
                        <Check className="w-4 h-4 text-emerald-500" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* RBAC & Mobile Responsive */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-amber-50/40 dark:bg-amber-950/20 border border-amber-200/80 dark:border-amber-900/40">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-800 dark:text-amber-300 mb-2 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-amber-600" />
                {isVi ? 'Quy tắc Phân quyền (RBAC Rules)' : 'RBAC Permission Rules'}
              </h4>
              <ul className="space-y-1 text-xs text-amber-900 dark:text-amber-200">
                {(isVi ? spec.permissionRulesVi : spec.permissionRulesEn).map((rule, idx) => (
                  <li key={idx}>• {rule}</li>
                ))}
              </ul>
            </div>

            <div className="p-4 rounded-xl bg-sky-50/40 dark:bg-sky-950/20 border border-sky-200/80 dark:border-sky-900/40">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-sky-800 dark:text-sky-300 mb-2 flex items-center gap-1.5">
                <Smartphone className="w-4 h-4 text-sky-600" />
                {isVi ? 'Tương thích Di động (Responsive Rules)' : 'Mobile Responsive Rules'}
              </h4>
              <ul className="space-y-1 text-xs text-sky-900 dark:text-sky-200">
                {(isVi ? spec.mobileResponsiveRulesVi : spec.mobileResponsiveRulesEn).map((rule, idx) => (
                  <li key={idx}>• {rule}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40">
          <span className="text-xs text-slate-500">
            {isVi ? 'Chuẩn hóa thiết kế cho React + Tailwind CSS' : 'Standardized for React & Tailwind CSS'}
          </span>
          <button
            onClick={closeScreenSpec}
            className="px-4 py-2 text-xs font-medium rounded-lg bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 transition-colors"
          >
            {t.close}
          </button>
        </div>
      </div>
    </div>
  );
};
