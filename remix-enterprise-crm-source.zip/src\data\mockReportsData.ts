export interface SalesTeam {
  id: string;
  name: string;
  leader: string;
  region: 'Miền Bắc' | 'Miền Nam' | 'Toàn quốc';
  memberCount: number;
  monthlyQuota: number;
}

export interface MockSalesRep {
  id: string;
  name: string;
  avatar: string;
  teamId: string;
  teamName: string;
  region: 'Miền Bắc' | 'Miền Trung' | 'Miền Nam' | 'Toàn quốc';
  monthlyQuota: number; // Mục tiêu tháng (VND)
  actualRevenue: number; // Doanh thu thực tế (VND)
  collectedRevenue: number; // Doanh thu thực thu tiền mặt (VND)
  wonDealsCount: number;
  totalDeals: number;
  callsCount: number;
  meetingsCount: number;
  completedTasksCount: number;
  manualForecastOverride?: number; // Override từ trưởng phòng
  overrideAuthor?: string;
  overrideTime?: string;
}

export interface MockWonDeal {
  id: string;
  code: string;
  title: string;
  customerName: string;
  customerCompany: string;
  value: number; // VND
  repId: string;
  repName: string;
  teamId: string;
  teamName: string;
  region: 'Miền Bắc' | 'Miền Trung' | 'Miền Nam' | 'Toàn quốc';
  createdAt: string;
  wonDate: string;
  cycleDays: number;
  productName: string;
  source: 'Facebook' | 'Zalo' | 'Website' | 'Giới thiệu' | 'Hotline' | 'Triển lãm' | 'Khác';
  isCollected: boolean; // Thực thu
}

export interface MockLostDeal {
  id: string;
  code: string;
  title: string;
  customerName: string;
  customerCompany: string;
  value: number; // VND
  repId: string;
  repName: string;
  teamId: string;
  teamName: string;
  region: 'Miền Bắc' | 'Miền Trung' | 'Miền Nam' | 'Toàn quốc';
  lostDate: string;
  lostStage: 'Khám phá nhu cầu' | 'Báo giá & Đề xuất' | 'Đàm phán';
  lossReason: 'Giá cao hơn kỳ vọng' | 'Đối thủ cạnh tranh thắng' | 'Chưa có ngân sách' | 'Không phản hồi / Mất liên lạc' | 'Dự án hoãn vô thời hạn' | 'Khác';
  competitor?: string;
  productName: string;
  source: 'Facebook' | 'Zalo' | 'Website' | 'Giới thiệu' | 'Hotline' | 'Triển lãm' | 'Khác';
}

export interface MockPipelineDeal {
  id: string;
  code: string;
  title: string;
  customerName: string;
  customerCompany: string;
  amount: number;
  probability: number; // %
  stage: 'Lead mới' | 'Liên hệ' | 'Khám phá nhu cầu' | 'Báo giá & Đề xuất' | 'Đàm phán';
  forecastCategory: 'commit' | 'best_case' | 'pipeline';
  repId: string;
  repName: string;
  teamId: string;
  expectedCloseDate: string;
  dwellDaysInStage: number;
  productName: string;
  region: 'Miền Bắc' | 'Miền Trung' | 'Miền Nam' | 'Toàn quốc';
  isStagnant: boolean; // Đứng quá lâu (>14 ngày trong giai đoạn)
}

export interface MockLeadAnalysis {
  id: string;
  code: string;
  name: string;
  phone: string;
  email: string;
  company: string;
  source: 'Facebook' | 'Zalo' | 'Website' | 'Giới thiệu' | 'Hotline' | 'Triển lãm' | 'Khác';
  status: 'Mới tạo' | 'Đã liên hệ' | 'Đã thẩm định' | 'Chuyển đổi thành Cơ hội' | 'Không tiềm năng';
  createdAt: string;
  firstResponseMinutes: number; // Thời gian phản hồi đầu tiên (phút)
  repId?: string;
  repName?: string;
  teamId?: string;
  unassigned: boolean;
  isStagnant: boolean; // Quá 24h chưa xử lý
  campaignCost?: number;
}

export const MOCK_SALES_TEAMS: SalesTeam[] = [
  { id: 'team-north', name: 'Đội Sales Miền Bắc', leader: 'Trần Anh Tuấn', region: 'Miền Bắc', memberCount: 5, monthlyQuota: 1800000000 },
  { id: 'team-south', name: 'Đội Sales Miền Nam', leader: 'Lê Hoàng Yến', region: 'Miền Nam', memberCount: 5, monthlyQuota: 2200000000 },
  { id: 'team-b2b', name: 'Đội Enterprise B2B', leader: 'Nguyễn Văn Hùng', region: 'Toàn quốc', memberCount: 3, monthlyQuota: 3500000000 },
  { id: 'team-tele', name: 'Đội Telesales & SME', leader: 'Phạm Minh Tâm', region: 'Toàn quốc', memberCount: 3, monthlyQuota: 1000000000 },
];

export const MOCK_SALES_REPS: MockSalesRep[] = [
  // Miền Bắc
  { id: 'rep-01', name: 'Trần Anh Tuấn', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', monthlyQuota: 500000000, actualRevenue: 560000000, collectedRevenue: 510000000, wonDealsCount: 7, totalDeals: 12, callsCount: 142, meetingsCount: 28, completedTasksCount: 45 },
  { id: 'rep-02', name: 'Đỗ Thùy Trang', avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=100', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', monthlyQuota: 400000000, actualRevenue: 420000000, collectedRevenue: 380000000, wonDealsCount: 5, totalDeals: 10, callsCount: 165, meetingsCount: 22, completedTasksCount: 38 },
  { id: 'rep-03', name: 'Nguyễn Đức Minh', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', monthlyQuota: 350000000, actualRevenue: 230000000, collectedRevenue: 190000000, wonDealsCount: 3, totalDeals: 9, callsCount: 110, meetingsCount: 14, completedTasksCount: 25 },
  { id: 'rep-04', name: 'Vũ Thị Ngọc', avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', monthlyQuota: 300000000, actualRevenue: 310000000, collectedRevenue: 280000000, wonDealsCount: 4, totalDeals: 8, callsCount: 130, meetingsCount: 19, completedTasksCount: 32 },
  { id: 'rep-05', name: 'Hoàng Quốc Việt', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', monthlyQuota: 250000000, actualRevenue: 155000000, collectedRevenue: 120000000, wonDealsCount: 2, totalDeals: 7, callsCount: 88, meetingsCount: 11, completedTasksCount: 20 },

  // Miền Nam
  { id: 'rep-06', name: 'Lê Hoàng Yến', avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', monthlyQuota: 600000000, actualRevenue: 680000000, collectedRevenue: 620000000, wonDealsCount: 8, totalDeals: 14, callsCount: 180, meetingsCount: 35, completedTasksCount: 52 },
  { id: 'rep-07', name: 'Phan Quốc Bảo', avatar: 'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=100', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', monthlyQuota: 500000000, actualRevenue: 530000000, collectedRevenue: 490000000, wonDealsCount: 6, totalDeals: 11, callsCount: 155, meetingsCount: 26, completedTasksCount: 41 },
  { id: 'rep-08', name: 'Trịnh Mai Phương', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=100', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', monthlyQuota: 450000000, actualRevenue: 480000000, collectedRevenue: 440000000, wonDealsCount: 5, totalDeals: 9, callsCount: 140, meetingsCount: 24, completedTasksCount: 36 },
  { id: 'rep-09', name: 'Dương Tấn Đạt', avatar: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=100', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', monthlyQuota: 350000000, actualRevenue: 240000000, collectedRevenue: 210000000, wonDealsCount: 3, totalDeals: 8, callsCount: 95, meetingsCount: 16, completedTasksCount: 24 },
  { id: 'rep-10', name: 'Bùi Kim Ngân', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', monthlyQuota: 300000000, actualRevenue: 290000000, collectedRevenue: 260000000, wonDealsCount: 4, totalDeals: 7, callsCount: 125, meetingsCount: 18, completedTasksCount: 30 },

  // Enterprise B2B
  { id: 'rep-11', name: 'Nguyễn Văn Hùng', avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100', teamId: 'team-b2b', teamName: 'Đội Enterprise B2B', region: 'Toàn quốc', monthlyQuota: 1500000000, actualRevenue: 1750000000, collectedRevenue: 1600000000, wonDealsCount: 4, totalDeals: 7, callsCount: 95, meetingsCount: 32, completedTasksCount: 40 },
  { id: 'rep-12', name: 'Đặng Thanh Tùng', avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=100', teamId: 'team-b2b', teamName: 'Đội Enterprise B2B', region: 'Toàn quốc', monthlyQuota: 1100000000, actualRevenue: 980000000, collectedRevenue: 850000000, wonDealsCount: 3, totalDeals: 6, callsCount: 82, meetingsCount: 25, completedTasksCount: 33 },
  { id: 'rep-13', name: 'Lê Thu Hương', avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=100', teamId: 'team-b2b', teamName: 'Đội Enterprise B2B', region: 'Toàn quốc', monthlyQuota: 900000000, actualRevenue: 620000000, collectedRevenue: 550000000, wonDealsCount: 2, totalDeals: 5, callsCount: 76, meetingsCount: 20, completedTasksCount: 28 },

  // Telesales & SME
  { id: 'rep-14', name: 'Phạm Minh Tâm', avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=100', teamId: 'team-tele', teamName: 'Đội Telesales & SME', region: 'Toàn quốc', monthlyQuota: 400000000, actualRevenue: 430000000, collectedRevenue: 410000000, wonDealsCount: 11, totalDeals: 20, callsCount: 320, meetingsCount: 15, completedTasksCount: 65 },
  { id: 'rep-15', name: 'Ngô Hải Yến', avatar: 'https://images.unsplash.com/photo-1567532939604-b6b5b0db2604?w=100', teamId: 'team-tele', teamName: 'Đội Telesales & SME', region: 'Toàn quốc', monthlyQuota: 300000000, actualRevenue: 310000000, collectedRevenue: 290000000, wonDealsCount: 9, totalDeals: 18, callsCount: 295, meetingsCount: 12, completedTasksCount: 58 },
  { id: 'rep-16', name: 'Lý Quốc Cường', avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?w=100', teamId: 'team-tele', teamName: 'Đội Telesales & SME', region: 'Toàn quốc', monthlyQuota: 300000000, actualRevenue: 195000000, collectedRevenue: 180000000, wonDealsCount: 5, totalDeals: 16, callsCount: 240, meetingsCount: 8, completedTasksCount: 42 },
];

export const MOCK_WON_DEALS: MockWonDeal[] = [
  { id: 'wd-01', code: 'DEAL-WON-2026-001', title: 'Hệ thống A+ Enterprise CRM 250 Users', customerName: 'Ông Đoàn Nguyên Đức', customerCompany: 'Tập đoàn Hoàng Anh Gia Lai', value: 850000000, repId: 'rep-11', repName: 'Nguyễn Văn Hùng', teamId: 'team-b2b', teamName: 'Đội Enterprise B2B', region: 'Miền Nam', createdAt: '2026-08-10', wonDate: '2026-09-28', cycleDays: 49, productName: 'Gói Enterprise CRM', source: 'Giới thiệu', isCollected: true },
  { id: 'wd-02', code: 'DEAL-WON-2026-002', title: 'Triển khai ERP Cloud & Quản lý Kho', customerName: 'Bà Nguyễn Thị Mai', customerCompany: 'Công ty CP May Sông Hồng', value: 520000000, repId: 'rep-01', repName: 'Trần Anh Tuấn', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', createdAt: '2026-08-20', wonDate: '2026-09-25', cycleDays: 36, productName: 'Giải pháp ERP Cloud', source: 'Website', isCollected: true },
  { id: 'wd-03', code: 'DEAL-WON-2026-003', title: 'Phân hệ Kho Vận WMS Đa Chi Nhánh', customerName: 'Ông Phạm Nhật Vũ', customerCompany: 'Logistics Toàn Cầu Giao Hàng Xanh', value: 380000000, repId: 'rep-06', repName: 'Lê Hoàng Yến', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', createdAt: '2026-09-01', wonDate: '2026-09-30', cycleDays: 29, productName: 'Module Kho Vận WMS', source: 'Hotline', isCollected: true },
  { id: 'wd-04', code: 'DEAL-WON-2026-004', title: 'Nền tảng Tích hợp API Ngân hàng & ERP', customerName: 'Bà Trần Kim Oanh', customerCompany: 'Chuỗi Bán Lẻ Con Cưng', value: 450000000, repId: 'rep-12', repName: 'Đặng Thanh Tùng', teamId: 'team-b2b', teamName: 'Đội Enterprise B2B', region: 'Toàn quốc', createdAt: '2026-08-15', wonDate: '2026-09-22', cycleDays: 38, productName: 'Dịch vụ Tích hợp API', source: 'Facebook', isCollected: true },
  { id: 'wd-05', code: 'DEAL-WON-2026-005', title: 'A+ Sales & Chăm sóc khách hàng tự động', customerName: 'Ông Võ Văn Thưởng', customerCompany: 'Bất động sản Hưng Thịnh Corp', value: 290000000, repId: 'rep-07', repName: 'Phan Quốc Bảo', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', createdAt: '2026-09-05', wonDate: '2026-09-29', cycleDays: 24, productName: 'Gói Chăm sóc Khách hàng', source: 'Zalo', isCollected: false },
  { id: 'wd-06', code: 'DEAL-WON-2026-006', title: 'Cổng Portal Khách hàng B2B & Báo giá', customerName: 'Bà Đặng Thị Ngọc', customerCompany: 'Thép Pomina Miền Trung', value: 340000000, repId: 'rep-02', repName: 'Đỗ Thùy Trang', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Trung', createdAt: '2026-08-25', wonDate: '2026-09-26', cycleDays: 32, productName: 'Cổng Portal B2B', source: 'Triển lãm', isCollected: true },
  { id: 'wd-07', code: 'DEAL-WON-2026-007', title: 'Gói Bản quyền CRM Chuẩn SME (30 Users)', customerName: 'Ông Lê Hùng', customerCompany: 'Dược phẩm Tâm Bình', value: 165000000, repId: 'rep-14', repName: 'Phạm Minh Tâm', teamId: 'team-tele', teamName: 'Đội Telesales & SME', region: 'Miền Bắc', createdAt: '2026-09-12', wonDate: '2026-09-27', cycleDays: 15, productName: 'Gói Enterprise CRM', source: 'Website', isCollected: true },
  { id: 'wd-08', code: 'DEAL-WON-2026-008', title: 'Nâng cấp bảo trì hệ thống & SLA 24/7', customerName: 'Bà Mai Thị Liên', customerCompany: 'Bao bì Nhựa Rạng Đông', value: 120000000, repId: 'rep-15', repName: 'Ngô Hải Yến', teamId: 'team-tele', teamName: 'Đội Telesales & SME', region: 'Miền Nam', createdAt: '2026-09-10', wonDate: '2026-09-24', cycleDays: 14, productName: 'Gói Chăm sóc Khách hàng', source: 'Zalo', isCollected: true },
  { id: 'wd-09', code: 'DEAL-WON-2026-009', title: 'Phần mềm Quản lý Sales & Hoa hồng', customerName: 'Ông Cao Văn Sơn', customerCompany: 'Thiết bị Y tế Phương Đông', value: 210000000, repId: 'rep-08', repName: 'Trịnh Mai Phương', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', createdAt: '2026-08-30', wonDate: '2026-09-28', cycleDays: 29, productName: 'Gói Enterprise CRM', source: 'Facebook', isCollected: true },
  { id: 'wd-10', code: 'DEAL-WON-2026-010', title: 'Hệ thống Quản lý Hợp đồng Điện tử eContract', customerName: 'Bà Trần Thị Dung', customerCompany: 'Bảo hiểm Quân đội MIC', value: 310000000, repId: 'rep-03', repName: 'Vũ Đức Thịnh', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', createdAt: '2026-08-15', wonDate: '2026-09-21', cycleDays: 37, productName: 'Gói Enterprise CRM', source: 'Giới thiệu', isCollected: true },
  { id: 'wd-11', code: 'DEAL-WON-2026-011', title: 'Dịch vụ Đào tạo Quản trị & Tối ưu hóa Sales Pipeline', customerName: 'Ông Hoàng Nam', customerCompany: 'Tập đoàn Dabaco', value: 175000000, repId: 'rep-04', repName: 'Lê Minh Khôi', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', createdAt: '2026-08-22', wonDate: '2026-09-24', cycleDays: 33, productName: 'Gói Chăm sóc Khách hàng', source: 'Website', isCollected: true },
  { id: 'wd-12', code: 'DEAL-WON-2026-012', title: 'Quản lý kho và mã vạch Barcode RFID', customerName: 'Bà Ngô Thị Tuyết', customerCompany: 'Chuỗi Cửa hàng Sách Fahasa', value: 260000000, repId: 'rep-10', repName: 'Bùi Kim Ngân', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', createdAt: '2026-08-28', wonDate: '2026-09-26', cycleDays: 29, productName: 'Module Kho Vận WMS', source: 'Website', isCollected: false },
  { id: 'wd-13', code: 'DEAL-WON-2026-013', title: 'Hệ thống Quản lý Kênh Phân phối B2B Toàn quốc', customerName: 'Ông Đặng Lê Nguyên Vũ', customerCompany: 'Tập đoàn Cà phê Trung Nguyên', value: 680000000, repId: 'rep-11', repName: 'Nguyễn Văn Hùng', teamId: 'team-b2b', teamName: 'Đội Enterprise B2B', region: 'Toàn quốc', createdAt: '2026-08-05', wonDate: '2026-10-02', cycleDays: 58, productName: 'Gói Enterprise CRM', source: 'Giới thiệu', isCollected: true },
  { id: 'wd-14', code: 'DEAL-WON-2026-014', title: 'Triển khai CRM Khách hàng Bất động sản Nghỉ dưỡng', customerName: 'Bà Lê Thị Thu Thủy', customerCompany: 'Tập đoàn Vingroup (Vinhomes)', value: 1250000000, repId: 'rep-01', repName: 'Trần Anh Tuấn', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', createdAt: '2026-07-20', wonDate: '2026-10-01', cycleDays: 73, productName: 'Gói Enterprise CRM', source: 'Hotline', isCollected: true },
  { id: 'wd-15', code: 'DEAL-WON-2026-015', title: 'Giải pháp Quản lý Kho Dược & Chuỗi Nhà thuốc', customerName: 'Dược sĩ Nguyễn Văn Hiếu', customerCompany: 'Hệ thống Nhà thuốc Pharmacity', value: 490000000, repId: 'rep-06', repName: 'Lê Hoàng Yến', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', createdAt: '2026-08-18', wonDate: '2026-10-03', cycleDays: 46, productName: 'Module Kho Vận WMS', source: 'Website', isCollected: true },
  { id: 'wd-16', code: 'DEAL-WON-2026-016', title: 'Cổng Báo giá & Đấu thầu Xây dựng Công nghiệp', customerName: 'Ông Nguyễn Bá Dương', customerCompany: 'Công ty Cổ phần Xây dựng Coteccons', value: 580000000, repId: 'rep-12', repName: 'Đặng Thanh Tùng', teamId: 'team-b2b', teamName: 'Đội Enterprise B2B', region: 'Toàn quốc', createdAt: '2026-08-12', wonDate: '2026-09-30', cycleDays: 49, productName: 'Cổng Portal B2B', source: 'Triển lãm', isCollected: true },
  { id: 'wd-17', code: 'DEAL-WON-2026-017', title: 'Phần mềm Telesales & Đăng ký Lái thử Xe Điện', customerName: 'Bà Nguyễn Thị Vân Anh', customerCompany: 'VinFast Auto Miền Bắc', value: 390000000, repId: 'rep-14', repName: 'Phạm Minh Tâm', teamId: 'team-tele', teamName: 'Đội Telesales & SME', region: 'Miền Bắc', createdAt: '2026-09-01', wonDate: '2026-10-04', cycleDays: 33, productName: 'Gói Chăm sóc Khách hàng', source: 'Facebook', isCollected: true },
  { id: 'wd-18', code: 'DEAL-WON-2026-018', title: 'Module Tích hợp Logistics Đa Sàn Thương mại', customerName: 'Ông Trần Hải Linh', customerCompany: 'Sendo Smart Logistics', value: 310000000, repId: 'rep-07', repName: 'Phan Quốc Bảo', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', createdAt: '2026-08-25', wonDate: '2026-10-02', cycleDays: 38, productName: 'Module Kho Vận WMS', source: 'Zalo', isCollected: true },
];

export const MOCK_LOST_DEALS: MockLostDeal[] = [
  { id: 'ld-01', code: 'DEAL-LOST-2026-001', title: 'Phần mềm Quản lý Bán buôn & Phân phối', customerName: 'Ông Vũ Văn Tiền', customerCompany: 'Tập đoàn Geleximco', value: 650000000, repId: 'rep-01', repName: 'Trần Anh Tuấn', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', lostDate: '2026-09-27', lostStage: 'Đàm phán', lossReason: 'Đối thủ cạnh tranh thắng', competitor: 'Base.vn', productName: 'Gói Enterprise CRM', source: 'Website' },
  { id: 'ld-02', code: 'DEAL-LOST-2026-002', title: 'Giải pháp ERP Quản lý Sản xuất Gỗ', customerName: 'Bà Huỳnh Thị Nga', customerCompany: 'Tập đoàn Gỗ An Cường', value: 890000000, repId: 'rep-11', repName: 'Nguyễn Văn Hùng', teamId: 'team-b2b', teamName: 'Đội Enterprise B2B', region: 'Miền Nam', lostDate: '2026-09-20', lostStage: 'Báo giá & Đề xuất', lossReason: 'Giá cao hơn kỳ vọng', competitor: 'FPT Software', productName: 'Giải pháp ERP Cloud', source: 'Giới thiệu' },
  { id: 'ld-03', code: 'DEAL-LOST-2026-003', title: 'Cổng Quản trị Vận tải & Giao nhận', customerName: 'Ông Trương Gia Bình', customerCompany: 'Công ty Cổ phần Vận tải Á Châu', value: 420000000, repId: 'rep-06', repName: 'Lê Hoàng Yến', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', lostDate: '2026-09-25', lostStage: 'Đàm phán', lossReason: 'Chưa có ngân sách', competitor: undefined, productName: 'Module Kho Vận WMS', source: 'Hotline' },
  { id: 'ld-04', code: 'DEAL-LOST-2026-004', title: 'Phần mềm CRM Chăm sóc Bệnh nhân Nha khoa', customerName: 'Bác sĩ Lê Thị Mai', customerCompany: 'Hệ thống Nha khoa Kim', value: 240000000, repId: 'rep-07', repName: 'Phan Quốc Bảo', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', lostDate: '2026-09-22', lostStage: 'Báo giá & Đề xuất', lossReason: 'Đối thủ cạnh tranh thắng', competitor: 'Viettel Solutions', productName: 'Gói Chăm sóc Khách hàng', source: 'Facebook' },
  { id: 'ld-05', code: 'DEAL-LOST-2026-005', title: 'Bản quyền CRM cho Văn phòng Luật sư', customerName: 'Luật sư Trần Văn An', customerCompany: 'Công ty Luật Vilaf', value: 180000000, repId: 'rep-03', repName: 'Nguyễn Đức Minh', teamId: 'team-north', teamName: 'Đội Sales Miền Bắc', region: 'Miền Bắc', lostDate: '2026-09-18', lostStage: 'Khám phá nhu cầu', lossReason: 'Không phản hồi / Mất liên lạc', competitor: undefined, productName: 'Gói Enterprise CRM', source: 'Website' },
  { id: 'ld-06', code: 'DEAL-LOST-2026-006', title: 'Tích hợp Hóa đơn điện tử và Phần mềm kế toán', customerName: 'Kế toán trưởng Nguyễn Thị Hoa', customerCompany: 'Dệt May Phong Phú', value: 310000000, repId: 'rep-13', repName: 'Lê Thu Hương', teamId: 'team-b2b', teamName: 'Đội Enterprise B2B', region: 'Toàn quốc', lostDate: '2026-09-15', lostStage: 'Báo giá & Đề xuất', lossReason: 'Dự án hoãn vô thời hạn', competitor: undefined, productName: 'Dịch vụ Tích hợp API', source: 'Triển lãm' },
  { id: 'ld-07', code: 'DEAL-LOST-2026-007', title: 'Gói Sales CRM cho Chuỗi Nhà thuốc', customerName: 'Dược sĩ Đinh Văn Hùng', customerCompany: 'Nhà thuốc An Khang', value: 350000000, repId: 'rep-08', repName: 'Trịnh Mai Phương', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', lostDate: '2026-09-26', lostStage: 'Đàm phán', lossReason: 'Giá cao hơn kỳ vọng', competitor: 'VNPT', productName: 'Gói Enterprise CRM', source: 'Zalo' },
  { id: 'ld-08', code: 'DEAL-LOST-2026-008', title: 'CRM Telesales cho Trung tâm Anh ngữ', customerName: 'Thầy David Miller', customerCompany: 'Hệ thống Anh ngữ VUS', value: 290000000, repId: 'rep-16', repName: 'Lý Quốc Cường', teamId: 'team-tele', teamName: 'Đội Telesales & SME', region: 'Toàn quốc', lostDate: '2026-09-12', lostStage: 'Khám phá nhu cầu', lossReason: 'Đối thủ cạnh tranh thắng', competitor: 'Fast Software', productName: 'Gói Enterprise CRM', source: 'Hotline' },
  { id: 'ld-09', code: 'DEAL-LOST-2026-009', title: 'Giải pháp CRM Đào tạo Trực tuyến E-learning', customerName: 'Bà Trần Mai Ly', customerCompany: 'Tổ chức Giáo dục Topica', value: 220000000, repId: 'rep-15', repName: 'Ngô Hải Yến', teamId: 'team-tele', teamName: 'Đội Telesales & SME', region: 'Toàn quốc', lostDate: '2026-09-29', lostStage: 'Báo giá & Đề xuất', lossReason: 'Chưa có ngân sách', competitor: undefined, productName: 'Gói Enterprise CRM', source: 'Website' },
  { id: 'ld-10', code: 'DEAL-LOST-2026-010', title: 'Hệ thống Chăm sóc Hội viên Phòng Gym & Spa', customerName: 'Ông Phan Thành Nam', customerCompany: 'California Fitness & Yoga', value: 380000000, repId: 'rep-09', repName: 'Dương Tấn Đạt', teamId: 'team-south', teamName: 'Đội Sales Miền Nam', region: 'Miền Nam', lostDate: '2026-09-28', lostStage: 'Đàm phán', lossReason: 'Đối thủ cạnh tranh thắng', competitor: 'Salesforce', productName: 'Gói Chăm sóc Khách hàng', source: 'Facebook' },
];

export const MOCK_PIPELINE_DEALS: MockPipelineDeal[] = [
  // Commit
  { id: 'pipe-01', code: 'PIPE-2026-101', title: 'Hợp đồng A+ CRM Enterprise 300 Users', customerName: 'Ông Trần Bá Dương', customerCompany: 'Tập đoàn THACO Trường Hải', amount: 980000000, probability: 90, stage: 'Đàm phán', forecastCategory: 'commit', repId: 'rep-11', repName: 'Nguyễn Văn Hùng', teamId: 'team-b2b', expectedCloseDate: '2026-10-15', dwellDaysInStage: 8, productName: 'Gói Enterprise CRM', region: 'Miền Nam', isStagnant: false },
  { id: 'pipe-02', code: 'PIPE-2026-102', title: 'ERP Quản lý Chuỗi Cung ứng Thủy sản', customerName: 'Bà Trương Thị Lệ Khanh', customerCompany: 'Vĩnh Hoàn Seafood Corp', amount: 720000000, probability: 85, stage: 'Đàm phán', forecastCategory: 'commit', repId: 'rep-06', repName: 'Lê Hoàng Yến', teamId: 'team-south', expectedCloseDate: '2026-10-20', dwellDaysInStage: 11, productName: 'Giải pháp ERP Cloud', region: 'Miền Nam', isStagnant: false },
  { id: 'pipe-03', code: 'PIPE-2026-103', title: 'Phần mềm Quản lý Kho Tổng & RFID', customerName: 'Ông Đặng Văn Thành', customerCompany: 'Tập đoàn Thành Thành Công (TTC)', amount: 540000000, probability: 85, stage: 'Đàm phán', forecastCategory: 'commit', repId: 'rep-07', repName: 'Phan Quốc Bảo', teamId: 'team-south', expectedCloseDate: '2026-10-18', dwellDaysInStage: 6, productName: 'Module Kho Vận WMS', region: 'Miền Nam', isStagnant: false },
  { id: 'pipe-04', code: 'PIPE-2026-104', title: 'Triển khai CRM cho Khối Bán lẻ Miền Bắc', customerName: 'Ông Phạm Đình Đoàn', customerCompany: 'Tập đoàn Phú Thái Holdings', amount: 480000000, probability: 80, stage: 'Đàm phán', forecastCategory: 'commit', repId: 'rep-01', repName: 'Trần Anh Tuấn', teamId: 'team-north', expectedCloseDate: '2026-10-25', dwellDaysInStage: 9, productName: 'Gói Enterprise CRM', region: 'Miền Bắc', isStagnant: false },
  { id: 'pipe-13', code: 'PIPE-2026-113', title: 'Hệ thống Quản lý Đội xe Vận chuyển Đa kênh', customerName: 'Ông Lương Trí Thìn', customerCompany: 'Đất Xanh Group Logistics', amount: 650000000, probability: 85, stage: 'Đàm phán', forecastCategory: 'commit', repId: 'rep-12', repName: 'Đặng Thanh Tùng', teamId: 'team-b2b', expectedCloseDate: '2026-10-22', dwellDaysInStage: 7, productName: 'Module Kho Vận WMS', region: 'Toàn quốc', isStagnant: false },

  // Best Case
  { id: 'pipe-05', code: 'PIPE-2026-105', title: 'Tích hợp API Cổng Thanh toán & CRM', customerName: 'Bà Nguyễn Thị Phương Thảo', customerCompany: 'HDBank & Vietjet', amount: 1200000000, probability: 60, stage: 'Báo giá & Đề xuất', forecastCategory: 'best_case', repId: 'rep-11', repName: 'Nguyễn Văn Hùng', teamId: 'team-b2b', expectedCloseDate: '2026-11-10', dwellDaysInStage: 16, productName: 'Dịch vụ Tích hợp API', region: 'Toàn quốc', isStagnant: true },
  { id: 'pipe-06', code: 'PIPE-2026-106', title: 'Chuyển đổi số Quy trình Sales B2B', customerName: 'Ông Hồ Hùng Anh', customerCompany: 'Tập đoàn Masan Consumer', amount: 850000000, probability: 65, stage: 'Báo giá & Đề xuất', forecastCategory: 'best_case', repId: 'rep-12', repName: 'Đặng Thanh Tùng', teamId: 'team-b2b', expectedCloseDate: '2026-11-05', dwellDaysInStage: 12, productName: 'Gói Enterprise CRM', region: 'Miền Bắc', isStagnant: false },
  { id: 'pipe-07', code: 'PIPE-2026-107', title: 'Phần mềm Quản trị Phân phối DMS & CRM', customerName: 'Bà Mai Kiều Liên', customerCompany: 'Vinamilk Việt Nam', amount: 950000000, probability: 60, stage: 'Báo giá & Đề xuất', forecastCategory: 'best_case', repId: 'rep-01', repName: 'Trần Anh Tuấn', teamId: 'team-north', expectedCloseDate: '2026-11-15', dwellDaysInStage: 19, productName: 'Gói Enterprise CRM', region: 'Miền Bắc', isStagnant: true },
  { id: 'pipe-08', code: 'PIPE-2026-108', title: 'Quản lý Dịch vụ Khách hàng & Bảo hành', customerName: 'Ông Nguyễn Đức Tài', customerCompany: 'Thế Giới Di Động (MWG)', amount: 620000000, probability: 55, stage: 'Báo giá & Đề xuất', forecastCategory: 'best_case', repId: 'rep-06', repName: 'Lê Hoàng Yến', teamId: 'team-south', expectedCloseDate: '2026-11-20', dwellDaysInStage: 14, productName: 'Gói Chăm sóc Khách hàng', region: 'Miền Nam', isStagnant: false },
  { id: 'pipe-14', code: 'PIPE-2026-114', title: 'Cổng Portal Khách hàng Đại lý Thép', customerName: 'Ông Trần Đình Long', customerCompany: 'Tập đoàn Hòa Phát', amount: 1100000000, probability: 65, stage: 'Báo giá & Đề xuất', forecastCategory: 'best_case', repId: 'rep-11', repName: 'Nguyễn Văn Hùng', teamId: 'team-b2b', expectedCloseDate: '2026-11-12', dwellDaysInStage: 10, productName: 'Cổng Portal B2B', region: 'Miền Bắc', isStagnant: false },

  // Pipeline
  { id: 'pipe-09', code: 'PIPE-2026-109', title: 'Giải pháp Chấm công, Nhân sự & CRM', customerName: 'Bà Cao Thị Ngọc Dung', customerCompany: 'Vàng bạc Đá quý PNJ', amount: 780000000, probability: 40, stage: 'Khám phá nhu cầu', forecastCategory: 'pipeline', repId: 'rep-07', repName: 'Phan Quốc Bảo', teamId: 'team-south', expectedCloseDate: '2026-12-05', dwellDaysInStage: 22, productName: 'Giải pháp ERP Cloud', region: 'Miền Nam', isStagnant: true },
  { id: 'pipe-10', code: 'PIPE-2026-110', title: 'Hệ thống Quản lý Bán hàng Đa kênh Omnichannel', customerName: 'Ông Trần Lệ Nguyên', customerCompany: 'Tập đoàn KIDO', amount: 490000000, probability: 35, stage: 'Khám phá nhu cầu', forecastCategory: 'pipeline', repId: 'rep-08', repName: 'Trịnh Mai Phương', teamId: 'team-south', expectedCloseDate: '2026-12-12', dwellDaysInStage: 18, productName: 'Gói Enterprise CRM', region: 'Miền Nam', isStagnant: true },
  { id: 'pipe-11', code: 'PIPE-2026-111', title: 'Portal Tra cứu Đơn hàng cho Đại lý', customerName: 'Ông Đặng Lê Nguyên Vũ', customerCompany: 'Tập đoàn Cà phê Trung Nguyên', amount: 530000000, probability: 30, stage: 'Liên hệ', forecastCategory: 'pipeline', repId: 'rep-13', repName: 'Lê Thu Hương', teamId: 'team-b2b', expectedCloseDate: '2026-12-20', dwellDaysInStage: 10, productName: 'Cổng Portal B2B', region: 'Toàn quốc', isStagnant: false },
  { id: 'pipe-12', code: 'PIPE-2026-112', title: 'Hệ thống Quản lý Hợp đồng Xuất nhập khẩu', customerName: 'Bà Nguyễn Thị Nga', customerCompany: 'Tập đoàn BRG Group', amount: 410000000, probability: 30, stage: 'Liên hệ', forecastCategory: 'pipeline', repId: 'rep-02', repName: 'Đỗ Thùy Trang', teamId: 'team-north', expectedCloseDate: '2026-12-15', dwellDaysInStage: 8, productName: 'Module Kho Vận WMS', region: 'Miền Bắc', isStagnant: false },
];

export const MOCK_LEADS_ANALYSIS: MockLeadAnalysis[] = [
  { id: 'lead-01', code: 'LEAD-2026-501', name: 'Nguyễn Văn Minh', phone: '0912 345 678', email: 'minh.nv@anphat.vn', company: 'Nhựa An Phát Xanh', source: 'Facebook', status: 'Mới tạo', createdAt: '2026-10-04 10:15', firstResponseMinutes: 18, repId: 'rep-01', repName: 'Trần Anh Tuấn', teamId: 'team-north', unassigned: false, isStagnant: false, campaignCost: 45000 },
  { id: 'lead-02', code: 'LEAD-2026-502', name: 'Trần Bích Thủy', phone: '0988 234 567', email: 'thuy.tb@sunhouse.com.vn', company: 'Tập đoàn Sunhouse', source: 'Website', status: 'Đã liên hệ', createdAt: '2026-10-04 09:30', firstResponseMinutes: 8, repId: 'rep-02', repName: 'Đỗ Thùy Trang', teamId: 'team-north', unassigned: false, isStagnant: false, campaignCost: 35000 },
  { id: 'lead-03', code: 'LEAD-2026-503', name: 'Lê Quang Huy', phone: '0903 888 999', email: 'huy.lq@thacogroup.vn', company: 'Cơ khí THACO Chu Lai', source: 'Giới thiệu', status: 'Chuyển đổi thành Cơ hội', createdAt: '2026-10-03 14:20', firstResponseMinutes: 12, repId: 'rep-11', repName: 'Nguyễn Văn Hùng', teamId: 'team-b2b', unassigned: false, isStagnant: false, campaignCost: 0 },
  { id: 'lead-04', code: 'LEAD-2026-504', name: 'Phạm Hồng Nhung', phone: '0977 123 456', email: 'nhung.ph@hoa-sen.vn', company: 'Tôn Hoa Sen Miền Nam', source: 'Hotline', status: 'Đã liên hệ', createdAt: '2026-10-03 11:00', firstResponseMinutes: 5, repId: 'rep-06', repName: 'Lê Hoàng Yến', teamId: 'team-south', unassigned: false, isStagnant: false, campaignCost: 15000 },
  { id: 'lead-05', code: 'LEAD-2026-505', name: 'Vũ Đức Thành', phone: '0933 654 321', email: 'thanh.vd@vietchem.com', company: 'Hóa chất Việt Chem', source: 'Zalo', status: 'Mới tạo', createdAt: '2026-10-02 08:45', firstResponseMinutes: 95, repId: 'rep-03', repName: 'Nguyễn Đức Minh', teamId: 'team-north', unassigned: false, isStagnant: true, campaignCost: 28000 },
  { id: 'lead-06', code: 'LEAD-2026-506', name: 'Đoàn Nhật Nam', phone: '0944 555 666', email: 'nam.dn@ktexport.com', company: 'Khánh Trình Garments', source: 'Facebook', status: 'Mới tạo', createdAt: '2026-10-01 16:20', firstResponseMinutes: 0, repId: undefined, repName: undefined, teamId: undefined, unassigned: true, isStagnant: true, campaignCost: 45000 },
  { id: 'lead-07', code: 'LEAD-2026-507', name: 'Hoàng Kim Chi', phone: '0918 777 888', email: 'chi.hk@phuclong.com.vn', company: 'Trà Sữa Phúc Long Tea', source: 'Triển lãm', status: 'Đã thẩm định', createdAt: '2026-09-30 15:00', firstResponseMinutes: 25, repId: 'rep-07', repName: 'Phan Quốc Bảo', teamId: 'team-south', unassigned: false, isStagnant: false, campaignCost: 120000 },
  { id: 'lead-08', code: 'LEAD-2026-508', name: 'Bùi Tuấn Anh', phone: '0966 333 222', email: 'anh.bt@vinatex.com.vn', company: 'Tập đoàn Dệt May Việt Nam', source: 'Website', status: 'Chuyển đổi thành Cơ hội', createdAt: '2026-09-29 10:10', firstResponseMinutes: 10, repId: 'rep-12', repName: 'Đặng Thanh Tùng', teamId: 'team-b2b', unassigned: false, isStagnant: false, campaignCost: 35000 },
  { id: 'lead-09', code: 'LEAD-2026-509', name: 'Đinh Thị Thu', phone: '0909 111 222', email: 'thu.dt@highlandscoffee.com', company: 'Highlands Coffee JSC', source: 'Facebook', status: 'Mới tạo', createdAt: '2026-10-01 09:00', firstResponseMinutes: 0, repId: undefined, repName: undefined, teamId: undefined, unassigned: true, isStagnant: true, campaignCost: 45000 },
  { id: 'lead-10', code: 'LEAD-2026-510', name: 'Lâm Văn Khoa', phone: '0922 444 888', email: 'khoa.lv@baoviet.com.vn', company: 'Tập đoàn Bảo Việt', source: 'Giới thiệu', status: 'Đã liên hệ', createdAt: '2026-10-03 16:45', firstResponseMinutes: 15, repId: 'rep-14', repName: 'Phạm Minh Tâm', teamId: 'team-tele', unassigned: false, isStagnant: false, campaignCost: 0 },
  { id: 'lead-11', code: 'LEAD-2026-511', name: 'Tạ Minh Châu', phone: '0987 654 999', email: 'chau.tm@kinhdo.vn', company: 'Mondelez Kinh Đô', source: 'Zalo', status: 'Mới tạo', createdAt: '2026-10-04 11:20', firstResponseMinutes: 14, repId: 'rep-08', repName: 'Trịnh Mai Phương', teamId: 'team-south', unassigned: false, isStagnant: false, campaignCost: 28000 },
  { id: 'lead-12', code: 'LEAD-2026-512', name: 'Vương Gia Huy', phone: '0915 222 333', email: 'huy.vg@saigoncoop.vn', company: 'Saigon Co.op', source: 'Hotline', status: 'Chuyển đổi thành Cơ hội', createdAt: '2026-10-02 14:00', firstResponseMinutes: 6, repId: 'rep-06', repName: 'Lê Hoàng Yến', teamId: 'team-south', unassigned: false, isStagnant: false, campaignCost: 15000 },
  { id: 'lead-13', code: 'LEAD-2026-513', name: 'Trịnh Quốc Thắng', phone: '0913 888 222', email: 'thang.tq@nutifood.com.vn', company: 'Công ty Cổ phần Thực phẩm Dinh dưỡng NutiFood', source: 'Website', status: 'Mới tạo', createdAt: '2026-10-05 08:30', firstResponseMinutes: 11, repId: 'rep-06', repName: 'Lê Hoàng Yến', teamId: 'team-south', unassigned: false, isStagnant: false, campaignCost: 35000 },
  { id: 'lead-14', code: 'LEAD-2026-514', name: 'Đỗ Thị Minh Hạnh', phone: '0938 777 666', email: 'hanh.dtm@sotrans.com.vn', company: 'Kho Vận Miền Nam Sotrans', source: 'Hotline', status: 'Chuyển đổi thành Cơ hội', createdAt: '2026-10-05 09:15', firstResponseMinutes: 7, repId: 'rep-07', repName: 'Phan Quốc Bảo', teamId: 'team-south', unassigned: false, isStagnant: false, campaignCost: 15000 },
];

export const MOCK_HISTORICAL_MONTHS = [
  { month: 'T05/2026', revenue: 6800000000, target: 7500000000, collected: 6200000000 },
  { month: 'T06/2026', revenue: 7400000000, target: 7800000000, collected: 6900000000 },
  { month: 'T07/2026', revenue: 8100000000, target: 8000000000, collected: 7600000000 },
  { month: 'T08/2026', revenue: 8650000000, target: 8200000000, collected: 8100000000 },
  { month: 'T09/2026', revenue: 9245000000, target: 8500000000, collected: 8430000000 },
];
