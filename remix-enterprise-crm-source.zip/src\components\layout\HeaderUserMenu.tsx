import React, { useState, useRef, useEffect } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useMultiTenant } from '../../context/MultiTenantContext';
import { ThemeMode, ProfileTab } from '../../types/crm';
import {
  User,
  ShieldCheck,
  Palette,
  BellRing,
  History,
  Building2,
  LogOut,
  Sun,
  Moon,
  Laptop,
  Check,
  X,
  ChevronRight,
  ChevronDown,
  ShieldAlert,
} from 'lucide-react';

import { THEME_PRESETS } from '../../theme/themeEngine';
import { ThemePreset } from '../../types/crm';

export const HeaderUserMenu: React.FC = () => {
  const {
    currentUser,
    currentTenant,
    tenants,
    setCurrentTenantId,
    currentRole,
    theme,
    setTheme,
    themeMode,
    setThemeMode,
    setActiveModule,
    setProfileActiveTab,
    setCurrentDocCode,
    showToast,
    switchDemoUser,
  } = useCRM();

  const { logout, setIsPlatformMode, pendingCompanyRegistrations } = useMultiTenant();

  const pendingRequestsCount = React.useMemo(() => {
    return pendingCompanyRegistrations?.filter((r) => r.status === 'PENDING').length || 0;
  }, [pendingCompanyRegistrations]);

  const [isOpen, setIsOpen] = useState(false);
  const [companyModalOpen, setCompanyModalOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);

  const handleMouseEnter = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    setIsOpen(true);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setIsOpen(false);
    }, 250);
  };

  // Close desktop dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const navigateToProfileTab = (tab: ProfileTab) => {
    setIsPlatformMode(false);
    setCurrentDocCode(null);
    setProfileActiveTab(tab);
    setActiveModule('my-profile');
    setIsOpen(false);
  };

  const handleLogout = () => {
    setIsOpen(false);
    logout();
    showToast('Đăng xuất thành công', 'Bạn đã đăng xuất khỏi phiên làm việc hiện tại.', 'info');
  };

  return (
    <div
      className="relative shrink-0"
      ref={dropdownRef}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Avatar & User Profile Button Trigger: Hover để mở menu, Click để vào thẳng Hồ sơ của tôi */}
      <button
        type="button"
        onClick={() => navigateToProfileTab('personal')}
        className={`flex items-center gap-2.5 p-1 sm:pl-1.5 sm:pr-2.5 rounded-2xl border transition-all cursor-pointer select-none group focus:outline-hidden ${
          isOpen
            ? 'bg-blue-50/80 dark:bg-blue-950/60 border-blue-300 dark:border-blue-700 shadow-xs'
            : 'bg-white/90 dark:bg-slate-800/80 border-slate-200 dark:border-slate-700/80 hover:bg-slate-50 dark:hover:bg-slate-750 hover:border-slate-300 dark:hover:border-slate-600'
        }`}
        title="Bấm để vào Hồ sơ của tôi (hoặc rê chuột để xem menu)"
        aria-label="Tài khoản cá nhân"
      >
        <img
          src={currentUser.avatar}
          alt={currentUser.fullName}
          className="w-8.5 h-8.5 rounded-full object-cover ring-2 ring-blue-500/10 dark:ring-sky-400/20 border border-slate-200/80 dark:border-slate-700 shadow-2xs shrink-0"
        />

        {/* User Info (Tên & Chức vụ) */}
        <div className="text-left hidden sm:flex flex-col min-w-0 pr-0.5">
          <span className="text-[13px] font-bold text-slate-900 dark:text-white truncate leading-tight group-hover:text-blue-600 dark:group-hover:text-sky-400 transition-colors">
            {currentUser.fullName}
          </span>
          <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 truncate leading-tight mt-0.5">
            {currentUser.role}
          </span>
        </div>

        {/* Chevron Icon */}
        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 dark:text-slate-500 hidden sm:block transition-transform duration-200 shrink-0 ${
            isOpen ? 'rotate-180 text-blue-600 dark:text-sky-400' : 'group-hover:text-slate-600 dark:group-hover:text-slate-300'
          }`}
        />
      </button>

      {/* Desktop & Tablet Dropdown Popover */}
      {isOpen && (
        <>
          {/* Backdrop on mobile for slide-up bottom sheet */}
          <div
            className="sm:hidden fixed inset-0 z-40 bg-black/40 backdrop-blur-2xs animate-in fade-in duration-200"
            onClick={() => setIsOpen(false)}
          />

          {/* Menu Container: Dropdown on desktop, Bottom Sheet on mobile */}
          <div className="fixed sm:absolute bottom-0 sm:bottom-auto left-0 sm:left-auto right-0 mt-0 sm:mt-1.5 w-full sm:w-84 bg-white dark:bg-slate-900 border-t sm:border border-slate-200 dark:border-slate-800 rounded-t-2xl sm:rounded-2xl shadow-2xl z-50 animate-in slide-in-from-bottom sm:slide-in-from-top-1 duration-200 overflow-hidden flex flex-col max-h-[85vh] sm:max-h-[560px]">
            {/* Mobile Drag Handle */}
            <div className="sm:hidden w-12 h-1.5 bg-slate-300 dark:bg-slate-700 rounded-full mx-auto my-2.5" />

            {/* Header: Avatar, Name, Email, Company, Role */}
            <div className="p-4 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60 flex items-start gap-3">
              <img
                src={currentUser.avatar}
                alt={currentUser.fullName}
                className="w-11 h-11 rounded-full object-cover border border-slate-200 dark:border-slate-700 shrink-0 shadow-xs"
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1">
                  <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 truncate">
                    {currentUser.fullName}
                  </h3>
                  <span className="text-[10px] font-semibold text-[#002659] dark:text-sky-300 bg-sky-100/80 dark:bg-sky-950 px-1.5 py-0.5 rounded shrink-0">
                    {currentUser.role}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                  {currentUser.email}
                </p>
                <div className="flex items-center gap-1.5 mt-1 text-[11px] font-medium text-slate-600 dark:text-slate-300 truncate">
                  <Building2 className="w-3 h-3 text-[#002659] dark:text-sky-400 shrink-0" />
                  <span className="truncate">Tập đoàn Vingroup</span>
                </div>
              </div>
            </div>

            {/* Menu Body */}
            <div className="p-2 overflow-y-auto space-y-0.5 flex-1 divide-y divide-slate-100 dark:divide-slate-800/60">
              {/* Lối tắt Cổng Quản Trị Nền Tảng (Chỉ hiển thị cho Super Admin) */}
              {(currentRole === 'Super Admin' || currentUser.role === 'Super Admin') && (
                <div className="pb-1">
                  <button
                    type="button"
                    onClick={() => {
                      setIsOpen(false);
                      setIsPlatformMode(true);
                      setActiveModule('platform-admin');
                    }}
                    className="w-full text-left p-2.5 rounded-xl bg-purple-50 dark:bg-purple-950/50 hover:bg-purple-100 dark:hover:bg-purple-900/60 border border-purple-200 dark:border-purple-800/60 flex items-center justify-between text-xs text-purple-900 dark:text-purple-200 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-purple-600 dark:text-purple-400 shrink-0" />
                      <div>
                        <span className="font-bold block leading-tight">Cổng Super Admin</span>
                        <span className="text-[10px] text-purple-600/80 dark:text-purple-300/80 block">Duyệt đăng ký & Cấp CSDL</span>
                      </div>
                    </div>
                    {pendingRequestsCount > 0 ? (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-400 text-slate-900 shrink-0 animate-pulse">
                        {pendingRequestsCount} chờ
                      </span>
                    ) : (
                      <ChevronRight className="w-3.5 h-3.5 text-purple-400" />
                    )}
                  </button>
                </div>
              )}

              <div className="space-y-0.5 pb-1">
                {/* 1. Hồ sơ của tôi */}
                <button
                  type="button"
                  onClick={() => navigateToProfileTab('personal')}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-xs text-slate-700 dark:text-slate-200 hover:text-[#002659] dark:hover:text-sky-400 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <User className="w-4 h-4 text-[#002659] dark:text-sky-400" />
                    <span className="font-medium">1. Hồ sơ của tôi</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* 2. Bảo mật tài khoản */}
                <button
                  type="button"
                  onClick={() => navigateToProfileTab('security')}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-xs text-slate-700 dark:text-slate-200 hover:text-[#002659] dark:hover:text-sky-400 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                    <span className="font-medium">2. Bảo mật tài khoản</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* 3. Giao diện (Gọn gàng, đều với các đề mục khác) */}
                <button
                  type="button"
                  onClick={() => navigateToProfileTab('appearance')}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-xs text-slate-700 dark:text-slate-200 hover:text-[#002659] dark:hover:text-sky-400 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <Palette className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                    <span className="font-medium">3. Giao diện</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <span className="text-[11px] font-normal">
                      {themeMode === 'light' ? 'Sáng' : themeMode === 'dark' ? 'Tối' : 'Tự động'}
                    </span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </div>
                </button>

                {/* 4. Tùy chọn thông báo */}
                <button
                  type="button"
                  onClick={() => navigateToProfileTab('notifications')}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-xs text-slate-700 dark:text-slate-200 hover:text-[#002659] dark:hover:text-sky-400 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <BellRing className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    <span className="font-medium">4. Tùy chọn thông báo</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* 5. Lịch sử thao tác */}
                <button
                  type="button"
                  onClick={() => navigateToProfileTab('activity')}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center justify-between text-xs text-slate-700 dark:text-slate-200 hover:text-[#002659] dark:hover:text-sky-400 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5">
                    <History className="w-4 h-4 text-sky-600 dark:text-sky-400" />
                    <span className="font-medium">5. Lịch sử thao tác</span>
                  </div>
                  <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                </button>
              </div>

              {/* 6. Đăng xuất (Tách riêng, màu cảnh báo đỏ) */}
              <div className="pt-1">
                <button
                  type="button"
                  onClick={handleLogout}
                  className="w-full text-left px-3 py-2 rounded-lg text-rose-600 hover:text-rose-700 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-2.5 text-xs font-semibold transition-colors cursor-pointer"
                >
                  <LogOut className="w-4 h-4" />
                  <span>6. Đăng xuất</span>
                </button>
              </div>
            </div>

            {/* Footer: Version info */}
            <div className="p-2.5 border-t border-slate-100 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-900/80 text-center">
              <span className="text-[10px] text-slate-400 font-mono tracking-tight">
                A+ Enterprise CRM v3.2.0 • Build 2026.10
              </span>
            </div>
          </div>
        </>
      )}

      {/* Switch Company Dialog */}
      {companyModalOpen && (
        <div className="fixed inset-0 z-60 bg-black/50 backdrop-blur-2xs flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-2xl p-5 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-[#002659] dark:text-sky-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Chuyển đổi công ty
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setCompanyModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-1.5 max-h-60 overflow-y-auto">
              {tenants.map((ten) => {
                const isSelected = ten.id === currentTenant.id;
                return (
                  <button
                    key={ten.id}
                    type="button"
                    onClick={() => {
                      setCurrentTenantId(ten.id);
                      setCompanyModalOpen(false);
                      setIsOpen(false);
                      showToast('Chuyển công ty', `Đã chuyển sang ${ten.name}`);
                    }}
                    className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between gap-2 cursor-pointer ${
                      isSelected
                        ? 'border-[#002659] bg-[#F0F7FD] dark:bg-sky-950/40 dark:border-sky-500'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div>
                      <div className="text-xs font-bold text-slate-900 dark:text-slate-100">
                        {ten.name}
                      </div>
                      <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                        Mã: {ten.code} • Gói: {ten.plan}
                      </div>
                    </div>
                    {isSelected && <Check className="w-4 h-4 text-[#002659] dark:text-sky-400 shrink-0" />}
                  </button>
                );
              })}
            </div>

            <div className="pt-2 text-right">
              <button
                type="button"
                onClick={() => setCompanyModalOpen(false)}
                className="px-4 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
              >
                Đóng
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
