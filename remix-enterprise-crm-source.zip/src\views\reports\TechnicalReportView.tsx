import React, { useState, useMemo } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useTechnical } from '../../context/TechnicalContext';
import {
  Wrench,
  CheckCircle2,
  Clock,
  AlertTriangle,
  DollarSign,
  Download,
  Printer,
  Search,
  Layers,
  FileCheck2,
  ShieldCheck,
  Briefcase,
  Users,
} from 'lucide-react';

export const TechnicalReportView: React.FC = () => {
  const { showToast } = useCRM();
  const {
    quotationRequests,
    projects,
    acceptanceCertificates,
    warrantyTickets,
  } = useTechnical();

  const [activeTab, setActiveTab] = useState<'projects' | 'acceptance' | 'warranty'>('projects');
  const [searchTerm, setSearchTerm] = useState('');

  // 1. KPI Metrics
  const kpis = useMemo(() => {
    const totalRequests = quotationRequests.length;
    const completedQuotes = quotationRequests.filter((q) => q.status === 'Đã hoàn tất BOM').length;
    const quoteCompletionRate = totalRequests > 0 ? Math.round((completedQuotes / totalRequests) * 100) : 0;

    const totalAcceptanceValue = acceptanceCertificates
      .filter((a) => a.status === 'Đã ký nghiệm thu')
      .reduce((sum, a) => sum + a.totalValue, 0);

    const activeProjectsCount = projects.filter((p) => p.status === 'Đang triển khai').length;

    const totalWarranty = warrantyTickets.length;
    const resolvedWarranty = warrantyTickets.filter((w) => w.status === 'Hoàn tất').length;
    const slaComplianceRate = totalWarranty > 0 ? Math.round((resolvedWarranty / totalWarranty) * 100) : 95;

    return {
      quoteCompletionRate,
      totalAcceptanceValue,
      activeProjectsCount,
      slaComplianceRate,
      signedAcceptanceCount: acceptanceCertificates.filter((a) => a.status === 'Đã ký nghiệm thu').length,
    };
  }, [quotationRequests, projects, acceptanceCertificates, warrantyTickets]);

  // 2. Filtered Projects
  const filteredProjects = useMemo(() => {
    return projects.filter((p) => {
      return (
        p.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.projectManager.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  }, [projects, searchTerm]);

  // 3. Filtered Acceptance
  const filteredAcceptance = useMemo(() => {
    return acceptanceCertificates.filter((a) => {
      return (
        a.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        a.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        a.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  }, [acceptanceCertificates, searchTerm]);

  // 4. Filtered Warranty
  const filteredWarranty = useMemo(() => {
    return warrantyTickets.filter((w) => {
      return (
        w.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
        w.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        w.title.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  }, [warrantyTickets, searchTerm]);

  return (
    <div className="space-y-6">
      {/* 1. Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300">
              Báo cáo Khối Kỹ thuật (Technical Operations)
            </span>
            <span className="text-xs text-slate-400">Khảo sát, Dự án &amp; Nghiệm thu</span>
          </div>
          <h1 className="text-xl md:text-2xl font-bold text-slate-900 dark:text-white mt-1">
            Báo cáo Triển khai Dự án &amp; Nghiệm thu Bàn giao Doanh thu
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Theo dõi tiến độ thi công dự án, tỷ lệ hoàn tất nghiệm thu để kế toán xuất hóa đơn, và cam kết chất lượng xử lý bảo hành SLA.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => window.print()}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg border border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors shadow-sm"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            In Báo cáo
          </button>
          <button
            onClick={() => showToast('Xuất báo cáo', 'Đã tải xuống file Excel báo cáo kỹ thuật & nghiệm thu.')}
            className="flex items-center gap-1.5 px-3.5 py-2 text-sm font-medium rounded-lg bg-amber-600 hover:bg-amber-700 text-white transition-colors shadow-sm"
          >
            <Download className="w-4 h-4" />
            Xuất Excel
          </button>
        </div>
      </div>

      {/* 2. Top KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3.5">
        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Giá trị nghiệm thu đã ký</span>
          <div className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {(kpis.totalAcceptanceValue || 0).toLocaleString('vi-VN')} đ
          </div>
          <span className="text-[11px] text-slate-400">{kpis.signedAcceptanceCount} biên bản ký</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Dự án đang thi công</span>
          <div className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
            {kpis.activeProjectsCount} dự án
          </div>
          <span className="text-[11px] text-slate-400">Đang triển khai</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Hoàn tất BOM từ Sales</span>
          <div className="text-xl font-bold text-slate-900 dark:text-white mt-1">
            {kpis.quoteCompletionRate}%
          </div>
          <span className="text-[11px] text-emerald-500">Sinh báo giá thương mại</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Tuân thủ SLA bảo hành</span>
          <div className="text-xl font-bold text-indigo-600 dark:text-indigo-400 mt-1">
            {kpis.slaComplianceRate}%
          </div>
          <span className="text-[11px] text-indigo-500">Đúng hạn cam kết</span>
        </div>

        <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm">
          <span className="text-xs font-medium text-slate-500">Yêu cầu bảo hành</span>
          <div className="text-lg font-bold text-amber-600 dark:text-amber-400 mt-1">
            {warrantyTickets.length} sự cố
          </div>
          <span className="text-[11px] text-slate-400">Tiếp nhận từ khách</span>
        </div>
      </div>

      {/* 3. Search Bar */}
      <div className="bg-white dark:bg-slate-800 p-4 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm flex items-center justify-between">
        <div className="flex-1 relative">
          <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo mã dự án, biên bản nghiệm thu, khách hàng..."
            className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-amber-500"
          />
        </div>
      </div>

      {/* 4. Tab Navigation */}
      <div className="flex border-b border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-4 rounded-t-xl">
        <button
          onClick={() => setActiveTab('projects')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'projects'
              ? 'border-amber-600 text-amber-600 dark:text-amber-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          Tiến Độ Dự Án Thi Công ({filteredProjects.length})
        </button>

        <button
          onClick={() => setActiveTab('acceptance')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'acceptance'
              ? 'border-amber-600 text-amber-600 dark:text-amber-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <FileCheck2 className="w-4 h-4" />
          Nghiệm Thu &amp; Chuyển Hóa Đơn ({filteredAcceptance.length})
        </button>

        <button
          onClick={() => setActiveTab('warranty')}
          className={`py-3.5 px-5 font-semibold text-sm border-b-2 flex items-center gap-2 transition-all ${
            activeTab === 'warranty'
              ? 'border-amber-600 text-amber-600 dark:text-amber-400'
              : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-emerald-500" />
          Bảo Hành &amp; Cam Kết SLA ({filteredWarranty.length})
        </button>
      </div>

      {/* 5. TAB 1: DỰ ÁN */}
      {activeTab === 'projects' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã Dự Án</th>
                  <th className="px-4 py-3.5">Tên Dự Án &amp; Khách Hàng</th>
                  <th className="px-4 py-3.5">Chủ Nhiệm Dự Án</th>
                  <th className="px-3 py-3.5 text-right">Ngân Sách</th>
                  <th className="px-3 py-3.5 text-center">Tiến Độ</th>
                  <th className="px-3 py-3.5 text-center">Thời Gian</th>
                  <th className="px-3 py-3.5 text-center">Trạng Thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {filteredProjects.map((p) => (
                  <tr key={p.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{p.code}</td>
                    <td className="px-4 py-3.5">
                      <div className="font-medium text-slate-900 dark:text-white">{p.title}</div>
                      <div className="text-xs text-slate-400">HĐ: {p.contractCode || '-'}</div>
                    </td>
                    <td className="px-4 py-3.5 text-xs text-slate-700 dark:text-slate-300">{p.projectManager}</td>
                    <td className="px-3 py-3.5 text-right font-bold text-slate-900 dark:text-white">
                      {(p.budget || 0).toLocaleString('vi-VN')} đ
                    </td>
                    <td className="px-3 py-3.5 text-center">
                      <div className="w-24 mx-auto bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                        <div
                          className="bg-amber-500 h-full rounded-full"
                          style={{ width: `${p.progress || 65}%` }}
                        />
                      </div>
                      <span className="text-[11px] font-mono text-slate-400 mt-1 block">
                        {p.progress || 65}%
                      </span>
                    </td>
                    <td className="px-3 py-3.5 text-center text-xs font-mono text-slate-500">
                      {p.startDate} → {p.endDate}
                    </td>
                    <td className="px-3 py-3.5 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          p.status === 'Hoàn tất'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300'
                            : 'bg-blue-100 text-blue-800 dark:bg-blue-900/40 dark:text-blue-300'
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. TAB 2: NGHIỆM THU */}
      {activeTab === 'acceptance' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã Biên Bản</th>
                  <th className="px-4 py-3.5">Nội Dung Nghiệm Thu</th>
                  <th className="px-4 py-3.5">Khách Hàng</th>
                  <th className="px-3 py-3.5 text-right font-bold">Giá Trị Nghiệm Thu</th>
                  <th className="px-3 py-3.5 text-center">Ngày Ký</th>
                  <th className="px-3 py-3.5 text-center">Trạng Thái</th>
                  <th className="px-4 py-3.5 text-center">Chuỗi Hóa Đơn</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {filteredAcceptance.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{a.code}</td>
                    <td className="px-4 py-3.5">
                      <div className="font-medium text-slate-900 dark:text-white">{a.title}</div>
                      <div className="text-xs text-slate-400">Dự án: {a.projectCode || '-'}</div>
                    </td>
                    <td className="px-4 py-3.5 text-slate-800 dark:text-slate-200">{a.customerName}</td>
                    <td className="px-3 py-3.5 text-right font-bold text-emerald-600 dark:text-emerald-400">
                      {(a.totalValue || 0).toLocaleString('vi-VN')} đ
                    </td>
                    <td className="px-3 py-3.5 text-center text-xs font-mono">{a.signedDate || a.acceptanceDate}</td>
                    <td className="px-3 py-3.5 text-center">
                      <span className="px-2 py-0.5 rounded text-xs font-semibold bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300">
                        {a.status}
                      </span>
                    </td>
                    <td className="px-4 py-3.5 text-center">
                      <span className="px-2.5 py-0.5 rounded text-xs font-semibold bg-sky-50 text-sky-700 border border-sky-200">
                        Sẵn sàng xuất HĐĐT
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. TAB 3: BẢO HÀNH */}
      {activeTab === 'warranty' && (
        <div className="bg-white dark:bg-slate-800 rounded-b-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden -mt-6">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-slate-600 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-900 text-xs uppercase font-semibold text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3.5">Mã Sự Cố</th>
                  <th className="px-4 py-3.5">Nội Dung Yêu Cầu</th>
                  <th className="px-4 py-3.5">Khách Hàng</th>
                  <th className="px-3 py-3.5 text-center">Phạm Vi Hạn</th>
                  <th className="px-3 py-3.5 text-center">Cam Kết SLA</th>
                  <th className="px-3 py-3.5 text-center">Trạng Thái</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                {filteredWarranty.map((w) => (
                  <tr key={w.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-700/40 transition-colors">
                    <td className="px-4 py-3.5 font-mono font-bold text-slate-900 dark:text-white">{w.code}</td>
                    <td className="px-4 py-3.5">
                      <div className="font-medium text-slate-900 dark:text-white">{w.title}</div>
                      <div className="text-xs text-slate-400">{w.description}</div>
                    </td>
                    <td className="px-4 py-3.5 text-slate-800 dark:text-slate-200">{w.customerName}</td>
                    <td className="px-3 py-3.5 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          w.isUnderWarranty
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300'
                            : 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
                        }`}
                      >
                        {w.isUnderWarranty ? 'Trong hạn bảo hành' : 'Ngoài hạn (Có phí)'}
                      </span>
                    </td>
                    <td className="px-3 py-3.5 text-center text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                      {w.slaHours || 4} giờ
                    </td>
                    <td className="px-3 py-3.5 text-center">
                      <span
                        className={`px-2 py-0.5 rounded text-xs font-semibold ${
                          w.status === 'Hoàn tất'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {w.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
