import React, { useState } from 'react';
import { useCRM } from '../../context/CRMContext';
import { useSales } from '../../context/SalesContext';
import { SalesReceipt } from '../../types/sales';
import { DocumentChainBar } from '../../components/sales/DocumentChainBar';
import { APlusLogo } from '../../components/common/APlusLogo';
import {
  Banknote,
  Search,
  Printer,
  Calendar,
  Building,
  CheckCircle2,
  XCircle,
  X,
  CreditCard,
  AlertTriangle,
  Receipt,
  RotateCcw,
} from 'lucide-react';
import { useColumnVisibility, ColumnDef } from '../../hooks/useColumnVisibility';
import { ColumnVisibilityPicker } from '../../components/common/ColumnVisibilityPicker';

const RECEIPT_COLUMNS: ColumnDef[] = [
  { id: 'receiptNumber', label: 'Số Phiếu Thu', required: true },
  { id: 'date', label: 'Ngày Thu' },
  { id: 'customer', label: 'Khách Hàng / Người Nộp' },
  { id: 'invoiceNumber', label: 'Hóa Đơn Liên Quan' },
  { id: 'amount', label: 'Số Tiền Thu' },
  { id: 'paymentMethod', label: 'Hình Thức' },
  { id: 'collector', label: 'Người Lập / Thu' },
  { id: 'status', label: 'Trạng Thái' },
  { id: 'actions', label: 'Thao Tác' },
];

export const SalesReceiptsView: React.FC = () => {
  const { showToast } = useCRM();
  const { receipts, cancelReceipt } = useSales();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedReceipt, setSelectedReceipt] = useState<SalesReceipt | null>(null);

  const {
    columns: colDefs,
    visibleColumns,
    isVisible,
    toggleColumn,
    selectAll,
    resetToDefault,
  } = useColumnVisibility('sales_receipts', RECEIPT_COLUMNS);

  // Cancel Modal
  const [isCancelModalOpen, setIsCancelModalOpen] = useState(false);
  const [cancelReasonText, setCancelReasonText] = useState('');

  const filteredReceipts = receipts.filter((r) => {
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        r.receiptNumber.toLowerCase().includes(q) ||
        r.customerName.toLowerCase().includes(q) ||
        r.payerName.toLowerCase().includes(q) ||
        (r.invoiceNumber && r.invoiceNumber.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const handlePrint = () => {
    window.print();
  };

  const handleCancelSubmit = () => {
    if (!selectedReceipt || !cancelReasonText.trim()) {
      showToast('Lỗi', 'Bắt buộc nhập lý do hủy phiếu thu.', 'warning');
      return;
    }
    cancelReceipt(selectedReceipt.id, cancelReasonText);
    setSelectedReceipt((prev) => (prev ? { ...prev, status: 'Đã hủy', cancelReason: cancelReasonText } : null));
    setIsCancelModalOpen(false);
    setCancelReasonText('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800">
                <Banknote className="w-5 h-5" />
              </span>
              Phiếu Thu Tiền (Printed Receipts)
            </h1>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono font-bold">
              {receipts.length} Phiếu thu
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Ghi nhận tiền vào quỹ, in phiếu thu chuẩn mẫu kế toán Việt Nam kèm số tiền bằng chữ và liên kết hóa đơn.
          </p>
        </div>
      </div>

      {/* Search & Actions Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-3.5 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Tìm theo số phiếu (PT-...), khách hàng, người nộp, HĐ..."
            className="w-full pl-9 pr-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
          />
        </div>

        <div className="flex items-center gap-2">
          <ColumnVisibilityPicker
            columns={colDefs}
            visibleColumns={visibleColumns}
            onToggle={toggleColumn}
            onSelectAll={selectAll}
            onReset={resetToDefault}
          />
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-200 dark:border-slate-800 uppercase text-[11px]">
              <tr>
                {isVisible('receiptNumber') && <th className="py-3 px-3">Số Phiếu Thu</th>}
                {isVisible('date') && <th className="py-3 px-3">Ngày Thu</th>}
                {isVisible('customer') && <th className="py-3 px-3">Khách Hàng / Người Nộp</th>}
                {isVisible('invoiceNumber') && <th className="py-3 px-3">Hóa Đơn Liên Quan</th>}
                {isVisible('amount') && <th className="py-3 px-3 text-right">Số Tiền Thu</th>}
                {isVisible('paymentMethod') && <th className="py-3 px-3">Hình Thức</th>}
                {isVisible('collector') && <th className="py-3 px-3">Người Lập / Thu</th>}
                {isVisible('status') && <th className="py-3 px-3">Trạng Thái</th>}
                {isVisible('actions') && <th className="py-3 px-3 text-right">Thao Tác</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredReceipts.length === 0 ? (
                <tr>
                  <td colSpan={colDefs.filter(c => isVisible(c.id)).length || 1} className="py-8 text-center text-slate-400">
                    Không tìm thấy phiếu thu nào phù hợp.
                  </td>
                </tr>
              ) : (
                filteredReceipts.map((rec) => (
                  <tr
                    key={rec.id}
                    onClick={() => setSelectedReceipt(rec)}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                  >
                    {isVisible('receiptNumber') && (
                      <td className="py-3 px-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {rec.receiptNumber}
                      </td>
                    )}

                    {isVisible('date') && (
                      <td className="py-3 px-3 font-mono text-[11px]">
                        {rec.date}
                      </td>
                    )}

                    {isVisible('customer') && (
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900 dark:text-white">{rec.customerName}</div>
                        <div className="text-[11px] text-slate-400">Người nộp: {rec.payerName}</div>
                      </td>
                    )}

                    {isVisible('invoiceNumber') && (
                      <td className="py-3 px-3 font-mono text-[11px] text-sky-600">
                        {rec.invoiceNumber || 'Thu trước/Đặt cọc'}
                      </td>
                    )}

                    {isVisible('amount') && (
                      <td className="py-3 px-3 text-right font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {rec.amount.toLocaleString()} ₫
                      </td>
                    )}

                    {isVisible('paymentMethod') && (
                      <td className="py-3 px-3">
                        <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {rec.paymentMethod}
                        </span>
                      </td>
                    )}

                    {isVisible('collector') && (
                      <td className="py-3 px-3 font-medium">
                        {rec.collectorName}
                      </td>
                    )}

                    {isVisible('status') && (
                      <td className="py-3 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            rec.status === 'Hoàn tất'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {rec.status}
                        </span>
                      </td>
                    )}

                    {isVisible('actions') && (
                      <td className="py-3 px-3 text-right" onClick={(e) => e.stopPropagation()}>
                        <button
                          onClick={() => setSelectedReceipt(rec)}
                          className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-semibold hover:bg-slate-200 text-xs flex items-center gap-1 ml-auto"
                        >
                          <Printer className="w-3 h-3 text-slate-500" />
                          <span>Xem &amp; In</span>
                        </button>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal / Sheet: In Phiếu Thu Chuẩn Việt Nam Khổ A5/A4 */}
      {selectedReceipt && (
        <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150">
          <div className="w-full max-w-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl h-[92vh] overflow-y-auto flex flex-col shadow-2xl p-6">
            {/* Top Toolbar */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800 shrink-0">
              <div className="flex items-center gap-2">
                <span className="font-mono text-xs px-2.5 py-1 rounded bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold">
                  {selectedReceipt.receiptNumber}
                </span>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 font-bold">
                  {selectedReceipt.status}
                </span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="px-3.5 py-1.5 rounded-lg bg-emerald-600 text-white font-bold text-xs flex items-center gap-1.5 hover:bg-emerald-700 shadow-sm"
                >
                  <Printer className="w-3.5 h-3.5" /> In Phiếu Thu (A5/A4)
                </button>

                {selectedReceipt.status === 'Hoàn tất' && (
                  <button
                    onClick={() => setIsCancelModalOpen(true)}
                    className="px-3 py-1.5 rounded-lg border border-rose-300 text-rose-600 font-semibold text-xs hover:bg-rose-50"
                  >
                    Hủy Phiếu Thu
                  </button>
                )}

                <button
                  onClick={() => setSelectedReceipt(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Document Chain Bar */}
            <div className="mt-4">
              <DocumentChainBar currentType="receipt" chain={selectedReceipt.chain} />
            </div>

            {/* Printable Receipt Paper (Mẫu Chuẩn Phiếu Thu Việt Nam) */}
            <div className="mt-6 flex-1 p-8 border border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 text-xs font-serif leading-relaxed space-y-6">
              {/* Header */}
              <div className="flex items-start justify-between border-b border-slate-300 dark:border-slate-800 pb-4">
                <div className="flex items-center gap-3">
                  <APlusLogo size={36} />
                  <div>
                    <h3 className="font-bold text-xs uppercase">
                      CÔNG TY CỔ PHẦN CÔNG NGHỆ VÀ THƯƠNG MẠI A+ ENTERPRISE
                    </h3>
                    <p className="text-[10px] text-slate-500 font-sans">
                      Địa chỉ: 180 Triệu Việt Vương, Hai Bà Trưng, Hà Nội
                    </p>
                    <p className="text-[10px] text-slate-500 font-sans">
                      Mã số thuế: 0108998877 • Hotline: 1900 6868
                    </p>
                  </div>
                </div>
                <div className="text-right text-[11px] font-sans">
                  <p className="font-bold">Mẫu số: 01 - TT</p>
                  <p className="text-[10px] text-slate-500">(Ban hành theo TT số 200/2014/TT-BTC)</p>
                  <p className="font-mono font-bold text-emerald-600 text-xs mt-1">Số: {selectedReceipt.receiptNumber}</p>
                </div>
              </div>

              {/* Title */}
              <div className="text-center py-2 space-y-0.5">
                <h2 className="text-xl font-bold uppercase tracking-wide">PHIẾU THU</h2>
                <p className="text-[11px] italic font-sans text-slate-500">
                  Ngày {selectedReceipt.date.split('-')[2]} tháng {selectedReceipt.date.split('-')[1]} năm {selectedReceipt.date.split('-')[0]}
                </p>
              </div>

              {/* Body Content */}
              <div className="space-y-2.5 text-xs font-sans">
                <div className="flex">
                  <span className="w-44 text-slate-500">Họ và tên người nộp tiền:</span>
                  <span className="font-bold text-slate-900 dark:text-white">{selectedReceipt.payerName}</span>
                </div>
                <div className="flex">
                  <span className="w-44 text-slate-500">Đơn vị / Khách hàng:</span>
                  <span className="font-semibold text-slate-900 dark:text-white">{selectedReceipt.customerName}</span>
                </div>
                <div className="flex">
                  <span className="w-44 text-slate-500">Địa chỉ:</span>
                  <span className="text-slate-800 dark:text-slate-200">{selectedReceipt.payerAddress || 'Việt Nam'}</span>
                </div>
                <div className="flex">
                  <span className="w-44 text-slate-500">Lý do nộp:</span>
                  <span className="text-slate-800 dark:text-slate-200">{selectedReceipt.reason}</span>
                </div>
                <div className="flex items-center">
                  <span className="w-44 text-slate-500">Số tiền nộp:</span>
                  <span className="font-mono font-bold text-base text-emerald-600">
                    {selectedReceipt.amount.toLocaleString()} VNĐ
                  </span>
                </div>
                <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-lg border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200">
                  <strong>Viết bằng chữ: </strong>
                  <em>{selectedReceipt.amountInWords}</em>
                </div>
                <div className="flex">
                  <span className="w-44 text-slate-500">Hình thức thanh toán:</span>
                  <span className="font-semibold">{selectedReceipt.paymentMethod}</span>
                  {selectedReceipt.bankRefNumber && (
                    <span className="text-slate-500 ml-2 font-mono">({selectedReceipt.bankRefNumber})</span>
                  )}
                </div>
                <div className="flex">
                  <span className="w-44 text-slate-500">Kèm theo chứng từ gốc:</span>
                  <span className="text-slate-700 dark:text-slate-300">
                    Hóa đơn {selectedReceipt.invoiceNumber || 'GTGT điện tử'}
                  </span>
                </div>
              </div>

              {/* Signatures */}
              <div className="grid grid-cols-4 gap-4 text-center pt-8 text-xs font-sans">
                <div>
                  <p className="font-bold">Giám đốc</p>
                  <p className="text-[10px] text-slate-400 italic">(Ký, đóng dấu)</p>
                  <div className="h-16" />
                  <p className="font-bold">Trần Minh Đức</p>
                </div>
                <div>
                  <p className="font-bold">Kế toán trưởng</p>
                  <p className="text-[10px] text-slate-400 italic">(Ký, họ tên)</p>
                  <div className="h-16" />
                  <p className="font-bold">{selectedReceipt.cashierName}</p>
                </div>
                <div>
                  <p className="font-bold">Người nộp tiền</p>
                  <p className="text-[10px] text-slate-400 italic">(Ký, họ tên)</p>
                  <div className="h-16" />
                  <p className="font-bold">{selectedReceipt.payerName}</p>
                </div>
                <div>
                  <p className="font-bold">Người lập phiếu</p>
                  <p className="text-[10px] text-slate-400 italic">(Ký, họ tên)</p>
                  <div className="h-16" />
                  <p className="font-bold">{selectedReceipt.collectorName}</p>
                </div>
              </div>

              {selectedReceipt.status === 'Đã hủy' && (
                <div className="p-3 bg-rose-100 text-rose-800 rounded-lg text-center font-bold">
                  PHIẾU THU ĐÃ HỦY • LÝ DO: {selectedReceipt.cancelReason}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal: Hủy Phiếu Thu */}
      {isCancelModalOpen && selectedReceipt && (
        <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl text-xs">
            <h3 className="font-bold text-rose-600 text-base mb-2">
              Hủy Phiếu Thu: {selectedReceipt.receiptNumber}
            </h3>
            <p className="text-slate-500 mb-3">
              Sau khi hủy, số tiền thu sẽ được hoàn tác vào công nợ của hóa đơn {selectedReceipt.invoiceNumber} và khách hàng.
            </p>
            <div>
              <label className="block text-slate-600 font-semibold mb-1">Lý do hủy bắt buộc *</label>
              <textarea
                rows={3}
                required
                value={cancelReasonText}
                onChange={(e) => setCancelReasonText(e.target.value)}
                placeholder="Nhập sai thông tin, khách hàng hủy giao dịch chuyển khoản..."
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800"
              />
            </div>
            <div className="flex items-center justify-end gap-2 mt-4">
              <button
                onClick={() => setIsCancelModalOpen(false)}
                className="px-3 py-1.5 rounded-lg border border-slate-300 text-slate-600"
              >
                Đóng
              </button>
              <button
                onClick={handleCancelSubmit}
                className="px-4 py-1.5 rounded-lg bg-rose-600 text-white font-bold"
              >
                Xác Nhận Hủy
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
