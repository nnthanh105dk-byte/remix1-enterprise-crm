import React, { useState } from 'react';
import { TrendingUp, TrendingDown, AlertTriangle, ArrowRight } from 'lucide-react';
import { useCRM } from '../../context/CRMContext';
import { getReportText, formatCurrencyShort } from '../../i18n/translations';

export interface KPICardProps {
  title: string;
  value: string;
  target?: string;
  percentProgress?: number;
  changePercent?: number; // e.g. +14.5 or -8.2
  changePeriodLabel?: string;
  icon: React.ComponentType<{ className?: string }>;
  iconColor?: string;
  onClickDrilldown?: () => void;
  drilldownHint?: string;
  explanation?: string | React.ReactNode;
  badge?: string;
}

const getCornerAccent = (iconColor?: string) => {
  if (!iconColor) {
    return {
      gradient: 'from-sky-500/18 via-sky-500/5 to-transparent',
      bar: 'bg-sky-500',
    };
  }
  if (iconColor.includes('emerald')) {
    return {
      gradient: 'from-emerald-500/18 via-emerald-500/5 to-transparent',
      bar: 'bg-emerald-500',
    };
  }
  if (iconColor.includes('blue')) {
    return {
      gradient: 'from-blue-500/18 via-blue-500/5 to-transparent',
      bar: 'bg-blue-500',
    };
  }
  if (iconColor.includes('indigo')) {
    return {
      gradient: 'from-indigo-500/18 via-indigo-500/5 to-transparent',
      bar: 'bg-indigo-500',
    };
  }
  if (iconColor.includes('amber')) {
    return {
      gradient: 'from-amber-500/18 via-amber-500/5 to-transparent',
      bar: 'bg-amber-500',
    };
  }
  if (iconColor.includes('purple')) {
    return {
      gradient: 'from-purple-500/18 via-purple-500/5 to-transparent',
      bar: 'bg-purple-500',
    };
  }
  if (iconColor.includes('rose')) {
    return {
      gradient: 'from-rose-500/18 via-rose-500/5 to-transparent',
      bar: 'bg-rose-500',
    };
  }
  return {
    gradient: 'from-sky-500/18 via-sky-500/5 to-transparent',
    bar: 'bg-sky-500',
  };
};

export const KPICard: React.FC<KPICardProps> = ({
  title,
  value,
  target,
  percentProgress,
  changePercent,
  changePeriodLabel = 'kỳ trước',
  icon: Icon,
  iconColor = 'text-sky-500 bg-sky-50 dark:bg-sky-950/60 border-sky-200 dark:border-sky-800',
  onClickDrilldown,
  drilldownHint,
  badge,
}) => {
  const isPositive = changePercent !== undefined && changePercent >= 0;
  const corner = getCornerAccent(iconColor);

  return (
    <div
      onClick={onClickDrilldown}
      className={`relative overflow-hidden bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-xl p-4.5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.1)] hover:-translate-y-0.5 transition-all duration-200 flex flex-col justify-between ${
        onClickDrilldown ? 'cursor-pointer hover:border-sky-400 dark:hover:border-sky-500 group' : ''
      }`}
    >
      {/* Điểm nhấn màu ở góc card để làm nổi bật hơn, tránh đơn điệu */}
      <div className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl ${corner.gradient} rounded-bl-full pointer-events-none opacity-90`} />
      <div className={`absolute top-0 right-0 w-12 h-1 rounded-bl-sm ${corner.bar} pointer-events-none`} />

      <div className="relative z-10">
        <div className="flex items-start justify-between gap-2">
          <p className="text-[14.5px] sm:text-[15px] font-bold text-slate-800 dark:text-slate-100 tracking-tight leading-snug">
            {title}
          </p>
          <div className="flex items-center gap-1.5 shrink-0">
            <div className={`w-8.5 h-8.5 rounded-lg border flex items-center justify-center shrink-0 shadow-2xs ${iconColor}`}>
              <Icon className="w-4.5 h-4.5" />
            </div>
          </div>
        </div>

        {/* Big Bold Metric for Executive Visibility */}
        <h3 className="text-[28px] sm:text-[32px] font-black text-slate-900 dark:text-white mt-2.5 font-mono tracking-tight tabular-nums leading-none">
          {value}
        </h3>
      </div>

      {/* Dòng so sánh (chỉ hiển thị khi có so sánh được truyền vào) */}
      {changePercent !== undefined && (
        <div className="relative z-10 mt-3 flex items-center gap-1.5 flex-wrap">
          <span
            className={`inline-flex items-center font-bold px-1.5 py-0.5 rounded text-[11.5px] shrink-0 whitespace-nowrap ${
              isPositive
                ? 'text-emerald-700 bg-emerald-50 dark:bg-emerald-950/60 dark:text-emerald-400 border border-emerald-200/70 dark:border-emerald-800'
                : 'text-rose-700 bg-rose-50 dark:bg-rose-950/60 dark:text-rose-400 border border-rose-200/70 dark:border-rose-800'
            }`}
          >
            {isPositive ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
            {isPositive ? `+${changePercent}%` : `${changePercent}%`}
          </span>
          <span className="text-[12px] font-medium text-slate-500 dark:text-slate-400 whitespace-nowrap">
            so với {changePeriodLabel}
          </span>
        </div>
      )}
    </div>
  );
};

export interface ExecutiveStatCardProps {
  title: string;
  value: string | number;
  icon?: React.ComponentType<{ className?: string }>;
  iconColor?: string;
  valueColor?: string;
  className?: string;
  explanation?: React.ReactNode | string;
  badge?: string;
  onClick?: () => void;
}

export const ExecutiveStatCard: React.FC<ExecutiveStatCardProps> = ({
  title,
  value,
  icon: Icon,
  iconColor = 'text-sky-600 bg-sky-50 dark:bg-sky-950/50 border-sky-200 dark:border-sky-800',
  valueColor = 'text-slate-900 dark:text-white',
  className = '',
  badge,
  onClick,
}) => {
  const corner = getCornerAccent(iconColor);

  return (
    <div
      onClick={onClick}
      className={`relative overflow-hidden bg-white dark:bg-slate-900 border border-slate-200/90 dark:border-slate-800 rounded-xl p-4.5 shadow-[0_4px_20px_-2px_rgba(0,0,0,0.06),0_2px_6px_-1px_rgba(0,0,0,0.03)] hover:shadow-[0_8px_26px_-2px_rgba(0,0,0,0.1)] hover:-translate-y-0.5 transition-all duration-200 ${
        onClick ? 'cursor-pointer hover:border-sky-400 dark:hover:border-sky-600' : ''
      } ${className}`}
    >
      {/* Điểm nhấn màu ở góc card */}
      <div className={`absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl ${corner.gradient} rounded-bl-full pointer-events-none opacity-90`} />
      <div className={`absolute top-0 right-0 w-12 h-1 rounded-bl-sm ${corner.bar} pointer-events-none`} />

      <div className="relative z-10 flex items-start justify-between gap-2">
        <span className="text-[14.5px] sm:text-[15px] font-bold text-slate-800 dark:text-slate-100 leading-snug tracking-tight">
          {title}
        </span>
        {Icon && (
          <div className={`w-8.5 h-8.5 rounded-lg border flex items-center justify-center shrink-0 shadow-2xs ${iconColor}`}>
            <Icon className="w-4.5 h-4.5" />
          </div>
        )}
      </div>

      <div className={`relative z-10 text-[28px] sm:text-[32px] font-black tracking-tight mt-2.5 font-mono tabular-nums leading-none ${valueColor}`}>
        {value}
      </div>

      {badge && (
        <div className="relative z-10 mt-2.5">
          <span className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
            {badge}
          </span>
        </div>
      )}
    </div>
  );
};

interface FunnelStageItem {
  id: string;
  name: string;
  count: number;
  value: number; // VND
  conversionFromPrev: number; // %
  avgDwellDays: number;
  isBottleneck?: boolean;
}

export const FunnelVisualChart: React.FC<{
  stages: FunnelStageItem[];
  onStageClick?: (stageId: string) => void;
}> = ({ stages, onStageClick }) => {
  const maxCount = Math.max(...stages.map((s) => s.count), 1);

  return (
    <div className="space-y-3">
      {stages.map((st, idx) => {
        const widthPct = Math.max(35, Math.round((st.count / maxCount) * 100));

        return (
          <div
            key={st.id}
            onClick={() => onStageClick && onStageClick(st.id)}
            className={`p-3 rounded-xl border transition-all ${
              st.isBottleneck
                ? 'bg-amber-50/60 dark:bg-amber-950/20 border-amber-300 dark:border-amber-800'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
            } ${onStageClick ? 'cursor-pointer hover:border-sky-400' : ''}`}
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-slate-100 dark:bg-slate-800 font-mono text-[11px] font-bold flex items-center justify-center text-slate-700 dark:text-slate-300">
                  {idx + 1}
                </span>
                <span className="font-bold text-slate-900 dark:text-white text-sm">{st.name}</span>
                {st.isBottleneck && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-white animate-pulse">
                    <AlertTriangle className="w-3 h-3" /> Điểm nghẽn phễu
                  </span>
                )}
              </div>

              <div className="flex items-center gap-3 text-slate-600 dark:text-slate-300">
                <span className="font-semibold text-slate-900 dark:text-white">
                  {st.count} deal ({((st.value || 0) / 1000000).toLocaleString('vi-VN')} Tr)
                </span>
                {idx > 0 && (
                  <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-sky-50 dark:bg-sky-950/50 text-sky-600 dark:text-sky-400 font-bold border border-sky-100 dark:border-sky-900">
                    Chuyển đổi: {st.conversionFromPrev}%
                  </span>
                )}
                <span className="text-[11px] text-slate-500 dark:text-slate-400">
                  TB {st.avgDwellDays} ngày
                </span>
              </div>
            </div>

            {/* Visual Funnel Bar */}
            <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-3 overflow-hidden">
              <div
                style={{ width: `${widthPct}%` }}
                className={`h-full rounded-full transition-all duration-500 ${
                  st.isBottleneck
                    ? 'bg-gradient-to-r from-amber-500 to-amber-600'
                    : idx === stages.length - 1
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-500'
                    : 'bg-gradient-to-r from-sky-500 to-blue-600'
                }`}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};

export const MonthlyComparisonBarChart: React.FC<{
  data: { month: string; revenue: number; target: number; collected: number }[];
}> = ({ data }) => {
  const { language } = useCRM();
  const maxVal = Math.max(...data.map((d) => Math.max(d.revenue, d.target)), 1000000);

  const legendRecognized = getReportText('legendRecognized', language);
  const legendCollected = getReportText('legendCollected', language);
  const legendQuota = getReportText('legendQuota', language);

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-end gap-4 text-xs">
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-xs bg-sky-500" />
          <span className="text-slate-600 dark:text-slate-300">{legendRecognized}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-xs bg-emerald-500" />
          <span className="text-slate-600 dark:text-slate-300">{legendCollected}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="w-3 h-3 rounded-xs bg-amber-400" />
          <span className="text-slate-600 dark:text-slate-300">{legendQuota}</span>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2 items-end pt-6 min-h-[220px]">
        {data.map((item, idx) => {
          const revHeight = Math.round((item.revenue / maxVal) * 150);
          const colHeight = Math.round((item.collected / maxVal) * 150);
          const targetHeight = Math.round((item.target / maxVal) * 150);
          const pct = Math.round((item.revenue / item.target) * 100);

          return (
            <div key={idx} className="flex flex-col items-center gap-2 group">
              <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400">
                {pct}%
              </span>

              {/* Bar Container */}
              <div className="h-[150px] w-full flex items-end justify-center gap-1 px-1 bg-slate-50 dark:bg-slate-800/40 rounded-lg relative">
                {/* Target line indicator */}
                <div
                  style={{ bottom: `${targetHeight}px` }}
                  className="absolute left-0 right-0 border-b-2 border-dashed border-amber-400 z-10"
                  title={`${legendQuota}: ${formatCurrencyShort(item.target, language)}`}
                />

                {/* Revenue Bar */}
                <div
                  style={{ height: `${revHeight}px` }}
                  className="w-1/2 max-w-[18px] bg-sky-500 group-hover:bg-sky-400 rounded-t-sm transition-all"
                  title={`${legendRecognized}: ${formatCurrencyShort(item.revenue, language)}`}
                />

                {/* Collected Bar */}
                <div
                  style={{ height: `${colHeight}px` }}
                  className="w-1/2 max-w-[18px] bg-emerald-500 group-hover:bg-emerald-400 rounded-t-sm transition-all"
                  title={`${legendCollected}: ${formatCurrencyShort(item.collected, language)}`}
                />
              </div>

              <span className="text-xs font-semibold text-slate-700 dark:text-slate-300 truncate">
                {(() => {
                  const match = item.month.match(/T?(\d{2})\/(\d{4})/);
                  if (!match) return item.month;
                  const monthNum = parseInt(match[1], 10);
                  const year = match[2];
                  if (language === 'vi') return `T${match[1]}/${year}`;
                  if (language === 'ja') return `${year}年${monthNum}月`;
                  const enMonths = ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                  return `${enMonths[monthNum]} ${year}`;
                })()}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
