/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useMultiTenant } from '../../context/MultiTenantContext';
import { Building2, Check, X, ArrowRight, ShieldCheck } from 'lucide-react';

interface SwitchCompanyModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SwitchCompanyModal: React.FC<SwitchCompanyModalProps> = ({ isOpen, onClose }) => {
  const { userCompanies, currentCompany, switchCompany } = useMultiTenant();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full shadow-2xl p-5 space-y-4 text-xs animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 flex items-center justify-center">
              <Building2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Chuyển Đổi Không Gian Làm Việc
              </h3>
              <p className="text-[11px] text-slate-400">
                Tài khoản của bạn tham gia vào {userCompanies.length} tổ chức doanh nghiệp
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-2">
          {userCompanies.map((comp) => {
            const isCurrent = comp.id === currentCompany?.id;
            return (
              <button
                key={comp.id}
                type="button"
                onClick={() => {
                  if (!isCurrent) {
                    switchCompany(comp.id);
                  }
                  onClose();
                }}
                className={`w-full p-3.5 rounded-xl border text-left flex items-center justify-between transition-all ${
                  isCurrent
                    ? 'bg-blue-50/80 dark:bg-blue-950/40 border-blue-400 dark:border-blue-600/60 shadow-xs'
                    : 'bg-white dark:bg-slate-800/40 border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                      isCurrent
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                    }`}
                  >
                    {comp.code.substring(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-slate-900 dark:text-white">
                        {comp.name}
                      </span>
                      {isCurrent && (
                        <span className="px-1.5 py-0.5 rounded bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 text-[9px] font-bold">
                          Hiện tại
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 mt-0.5">
                      <span className="font-mono">{comp.code}</span>
                      <span>• MST: {comp.taxCode}</span>
                    </div>
                  </div>
                </div>

                {isCurrent ? (
                  <Check className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0" />
                ) : (
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-slate-600 shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <span className="text-[10px] text-slate-400">
            Dữ liệu của từng công ty được cách ly an toàn 100%.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 font-semibold text-slate-700 dark:text-slate-300"
          >
            Đóng
          </button>
        </div>
      </div>
    </div>
  );
};
